const Constants = Object.freeze({
  accessControlConfig: {
    ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX: "accessmapping_",
    PROJECT_USERS_CACHE_KEY_PREFIX: "project_users_",
  },
  accessObjectKeys: {
    //WIR
    WIR_ACCESS_ALL_WIRS: "WIR_ACCESS_ALL_WIRS",    
  }  
});
module.exports = { Constants };