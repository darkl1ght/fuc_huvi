const { vimeoConfig } = require(".");
let Vimeo = require("vimeo").Vimeo;

let vimeoClient = new Vimeo(
  vimeoConfig.clientId,
  vimeoConfig.clientSecret,
  vimeoConfig.accessToken
);

module.exports = vimeoClient;
