"use strict";

module.exports = {
  secret:
    process.env.NODE_ENV === "production"
      ? process.env.SECRET
      : "401b09eab3c013d4ca54922bb802bec8fd5318192b0a75f201d8b3727429090fb337591abd3e44453b954555b7a0812e1081c39b740293f765eae731f5a65ed1",
  mapboxAccessToken:
    process.env.NODE_ENV === "production"
      ? process.env.MAPBOX_TOKEN
      : "sk.eyJ1IjoiZGFya2wxZ2h0IiwiYSI6ImNraDF1aHFudzA4dWEycnBxZ3p5ZWs2Z20ifQ.HrbQo001IxHwLLZOqP-z5A",
  mapboxTilequeryAccessToken:
    process.env.NODE_ENV === "production"
      ? process.env.MAPBOX_TILEQUERY_TOKEN
      : "pk.eyJ1IjoiZGFya2wxZ2h0IiwiYSI6ImNrZXJ6em5qNjB5ZnczMHF4bnBxbDJqdmwifQ.U9-tTIfhplv4wWNET22sDg",
  mapboxTilesetDeleteToken:
    process.env.NODE_ENV === "production"
      ? process.env.MAPBOX_TILESET_DELETE_TOKEN
      : "sk.eyJ1IjoiZGFya2wxZ2h0IiwiYSI6ImNrbXI3NXh0bTA1NmUyeHBldXg0MmRkMWgifQ.p2aiL1BfCHYIOyvjM4cYbw",
  firebase: {
    AWS_FIREBASE_ACCESS_KEY_ID: process.env.AWS_FIREBASE_ACCESS_KEY_ID,
    AWS_FIREBASE_SECRET_ACCESS_KEY: process.env.AWS_FIREBASE_SECRET_ACCESS_KEY,
  },
  procore: {
    client_id:
      process.env.NODE_ENV === "production"
        ? process.env.PROCORE_CLIENT_ID
        : "3c2668d5a2dffab972a18520f99b98e8a223fb3de5a354963f17d2dcdeefddae",
    client_secret:
      process.env.NODE_ENV === "production"
        ? process.env.PROCORE_CLIENT_SECRET
        : "e908e48f352abe19312abd6eca593582302f677a8cd2a977b938644da29c1393",
    token_endpoint:
      process.env.NODE_ENV === "production"
        ? process.env.PROCORE_TOKEN_ENDPOINT
        : "https://login-sandbox.procore.com/oauth/token",
    redirect_uri:
      process.env.NODE_ENV === "production"
        ? process.env.PROCORE_REDIRECT_URI
        : "https://qa.huviair.com/callback",
    endpoint_base:
      process.env.NODE_ENV === "production"
        ? process.env.PROCORE_ENDPOINT_BASE
        : "https://sandbox.procore.com/rest/v1.0",
  },
  livestream: {
    PASSWORD: "huviair",
    LIVE_STREAM_HOST:
      process.env.NODE_ENV === "production"
        ? process.env.LIVE_STREAM_HOST
        : "https://portal.huviair.com:6001/api/",
    WITH_REC: "source/register/record",
    WITHOUT_REC: "source/register",
    REC_OPTION: "recorder/stream/{{source_name}}/action/start",
    DELETE_SOURCE: "source/{{source_name}}",
    STREAM_STATISTICS: "stream/liveDetails/{{source_name}}",
  },
  geoprocessingAPI: {
    AERIAL_TOUR_CONTAINER_BASE_URL:
      process.env.NODE_ENV === "production"
        ? process.env.AERIAL_TOUR_CONTAINER_BASE_URL
        : "https://huviairinspection.blob.core.windows.net/aerialtour",
    BASE_URL:
      process.env.NODE_ENV === "production"
        ? process.env.GEOPROCESSING_BASE_URL
        : "https://geoprocessing.huviair.com",
    PORT: "8000",
    PROCESSING_PATH: "/process/beginImageProcessing/{projectId}/{tourId}",
    MAP_PROCESSED_URLS_PATH: "/process_status/url/{tourId}",
  },
  mapboxAPI: {
    BASE_URL: "https://api.mapbox.com",
    UPLOADS_RESOURCE: "/uploads/v1",
    MAPBOX_USERNAME:
      process.env.NODE_ENV === "production"
        ? process.env.MAPBOX_USERNAME
        : "darkl1ght",
    CREDENTIALS_PATH: "/{username}/credentials",
    UPLOAD_ID_PATH: "/{username}",
    UPLOAD_STATUS_PATH: "/{username}/{upload_id}",
    TILEQUERY_RESOURCE: "/v4/{tileset_id}/tilequery/{lon},{lat}.json",
    TILESET_DELETE_RESOURCE: "/tilesets/v1/{tileset_id}",
  },
  azureStorage: {
    AzureAccountName:
      process.env.NODE_ENV === "production"
        ? process.env.AzureAccountName
        : "huviairinspection",
    AzureAccountKey:
      process.env.NODE_ENV === "production"
        ? process.env.AzureAccountKey
        : "D3rj08WOOL7iMo9BLM9Ihukf9Gy6KKF+h04h3+WK1TBJ4SQiKcsxU/gExfInyOj2hYT82aIv99BuKS49TyqyrQ==",
    AzureWebJobsStorage:
      process.env.NODE_ENV === "production"
        ? process.env.AzureWebJobsStorage
        : "DefaultEndpointsProtocol=https;AccountName=huviairinspection;AccountKey=D3rj08WOOL7iMo9BLM9Ihukf9Gy6KKF+h04h3+WK1TBJ4SQiKcsxU/gExfInyOj2hYT82aIv99BuKS49TyqyrQ==;EndpointSuffix=core.windows.net",
    containers: {
      blobRawdataSMRef:
        process.env.NODE_ENV === "production"
          ? process.env.blobRef
          : "rawdata-sm",
      blobMediaRef:
        process.env.NODE_ENV === "production"
          ? process.env.blobMediaRef
          : "media",
      blobDrawingRef:
        process.env.NODE_ENV === "production"
          ? process.env.blobDrawingRef
          : "floor-plan",
      blobSignatureRef:
        process.env.NODE_ENV === "production"
          ? process.env.blobSignatureRef
          : "signature",
      blobContainerBaseUrl:
        process.env.NODE_ENV === "production"
          ? process.env.blobContainer
          : "https://huviairinspection.blob.core.windows.net/",
      aerialtourContainer:
        process.env.NODE_ENV === "production"
          ? process.env.aerialtourContainer
          : "aerialtour",
      virtualtourContainer:
        process.env.NODE_ENV === "production"
          ? process.env.virtualtourContainer
          : "virtualtour",
      mapOutputContainer:
        process.env.NODE_ENV === "production"
          ? process.env.mapOutputContainer
          : "mapoutputs",
    },
  },
  email: {
    fromEmail:
      process.env.NODE_ENV === "production"
        ? process.env.FROM_EMAIL
        : "Huviair Support<info@huviair.com>",
    sendGridKey:
      process.env.NODE_ENV === "production"
        ? process.env.SENDGRID_KEY
        : "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",
  },
  autocadForge: {
    clientId:
      process.env.NODE_ENV === "production"
        ? process.env.FORGE_CLIENT_ID
        : "BY1YR2fxkSZOc3Y0izlzYld75JtHHeK7",
    clientSecret:
      process.env.NODE_ENV === "production"
        ? process.env.FORGE_CLIENT_SECRET
        : "O85604198af784be",
    scopes: {
      // Required scopes for the server-side application
      internal: [
        "bucket:create",
        "bucket:read",
        "data:read",
        "data:create",
        "data:write",
        "bucket:delete",
      ],
      // Required scope for the client-side viewer
      public: ["data:read", "viewables:read"],
    },
  },
  redisConfig: {
    redisHost: process.env.REDIS_HOST,
    redisPort:
      process.env.NODE_ENV === "production" ? process.env.REDIS_PORT : "6379",
  },
  messageBrokerConfig: {
    url:
      process.env.NODE_ENV === "production"
        ? process.env.MESSAGE_BROKER_URL
        : "amqps://huviair:Huviair%23RabbitmqUser@b-be044d50-86e9-408c-87c5-78ae0c290831.mq.ap-south-1.amazonaws.com:5671",
  },
  vimeoConfig: {
    accessToken: "596aa3198d55d0f76072efd69a6f85f4",
    clientId: "f191b6b4b7f9cdfef250ecd09e8b643ac56336f6",
    clientSecret:
      "WaJTJkLW13S9CnsU5BDKuFBxZ5sOOo7PiG+yfXWF+ZHjZpJxQbywWKVObizRcIOJOsxa6asNf9zfVKicq2owzugDAtpbVQfyIJG1hipXKr+bnleW+HR8XKe1rVvs/XEV",
  },
};
