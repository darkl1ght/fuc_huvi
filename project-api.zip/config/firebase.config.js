const { spawn } = require("child_process");
const logger = require("../common/logger");
const firebase = require("firebase-admin");
const { firebase: firebase_aws } = require("./index");
const path = require("path");
const fs = require("fs");

const FIREBASE_CRED_FILE = path.join(
  __dirname,
  "huviair-app-service-account.json"
);

let childProcess;

module.exports = async () => {
  try {
    if (!fs.existsSync(FIREBASE_CRED_FILE)) {
      if (childProcess) childProcess.kill();

      const command = `aws s3 cp s3://huviair-google-firebase/huviair-app-service-account.json config/huviair-app-service-account.json`;
      childProcess = spawn(command, {
        shell: true,
        env: {
          AWS_ACCESS_KEY_ID: firebase_aws.AWS_FIREBASE_ACCESS_KEY_ID,
          AWS_SECRET_ACCESS_KEY: firebase_aws.AWS_FIREBASE_SECRET_ACCESS_KEY,
        },
      });

      childProcess.stdout.on("data", (data) => {
        logger.info(`Firebase json file downloaded successfully: ${data}`);
        firebase.initializeApp({
          credential: firebase.credential.cert(FIREBASE_CRED_FILE),
        });
        logger.info(`Initialized firebase`);
      });

      childProcess.stderr.on("data", (data) => {
        logger.error(`Firebase json file download failed: ${data}`);
      });

      childProcess.on("close", (code) => {});

      childProcess.on("exit", (code) => {
        logger.info(`Child process exited with code ${code}`);
      });

      childProcess.on("error", (error) => {
        logger.error(`Child process encountered an error: ${error}`);
      });
    } else {
      firebase.initializeApp({
        credential: firebase.credential.cert(FIREBASE_CRED_FILE),
      });
      logger.info(`Initialized firebase`);
    }
  } catch (error) {
    logger.error(`Error in firebase file download`, error);
  }
};
