const { messageBrokerConfig } = require("../index");
const { AMQPClient } = require("@cloudamqp/amqp-client");
const logger = require("../../common/logger");

/**
 * Broker for async messaging
 */
let instance;

class MessageBroker {
  connection;
  channel;

  /**
   * Initialize connection to rabbitMQ
   */
  async init() {
    const amqp = new AMQPClient(messageBrokerConfig.url);
    this.connection = await amqp.connect();
    return this;
  }

  async send(queueName, msg) {
    if (this.connection.closed) {
      await this.init();
    }
    let channel = await this.connection.channel();
    let queue = await channel.queue(queueName, { durable: true });
    await queue.publish(Buffer.from(JSON.stringify(msg)), {
      deliveryMode: 2,
    });
    await channel.close();
    await this.connection.close();
    logger.info("Sent message to RabbitMQ: " + JSON.stringify(msg));
  }
  /**
   * @return {Promise<MessageBroker>}
   */
  static getInstance() {
    if (!instance) {
      const broker = new MessageBroker();
      instance = broker.init();
    }
    return instance;
  }
}

module.exports = { MessageBroker };
