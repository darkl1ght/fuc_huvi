const messagingConstants = Object.freeze({
  queueNames: {
    NOTIFICATIONS_QUEUE: "notifications",
    VIDEO_PROCESSING_QUEUE: "360-video-processing",
    PHOTO_MODE_PROCESSING_QUEUE: "photo-mode-processing-queue",
  },
  messageType: {
    TYPE_START_INTERIOR_VIDEO_PROCESSING: "Start interior video processing",
    TYPE_START_PHOTO_MODE_PROCESSING_QUEUE: "Start interior photo processing",
  },
});

module.exports = messagingConstants;
