"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const InteriorTour = mongoose.model("InteriorTour");
const InteriorWBS = mongoose.model("InteriorWBS");
const LookUp = mongoose.model("LookUp");
const FieldIssue = mongoose.model("FieldIssue");
const MasterData = mongoose.model("MasterData");
const TourImage = mongoose.model("TourImage");
const fs = require("fs");
const auth = require("../../auth");
const Utils = require("../../../common/util");
const path = require("path");
const moment = require("moment-timezone");
const Util = require("../../../common/util");
const Logger = require("../../../common/logger");
const { saveForDownloadReport } = require("../../../common/fieldissue-report");
const _ = require("lodash");

// Preload project objects on routes with ':project'
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.param("interior", (req, res, next, interiorId) => {
  InteriorTour.findOne({
    interiorId: interiorId,
  })
    .then((interior) => {
      if (!interior) {
        return res.sendStatus(404);
      }
      req.interior = interior;
      return next();
    })
    .catch(next);
});

router.param("tour", (req, res, next, tourId) => {
  TourImage.findOne({
    tourId: tourId,
  })
    .then((tour) => {
      if (!tour) {
        return res.sendStatus(404);
      }
      req.tour = tour;
      return next();
    })
    .catch(next);
});

router.put(
  "/:project/:issueId/downloadpdfreport",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (req.project) {
              const rootDir = path.dirname(
                path.dirname(path.dirname(__dirname))
              );
              const savePath = path.join(
                rootDir,
                "temp_report",
                req.params.issueId + ".pdf"
              );
              const fieldIssue = await FieldIssue.findOne({
                projectId: req.project.projectId,
                issueId: req.params.issueId,
              }).catch(next);
              await saveForDownloadReport(
                fieldIssue,
                req.project,
                req.payload.firstName + " " + req.payload.lastName,
                savePath,
                req.body
              );
              await Utils.wait(500);
              const data = fs.readFileSync(savePath);
              res.setHeader("Content-Type", "text/plain");
              res.send(data.toString("base64"));
              fs.unlink(savePath, (_err) => {
                // console.log("File was deleted");
              });
            } else {
              res.sendStatus(401);
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.post("/:project/:tour/create", auth.required, async (req, res, next) => {
  await Project.countDocuments(
    {
      users: {
        $elemMatch: {
          email: req.payload.email,
          isActive: true,
          isBlocked: false,
        },
      },
      projectId: req.project.projectId,
      isActive: true,
    },
    async (err, count) => {
      if (count > 0 || req.payload.isAdmin) {
        let priorityLookup;
        let statusLookup;
        const { users: projectTeam, projectName } = req.project;
        const { fieldIssue, uploadedFileObject } = req.body;
        const { newDiscussion } = fieldIssue;
        let wbsLinksDesc = "";
        const lastFieldIssueNumber = req.tour.lastFieldIssueNumber || 0;
        const fiDoc = new FieldIssue(fieldIssue);
        fiDoc.issueNumber = parseInt(lastFieldIssueNumber) + 1;
        fiDoc.createdBy = req.payload.email;
        fiDoc.updatedBy = req.payload.email;
        if (fiDoc.wbsLinks?.length > 0) {
          await InteriorWBS.aggregate([
            {
              $match: {
                projectId: fiDoc.projectId,
                towerId: fiDoc.towerId,
                floorId: fiDoc.floorId,
              },
            },
            {
              $unwind: "$wbsList",
            },
            { $project: { wbsList: 1, _id: 0 } },
            {
              $match: {
                "wbsList.wbsId": {
                  $in: fiDoc.wbsLinks,
                },
              },
            },
            { $project: { "wbsList.description": 1 } },
            {
              $set: {
                description: "$wbsList.description",
                wbsList: "$$REMOVE",
              },
            },
          ]).exec((err, data) => {
            if (err) throw err;
            wbsLinksDesc = data.map((el) => el.description).join(", ");
          });
        }

        await LookUp.findOne({
          type: "fieldIssueStatus",
          key: fieldIssue.status,
        })
          .then((statusData) => {
            statusLookup = statusData;
          })
          .catch(next);

        await LookUp.findOne({
          type: "fieldIssuePriority",
          key: fieldIssue.priority,
        })
          .then((priorityData) => {
            priorityLookup = priorityData;
          })
          .catch(next);

        await fiDoc
          .save()
          .then(async (fiData) => {
            req.tour.lastFieldIssueNumber = fiData.issueNumber;
            await req.tour.save();
            return fiData;
          })
          .then(async (fiData) => {
            let fiCopy = Object.assign({}, fiData.toJSON());
            fiCopy.status = statusLookup.value;
            fiCopy.priority = priorityLookup.value;
            const fields = [
              {
                fieldName: "status",
                newValue: fiCopy.status,
              },
              {
                fieldName: "priority",
                newValue: fiCopy.priority,
              },
              {
                fieldName: "dueDate",
                newValue: fiCopy.dueDate,
              },

              {
                fieldName: "description",
                newValue: fiCopy.description,
              },
            ];
            wbsLinksDesc &&
              fiDoc.wbsLinks?.length > 0 &&
              fields.push({
                fieldName: "wbsItems",
                newValue: wbsLinksDesc,
              });

            const promises = [];

            if (fiCopy.assignee) {
              wbsLinksDesc != "" && (fiCopy.wbsLinks = wbsLinksDesc);
              const mailToArray = Util.getMailToArrayFromEmailArray(
                projectTeam,
                [fiCopy.assignee]
              );
              promises.push(
                new Promise(async (resolve, reject) => {
                  await Util.sendAsigneeEmail(mailToArray, {
                    issueNumber: fiCopy.issueNumber,
                    fields,
                    projectName,
                    uploadedFileObject,
                  }).then((data) => {
                    if (data[0]) {
                      Logger.error(
                        "Error while sending mail in sendAsigneeEmail in fieldIssue.js Route " +
                          data[0]
                      );
                      reject(data[0]);
                    } else {
                      resolve(data[1]);
                    }
                  });
                })
              );
            }
            if (newDiscussion) {
              promises.push(
                getDiscussionEmailPromise(
                  {
                    projectTeam,
                    projectName,
                    issueNumber: fiCopy.issueNumber,
                    discussion: newDiscussion,
                  },
                  req.payload
                )
              );
            }
            if (fiCopy.watchList?.length > 0) {
              const mailToArray = Util.getMailToArrayFromEmailArray(
                projectTeam,
                fiCopy.watchList
              );
              promises.push(
                new Promise(async (resolve, reject) => {
                  await Util.sendFIWatchlistEmail(mailToArray, {
                    issueNumber: fiCopy.issueNumber,
                    fields,
                    projectName,
                    uploadedFileObject,
                  }).then((data) => {
                    if (data[0]) {
                      Logger.error(
                        "Error while sending mail in sendFIWatchlistEmail in fieldIssue.js Route " +
                          data[0]
                      );
                      reject(data[0]);
                    } else {
                      resolve(data[1]);
                    }
                  });
                })
              );
            }

            await Promise.all(promises).then(({}) => {
              return;
            });
          })
          .then(() => {
            res.json({ status: "success" });
          })
          .catch((err) => {
            console.log(err);
          });
      }
    }
  );
});

router.put("/:project/:tour/update", auth.required, async (req, res, next) => {
  await Project.countDocuments(
    {
      users: {
        $elemMatch: {
          email: req.payload.email,
          isActive: true,
          isBlocked: false,
        },
      },
      projectId: req.project.projectId,
      isActive: true,
    },
    async (err, count) => {
      if (count > 0 || req.payload.isAdmin) {
        let priorityLookup;
        let statusLookup;
        const { users: projectTeam, projectName } = req.project;
        const { fieldIssue, modifiedFields } = req.body;
        const { newDiscussion, updatedDiscussion } = fieldIssue;
        await LookUp.findOne({
          type: "fieldIssueStatus",
          key: fieldIssue.status,
        })
          .then((statusData) => {
            statusLookup = statusData;
          })
          .catch(next);
        await LookUp.findOne({
          type: "fieldIssuePriority",
          key: fieldIssue.priority,
        })
          .then((priorityData) => {
            priorityLookup = priorityData;
          })
          .catch(next);

        await FieldIssue.findOneAndUpdate(
          { issueId: fieldIssue.issueId },
          {
            $set: {
              status: fieldIssue.status,
              priority: fieldIssue.priority,
              dueDate: fieldIssue.dueDate,
              description: fieldIssue.description,
              wbsLinks: fieldIssue.wbsLinks,
              assignee: fieldIssue.assignee,
              workTrade: fieldIssue.workTrade,
              watchList: fieldIssue.watchList,
              tags: fieldIssue.tags,
              discussion: fieldIssue.discussion,
              updatedBy: req.payload.email,
            },
          },
          {
            new: true,
          }
        )
          .then(async (fiData) => {
            if (fiData && fiData.toJSON()) {
              let fiCopy = Object.assign({}, fiData.toJSON());
              fiCopy.status = statusLookup;
              fiCopy.priority = priorityLookup;
              const promises = [];
              let mailToArrayForModifiedFields = [];
              //send WatchList members mail
              if (fiCopy.watchList?.length > 0) {
                mailToArrayForModifiedFields = [
                  ...Util.getMailToArrayFromEmailArray(projectTeam, [
                    ...fiCopy.watchList,
                  ]),
                ];
              }

              // send assignee the mail if they are modified
              let assigneeIndex = modifiedFields.findIndex(
                (field) => field.fieldName.toLowerCase() == "assignee"
              );
              if (assigneeIndex !== -1) {
                const prevAssignee = Util.getMailToArrayFromEmailArray(
                  projectTeam,
                  [modifiedFields[assigneeIndex].prevValue]
                );
                const newAssignee = Util.getMailToArrayFromEmailArray(
                  projectTeam,
                  [modifiedFields[assigneeIndex].newValue]
                );
                mailToArrayForModifiedFields.push(
                  ...prevAssignee,
                  ...newAssignee
                );
                modifiedFields[assigneeIndex].prevValue = prevAssignee[0];
                modifiedFields[assigneeIndex].newValue = newAssignee[0];
              }
              modifiedFields?.length > 0 &&
                promises.push(
                  new Promise(async (resolve, reject) => {
                    await Util.sendFIUpdateEmail(mailToArrayForModifiedFields, {
                      fi: fiCopy,
                      fields: modifiedFields,
                      projectName,
                      projectTeam,
                    }).then((data) => {
                      if (data[0]) {
                        Logger.error(
                          "Error while sending mail in sendFIUpdateEmail in fieldIssue.js Route " +
                            data[0]
                        );
                        reject(data[0]);
                      } else {
                        resolve(data[1]);
                      }
                    });
                  })
                );
              await Promise.all(promises).then(({}) => {
                return;
              });
            }
          })
          .then((issue) => {
            res.json({ status: "success" });
          });
      }
    }
  );
});

/**
options: Object
  { projectName, issueNumber, discussion },
mailFrom: Object
*/
const getDiscussionEmailPromise = (options, mailFrom) => {
  const mailToArray = Util.getMailToArrayFromEmailArray(
    options.projectTeam,
    options.discussion.mention
  );

  return new Promise(async (resolve, reject) => {
    Util.sendFIDiscussionEmail(mailToArray, mailFrom, options).then((data) => {
      if (data[0]) {
        Logger.error(
          "Error while sending mail in sendAsigneeEmail in fieldIssue.js Route " +
            data[0]
        );
        reject(data[0]);
      } else {
        resolve(data[1]);
      }
    });
  });
};

router.get(
  "/:project/:tour/:towerId/:floorId/list",
  auth.required,
  async (req, res, next) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          FieldIssue.find({
            projectId: req.project.projectId,
            tourId: req.tour.tourId,
            towerId: req.params.towerId,
            floorId: req.params.floorId,
          }).then((data) => {
            res.json({ fieldIssues: data });
          });
        }
      }
    );
  }
);

router.post(
  "/:project/:tour/:issueId/savemarkerannotation",
  auth.required,
  async (req, res, next) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          await FieldIssue.findOneAndUpdate(
            {
              tourId: req.params.tour,
              issueId: req.params.issueId,
            },
            {
              $set: {
                maState: req.body.maState,
              },
            },
            {
              new: true,
            }
          ).then(async (fiData) => {
            res.json({ maState: fiData.maState });
          });
        }
      }
    );
  }
);

router.put(
  "/:project/:tour/:towerId/:floorId/:issueId/discussion/:discussionId",
  auth.required,
  async (req, res, next) => {
    const {
      project: { users: projectTeam, projectId, projectName },
      tour: { tourId },
      params: { towerId, floorId, issueId, discussionId },
    } = req;
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          await FieldIssue.findOne({
            projectId,
            tourId,
            towerId,
            floorId,
            issueId,
          })
            .then(async (data) => {
              let issueNumber;
              const { discussion, isNew } = req.body;
              if (isNew) {
                await FieldIssue.findOneAndUpdate(
                  {
                    projectId,
                    tourId,
                    towerId,
                    floorId,
                    issueId,
                  },
                  {
                    $push: {
                      discussion: discussion,
                    },
                  },
                  {
                    new: true,
                  }
                ).then((updatedFI) => {
                  issueNumber = updatedFI.issueNumber;
                  res.json({ discussion: updatedFI.discussion });
                });
              } else {
                await FieldIssue.findOneAndUpdate(
                  {
                    projectId,
                    tourId,
                    towerId,
                    floorId,
                    issueId,
                    "discussion.discussionId": discussionId,
                  },
                  {
                    $set: {
                      "discussion.$": discussion,
                    },
                  },
                  { new: true }
                ).then((updatedFI) => {
                  issueNumber = updatedFI.issueNumber;
                  res.json({ discussion: updatedFI.discussion });
                });
              }
              await getDiscussionEmailPromise(
                {
                  projectTeam,
                  projectName,
                  issueNumber,
                  discussion,
                },
                req.payload
              ).then((data) => {});
            })
            .catch((err) => {
              res.status(401);
              next(err);
            });
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);

router.delete(
  "/:project/:tour/:towerId/:floorId/:issueId/discussion/:discussionId",
  auth.required,
  async (req, res, next) => {
    const {
      project: { projectId },
      tour,
      params: { towerId, floorId, issueId, discussionId },
    } = req;
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          FieldIssue.findOneAndUpdate(
            {
              projectId: projectId,
              tourId: tour.tourId,
              towerId: towerId,
              floorId: floorId,
              issueId: issueId,
              "discussion.discussionId": discussionId,
            },
            {
              $set: {
                "discussion.$.isDeleted": true,
              },
            },
            { new: true }
          )
            .then((updatedFI) => {
              if (updatedFI) res.json({ discussion: updatedFI.discussion });
              else res.status(403);
            })
            .catch((err) => next(err));
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);
router.get(
  "/:project/:towerId/:floorId/list",
  auth.required,
  async (req, res, next) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let fieldIssueList = [];
          let workLocations = [];
          let towers = [];
          let floors = [];
          let fieldIssueTours = [];
          const projectUsers = req.project.users;
          const ALL_TOWERS = "All";
          const ALL_FLOORS = "All";

          await MasterData.findOne({
            projectId: req.project.projectId,
          }).then(async (loc) => {
            workLocations = loc?.workLocation;
          });

          if (req.params.towerId === ALL_TOWERS) {
            towers =
              workLocations
                ?.filter((loc) => !loc.parentLocationId)
                .map((loc) => loc.locationId) || [];
          }
          if (
            req.params.floorId === ALL_FLOORS &&
            req.params.towerId !== ALL_TOWERS
          ) {
            floors =
              workLocations
                ?.filter(
                  (loc) =>
                    loc.parentLocationId === req.params.towerId &&
                    !loc.level3 &&
                    !loc.level4
                )
                .map((loc) => loc.locationId) || [];
          }

          const filter = {
            projectId: req.project.projectId,
            ...(req.params.towerId === ALL_TOWERS
              ? { towerId: { $in: towers } }
              : { towerId: req.params.towerId }),
          };

          req.params.floorId === "none"
            ? null
            : req.params.floorId === ALL_FLOORS
            ? (filter.floorId = { $in: floors })
            : (filter.floorId = req.params.floorId);

          await FieldIssue.find(filter)
            .sort({ createdAt: "asc" })
            .then(async (data) => {
              if (
                !!data &&
                data.length > 0 &&
                !!projectUsers &&
                projectUsers.length > 0
              ) {
                const fieldIssueTourIds = data.map((fieldIssue) => {
                  return fieldIssue.tourId;
                });
                await TourImage.find({
                  tourId: { $in: fieldIssueTourIds },
                }).then(async (tours) => {
                  fieldIssueTours = tours;
                });
                fieldIssueList = data.map((fieldIssue) => {
                  const assignee = projectUsers.find(
                    (user) => user.email === fieldIssue.assignee
                  );
                  const currentTour = fieldIssueTours.find(
                    (tour) => tour.tourId === fieldIssue.tourId
                  );
                  const floorLocationObj = workLocations.find(
                    (location) =>
                      location.parentLocationId === fieldIssue.towerId &&
                      location.locationId === fieldIssue.floorId &&
                      location.level3 === "" &&
                      location.level4 === ""
                  );

                  return {
                    ...fieldIssue.toJSON(),
                    tour: currentTour,
                    towerName: !!floorLocationObj
                      ? floorLocationObj.level1
                      : "",
                    assignee: fieldIssue.assignee,
                    assigneeName: !!assignee
                      ? assignee.firstName + " " + assignee.lastName
                      : fieldIssue.assignee,
                    dueDate: fieldIssue.dueDate,
                    issueId: fieldIssue.issueId,
                    issueNumber: fieldIssue.issueNumber,
                    description: fieldIssue.description,
                    priority: fieldIssue.priority,
                    status: fieldIssue.status,

                    location: !!floorLocationObj
                      ? floorLocationObj.level1 +
                        " - " +
                        floorLocationObj.level2
                      : "",
                  };
                });
              }
            });
          res.json({ fieldIssues: fieldIssueList });
        }
      }
    );
  }
);
module.exports = router;
