"use strict";

const router = require("express").Router();

router.use("/", require("./interior"));
router.use("/videocapture", require("./videocapture"));
router.use("/fieldissue", require("./fieldissue"));

module.exports = router;
