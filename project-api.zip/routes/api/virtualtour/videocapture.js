"use strict";
const mongoose = require("mongoose");
const router = require("express").Router();
const auth = require("../../auth");
const Message = require("../../../models/Message");
const messagingConstants = require("../../../config/messaging/messaging-constants");
const { MessageBroker } = require("../../../config/messaging/message-broker");
const logger = require("../../../common/logger");
const {
  virtualTourMiddleware,
} = require("../../../middlewares/virtualtour.middleware");
const nj = require("@d4c/numjs").default;
const math = require("mathjs");
const {
  VirtualTourProcessingStats,
} = require("../../../models/VirtualTourProcessingStats");
const LookUp = mongoose.model("LookUp");
const TourImage = mongoose.model("TourImage");
const DeletedTourFeature = mongoose.model("DeletedTourFeature");

// Starts the video processing by sending messages to the queue
router.post(
  "/:project/tour/:tour/start-processing",
  auth.required,
  virtualTourMiddleware,
  async ({ tour, payload, headers }, res, next) => {
    try {
      logger.info(`Starting processing for tour id ${tour.tourId}`);

      let authToken = headers.authorization.split(" ")[1];

      await sendVideoProcessingMessage(
        tour,
        messagingConstants,
        payload.email,
        authToken
      );

      let virtualTourProcessingStats = VirtualTourProcessingStats({
        tourId: tour.tourId,
        projectId: tour.projectId,
        interiorId: tour.interiorId,
        towerId: tour.towerId,
        processTriggeredBy: payload.email,
        authToken,
        events: [
          {
            type: "Message published to video processing queue",
          },
        ],
        status: getLookupStatus("interiorStatus", "VW10002"),
      });

      await virtualTourProcessingStats.save();

      res.json({ status: "Video processing started successfully" });
    } catch (error) {
      logger.error("Error in triggering video processing: " + error.message);
      next(error);
    }
  }
);

// Updates the RAW Videos references obtained from the 360 camera
router.put(
  "/:project/tour/:tour/video-capture-details",
  auth.required,
  virtualTourMiddleware,
  async (req, res, next) => {
    try {
      const { tour, headers } = req;
      const { rawVideoStorageRefs, captureStartPoint, captureEndPoint } =
        req.body;
      const { email } = req.payload;

      tour.videoCaptureDetails = {
        ...tour.videoCaptureDetails,
        rawVideoStorageRefs,
        captureStartPoint,
        captureEndPoint,
      };

      tour.updatedBy = email;

      await tour.save();

      const logMessage = `Starting virtual tour video processing for tour id ${tour.tourId}`;

      logger.info(logMessage);

      let authToken = headers.authorization.split(" ")[1];

      await sendVideoProcessingMessage(
        tour,
        messagingConstants,
        email,
        authToken
      );

      let virtualTourProcessingStats = VirtualTourProcessingStats({
        tourId: tour.tourId,
        projectId: tour.projectId,
        processTriggeredBy: email,
        tourId: tour.tourId,
        projectId: tour.projectId,
        interiorId: tour.interiorId,
        towerId: tour.towerId,
        authToken,
        events: [
          {
            type: "Message published to video processing queue",
          },
        ],
        status: await getLookupStatus("interiorStatus", "VW10002"),
      });

      await virtualTourProcessingStats.save();

      res.json({
        status: "Updated video references and started processing successfully",
      });
    } catch (error) {
      next(error);
    }
  }
);

async function sendVideoProcessingMessage(tour, constants, email, authToken) {
  const message = new Message(
    constants.messageType.TYPE_START_INTERIOR_VIDEO_PROCESSING,
    {
      tourId: tour.tourId,
      rawVideoStorageRefs: tour.videoCaptureDetails?.rawVideoStorageRefs,
      updatedBy: email,
      authToken,
    }
  );

  const connection = await MessageBroker.getInstance();
  await connection.send(constants.queueNames.VIDEO_PROCESSING_QUEUE, message);
}

async function sendPhotoProcessingMessage(tourId, constants, email, authToken) {
  const message = new Message(
    constants.messageType.TYPE_START_PHOTO_MODE_PROCESSING_QUEUE,
    {
      tourId: tourId,
      updatedBy: email,
      authToken,
    }
  );

  const connection = await MessageBroker.getInstance();
  await connection.send(
    constants.queueNames.PHOTO_MODE_PROCESSING_QUEUE,
    message
  );
}
async function getLookupStatus(type, key) {
  let { key: code, value: desc } = await LookUp.findOne({
    type,
    key,
  });
  return { code, desc };
}

// Updates the start and end points
router.put(
  "/:project/tour/:tour/capture-points",
  auth.required,
  virtualTourMiddleware,
  async (req, res, next) => {
    try {
      req.tour.videoCaptureDetails = {
        ...req.tour.videoCaptureDetails,
        captureStartPoint: req.body.captureStartPoint,
        captureEndPoint: req.body.captureEndPoint,
      };

      req.tour.updatedBy = req.payload.email;
      await req.tour.save();

      res.json({ status: "Updated capture points successfully" });
    } catch (error) {
      next(error);
    }
  }
);

// Updates the transformation
router.put(
  "/:project/tour/:tour/update-transformations",
  auth.required,
  virtualTourMiddleware,
  async (req, res, next) => {
    try {
      let captureStartPoint = req.body.captureStartPoint;
      let captureEndPoint = req.body.captureEndPoint;

      let agisoftExportedCoordinates =
        req.tour.videoCaptureDetails.exportedCoordinates;

      // Agisoft coordinate system
      let { x: x1, y: y1 } = {
        x: agisoftExportedCoordinates[0]["X-Coordinate"],
        y: agisoftExportedCoordinates[0]["Y-Coordinate"],
      };
      let { x: x2, y: y2 } = {
        x: agisoftExportedCoordinates[agisoftExportedCoordinates.length - 1][
          "X-Coordinate"
        ],
        y: agisoftExportedCoordinates[agisoftExportedCoordinates.length - 1][
          "Y-Coordinate"
        ],
      };

      // Floor plan coordinate system
      let { x: x1n, y: y1n } = {
        x: captureStartPoint.x,
        y: captureStartPoint.y,
      };
      let { x: x2n, y: y2n } = { x: captureEndPoint.x, y: captureEndPoint.y };

      let matrix1 = nj
        .array([
          [x1, y1, 1, 0],
          [-y1, x1, 0, 1],
          [x2, y2, 1, 0],
          [-y2, x2, 0, 1],
        ])
        .tolist();

      let matrix2 = nj.array([x1n, y1n, x2n, y2n]);

      // a,b,c,d values from the linear equations (ax+by+c) (bx-ay+d)
      let newMatrix = nj.dot(math.inv(matrix1), matrix2).tolist();

      let a = newMatrix[0];
      let b = newMatrix[1];
      let c = newMatrix[2];
      let d = newMatrix[3];

      let imageFeatures = [];

      agisoftExportedCoordinates.forEach((point, index) => {
        let x = a * point["X-Coordinate"] + b * point["Y-Coordinate"] + c;
        let y = b * point["X-Coordinate"] - a * point["Y-Coordinate"] + d;

        let latestCoordinates = [x, y];

        imageFeatures.push({
          type: "Feature",
          geometry: {
            coordinates: latestCoordinates,
            type: "Point",
          },
          properties: {
            imageNumber: index + 1,
            imageId: point["Image number"] + ".jpg",
            imageName: point["Image number"] + ".jpg",
          },
          id: math.random(),
        });
      });

      let tourFeatures = {
        type: "FeatureCollection",
        features: imageFeatures,
      };

      req.tour.videoCaptureDetails.captureStartPoint = captureStartPoint;
      req.tour.videoCaptureDetails.captureEndPoint = captureEndPoint;
      req.tour.features = tourFeatures;

      req.tour.updatedBy = req.payload.email;
      await req.tour.save();

      res.json({ status: "Updated capture points successfully" });
    } catch (error) {
      next(error);
    }
  }
);

// gets all the virtualtourvideoprocessingstats for provided tourId's
router.get(
  "/:project/interior/:interiorId/tower/:towerId/get-processing-stats",
  auth.required,
  async ({ params }, res, next) => {
    try {
      let { interiorId, towerId, project: projectId } = params;
      let data = await VirtualTourProcessingStats.find({
        interiorId,
        towerId,
        projectId,
      });
      res.json({ data });
    } catch (error) {
      logger.error("Error in getting video processing stats: " + error.message);
      next(error);
    }
  }
);

// Updates the path coordinates
router.put(
  "/:project/tour/:tour/update-path-coordinates",
  auth.required,
  virtualTourMiddleware,
  async (req, res, next) => {
    try {
      let updatedCoordinates = req.body.updatedCoordinates;

      const { captureStartPoint, captureEndPoint } = req.body;

      if (captureStartPoint && captureEndPoint) {
        req.tour.videoCaptureDetails.captureStartPoint = captureStartPoint;
        req.tour.videoCaptureDetails.captureEndPoint = captureEndPoint;
      }

      let imageFeatures = req.tour.features.features;

      imageFeatures = imageFeatures.map((feature, index) => {
        return Object.assign({}, feature, {
          geometry: {
            type: feature.geometry.type,
            coordinates: updatedCoordinates[index],
          },
        });
      });

      let tourFeatures = {
        type: "FeatureCollection",
        features: imageFeatures,
      };

      req.tour.features = tourFeatures;

      req.tour.updatedBy = req.payload.email;

      await req.tour.save();

      res.json({ status: "Updated capture points successfully" });
    } catch (error) {
      next(error);
    }
  }
);

router.put(
  "/:project/tour/:tour/delete-path-coordinates",
  auth.required,
  virtualTourMiddleware,
  async (req, res, next) => {
    try {
      let imageNumbersArray = req.body.imageNumbers;
      let imageFeatures = [];
      let deletedFeatures = [];

      if (req.tour.features.features.length > 0) {
        req.tour.features.features.forEach((feature, index) => {
          let isCoordinateMatched = imageNumbersArray.find(
            (imgNumber) => imgNumber == index + 1
          );

          if (!!isCoordinateMatched && isCoordinateMatched >= 0) {
            deletedFeatures.push(feature);
          } else {
            imageFeatures.push(feature);
          }
        });

        let tourFeatures = {
          type: "FeatureCollection",
          features: imageFeatures,
        };
        req.tour.features = tourFeatures;
        req.tour.updatedBy = req.payload.email;

        await req.tour.save();
        if (deletedFeatures.length > 0) {
          const deletedFeature = new DeletedTourFeature();
          deletedFeature.projectId = req.tour.projectId;
          deletedFeature.tourId = req.tour.tourId;
          deletedFeature.features = deletedFeatures;
          deletedFeature.deletedBy = req.payload.email;
          await deletedFeature.save();
        }

        res.json({ status: "Deleted capture points successfully" });
      }
    } catch (error) {
      next(error);
    }
  }
);

// Publish all pending data
router.post(
  "/:project/publish-pending-messages",
  auth.required,
  async ({ params }, res, next) => {
    try {
      let { project: projectId } = params;
      let virtualToursToBeProcessed = await VirtualTourProcessingStats.find({
        projectId,
        isProcessingComplete: false,
      });

      if (virtualToursToBeProcessed.length > 0) {
        for (const record of virtualToursToBeProcessed) {
          let tour = await TourImage.findOne({ tourId: record.tourId });
          await sendVideoProcessingMessage(
            tour,
            messagingConstants,
            record.processTriggeredBy,
            record.authToken
          );
        }

        res.json({ status: "Published all messages successfully" });
      } else res.json({ status: "No messages available to publish" });
    } catch (error) {
      logger.error("Error in publishing data: " + error.message);
      next(error);
    }
  }
);

// Publish all pending data
router.post(
  "/:project/publish-pending-messages-by-tour/:tourId",
  auth.required,
  async ({ params }, res, next) => {
    try {
      let { project: projectId, tourId: tourId } = params;
      let virtualToursToBeProcessed = await VirtualTourProcessingStats.find({
        projectId,
        isProcessingComplete: false,
        tourId: tourId,
      });

      if (virtualToursToBeProcessed.length > 0) {
        for (const record of virtualToursToBeProcessed) {
          console.log(record);
          let tour = await TourImage.findOne({ tourId: record.tourId });
          await sendVideoProcessingMessage(
            tour,
            messagingConstants,
            record.processTriggeredBy,
            record.authToken
          );
        }

        res.json({ status: "Published  messages for tour" });
      } else res.json({ status: "No messages available to publish" });
    } catch (error) {
      logger.error("Error in publishing data: " + error.message);
      next(error);
    }
  }
);

router.put(
  "/:project/tour/:tour/publish-photo-mode-messages",
  auth.required,
  virtualTourMiddleware,
  async (req, res, next) => {
    try {
      let authToken = req.headers.authorization.split(" ")[1];

      if (req.tour && req.tour.images.length > 0) {
        await sendPhotoProcessingMessage(
          req.tour.tourId,
          messagingConstants,
          req.payload.email,
          authToken
        );
      }

      res.json({ status: "Published all messages successfully" });
    } catch (error) {
      logger.error("Error in publishing data: " + error.message);
      next(error);
    }
  }
);

module.exports = router;
