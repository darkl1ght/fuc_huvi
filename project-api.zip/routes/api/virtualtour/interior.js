"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const LookUp = mongoose.model("LookUp");
const InteriorTour = mongoose.model("InteriorTour");
const TourImage = mongoose.model("TourImage");
const InteriorImage = mongoose.model("InteriorImage");
const ProjectChart = mongoose.model("ProjectChart");
const MasterData = mongoose.model("MasterData");
const asyncPackage = require("async");
const auth = require("../../auth");
const uuid = require("uuid");
const moment = require("moment-timezone");
const Util = require("../../../common/util");
const prepareNotificationData = require("../../../common/notification");
const {
  notificationMiddleWare,
} = require("../../../middlewares/notification.middleware");
const InteriorWBS = mongoose.model("InteriorWBS");
const InteriorCapture = mongoose.model("InteriorCapture");
const _ = require("underscore");
const logger = require("../../../common/logger");
var Excel = require("exceljs");
var lodash = require("lodash");

// Preload project objects on routes with ':project'
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.param("interior", (req, res, next, interiorId) => {
  InteriorTour.findOne({
    interiorId: interiorId,
  })
    .then((interior) => {
      if (!interior) {
        return res.sendStatus(404);
      }
      req.interior = interior;
      return next();
    })
    .catch(next);
});

router.param("tour", (req, res, next, tourId) => {
  TourImage.findOne({
    tourId: tourId,
  })
    .then((tour) => {
      if (!tour) {
        return res.sendStatus(404);
      }
      req.tour = tour;
      return next();
    })
    .catch(next);
});

router.get("/:project/interiors", auth.required, async (req, res, next) => {
  await req.project
    .populate({
      path: "interiors",
      options: {
        sort: {
          createdAt: "desc",
        },
      },
      populate: {
        path: "floorWalkthough",
        populate: {
          path: "tours",
          model: "TourImage",
        },
      },
    })
    .execPopulate()
    .then(() => {
      let interiorData = req.project.interiors;
      interiorData.map((interior) => {
        interior.floorWalkthough = lodash.orderBy(
          interior.floorWalkthough,
          ["orderNo"],
          ["asc"]
        );
        return interior.floorWalkthough.map((walkthrough) => {
          walkthrough.tours = lodash.orderBy(
            walkthrough.tours,
            ["orderNo"],
            ["asc"]
          );
        });
      });
      res.json({
        interiors: interiorData,
      });
    })
    .catch(next);
});

// Used in mobile App
router.get(
  "/:project/interiors-without-tours",
  auth.required,
  async (req, res, next) => {
    await req.project
      .populate({
        path: "interiors",
        options: {
          sort: {
            createdAt: "desc",
          },
        },
      })
      .execPopulate()
      .then(() => {
        res.json({
          interiors: req.project.interiors,
        });
      })
      .catch(next);
  }
);

router.post("/:project/interiors", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let status;
          await LookUp.findOne({
            type: "interiorStatus",
            key: "VW10001",
          })
            .then((data) => {
              status = data;
            })
            .catch(next);
          const interior = new InteriorTour(req.body.interior);
          interior.interiorId = uuid.v4();
          interior.projectId = req.project.projectId;
          interior.createdBy = req.payload.email;
          interior.updatedBy = req.payload.email;
          interior.status = status
            ? {
                code: status.key,
                desc: status.value,
              }
            : null;

          await interior
            .save()
            .then(async () => {
              req.project.interiors.push(interior);
              await req.project.save().then(async () => {
                if (interior.mapType != "S") {
                  let isSelfServe = req.project.isInteriorWBSPublished
                    ? true
                    : false;
                  await createTours(
                    interior.projectId,
                    interior.interiorId,
                    interior.interiorDate,
                    req.payload.email,
                    isSelfServe,
                    req.payload.email
                  );
                }

                const p = new Promise((resolve) => {
                  setTimeout(resolve, 2000);
                });

                // wait for couple of seconds to  create full structure
                p.then(() => {
                  res.json({
                    interior: interior,
                  });
                });
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

router.delete(
  "/:project/interiors/:interior",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            req.project.interiors.remove(req.interior._id);
            await req.project
              .save()
              .then(
                InteriorTour.findOneAndUpdate(
                  {
                    _id: req.interior._id,
                  },
                  {
                    $set: {
                      isActive: false,
                    },
                  }
                ).exec()
              )
              .then(() => {
                res.sendStatus(204);
              });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.interior) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (typeof req.body.interior.interiorName !== "undefined") {
              req.interior.interiorName = req.body.interior.interiorName;
            }

            if (typeof req.body.interior.interiorDate !== "undefined") {
              req.interior.interiorDate = req.body.interior.interiorDate;
            }

            req.interior.updatedBy = req.payload.email;

            await req.interior
              .save()
              .then(async (interior) => {
                await updateProgressByDate(
                  interior.projectId,
                  interior.interiorId,
                  interior.interiorDate,
                  req.payload.email
                );
                res.json({
                  interior: interior,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/statictour/:interior",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.tour) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const requestData = req.body.tour;

            const tour = {};
            tour.tourId = uuid.v4();
            tour.tourName = requestData.tourName;
            tour.tourUrl = requestData.tourUrl;
            req.interior.staticMap.urls.push(tour);

            req.interior.updatedBy = req.payload.email;

            await req.interior
              .save()
              .then((interior) => {
                res.json({
                  interior: interior,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// create a new document
router.delete(
  "/:project/interiors/statictour/:interior/tour/:statictourid",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            InteriorTour.findOneAndUpdate(
              {
                interiorId: req.interior.interiorId,
              },
              {
                $pull: {
                  "staticMap.urls": {
                    tourId: req.params.statictourid,
                  },
                },
              },
              {
                new: true,
              }
            )
              .then((interior) => {
                res.json({
                  interior: interior,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/statictour/:interior/chart",
  auth.required,
  async (req, res, next) => {
    let charts;
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            charts = req.body.charts;
            req.interior.staticMap.charts = [];

            for (let i = 0; i < charts.length; i++) {
              const chart = new ProjectChart(charts[i]);
              chart.chartId = uuid.v4();
              chart.createdBy = req.payload.email;
              req.interior.staticMap.charts.push(chart);
            }

            req.interior.updatedBy = req.payload.email;
            await req.interior
              .save()
              .then((interior) => {
                res.json({
                  interior: interior,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/interiors/statictour/:interior/removechart/:chartId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0) {
            await InteriorTour.findOneAndUpdate(
              {
                interiorId: req.interior.interiorId,
              },
              {
                $pull: {
                  "staticMap.charts": {
                    chartId: req.params.chartId,
                  },
                },
              },
              {
                new: true,
              }
            )
              .then((interior) => {
                res.json({
                  interior: interior,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// update static tour
router.put(
  "/:project/interiors/statictour/status/:interior",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      let status;
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await LookUp.findOne({
              type: "interiorStatus",
              key: "VW10003",
            })
              .then((data) => {
                status = data;
              })
              .catch(next);

            req.interior.status = status
              ? {
                  code: status.key,
                  desc: status.value,
                }
              : null;
            req.interior.updatedBy = req.payload.email;

            await req.interior
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/status/:interior",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      let status;
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await LookUp.findOne({
              type: "interiorStatus",
              key: "VW10003",
            })
              .then((data) => {
                status = data;
              })
              .catch(next);

            req.interior.status = status
              ? {
                  code: status.key,
                  desc: status.value,
                }
              : null;
            req.interior.updatedBy = req.payload.email;

            await req.interior
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// create a new tour
router.post(
  "/:project/interiors/:interior/tour",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const tour = new TourImage(req.body.tour);
            tour.tourId = uuid.v4();
            tour.interiorId = req.interior.interiorId;
            tour.projectId = req.project.projectId;
            tour.isActive = true;
            tour.isPublished = false;
            tour.isSelfServe = req.project.isInteriorWBSPublished
              ? true
              : false;
            tour.createdBy = req.payload.email;
            await tour
              .save()
              .then(async (tour) => {
                req.interior.tours.push(tour);
                req.interior.save().then(() => {
                  res.json({
                    tour: tour,
                  });
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// add image
router.post(
  "/:project/interiors/:interior/tour/:tour/image",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const image = new InteriorImage(req.body.image);
            image.createdBy = req.payload.email;

            req.tour.images.push(image);
            await req.tour
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/feature",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            req.tour.features = req.body.feature;
            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/imagesAndFeatures",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
            },
          },
          projectId: req.project.projectId,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (!req.tour.features) {
              req.tour.features = {
                features: [],
                type: "FeatureCollection",
              };
            }
            // Image Details
            let image = new InteriorImage(req.body.image);
            image.createdBy = req.payload.email;
            req.tour.images.push(image);

            // Feature details
            req.tour.features.features.push(req.body.feature);
            req.tour.markModified("features");

            req.tour.updatedBy = req.payload.email;
            return req.tour
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/linkage",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await TourImage.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "images.imageId": req.body.linkage.imageId,
              },
              {
                $push: {
                  "images.$.linkage": req.body.linkage.link,
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/mapping",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await TourImage.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "images.imageId": req.body.linkage.imageId,
              },
              {
                $pull: {
                  "images.$.linkage": {
                    imageId: req.body.linkage.link.imageId,
                  },
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// a project's users
router.get(
  "/:project/interiors/:interior/tour/:tour/chart",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isBlocked: false,
              isActive: true,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            res.json({
              charts: req.tour.charts,
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/chart",
  auth.required,
  async (req, res, next) => {
    let charts;
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            charts = req.body.charts;
            req.tour.charts = [];

            if (charts && charts.length > 0) {
              for (let i = 0; i < charts.length; i++) {
                const chart = new ProjectChart(charts[i]);
                chart.chartId = uuid.v4();
                chart.createdBy = req.payload.email;
                req.tour.charts.push(chart);
              }
            }

            await req.tour
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/removechart",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await TourImage.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "charts.chartId": req.body.chart.chartId,
              },
              {
                $pull: {
                  charts: {
                    chartId: req.body.chart.chartId,
                  },
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/publish",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let status;

            await LookUp.findOne({
              type: "interiorStatus",
              key: "VW10003",
            })
              .then((data) => {
                status = data;
              })
              .catch(next);

            req.tour.isPublished = true;
            req.tour.updatedBy = req.payload.email;
            req.tour.tourPublishDate = new Date().toISOString();

            await req.tour
              .save()
              .then((tour) => {
                req.interior.status = status
                  ? {
                      code: status.key,
                      desc: status.value,
                    }
                  : null;
                req.interior.updatedBy = req.payload.email;
                req.interior.save().then(() => {
                  res.json({
                    tour: tour,
                  });
                });
              })
              .catch(next);

            // Notification logic
            let towerName = req.interior.floorWalkthough.find(
              (walkthrough) => walkthrough.towerId === req.tour.towerId
            )["towerName"];

            let interiorData = {
              ...req.project.toObject(),
              ...req.tour.toObject(),
              ...req.interior.toObject(),
              towerName,
              messageType: "NT0003",
              appType: "APP002",
              metaData: {
                actionType: "Interior_tour_published",
                tourId: req.tour.tourId,
                floorPlanBlobId: req.tour.floorPlanBlobId,
                towerName,
              },
            };

            req.notificationData = await prepareNotificationData(interiorData);
            next();
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  },
  notificationMiddleWare
);

// create a new document
router.delete(
  "/:project/interiors/:interior/tour/:tour",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            // set status to inactive
            req.tour.isActive = false;

            await req.tour
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/interior/:interior",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (req.interior.isPannellum) {
              await InteriorTour.find({
                interiorId: req.params.interior,
              })
                .populate({
                  path: "floorWalkthough",
                  populate: {
                    path: "tours",
                    model: "TourImage",
                  },
                })
                .exec((err, data) => {
                  let floorWalkthough = lodash.orderBy(
                    data[0].floorWalkthough,
                    ["orderNo"],
                    ["asc"]
                  );
                  res.json({
                    tours: floorWalkthough,
                  });
                });
            } else {
              await req.interior
                .populate({
                  path: "tours",
                  options: {
                    sort: {
                      createdAt: "desc",
                    },
                  },
                })
                .execPopulate()
                .then((interior) => {
                  res.json({
                    tours: interior.tours,
                  });
                })
                .catch(next);
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/remark",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const remark = {};
            remark.hotspot = req.body.hotspot;
            remark.sceneId = req.body.sceneId;
            remark.remarkId = uuid.v4();
            remark.createdByEmail = req.payload.email;
            remark.createdByName =
              req.payload.firstName + " " + req.payload.lastName;
            req.tour.remarks.push(remark);

            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tour/:tour/removeremark",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await TourImage.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "remarks.remarkId": req.body.remark.remarkId,
              },
              {
                $pull: {
                  remarks: {
                    remarkId: req.body.remark.remarkId,
                  },
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

const createTours = async (
  projectId,
  interiorId,
  captureDate,
  createdBy,
  isSelfServe,
  email
) => {
  MasterData.findOne({
    projectId: projectId,
  }).then(async (masterdata) => {
    if (masterdata) {
      const workLocation = masterdata.workLocation;
      const level1LocationList = workLocation.filter(
        (location) => location.parentLocationId === ""
      );
      const floorWalkthough = [];

      asyncPackage.eachSeries(
        level1LocationList,
        (level1Location, callbackL1) => {
          const level2LocationList = workLocation.filter(
            (l2) => l2.parentLocationId === level1Location.locationId
          );
          const walkthrough = {
            towerId: level1Location.locationId,
            interiorId: interiorId,
            towerName: level1Location.level1,
            orderNo: level1Location.orderNo,
            tours: [],
          };
          if (level1Location.bim) {
            walkthrough.bim = {
              forgeObject: level1Location.bim.forgeObject,
              levels: level1Location.bim.levels,
              offset: level1Location.bim.offset,
            };
          }
          asyncPackage.eachSeries(
            level2LocationList,
            (level2Location, callbackL2) => {
              const tour = new TourImage();
              tour.towerId = level1Location.locationId;
              tour.tourName = level2Location.level2;
              tour.locationId = level2Location.locationId;
              tour.tourId = uuid.v4();
              tour.orderNo = level2Location.orderNo;
              tour.interiorId = interiorId;
              tour.floorPlanBlobId = level2Location.drawing
                ? level2Location.drawing.blobContentId
                : "";
              if (
                level2Location.drawing &&
                level2Location.drawing.floorPlanOrientation !== undefined
              ) {
                tour.floorPlanOrientation =
                  level2Location.drawing.floorPlanOrientation;
              }
              tour.projectId = projectId;
              tour.isActive = true;
              tour.isPublished = false;
              tour.createdBy = createdBy;
              tour.isSelfServe = isSelfServe;
              tour.isWBSPublished = true;

              if (
                level2Location.aecLevel &&
                level2Location.bim?.transformationScale
              ) {
                tour.aecLevel = level2Location.aecLevel;
                tour.bimAngularDeviationFromTrueNorth =
                  level2Location.bim.bimAngularDeviationFromTrueNorth;
                tour.transformationScale =
                  level2Location.bim.transformationScale;
                tour.origin = level2Location.bim.floorplanConfig?.origin;
              }

              tour.save().then(async (tour) => {
                await updateActualData(
                  projectId,
                  interiorId,
                  captureDate,
                  tour.tourId,
                  tour.towerId,
                  tour.locationId,
                  email
                );

                walkthrough.tours.push(tour);

                callbackL2();
              });
            },
            async () => {
              callbackL1();
            }
          );
          floorWalkthough.push(walkthrough);
        },
        async (err) => {
          if (err) {
            res.status(500).json({
              error: err,
            });
          }

          InteriorTour.findOneAndUpdate(
            {
              interiorId: interiorId,
            },
            {
              $set: {
                floorWalkthough: floorWalkthough,
                isPannellum: true,
              },
            },
            {
              new: true,
            },
            (err) => {
              if (err) {
              }
            }
          );
        }
      );
    }
  });
};

router.put(
  "/:project/interiors/:interior/syncdata",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async () => {
          if (req.payload.isAdmin) {
            syncTourData(
              req.interior.projectId,
              req.interior.interiorId,
              req.payload.email
            );
            const p = new Promise((resolve) => {
              setTimeout(resolve, 2000);
            });

            // wait for couple of seconds to  create full structure
            p.then(() => {
              res.json({
                status: "success",
              });
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

const syncTourData = async (projectId, interiorId, createdBy) => {
  MasterData.findOne({
    projectId: projectId,
  }).then(async (masterdata) => {
    if (masterdata) {
      try {
        const workLocation = masterdata.workLocation;
        const locations = workLocation.filter(
          (location) => location.parentLocationId === ""
        );
        let floorWalkthough = [];
        const interiorData = await InteriorTour.findOne(
          {
            interiorId: interiorId,
          },
          (err, data) => {
            if (data.floorWalkthough) {
              floorWalkthough = data.floorWalkthough;
            }
          }
        );

        // do not sync any data prior to -jul 22nd ,todo: temp fix;
        if (moment(interiorData.createdAt).isBefore("2022-07-22", "day")) {
          return;
        }

        await asyncPackage.forEach(locations, async (location) => {
          let walkthrough;
          let isNewWalkthrough = false;
          if (floorWalkthough.length > 0) {
            walkthrough = floorWalkthough.find(
              (t) => t.towerId === location.locationId
            );
          }
          if (!walkthrough) {
            isNewWalkthrough = true;
            walkthrough = {
              towerId: location.locationId,
              interiorId: interiorId,
              towerName: location.level1,
              tours: [],
            };
          }

          const level2List = workLocation.filter(
            (l2) => l2.parentLocationId === location.locationId
          );

          await asyncPackage.forEach(level2List, async (l2) => {
            let tour;
            const tourResult = await TourImage.findOne(
              {
                locationId: l2.locationId,
                towerId: location.locationId,
              },
              (err, tour) => {
                tour = tour;
              }
            );
            if (tourResult) {
              if (tourResult.images.length === 0 && !tourResult.isPublished) {
                const deletedTour = await TourImage.deleteOne(
                  {
                    _id: tourResult._id,
                  },
                  (err) => {
                    if (!err) {
                      walkthrough.tours.remove(tour);
                    }
                  }
                );
                if (deletedTour) {
                  tour = new TourImage();
                  tour.towerId = location.locationId;
                  tour.tourName = l2.level2;
                  tour.locationId = l2.locationId;
                  tour.tourId = uuid.v4();
                  tour.interiorId = interiorId;
                  tour.floorPlanBlobId = l2.drawing
                    ? l2.drawing.blobContentId
                    : "";
                  tour.projectId = projectId;
                  tour.isActive = true;
                  tour.isPublished = false;
                  tour.createdBy = createdBy;
                }
              } else {
                tour = tourResult;
              }
            } else {
              tour = new TourImage();
              tour.towerId = location.locationId;
              tour.tourName = l2.level2;
              tour.locationId = l2.locationId;
              tour.tourId = uuid.v4();
              tour.interiorId = interiorId;
              tour.floorPlanBlobId = l2.drawing ? l2.drawing.blobContentId : "";
              tour.projectId = projectId;
              tour.isActive = true;
              tour.isPublished = false;
              tour.createdBy = createdBy;
            }
            await tour.save().then((doc) => {
              walkthrough.tours.push(doc);
            });
          });
          if (isNewWalkthrough) {
            floorWalkthough.push(walkthrough);
          }
        });
        await InteriorTour.findOneAndUpdate(
          {
            interiorId: interiorId,
          },
          {
            $set: {
              floorWalkthough: floorWalkthough,
              isPannellum: true,
            },
          },
          {
            new: true,
          },
          (err) => {
            if (err) {
            }
          }
        );
      } catch (err) {}
    }
  });
};

// create a new tour
router.post(
  "/:project/interiors/:interior/tower/:towerId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const tour = new TourImage(req.body.tour);
            tour.tourId = uuid.v4();
            tour.interiorId = req.interior.interiorId;
            tour.projectId = req.project.projectId;
            tour.isActive = true;
            tour.isPublished = false;
            tour.createdBy = req.payload.email;
            await tour
              .save()
              .then(async (tour) => {
                InteriorTour.update(
                  {
                    interiorId: req.params.interiorId,
                    "floorWalkthough.towerId": req.params.towerId,
                  },
                  {
                    $push: {
                      "floorWalkthough.$.tours": tour,
                    },
                  },
                  (err) => {
                    if (err) {
                      res.status(500).json({
                        error: "Unable to update floorWalkthough.",
                      });
                    } else {
                      res.json({
                        tour: tour,
                      });
                    }
                  }
                );
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// delete tourid based on towerId
router.delete(
  "/:project/interiors/:interior/tower/:towerId/tour/:tour",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            InteriorTour.update(
              {
                interiorId: req.params.interiorId,
                "floorWalkthough.towerId": req.params.towerId,
              },
              {
                $pullAll: {
                  "floorWalkthough.$.tours": [req.tour._id],
                },
              },
              (err) => {
                if (err) {
                  res.status(500).json({
                    error: "Unable to update floorWalkthough.",
                  });
                } else {
                  res.json({
                    tour: tour,
                  });
                }
              }
            );
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// get tour
router.get(
  "/:project/interiors/tour/:tour",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isBlocked: false,
              isActive: true,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            res.json({
              tour: req.tour,
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/tour/:tour/updatefp",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let blobContentId = req.body.blobContentId;
            req.tour.floorPlanBlobId = blobContentId;
            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// add comment
router.post(
  "/:project/interior/:interior/comments/tour/:tour/remark/:remarkId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.body.comment) {
        const extractEmails = (text) => {
          return text.match(
            /[A-Z0-9._%+-]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,8}[A-Z]{2,63}/gi
          );
        };
        const emails = extractEmails(req.body.comment);
        const mailTo = [];
        if (emails) {
          for (let email of emails) {
            const user = req.project.users.filter((projectUser) => {
              return projectUser.email.toLowerCase() === email.toLowerCase();
            });
            if (user.length > 0)
              mailTo.push({
                email: user[0].email,
                firstName: user[0].firstName,
                name: `${user[0].firstName} ${user[0].lastName}`,
              });
          }
        }

        const comment = {};
        comment.commentId = uuid.v4();
        comment.remarkId = req.params.remarkId;
        comment.body = req.body.comment;
        comment.createdAt = moment.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
        comment.createdByName =
          req.payload.firstName + " " + req.payload.lastName;
        comment.createdByEmail = req.payload.email;

        await TourImage.findOneAndUpdate(
          {
            tourId: req.params.tour,
            "remarks.remarkId": req.params.remarkId,
          },
          {
            $push: {
              "remarks.$.comments": comment,
            },
          },
          {
            new: true,
          }
        )
          .then(async () => {
            if (mailTo && mailTo.length > 0) {
              let interiorData = moment(req.interior.interiorDate).format(
                "DD MMM YYYY"
              );
              let tourName = req.tour.tourName;
              let remark = req.tour.remarks.find(
                (x) => x.remarkId === req.params.remarkId
              );
              const [mailSentError, mailSentStatus] =
                await Util.sendInteriorTagEmail(
                  mailTo,
                  req.project.projectName,
                  interiorData,
                  tourName,
                  remark ? remark.hotspot.text : "",
                  req.body.comment
                );
              if (mailSentError) {
                logger.error(
                  "Error while sending mail in Media Tag :" + mailSentError
                );
              }
            }

            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

// remove comments
router.delete(
  "/:project/comments/tour/:tour/remark/:remarkId/:commentId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.commentId) {
        await TourImage.findOneAndUpdate(
          {
            tourId: req.params.tour,
            "remarks.remarkId": req.params.remarkId,
          },
          {
            $pull: {
              "remarks.$.comments": {
                commentId: req.params.commentId,
              },
            },
          },
          {
            new: true,
          }
        )
          .then(() => {
            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/comments/tour/:tour/remark/:remarkId",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      res.json({
        remark: req.tour.remarks.find(
          (x) => x.remarkId === req.params.remarkId
        ),
      });
    } else {
      res.sendStatus(403);
    }
  }
);

// Fetch interiors with their tower and walkthroughs
router.get(
  "/:project/interiors-and-walkthroughs",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isBlocked: false,
              isActive: true,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            req.project
              .populate({
                path: "interiors",
                options: {
                  sort: {
                    createdAt: "desc",
                  },
                },
                populate: {
                  path: "floorWalkthough.tours",
                  match: {
                    isPublished: false,
                  },
                },
              })
              .execPopulate()
              .then(({ interiors }) => {
                res.json({
                  interiors,
                });
              });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// important method to keep the node service waiting

router.put(
  "/:project/interiors/:interior/tower/:towerId/chart",
  auth.required,
  async (req, res, next) => {
    let charts;
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            charts = req.body.charts;
            let progresscharts = [];

            if (charts && charts.length > 0) {
              for (let i = 0; i < charts.length; i++) {
                const chart = new ProjectChart(charts[i]);
                chart.chartId = uuid.v4();
                chart.createdBy = req.payload.email;
                progresscharts.push(chart);
              }
            }

            await TourImage.updateMany(
              {
                projectId: req.params.project,
                towerId: req.params.towerId,
                interiorId: req.params.interior,
              },
              {
                $set: {
                  charts: progresscharts,
                },
              }
            )
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interiorId/tower/:towerId/override",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const towerData = req.body.interior;

            await InteriorTour.findOne({
              "floorWalkthough.towerId": req.params.towerId,
              interiorId: req.params.interiorId,
            })
              .then((data) => {
                const walkthrough = data.floorWalkthough.find(
                  (x) => x.towerId === req.params.towerId
                );

                InteriorTour.findOneAndUpdate(
                  {
                    interiorId: req.params.interiorId,
                    "floorWalkthough.towerId": req.params.towerId,
                  },
                  {
                    $set: {
                      "floorWalkthough.$.towerName": towerData.towerName
                        ? towerData.towerName
                        : walkthrough.towerName,
                      "floorWalkthough.$.captureDate": towerData.captureDate
                        ? towerData.captureDate
                        : walkthrough.captureDate,
                    },
                  },
                  {
                    new: true,
                  },
                  (err) => {
                    if (err) {
                      res.json({
                        status: "failed",
                      });
                    }

                    res.json({
                      status: "success",
                    });
                  }
                );
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interiorId/tour/:tourId/override",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const tourData = req.body.tour;

            await TourImage.findOne({
              tourId: req.params.tourId,
              interiorId: req.params.interiorId,
            })
              .then((data) => {
                TourImage.findOneAndUpdate(
                  {
                    tourId: req.params.tourId,
                    interiorId: req.params.interiorId,
                  },
                  {
                    $set: {
                      tourName: tourData.tourName
                        ? tourData.tourName
                        : data.tourName,
                    },
                  },
                  {
                    new: true,
                  },
                  (err) => {
                    if (err) {
                      res.json({
                        status: "failed",
                      });
                    }

                    res.json({
                      status: "success",
                    });
                  }
                );
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/interiors/:interior",
  auth.required,
  async (req, res, next) => {
    InteriorTour.findOne({
      interiorId: req.params.interior,
    })
      .then((interior) => {
        if (!interior) {
          return res.sendStatus(404);
        }
        res.json({
          data: interior,
        });
      })
      .catch(next);
  }
);

router.get(
  "/:project/wbsstatus/:tour/:towerId/:floorId",
  auth.required,
  async (req, res) => {
    await InteriorWBS.findOne({
      projectId: req.params.project,
      towerId: req.params.towerId,
      floorId: req.params.floorId,
    }).then(async (projectWBS) => {
      if (
        projectWBS &&
        (req.project.isInteriorWBSPublished || req.tour.isSelfServe)
      ) {
        res.json({
          status: true,
        });
      } else {
        res.json({
          status: false,
        });
      }
    });
  }
);

router.get(
  "/:project/wbs/:interior/syncwbsmasterdata/:tour/:towerId/:floorId",
  auth.required,
  async (req, res) => {
    await InteriorWBS.find({
      projectId: req.params.project,
      towerId: req.params.towerId,
    }).then(async (projectWBS) => {
      if (projectWBS.length > 0) {
        await req.tour.save().then(async (tour) => {
          await updateActualData(
            tour.projectId,
            req.params.interior,
            req.interior.interiorDate,
            tour.tourId,
            tour.towerId,
            tour.floorId,
            req.payload.email
          );
          res.json({
            status: "success",
          });
        });
      } else {
        res.json({
          status: "success",
        });
      }
    });
  }
);

router.get(
  "/:project/wbs/:interior/publishwbstourdata/:tour/:towerId/:floorId",
  auth.required,
  async (req, res) => {
    await InteriorCapture.find({
      projectId: req.params.project,
      interiorId: req.params.interiorId,
      towerId: req.params.towerId,
      tourId: req.params.tour,
    }).then(async (capture) => {
      if (capture.length === 0) {
        req.tour.isWBSPublished = true;

        await req.tour.save().then(async (tour) => {
          await updateActualData(
            tour.projectId,
            req.params.interior,
            req.interior.interiorDate,
            tour.tourId,
            tour.towerId,
            req.params.floorId,
            req.payload.email
          );
        });
      }
      res.json({
        status: "success",
      });
    });
  }
);

const updateActualData = async (
  projectId,
  interiorId,
  captureDate,
  tourId,
  towerId,
  floorId,
  email
) => {
  await InteriorWBS.find({
    projectId: projectId,
    towerId: towerId,
    floorId: floorId,
  }).then(async (wbsItems) => {
    if (wbsItems) {
      asyncPackage.forEach(
        wbsItems,
        async function (projectWBS, callback) {
          let insertNew = false;
          let intCapture = await InteriorCapture.findOne({
            interiorId: interiorId,
            projectId: projectWBS.projectId,
            towerId: projectWBS.towerId,
            floorId: projectWBS.floorId,
            tourId: tourId,
          }).exec();

          if (intCapture) {
            if (!intCapture.isActualPublished) {
              await InteriorCapture.deleteMany(
                {
                  projectId: req.params.project,
                  towerId: projectWBS.towerId,
                  floorId: projectWBS.floorId,
                },
                function (err) {
                  if (err) console.log(err);
                }
              );
              insertNew = true;
            } else {
              intCapture.save(callback);
            }
          } else {
            insertNew = true;
          }

          if (insertNew) {
            const capture = new InteriorCapture();
            capture.captureId = uuid.v4();
            capture.tourId = tourId;
            capture.captureDate = captureDate;
            capture.interiorId = interiorId;
            capture.projectId = projectWBS.projectId;
            capture.towerId = projectWBS.towerId;
            capture.floorId = projectWBS.floorId;
            capture.unitId = projectWBS.unitId;
            capture.projectDuration = projectWBS.projectDuration;
            capture.captureInterval = projectWBS.captureInterval;
            capture.projectStartDate = projectWBS.projectStartDate;
            capture.projectFinishDate = projectWBS.projectFinishDate;
            capture.isActualPublished = true;
            capture.createdBy = email;
            capture.updatedBy = email;

            const prevActiveInterior = await InteriorTour.find({
              projectId,
              interiorId: { $ne: interiorId }, //Exclude the new interior
              isActive: true,
            })
              .sort({
                interiorDate: -1,
              })
              .limit(1)
              .exec();

            let previousCapture = await InteriorCapture.find({
              interiorId:
                prevActiveInterior?.length > 0
                  ? prevActiveInterior[0].interiorId
                  : null,
              projectId: projectId,
              towerId: towerId,
              floorId: floorId,
            })
              .sort({
                _id: -1,
              })
              .limit(1)
              .exec();

            if (previousCapture && previousCapture.length > 0) {
              capture.wbsItem = previousCapture[0].wbsItem;
              capture.wbsItem.forEach((wbs) => {
                var progress = 0;
                const startDT = new Date(captureDate);
                let plannedCapture = new Date(startDT).setHours(0, 0, 0, 0);
                const taskStart = new Date(wbs.startDate);
                const taskEnd = new Date(wbs.finishDate);
                const duration = wbs.duration;

                if (plannedCapture < taskStart) {
                  progress = 0;
                } else {
                  if (plannedCapture > taskEnd) {
                    progress = 1;
                  } else {
                    const diffTime = Math.abs(plannedCapture - taskStart);
                    const diffDays = Math.ceil(
                      diffTime / (1000 * 60 * 60 * 24)
                    );
                    progress = (diffDays / duration).toFixed(3);
                  }
                }

                wbs.planned = progress;
                wbs.createdBy = email;
                wbs.createdAt = new Date();
                wbs.updatedBy = email;
                wbs.updatedAt = new Date();
              });
            } else {
              projectWBS.wbsList.forEach((wbs) => {
                const wbsId = wbs.wbsId;
                const description = wbs.description;
                const startDate = wbs.startDate;
                const finishDate = wbs.finishDate;
                const duration = wbs.duration;
                const weightage = wbs.weightage;
                const category = wbs.category;
                const classification = wbs.classification;

                var progress = 0;
                const startDT = new Date(captureDate);
                let plannedCapture = new Date(startDT).setHours(0, 0, 0, 0);
                const taskStart = new Date(startDate);
                const taskEnd = new Date(finishDate);

                if (plannedCapture < taskStart) {
                  progress = 0;
                } else {
                  if (plannedCapture > taskEnd) {
                    progress = 1;
                  } else {
                    const diffTime = Math.abs(plannedCapture - taskStart);
                    const diffDays = Math.ceil(
                      diffTime / (1000 * 60 * 60 * 24)
                    );
                    progress = (diffDays / duration).toFixed(3);
                  }
                }

                let data = {
                  wbsId: wbsId,
                  description: description,
                  startDate: startDate,
                  finishDate: finishDate,
                  duration: duration,
                  weightage: weightage,
                  planned: progress,
                  actual: 0,
                  comment: "",
                  category: category,
                  classification: classification,
                  createdBy: email,
                  createdAt: new Date(),
                  updatedBy: email,
                  updatedAt: new Date(),
                };

                capture.wbsItem.push(data);
              });
            }

            capture.save(callback);
          }
        },
        function () {
          return;
        }
      );
    }
  });
};

router.get(
  "/:project/:interior/wbs/int/tour/:tour/:towerId/:floorId",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.project,
          isActive: true,
        },

        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await InteriorCapture.findOne({
              projectId: req.params.project,
              towerId: req.params.towerId,
              floorId: req.params.floorId,
              tourId: req.params.tour,
            }).then(async (projectWBS) => {
              if (projectWBS) {
                const wbsList = projectWBS.wbsItem;
                res.json({
                  wbsData: wbsList,
                });
              } else {
                res.json({
                  wbsData: [],
                });
              }
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

const updateWbsProgressBulk = async (bulkPayload, email) => {
  return bulkPayload.wbsList.map(async (payloadWbs) => {
    if (!!bulkPayload.unitId) {
      const updatedIntCaptureByUnit = await InteriorCapture.findOneAndUpdate(
        {
          "wbsItem.wbsId": payloadWbs.wbsId,
          tourId: bulkPayload.tourId,
          projectId: bulkPayload.projectId,
          towerId: bulkPayload.towerId,
          floorId: bulkPayload.floorId,
          unitId: bulkPayload.unitId,
        },
        {
          $set: {
            updatedBy: email,
            "wbsItem.$.actual": payloadWbs.progress,
            "wbsItem.$.comment": payloadWbs.comment,
            "wbsItem.$.updatedBy": email,
            "wbsItem.$.updatedAt": new Date(),
          },
        }
      );
      return updatedIntCaptureByUnit;
    } else {
      const updatedIntCapture = await InteriorCapture.findOneAndUpdate(
        {
          "wbsItem.wbsId": payloadWbs.wbsId,
          tourId: bulkPayload.tourId,
          projectId: bulkPayload.projectId,
          towerId: bulkPayload.towerId,
          floorId: bulkPayload.floorId,
        },
        {
          $set: {
            updatedBy: email,
            "wbsItem.$.actual": payloadWbs.progress,
            "wbsItem.$.comment": payloadWbs.comment,
            "wbsItem.$.updatedBy": email,
            "wbsItem.$.updatedAt": new Date(),
          },
        }
      );
      return updatedIntCapture;
    }
  });
};

router.put("/wbs/progress/bulk", auth.required, async (req, res, next) => {
  if (req.payload.email && req.body.projectId) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.body.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          await updateWbsProgressBulk(req.body, req.payload.email)
            .then((v) => Promise.all(v))
            .then(() => {
              res.json({
                status: "success",
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

router.put(
  "/:project/:interior/wbs/:wbsId/int/:tour/:towerId/:floorId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.wbsProgress) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const wbsProgress = req.body.wbsProgress;

            await InteriorCapture.findOneAndUpdate(
              {
                "wbsItem.wbsId": req.params.wbsId,
                tourId: req.params.tour,
                projectId: req.params.project,
                towerId: req.params.towerId,
                floorId: req.params.floorId,
              },
              {
                $set: {
                  updatedBy: req.payload.email,
                  "wbsItem.$.actual": wbsProgress.progress,
                  "wbsItem.$.comment": wbsProgress.comment,
                  "wbsItem.$.updatedBy": req.payload.email,
                  "wbsItem.$.updatedAt": new Date(),
                },
              }
            )
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/:interior/wbs/int/chart/:tour/:towerId/:floorId",
  auth.required,
  async (req, res) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let response = {
            sCurve: {
              labels: [],
              planned: [],
              actual: [],
            },
            wbsChart: {
              labels: [],
              planned: [],
              actual: [],
              toolTip: [],
            },
          };

          let captureList = await InteriorTour.find({
            projectId: req.params.project,
            isActive: true,
          })
            .sort({
              captureDate: "asc",
            })
            .exec();

          let dataCaptureList = await InteriorCapture.find({
            projectId: req.params.project,
            towerId: req.params.towerId,
          })
            .select({
              wbsItem: 1,
              projectId: 1,
              interiorId: 1,
              tourId: 1,
            })
            .exec();

          let sCurve = [];
          let barChart = [];

          if (
            captureList &&
            captureList.length > 0 &&
            dataCaptureList.length > 0
          ) {
            for (let i = 0; i < captureList.length; i++) {
              let dc = captureList[i];
              let dataCaptureDate = new Date(dc.interiorDate);
              let plannedProgress = 0;
              let actualProgress = 0;

              let dcList = _.filter(dataCaptureList, {
                projectId: dc.projectId,
                interiorId: dc.interiorId,
              });

              if (dcList && dcList.length > 0) {
                for (let i = 0; i < dcList.length; i++) {
                  dcList[i].wbsItem.forEach((wbs) => {
                    plannedProgress =
                      plannedProgress + wbs.planned * wbs.weightage;

                    if (wbs.actual) {
                      actualProgress =
                        actualProgress + wbs.actual * wbs.weightage;
                    }
                  });
                }

                let point = {
                  captureDate: dataCaptureDate,
                  planned: plannedProgress > 1 ? 1 : plannedProgress,
                  actual: actualProgress,
                  isCaptureCompleted: true,
                };

                sCurve.push(point);
              }
            }

            // add data for planned s curve till last date of the project
            if (sCurve.length > 0) {
              let intWBSList = await InteriorWBS.find({
                towerId: req.params.towerId,
                projectId: req.params.project,
              });

              let projectFinishdate = await InteriorWBS.findOne({
                towerId: req.params.towerId,
                projectId: req.params.project,
              })
                .sort({
                  projectFinishDate: "desc",
                })
                .exec();

              let finishDate = projectFinishdate.projectFinishDate;
              let captureInterval = projectFinishdate.captureInterval;

              let lastCaptureDate = new Date(
                sCurve[sCurve.length - 1].captureDate
              );

              let nextPlannedCapture = lastCaptureDate.setDate(
                lastCaptureDate.getDate() + captureInterval
              );
              let plannedEndDate = new Date(finishDate);
              let plannedDataCapture = new Date(nextPlannedCapture).setHours(
                0,
                0,
                0,
                0
              );
              let nextCapture = new Date(plannedDataCapture);

              while (nextCapture <= plannedEndDate) {
                const dataCaptureDate = new Date(nextCapture);
                let progress = 0;
                let overallAprogress = 0;

                for (let i = 0; i < intWBSList.length; i++) {
                  intWBSList[i].wbsList.forEach((wbs) => {
                    const taskStart = new Date(wbs.startDate);
                    const taskEnd = new Date(wbs.finishDate);

                    if (dataCaptureDate < taskStart) {
                      progress = 0;
                    } else {
                      if (dataCaptureDate > taskEnd) {
                        progress = 1;
                      } else {
                        const diffTime = Math.abs(
                          new Date(dataCaptureDate) - new Date(taskStart)
                        );
                        const diffDays = Math.ceil(
                          diffTime / (1000 * 60 * 60 * 24)
                        );

                        progress = (diffDays / wbs.duration).toFixed(3);
                      }
                    }

                    overallAprogress =
                      overallAprogress + progress * wbs.weightage;
                  });
                }

                let point = {
                  captureDate: dataCaptureDate,
                  planned: overallAprogress > 1 ? 1 : overallAprogress,
                  actual: 0,
                  isCaptureCompleted: false,
                };

                sCurve.push(point);

                let nextPlannedCapture = nextCapture.setDate(
                  nextCapture.getDate() + captureInterval
                );
                nextCapture = new Date(nextPlannedCapture);
              }
            }

            let workSchedule = await InteriorCapture.findOne({
              projectId: req.params.project,
              interiorId: req.params.interior,
              tourId: req.params.tour,
              towerId: req.params.towerId,
              floorId: req.params.floorId,
            });

            if (workSchedule) {
              workSchedule.wbsItem.forEach((wbs) => {
                if (
                  (wbs.actual && wbs.actual > 0) ||
                  (wbs.planned && wbs.planned > 0)
                ) {
                  let bar = {
                    wbsName: wbs.description,
                    planned: wbs.planned,
                    actual: wbs.actual,
                    comment: wbs.comment ? wbs.comment : "",
                  };

                  barChart.push(bar);
                }
              });
            }
            await MasterData.findOne({
              projectId: req.params.project,
            }).then((data) => {
              response.performanceIndex = data?.performanceIndex;
            });

            sCurve.forEach((m) => {
              response.sCurve.labels.push(
                moment(m.captureDate).utcOffset(330).format("YYYY-MMM-DD")
              );
              response.sCurve.planned.push((m.planned * 100).toFixed(2));
              if (m.isCaptureCompleted) {
                response.sCurve.actual.push(m.actual.toFixed(2));
              }
            });

            barChart.forEach((m) => {
              response.wbsChart.labels.push(m.wbsName);
              response.wbsChart.planned.push((m.planned * 100).toFixed(2));
              if (m.actual > 0 || m.planned > 0) {
                response.wbsChart.actual.push(m.actual.toFixed(2));
              }
              response.wbsChart.toolTip.push(m.comment);
            });
          }

          res.json({
            response,
          });
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);

router.get(
  "/:project/:interior/wbs/int/chart/",
  auth.required,
  async (req, res) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let responseData = [];
          let performanceIndex;

          let captureList = await InteriorTour.find({
            projectId: req.params.project,
            isActive: true,
          })
            .sort({
              captureDate: "asc",
            })
            .exec();
          let interiorData = await req.interior
            .populate({
              path: "floorWalkthough",
              populate: {
                path: "tours",
                model: "TourImage",
              },
            })
            .execPopulate();
          let interiorOrderData = lodash.orderBy(
            interiorData.floorWalkthough,
            ["orderNo"],
            ["asc"]
          );

          let unitLevelCharts = [];
          let locations = [];
          if (req.project.isUnitLevel) {
            await MasterData.findOne({
              projectId: req.params.project,
            }).then(async (data) => {
              locations = data?.workLocation;
            });
            for (let tower of interiorOrderData) {
              for (let tour of tower.tours) {
                let workSchedules = await InteriorCapture.find({
                  projectId: req.params.project,
                  interiorId: tour.interiorId,
                  tourId: tour.tourId,
                  towerId: tour.towerId,
                  floorId: tour.locationId,
                });
                let towerName = locations.find(
                  (item) => item.locationId == tour.towerId
                );
                let floorName = locations.find(
                  (item) => item.locationId == tour.locationId
                );
                if (!!workSchedules && workSchedules.length > 0) {
                  for (const workSchedule of workSchedules) {
                    let wbsChart = {
                      labels: [],
                      planned: [],
                      actual: [],
                      toolTip: [],
                    };
                    let unitLevelData = {
                      unitId: null,
                      unitName: null,
                      orderNumber: 0,
                      wbsChart: wbsChart,
                    };
                    const wbsItems = workSchedule.wbsItem;
                    wbsItems.forEach((wbs) => {
                      if (
                        (wbs.actual && wbs.actual > 0) ||
                        (wbs.planned && wbs.planned > 0)
                      ) {
                        let bar = {
                          wbsName: wbs.description,
                          planned: wbs.planned,
                          actual: wbs.actual,
                          comment: wbs.comment ? wbs.comment : "",
                        };
                        wbsChart.labels.push(bar.wbsName);
                        wbsChart.planned.push((bar.planned * 100).toFixed(2));
                        if (bar.actual > 0 || bar.planned > 0) {
                          wbsChart.actual.push(bar.actual.toFixed(2));
                        }
                        wbsChart.toolTip.push(bar.comment);
                      }
                    });
                    unitLevelData.unitId = workSchedule.unitId;
                    const unitData = locations.find(
                      (l) => l.locationId === unitLevelData.unitId
                    );
                    unitLevelData.unitName = unitData.level3;
                    unitLevelData.orderNumber = unitData.orderNo;
                    unitLevelData.wbsChart = wbsChart;
                    unitLevelData.towerName = towerName.level1;
                    unitLevelData.towerOrderNumber = towerName.orderNo;
                    unitLevelData.floorOrderNumber = floorName.orderNo;
                    unitLevelData.floorName =
                      floorName.level2 + " " + unitData.level3;
                    unitLevelCharts.push(unitLevelData);
                  }
                }
              }
            }
            if (unitLevelCharts.length > 0) {
              responseData = lodash.orderBy(
                unitLevelCharts,
                ["towerOrderNumber", "floorOrderNumber", "orderNumber"],
                ["asc"]
              );
            }
          } else {
            for (let tower of interiorOrderData) {
              tower.tours = lodash.orderBy(tower.tours, ["orderNo"], ["asc"]);
              let towerTourData = tower.tours.filter(
                (item) => item.isPublished == true
              );
              for (let tour of towerTourData) {
                let response = {
                  towerName: tower.towerName,
                  floorName: tour.tourName,
                  tourId: tour.tourId,
                  towerOrderNo: tower.orderNo,
                  floorOrderNo: tour.orderNo,
                  sCurve: {
                    labels: [],
                    planned: [],
                    actual: [],
                  },
                  wbsChart: {
                    labels: [],
                    planned: [],
                    actual: [],
                    toolTip: [],
                  },
                };
                let dataCaptureList = await InteriorCapture.find({
                  projectId: req.params.project,
                  towerId: tower.towerId,
                })
                  .select({
                    wbsItem: 1,
                    projectId: 1,
                    interiorId: 1,
                    tourId: 1,
                  })
                  .exec();

                let sCurve = [];
                let barChart = [];

                if (
                  captureList &&
                  captureList.length > 0 &&
                  dataCaptureList.length > 0
                ) {
                  for (let i = 0; i < captureList.length; i++) {
                    let dc = captureList[i];
                    let dataCaptureDate = new Date(dc.interiorDate);
                    let plannedProgress = 0;
                    let actualProgress = 0;

                    let dcList = _.filter(dataCaptureList, {
                      projectId: dc.projectId,
                      interiorId: dc.interiorId,
                    });

                    if (dcList && dcList.length > 0) {
                      for (let i = 0; i < dcList.length; i++) {
                        dcList[i].wbsItem.forEach((wbs) => {
                          plannedProgress =
                            plannedProgress + wbs.planned * wbs.weightage;

                          if (wbs.actual) {
                            actualProgress =
                              actualProgress + wbs.actual * wbs.weightage;
                          }
                        });
                      }

                      let point = {
                        captureDate: dataCaptureDate,
                        planned: plannedProgress > 1 ? 1 : plannedProgress,
                        actual: actualProgress,
                        isCaptureCompleted: true,
                      };

                      sCurve.push(point);
                    }
                  }

                  // add data for planned s curve till last date of the project
                  if (sCurve.length > 0) {
                    let intWBSList = await InteriorWBS.find({
                      towerId: tower.towerId,
                      projectId: req.params.project,
                    });

                    let projectFinishdate = await InteriorWBS.findOne({
                      towerId: tower.towerId,
                      projectId: req.params.project,
                    })
                      .sort({
                        projectFinishDate: "desc",
                      })
                      .exec();

                    let finishDate = projectFinishdate.projectFinishDate;
                    let captureInterval = projectFinishdate.captureInterval;

                    let lastCaptureDate = new Date(
                      sCurve[sCurve.length - 1].captureDate
                    );

                    let nextPlannedCapture = lastCaptureDate.setDate(
                      lastCaptureDate.getDate() + captureInterval
                    );
                    let plannedEndDate = new Date(finishDate);
                    let plannedDataCapture = new Date(
                      nextPlannedCapture
                    ).setHours(0, 0, 0, 0);
                    let nextCapture = new Date(plannedDataCapture);

                    while (nextCapture <= plannedEndDate) {
                      const dataCaptureDate = new Date(nextCapture);
                      let progress = 0;
                      let overallAprogress = 0;

                      for (let i = 0; i < intWBSList.length; i++) {
                        intWBSList[i].wbsList.forEach((wbs) => {
                          const taskStart = new Date(wbs.startDate);
                          const taskEnd = new Date(wbs.finishDate);

                          if (dataCaptureDate < taskStart) {
                            progress = 0;
                          } else {
                            if (dataCaptureDate > taskEnd) {
                              progress = 1;
                            } else {
                              const diffTime = Math.abs(
                                new Date(dataCaptureDate) - new Date(taskStart)
                              );
                              const diffDays = Math.ceil(
                                diffTime / (1000 * 60 * 60 * 24)
                              );

                              progress = (diffDays / wbs.duration).toFixed(3);
                            }
                          }

                          overallAprogress =
                            overallAprogress + progress * wbs.weightage;
                        });
                      }

                      let point = {
                        captureDate: dataCaptureDate,
                        planned: overallAprogress > 1 ? 1 : overallAprogress,
                        actual: 0,
                        isCaptureCompleted: false,
                      };

                      sCurve.push(point);

                      let nextPlannedCapture = nextCapture.setDate(
                        nextCapture.getDate() + captureInterval
                      );
                      nextCapture = new Date(nextPlannedCapture);
                    }
                  }

                  let workSchedule = await InteriorCapture.findOne({
                    projectId: req.params.project,
                    interiorId: req.params.interior,
                    tourId: tour.tourId,
                    towerId: tower.towerId,
                    floorId: tour.locationId,
                  });

                  if (workSchedule) {
                    workSchedule.wbsItem.forEach((wbs) => {
                      if (
                        (wbs.actual && wbs.actual > 0) ||
                        (wbs.planned && wbs.planned > 0)
                      ) {
                        let bar = {
                          wbsName: wbs.description,
                          planned: wbs.planned,
                          actual: wbs.actual,
                          comment: wbs.comment ? wbs.comment : "",
                        };

                        barChart.push(bar);
                      }
                    });
                  }

                  sCurve.forEach((m) => {
                    response.sCurve.labels.push(
                      moment(m.captureDate).utcOffset(330).format("YYYY-MMM-DD")
                    );
                    response.sCurve.planned.push((m.planned * 100).toFixed(2));
                    if (m.isCaptureCompleted) {
                      response.sCurve.actual.push(m.actual.toFixed(2));
                    }
                  });

                  barChart.forEach((m) => {
                    response.wbsChart.labels.push(m.wbsName);
                    response.wbsChart.planned.push(
                      (m.planned * 100).toFixed(2)
                    );
                    if (m.actual > 0 || m.planned > 0) {
                      response.wbsChart.actual.push(m.actual.toFixed(2));
                    }
                    response.wbsChart.toolTip.push(m.comment);
                  });
                }
                responseData.push(response);
              }
            }
            await MasterData.findOne({
              projectId: req.params.project,
            }).then((data) => {
              performanceIndex = data?.performanceIndex;
            });
          }
          res.json({
            responseData,
            performanceIndex,
          });
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);

// Previous tour details
router.get(
  "/:project/interiors/:interior/tour/:tour/previous-tour-details",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await req.project
              .populate({
                path: "interiors",
                match: {
                  createdAt: {
                    $lt: new Date(req.interior.createdAt),
                  },
                  isActive: true,
                },
                options: {
                  sort: {
                    createdAt: "desc",
                  },
                },
              })
              .execPopulate();

            if (req.project.interiors.length > 0) {
              for (let { interiorId } of req.project.interiors) {
                let walkthrough = await TourImage.findOne({
                  interiorId,
                  locationId: req.tour.locationId,
                  isPublished: true,
                });

                if (walkthrough && walkthrough.features) {
                  res.json(walkthrough);
                  return;
                }
              }
              res.sendStatus(404);
              return;
            }

            res.sendStatus(404);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

const updateProgressByDate = async (
  projectId,
  interiorId,
  captureDate,
  email
) => {
  await InteriorCapture.find({
    interiorId: interiorId,
    projectId: projectId,
  }).then(async (wbsItems) => {
    if (wbsItems) {
      asyncPackage.forEach(
        wbsItems,
        async function (projectWBS, callback) {
          if (projectWBS) {
            projectWBS.captureDate = new Date(captureDate).setHours(0, 0, 0, 0);
            projectWBS.updatedBy = email;

            projectWBS.wbsItem.forEach((wbs) => {
              const startDate = wbs.startDate;
              const finishDate = wbs.finishDate;
              const duration = wbs.duration;
              var progress = 0;

              const startDT = new Date(
                moment(captureDate).utcOffset(0)
              ).setHours(0, 0, 0, 0);

              let plannedCapture = new Date(startDT);
              const taskStart = new Date(
                moment(startDate).utcOffset(0)
              ).setHours(0, 0, 0, 0);
              const taskEnd = new Date(
                moment(finishDate).utcOffset(0)
              ).setHours(0, 0, 0, 0);

              if (plannedCapture < taskStart) {
                progress = 0;
              } else {
                if (plannedCapture > taskEnd) {
                  progress = 1;
                } else {
                  const diffTime = Math.abs(plannedCapture - taskStart);
                  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                  progress = (diffDays / duration).toFixed(4);
                }
              }

              wbs.planned = progress;
              wbs.updatedBy = email;
              wbs.updatedAt = new Date();
            });
            projectWBS.save(callback);
          }
        },
        function (err) {
          console.log(err);
          return;
        }
      );
    }
  });
};

// check self serve access
router.get("/:project/access/self-serve", auth.required, async (req, res) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          res.json({
            access: true,
          });
        } else {
          res.json({
            access: false,
          });
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

router.put(
  "/:project/:interior/restore/int/tour/:tour/:towerId/:floorId",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.project,
          isActive: true,
        },

        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let projectId = req.params.project;
            let towerId = req.params.towerId;
            let floorId = req.params.floorId;
            let tourId = req.params.tour;
            let interiorId = req.params.interior;
            let captureDate = req.interior.interiorDate;

            await InteriorWBS.findOne({
              projectId: projectId,
              towerId: towerId,
              floorId: floorId,
            }).then(async (projectWBS) => {
              if (projectWBS) {
                let wbsItems = [];

                projectWBS.wbsList.forEach((wbs) => {
                  const wbsId = wbs.wbsId;
                  const description = wbs.description;
                  const startDate = wbs.startDate;
                  const finishDate = wbs.finishDate;
                  const duration = wbs.duration;
                  const weightage = wbs.weightage;
                  const category = wbs.category;
                  const classification = wbs.classification;
                  var progress = 0;
                  const startDT = new Date(captureDate);
                  let plannedCapture = new Date(startDT).setHours(0, 0, 0, 0);
                  const taskStart = new Date(startDate);
                  const taskEnd = new Date(finishDate);

                  if (plannedCapture < taskStart) {
                    progress = 0;
                  } else {
                    if (plannedCapture > taskEnd) {
                      progress = 1;
                    } else {
                      const diffTime = Math.abs(plannedCapture - taskStart);
                      const diffDays = Math.ceil(
                        diffTime / (1000 * 60 * 60 * 24)
                      );
                      progress = (diffDays / duration).toFixed(3);
                    }
                  }

                  let data = {
                    wbsId: wbsId,
                    description: description,
                    startDate: startDate,
                    finishDate: finishDate,
                    duration: duration,
                    weightage: weightage,
                    planned: progress,
                    actual: 0,
                    comment: "",
                    category: category,
                    classification: classification,
                    createdBy: req.payload.email,
                    createdAt: new Date(),
                    updatedBy: req.payload.email,
                    updatedAt: new Date(),
                  };

                  wbsItems.push(data);
                });

                await InteriorCapture.findOneAndUpdate(
                  {
                    projectId: projectId,
                    towerId: towerId,
                    floorId: floorId,
                    tourId: tourId,
                    interiorId: interiorId,
                  },
                  {
                    $set: {
                      wbsItem: wbsItems,
                      updatedBy: req.payload.email,
                    },
                  }
                ).exec();

                res.json({
                  status: "success",
                });
              }
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// return a list of tags
router.get(
  "/:project/:interior/exportchartdata/int/:towerId",
  auth.required,
  async (req, res, next) => {
    var workbook = new Excel.Workbook();
    let worksheet = workbook.addWorksheet("Data");
    let projectId = req.params.project;
    let interiorId = req.params.interior;
    let towerId = req.params.towerId;

    await MasterData.findOne({
      projectId: req.params.project,
    })
      .then(async (data) => {
        const locations = data?.workLocation;

        worksheet.columns = [
          {
            header: "Level1 Location",
            key: "level1",
            width: 35,
          },
          {
            header: "Level2 Location",
            key: "level2",
            width: 35,
          },
          {
            header: "WBS Description",
            key: "wbs",
            width: 35,
          },
          {
            header: "Planned",
            key: "planned",
            width: 22,
          },
          {
            header: "Actual",
            key: "actual",
            width: 22,
          },
        ];
        let projectData = await Project.findOne({
          projectId: projectId,
        }).exec();
        const isUnitLevel = projectData?.isUnitLevel;
        let unit = null;
        if (isUnitLevel) {
          worksheet.columns = [
            {
              header: "Level1 Location",
              key: "level1",
              width: 35,
            },
            {
              header: "Level2 Location",
              key: "level2",
              width: 35,
            },
            {
              header: "Level3 Location",
              key: "level3",
              width: 35,
            },
            {
              header: "WBS Description",
              key: "wbs",
              width: 35,
            },
            {
              header: "Planned",
              key: "planned",
              width: 22,
            },
            {
              header: "Actual",
              key: "actual",
              width: 22,
            },
          ];
        }
        let captureList = await InteriorCapture.find({
          projectId: projectId,
          interiorId: interiorId,
          towerId: towerId,
        }).exec();

        for (let i = 0; i < captureList.length; i++) {
          let capture = captureList[i];
          let wbsItem = capture.wbsItem;
          if (wbsItem && wbsItem.length > 0) {
            let tower = locations.find(
              (l) => l.locationId === captureList[i].towerId
            );
            let floor = locations.find(
              (l) => l.locationId === captureList[i].floorId
            );
            if (isUnitLevel) {
              unit = locations.find(
                (l) => l.locationId === captureList[i].unitId
              );
            }
            for (let j = 0; j < wbsItem.length; j++) {
              let wbs = [];

              wbs.push(tower?.level1);
              wbs.push(floor?.level2);
              if (isUnitLevel) {
                wbs.push(unit?.level3);
              }
              wbs.push(wbsItem[j].description);
              wbs.push(wbsItem[j].planned * 100);
              wbs.push(wbsItem[j].actual);

              worksheet.addRow(wbs);
            }
          }
        }

        res.setHeader("Content-Type", "text/plain");

        const fileBuffer = await workbook.xlsx.writeBuffer();

        res.send(fileBuffer.toString("base64"));
      })
      .catch(next);
  }
);

router.post(
  "/:project/:interior/wbs/int/chartbyactivity/:tour/:towerId/",
  auth.required,
  async (req, res) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let response = {
            wbsChart: {
              labels: [],
              planned: [],
              actual: [],
            },
          };
          let query = req.body.query;
          let projectId = req.params.project;
          let interiorId = req.params.interior;
          let towerId = req.params.towerId;
          let locations;

          let barChart = [];

          let calptureList = await InteriorCapture.find({
            projectId: projectId,
            interiorId: interiorId,
            towerId: towerId,
          });

          await MasterData.findOne({
            projectId: projectId,
          }).then((data) => {
            locations = data?.workLocation;
          });

          if (calptureList && calptureList.length > 0) {
            calptureList.forEach((wbs) => {
              let location = locations.find(
                (l) => l.locationId === wbs.floorId
              );

              let wbsItem = wbs.wbsItem.find(
                (item) => query.toLowerCase() === item.description.toLowerCase()
              );

              if (wbsItem) {
                let bar = {
                  wbsName: location.level2,
                  planned: wbsItem.planned,
                  actual: wbsItem.actual,
                };

                barChart.push(bar);
              }
            });

            barChart.forEach((m) => {
              response.wbsChart.labels.push(m.wbsName);
              response.wbsChart.planned.push((m.planned * 100).toFixed(2));
              response.wbsChart.actual.push(m.actual.toFixed(2));
            });
          }

          res.json({
            response,
          });
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);

router.get(
  "/:project/interiors-with-towers",
  auth.required,
  async (req, res, next) => {
    try {
      const project = await req.project
        .populate({
          path: "interiors",
          options: {
            sort: {
              createdAt: "desc",
            },
          },
          populate: {
            path: "floorWalkthough",
            populate: {
              path: "tours",
              model: "TourImage",
              select: "isActive isPublished locationId",
            },
          },
        })
        .execPopulate();
      let dataCaptureList = [];
      let plannedProgress = 0;
      let actualProgress = 0;
      if (!project.isUnitLevel) {
        dataCaptureList = await InteriorCapture.find({
          projectId: req.params.project,
        })
          .select({
            wbsItem: 1,
            projectId: 1,
            interiorId: 1,
            tourId: 1,
            towerId: 1,
          })
          .exec();
      }
      const interiorData = project.interiors.map((interior) => {
        // Sort floorWalkthough by orderNumber
        const sortedFloorWalkthrough = lodash.orderBy(
          interior.floorWalkthough,
          ["orderNo"],
          ["asc"]
        );

        // Compute tour counts for each floorWalkthough
        const modifiedFloorWalkthrough = sortedFloorWalkthrough.map(
          (walkthrough) => {
            const { tours, ...walkthroughWithoutTours } =
              walkthrough.toObject();
            if (
              !project.isUnitLevel &&
              !!walkthrough &&
              dataCaptureList &&
              dataCaptureList.length > 0
            ) {
              let dcList = _.filter(dataCaptureList, {
                projectId: interior.projectId,
                interiorId: walkthrough.interiorId,
                towerId: walkthrough.towerId,
              });

              plannedProgress = 0;
              actualProgress = 0;
              if (dcList && dcList.length > 0) {
                for (let i = 0; i < dcList.length; i++) {
                  dcList[i].wbsItem.forEach((wbs) => {
                    plannedProgress =
                      plannedProgress + wbs.planned * wbs.weightage;

                    if (wbs.actual) {
                      actualProgress =
                        actualProgress + wbs.actual * wbs.weightage;
                    }
                  });
                }
              }
            }
            const tourCounts = tours.reduce(
              (acc, tour) => {
                if (tour.isActive) {
                  acc.totalCount++;
                  if (tour.isPublished) {
                    acc.publishedCount++;
                  }
                }
                return acc;
              },
              { publishedCount: 0, totalCount: 0 }
            );

            return {
              ...walkthroughWithoutTours,
              publishedCount: tourCounts.publishedCount,
              totalCount: tourCounts.totalCount,
              planned:
                plannedProgress > 0.99
                  ? 100
                  : (plannedProgress * 100).toFixed(2),
              actual:
                actualProgress?.toFixed(2) > 99.5
                  ? 100
                  : actualProgress?.toFixed(2),
              tours: walkthrough.tours,
            };
          }
        );

        // Return modified interior object
        return {
          ...interior.toObject(),
          floorWalkthough: modifiedFloorWalkthrough,
        };
      });

      res.json({ interiors: interiorData });
    } catch (error) {
      next(error);
    }
  }
);

router.get(
  "/:project/interior/:interior/tower/:towerId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const count = await Project.countDocuments({
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      });
      if (count > 0 || req.payload.isAdmin) {
        const data = await InteriorTour.findOne(
          {
            interiorId: req.params.interior,
            "floorWalkthough.towerId": req.params.towerId,
          },
          {
            "floorWalkthough.$": 1, // Select the first matched floorWalkthough object only
          }
        )
          .populate({
            path: "floorWalkthough.tours",
            model: "TourImage",
          })
          .exec();

        let floorWalkthough = lodash.orderBy(
          data.floorWalkthough[0].tours,
          ["orderNo"],
          ["asc"]
        );
        res.json({
          tours: floorWalkthough,
        });
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);
//Unit level related newly added apis
// Fetch units for the floor
router.get(
  "/:project/location/units/:floorId",
  auth.required,
  async (req, res) => {
    let projectId = req.params.project;
    let floorId = req.params.floorId;
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isBlocked: false,
              isActive: true,
            },
          },
          projectId: projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await MasterData.findOne({
              projectId: projectId,
            })
              .then(async (data) => {
                const locations = data?.workLocation;
                const units = locations.filter(
                  (loc) => loc.parentLocationId == floorId && !loc.level4
                );
                const classifications = data?.workClassification;
                res.json({
                  units: units,
                  classifications: classifications,
                });
                return;
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);
router.get(
  "/:project/:interior/wbs/int/tour/:tour/:towerId/:floorId/:unitId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.project,
          isActive: true,
        },

        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let wbsData = [];

            await InteriorCapture.findOne({
              projectId: req.params.project,
              towerId: req.params.towerId,
              floorId: req.params.floorId,
              tourId: req.params.tour,
              unitId: req.params.unitId,
            }).then(async (projectWBS) => {
              if (projectWBS) {
                const wbsList = projectWBS.wbsItem;
                res.json({
                  wbsData: wbsList,
                });
              } else {
                res.json({
                  wbsData: [],
                });
              }
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);
router.get(
  "/:project/:interior/wbs/int/chart/:tour/:towerId/:floorId/byUnit",
  auth.required,
  async (req, res, next) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let response = {
            unitLevelCharts: [],
          };
          let unitLevelCharts = [];
          let locations = [];
          let workSchedules = await InteriorCapture.find({
            projectId: req.params.project,
            interiorId: req.params.interior,
            tourId: req.params.tour,
            towerId: req.params.towerId,
            floorId: req.params.floorId,
          });
          await MasterData.findOne({
            projectId: req.params.project,
          }).then(async (data) => {
            locations = data?.workLocation;
          });
          if (!!workSchedules && workSchedules.length > 0) {
            for (const workSchedule of workSchedules) {
              let wbsChart = {
                labels: [],
                planned: [],
                actual: [],
                toolTip: [],
              };
              let unitLevelData = {
                unitId: null,
                unitName: null,
                orderNumber: 0,
                wbsChart: wbsChart,
              };
              const wbsItems = workSchedule.wbsItem;
              wbsItems.forEach((wbs) => {
                if (
                  (wbs.actual && wbs.actual > 0) ||
                  (wbs.planned && wbs.planned > 0)
                ) {
                  let bar = {
                    wbsName: wbs.description,
                    planned: wbs.planned,
                    actual: wbs.actual,
                    comment: wbs.comment ? wbs.comment : "",
                  };
                  wbsChart.labels.push(bar.wbsName);
                  wbsChart.planned.push((bar.planned * 100).toFixed(2));
                  if (bar.actual > 0 || bar.planned > 0) {
                    wbsChart.actual.push(bar.actual.toFixed(2));
                  }
                  wbsChart.toolTip.push(bar.comment);
                }
              });
              unitLevelData.unitId = workSchedule.unitId;
              const unitData = locations.find(
                (l) => l.locationId === unitLevelData.unitId
              );
              unitLevelData.unitName = unitData.level3;
              unitLevelData.orderNumber = unitData.orderNo;
              unitLevelData.wbsChart = wbsChart;
              unitLevelCharts.push(unitLevelData);
            }
          }
          if (unitLevelCharts.length > 0) {
            response.unitLevelCharts = lodash.orderBy(
              unitLevelCharts,
              ["orderNumber"],
              ["asc"]
            );
          }
          res.json({
            response,
          });
          return;
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);

router.put(
  "/:project/:interior/restore/int/tour/:tour/:towerId/:floorId/:unitId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.project,
          isActive: true,
        },

        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let projectId = req.params.project;
            let towerId = req.params.towerId;
            let floorId = req.params.floorId;
            let unitId = req.params.unitId;
            let tourId = req.params.tour;
            let interiorId = req.params.interior;
            let captureDate = req.interior.interiorDate;

            await InteriorWBS.findOne({
              projectId: projectId,
              towerId: towerId,
              floorId: floorId,
              unitId: unitId,
            }).then(async (projectWBS) => {
              if (projectWBS) {
                let wbsItems = [];

                projectWBS.wbsList.forEach((wbs) => {
                  const wbsId = wbs.wbsId;
                  const description = wbs.description;
                  const startDate = wbs.startDate;
                  const finishDate = wbs.finishDate;
                  const duration = wbs.duration;
                  const weightage = wbs.weightage;
                  const category = wbs.category;
                  const classification = wbs.classification;
                  var progress = 0;
                  const startDT = new Date(captureDate);
                  let plannedCapture = new Date(startDT).setHours(0, 0, 0, 0);
                  const taskStart = new Date(startDate);
                  const taskEnd = new Date(finishDate);

                  if (plannedCapture < taskStart) {
                    progress = 0;
                  } else {
                    if (plannedCapture > taskEnd) {
                      progress = 1;
                    } else {
                      const diffTime = Math.abs(plannedCapture - taskStart);
                      const diffDays = Math.ceil(
                        diffTime / (1000 * 60 * 60 * 24)
                      );
                      progress = (diffDays / duration).toFixed(3);
                    }
                  }

                  let data = {
                    wbsId: wbsId,
                    description: description,
                    startDate: startDate,
                    finishDate: finishDate,
                    duration: duration,
                    weightage: weightage,
                    planned: progress,
                    actual: 0,
                    comment: "",
                    category: category,
                    classification: classification,
                    createdBy: req.payload.email,
                    createdAt: new Date(),
                    updatedBy: req.payload.email,
                    updatedAt: new Date(),
                  };

                  wbsItems.push(data);
                });

                await InteriorCapture.findOneAndUpdate(
                  {
                    projectId: projectId,
                    towerId: towerId,
                    floorId: floorId,
                    unitId: unitId,
                    tourId: tourId,
                    interiorId: interiorId,
                  },
                  {
                    $set: {
                      wbsItem: wbsItems,
                      updatedBy: req.payload.email,
                    },
                  }
                ).exec();

                res.json({
                  status: "success",
                });
              }
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/interiors/:interior/emailNotify",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.project,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            res.json({ status: "success" });
            const unblockedUser = req.project.users.filter(
              ({ isBlocked }) => !isBlocked
            );
            await Util.sendTourPublishEmail(
              Util.getMailToArrayFromEmailArray(
                unblockedUser,
                unblockedUser.map(({ email }) => email)
              ),
              {
                tour: {
                  tourName: req.interior.interiorName,
                  tourDate: req.interior.interiorDate,
                },
                project: req.project,
                shareLink: req.body.shareLink,
                floorPublishedCount: req.body.floorPublishedCount,
                tourType: "Virtual",
              }
            );
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/interiors/:interior/tags",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (!!req.body.tagList && req.body.tagList.length > 0) {
              req.interior.tagList = req.body.tagList;
            }
            req.interior.updatedBy = req.payload.email;
            await req.interior
              .save()
              .then((interior) => {
                res.json({
                  interior: interior,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);
router.put(
  "/:project/interiors/fixFeatureData/test",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let destTour;
            let sourceTour;
            let destFeature = [];
            await TourImage.findOne({
              tourId: req.body.sourceTourId,
              interiorId: req.body.sourceInteriorId,
            }).then((data) => {
              sourceTour = data;
            });
            await TourImage.findOne({
              tourId: req.body.destTourId,
              interiorId: req.body.interiorId,
            })
              .then((data) => {
                destTour = data;
                for (let i = 0; i < destTour.images.length; i++) {
                  const imageData = destTour.images[i];
                  const featureExists = destTour.features.features.find(
                    (feature) =>
                      feature.properties.imageId === imageData.imageId
                  );
                  if (!featureExists) {
                    let imageNumber = imageData.imageId.split("_")[1];
                    console.log(imageNumber);
                    console.log(sourceTour.features.features[imageNumber - 1]);
                    let sourceFeature =
                      sourceTour.features.features[imageNumber - 1];

                    console.log(sourceFeature);
                    destFeature.push({
                      geometry: sourceFeature.geometry,
                      id: sourceFeature?.id,
                      properties: {
                        imageId: imageData.imageId,
                        imageName: imageData.imageName,
                        imageNumber: imageNumber,
                      },
                      type: "Feature",
                    });
                  } else {
                    destFeature.push(featureExists);
                  }
                }

                TourImage.findOneAndUpdate(
                  {
                    tourId: req.body.destTourId,
                    interiorId: req.body.interiorId,
                  },
                  {
                    $set: {
                      features: {
                        features: destFeature,
                        type: "FeatureCollection",
                      },
                    },
                  },
                  {
                    new: true,
                  },
                  (err) => {
                    console.log(err);
                    if (err) {
                      res.json({
                        status: "failed",
                      });
                    }

                    res.json({
                      missingData: destFeature,
                      status: "success",
                    });
                  }
                );
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);
module.exports = router;
