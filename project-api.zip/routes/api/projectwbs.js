"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const ExteriorWBS = mongoose.model("ExteriorWBS");
const InteriorWBS = mongoose.model("InteriorWBS");
const TourImage = mongoose.model("TourImage");
const AerialTour = mongoose.model("AerialTour");
const Project = mongoose.model("Project");
const auth = require("../auth");
const uuid = require("uuid");
const _ = require("underscore");
const asyncPackage = require("async");
const InteriorCapture = mongoose.model("InteriorCapture");
const InteriorTour = mongoose.model("InteriorTour");

// Preload project objects on routes with ':project'
router.param("projectId", (req, res, next, projectId) => {
  Project.findOne({ projectId: projectId })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.get(
  "/:projectId/wbs/int/:towerId/:floorId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            InteriorWBS.findOne(
              {
                projectId: req.params.projectId,
                towerId: req.params.towerId,
                floorId: req.params.floorId,
              },
              {
                "wbsList.wbsId": 1,
                "wbsList.startDate": 1,
                "wbsList.finishDate": 1,
                "wbsList.weightage": 1,
                "wbsList.duration": 1,
                "wbsList.description": 1,
                "wbsList.category": 1,
                "wbsList.classification": 1,
              }
            )
              .then((data) => {
                res.json({
                  wbs: data ? data.wbsList : [],
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:projectId/wbs/ext/:towerId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            ExteriorWBS.findOne(
              {
                projectId: req.params.projectId,
                towerId: req.params.towerId,
              },
              {
                "wbsList.wbsId": 1,
                "wbsList.startDate": 1,
                "wbsList.finishDate": 1,
                "wbsList.weightage": 1,
                "wbsList.duration": 1,
                "wbsList.description": 1,
              }
            )
              .then((data) => {
                res.json({
                  wbs: data ? data.wbsList : [],
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.post("/:projectId/wbs/int/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    const pid = req.params.projectId;
    const createdBy = req.payload.email;
    const projectWBS = req.body.wbs.wbs;
    const startDate = projectWBS.startDate;
    const finishDate = projectWBS.finishDate;
    const captureInterval = projectWBS.captureInterval;
    const towerId = projectWBS.towerId;
    const floorId = projectWBS.floorId;
    var projectDuration = 0;

    await TourImage.updateMany(
      {
        projectId: pid,
        towerId: towerId,
        locationId: floorId,
      },
      {
        $set: {
          isSelfServe: true,
          isWBSPublished: false,
        },
      }
    );

    await InteriorWBS.deleteMany(
      { projectId: pid, towerId: towerId, floorId: floorId },
      function (err) {
        if (err) console.log(err);
      }
    );

    for (var i = 0; i < projectWBS.wbsList.length; i++) {
      projectDuration += projectWBS.wbsList[i].duration;
    }

    const wbsData = new InteriorWBS();
    wbsData.projectId = pid;
    wbsData.createdBy = createdBy;
    wbsData.projectDuration = projectDuration;
    wbsData.captureInterval = captureInterval;
    wbsData.projectStartDate = startDate;
    wbsData.projectFinishDate = finishDate;
    wbsData.towerId = towerId;
    wbsData.floorId = floorId;

    projectWBS.wbsList.forEach((wbsObj) => {
      let wbs = {};
      wbs.wbsId = uuid.v4();
      wbs.description = wbsObj.description;
      wbs.startDate = wbsObj.startDate;
      wbs.finishDate = wbsObj.finishDate;
      wbs.category = wbsObj.category;
      wbs.classification = wbsObj.classification;
      const timeDifference = Math.abs(
        new Date(wbsObj.finishDate) - new Date(wbsObj.startDate)
      );
      const diffDuration = Math.ceil(timeDifference / (1000 * 60 * 60 * 24));
      wbs.duration = diffDuration === 0 ? 1 : diffDuration;

      wbs.weightage = (
        (diffDuration > 0 ? diffDuration : 1) / projectDuration
      ).toFixed(4);

      wbs.planned = 0;
      wbs.actual = 0;
      wbs.comment = "";

      wbsData.wbsList.push(wbs);
    });

    wbsData.save(async function (err, result) {
      if (err) {
        console.log(err);
      } else {
        req.project.isSelfServe = true;
        await req.project.save().then(async (project) => {
          await updateInternalWeightage(pid, towerId);

          res.json({
            status: "success",
          });
        });
      }
    });
  } else {
    res.sendStatus(403);
  }
});

router.post("/:projectId/wbs/ext/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    const pid = req.params.projectId;
    const createdBy = req.payload.email;
    const projectWBS = req.body.wbs.wbs;
    const startDate = projectWBS.startDate;
    const finishDate = projectWBS.finishDate;
    const captureInterval = projectWBS.captureInterval;
    const towerId = projectWBS.towerId;
    var projectDuration = 0;

    await AerialTour.updateMany(
      {
        projectId: pid,
      },
      {
        $set: {
          isSelfServe: true,
          isWBSPublished: false,
        },
      }
    );

    await ExteriorWBS.deleteMany(
      { projectId: pid, towerId: towerId },
      function (err) {
        if (err) console.log(err);
      }
    );

    for (var i = 0; i < projectWBS.wbsList.length; i++) {
      projectDuration += projectWBS.wbsList[i].duration;
    }

    const wbsData = new ExteriorWBS();
    wbsData.projectId = pid;
    wbsData.createdBy = createdBy;
    wbsData.projectDuration = projectDuration;
    wbsData.captureInterval = captureInterval;
    wbsData.towerId = towerId;
    wbsData.projectStartDate = startDate;
    wbsData.projectFinishDate = finishDate;

    projectWBS.wbsList.forEach((wbsObj) => {
      let wbs = {};
      wbs.wbsId = uuid.v4();
      wbs.description = wbsObj.description;
      wbs.startDate = wbsObj.startDate;
      wbs.finishDate = wbsObj.finishDate;

      const timeDifference = Math.abs(
        new Date(wbsObj.finishDate) - new Date(wbsObj.startDate)
      );
      const diffDuration = Math.ceil(timeDifference / (1000 * 60 * 60 * 24));
      wbs.duration = diffDuration > 0 ? diffDuration : 1;

      wbs.weightage = (
        (diffDuration > 0 ? diffDuration : 1) / projectDuration
      ).toFixed(4);

      wbs.planned = 0;
      wbs.actual = 0;
      wbs.comment = "";

      wbsData.wbsList.push(wbs);
    });

    wbsData.isActualPublished = false;
    wbsData.save(async function (err, result) {
      if (err) {
        console.log(err);
      } else {
        req.project.isSelfServe = true;
        await req.project.save().then(async (project) => {
          await updateExtWeightage(req.params.projectId);
          res.json({
            status: "success",
          });
        });
      }
    });
  } else {
    res.sendStatus(403);
  }
});

router.delete(
  "/:projectId/wbs/ext/:towerId/remove",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await ExteriorWBS.deleteMany(
              {
                projectId: req.params.projectId,
                towerId: req.params.towerId,
              },
              async function (err) {
                if (err) {
                  console.log(err);
                }
                await updateExtWeightage(req.params.projectId);
                res.json({
                  status: "success",
                });
              }
            );
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:projectId/wbs/int/:towerId/:floorId/remove",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0) {
            await InteriorWBS.deleteMany(
              {
                projectId: req.params.projectId,
                towerId: req.params.towerId,
                floorId: req.params.floorId,
              },
              async function (err) {
                if (err) {
                  console.log(err);
                }
                await updateInternalWeightage(
                  req.params.projectId,
                  req.params.towerId
                );
                res.json({
                  status: "success",
                });
              }
            );
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:projectId/wbs/ext/publish_wbs",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            req.project.isExteriorWBSPublished = true;
            await req.project
              .save()
              .then((project) => {
                res.json({ status: "success" });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:projectId/wbs/int/publish_wbs",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            req.project.isInteriorWBSPublished = true;
            await req.project
              .save()
              .then((project) => {
                res.json({ status: "success" });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:projectId/wbs/wbs_publish_status",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await Project.findOne({ projectId: req.params.projectId })
              .then((data) => {
                res.json({
                  isInteriorWBSPublished: data.isInteriorWBSPublished,
                  isExteriorWBSPublished: data.isExteriorWBSPublished,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

const updateExtWeightage = async (projectId) => {
  await ExteriorWBS.find({ projectId: projectId }).then(async (projectWBS) => {
    if (projectWBS) {
      var overAllDuration = 0;

      for (let wbsItem of projectWBS) {
        if (wbsItem) {
          overAllDuration = overAllDuration + wbsItem.projectDuration;
        }
      }

      asyncPackage.forEach(
        projectWBS,
        async function (wbsDoc, callback) {
          wbsDoc.wbsList.forEach((wbs) => {
            const weightage =
              overAllDuration > 0
                ? wbs.duration / overAllDuration
                : wbs.weightage;
            wbs.weightage = weightage.toFixed(4);
          });

          wbsDoc.save(callback);
        },
        function (err) {
          return;
        }
      );
    }
  });
};

const updateInternalWeightage = async (projectId, towerId) => {
  await InteriorWBS.find({
    projectId: projectId,
    towerId: towerId,
  }).then(async (projectWBS) => {
    if (projectWBS) {
      var overAllDuration = 0;

      for (let wbsItem of projectWBS) {
        if (wbsItem) {
          overAllDuration = overAllDuration + wbsItem.projectDuration;
        }
      }
      asyncPackage.forEach(
        projectWBS,
        async function (wbsDoc, callback) {
          wbsDoc.wbsList.forEach((wbs) => {
            const weightage =
              overAllDuration > 0
                ? wbs.duration / overAllDuration
                : wbs.weightage;
            wbs.weightage = weightage.toFixed(4);
          });

          wbsDoc.save(callback);
        },
        function (err) {
          return;
        }
      );
    }
  });
};

// return a list of all wbs activities
router.get(
  "/:project/interior/activities",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const latestTour = await InteriorTour.find({
        projectId: req.params.project,
      })
        .limit(1)
        .sort({ $natural: -1 });
      const interiorData = await InteriorCapture.aggregate([
        {
          $match: {
            projectId: req.params.project,
            interiorId: latestTour[0].interiorId,
          },
        },
        { $project: { towerId: 1, floorId: 1, wbsItem: 1, _id: 0 } },
        { $unwind: { path: "$wbsItem", preserveNullAndEmptyArrays: true } },
        {
          $project: {
            towerId: 1,
            floorId: 1,
            "wbsItem.wbsId": 1,
            "wbsItem.description": 1,
            "wbsItem.planned": 1,
            "wbsItem.actual": 1,
            "wbsItem.duration": 1,
            "wbsItem.weightage": 1,
            "wbsItem.comment": 1,
          },
        },
      ]);

      const data = await new Promise((resolve, reject) => {
        InteriorWBS.aggregate([
          { $match: { projectId: req.params.project } },
          { $project: { towerId: 1, floorId: 1, wbsList: 1, _id: 0 } },
          { $unwind: { path: "$wbsList", preserveNullAndEmptyArrays: true } },
          {
            $project: {
              towerId: 1,
              floorId: 1,
              "wbsList.wbsId": 1,
              "wbsList.description": 1,
            },
          },
        ]).exec((err, data) => {
          if (err) {
            reject(err);
          } else {
            resolve(data);
          }
        });
      });
      for (let dat of data) {
        let progressPercentage = interiorData.find(
          (item) =>
            item.towerId == dat.towerId &&
            item.floorId == dat.floorId &&
            item?.wbsItem?.wbsId == dat?.wbsList?.wbsId
        );
        dat.actualPercentage =
          progressPercentage?.wbsItem?.actual == undefined
            ? 0
            : progressPercentage?.wbsItem?.actual;
      }
      res.json({
        wbs: data,
      });
    } else {
      res.sendStatus(401);
    }
  }
);

// return a list of all wbs activities by towerid  and floorid
router.get(
  "/:project/interior/activities/:towerId/:floorId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const latestTour = await InteriorTour.find({
        projectId: req.params.project,
      })
        .limit(1)
        .sort({ $natural: -1 });
      const interiorData = [];
      if (latestTour.length > 0) {
        const captureData = await InteriorCapture.find({
          projectId: req.params.project,
          interiorId: latestTour[0].interiorId,
        });
        for (let capDat of captureData) {
          for (let wbsItem of capDat.wbsItem) {
            interiorData.push({
              towerId: capDat.towerId,
              floorId: capDat.floorId,
              wbsId: wbsItem?.wbsId,
              actual: wbsItem.actual,
            });
          }
        }
      }
      const data = await new Promise((resolve, reject) => {
        InteriorWBS.aggregate([
          {
            $match: {
              projectId: req.params.project,
              towerId: req.params.towerId,
              floorId: req.params.floorId,
            },
          },
          {
            $project: { towerId: 1, floorId: 1, unitId: 1, wbsList: 1, _id: 0 },
          },
          { $unwind: { path: "$wbsList", preserveNullAndEmptyArrays: true } },
          {
            $project: {
              towerId: 1,
              floorId: 1,
              unitId: 1,
              "wbsList.wbsId": 1,
              "wbsList.description": 1,
              "wbsList.category": 1,
            },
          },
        ]).exec((err, data) => {
          if (err) {
            reject(err);
          } else {
            resolve(data);
          }
        });
      });
      for (let dat of data) {
        let progressPercentage = interiorData.find(
          (item) =>
            item.towerId == dat.towerId &&
            item.floorId == dat.floorId &&
            item?.wbsId == dat?.wbsList?.wbsId
        );
        dat.actualPercentage =
          progressPercentage?.actual == undefined
            ? 0
            : progressPercentage?.actual;
      }
      res.json({
        wbs: data,
      });
    } else {
      res.sendStatus(401);
    }
  }
);

module.exports = router;
