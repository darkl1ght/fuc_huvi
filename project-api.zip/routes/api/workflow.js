const router = require("express").Router();
const mongoose = require("mongoose");
const MasterData = mongoose.model("MasterData");
const WorkFlow = mongoose.model("WorkFlow");
const RfiWorkFlow = mongoose.model("RfiWorkFlow");
const auth = require("../auth");
const uuid = require("uuid");
const _ = require("underscore");
const asyncPackage = require("async");
const logger = require("../../common/logger");

router.get("/:projectId/workflow/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await MasterData.findOne({
      projectId: req.params.projectId,
    })
      .then((data) => {
        res.json({
          workFlow: data.workFlow == null ? [] : data.workFlow,
          rfi: data.rfi == null ? [] : data.rfi,
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.get("/:projectId/rfi/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await MasterData.findOne({
      projectId: req.params.projectId,
    })
      .then((data) => {
        res.json({
          rfi: data.rfi == null ? [] : data.rfi,
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.post("/:projectId/workflow/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    const wf = req.body.workFlow;
    if (wf.type == "workTrade") {
      const workFlow = new WorkFlow();
      workFlow.workFlowId = uuid.v4();
      workFlow.name = wf.name;
      workFlow.projectId = req.params.projectId;
      workFlow.orderNo = wf.orderNo;
      workFlow.isActive = true;
      workFlow.createdBy = req.payload.email;
      workFlow.updatedBy = req.payload.email;
      await MasterData.findOneAndUpdate(
        {
          projectId: req.params.projectId,
        },
        {
          $push: {
            workFlow: workFlow,
          },
        },
        {
          new: true,
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else if (wf.type == "rfi") {
      const rfiWorkFlow = new RfiWorkFlow();
      rfiWorkFlow.rfiId = uuid.v4();
      rfiWorkFlow.name = wf.name;
      rfiWorkFlow.projectId = req.params.projectId;
      rfiWorkFlow.orderNo = wf.orderNo;
      rfiWorkFlow.isActive = true;
      rfiWorkFlow.createdBy = req.payload.email;
      rfiWorkFlow.updatedBy = req.payload.email;
      await MasterData.findOneAndUpdate(
        {
          projectId: req.params.projectId,
        },
        {
          $push: {
            rfi: rfiWorkFlow,
          },
        },
        {
          new: true,
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    }
  } else {
    res.sendStatus(403);
  }
});

router.delete(
  "/:project/:type/:workFlowId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.workFlowId && req.params.project && req.params.type) {
        if (req.params.type == "rfi") {
          await MasterData.findOneAndUpdate(
            {
              projectId: req.params.project,
              "rfi.rfiId": req.params.workFlowId,
            },
            {
              $pull: {
                rfi: {
                  rfiId: req.params.workFlowId,
                },
              },
            },
            {
              new: true,
            }
          )
            .then(() => {
              res.json({
                status: "success",
              });
            })
            .catch(next);
        }
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

module.exports = router;
