"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const ProjectAlbum = mongoose.model("ProjectAlbum");
const ProjectMedia = mongoose.model("ProjectMedia");
const MediaAnnotation = mongoose.model("MediaAnnotation");
const VideoProcessingQueue = mongoose.model("VideoProcessingQueue");
const auth = require("../auth");
const uuid = require("uuid");
const moment = require("moment-timezone");
const _ = require("underscore");
const Util = require("../../common/util");
const logger = require("../../common/logger");
const prepareNotificationData = require("../../common/notification");
const {
  notificationMiddleWare,
} = require("../../middlewares/notification.middleware");

const vimeoClient = require("../../config/vimeo");

// Preload project objects on routes with ':project'
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.param("album", (req, res, next, albumId) => {
  ProjectAlbum.findOne({
    albumId: albumId,
  })
    .then((album) => {
      if (!album) {
        return res.sendStatus(404);
      }
      req.album = album;
      return next();
    })
    .catch(next);
});

router.param("annotation", (req, res, next, annotationId) => {
  MediaAnnotation.findOne({
    annotationId: annotationId,
  })
    .then((annotation) => {
      if (!annotation) {
        return res.sendStatus(404);
      }
      req.annotation = annotation;
      return next();
    })
    .catch(next);
});

router.param("media", (req, res, next, mediaId) => {
  ProjectAlbum.findOne({
    media: {
      $elemMatch: {
        mediaId: mediaId,
      },
    },
  })
    .then((album) => {
      if (!album) {
        return res.sendStatus(404);
      }
      req.media = album.media.find((m) => m.mediaId === mediaId);
      return next();
    })
    .catch(next);
});

router.get("/:project/album", auth.required, async (req, res, next) => {
  await req.project
    .populate({
      path: "album",
      match: {
        isActive: true,
      },
      options: {
        sort: {
          createdAt: "desc",
        },
      },
    })
    .execPopulate()
    .then(() => {
      res.json({
        album: req.project.album,
      });
    })
    .catch(next);
});

// create a new album
router.post("/:project/album", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          const album = new ProjectAlbum(req.body.album);
          album.albumId = uuid.v4();
          album.projectId = req.project.projectId;
          album.createdBy = req.payload.email;
          album.updatedBy = req.payload.email;
          await album
            .save()
            .then(() => {
              req.project.album.push(album);
              req.project.save().then(() => {
                res.json({
                  album: album,
                });
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

router.delete(
  "/:project/album/:album",
  auth.required,
  async (req, res, next) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          await ProjectAlbum.findOneAndUpdate(
            {
              _id: req.album._id,
            },
            {
              isActive: false,
            }
          )
            .then(() => {
              res.json({
                status: "success",
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);

router.put("/:project/album/remove", auth.required, async (req, res, next) => {
  await Project.countDocuments(
    {
      users: {
        $elemMatch: {
          email: req.payload.email,
          isActive: true,
          isBlocked: false,
        },
      },
      projectId: req.project.projectId,
      isActive: true,
    },
    async (err, count) => {
      if (count > 0 || req.payload.isAdmin) {
        let ids = req.body.albumIds;
        await ProjectAlbum.updateMany(
          {
            albumId: {
              $in: ids,
            },
          },
          {
            $set: {
              isActive: false,
            },
          }
        )
          .then(() => {
            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    }
  );
});

// update album
router.put("/:project/album/:album", auth.required, async (req, res, next) => {
  if (req.payload.email && req.body.album) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          if (typeof req.body.album.albumName !== "undefined") {
            req.album.albumName = req.body.album.albumName;
          }
          if (typeof req.body.album.albumDate !== "undefined") {
            req.album.albumDate = req.body.album.albumDate;
          }

          req.album.updatedBy = req.payload.email;
          await req.album
            .save()
            .then((album) => {
              res.json({
                album: album,
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

// add media
router.post("/:project/album/media", auth.required, async (req, res, next) => {
  let album;
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          const media = new ProjectMedia(req.body.media);
          media.meta.updatedBy =
            req.payload.firstName + " " + req.payload.lastName;
          media.meta.updatedByEmail = req.payload.email;
          media.meta.updatedAt = moment
            .utc()
            .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");

          if (!req.body.media.albumId) {
            album = await ProjectAlbum.findOneAndUpdate(
              {
                albumName: "Un-mapped",
                projectId: req.project.projectId,
              },
              {
                $setOnInsert: {
                  albumId: uuid.v4(),
                  projectId: req.project.projectId,
                  albumDate: moment().toISOString(),
                  albumName: "Un-mapped",
                  isActive: true,
                  createdBy: req.payload.email,
                },
              },
              {
                new: true,
                upsert: true,
              },
              async (err, host) => {
                if (err) {
                  res.json(err);
                } else {
                  req.project.album.push(host);
                  await req.project.save().then(() => {
                    media.albumId = host.albumId;
                  });
                }
              }
            );
          } else {
            album = await ProjectAlbum.findOne({
              albumId: req.body.media.albumId,
            }).exec();
          }

          media.projectId = req.project.projectId;
          media.createdBy = req.payload.email;
          media.updatedBy = req.payload.email;

          if (media.mediaType.code === "MT10002") {
            media.isPublished = false;
          } else {
            media.isPublished = true;
          }
          // media.meta && media.meta.fileSize > 100000000 ? false : true;
          album.media.push(media);
          album.isActive = true;

          await album
            .save()
            .then(async () => {
              if (!media.isPublished) {
                const queue = new VideoProcessingQueue();
                queue.mediaId = media.mediaId;
                queue.albumId = media.albumId;
                queue.projectId = media.projectId;
                queue.blobContentId = media.blobContentId;
                queue.status = "new";
                queue.meta = media.meta;

                await queue.save().then(() => {});
              }

              res.json({
                status: "success",
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

// get a album's media list
router.get("/:project/album/:album", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          ProjectAlbum.findOne({
            albumId: req.params.album,
          })
            .then((album) => {
              if (!album) {
                return res.sendStatus(404);
              }
              res.json({
                album: album,
                media: album.media,
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});
// delete media
router.delete(
  "/:project/album/:album/media/:media",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await ProjectAlbum.findOneAndUpdate(
        {
          albumId: req.album.albumId,
        },
        {
          $pull: {
            media: {
              mediaId: req.media.mediaId,
            },
          },
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// delete media bulk
router.put(
  "/:project/album/:album/media/bulkdelete",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await ProjectAlbum.findOneAndUpdate(
        {
          albumId: req.album.albumId,
        },
        {
          $pull: {
            media: {
              mediaId: {
                $in: req.body.mediaIds,
              },
            },
          },
        },
        {
          new: true,
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// add comment annotation
router.post(
  "/:project/media/:media/comment",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.body.comment) {
        const extractEmails = (text) => {
          return text.match(
            /[A-Z0-9._%+-]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,8}[A-Z]{2,63}/gi
          );
        };
        const emails = extractEmails(req.body.comment);
        const mailTo = [];
        if (emails)
          for (let email of emails) {
            const user = req.project.users.filter((projectUser) => {
              return projectUser.email.toLowerCase() === email.toLowerCase();
            });
            if (user.length > 0)
              mailTo.push({
                email: user[0].email,
                firstName: user[0].firstName,
                name: `${user[0].firstName} ${user[0].lastName}`,
              });
          }

        const comment = {};
        comment.commentId = uuid.v4();
        comment.mediaId = req.media.mediaId;
        comment.body = req.body.comment;
        comment.createdAt = moment.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
        comment.createdByName =
          req.payload.firstName + " " + req.payload.lastName;
        comment.createdByEmail = req.payload.email;

        await ProjectAlbum.findOneAndUpdate(
          {
            projectId: req.project.projectId,
            "media.mediaId": req.media.mediaId,
          },
          {
            $push: {
              "media.$.comments": comment,
            },
          },
          {
            new: true,
          }
        )
          .then(async () => {
            if (mailTo && mailTo.length > 0) {
              const [mailSentError, mailSentStatus] =
                await Util.sendMediaTagEmail(
                  mailTo,
                  req.project.projectName,
                  req.body.comment
                );
              if (mailSentError) {
                logger.error(
                  "Error while sending mail in Media Tag :" + mailSentError
                );
              }
            }

            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

// remove comments
router.put(
  "/:project/media/:media/removecomment",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.body.commentId) {
        await ProjectAlbum.findOneAndUpdate(
          {
            projectId: req.project.projectId,
            "media.mediaId": req.media.mediaId,
          },
          {
            $pull: {
              "media.$.comments": {
                commentId: req.body.commentId,
              },
            },
          },
          {
            new: true,
          }
        )
          .then(() => {
            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/media/:media/comments",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      res.json({
        comments: req.media.comments,
      });
    } else {
      res.sendStatus(403);
    }
  }
);

// update media
router.put(
  "/:project/media/:album/update",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.detail) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (req.body.detail.targetAlbum) {
              await ProjectAlbum.findOne({
                albumId: req.body.detail.targetAlbum,
              }).then(async (album) => {
                if (
                  album &&
                  req.album.albumId !== req.body.detail.targetAlbum
                ) {
                  req.body.detail.mediaIds.forEach((mediaId) => {
                    let media = req.album.media.find(
                      (m) => m.mediaId === mediaId
                    );
                    media.tags = req.body.detail.tags
                      ? req.body.detail.tags
                      : media.tags;
                    media.mediaDescription = req.body.detail.mediaDescription
                      ? req.body.detail.mediaDescription
                      : media.mediaDescription;
                    album.media.push(media);
                  });
                  await album
                    .save()
                    .then(async () => {
                      await ProjectAlbum.findOneAndUpdate(
                        {
                          albumId: req.album.albumId,
                        },
                        {
                          $pull: {
                            media: {
                              mediaId: {
                                $in: req.body.detail.mediaIds,
                              },
                            },
                          },
                        },
                        {
                          new: true,
                        }
                      )
                        .then(() => {
                          res.json({
                            status: "success",
                          });
                        })
                        .catch(next);
                    })
                    .catch(next);
                } else {
                  res.json({
                    status: "success",
                  });
                }
              });
            } else {
              let update = {};
              if (req.body.detail.tags)
                update["media.tags"] = req.body.detail.tags;
              if (req.body.detail.mediaDescription)
                update["media.mediaDescription"] =
                  req.body.detail.mediaDescription;

              await ProjectAlbum.findOne(
                { albumId: req.params.album },
                (err, album) => {
                  let mediaList = req.body.detail.mediaIds;
                  mediaList.forEach((m) => {
                    let media = album.media.find((x) => x.mediaId == m);
                    media.tags = req.body.detail.tags;
                    media.mediaDescription = req.body.detail.mediaDescription;
                  });
                  album.markModified("media");
                  album.save((err) => {
                    if (err)
                      res.json({
                        status: "error",
                      });
                    else
                      res.json({
                        status: "success",
                      });
                  });
                }
              );
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/media/:media/annotation",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const annotation = new MediaAnnotation(req.body.annotation);

      if (!req.body.annotation.annotationId) {
        annotation.annotationId = annotation.shape.guid;
      }
      annotation.mediaId = req.media.mediaId;
      annotation.createdBy = req.payload.email;
      annotation.updatedBy = req.payload.email;

      await ProjectAlbum.findOneAndUpdate(
        {
          projectId: req.project.projectId,
          "media.mediaId": req.media.mediaId,
        },
        {
          $push: {
            "media.$.annotations": annotation,
          },
          $set: {
            "media.$.features": req.body.features,
          },
        },
        {
          new: true,
        }
      )
        .then(() => {
          res.json({
            annotationId: annotation.shape.guid,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/media/:media/annotation",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      res.json({
        media: req.media,
      });
    } else {
      res.sendStatus(403);
    }
  }
);

// delete annotation
router.put(
  "/:project/media/:media/annotations/remove",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await ProjectAlbum.findOneAndUpdate(
        {
          projectId: req.project.projectId,
          "media.mediaId": req.media.mediaId,
        },
        {
          $pull: {
            "media.$.annotations": {
              annotationId: req.body.annotationId,
            },
          },
        },
        {
          new: true,
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// update annotation
router.put(
  "/:project/media/:media/annotations",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.annotation) {
      const annotation = req.media.annotations.find(
        (x) => x.annotationId === req.body.annotation.annotationId
      );

      await ProjectAlbum.findOneAndUpdate(
        {
          projectId: req.params.project,
          "media.annotations.annotationId": req.body.annotation.annotationId,
        },
        {
          $set: {
            "media.$[outer].annotations.$[inner].annotationTitle":
              typeof req.body.annotation.annotationTitle !== "undefined"
                ? req.body.annotation.annotationTitle
                : annotation.annotationTitle,
            "media.$[outer].annotations.$[inner].description":
              typeof req.body.annotation.description !== "undefined"
                ? req.body.annotation.description
                : annotation.description,
            "media.$[outer].annotations.$[inner].tags":
              typeof req.body.annotation.tags !== "undefined"
                ? req.body.annotation.tags
                : annotation.tags,
            "media.$[outer].annotations.$[inner].shape":
              typeof req.body.annotation.shape !== "undefined"
                ? req.body.annotation.shape
                : annotation.shape,
          },
        },
        {
          arrayFilters: [
            {
              "outer.mediaId": req.params.media,
            },
            {
              "inner.annotationId": req.body.annotation.annotationId,
            },
          ],
        }
      )
        .then(() => {
          res.json({
            annotationId: annotation.annotationId,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// update layers
router.put(
  "/:project/media/:media/features",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.feature) {
      await ProjectAlbum.findOneAndUpdate(
        {
          projectId: req.project.projectId,
          "media.mediaId": req.media.mediaId,
        },
        {
          $set: {
            "media.$.features": req.body.features,
          },
        },
        {
          new: true,
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/album/notify",
  auth.required,
  async (req, res, next) => {
    try {
      const { albumId } = req.body;
      let query;

      if (!albumId)
        query = {
          projectId: req.project.projectId,
          albumName: "Un-mapped",
        };
      else query = { albumId };

      let { albumName, albumId: updatedAlbumId } = await ProjectAlbum.findOne(
        query,
        {
          albumName: 1,
          albumId: 1,
          _id: 0,
        }
      );

      res.json({ status: "success" });

      let data = {
        messageType: "NT0007",
        appType: "APP002",
        ...req.project.toObject(),
        albumName,
        metaData: {
          actionType: "Media_uploaded",
          projectId: req.project.projectId,
          projectName: req.project.projectName,
          albumId: updatedAlbumId,
          albumName,
        },
      };

      req.notificationData = await prepareNotificationData(data);

      next();
    } catch (error) {
      next(error);
    }
  },
  notificationMiddleWare
);

// Get the vimeoId video details
router.get("/vimeo/:vimeoId", auth.required, async (req, res, next) => {
  try {
    const { vimeoId } = req.params;

    vimeoClient.request(
      {
        method: "GET",
        path: `/videos/${vimeoId}`,
      },
      function (error, body, status_code, headers) {
        if (error) {
          logger.error("Error in fetching vimeo video details", error);
        }

        res.json({ data: body.play.progressive });
      }
    );
  } catch (error) {
    next(error);
  }
});
module.exports = router;
