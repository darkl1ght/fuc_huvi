"use strict";
const router = require("express").Router();
const mongoose = require("mongoose");
const AppMessage = mongoose.model("AppMessage");

const auth = require("../auth");
const uuid = require("uuid");

router.get("/fetch", auth.required, async (req, res, next) => {
  try {
    await AppMessage.find({
      isActive: true,
    })
      .then((messages) => {
        res.json({
          appMessages: messages,
        });
      })
      .catch(next);
  } catch (error) {
    next(error);
  }
});
// Add App messages
router.post("/", auth.required, async (req, res, next) => {
  try {
    const reqBody = req.body;
    const appMessage = new AppMessage();
    appMessage.messageId = uuid.v4();
    appMessage.messageTitle = reqBody.messageTitle;
    appMessage.messageContent = reqBody.messageContent;
    appMessage.sortOrder = reqBody.sortOrder;
    appMessage.isActive = true;
    await appMessage
      .save()
      .then(
        res.json({
          status: "success",
        })
      )
      .catch(next);
  } catch (error) {
    next(error);
  }
});

//edit messages
router.put("/:messageId", auth.required, async (req, res, next) => {
  try {
    const reqBody = req.body;
    await AppMessage.findOneAndUpdate(
      {
        messageId: req.params.messageId,
        isActive: true,
      },
      {
        $set: {
          messageTitle: reqBody.messageTitle,
          messageContent: reqBody.messageContent,
          sortOrder: reqBody.sortOrder,
        },
      }
    )
      .then(() => {
        res.json({
          status: "success",
        });
      })
      .catch(next);
  } catch (error) {
    next(error);
  }
});

//soft delete
router.delete("/:messageId", auth.required, async (req, res, next) => {
  try {
    const { messageId } = req.params;

    if (!!messageId) {
      await AppMessage.findOneAndUpdate(
        {
          messageId: messageId,
        },
        {
          $set: {
            isActive: false,
          },
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    }
  } catch (error) {
    next(error);
  }
});

module.exports = router;
