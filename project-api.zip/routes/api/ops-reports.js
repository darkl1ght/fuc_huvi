"use strict";
const router = require("express").Router();
const mongoose = require("mongoose");
const AerialTours = mongoose.model("AerialTour");
const VirtualTours = mongoose.model("InteriorTour");
const Projects = mongoose.model("Project");
const Clients = mongoose.model("Client");
const FieldIssues = mongoose.model("FieldIssue");
const RFIS = mongoose.model("Rfi");
const ProjectTasks = mongoose.model("ProjectTask");
const moment = require("moment-timezone");
const auth = require("../auth");

router.post("/fetchaerialcaptures/", auth.required, async (req, res, next) => {
  const projectIds = req.body.projectIds; // project ids selected by users will be passed from the front end and will be in comma seperated strings in the array
  const startDate = moment(req.body.startDate);
  const endDate = moment(req.body.endDate).add(
    86399999 //a day minus 1ms
  );

  const conditions = {
    projectId: { $in: projectIds },
    "status.code": "AT10003", //Ready for visualization
    "Aerial_Project.isActive": true,
    isActive: true,
  };

  await AerialTours.aggregate([
    {
      $lookup: {
        from: "projects",
        localField: "projectId",
        foreignField: "projectId",
        as: "Aerial_Project",
      },
    },
    {
      $unwind: "$Aerial_Project",
    },
    {
      $match: conditions,
    },
    {
      $project: {
        projectName: "$Aerial_Project.projectName",
        projectId: 1,
        tourDate: 1,
      },
    },
  ]).exec((err, data) => {
    if (err) {
      next(err);
    }
    try {
      data = data.filter((el) => {
        el.tourDate = moment(el.tourDate);
        const tourDate = el.tourDate;
        el.week = tourDate.format("yy") + "-Week-" + tourDate.week();
        el.month = tourDate.format("yy") + "-" + tourDate.format("MMM");
        el.quarter = tourDate.format("yy") + "-Q" + tourDate.quarter();

        return el.tourDate >= startDate && el.tourDate <= endDate;
      });

      data.sort((a, b) => a.tourDate - b.tourDate);

      const projectWise = groupAndCountByProperty(data, "projectName");
      const weekWise = groupAndCountByProperty(data, "week");
      const monthWise = groupAndCountByProperty(data, "month");
      const quarterWise = groupAndCountByProperty(data, "quarter");

      res.json({
        data: {
          project: {
            labels: Object.keys(projectWise),
            values: Object.values(projectWise),
          },
          week: {
            labels: Object.keys(weekWise),
            values: Object.values(weekWise),
          },
          month: {
            labels: Object.keys(monthWise),
            values: Object.values(monthWise),
          },
          quarter: {
            labels: Object.keys(quarterWise),
            values: Object.values(quarterWise),
          },
        },
      });
    } catch (e) {
      next(e);
    }
  });
});

router.post("/fetchvirtualcaptures/", auth.required, async (req, res, next) => {
  const projectIds = req.body.projectIds;
  const startDate = moment(req.body.startDate);
  const endDate = moment(req.body.endDate).add(
    86399999 //a day minus 1ms
  );

  const conditions = {
    projectId: { $in: projectIds },
    "status.code": "VW10003", //Ready for visualization
    "Virtual_Project.isActive": true, //Project is active
    isActive: true, //Tour is active
  };

  await VirtualTours.aggregate([
    {
      $lookup: {
        from: "projects",
        localField: "projectId",
        foreignField: "projectId",
        as: "Virtual_Project",
      },
    },
    {
      $unwind: "$Virtual_Project",
    },
    {
      $match: conditions,
    },

    {
      $project: {
        projectName: "$Virtual_Project.projectName",
        projectId: 1,
        interiorDate: 1,
      },
    },
  ]).exec((err, data) => {
    if (err) {
      next(err);
    }
    try {
      data = data.filter((el) => {
        el.interiorDate = moment(el.interiorDate); //convert to moment date
        return el.interiorDate >= startDate && el.interiorDate <= endDate;
      });

      data.sort((a, b) => a.interiorDate - b.interiorDate);

      for (const element of data) {
        const tourDate = element.interiorDate;
        element.week = tourDate.format("yy") + "-Week-" + tourDate.week();
        element.month = tourDate.format("yy") + "-" + tourDate.format("MMM");
        element.quarter = tourDate.format("yy") + "-Q" + tourDate.quarter();
      }

      const projectWise = groupAndCountByProperty(data, "projectName");
      const weekWise = groupAndCountByProperty(data, "week");
      const monthWise = groupAndCountByProperty(data, "month");
      const quarterWise = groupAndCountByProperty(data, "quarter");

      res.json({
        data: {
          project: {
            labels: Object.keys(projectWise),
            values: Object.values(projectWise),
          },
          week: {
            labels: Object.keys(weekWise),
            values: Object.values(weekWise),
          },
          month: {
            labels: Object.keys(monthWise),
            values: Object.values(monthWise),
          },
          quarter: {
            labels: Object.keys(quarterWise),
            values: Object.values(quarterWise),
          },
        },
      });
    } catch (e) {
      next(e);
    }
  });
});

router.post("/fetchcapturemetrics/", auth.required, async (req, res, next) => {
  const projectIds = req.body.projectIds;
  const startDate = moment(req.body.startDate);
  const endDate = moment(req.body.endDate).add(
    86399999 //a day minus 1ms
  );

  let finalCollatedData = [];

  const aerialConditions = {
    projectId: { $in: projectIds },
    "status.code": "AT10003", //Ready for visualization
    "Aerial_Project.isActive": true,
    isActive: true,
  };

  await AerialTours.aggregate([
    {
      $lookup: {
        from: "projects",
        localField: "projectId",
        foreignField: "projectId",
        as: "Aerial_Project",
      },
    },
    {
      $unwind: "$Aerial_Project",
    },
    {
      $match: aerialConditions,
    },
    {
      $project: {
        projectName: "$Aerial_Project.projectName",
        tourName: 1,
        images: 1,
        tourDate: 1,
        _id: 0,
      },
    },
  ]).exec(async (err, aerialData) => {
    if (err) {
      next(err);
    }
    try {
      aerialData = aerialData.filter((el) => {
        el.tourDate = moment(el.tourDate);
        return (
          el.tourDate >= startDate &&
          el.tourDate <= endDate &&
          el.images.length > 0
        );
      });

      aerialData.sort((a, b) => a.tourDate - b.tourDate);

      for (const element of aerialData) {
        element.type = "Aerial Maps";
        element.imagecount = element.images.length;
      }

      finalCollatedData = aerialData.slice(); //copy aerial data to finalData array
      const virtualConditions = {
        projectId: { $in: projectIds },
        "status.code": "VW10003", //Ready for visualization
        "Virtual_Project.isActive": true, //Project is active
        isActive: true, //Tour is active
        "Tour_Join.isActive": true,
        "Tour_Join.isPublished": true, //get only published tours
      };

      await VirtualTours.aggregate([
        {
          $lookup: {
            from: "projects",
            localField: "projectId",
            foreignField: "projectId",
            as: "Virtual_Project",
          },
        },

        {
          $unwind: "$Virtual_Project",
        },
        {
          $unwind: "$floorWalkthough",
        },
        {
          $unwind: "$floorWalkthough.tours",
        },
        {
          $lookup: {
            from: "tourimages",
            localField: "floorWalkthough.tours",
            foreignField: "_id",
            as: "Tour_Join",
          },
        },
        {
          $unwind: "$Tour_Join",
        },
        {
          $unwind: "$Tour_Join.features",
        },

        {
          $match: virtualConditions,
        },
        {
          $project: {
            projectName: "$Virtual_Project.projectName",
            tourName: "$interiorName",
            towerName: "$floorWalkthough.towerName",
            floorName: "$Tour_Join.tourName",
            images: "$Tour_Join.features.features",
            interiorDate: 1,
            _id: 0,
          },
        },
      ]).exec((err, virtualdata) => {
        if (err) {
          next(err);
        }
        try {
          virtualdata = virtualdata.filter((el) => {
            el.interiorDate = moment(el.interiorDate);
            return (
              el.interiorDate >= startDate &&
              el.interiorDate <= endDate &&
              el.images.length > 0
            );
          });

          virtualdata.sort((a, b) => a.interiorDate - b.interiorDate);

          for (const element of virtualdata) {
            element.type = "Virtual Tours";
            element.imagecount = element.images.length;
            element.tourDate = element.interiorDate;
            delete element.interiorDate;
          }

          finalCollatedData = [...finalCollatedData, ...virtualdata]; //append virtual data

          const propertyToRemove = "images";
          finalCollatedData.forEach((obj) => {
            if (obj.hasOwnProperty(propertyToRemove)) {
              delete obj[propertyToRemove];
            }
          });
          finalCollatedData.sort((a, b) => {
            if (a.projectName !== b.projectName) {
              return a.projectName.localeCompare(b.projectName); // Sort by projectName in ascending order
            } else {
              return a.type - b.type; // Sort by type in descending order
            }
          });
          res.json({
            data: finalCollatedData,
          });
        } catch (e) {
          next(e);
        }
      });
    } catch (e) {
      next(e);
    }
  });
});

router.post("/fetchfieldissues/", auth.required, async (req, res, next) => {
  const projectIds = req.body.projectIds;
  const startDate = moment(req.body.startDate);
  const endDate = moment(req.body.endDate).add(
    86399999 //a day minus 1ms
  );

  const conditions = {
    projectId: { $in: projectIds },
    "Field_Project.isActive": true,
  };

  await FieldIssues.aggregate([
    {
      $lookup: {
        from: "projects",
        localField: "projectId",
        foreignField: "projectId",
        as: "Field_Project",
      },
    },
    {
      $unwind: "$Field_Project",
    },
    {
      $lookup: {
        from: "lookups",
        localField: "status",
        foreignField: "key",
        as: "Field_Lookup",
      },
    },
    {
      $unwind: "$Field_Lookup",
    },
    {
      $match: conditions,
    },
    {
      $project: {
        statusName: "$Field_Lookup.value",
        projectName: "$Field_Project.projectName",
        createdAt: 1,
      },
    },
  ]).exec((err, data) => {
    if (err) {
      next(err);
    }
    try {
      data = data.filter((el) => {
        el.createdAt = moment(el.createdAt);
        el.week = el.createdAt.format("yy") + "-Week-" + el.createdAt.week();
        return el.createdAt >= startDate && el.createdAt <= endDate;
      });

      data.sort((a, b) => a.createdAt - b.createdAt);

      // Grouping and counting by projectName and statusName column
      const groupedDataProjectWise = data.reduce((acc, item) => {
        const key = `${item.projectName}~${item.statusName}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});

      // Convert groupedData back to an array of [projectName,statusName,count] objects
      const resultProjectWise = Object.keys(groupedDataProjectWise).map(
        (key) => {
          const [projectName, statusName] = key.split("~");
          return {
            projectName,
            statusName,
            count: groupedDataProjectWise[key],
          };
        }
      );

      // Grouping and counting by week and statusName column
      const groupedDataWeekWise = data.reduce((acc, item) => {
        const key = `${item.week}~${item.statusName}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});

      // Convert groupedData back to an array of [week,statusName,count] objects
      const resultWeekWise = Object.keys(groupedDataWeekWise).map((key) => {
        const [week, statusName] = key.split("~");
        return { week, statusName, count: groupedDataWeekWise[key] };
      });

      let projectWiseLabels = [];
      let openProjectValues = [];
      let verifiedProjectValues = [];
      let archivedProjectValues = [];
      let resolvedProjectValues = [];

      resultProjectWise.forEach((element) => {
        projectWiseLabels.push(element["projectName"]);
      });

      let uniqueProjectWiseLabels = [...new Set(projectWiseLabels)];

      let projectStatusArgs = {
        openProjectValues,
        verifiedProjectValues,
        archivedProjectValues,
        resolvedProjectValues,
      };

      setGroupCalculatedValues(
        "FieldIssues",
        "Project",
        uniqueProjectWiseLabels,
        projectStatusArgs,
        resultProjectWise
      );

      let weekWiseLabels = [];
      let openWeeklyValues = [];
      let verifiedWeeklyValues = [];
      let archivedWeeklyValues = [];
      let resolvedWeeklyValues = [];

      resultWeekWise.forEach((element) => {
        weekWiseLabels.push(element["week"]);
      });

      let uniqueWeekWiseLabels = [...new Set(weekWiseLabels)]; //get distinct labels

      let weekStatusArgs = {
        openWeeklyValues,
        verifiedWeeklyValues,
        archivedWeeklyValues,
        resolvedWeeklyValues,
      };

      setGroupCalculatedValues(
        "FieldIssues",
        "Week",
        uniqueWeekWiseLabels,
        weekStatusArgs,
        resultWeekWise
      );

      res.json({
        data: {
          project: {
            labels: uniqueProjectWiseLabels,
            open: openProjectValues,
            verified: verifiedProjectValues,
            archived: archivedProjectValues,
            resolved: resolvedProjectValues,
          },
          week: {
            labels: uniqueWeekWiseLabels,
            open: openWeeklyValues,
            verified: verifiedWeeklyValues,
            archived: archivedWeeklyValues,
            resolved: resolvedWeeklyValues,
          },
        },
      });
    } catch (e) {
      next(e);
    }
  });
});

router.post("/fetchwirs/", auth.required, async (req, res, next) => {
  const projectIds = req.body.projectIds;
  const startDate = moment(req.body.startDate);
  const endDate = moment(req.body.endDate).add(
    86399999 //a day minus 1ms
  );

  let conditions = {
    projectId: { $in: projectIds },
    "RFI_Project.isActive": true,
    isActive: true,
  };

  await RFIS.aggregate([
    {
      $lookup: {
        from: "projects",
        localField: "projectId",
        foreignField: "projectId",
        as: "RFI_Project",
      },
    },

    {
      $unwind: "$RFI_Project",
    },

    {
      $match: conditions,
    },
    {
      $project: {
        statusName: "$status.value",
        projectName: "$RFI_Project.projectName",
        createdAt: 1,
      },
    },
  ]).exec((err, data) => {
    if (err) {
      next(err);
    }
    try {
      data = data.filter((el) => {
        el.createdAt = moment(el.createdAt);
        return el.createdAt >= startDate && el.createdAt <= endDate;
      });

      data.sort((a, b) => a.createdAt - b.createdAt);

      for (const element of data) {
        const createdAt = element.createdAt;
        element.week = createdAt.format("yy") + "-Week-" + createdAt.week();
      }

      // Grouping and counting by two columns
      const groupedDataProjectWise = data.reduce((acc, item) => {
        const key = `${item.projectName}~${item.statusName}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});

      // Convert groupedData back to an array of [projectName,statusName,count] objects
      const resultProjectWise = Object.keys(groupedDataProjectWise).map(
        (key) => {
          const [projectName, statusName] = key.split("~");
          return {
            projectName,
            statusName,
            count: groupedDataProjectWise[key],
          };
        }
      );

      // Grouping and counting by week and status columns
      const groupedDataWeekWise = data.reduce((acc, item) => {
        const key = `${item.week}~${item.statusName}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});

      let projectWiseLabels = [];
      let newProjectValues = [];
      let pendingProjectValues = [];
      let approvedProjectValues = [];

      resultProjectWise.forEach((element) => {
        projectWiseLabels.push(element["projectName"]);
      });

      let uniqueProjectWiseLabels = [...new Set(projectWiseLabels)];

      let projectWiseArgs = {
        newProjectValues,
        pendingProjectValues,
        approvedProjectValues,
      };

      setGroupCalculatedValues(
        "WIR",
        "Project",
        uniqueProjectWiseLabels,
        projectWiseArgs,
        resultProjectWise
      );

      // Convert groupedData back to an array of [week,statusName,count] objects
      const resultWeekWise = Object.keys(groupedDataWeekWise).map((key) => {
        const [week, statusName] = key.split("~");
        return { week, statusName, count: groupedDataWeekWise[key] };
      });

      let weekWiseLabels = [];
      let newWeeklyValues = [];
      let pendingWeeklyValues = [];
      let approvedWeeklyValues = [];

      resultWeekWise.forEach((element) => {
        weekWiseLabels.push(element["week"]);
      });

      let uniqueWeekWiseLabels = [...new Set(weekWiseLabels)]; //get distinct labels

      let weekWiseArgs = {
        newWeeklyValues,
        pendingWeeklyValues,
        approvedWeeklyValues,
      };

      setGroupCalculatedValues(
        "WIR",
        "Week",
        uniqueWeekWiseLabels,
        weekWiseArgs,
        resultWeekWise
      );

      res.json({
        data: {
          project: {
            labels: uniqueProjectWiseLabels,
            new: newProjectValues,
            pending: pendingProjectValues,
            approved: approvedProjectValues,
          },
          week: {
            labels: uniqueWeekWiseLabels,
            new: newWeeklyValues,
            pending: pendingWeeklyValues,
            approved: approvedWeeklyValues,
          },
        },
      });
    } catch (e) {
      next(e);
    }
  });
});

router.post("/fetchpunchlists/", auth.required, async (req, res, next) => {
  const projectIds = req.body.projectIds;
  const startDate = moment(req.body.startDate);
  const endDate = moment(req.body.endDate).add(
    86399999 //a day minus 1ms
  );

  const conditions = {
    projectId: { $in: projectIds },
    "Punchlist_Project.isActive": true,
    isActive: true,
  };

  await ProjectTasks.aggregate([
    {
      $lookup: {
        from: "projects",
        localField: "projectId",
        foreignField: "projectId",
        as: "Punchlist_Project",
      },
    },
    {
      $unwind: "$Punchlist_Project",
    },
    {
      $match: conditions,
    },
    {
      $project: {
        statusName: "$taskStatus.desc",
        projectName: "$Punchlist_Project.projectName",
        createdAt: 1,
      },
    },
  ]).exec((err, data) => {
    if (err) {
      next(err);
    }
    try {
      data = data.filter((el) => {
        el.createdAt = moment(el.createdAt);
        return el.createdAt >= startDate && el.createdAt <= endDate;
      });

      data.sort((a, b) => a.createdAt - b.createdAt);

      for (const element of data) {
        let createdAt = moment(element.createdAt);
        element.week = createdAt.format("yy") + "-Week-" + createdAt.week();
      }

      // Grouping and counting by two projectName and statusName
      const groupedDataProjectWise = data.reduce((acc, item) => {
        const key = `${item.projectName}~${item.statusName}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});

      // Convert groupedData back to an array of [projectName,statusName,count]objects
      const resultProjectWise = Object.keys(groupedDataProjectWise).map(
        (key) => {
          const [projectName, statusName] = key.split("~");
          return {
            projectName,
            statusName,
            count: groupedDataProjectWise[key],
          };
        }
      );

      // Grouping and counting by week and statusName columns
      const groupedDataWeekWise = data.reduce((acc, item) => {
        const key = `${item.week}~${item.statusName}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});

      let projectWiseLabels = [];
      let pendingVerificationProjectValues = [];
      let acceptedProjectValues = [];
      let notAcceptedProjectValues = [];
      let conditionallyAcceptedProjectValues = [];

      resultProjectWise.forEach((element) => {
        projectWiseLabels.push(element["projectName"]);
      });

      let uniqueProjectWiseLabels = [...new Set(projectWiseLabels)];

      let projectArgs = {
        pendingVerificationProjectValues,
        acceptedProjectValues,
        notAcceptedProjectValues,
        conditionallyAcceptedProjectValues,
      };

      setGroupCalculatedValues(
        "PunchList",
        "Project",
        uniqueProjectWiseLabels,
        projectArgs,
        resultProjectWise
      );

      // Convert groupedData back to an array of objects
      const resultWeekWise = Object.keys(groupedDataWeekWise).map((key) => {
        const [week, statusName] = key.split("~");
        return { week, statusName, count: groupedDataWeekWise[key] };
      });

      let weekWiseLabels = [];
      let pendingVerificationWeeklyValues = [];
      let acceptedWeeklyValues = [];
      let notacceptedWeeklyValues = [];
      let conditionallyAcceptedWeeklyValues = [];

      resultWeekWise.forEach((element) => {
        weekWiseLabels.push(element["week"]);
      });

      let uniqueWeekWiseLabels = [...new Set(weekWiseLabels)]; //get distinct labels

      let weekArgs = {
        pendingVerificationWeeklyValues,
        acceptedWeeklyValues,
        notacceptedWeeklyValues,
        conditionallyAcceptedWeeklyValues,
      };

      setGroupCalculatedValues(
        "PunchList",
        "Week",
        uniqueWeekWiseLabels,
        weekArgs,
        resultWeekWise
      );

      res.json({
        data: {
          project: {
            labels: uniqueProjectWiseLabels,
            pending: pendingVerificationProjectValues,
            accepted: acceptedProjectValues,
            notAccepted: notAcceptedProjectValues,
            conditionallyAccepted: conditionallyAcceptedProjectValues,
          },
          week: {
            labels: uniqueWeekWiseLabels,
            pending: pendingVerificationWeeklyValues,
            accepted: acceptedWeeklyValues,
            notAccepted: notacceptedWeeklyValues,
            conditionallyAccepted: conditionallyAcceptedWeeklyValues,
          },
        },
      });
    } catch (e) {
      next(e);
    }
  });
});

router.post("/fetchcontractdates/", auth.required, async (req, res, next) => {
  const clientIds = req.body.clientIds;
  const startDate = moment(req.body.startDate);
  const endDate = moment(req.body.endDate).add(
    86399999 //a day minus 1ms
  );

  const conditions = {
    clientId: { $in: clientIds },
    isActive: true,
    contractEndDate: { $exists: true },
    "Project_Client.isActive": true,
    //append the below condition only if the user is not a super admin
    ...(!req.payload.isAdmin && {
      "users.email": req.payload.email, //loggedin user email id
      "users.isBlocked": false,
      "users.isActive": true,
    }),
  };

  await Projects.aggregate([
    {
      $lookup: {
        from: "clients",
        localField: "clientId",
        foreignField: "clientId",
        as: "Project_Client",
      },
    },
    {
      $match: conditions,
    },
    {
      $unwind: "$Project_Client",
    },
    {
      $project: {
        clientName: "$Project_Client.clientName",
        projectName: 1,
        contractEndDate: 1,
        isCompleted: 1,
        _id: 0,
      },
    },
  ]).exec((err, data) => {
    if (err) {
      next(err);
    }

    try {
      data = data.filter((el) => {
        return el.contractEndDate >= startDate && el.contractEndDate <= endDate;
      });

      for (let el of data) {
        el.status = "Active";
        if (el.isCompleted) {
          el.status = "Completed";
        }
      }
      res.json(data);
    } catch (e) {
      next(e);
    }
  });
});

router.get("/getclientsbyuser/", auth.required, async (req, res, next) => {
  if (!req.payload.isAdmin) {
    //if user is not admin, get only clients for which the user has projects assigned as a team member and is active
    await Projects.aggregate([
      {
        $lookup: {
          from: "clients",
          localField: "clientId",
          foreignField: "clientId",
          as: "Client_Project",
        },
      },
      {
        $unwind: "$users",
      },
      {
        $unwind: "$Client_Project",
      },
      {
        $match: {
          "users.email": req.payload.email, //loggedin user email id
          "Client_Project.isActive": true,
          isActive: true,
          "users.isBlocked": false,
          "users.isActive": true,
        },
      },
      {
        $sort: { "Client_Project.clientName": 1 },
      },
      {
        $project: {
          clientName: "$Client_Project.clientName",
          clientId: 1,
          _id: 0,
        },
      },
    ]).exec((err, data) => {
      if (err) {
        next(err);
      }
      try {
        data = Array.from(new Set(data.map(JSON.stringify))) //Remove duplicates of array of objects
          .map(JSON.parse);
        res.json(data);
      } catch (e) {
        next(e);
      }
    });
  } else {
    //For Super admins get all the clients
    Clients.find({ isActive: true })
      .select({ clientId: 1, clientName: 1, _id: 0 })
      .sort("clientName")
      .exec((err, data) => {
        if (err) {
          next(err);
        } else {
          res.json(data);
        }
      });
  }
});

router.get("/getprojectsbyuser/", auth.required, async (req, res, next) => {
  if (!req.payload.isAdmin) {
    //if user is not admin, get only clients for which the user has projects assigned as a team member and is active
    await Projects.aggregate([
      {
        $lookup: {
          from: "clients",
          localField: "clientId",
          foreignField: "clientId",
          as: "Client_Project",
        },
      },
      {
        $unwind: "$Client_Project",
      },
      {
        $unwind: "$users",
      },
      {
        $match: {
          "users.email": req.payload.email, //loggedin user email id
          isActive: true,
          "users.isBlocked": false,
          "users.isActive": true,
          "Client_Project.isActive": true,
        },
      },
      {
        $sort: { projectName: 1 },
      },
      {
        $project: {
          clientName: "$Client_Project.clientName",
          projectName: 1,
          projectId: 1,
          _id: 0,
        },
      },
    ]).exec((err, data) => {
      if (err) {
        next(err);
      }
      try {
        data = Array.from(new Set(data.map(JSON.stringify))) //Remove duplicates of array of objects
          .map(JSON.parse);
        for (const element of data) {
          element.toolTip = element.clientName + "~" + element.projectName;
        }
        res.json(data);
      } catch (e) {
        next(e);
      }
    });
  } else {
    //For Super admins get all the projects
    await Projects.aggregate([
      {
        $lookup: {
          from: "clients",
          localField: "clientId",
          foreignField: "clientId",
          as: "Client_Project",
        },
      },
      {
        $unwind: "$Client_Project",
      },
      {
        $match: {
          isActive: true,
          "Client_Project.isActive": true,
        },
      },
      {
        $sort: { projectName: 1 },
      },
      {
        $project: {
          clientName: "$Client_Project.clientName",
          projectName: 1,
          projectId: 1,
          _id: 0,
        },
      },
    ]).exec((err, data) => {
      if (err) {
        next(err);
      } else {
        data = Array.from(new Set(data.map(JSON.stringify))) //Remove duplicates of array of objects
          .map(JSON.parse);
        for (const element of data) {
          element.toolTip = element.clientName + "~" + element.projectName;
        }
        res.json(data);
      }
    });
  }
});

const groupAndCountByProperty = (data, property) => {
  let key;
  return data.reduce((result, item) => {
    key = item[property];
    result[key] = (result[key] || 0) + 1;
    return result;
  }, {});
};

let setGroupCalculatedValues = (
  reportType,
  groupType,
  uniqueLabels,
  args,
  resultTypeWise
) => {
  uniqueLabels.forEach((element) => {
    //form the statusValues array which is the count of records for the respective status value
    const groupStatusValues = (statusName, statusValues) => {
      if (!statusValues) {
        statusValues = [];
      }
      const statusFilter = resultTypeWise.filter((el) => {
        //group by type of groupType and status
        if (groupType == "Week") {
          return el.week == element && el.statusName == statusName;
        }
        if (groupType == "Project") {
          return el.projectName == element && el.statusName == statusName;
        }
      });

      //form the statusValues array which is the count of records for the respective status value, if the element doesnt exist put 0
      if (typeof statusFilter !== "undefined" && statusFilter.length > 0) {
        statusValues.push(statusFilter[0].count); //push the count of the group
      } else {
        statusValues.push(0); // if the value doesnt exist push 0 for this instance
      }
    };

    if (reportType == "FieldIssues" && groupType == "Project") {
      groupStatusValues("Open", args.openProjectValues);
      groupStatusValues("Verified", args.verifiedProjectValues);
      groupStatusValues("Archived", args.archivedProjectValues);
      groupStatusValues("Resolved", args.resolvedProjectValues);
    }
    if (reportType == "FieldIssues" && groupType == "Week") {
      groupStatusValues("Open", args.openWeeklyValues);
      groupStatusValues("Verified", args.verifiedWeeklyValues);
      groupStatusValues("Archived", args.archivedWeeklyValues);
      groupStatusValues("Resolved", args.resolvedWeeklyValues);
    }
    if (reportType == "WIR" && groupType == "Project") {
      groupStatusValues("New", args.newProjectValues);
      groupStatusValues("Pending", args.pendingProjectValues);
      groupStatusValues("Approved", args.approvedProjectValues);
    }
    if (reportType == "WIR" && groupType == "Week") {
      groupStatusValues("New", args.newWeeklyValues);
      groupStatusValues("Pending", args.pendingWeeklyValues);
      groupStatusValues("Approved", args.approvedWeeklyValues);
    }

    if (reportType == "PunchList" && groupType == "Project") {
      groupStatusValues(
        "Pending Verification",
        args.pendingVerificationProjectValues
      );
      groupStatusValues("Accepted", args.acceptedProjectValues);
      groupStatusValues("Not Accepted", args.notAcceptedProjectValues);
      groupStatusValues(
        "Conditionally Accepted",
        args.conditionallyAcceptedProjectValues
      );
    }
    if (reportType == "PunchList" && groupType == "Week") {
      groupStatusValues(
        "Pending Verification",
        args.pendingVerificationWeeklyValues
      );
      groupStatusValues("Accepted", args.acceptedWeeklyValues);
      groupStatusValues("Not Accepted", args.notacceptedWeeklyValues);
      groupStatusValues(
        "Conditionally Accepted",
        args.conditionallyAcceptedWeeklyValues
      );
    }
  });
};

module.exports = router;
