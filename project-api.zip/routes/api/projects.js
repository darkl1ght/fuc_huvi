"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const Client = mongoose.model("Client");
const LookUp = mongoose.model("LookUp");
const ProjectUser = mongoose.model("ProjectUser");
const Document = mongoose.model("Document");
const Device = mongoose.model("Device");
const AccessMapping = mongoose.model("AccessMapping");
const MasterData = mongoose.model("MasterData");
const WorkPackage = mongoose.model("WorkPackage");
const auth = require("../auth");
const uuid = require("uuid");
var Excel = require("exceljs");
const _ = require("underscore");
const { redisDeleteKey } = require("../../common/redisHelper");
const { Constants } = require("../../config/constants");
const InteriorTour = mongoose.model("InteriorTour");
const ProjectTask = mongoose.model("ProjectTask");
const {
  blobDrawingRef,
  virtualtourContainer,
  blobMediaRef,
  aerialtourContainer,
  mapOutputContainer,
} = require("../../config/index").azureStorage.containers;
const Rfi = mongoose.model("Rfi");
const { getTotalBlobSize } = require("../../common/util");
const AerialTour = mongoose.model("AerialTour");
const Utils = require("../../common/livestream");

// Preload project objects on routes with ':project'
router.param("project", (req, res, next, projectId) => {
  Project.findOne({ projectId: projectId })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

// Preload device objects on routes with ':device'
router.param("device", (req, res, next, deviceId) => {
  Device.findOne({ deviceId: deviceId })
    .then((device) => {
      if (!device) {
        return res.sendStatus(404);
      }
      req.device = device;
      return next();
    })
    .catch(next);
});

router.get("/createAccess", auth.required, async (req, res, next) => {
  let client;
  if (req.payload.isAdmin) {
    res.json({ canCreate: true });
  } else {
    await Client.findOne({
      $or: [
        { email: req.payload.email.toLowerCase() },
        { siteAdmins: req.payload.email.toLowerCase() },
      ],
    })
      .then((data) => {
        client = data;
      })
      .catch(next);

    if (client) {
      res.json({
        clientId: client.clientId,
        canCreate: true,
        isCustomIntegration: client.isCustomIntegration ? true : false,
      });
    } else {
      res.json({ canCreate: false });
    }
  }
});

router.get("/logocheck", auth.required, async (req, res, next) => {
  const query = {};
  const limit = 200;
  const offset = 0;
  const clientId = "3002c1db-97b0-4863-9d17-89bd02dd2e3a";

  if (req.payload.email) {
    query.users = {
      $elemMatch: {
        email: req.payload.email.toLowerCase(),
        isBlocked: false,
        isActive: true,
      },
    };
    query.isActive = true;
    query.clientId = clientId;
  }

  await Promise.all([Project.countDocuments(query).exec()])
    .then((results) => {
      const projectCount = results[0];

      res.json({
        isCustomLogo: projectCount > 0 ? true : false,
      });
    })
    .catch(next);
});

router.get("/", auth.required, async (req, res, next) => {
  const query = {};
  const limit = 200;
  const offset = 0;

  if (req.payload.email) {
    query.users = {
      $elemMatch: {
        email: req.payload.email.toLowerCase(),
        isBlocked: false,
        isActive: true,
      },
    };
    query.isActive = true;
  }

  await Promise.all([
    Project.find(query)
      .limit(Number(limit))
      .skip(Number(offset))
      .sort({ createdAt: "desc" })
      .exec(),
    Project.countDocuments(query).exec(),
  ])
    .then((results) => {
      const projects = results[0];
      const projectCount = results[1];

      res.json({
        projects: projects.map((project) => project.toJSONForMap()),
        projectCount: projectCount,
      });
    })
    .catch(next);
});

router.get(
  "/:project/getProjectDataVolume",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            //Aerial tour images
            const aerialTourPromise = new Promise(async (resolve) => {
              const aerialToursDb = await AerialTour.find({
                projectId: req.params.project,
                isActive: true,
              });

              const blobReferences = new Set();
              const mapOutputBlobReferences = new Set();
              const legendBlobReferences = new Set();

              if (aerialToursDb.length > 0) {
                const result = await Promise.all(
                  aerialToursDb.map(
                    async (aerialTour) =>
                      new Promise(async (resolveAerial) => {
                        await aerialTour
                          .populate({
                            path: "images",
                          })
                          .execPopulate()
                          .then((tour) => {
                            resolveAerial({
                              tourId: aerialTour.tourId,
                              images: tour.images || [],
                              mapUrls: tour.mapUrls || [],
                              legend: tour.legend,
                            });
                          });
                      })
                  )
                );

                for (const tour of result) {
                  for (const image of tour.images) {
                    blobReferences.add(`${tour.tourId}/${image.blobImageId}`);
                  }

                  for (const mapUrl of tour.mapUrls) {
                    mapUrl.uploadedTo == "blob" &&
                      mapUrl.value &&
                      mapOutputBlobReferences.add(
                        mapUrl.value?.split("/").pop()
                      );
                  }

                  tour.legend?.blobContentId &&
                    legendBlobReferences.add(tour.legend.blobContentId);
                }

                resolve({
                  section: "Aerial Maps",
                  subSections: [
                    {
                      section: "Tour Images",
                      container: aerialtourContainer,
                      blobs: blobReferences,
                      blobsCount: blobReferences.size,
                      avgSize: 10 * 1024 * 1024,
                    },
                    {
                      section: "Map Output",
                      container: mapOutputContainer,
                      blobs: mapOutputBlobReferences,
                      blobsCount: mapOutputBlobReferences.size,
                      avgSize: 100 * 1024 * 1024,
                    },
                    {
                      section: "Legend",
                      container: blobMediaRef,
                      blobs: legendBlobReferences,
                      blobsCount: legendBlobReferences.size,
                      avgSize: 100 * 1024 * 1024,
                    },
                  ],
                  blobsCount:
                    blobReferences.size +
                    mapOutputBlobReferences.size +
                    legendBlobReferences.size,
                });
              } else {
                resolve({
                  section: "Aerial Maps",
                  subSections: [
                    {
                      section: "Tour Images",
                      container: aerialtourContainer,
                      blobs: blobReferences,
                      blobsCount: blobReferences.size,
                      avgSize: 10 * 1024 * 1024,
                    },
                    {
                      section: "Map Output",
                      container: mapOutputContainer,
                      blobs: mapOutputBlobReferences,
                      blobsCount: mapOutputBlobReferences.size,
                      avgSize: 100 * 1024 * 1024,
                    },
                    {
                      section: "Legend",
                      container: blobMediaRef,
                      blobs: legendBlobReferences,
                      blobsCount: legendBlobReferences.size,
                      avgSize: 100 * 1024 * 1024,
                    },
                  ],
                  blobsCount:
                    blobReferences.size +
                    mapOutputBlobReferences.size +
                    legendBlobReferences.size,
                });
              }
            });

            //Aerial Punchlist data
            const aerialPunchListPromise = new Promise(async (resolve) => {
              const projectTasksDb = await ProjectTask.aggregate([
                {
                  $match: {
                    projectId: req.project.projectId,
                    isActive: true,
                  },
                },
                {
                  $lookup: {
                    from: "aerialtours",
                    localField: "tourId",
                    foreignField: "tourId",
                    as: "aerial_tours",
                  },
                },
                {
                  $match: {
                    "aerial_tours.projectId": req.project.projectId,
                    "aerial_tours.isActive": true,
                  },
                },
                {
                  $unwind: "$mediaList",
                },
                {
                  $project: {
                    _id: 0,
                    blobReference: "$mediaList.blobReference",
                  },
                },
              ]);

              const blobReferences = new Set();

              if (projectTasksDb.length > 0) {
                for (const iterator of projectTasksDb) {
                  iterator.blobReference &&
                    blobReferences.add(iterator.blobReference);
                }
              }

              resolve({
                section: "Aerial Punchlist",
                subSections: [
                  {
                    section: "Aerial Punchlist",
                    container: blobMediaRef,
                    blobs: blobReferences,
                    blobsCount: blobReferences.size,
                    avgSize: 5 * 1024 * 1024,
                  },
                ],
                blobsCount: blobReferences.size,
              });
            });

            // Interior tour images, interior floor plans
            const interiorTourPromise = new Promise(async (resolve) => {
              const interiorTourDb = await InteriorTour.find({
                projectId: req.params.project,
                isActive: true,
              });

              const blobReferencesFloorPlan = new Set();
              const blobReferencesTourImages = new Set();

              if (interiorTourDb.length > 0) {
                const result = await Promise.all(
                  interiorTourDb.map(
                    (interiorTour) =>
                      new Promise(async (resolveInterior) => {
                        await interiorTour
                          .populate({
                            path: "floorWalkthough",
                            populate: {
                              path: "tours",
                              model: "TourImage",
                            },
                          })
                          .execPopulate()
                          .then((tour) => {
                            const blobReferencesFloorPlanTemp = new Set();
                            const blobReferencesTourImagesTemp = new Set();

                            for (const tower of tour.floorWalkthough || []) {
                              for (const floor of tower.tours || []) {
                                //Floor plans
                                floor.floorPlanBlobId &&
                                  blobReferencesFloorPlanTemp.add(
                                    floor.floorPlanBlobId
                                  );

                                //Tour images
                                for (const image of floor.images || []) {
                                  blobReferencesTourImagesTemp.add(
                                    `${floor.tourId}/${image.blobImageId}`
                                  );
                                }
                              }
                            }

                            resolveInterior({
                              floorPlan: blobReferencesFloorPlanTemp,
                              tourImages: blobReferencesTourImagesTemp,
                            });
                          });
                      })
                  )
                );

                for (const interior of result) {
                  for (const file of Array.from(interior.floorPlan)) {
                    blobReferencesFloorPlan.add(file);
                  }

                  for (const file of Array.from(interior.tourImages)) {
                    blobReferencesTourImages.add(file);
                  }
                }

                resolve({
                  section: "Virtual Tours",
                  subSections: [
                    {
                      section: "Tour Images",
                      container: virtualtourContainer,
                      blobs: blobReferencesTourImages,
                      blobsCount: blobReferencesTourImages.size,
                      avgSize: 500 * 1024,
                    },
                    {
                      section: "Floor Plan",
                      container: blobDrawingRef,
                      blobs: blobReferencesFloorPlan,
                      blobsCount: blobReferencesFloorPlan.size,
                      avgSize: 5 * 1024 * 1024,
                    },
                  ],
                  blobsCount:
                    blobReferencesTourImages.size +
                    blobReferencesFloorPlan.size,
                });
              } else {
                resolve({
                  section: "Virtual Tours",
                  subSections: [
                    {
                      section: "Tour Images",
                      container: virtualtourContainer,
                      blobs: blobReferencesTourImages,
                      blobsCount: blobReferencesTourImages.size,
                      avgSize: 500 * 1024,
                    },
                    {
                      section: "Floor Plan",
                      container: blobDrawingRef,
                      blobs: blobReferencesFloorPlan,
                      blobsCount: blobReferencesFloorPlan.size,
                      avgSize: 5 * 1024 * 1024,
                    },
                  ],
                  blobsCount:
                    blobReferencesTourImages.size +
                    blobReferencesFloorPlan.size,
                });
              }
            });

            //Interior Punchlist data
            const interiorPunchlistPromise = new Promise(async (resolve) => {
              const projectTaskDb = await ProjectTask.aggregate([
                {
                  $match: {
                    projectId: req.project.projectId,
                    isActive: true,
                    tourId: { $exists: false },
                  },
                },
                {
                  $unwind: "$mediaList",
                },
                {
                  $project: {
                    _id: 0,
                    blobReference: "$mediaList.blobReference",
                    latestSnapshotBlobId: "$floorPlan.latestSnapshotBlobId",
                  },
                },
              ]);

              const blobReferences = new Set();

              if (projectTaskDb.length > 0) {
                for (const iterator of projectTaskDb) {
                  iterator.blobReference &&
                    blobReferences.add(iterator.blobReference);
                  iterator.latestSnapshotBlobId &&
                    blobReferences.add(iterator.latestSnapshotBlobId);
                }
              }

              resolve({
                section: "Interior Punchlist",
                subSections: [
                  {
                    section: "Interior Punchlist",
                    container: blobMediaRef,
                    blobs: blobReferences,
                    blobsCount: blobReferences.size,
                    avgSize: 1 * 1024 * 1024,
                  },
                ],
                blobsCount: blobReferences.size,
              });
            });

            const RFIPromise = new Promise(async (resolve) => {
              const RFIDb = await Rfi.find({
                projectId: req.params.project,
                isActive: true,
              });

              const blobReferences = new Set();

              if (RFIDb.length > 0) {
                for (const rfi of RFIDb) {
                  for (const photo of rfi.sitePhotos || []) {
                    photo.drawingId && blobReferences.add(photo.drawingId);
                  }

                  for (const check of rfi.checkList || []) {
                    for (const image of check.images || []) {
                      image.drawingId && blobReferences.add(image.drawingId);
                    }
                  }
                }
              }

              resolve({
                section: "RFI",
                subSections: [
                  {
                    section: "RFI",
                    container: blobMediaRef,
                    blobs: blobReferences,
                    blobsCount: blobReferences.size,
                    avgSize: 1 * 1024 * 1024,
                  },
                ],
                blobsCount: blobReferences.size,
              });
            });

            const sections = await Promise.all([
              aerialTourPromise,
              aerialPunchListPromise,
              interiorTourPromise,
              interiorPunchlistPromise,
              RFIPromise,
            ]);

            let totBlobCount = 0;

            for (const section of sections) {
              for (const subSection of section.subSections) {
                totBlobCount += subSection.blobs.size;
              }
            }

            let thresholdCount = parseInt(req.query.threshold);
            thresholdCount = isNaN(thresholdCount) ? 2000 : thresholdCount;

            if (totBlobCount > thresholdCount) {
              //Show estimated sizes
              const resultTransformed = sections.map((section) => {
                return {
                  section: section.section,
                  subSections: section.subSections.map((subSection) => {
                    return {
                      section: subSection.section,
                      blobsCount: subSection.blobsCount,
                      //less confidence on approximation
                      size: `${section.section == "Aerial Maps" ? "~~" : "~"}${
                        subSection.avgSize * subSection.blobsCount
                      }`,
                    };
                  }),
                  blobsCount: section.blobsCount,
                  size: `${
                    section.section == "Aerial Maps" ? "~~" : "~"
                  }${section.subSections.reduce(
                    (acc, subSection) =>
                      acc + subSection.avgSize * subSection.blobsCount,
                    0
                  )}`,
                };
              });

              const resultFinal = resultTransformed.map((section) => {
                return {
                  module: section.section,
                  blobsCount: section.blobsCount,
                  size: section.size,
                };
              });

              res.json(resultFinal);
            } else {
              //Show actual sizes
              const result = await Promise.all(
                sections.map(
                  (section) =>
                    new Promise(async (resolve) => {
                      if (section.subSections.length > 0) {
                        const subSectionsUpdated = await Promise.all(
                          section.subSections.map(
                            (subSection) =>
                              new Promise(async (resolveSubSection) => {
                                const size = await getTotalBlobSize(
                                  subSection.container,
                                  Array.from(subSection.blobs)
                                );
                                subSection.size = size;
                                resolveSubSection(subSection);
                              })
                          )
                        );
                        let totSectionSize = 0;
                        let sizeError = false;

                        for (const subSection of subSectionsUpdated) {
                          if (subSection.size == -1) {
                            sizeError = true;
                          }

                          totSectionSize += subSection.size;
                        }

                        section.subSections = subSectionsUpdated;
                        section.size = sizeError ? -1 : totSectionSize;
                        resolve(section);
                      } else {
                        section.size = 0;
                        resolve(section);
                      }
                    })
                )
              );

              const resultTransformed = result.map((section) => {
                return {
                  section: section.section,
                  subSections: section.subSections.map((subSection) => {
                    return {
                      section: subSection.section,
                      blobsCount: subSection.blobsCount,
                      size: subSection.size ?? 0,
                    };
                  }),
                  blobsCount: section.blobsCount,
                  size: section.size ?? 0,
                };
              });

              const resultFinal = resultTransformed.map((section) => {
                return {
                  module: section.section,
                  blobsCount: section.blobsCount,
                  size: section.size?.toString(),
                };
              });

              res.json(resultFinal);
            }
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

//This is used in Orchestrator for validation
router.get(
  "/:project/getprojectusers",
  auth.required,
  async (req, res, next) => {
    res.json({ users: req.project.users });
  }
);

router.get(
  "/searchbyclientId/:clientId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.isAdmin) {
      const query = {};
      const limit = 200;
      const offset = 0;

      if (req.payload.email) {
        query.clientId = req.params.clientId;
        query.isActive = true;
      }

      await Promise.all([
        Project.find(query)
          .limit(Number(limit))
          .skip(Number(offset))
          .sort({ createdAt: "desc" })
          .exec(),
        Project.countDocuments(query).exec(),
      ])
        .then((results) => {
          const projects = results[0];
          const projectCount = results[1];

          res.json({
            projects: projects.map((project) => project.toJSONForMap()),
            projectCount: projectCount,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(401);
    }
  }
);

router.post(
  "/createproject/:clientId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.isAdmin) {
      let client;
      await Client.findOne({ clientId: req.params.clientId })
        .then((data) => {
          client = data;
        })
        .catch(next);

      let userRole;
      const project = new Project(req.body.project);
      project.projectAdmin = client.email;
      project.clientId = client.clientId;
      project.projectId = uuid.v4();
      project.createdBy = req.payload.email;
      project.isActive = true;

      await AccessMapping.findOne(
        {
          role: "Project Admin",
          isActive: true,
        },
        {
          role: 1,
          desc: 1,
        }
      )
        .then((data) => {
          userRole = data;
        })
        .catch(next);

      const user = new ProjectUser();
      user.memberId = uuid.v4();
      user.firstName = client.firstName;
      user.lastName = client.lastName;
      user.isActive = true;
      user.isBlocked = false;
      user.role = userRole
        ? {
            code: userRole.role,
            desc: userRole.desc,
          }
        : null;
      user.email = client.email;
      user.createdBy = req.payload.email;
      project.users.push(user);

      project
        .save()
        .then(() => {
          client.projects.push(project);
          client.save().then(() => {
            createMasterData(project.projectId, req.payload.email);
            res.json({ project: project });
          });
        })
        .catch(next);
    } else {
      res.sendStatus(401);
    }
  }
);

router.post("/", auth.required, async (req, res, next) => {
  let userRole;
  let client;

  await Client.findOne({ email: req.payload.email.toLowerCase() })
    .then((data) => {
      client = data;
    })
    .catch(next);

  await AccessMapping.findOne(
    {
      role: "Project Admin",
      isActive: true,
    },
    {
      role: 1,
      desc: 1,
    }
  )
    .then((data) => {
      userRole = data;
    })
    .catch(next);

  const bodyNew = { ...req.body.project };

  if (!req.payload.isAdmin) {
    delete bodyNew.contractEndDate;
    delete bodyNew.isCompleted;
  }

  const project = new Project(bodyNew);
  project.projectAdmin = req.payload.email.toLowerCase();
  project.projectId = uuid.v4();
  project.clientId = client.clientId;
  project.createdBy = req.payload.email;
  project.isActive = true;

  const user = new ProjectUser();
  user.memberId = uuid.v4();
  user.firstName = req.payload.firstName;
  user.lastName = req.payload.lastName;
  user.isActive = true;
  user.isBlocked = false;
  user.role = userRole
    ? {
        code: userRole.role,
        desc: userRole.desc,
      }
    : null;
  user.email = req.payload.email.toLowerCase();
  user.createdBy = req.payload.email;
  project.users.push(user);

  project
    .save()
    .then(() => {
      client.projects.push(project);
      client.save().then(() => {
        createMasterData(project.projectId, req.payload.email.toLowerCase());
        res.json({ project: project });
      });
    })
    .catch(next);
});

const createMasterData = async (projectId, email) => {
  if (projectId) {
    await MasterData.findOne({ projectId: projectId }).then(
      async (masterdata) => {
        if (!masterdata) {
          await WorkPackage.find({}, async (err, workTradeList) => {
            const workPackageList = [];
            workTradeList.forEach((work) => {
              workPackageList.push(work);
            });

            const masterData = new MasterData();
            masterData.projectId = projectId;
            masterData.workPackage = workPackageList;
            masterData.workLocation = [];
            masterData.workFlow = [];
            masterData.rfi = [];
            masterData.directory = [];
            masterData.createdBy = email;
            masterData.updatedBy = email;
            await masterData.save().then(() => {});
          });
        }
      }
    );
  }
};

router.get("/projectsAndInteriors", auth.required, async (req, res, next) => {
  const query = {};
  const limit = 200;
  const offset = 0;

  if (req.payload.email) {
    query.users = {
      $elemMatch: {
        email: req.payload.email.toLowerCase(),
        isBlocked: false,
        isActive: true,
      },
    };
    query.isActive = true;

    await Project.find(query)
      .limit(Number(limit))
      .skip(Number(offset))
      .populate({
        path: "interiors",
        populate: {
          path: "floorWalkthough.tours",
          model: "TourImage",
        },
      })
      .sort({ createdAt: -1 })
      .then((results) => {
        res.json({
          projects: results.map((project) =>
            project.projectsAndInteriorsToJSON()
          ),
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

// get a project
router.get("/:project", auth.required, async (req, res, next) => {
  await Project.countDocuments(
    {
      users: {
        $elemMatch: {
          email: req.payload.email,
          isActive: true,
          isBlocked: false,
        },
      },
      projectId: req.project.projectId,
      isActive: true,
    },
    async (err, count) => {
      if (count > 0 || req.payload.isAdmin) {
        Promise.all([req.project.execPopulate()])
          .then(() => {
            res.json({ project: req.project });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    }
  );
});

// update article
router.put("/:project", auth.required, async (req, res, next) => {
  await Project.countDocuments(
    {
      users: {
        $elemMatch: {
          email: req.payload.email,
          isActive: true,
          isBlocked: false,
        },
      },
      projectId: req.project.projectId,
      isActive: true,
    },
    async (err, count) => {
      if (count > 0 || req.payload.isAdmin) {
        if (typeof req.body.project.projectName !== "undefined") {
          req.project.projectName = req.body.project.projectName;
        }

        if (typeof req.body.project.location !== "undefined") {
          req.project.location = req.body.project.location;
        }

        if (typeof req.body.project.type !== "undefined") {
          req.project.type = req.body.project.type;
        }

        if (typeof req.body.project.lat !== "undefined") {
          req.project.lat = req.body.project.lat;
        }

        if (typeof req.body.project.lng !== "undefined") {
          req.project.lng = req.body.project.lng;
        }

        if (typeof req.body.project.type !== "undefined") {
          req.project.type = req.body.project.type;
        }

        if (req.payload.isAdmin) {
          if (req.body.project.contractEndDate) {
            req.project.contractEndDate = req.body.project.contractEndDate;
          }
          if (typeof req.body.project.isCompleted === "boolean") {
            req.project.isCompleted = req.body.project.isCompleted;
          }
        }

        req.project.updatedBy = req.payload.email;

        await req.project
          .save()
          .then((project) => {
            res.json({ project: project });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    }
  );
});

router.delete("/:project", auth.required, async (req, res, next) => {
  await Project.countDocuments(
    {
      users: {
        $elemMatch: {
          email: req.payload.email,
          isActive: true,
          isBlocked: false,
        },
      },
      projectId: req.project.projectId,
      isActive: true,
    },
    async (err, count) => {
      if (count > 0 || req.payload.isAdmin) {
        req.project.isActive = false;
        await req.project
          .save()
          .then(() => {
            res.json({ status: "success" });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    }
  );
});

// get a project's users
router.get("/:project/users", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          res.json({ users: req.project.users });
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

// update article
router.put("/:project/users/:user", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          await Project.findOneAndUpdate(
            {
              projectId: req.project.projectId,
              "users.memberId": req.body.user.memberId,
            },
            {
              $set: {
                "users.$.isBlocked":
                  typeof req.body.user.isBlocked !== "undefined"
                    ? req.body.user.isBlocked
                    : req.user.isBlocked,
                "users.$.firstName":
                  typeof req.body.user.firstName !== "undefined"
                    ? req.body.user.firstName
                    : req.user.firstName,
                "users.$.lastName":
                  typeof req.body.user.lastName !== "undefined"
                    ? req.body.user.lastName
                    : req.user.lastName,
                "users.$.email":
                  typeof req.body.user.email !== "undefined"
                    ? req.body.user.email.toLowerCase()
                    : req.user.email.toLowerCase(),
                "users.$.role":
                  typeof req.body.user.role !== "undefined" &&
                  req.body.user.role !== "Super Admin"
                    ? req.body.user.role
                    : req.user.role,
              },
            }
          )
            .then(async () => {
              const projectUsersCacheKey =
                Constants.accessControlConfig.PROJECT_USERS_CACHE_KEY_PREFIX +
                req.project.projectId;
              await redisDeleteKey(projectUsersCacheKey);
              res.json({ status: "success" });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

router.put(
  "/:project/user/blockunblock",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await Project.findOneAndUpdate(
              {
                projectId: req.project.projectId,
                "users.memberId": req.body.memberId,
              },
              {
                $set: {
                  "users.$.isBlocked": req.body.isBlocked,
                },
              }
            )
              .then(() => {
                res.json({ status: "success" });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/users/:user/signature",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await Project.findOneAndUpdate(
              {
                projectId: req.project.projectId,
                "users.memberId": req.user.memberId,
              },
              {
                $set: {
                  "users.$.signature": req.body.signature,
                },
              }
            )
              .then(() => {
                res.json({ status: "success" });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// create a new user
router.post("/:project/users", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          // if user is already exist , remove the user from the list
          await Project.findOneAndUpdate(
            {
              projectId: req.project.projectId,
            },
            {
              $pull: {
                users: {
                  email: req.body.user.email.toLowerCase(),
                },
              },
            }
          );

          const user = new ProjectUser(req.body.user);
          user.memberId = uuid.v4();
          user.isBlocked = false;
          user.isActive = true;
          user.createdBy = req.payload.email;
          req.project.users.push(user);

          await req.project
            .save()
            .then(async () => {
              const projectUsersCacheKey =
                Constants.accessControlConfig.PROJECT_USERS_CACHE_KEY_PREFIX +
                req.project.projectId;
              await redisDeleteKey(projectUsersCacheKey);
              res.json({ status: "success" });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    ).catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.delete(
  "/:project/users/:user",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await Project.findOneAndUpdate(
              {
                projectId: req.project.projectId,
              },
              {
                $pull: {
                  users: {
                    memberId: req.user.memberId,
                  },
                },
              }
            )
              .then(async () => {
                const projectUsersCacheKey =
                  Constants.accessControlConfig.PROJECT_USERS_CACHE_KEY_PREFIX +
                  req.project.projectId;
                await redisDeleteKey(projectUsersCacheKey);
                res.json({ status: "success" });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.param("user", (req, res, next, memberId) => {
  Project.findOne({
    users: {
      $elemMatch: {
        memberId: memberId,
      },
    },
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.user = project.users.find((m) => m.memberId === memberId);
      return next();
    })
    .catch(next);
});

router.param("document", (req, res, next, documentId) => {
  Document.findOne({ documentId: documentId })
    .then((document) => {
      if (!document) {
        return res.sendStatus(404);
      }
      req.document = document;
      return next();
    })
    .catch(next);
});

router.get("/:project/documents", auth.required, async (req, res, next) => {
  await req.project
    .populate({
      path: "documents",
      options: {
        sort: {
          createdAt: "desc",
        },
      },
    })
    .execPopulate()
    .then(() => {
      res.json({ documents: req.project.documents });
    })
    .catch(next);
});

// create a new document
router.post("/:project/documents", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          const document = new Document(req.body.document);
          document.documentId = uuid.v4();
          document.projectId = req.project.projectId;
          document.createdBy = req.payload.email;
          document.updatedBy = req.payload.email;
          await document
            .save()
            .then(() => {
              req.project.documents.push(document);
              req.project.save().then((project) => {
                res.json({ status: "success" });
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

router.delete(
  "/:project/documents/:document",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            req.project.documents.remove(req.document._id);
            await req.project
              .save()
              .then(
                Document.findOneAndUpdate(
                  {
                    _id: req.document._id,
                  },
                  {
                    $set: {
                      isActive: false,
                    },
                  }
                ).exec()
              )
              .then(() => {
                res.sendStatus(204);
              });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// update document
router.put(
  "/:project/documents/:document",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.document) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let history = {
              blobDocId: req.document.blobDocId,
              name: req.document.name,
              size: req.document.size,
              lastUpdated: req.document.updatedBy,
              updatedAt: req.document.updatedAt,
            };

            if (
              req.body.document.blobDocId &&
              req.document.blobDocId !== req.body.document.blobDocId
            ) {
              req.document.history.push(history);
            }

            if (typeof req.body.document.blobDocId !== "undefined") {
              req.document.blobDocId = req.body.document.blobDocId;
            }

            if (typeof req.body.document.name !== "undefined") {
              req.document.name = req.body.document.name;
            }

            if (typeof req.body.document.size !== "undefined") {
              req.document.size = req.body.document.size;
            }

            if (typeof req.body.document.tagList !== "undefined") {
              req.document.tagList = req.body.document.tagList;
            }

            req.document.updatedBy = req.payload.email;

            await req.document
              .save()
              .then((document) => {
                res.json({ document: document });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// create a new document
router.post("/:project/livestream", auth.required, async (req, res, next) => {
  let tokenArray;
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          tokenArray = req.headers.authorization.split(" ");
          let deviceCode = uuid.v4();
          let token = tokenArray[1];

          const response = await Utils.registerDevice(
            deviceCode,
            req.body.device.recording,
            token
          );

          const device = new Device(req.body.device);
          device.deviceId = deviceCode;
          device.isActive = true;
          device.rtmpUrl = response.rtmpLink;
          device.projectId = req.project.projectId;
          device.createdBy = req.payload.email;
          await device
            .save()
            .then(async () => {
              req.project.devices.push(device);
              req.project.save().then((project) => {
                res.json({ status: "success" });
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

// create a new document
router.delete(
  "/:project/livestream/:device",
  auth.required,
  async (req, res, next) => {
    let tokenArray;
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            tokenArray = req.headers.authorization.split(" ");
            let token = tokenArray[1];
            const response = await Utils.deleteDevice(
              req.device.deviceId,
              token
            );
            req.project.devices.remove(req.device._id);
            await req.project
              .save()
              .then(
                Device.findOneAndUpdate(
                  {
                    _id: req.device._id,
                  },
                  {
                    $set: {
                      isActive: false,
                    },
                  }
                ).exec()
              )
              .then(() => {
                res.sendStatus(204);
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/livestream/devices",
  auth.required,
  async (req, res, next) => {
    let tokenArray;
    let deviceList = [];
    if (req.payload.email) {
      await req.project
        .populate({
          path: "devices",
          options: {
            sort: {
              createdAt: "desc",
            },
          },
        })
        .execPopulate()
        .then(async (project) => {
          tokenArray = req.headers.authorization.split(" ");
          let token = tokenArray[1];
          let devices = req.project.devices;

          await Promise.all(
            devices.map(async (device) => {
              const response = await Utils.getStatistics(
                device.deviceId,
                token
              );
              device.upTime = response.streamDetails.uptime;
              device.bytesInRate = response.streamDetails.bytesInRate;
              deviceList.push(device);
            })
          );

          res.json({ devices: deviceList });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

//download template for users

router.get(
  "/:project/templateforusers",
  auth.required,
  async (req, res, next) => {
    var workbook = new Excel.Workbook();
    let worksheet = workbook.addWorksheet("Team Members");
    let worksheetUserRoleData = workbook.addWorksheet("UserRoleData");
    worksheetUserRoleData.state = "hidden";
    let sheetName = "team" + ".xlsx";

    await AccessMapping.find(
      {
        isActive: true,
        role: { $ne: "Super Admin" },
      },
      {
        _id: 0,
        role: 1,
        desc: 1,
      },
      {
        sort: {
          desc: 1,
        },
      }
    )
      .then(async (data) => {
        let users = data;
        if (users.length > 0) {
          _.each(users, function (user) {
            if (!!user.role) {
              worksheetUserRoleData.addRow([user.role]);
            }
          });
        }
        worksheet.columns = [
          {
            header: "First Name",
            key: "firstName",
            width: 30,
          },
          {
            header: "Last Name",
            key: "lastName",
            width: 28,
          },
          {
            header: "Email Address",
            key: "emailAddress",
            width: 32,
          },
          {
            header: "User Role",
            key: "userRole",
            width: 32,
          },
        ];

        worksheet.dataValidations.add("D2:D1000", {
          type: "list",
          allowBlank: true,
          prompt: "Choose from dropdown",
          formulae: ["=UserRoleData!$A$1:$A$9999"],
          showErrorMessage: true,
          errorStyle: "error",
          error: "Please select a valid value from the list",
        });
        res.setHeader("Content-Type", "text/plain");
        const fileBuffer = await workbook.xlsx.writeBuffer();
        res.send(fileBuffer.toString("base64"));
      })
      .catch(next);
  }
);

// bulk upload users

router.post(
  "/:project/bulkuploadusers",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            // if user is already exist , remove the user from the list
            await Project.findOneAndUpdate(
              {
                projectId: req.project.projectId,
              },
              {
                $pull: {
                  users: {
                    email: {
                      $in: req.body.teams.users.map((x) =>
                        x.email.toLowerCase()
                      ),
                    },
                  },
                },
              }
            );

            const users = [];
            req.body.teams.users.forEach((item) => {
              const user = {
                firstName: item.firstName,
                lastName: item.lastName,
                email: item.email.toLowerCase(),
                role: {
                  code: item.role,
                  desc: item.role,
                },
                isActive: true,
                isBlocked: false,
                memberId: uuid.v4(),
                createdBy: req.payload.email,
              };
              users.push(user);
            });
            await Project.findOneAndUpdate(
              {
                projectId: req.project.projectId,
              },
              {
                $push: {
                  users: {
                    $each: users,
                  },
                },
              }
            );

            await req.project
              .save()
              .then(async () => {
                res.json({
                  status: "Success",
                  msg: "Teams uploaded Sucessfully",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

module.exports = router;
