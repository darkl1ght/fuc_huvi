"use strict";
const router = require("express").Router();
const mongoose = require("mongoose");
const Lookup = mongoose.model("LookUp");
const NotificationMasterData = require("../../models/NotificationMasterData");

const auth = require("../auth");
const uuid = require("uuid");

// Adds notification messaging ID
router.post("/:appType", auth.required, async (req, res, next) => {
  try {
    const { appType } = req.params;
    const { token: messagingToken, deviceId } = req.body;
    const { key, value } = await Lookup.findOne({
      type: "appType",
      key: appType,
    });

    if (!value || !messagingToken || !deviceId)
      res.json({
        status: "Failure",
        message: "Please provide mandatory fields",
      });

    const token = {
      appType: {
        key,
        value,
      },
      token: messagingToken,
      deviceId,
    };

    /*
            Disable all existing tokens for a device 
            1) with different token
            2) with same token but for different user, 
        */
    await NotificationMasterData.updateMany(
      {
        "tokens.deviceId": deviceId,
        "tokens.appType.key": key,
        $or: [
          {
            "tokens.token": {
              $ne: messagingToken,
            },
          },
          {
            $and: [
              {
                "tokens.token": {
                  $eq: messagingToken,
                },
              },
              {
                userEmail: {
                  $ne: req.payload.email,
                },
              },
            ],
          },
        ],
      },
      {
        $set: {
          "tokens.$[].disabled": true,
        },
      }
    );

    // Add or modify new token data
    await NotificationMasterData.updateOne(
      {
        userEmail: req.payload.email,
      },
      {
        userEmail: req.payload.email,
        $addToSet: {
          tokens: token,
        },
      },
      { upsert: true }
    );

    res.json({ status: "Success" });
  } catch (error) {
    next(error);
  }
});

router.delete(
  "/:appType/:token/:deviceId",
  auth.required,
  async (req, res, next) => {
    try {
      const { appType, token, deviceId } = req.params;

      if (!token || !deviceId || !appType)
        res.json({
          status: "Failure",
          message: "Please provide mandatory fields",
        });

      await NotificationMasterData.updateMany(
        {
          "tokens.deviceId": deviceId,
          "tokens.token": token,
          "tokens.appType.key": appType,
          userEmail: req.payload.email,
        },
        {
          $set: {
            "tokens.$[].disabled": true,
          },
        }
      );
      res.json({ status: "Success" });
    } catch (error) {
      next(error);
    }
  }
);

module.exports = router;
