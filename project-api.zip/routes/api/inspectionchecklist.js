const router = require("express").Router();
const mongoose = require("mongoose");
const InspectionCheckList = mongoose.model("InspectionCheckList");
const auth = require("../auth");
const uuid = require("uuid");
const logger = require("../../common/logger");

router.get("/:projectId/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await InspectionCheckList.find({
      projectId: req.params.projectId,
    })
      .then((data) => {
        res.json({
          inspectionCheckList: data,
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.post("/:projectId/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    const inspectionCheckList = new InspectionCheckList(
      req.body.inspectionCheckList
    );
    inspectionCheckList.inspectionId = uuid.v4();
    inspectionCheckList.projectId = req.params.projectId;
    inspectionCheckList.createdBy = req.payload.email;
    inspectionCheckList.updatedBy = req.payload.email;
    await inspectionCheckList
      .save()
      .then(() => {
        res.json({
          status: "success",
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.put("/:project/:inspectionId", auth.required, async (req, res, next) => {
  const inspectionCheckList = req.body.inspectionCheckList;
  await InspectionCheckList.countDocuments(
    {
      projectId: req.params.project,
      inspectionId: req.params.inspectionId,
    },
    async (err, count) => {
      if (count > 0) {
        await InspectionCheckList.findOneAndUpdate(
          {
            projectId: req.params.project,
            inspectionId: req.params.inspectionId,
          },
          {
            $set: {
              checkListName: inspectionCheckList.checkListName,
              questionnaire: inspectionCheckList.questionnaire,
              activities: inspectionCheckList.activities,
              updatedBy: req.payload.email,
            },
          }
        )
          .then(() => {
            res.json({ status: "success" });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    }
  );
});

router.delete(
  "/:project/:inspectionId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.project && req.params.inspectionId) {
        await InspectionCheckList.deleteOne(
          {
            projectId: req.params.project,
            inspectionId: req.params.inspectionId,
          },
          function (err) {
            if (err) {
              res.sendStatus(401);
            } else {
              res.json({
                status: "success",
              });
            }
          }
        );
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

module.exports = router;
