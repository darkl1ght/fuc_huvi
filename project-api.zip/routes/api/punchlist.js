"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const LookUp = mongoose.model("LookUp");
const ProjectTask = mongoose.model("ProjectTask");
const OnsiteTask = mongoose.model("OnsiteTask");
const MasterData = mongoose.model("MasterData");
const auth = require("../auth");
const uuid = require("uuid");
const asyncPackage = require("async");
const moment = require("moment-timezone");
const Utils = require("../../common/util");
const { generateUUID } = require("../../common/util");
const Logger = require("../../common/logger");
const _ = require("lodash");
const fs = require("fs");
const prepareNotificationData = require("../../common/notification");
const {
  notificationMiddleWare,
} = require("../../middlewares/notification.middleware");

const path = require("path");
const { saveForDownloadReport } = require("../../common/snag-report");

// Preload project objects on routes with ':task'
router.param("task", (req, res, next, taskId) => {
  ProjectTask.findOne({
    taskId: taskId,
  })
    .then((task) => {
      if (!task) {
        return res.sendStatus(404);
      }
      req.task = task;
      return next();
    })
    .catch(next);
});

// Preload project objects on routes with ':project'
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.post(
  "/:project/query/:category",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const query = {};
            const config = req.body.config.filters;
            const category = req.params.category;

            switch (category) {
              case "all":
                break;
              case "open":
                query["$or"] = [
                  {
                    "taskStatus.code": "TS10001",
                  },
                  {
                    "taskStatus.code": "TS10003",
                  },
                ];
                break;
              case "assigned":
                query["$or"] = [
                  {
                    level1Users: {
                      $in: [req.payload.email],
                    },
                  },
                  {
                    level2Users: {
                      $in: [req.payload.email],
                    },
                  },
                ];
                break;
              case "overdue":
                const currentDate = new Date().toISOString();
                query["$and"] = [
                  {
                    $or: [
                      {
                        "taskStatus.code": "TS10001",
                      },
                      {
                        "taskStatus.code": "TS10003",
                      },
                    ],
                  },
                  {
                    dueDate: {
                      $lte: currentDate,
                    },
                  },
                ];
                break;
              case "completed":
                query["$or"] = [
                  {
                    "taskStatus.code": "TS10002",
                  },
                  {
                    "taskStatus.code": "TS10004",
                  },
                ];
                break;
              default:
            }

            if (typeof config.projectId !== "undefined") {
              query.projectId = req.params.project;
            }

            if (config.location) {
              query["workLocation.locationId"] = {
                $in: config.location,
              };
            }

            if (config.workPackage) {
              query["workPackage.tradeId"] = {
                $in: config.workPackage,
              };
            }

            if (config.priority) {
              query["taskPriority.code"] = config.priority;
            }

            if (config.assignee) {
              query["$or"] = [
                {
                  level1Users: {
                    $in: config.assignee,
                  },
                },

                {
                  level2Users: {
                    $in: config.assignee,
                  },
                },
              ];
            }

            if (config.isNonConformity) {
              query.isNonConformity = config.isNonConformity;
            }

            if (config.startDate && config.endDate) {
              const endDate = new Date(config.endDate);
              endDate.setDate(endDate.getDate() + 1);
              query["dueDate"] = {
                $gte: config.startDate,
                $lt: endDate.toISOString(),
              };
            } else if (config.startDate) {
              query["dueDate"] = {
                $gte: config.startDate,
              };
            } else if (config.endDate) {
              const endDate = new Date(config.endDate);
              endDate.setDate(endDate.getDate() + 1);
              query["dueDate"] = {
                $lt: endDate.toISOString(),
              };
            }

            if (config.createdStartDate && config.createdEndDate) {
              const createdEndDate = new Date(config.createdEndDate);
              createdEndDate.setDate(createdEndDate.getDate() + 1);
              query["createdAt"] = {
                $gte: config.createdStartDate,
                $lt: createdEndDate.toISOString(),
              };
            } else if (config.createdStartDate) {
              query["createdAt"] = {
                $gte: config.createdStartDate,
              };
            } else if (config.createdEndDate) {
              const createdEndDate = new Date(config.createdEndDate);
              createdEndDate.setDate(createdEndDate.getDate() + 1);
              query["createdAt"] = {
                $lt: createdEndDate.toISOString(),
              };
            }

            query["isActive"] = true;
            query["projectId"] = req.params.project;

            await Promise.all([
              ProjectTask.find(query)
                .sort({
                  createdAt: "desc",
                })
                .exec(),
              ProjectTask.countDocuments(query).exec(),
            ]).then((results) => {
              const punchItems = results[0];
              const itemCount = results[1];

              res.json({
                punchItems: punchItems,
                itemCount: itemCount,
              });
            });
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/querybypage/:category",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const query = {};
            let limit = 20;
            let offset = 0;
            let key = "workPackage.workTrade";
            let direction = "asc";

            const config = req.body.config.filters;
            const pageParams = req.body.pageParams;
            const category = req.params.category;
            const sortParams = req.body.sortParams;
            const searchTerm = req.body.searchTerm;

            if (pageParams && typeof pageParams.limit !== "undefined") {
              limit = pageParams.limit;
            }

            if (pageParams && typeof pageParams.offset !== "undefined") {
              offset = pageParams.offset;
            }

            if (sortParams && typeof sortParams.key !== "undefined") {
              key = sortParams.key;
            }

            if (sortParams && typeof sortParams.direction !== "undefined") {
              direction = sortParams.direction;
            }

            const sortQuery = {};
            sortQuery[key] = direction;

            switch (category) {
              case "all":
                break;
              case "open":
                query["$or"] = [
                  {
                    "taskStatus.code": "TS10001",
                  },
                  {
                    "taskStatus.code": "TS10003",
                  },
                ];
                break;
              case "assigned":
                query["$or"] = [
                  {
                    level1Users: {
                      $in: [req.payload.email],
                    },
                  },
                  {
                    level2Users: {
                      $in: [req.payload.email],
                    },
                  },
                ];
                break;
              case "overdue":
                const currentDate = new Date().toISOString();
                query["$and"] = [
                  {
                    $or: [
                      {
                        "taskStatus.code": "TS10001",
                      },
                      {
                        "taskStatus.code": "TS10003",
                      },
                    ],
                  },
                  {
                    dueDate: {
                      $lte: currentDate,
                    },
                  },
                ];
                break;
              case "completed":
                query["$or"] = [
                  {
                    "taskStatus.code": "TS10002",
                  },
                  {
                    "taskStatus.code": "TS10004",
                  },
                ];
                break;
              default:
            }

            if (typeof config.projectId !== "undefined") {
              query.projectId = req.params.project;
            }

            if (config.location) {
              query["workLocation.locationId"] = {
                $in: config.location,
              };
            }

            if (config.workPackage) {
              query["workPackage.tradeId"] = {
                $in: config.workPackage,
              };
            }

            if (config.punchListId) {
              query["punchListId"] = {
                $in: config.punchListId,
              };
            }

            if (config.priority) {
              query["taskPriority.code"] = config.priority;
            }

            if (config.assignee) {
              query["$or"] = [
                {
                  level1Users: {
                    $in: config.assignee,
                  },
                },

                {
                  level2Users: {
                    $in: config.assignee,
                  },
                },
              ];
            }

            if (config.isNonConformity) {
              query.isNonConformity = config.isNonConformity;
            }

            if (config.startDate && config.endDate) {
              const endDate = new Date(config.endDate);
              endDate.setDate(endDate.getDate() + 1);
              query["dueDate"] = {
                $gte: config.startDate,
                $lt: endDate.toISOString(),
              };
            } else if (config.startDate) {
              query["dueDate"] = {
                $gte: config.startDate,
              };
            } else if (config.endDate) {
              const endDate = new Date(config.endDate);
              endDate.setDate(endDate.getDate() + 1);
              query["dueDate"] = {
                $lt: endDate.toISOString(),
              };
            }

            if (config.createdStartDate && config.createdEndDate) {
              const createdEndDate = new Date(config.createdEndDate);
              createdEndDate.setDate(createdEndDate.getDate() + 1);
              query["createdAt"] = {
                $gte: config.createdStartDate,
                $lt: createdEndDate.toISOString(),
              };
            } else if (config.createdStartDate) {
              query["createdAt"] = {
                $gte: config.createdStartDate,
              };
            } else if (config.createdEndDate) {
              const createdEndDate = new Date(config.createdEndDate);
              createdEndDate.setDate(createdEndDate.getDate() + 1);
              query["createdAt"] = {
                $lt: createdEndDate.toISOString(),
              };
            }

            query["isActive"] = true;
            query["projectId"] = req.params.project;

            if (typeof searchTerm !== "undefined" && searchTerm !== "") {
              query["$and"] = [
                {
                  $or: [
                    {
                      taskDescription: {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workPackage.tradeName": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workLocation.level1": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workLocation.level2": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workLocation.level3": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workLocation.level4": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      punchId: {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "taskPriority.desc": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                  ],
                },
              ];
            }
            if (category.toLowerCase() === "onsite") {
              await Promise.all([
                OnsiteTask.find(query)
                  .limit(Number(limit))
                  .skip(Number(offset))
                  .sort(sortQuery)
                  .exec(),
                OnsiteTask.countDocuments(query).exec(),
              ]).then((results) => {
                const punchItems = results[0];
                const itemCount = results[1];

                res.json({
                  punchItems: punchItems,
                  itemCount: itemCount,
                });
              });
            } else {
              await Promise.all([
                ProjectTask.find(query)
                  .limit(Number(limit))
                  .skip(Number(offset))
                  .sort(sortQuery)
                  .exec(),
                ProjectTask.countDocuments(query).exec(),
              ]).then((results) => {
                const punchItems = results[0];
                const itemCount = results[1];

                res.json({
                  punchItems: punchItems,
                  itemCount: itemCount,
                });
              });
            }
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// Paginated snag results API
router.post(
  "/:project/paginate/:category",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const query = {};
            //Accept custom page number and pagesize
            const { page = 1, limit = 20 } = req.query;

            const config = req.body.config.filters;
            const searchTerm = req.body.searchTerm;
            const category = req.params.category;

            const options = {
              page,
              limit,
              sort: {
                createdAt: -1,
              },
            };

            switch (category) {
              case "all":
                break;
              case "open":
                query["$or"] = [
                  {
                    "taskStatus.code": "TS10001",
                  },
                  {
                    "taskStatus.code": "TS10003",
                  },
                ];
                break;
              case "assigned":
                query["$or"] = [
                  {
                    level1Users: {
                      $in: [req.payload.email],
                    },
                  },
                  {
                    level2Users: {
                      $in: [req.payload.email],
                    },
                  },
                ];
                break;
              case "overdue":
                const currentDate = new Date().toISOString();
                query["$and"] = [
                  {
                    $or: [
                      {
                        "taskStatus.code": "TS10001",
                      },
                      {
                        "taskStatus.code": "TS10003",
                      },
                    ],
                  },
                  {
                    dueDate: {
                      $lte: currentDate,
                    },
                  },
                ];
                break;
              case "completed":
                query["$or"] = [
                  {
                    "taskStatus.code": "TS10002",
                  },
                  {
                    "taskStatus.code": "TS10004",
                  },
                ];
                break;
              default:
            }

            if (typeof config.projectId !== "undefined") {
              query.projectId = req.params.project;
            }

            if (typeof searchTerm !== "undefined" && searchTerm !== "") {
              query["$and"] = [
                {
                  $or: [
                    {
                      taskDescription: {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workPackage.tradeName": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workLocation.level1": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workLocation.level2": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workLocation.level3": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "workLocation.level4": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      punchId: {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                    {
                      "taskPriority.desc": {
                        $regex: searchTerm,
                        $options: "i",
                      },
                    },
                  ],
                },
              ];
            }

            if (config.location) {
              query["workLocation.locationId"] = {
                $in: config.location,
              };
            }

            if (config.workPackage) {
              query["workPackage.tradeId"] = {
                $in: config.workPackage,
              };
            }

            if (config.priority) {
              query["taskPriority.code"] = config.priority;
            }

            if (config.assignee) {
              query["$or"] = [
                {
                  level1Users: {
                    $in: config.assignee,
                  },
                },

                {
                  level2Users: {
                    $in: config.assignee,
                  },
                },
              ];
            }

            if (config.punchListId) {
              query["punchListId"] = {
                $in: config.punchListId,
              };
            }

            if (config.isNonConformity) {
              query.isNonConformity = config.isNonConformity;
            }

            if (config.startDate) {
              query["dueDate"] = {
                $gte: config.startDate,
              };
            }

            if (config.endDate) {
              query["dueDate"] = {
                $lte: config.endDate,
              };
            }

            query["isActive"] = true;
            query["projectId"] = req.params.project;
            if (category.toLowerCase() === "onsite") {
              await Promise.all([OnsiteTask.paginate(query, options)]).then(
                (results) => {
                  let snagsResponse = {};
                  snagsResponse.snagsList = results[0].docs;
                  snagsResponse.paginationMetaData = populatePaginationMetaData(
                    results[0]
                  );

                  res.json({
                    snagsResponse,
                  });
                }
              );
            } else {
              await Promise.all([ProjectTask.paginate(query, options)]).then(
                (results) => {
                  let snagsResponse = {};
                  snagsResponse.snagsList = results[0].docs;
                  snagsResponse.paginationMetaData = populatePaginationMetaData(
                    results[0]
                  );

                  res.json({
                    snagsResponse,
                  });
                }
              );
            }
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/punchitem/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await Promise.all([req.task.execPopulate()])
              .then(() => {
                res.json({
                  punchItem: req.task,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/punchitem/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const log = Utils.generateLogObject(
              req.payload,
              `Deleted a punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
              },
              ["isActive"],
              "Active",
              "Deleted"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            const logs = req.task.logs;
            logs.push(log);
            await ProjectTask.findOneAndUpdate(
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
              },
              {
                $set: {
                  isActive: false,
                  logs: logs,
                },
              }
            )
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// create a new punch item
router.post("/:project/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          const task = req.body.punchItem;
          const punchItem = new ProjectTask();
          punchItem.taskId = uuid.v4();
          punchItem.projectId = req.project.projectId;
          punchItem.taskDescription = task.taskDescription;
          punchItem.remark = task.remark;
          punchItem.createdBy = req.payload.email;
          punchItem.updatedBy = req.payload.email;

          const log = Utils.generateLogObject(
            req.payload,
            `Created a punch item: ${punchItem.taskId}`,
            {
              projectId: req.project.projectId,
              taskId: punchItem.id,
            },
            [],
            "",
            "Active"
          );
          const logs = [];
          logs.push(log);
          punchItem.logs = logs;

          await punchItem
            .save()
            .then((newPunchItem) => {
              res.json({
                punchItem: newPunchItem,
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    ).catch(next);
  } else {
    res.sendStatus(403);
  }
});

// update punch item
router.put(
  "/:project/punchitem/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.punchItem) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const task = req.body.punchItem;
            const fieldNames = [];

            if (typeof task.taskDescription !== "undefined") {
              req.task.taskDescription.trim() !== task.taskDescription.trim()
                ? fieldNames.push("taskDescription")
                : null;
              req.task.taskDescription = task.taskDescription.trim();
            }

            if (typeof task.remark !== "undefined") {
              req.task.remark.trim() !== task.remark.trim()
                ? fieldNames.push("remark")
                : null;
              req.task.remark = task.remark.trim();
            }

            if (typeof task.dueDate !== "undefined") {
              req.task.dueDate !== task.dueDate
                ? fieldNames.push("dueDate")
                : null;
              req.task.dueDate = task.dueDate;
            }

            if (typeof task.tags !== "undefined") {
              req.task.tags && !_.isEqual(req.task.tags, task.tags)
                ? fieldNames.push("tags")
                : null;
              req.task.tags = task.tags;
            }

            if (typeof task.taskPriority !== "undefined") {
              req.task.taskPriority &&
              req.task.taskPriority.code !== task.taskPriority.code
                ? fieldNames.push("taskPriority")
                : null;
              req.task.taskPriority = task.taskPriority;
            }

            if (
              "mediaList" in req.body.punchItem &&
              req.body.punchItem.mediaList.length > 0
            ) {
              const mediaListTemp = [];
              for (const media of req.body.punchItem.mediaList) {
                media.mediaCreateDate = moment
                  .utc()
                  .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
                mediaListTemp.push(media);
              }
              if ("mediaList" in req.task) {
                req.task.mediaList.push(...mediaListTemp);
              } else {
                req.task.mediaList = mediaListTemp;
              }
            }

            req.task.updatedBy = req.payload.email;
            const log = Utils.generateLogObject(
              req.payload,
              `Updated a punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
              },
              fieldNames,
              "Active",
              "Active"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            req.task.logs.push(log);
            await req.task
              .save()
              .then((task) => {
                res.json({
                  punchItem: task,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/punchitem/:task/savePunchItemAnnotation",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.maState) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await ProjectTask.updateOne(
              {
                taskId: req.params.task,
                "mediaList.mediaId": req.body.mediaId,
              },
              {
                $set: {
                  "mediaList.$.maState": req.body.maState,
                },
              }
            )
              .then((data) => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// update punch item
router.put(
  "/:project/punchitem/floorplan/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.floorPlan) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const fp = req.body.floorPlan;
            req.task.floorPlan = {
              blobReference: fp.blobReference,
              features: fp.features ? fp.features : null,
              latestSnapshotBlobId: fp.latestSnapshotBlobId
                ? fp.latestSnapshotBlobId
                : null,
            };
            req.task.updatedBy = req.payload.email;

            const log = Utils.generateLogObject(
              req.payload,
              `Added floor plan to punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
                floorPlan: req.task.floorPlan,
              },
              ["floorplan"],
              "Active",
              "Active"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            req.task.logs.push(log);

            await req.task
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// update punch item
router.put(
  "/:project/punchitem/media/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.media) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const media = req.body.media;

            let state;
            if (
              req.task.level1Status.status.code === "VS10001" &&
              req.task.level2Status.status.code === "VS10001"
            ) {
              state = "created";
            } else if (
              req.task.level1Status.status.code !== "VS10001" &&
              req.task.level2Status.status.code === "VS10001"
            ) {
              state = "level1Updated";
            } else if (req.task.level2Status.status.code !== "VS10001") {
              state = "level2Updated";
            }

            req.task.mediaList.push({
              blobReference: media.blobReference,
              fileName: media.fileName,
              mediaId: media.mediaId,
              mediaCreateDate: moment
                .utc()
                .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
              state: media.state ? media.state : state,
              // features: media.features ? media.features : null,
            });

            req.task.updatedBy = req.payload.email;

            const log = Utils.generateLogObject(
              req.payload,
              `Added media to punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
                mediaId: media.mediaId,
              },
              ["mediaList"],
              "Active",
              "Active"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            req.task.logs.push(log);

            await req.task
              .save()
              .then(() => {
                res.json({
                  mediaList: req.task.mediaList,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// update punch item
router.put(
  "/:project/punchitem/reassign/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.users) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const users = req.body.users;
            const fieldNames = [];
            if (typeof users.user1 !== "undefined") {
              !_.isEqual(users.user1, req.task.level1Users)
                ? fieldNames.push("level1Users")
                : null;
              req.task.level1Users = users.user1;
            }

            if (typeof users.user2 !== "undefined") {
              !_.isEqual(users.user2, req.task.level2Users)
                ? fieldNames.push("level2Users")
                : null;
              req.task.level2Users = users.user2;
            }

            req.task.updatedBy = req.payload.email;

            const log = Utils.generateLogObject(
              req.payload,
              `Updated Assignee(s) in punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
              },
              fieldNames,
              "Active",
              "Active"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            req.task.logs.push(log);

            await req.task
              .save()
              .then((task) => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// resolve level1
router.put(
  "/:project/punchitem/resolve/level1/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.taskStatus) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let mailTemplateData = {};
            let mailTo = [];
            const taskStatus = req.body.taskStatus;
            const prevStatus = req.task.level1Status.status.desc;
            const newStatus = taskStatus.status.desc;
            if (req.task.level1Users.includes(req.payload.email)) {
              req.task.level1Status = {
                status: taskStatus.status,
                comment: taskStatus.comment,
                verifiedBy: req.payload.email,
              };
              await LookUp.findOne({
                type: "verificationStatus",
                key: "VS10001",
              })
                .then((data) => {
                  req.task.level2Status.status = {
                    code: data.key,
                    desc: data.value,
                  };
                })
                .catch(next);
              req.task.updatedBy = req.payload.email;

              // mail data preparation
              mailTemplateData.projectName = req.project.projectName;
              mailTemplateData.punchItemId = req.task.punchId;
              mailTemplateData.workTrade = req.task.workPackage.tradeName;
              mailTemplateData.priority = req.task.taskPriority.desc;
              mailTemplateData.description = req.task.taskDescription;
              mailTemplateData.dueDate = moment(req.task.dueDate)
                .tz("Asia/Kolkata")
                .format("DD MMM, YYYY");
              mailTemplateData.overallStatus = req.task.taskStatus.desc;
              mailTemplateData.level1Status =
                req.task.level1Status.status.desc.trim();
              mailTemplateData.level1ApproverComment =
                req.task.level1Status.comment;
              mailTemplateData.level2Status =
                req.task.level2Status.status.desc.trim();
              mailTemplateData.level2ApproverComment =
                req.task.level2Status.comment;
              for (let person of req.task.level1Users) {
                const user = req.project.users.find(
                  (projectUser) => projectUser.email === person
                );
                if (user) {
                  mailTo.push({
                    email: user.email,
                    firstName: user.firstName,
                    name: `${user.firstName} ${user.lastName}`,
                  });
                }
              }
              for (let person of req.task.level2Users) {
                const user = req.project.users.find(
                  (projectUser) => projectUser.email === person
                );
                if (user) {
                  mailTo.push({
                    email: user.email,
                    firstName: user.firstName,
                    name: `${user.firstName} ${user.lastName}`,
                  });
                }
              }

              mailTo = _.uniqBy(mailTo, "email");
              const updatedByPerson = mailTo.find((person) => {
                return (
                  person.email.toLowerCase() === req.payload.email.toLowerCase()
                );
              });

              mailTemplateData.updatedBy = updatedByPerson
                ? updatedByPerson.name
                : req.payload.email;
              mailTemplateData.updateFor = "Level 1";

              const log = Utils.generateLogObject(
                req.payload,
                `Level 1 Approver updated punch item: ${req.task.punchId} status from: ${prevStatus} to: ${newStatus}`,
                {
                  projectId: req.project.projectId,
                  taskId: req.task.taskId,
                },
                ["level1Status"],
                "Active",
                "Active"
              );
              if (!req.task.logs) {
                req.task.logs = [];
              }
              req.task.logs.push(log);

              if (
                "mediaList" in req.body.taskStatus &&
                req.body.taskStatus.mediaList.length > 0
              ) {
                const mediaListTemp = [];
                for (const media of req.body.taskStatus.mediaList) {
                  media.mediaCreateDate = moment
                    .utc()
                    .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
                  mediaListTemp.push(media);
                }
                if ("mediaList" in req.task) {
                  req.task.mediaList.push(...mediaListTemp);
                } else {
                  req.task.mediaList = mediaListTemp;
                }
              }

              await req.task
                .save()
                .then(async (task) => {
                  const [mailSentError, mailSentStatus] =
                    await Utils.sendPunchlistUpdateEmail(
                      mailTo,
                      mailTemplateData,
                      task,
                      req.payload.email
                    );
                  if (mailSentError) {
                    Logger.error(
                      "Error while sending punchlist update mail: ",
                      JSON.stringify(mailSentError)
                    );
                  }
                  res.json({
                    punchItem: task,
                  });
                })
                .catch(next);

              let notificationUserEmails = _.uniq([
                ...req.task.level2Users,
                req.task.createdBy,
              ]);

              let data = {
                messageType: "NT0002",
                appType: "APP001",
                updatedByName:
                  req.payload.firstName + " " + req.payload.lastName,
                notificationUserEmails,
                snagStatus: req.task.level1Status.status.desc.trim(),
                trade: req.task.workPackage.tradeName,
                ...req.project.toObject(),
                metaData: {
                  actionType: "SnagUpdate",
                  punchId: req.task.punchId,
                },
              };

              req.notificationData = await prepareNotificationData(data);
              next();
            } else {
              res.sendStatus(401);
            }
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  },
  notificationMiddleWare
);

// resolve level2
router.put(
  "/:project/punchitem/resolve/level2/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.taskStatus) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let mailTemplateData = {};
            let mailTo = [];
            const taskStatus = req.body.taskStatus;
            const prevStatus = req.task.level2Status.status.desc;
            const newStatus = taskStatus.status.desc;
            if (req.task.level2Users.includes(req.payload.email)) {
              req.task.level2Status = {
                status: taskStatus.status,
                comment: taskStatus.comment,
                verifiedBy: req.payload.email,
              };
              req.task.updatedBy = req.payload.email;
              let punchStatus = "";

              switch (taskStatus.status.code) {
                case "VS10001":
                  punchStatus = "TS10001";
                  break;
                case "VS10002":
                  punchStatus = "TS10002";
                  break;
                case "VS10003":
                  punchStatus = "TS10003";
                  break;
                case "VS10004":
                  punchStatus = "TS10004";
                  break;
                default:
                  punchStatus = "TS10001";
              }

              await LookUp.findOne({
                type: "taskStatus",
                key: punchStatus,
              })
                .then((data) => {
                  req.task.taskStatus = {
                    code: data.key,
                    desc: data.value,
                  };
                })
                .catch(next);

              // mail data preparation
              mailTemplateData.projectName = req.project.projectName;
              mailTemplateData.punchItemId = req.task.punchId;
              mailTemplateData.workTrade = req.task.workPackage.tradeName;
              mailTemplateData.priority = req.task.taskPriority.desc;
              mailTemplateData.description = req.task.taskDescription;
              mailTemplateData.dueDate = moment(req.task.dueDate)
                .tz("Asia/Kolkata")
                .format("DD MMM, YYYY");
              mailTemplateData.overallStatus = req.task.taskStatus.desc;
              mailTemplateData.level1Status =
                req.task.level1Status.status.desc.trim();
              mailTemplateData.level1ApproverComment =
                req.task.level1Status.comment.trim();
              mailTemplateData.level2Status =
                req.task.level2Status.status.desc.trim();
              mailTemplateData.level2ApproverComment =
                req.task.level2Status.comment.trim();
              for (let person of req.task.level1Users) {
                const user = req.project.users.find(
                  (projectUser) => projectUser.email === person
                );
                if (user) {
                  mailTo.push({
                    email: user.email,
                    firstName: user.firstName,
                    name: `${user.firstName} ${user.lastName}`,
                  });
                }
              }
              for (let person of req.task.level2Users) {
                const user = req.project.users.find(
                  (projectUser) => projectUser.email === person
                );
                if (user) {
                  mailTo.push({
                    email: user.email,
                    firstName: user.firstName,
                    name: `${user.firstName} ${user.lastName}`,
                  });
                }
              }

              mailTo = _.uniqBy(mailTo, "email");
              const updatedByPerson = mailTo.find((person) => {
                return (
                  person.email.toLowerCase() === req.payload.email.toLowerCase()
                );
              });

              mailTemplateData.updatedBy = updatedByPerson
                ? updatedByPerson.name
                : req.payload.email;
              mailTemplateData.updateFor = "Level 2";

              const log = Utils.generateLogObject(
                req.payload,
                `Level 2 Approver updated punch item: ${req.task.punchId} status from: ${prevStatus} to: ${newStatus}`,
                {
                  projectId: req.project.projectId,
                  taskId: req.task.taskId,
                },
                ["level2Status"],
                "Active",
                "Active"
              );
              if (!req.task.logs) {
                req.task.logs = [];
              }
              req.task.logs.push(log);

              if (
                "mediaList" in req.body.taskStatus &&
                req.body.taskStatus.mediaList.length > 0
              ) {
                const mediaListTemp = [];
                for (const media of req.body.taskStatus.mediaList) {
                  media.mediaCreateDate = moment
                    .utc()
                    .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
                  mediaListTemp.push(media);
                }
                if ("mediaList" in req.task) {
                  req.task.mediaList.push(...mediaListTemp);
                } else {
                  req.task.mediaList = mediaListTemp;
                }
              }

              await req.task
                .save()
                .then(async (task) => {
                  const [mailSentError, mailSentStatus] =
                    await Utils.sendPunchlistUpdateEmail(
                      mailTo,
                      mailTemplateData,
                      task,
                      req.payload.email
                    );
                  if (mailSentError) {
                    Logger.error(
                      "Error while sending punchlist update mail: ",
                      JSON.stringify(mailSentError)
                    );
                  }
                  res.json({
                    punchItem: task,
                  });
                })
                .catch(next);

              let notificationUserEmails = _.uniq([
                ...req.task.level1Users,
                req.task.createdBy,
              ]);

              let data = {
                messageType: "NT0002",
                appType: "APP001",
                ...req.project.toObject(),
                updatedByName:
                  req.payload.firstName + " " + req.payload.lastName,
                notificationUserEmails,
                snagStatus: req.task.level2Status.status.desc.trim(),
                trade: req.task.workPackage.tradeName,
                metaData: {
                  punchId: req.task.punchId,
                  actionType: "SnagUpdate",
                },
              };

              req.notificationData = await prepareNotificationData(data);
              next();
            } else {
              res.sendStatus(401);
            }
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  },
  notificationMiddleWare
);

//remove media
router.delete(
  "/:project/punchitem/:task/:mediaId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const log = Utils.generateLogObject(
              req.payload,
              `Deleted media from punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
                mediaId: req.params.mediaId,
              },
              ["mediaList"],
              "Active",
              "Active"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            req.task.logs.push(log);

            await ProjectTask.findOneAndUpdate(
              {
                taskId: req.task.taskId,
              },
              {
                $pull: {
                  mediaList: {
                    mediaId: req.params.mediaId,
                  },
                },
              },
              {
                new: true,
              }
            )
              .then((task) => {
                res.json({
                  task: task,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

//Bulk delete media
router.put(
  "/:project/punchitem/:task/bulkdeletemedia",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const log = Utils.generateLogObject(
              req.payload,
              `Bulk deleted media from punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
                mediaId: req.body.mediaIds,
              },
              ["mediaList"],
              "Active",
              "Active"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            req.task.logs.push(log);
            const logs = req.task.logs;

            await ProjectTask.findOneAndUpdate(
              {
                taskId: req.task.taskId,
              },
              {
                $pull: {
                  mediaList: {
                    mediaId: {
                      $in: req.body.mediaIds,
                    },
                  },
                },
                $set: {
                  logs: logs,
                },
              },
              {
                new: true,
              }
            )
              .then((task) => {
                res.json({
                  task: task,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

//create a new punch item
router.post(
  "/:project/bulk",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const emailTemplateParams = {};
            let mailTo = [];
            let snagList = [];
            const projectName = req.project.projectName;
            const projectLocation = req.project.location;
            emailTemplateParams.locations = [];
            emailTemplateParams.level1Assignee = [];
            emailTemplateParams.level2Assignee = [];
            emailTemplateParams.projectName = projectName;

            const punchItems = req.body.punchList.punchItems;
            const onsiteTaskId = req.body.punchList.onsiteTaskId;
            const locations = Array.isArray(req.body.punchList.locations)
              ? req.body.punchList.locations
              : [req.body.punchList.locations];
            const workPackageId = req.body.punchList.workPackageId;
            const dueDate = req.body.punchList.dueDate;
            const punchListId = req.body.punchList.punchListId
              ? req.body.punchList.punchListId
              : "NC";

            const stage1Approver = Array.isArray(
              req.body.punchList.stage1Approver
            )
              ? req.body.punchList.stage1Approver
              : [req.body.punchList.stage1Approver];
            const stage2Approver = Array.isArray(
              req.body.punchList.stage2Approver
            )
              ? req.body.punchList.stage2Approver
              : [req.body.punchList.stage2Approver];

            const masterData = await MasterData.findOne({
              projectId: req.params.project,
            });

            const workPackage = masterData.workPackage.find(
              (wp) => wp.tradeId === workPackageId
            );

            let taskPriority = {};
            let verificationStatus = {};
            let taskStatus = {};

            await LookUp.findOne({
              type: "taskPriority",
              key: "TP10001",
            })
              .then((data) => {
                taskPriority = {
                  code: data.key,
                  desc: data.value,
                };
              })
              .catch(next);

            await LookUp.findOne({
              type: "verificationStatus",
              key: "VS10001",
            })
              .then((data) => {
                verificationStatus = {
                  code: data.key,
                  desc: data.value,
                };
              })
              .catch(next);

            await LookUp.findOne({
              type: "taskStatus",
              key: "TS10001",
            })
              .then((data) => {
                taskStatus = {
                  code: data.key,
                  desc: data.value,
                };
              })
              .catch(next);

            emailTemplateParams.workTrade = workPackage.tradeName;
            if (
              (punchListId === "NC" || punchListId === "OB") &&
              punchItems[0].isNonConformity
            ) {
              emailTemplateParams.priority =
                punchItems[0].taskPriority && punchItems[0].taskPriority.desc
                  ? punchItems[0].taskPriority.desc
                  : taskPriority.desc;
            } else {
              emailTemplateParams.priority = taskPriority.desc;
              emailTemplateParams.punchListItems = [];
            }

            emailTemplateParams.punchListId = punchListId;
            emailTemplateParams.dueDate = moment(dueDate)
              .tz("Asia/Kolkata")
              .format("DD MMM, YYYY");
            for (let person of stage1Approver) {
              const user = req.project.users.find(
                (projectUser) => projectUser.email === person
              );
              if (user) {
                emailTemplateParams.level1Assignee.push(
                  `${user.firstName} ${user.lastName}`
                );
                mailTo.push({
                  email: user.email,
                  firstName: user.firstName,
                  name: `${user.firstName} ${user.lastName}`,
                });
              }
            }
            for (let person of stage2Approver) {
              const user = req.project.users.find(
                (projectUser) => projectUser.email === person
              );
              if (user) {
                emailTemplateParams.level2Assignee.push(
                  `${user.firstName} ${user.lastName}`
                );
                mailTo.push({
                  email: user.email,
                  firstName: user.firstName,
                  name: `${user.firstName} ${user.lastName}`,
                });
              }
            }

            mailTo = _.uniqBy(mailTo, "email");
            const locationCount = {};
            asyncPackage.each(
              locations,
              (location, callback) => {
                asyncPackage.each(
                  punchItems,
                  (task, callbackTask) => {
                    const punchItem = new ProjectTask();
                    punchItem.taskId = uuid.v4();
                    punchItem.punchId = generateUID();
                    punchItem.punchListId = punchListId;
                    punchItem.projectId = req.project.projectId;
                    punchItem.taskDescription = task.taskDescription;
                    punchItem.workPackage = workPackage;
                    punchItem.remark = task.remark;
                    punchItem.dueDate = task.dueDate ? task.dueDate : dueDate;
                    //                    : moment(dueDate).tz("Asia/Kolkata").format("DD/MM/YYYY");
                    const workLocationDetails = masterData.workLocation.find(
                      (loc) => loc.locationId === location
                    );
                    let emailLoc = workLocationDetails.level1;
                    workLocationDetails.level2
                      ? (emailLoc += " / " + workLocationDetails.level2)
                      : null;
                    workLocationDetails.level3
                      ? (emailLoc += " / " + workLocationDetails.level3)
                      : null;
                    workLocationDetails.level4
                      ? (emailLoc += " / " + workLocationDetails.level4)
                      : null;
                    if (locationCount[emailLoc] == undefined) {
                      locationCount[emailLoc] = 1;
                    } else {
                      locationCount[emailLoc] += 1;
                    }

                    emailTemplateParams.description = task.taskDescription;
                    punchItem.workLocation = workLocationDetails;

                    if (punchListId !== "NC" && punchListId !== "OB") {
                      emailTemplateParams.punchListItems.push(
                        `<tr style=\"border:1px solid #000\">
                      <td style=\"border:1px solid #000\"><strong>${
                        punchItem.punchId
                      }</strong></td>
                      <td style=\"border:1px solid #000\"><strong>${
                        punchItem.taskDescription
                      }</strong></td><td style=\"border:1px solid #000\"><strong>${moment(
                          punchItem.dueDate
                        )
                          .tz("Asia/Kolkata")
                          .format(
                            "DD MMM, YYYY"
                          )}</strong></td><td style=\"border:1px solid #000\"><strong>${
                          punchItem.remark
                        }</strong></td></tr>`
                      );
                    }

                    let parentFloorplanLocationDetails;

                    if (Array.isArray(task.features)) {
                      parentFloorplanLocationDetails =
                        masterData.workLocation.find(
                          (loc) =>
                            loc.locationId ===
                            task.features.find(
                              (item) => item.locationId === location
                            )?.parentFloorplanLocationId
                        );
                    }

                    if (parentFloorplanLocationDetails?.drawing) {
                      punchItem.floorPlan = {
                        features: task.features?.find(
                          (item) => item.locationId === location
                        )?.features,
                        blobReference:
                          parentFloorplanLocationDetails.drawing.blobContentId,
                        latestSnapshotBlobId: task.latestSnapshotBlobId?.find(
                          (item) => item.locationId === location
                        )?.latestSnapshotBlobId,
                      };
                    } else if (workLocationDetails.drawing) {
                      // Add floor plan and mediaList if provided
                      punchItem.floorPlan = {
                        features: Array.isArray(task.features)
                          ? null
                          : task.features
                          ? task.features
                          : null,
                        blobReference:
                          workLocationDetails.drawing.blobContentId,
                        latestSnapshotBlobId: Array.isArray(
                          task.latestSnapshotBlobId
                        )
                          ? null
                          : task.latestSnapshotBlobId
                          ? task.latestSnapshotBlobId
                          : null,
                      };
                    }

                    punchItem.mediaList = [];
                    if (task.mediaList && Array.isArray(task.mediaList)) {
                      for (let media of task.mediaList) {
                        media.mediaCreateDate = moment
                          .utc()
                          .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
                        punchItem.mediaList.push(media);
                      }
                    }

                    if (task.taskPriority && task.taskPriority.code) {
                      punchItem.taskPriority = task.taskPriority;
                    } else {
                      punchItem.taskPriority = taskPriority;
                    }

                    punchItem.isNonConformity = task.isNonConformity
                      ? task.isNonConformity
                      : false;

                    for (const element of stage1Approver) {
                      punchItem.level1Users.push(element);
                    }

                    for (const element of stage2Approver) {
                      punchItem.level2Users.push(element);
                    }

                    punchItem.level1Status = {
                      status: verificationStatus,
                      comment: "",
                      verifiedBy: "",
                    };
                    punchItem.level2Status = {
                      status: verificationStatus,
                      comment: "",
                      verifiedBy: "",
                    };

                    punchItem.taskStatus = taskStatus;

                    punchItem.createdBy = req.payload.email;
                    punchItem.updatedBy = req.payload.email;
                    punchItem.isActive = true;

                    const log = Utils.generateLogObject(
                      req.payload,
                      `Created a punch item: ${punchItem.punchId}`,
                      {
                        projectId: req.project.projectId,
                        taskId: punchItem.taskId,
                      },
                      [],
                      "",
                      "Active"
                    );
                    const logs = [];
                    logs.push(log);
                    punchItem.logs = logs;

                    punchItem.save((err, item) => {
                      if (err) {
                        Logger.error(
                          "Error while saving punchitem in endpoint post(/:project/bulk) : ",
                          err
                        );
                      }
                      snagList.push(item);
                      callbackTask();
                    });
                  },
                  (err) => {
                    callback();
                  }
                );
              },
              async (err) => {
                if (err) {
                  res.status(500).json({
                    error: err,
                  });
                }
                if (punchListId !== "NC" && punchListId !== "OB") {
                  for (let key of Object.keys(locationCount)) {
                    emailTemplateParams.locations.push(
                      `<tr style=\"border:1px solid #000\"><td style=\"border:1px solid #000\"><strong>${key}</strong></td><td style=\"border:1px solid #000\"><strong>${locationCount[key]}</strong></td></tr>`
                    );
                  }
                }

                let mailSentError;
                let mailSentStatus;
                if (!req.project.excludeSendEmailForSnag) {
                  if (punchListId === "NC" || punchListId === "OB") {
                    [mailSentError, mailSentStatus] =
                      await Utils.sendNonConfirmityPunchlistEmailWithReport(
                        mailTo,
                        "ET10010",
                        emailTemplateParams,
                        snagList,
                        projectName,
                        projectLocation,
                        req.payload.firstName + " " + req.payload.lastName
                      );
                  } else {
                    [mailSentError, mailSentStatus] =
                      await Utils.sendConfirmityPunchlistEmail(
                        mailTo,
                        "ET10005",
                        emailTemplateParams
                      );
                  }
                  if (mailSentError) {
                    Logger.error(
                      "Error while sending Punchlist Upload Email: " +
                        mailSentError
                    );
                  }
                }
                if (!!onsiteTaskId) {
                  const onsiteTask = await OnsiteTask.findOne({
                    projectId: req.project.projectId,
                    taskId: onsiteTaskId,
                  }).exec();

                  const log = Utils.generateLogObject(
                    req.payload,
                    `Create a new Snag and deleting the onsite task item: ${onsiteTaskId}`,
                    {
                      projectId: req.project.projectId,
                      taskId: onsiteTaskId,
                    },
                    ["isActive"],
                    "Active",
                    "Deleted"
                  );
                  if (!onsiteTask.logs) {
                    onsiteTask.logs = [];
                  }
                  const logs = onsiteTask.logs;
                  logs.push(log);
                  await OnsiteTask.findOneAndUpdate(
                    {
                      projectId: req.project.projectId,
                      taskId: onsiteTaskId,
                    },
                    {
                      $set: {
                        isActive: false,
                        logs: logs,
                      },
                    }
                  );
                }
                res.json({
                  status: "success",
                });

                // Push Notifications logic
                let notificationUserEmails = _.uniq(
                  stage1Approver.concat(stage2Approver)
                );

                let data = {
                  messageType: snagList.length === 1 ? "NT0004" : "NT0005",
                  appType: "APP001",
                  createdByName:
                    req.payload.firstName + " " + req.payload.lastName,
                  notificationUserEmails,
                  numberOfSnags: snagList.length,
                  ...req.project.toObject(),
                  metaData: {
                    actionType: "SnagCreate",
                  },
                };

                req.notificationData = await prepareNotificationData(data);
                next();
              }
            );
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  },
  notificationMiddleWare
);

router.post(
  "/:project/comment/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const comment = {};
            comment.commentId = uuid.v4();
            comment.body = req.body.comment;
            comment.createdAt = moment
              .utc()
              .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
            comment.createdByName =
              req.payload.firstName + " " + req.payload.lastName;
            comment.createdByEmail = req.payload.email;

            req.task.comments.push(comment);

            const log = Utils.generateLogObject(
              req.payload,
              `Added comment in punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
                commentId: comment.commentId,
              },
              ["comments"],
              "Active",
              "Active"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            req.task.logs.push(log);

            await req.task
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/comment/:task/:commentId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const log = Utils.generateLogObject(
              req.payload,
              `Deleted comment in punch item: ${req.task.punchId}`,
              {
                projectId: req.project.projectId,
                taskId: req.task.taskId,
                commentId: req.params.commentId,
              },
              ["comments"],
              "Active",
              "Active"
            );
            if (!req.task.logs) {
              req.task.logs = [];
            }
            req.task.logs.push(log);
            const logs = req.task.logs;

            await ProjectTask.findOneAndUpdate(
              {
                taskId: req.task.taskId,
              },
              {
                $set: {
                  logs: logs,
                },
                $pull: {
                  comments: {
                    commentId: req.params.commentId,
                  },
                },
              }
            )
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.get("/:project/comment/:task", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    let project;
    await Project.findOne({
      users: {
        $elemMatch: {
          email: req.payload.email,
        },
      },
      projectId: req.project.projectId,
    })
      .then((data) => {
        project = data;
      })
      .catch(next);

    if (project) {
      res.json({
        comments: req.task.comments,
      });
    } else {
      res.sendStatus(401);
    }
  } else {
    res.sendStatus(403);
  }
});

router.post(
  "/:project/sharereport/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.project) {
        let userList = req.body.users;
        let addSignatureFlag = req.body.addSignature;
        let signatureBlobContentId;
        let mailTo = [];

        for (let person of userList) {
          const user = req.project.users.find(
            (projectUser) => projectUser.email === person
          );
          if (user) {
            mailTo.push({
              email: user.email,
              firstName: user.firstName,
              name: `${user.firstName} ${user.lastName}`,
            });
          }
        }

        if (addSignatureFlag) {
          for (let user of req.project.users) {
            if (user.signature && user.signature.blobContentId) {
              signatureBlobContentId = user.signature.blobContentId;
            }
          }
        }

        await Utils.sendNonConfirmityPunchlistEmailWithTeam(
          mailTo,
          "ET10009",
          req.task,
          req.project.projectName,
          req.project.location,
          req.payload.firstName + " " + req.payload.lastName,
          signatureBlobContentId
        );

        res.json({
          status: "success",
        });
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/downloadpdfreport/:task",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.project) {
        const rootDir = path.dirname(path.dirname(__dirname));
        const savePath = path.join(
          rootDir,
          "temp_report",
          req.task.punchId + ".pdf"
        );
        await saveForDownloadReport(
          req.task,
          req.project.projectName,
          req.project.location,
          req.payload.firstName + " " + req.payload.lastName,
          savePath
        );
        await Utils.wait(500);

        var data = fs.readFileSync(savePath);

        res.setHeader("Content-Type", "text/plain");
        res.send(data.toString("base64"));

        fs.unlink(savePath, (_err) => {
          // console.log("File was deleted");
        });
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

const generateUID = () => {
  let out = "";
  let firstPart = (Math.random() * 46656) | 0;
  let secondPart = (Math.random() * 46656) | 0;
  firstPart = ("000" + firstPart.toString(36)).slice(-3);
  secondPart = ("000" + secondPart.toString(36)).slice(-3);
  out = firstPart + secondPart;
  return out.toUpperCase();
};

//dashboard
router.get(
  "/:project/overall/dashboard/workpackage/:type",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const type = req.params.type;
            const query = {};
            query["projectId"] = req.params.project;
            query["isActive"] = true;

            if (type === "assigned") {
              query["$or"] = [
                {
                  level1Users: {
                    $in: [req.payload.email],
                  },
                },
                {
                  level2Users: {
                    $in: [req.payload.email],
                  },
                },
              ];
            }

            await ProjectTask.aggregate([
              {
                $match: query,
              },
              {
                $group: {
                  _id: {
                    tradeName: "$workPackage.tradeName",
                  },
                  count: {
                    $sum: 1,
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  label: "$_id.tradeName",
                  count: 1,
                },
              },
            ]).exec((err, data) => {
              if (err) throw err;
              res.json({
                data: data,
              });
            });
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

//location
router.get(
  "/:project/overall/dashboard/location/:type",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const type = req.params.type;
            const query = {};
            query["projectId"] = req.params.project;
            query["isActive"] = true;

            if (type === "assigned") {
              query["$or"] = [
                {
                  level1Users: {
                    $in: [req.payload.email],
                  },
                },
                {
                  level2Users: {
                    $in: [req.payload.email],
                  },
                },
              ];
            }

            await ProjectTask.aggregate([
              {
                $match: query,
              },
              {
                $group: {
                  _id: {
                    level1: "$workLocation.level1",
                    level2: "$workLocation.level2",
                  },
                  count: {
                    $sum: 1,
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  label: {
                    $concat: ["$_id.level1", " ", "$_id.level2"],
                  },
                  count: 1,
                },
              },
            ]).exec((err, data) => {
              if (err) throw err;
              res.json({
                data: data,
              });
            });
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/overall/dashboard/status/:type",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const type = req.params.type;
            const query = {};
            query["projectId"] = req.params.project;
            query["isActive"] = true;

            if (type === "assigned") {
              query["$or"] = [
                {
                  level1Users: {
                    $in: [req.payload.email],
                  },
                },
                {
                  level2Users: {
                    $in: [req.payload.email],
                  },
                },
              ];
            }

            await ProjectTask.aggregate([
              {
                $match: query,
              },
              {
                $group: {
                  _id: {
                    taskStatus: "$taskStatus.desc",
                  },
                  count: {
                    $sum: 1,
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  label: "$_id.taskStatus",
                  count: 1,
                },
              },
            ]).exec((err, data) => {
              if (err) throw err;
              res.json({
                data: data,
              });
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/overall/dashboard/priority/:type",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const type = req.params.type;
            const query = {};
            query["projectId"] = req.params.project;
            query["isActive"] = true;

            if (type === "assigned") {
              query["$or"] = [
                {
                  level1Users: {
                    $in: [req.payload.email],
                  },
                },
                {
                  level2Users: {
                    $in: [req.payload.email],
                  },
                },
              ];
            }

            await ProjectTask.aggregate([
              {
                $match: query,
              },
              {
                $group: {
                  _id: {
                    taskPriority: "$taskPriority.desc",
                  },
                  count: {
                    $sum: 1,
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  label: "$_id.taskPriority",
                  count: 1,
                },
              },
            ]).exec((err, data) => {
              if (err) throw err;
              res.json({
                data: data,
              });
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/overall/dashboard/conformity/:type",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const type = req.params.type;
            const query = {};
            query["projectId"] = req.params.project;
            query["isActive"] = true;

            if (type === "assigned") {
              query["$or"] = [
                {
                  level1Users: {
                    $in: [req.payload.email],
                  },
                },
                {
                  level2Users: {
                    $in: [req.payload.email],
                  },
                },
              ];
            }

            await ProjectTask.aggregate([
              {
                $match: query,
              },
              {
                $group: {
                  _id: {
                    isNonConformity: "$isNonConformity",
                  },
                  count: {
                    $sum: 1,
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  label: "$_id.isNonConformity"
                    ? "Non Conformity"
                    : "Conformity",
                  count: 1,
                },
              },
            ]).exec((err, data) => {
              if (err) throw err;
              res.json({
                data: data,
              });
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/overall/dashboard/overdue/:type",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const type = req.params.type;
            let taskCount = null;
            const query = {};
            const queryInProgress = {};
            const currentDate = new Date().toISOString();
            query["projectId"] = req.params.project;
            queryInProgress["projectId"] = req.params.project;

            query["isActive"] = true;
            queryInProgress["isActive"] = true;

            if (type === "assigned") {
              query["$or"] = [
                {
                  level1Users: {
                    $in: [req.payload.email],
                  },
                },
                {
                  level2Users: {
                    $in: [req.payload.email],
                  },
                },
              ];

              queryInProgress["$or"] = [
                {
                  level1Users: {
                    $in: [req.payload.email],
                  },
                },
                {
                  level2Users: {
                    $in: [req.payload.email],
                  },
                },
              ];
            }

            queryInProgress["$and"] = [
              {
                $or: [
                  {
                    "taskStatus.code": "TS10001",
                  },
                  {
                    "taskStatus.code": "TS10003",
                  },
                ],
              },
              {
                dueDate: {
                  $gte: currentDate,
                },
              },
            ];

            query["$and"] = [
              {
                $or: [
                  {
                    "taskStatus.code": "TS10001",
                  },
                  {
                    "taskStatus.code": "TS10003",
                  },
                ],
              },
              {
                dueDate: {
                  $lte: currentDate,
                },
              },
            ];

            let overDueTask = 0;
            let inProgressTask = 0;

            await ProjectTask.countDocuments(query, (err, c) => {
              overDueTask = c;
            });

            await ProjectTask.countDocuments(queryInProgress, (err, c) => {
              inProgressTask = c;
            });

            if (overDueTask > 0 || inProgressTask > 0) {
              taskCount = [
                {
                  label: "Overdue items",
                  count: overDueTask,
                },
                {
                  label: "In Progress",
                  count: inProgressTask,
                },
              ];
            }

            res.json({
              data: taskCount,
            });
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

// used to display the snag statistics on the Android dashboard
router.get(
  "/:project/dashboard/snagstatistics",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      Project.countDocuments(
        {
          users: { $elemMatch: { email: req.payload.email } },
          projectId: req.params.project,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const currentDate = new Date().toISOString();

            let snagsCountResponse = await ProjectTask.aggregate([
              // Filter out all inactive projects and non required projects
              {
                $match: {
                  projectId: req.params.project,
                  isActive: true,
                },
              },

              // Using facet to get the count of documents based on different criterion in one go
              {
                $facet: {
                  overallCount: [{ $count: "count" }],
                  myAssignedCount: [
                    {
                      $match: {
                        $or: [
                          { level1Users: { $in: [req.payload.email] } },
                          { level2Users: { $in: [req.payload.email] } },
                        ],
                      },
                    },
                    { $count: "count" },
                  ],
                  overdueCount: [
                    {
                      $match: {
                        $and: [
                          {
                            $or: [
                              { "taskStatus.code": "TS10001" },
                              { "taskStatus.code": "TS10003" },
                            ],
                          },
                          { dueDate: { $lte: currentDate } },
                        ],
                      },
                    },
                    { $count: "count" },
                  ],
                  openCount: [
                    {
                      $match: {
                        $or: [
                          { "taskStatus.code": "TS10001" },
                          { "taskStatus.code": "TS10003" },
                        ],
                      },
                    },
                    { $count: "count" },
                  ],
                },
              },

              // Populate count as zero and add field, if no data in the above pipeline steps
              {
                $addFields: {
                  overallCount: {
                    $cond: [
                      { $eq: ["$overallCount", []] },
                      [{ count: 0 }],
                      "$overallCount",
                    ],
                  },
                  myAssignedCount: {
                    $cond: [
                      { $eq: ["$myAssignedCount", []] },
                      [{ count: 0 }],
                      "$myAssignedCount",
                    ],
                  },
                  overdueCount: {
                    $cond: [
                      { $eq: ["$overdueCount", []] },
                      [{ count: 0 }],
                      "$overdueCount",
                    ],
                  },
                  openCount: {
                    $cond: [
                      { $eq: ["$openCount", []] },
                      [{ count: 0 }],
                      "$openCount",
                    ],
                  },
                },
              },
              { $unwind: "$overallCount" },
              { $unwind: "$myAssignedCount" },
              { $unwind: "$overdueCount" },
              { $unwind: "$openCount" },

              {
                $project: {
                  overallCount: "$overallCount.count",
                  myAssignedCount: "$myAssignedCount.count",
                  overdueCount: "$overdueCount.count",
                  openCount: "$openCount.count",
                },
              },
            ]);

            const onsiteTask = await OnsiteTask.find({
              projectId: req.project.projectId,
              isActive: true,
            }).exec();

            let snagStatistics = snagsCountResponse[0];
            snagStatistics["onsiteCount"] = !!onsiteTask
              ? onsiteTask.length
              : 0;
            res.json({
              snagStatistics: snagStatistics,
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:projectId/nextseq/:punchListId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      ProjectTask.countDocuments(
        {
          punchListId: req.params.punchListId,
          projectId: req.params.projectId,
          isActive: true,
        },
        (err, c) => {
          res.json({
            totalRecords: c,
          });
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get("/:projectId/lookup/punchlist", auth.required, (req, res, next) => {
  const type = req.params.type;

  ProjectTask.find({
    projectId: req.params.projectId,
  }).distinct("punchListId", (error, ids) => {
    res.json({
      punchListId: ids,
    });
  });
});

let populatePaginationMetaData = (results) => {
  return {
    itemCount: results.totalDocs,
    itemsPerPage: results.limit,
    currentPage: results.page,
    pageCount: results.totalPages,
    hasPrevPage: results.hasPrevPage,
    hasNextPage: results.hasNextPage,
    prevPage: results.prevPage,
    nextPage: results.nextPage,
  };
};

// create a new aerial punch item
router.post(
  "/:project/aerials/bulk",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const emailTemplateParams = {};
            let mailTo = [];
            let snagList = [];
            const projectName = req.project.projectName;
            const projectLocation = req.project.location;
            emailTemplateParams.locations = [];
            emailTemplateParams.level1Assignee = [];
            emailTemplateParams.level2Assignee = [];
            emailTemplateParams.projectName = projectName;

            const punchItems = req.body.punchList.punchItems;
            const locations = Array.isArray(req.body.punchList.locations)
              ? req.body.punchList.locations
              : [req.body.punchList.locations];
            const workPackageId = req.body.punchList.workPackageId;
            const dueDate = req.body.punchList.dueDate;
            const punchListId = req.body.punchList.punchListId
              ? req.body.punchList.punchListId
              : "NC";

            const stage1Approver = Array.isArray(
              req.body.punchList.stage1Approver
            )
              ? req.body.punchList.stage1Approver
              : [req.body.punchList.stage1Approver];
            const stage2Approver = Array.isArray(
              req.body.punchList.stage2Approver
            )
              ? req.body.punchList.stage2Approver
              : [req.body.punchList.stage2Approver];

            let masterData = await MasterData.findOne({
              projectId: req.params.project,
            });

            const workPackage = masterData.workPackage.find(
              (wp) => wp.tradeId === workPackageId
            );

            let taskPriority = {};
            let verificationStatus = {};
            let taskStatus = {};

            await LookUp.findOne({
              type: "taskPriority",
              key: "TP10001",
            })
              .then((data) => {
                taskPriority = {
                  code: data.key,
                  desc: data.value,
                };
              })
              .catch(next);

            await LookUp.findOne({
              type: "verificationStatus",
              key: "VS10001",
            })
              .then((data) => {
                verificationStatus = {
                  code: data.key,
                  desc: data.value,
                };
              })
              .catch(next);

            await LookUp.findOne({
              type: "taskStatus",
              key: "TS10001",
            })
              .then((data) => {
                taskStatus = {
                  code: data.key,
                  desc: data.value,
                };
              })
              .catch(next);

            emailTemplateParams.workTrade = workPackage.tradeName;
            if (
              (punchListId === "NC" || punchListId === "OB") &&
              punchItems[0].isNonConformity
            ) {
              emailTemplateParams.priority =
                punchItems[0].taskPriority && punchItems[0].taskPriority.desc
                  ? punchItems[0].taskPriority.desc
                  : taskPriority.desc;
              emailTemplateParams.description = punchItems[0].taskDescription;
            } else {
              emailTemplateParams.priority = taskPriority.desc;
              emailTemplateParams.punchListItems = [];
            }

            emailTemplateParams.punchListId = punchListId;
            emailTemplateParams.dueDate = moment(dueDate)
              .tz("Asia/Kolkata")
              .format("DD MMM, YYYY");
            for (let person of stage1Approver) {
              const user = req.project.users.find(
                (projectUser) => projectUser.email === person
              );
              if (user) {
                emailTemplateParams.level1Assignee.push(
                  `${user.firstName} ${user.lastName}`
                );
                mailTo.push({
                  email: user.email,
                  firstName: user.firstName,
                  name: `${user.firstName} ${user.lastName}`,
                });
              }
            }
            for (let person of stage2Approver) {
              const user = req.project.users.find(
                (projectUser) => projectUser.email === person
              );
              if (user) {
                emailTemplateParams.level2Assignee.push(
                  `${user.firstName} ${user.lastName}`
                );
                mailTo.push({
                  email: user.email,
                  firstName: user.firstName,
                  name: `${user.firstName} ${user.lastName}`,
                });
              }
            }

            mailTo = _.uniqBy(mailTo, "email");

            const checkingWorkLocationDetailsAvailability =
              masterData.punchList.find(
                (punchItem) => (punchItem.tourId = req.body.punchList.tourId)
              );
            if (!checkingWorkLocationDetailsAvailability) {
              const punchListLocation = {
                location: req.body.punchList.tourName,
                locationId: generateUUID(),
                tourId: req.body.punchList.tourId,
              };

              masterData = await MasterData.findOneAndUpdate(
                { projectId: req.project.projectId },
                {
                  $push: {
                    punchList: punchListLocation,
                  },
                },
                {
                  new: true,
                }
              );
            }

            const locationCount = {};
            asyncPackage.each(
              locations,
              (location, callback) => {
                asyncPackage.each(
                  punchItems,
                  (task, callbackTask) => {
                    const punchItem = new ProjectTask();

                    punchItem.taskId = uuid.v4();
                    punchItem.punchId = generateUID();
                    punchItem.punchListId = punchListId;
                    punchItem.projectId = req.project.projectId;
                    punchItem.tourId = req.body.punchList.tourId;
                    punchItem.punchItemMarkerLat =
                      req.body.punchList.punchItemMarkerLat;
                    punchItem.punchItemMarkerLng =
                      req.body.punchList.punchItemMarkerLng;
                    punchItem.punchItemMarkerId =
                      req.body.punchList.punchItemMarkerId;

                    punchItem.markerType = req.body.punchList.markerType;
                    punchItem.punchItemPolygonMarkerId =
                      req.body.punchList.punchItemPolygonMarkerId;
                    punchItem.taskDescription = task.taskDescription;
                    punchItem.workPackage = workPackage;
                    punchItem.remark = task.remark;
                    punchItem.dueDate = task.dueDate ? task.dueDate : dueDate;
                    //                    : moment(dueDate).tz("Asia/Kolkata").format("DD/MM/YYYY");
                    const workLocationDetails = masterData.punchList.find(
                      (punchItem) =>
                        punchItem.tourId === req.body.punchList.tourId
                    );

                    let emailLoc = workLocationDetails.location;

                    workLocationDetails.level2
                      ? (emailLoc += " / " + workLocationDetails.level2)
                      : null;
                    workLocationDetails.level3
                      ? (emailLoc += " / " + workLocationDetails.level3)
                      : null;
                    workLocationDetails.level4
                      ? (emailLoc += " / " + workLocationDetails.level4)
                      : null;
                    if (locationCount[emailLoc] == undefined) {
                      locationCount[emailLoc] = 1;
                    } else {
                      locationCount[emailLoc] += 1;
                    }

                    const workLocation = {
                      locationId: workLocationDetails.locationId,
                      level1: workLocationDetails.location,
                      level2: "",
                      level3: "",
                      level4: "",
                    };

                    punchItem.workLocation = workLocation;
                    if (punchListId !== "NC" && punchListId !== "OB") {
                      emailTemplateParams.punchListItems.push(
                        `<tr style=\"border:1px solid #000\">
                      <td style=\"border:1px solid #000\"><strong>${
                        punchItem.punchId
                      }</strong></td>
                      <td style=\"border:1px solid #000\"><strong>${
                        punchItem.taskDescription
                      }</strong></td><td style=\"border:1px solid #000\"><strong>${moment(
                          punchItem.dueDate
                        )
                          .tz("Asia/Kolkata")
                          .format(
                            "DD MMM, YYYY"
                          )}</strong></td><td style=\"border:1px solid #000\"><strong>${
                          punchItem.remark
                        }</strong></td></tr>`
                      );
                    }

                    punchItem.mediaList = [];
                    if (task.mediaList && Array.isArray(task.mediaList)) {
                      for (let media of task.mediaList) {
                        media.mediaCreateDate = moment
                          .utc()
                          .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
                        punchItem.mediaList.push(media);
                      }
                    }

                    if (task.taskPriority && task.taskPriority.code) {
                      punchItem.taskPriority = task.taskPriority;
                    } else {
                      punchItem.taskPriority = taskPriority;
                    }

                    punchItem.isNonConformity = task.isNonConformity
                      ? task.isNonConformity
                      : false;

                    for (const element of stage1Approver) {
                      punchItem.level1Users.push(element);
                    }

                    for (const element of stage2Approver) {
                      punchItem.level2Users.push(element);
                    }

                    punchItem.level1Status = {
                      status: verificationStatus,
                      comment: "",
                      verifiedBy: "",
                    };
                    punchItem.level2Status = {
                      status: verificationStatus,
                      comment: "",
                      verifiedBy: "",
                    };

                    punchItem.taskStatus = taskStatus;

                    punchItem.createdBy = req.payload.email;
                    punchItem.updatedBy = req.payload.email;
                    punchItem.isActive = true;

                    const log = Utils.generateLogObject(
                      req.payload,
                      `Created a punch item: ${punchItem.punchId}`,
                      {
                        projectId: req.project.projectId,
                        taskId: punchItem.taskId,
                      },
                      [],
                      "",
                      "Active"
                    );
                    const logs = [];
                    logs.push(log);
                    punchItem.logs = logs;

                    punchItem.save((err, item) => {
                      if (err) {
                        Logger.error(
                          "Error while saving punchitem in endpoint post(/:project/aerials/bulk) : ",
                          JSON.stringify(err)
                        );
                      }
                      snagList.push(item);
                      callbackTask();
                    });
                  },
                  (err) => {
                    callback();
                  }
                );
              },
              async (err) => {
                if (err) {
                  res.status(500).json({
                    error: err,
                  });
                }
                if (punchListId !== "NC" && punchListId !== "OB") {
                  for (let key of Object.keys(locationCount)) {
                    emailTemplateParams.locations.push(
                      `<tr style=\"border:1px solid #000\"><td style=\"border:1px solid #000\"><strong>${key}</strong></td><td style=\"border:1px solid #000\"><strong>${locationCount[key]}</strong></td></tr>`
                    );
                  }
                }

                let mailSentError;
                let mailSentStatus;
                if (punchListId === "NC" || punchListId === "OB") {
                  [mailSentError, mailSentStatus] =
                    await Utils.sendNonConfirmityPunchlistEmailWithReport(
                      mailTo,
                      "ET10010",
                      emailTemplateParams,
                      snagList,
                      projectName,
                      projectLocation,
                      req.payload.firstName + " " + req.payload.lastName
                    );
                } else {
                  [mailSentError, mailSentStatus] =
                    await Utils.sendConfirmityPunchlistEmail(
                      mailTo,
                      "ET10005",
                      emailTemplateParams
                    );
                }
                if (mailSentError) {
                  Logger.error(
                    "Error while sending Punchlist Upload Email: " +
                      JSON.stringify(mailSentError)
                  );
                }

                res.json({
                  status: "success",
                });

                // Push Notifications logic
                let notificationUserEmails = _.uniq(
                  stage1Approver.concat(stage2Approver)
                );

                let data = {
                  messageType: snagList.length === 1 ? "NT0004" : "NT0005",
                  appType: "APP001",
                  createdByName:
                    req.payload.firstName + " " + req.payload.lastName,
                  notificationUserEmails,
                  numberOfSnags: snagList.length,
                  ...req.project.toObject(),
                  metaData: {
                    actionType: "SnagCreate",
                  },
                };

                req.notificationData = await prepareNotificationData(data);
                next();
              }
            );
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  },
  notificationMiddleWare
);

//get punch list details

router.get(
  "/:projectId/punchList/:tourId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      ProjectTask.find(
        {
          projectId: req.params.projectId,
          tourId: req.params.tourId,
          isActive: true,
        },
        (err, data) => {
          res.json({
            punchListData: data,
          });
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// create a new onsite snag
router.post("/:project/onsitetask", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          const task = req.body.punchList;
          const punchListId = task.punchListId ? task.punchListId : "NC";
          const workPackageId = task.workPackageId;
          const workLocationId = task?.locations[0];
          const punchItem = task?.punchItems[0];

          let masterData = await MasterData.findOne({
            projectId: req.params.project,
          });

          const workPackage = masterData.workPackage.find(
            (wp) => wp.tradeId === workPackageId
          );
          const workLocationDetails = masterData.workLocation.find(
            (loc) => loc.locationId === workLocationId
          );
          const workLocation = {
            locationId: workLocationDetails.locationId,
            level1: workLocationDetails.level1,
            level2: workLocationDetails?.level2,
            level3: workLocationDetails?.level3,
            level4: workLocationDetails?.level4,
          };
          const onsiteTask = new OnsiteTask();
          onsiteTask.taskId = uuid.v4();
          onsiteTask.projectId = req.project.projectId;
          onsiteTask.taskDescription = punchItem.taskDescription;
          onsiteTask.remark = punchItem.remark;
          onsiteTask.createdBy = req.payload.email;
          onsiteTask.updatedBy = req.payload.email;
          onsiteTask.isActive = true;
          onsiteTask.punchListId = punchListId;
          onsiteTask.isNonConformity =
            punchListId.toUpperCase() === "NC" ? true : false;

          onsiteTask.workLocation = workLocation;
          onsiteTask.workPackage = workPackage;
          onsiteTask.mediaList = punchItem.mediaList;
          const log = Utils.generateLogObject(
            req.payload,
            `Created a onsite snag item: ${onsiteTask.taskId}`,
            {
              projectId: req.project.projectId,
              taskId: onsiteTask.id,
            },
            [],
            "",
            "Active"
          );
          const logs = [];
          logs.push(log);
          onsiteTask.logs = logs;
          await onsiteTask
            .save()
            .then((newPunchItem) => {
              res.json({
                punchItem: newPunchItem,
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    ).catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.get(
  "/:projectId/onsitetask/:taskId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      OnsiteTask.findOne(
        {
          projectId: req.params.projectId,
          taskId: req.params.taskId,
          isActive: true,
        },
        (err, data) => {
          res.json({
            onsiteTask: data,
          });
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:projectId/onsitetask/all/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      OnsiteTask.find(
        {
          projectId: req.params.projectId,
          isActive: true,
        },
        (err, data) => {
          res.json({
            onsiteTaskList: data,
          });
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);
router.delete(
  "/:project/onsitetask/:taskId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const onsiteTask = await OnsiteTask.findOne({
              projectId: req.project.projectId,
              taskId: req.params.taskId,
            }).exec();

            const log = Utils.generateLogObject(
              req.payload,
              `Deleted a onsite task item: ${req.params.taskId}`,
              {
                projectId: req.project.projectId,
                taskId: req.params.taskId,
              },
              ["isActive"],
              "Active",
              "Deleted"
            );
            if (!onsiteTask.logs) {
              onsiteTask.logs = [];
            }
            const logs = onsiteTask.logs;
            logs.push(log);
            await OnsiteTask.findOneAndUpdate(
              {
                projectId: req.project.projectId,
                taskId: req.params.taskId,
              },
              {
                $set: {
                  isActive: false,
                  logs: logs,
                },
              }
            )
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      ).catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);
module.exports = router;
