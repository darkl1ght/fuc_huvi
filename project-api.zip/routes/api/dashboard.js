"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const logger = require("../../common/logger");
const Project = mongoose.model("Project");
const Rfi = mongoose.model("Rfi");
const ExteriorWBS = mongoose.model("ExteriorWBS");
const InteriorWBS = mongoose.model("InteriorWBS");
const InteriorCapture = mongoose.model("InteriorCapture");
const ProjectTask = mongoose.model("ProjectTask");
const FieldIssue = mongoose.model("FieldIssue");
const LookUp = mongoose.model("LookUp");
const auth = require("../auth");
const moment = require("moment-timezone");
const _ = require("lodash");

// Preload project objects on routes with ":project"
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

const checkActiveUserProjectAccess = async (req, res, next) => {
  const {
    project: { projectId },
    payload: { email, isAdmin },
  } = req;
  if (email && projectId) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || isAdmin) {
          next();
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
};

router.get(
  "/:project/daystocomplete/:towerId",
  auth.required,
  checkActiveUserProjectAccess,
  async (req, res, next) => {
    try {
      const {
        project: { isUnitLevel },
        params: { towerId, project: projectId },
      } = req;
      let response = {};
      let progress = {};
      const today = moment();
      let maxFinishDateExterior = today;
      let maxFinishDateInterior = today;
      const exteriorWbs = await ExteriorWBS.findOne({
        projectId,
        towerId,
      });
      if (exteriorWbs?.length > 0) {
        for (let wbs of exteriorWbs.wbsList) {
          if (moment(wbs.finishDate).isAfter(moment(maxFinishDateExterior))) {
            maxFinishDateExterior = moment(wbs.finishDate);
          }
        }
      }

      const interiorWBSTowers = await InteriorWBS.find({
        projectId,
        towerId,
      });
      if (interiorWBSTowers?.length > 0) {
        for (let floor of interiorWBSTowers) {
          for (let wbs of floor.wbsList)
            if (
              // issue here
              moment(wbs.finishDate).isSameOrAfter(
                moment(maxFinishDateInterior)
              )
            ) {
              maxFinishDateInterior = moment(wbs.finishDate);
            }
        }

        if (!isUnitLevel) {
          const { interiors: interiorTours } = await populateProject(
            req.project,
            false,
            true
          );
          let tourReadyFlag = false;
          let matchedInteriorId;
          let floorWalkthough;
          for (let interiorTour of interiorTours) {
            if (interiorTour.isActive) {
              for (let walkthroughTour of interiorTour.floorWalkthough) {
                for (let tower of walkthroughTour.tours)
                  if (tower.isPublished) {
                    tourReadyFlag = true;
                    break;
                  }
                if (tourReadyFlag) {
                  break;
                }
              }
            }
            if (tourReadyFlag) {
              ({ interiorId: matchedInteriorId, floorWalkthough } =
                interiorTour);
              break;
            }
          }

          if (tourReadyFlag && matchedInteriorId) {
            let plannedProgress = 0;
            let actualProgress = 0;
            const dataCaptureList = await InteriorCapture.find({
              projectId,
              interiorId: matchedInteriorId,
              towerId,
            })
              .select({
                wbsItem: 1,
                projectId: 1,
                interiorId: 1,
                tourId: 1,
                towerId: 1,
              })
              .exec();

            for (let walkthrough of floorWalkthough) {
              if (walkthrough.towerId === towerId) {
                plannedProgress = 0;
                actualProgress = 0;
                if (dataCaptureList?.length > 0) {
                  for (let dataCatpure of dataCaptureList) {
                    dataCatpure.wbsItem.forEach((wbs) => {
                      plannedProgress =
                        plannedProgress + wbs.planned * wbs.weightage;

                      if (wbs.actual) {
                        actualProgress =
                          actualProgress + wbs.actual * wbs.weightage;
                      }
                    });
                  }
                }

                progress = {
                  planned:
                    plannedProgress > 0.99
                      ? 100
                      : (plannedProgress * 100).toFixed(2),
                  actual:
                    actualProgress?.toFixed(2) > 99.5
                      ? 100
                      : actualProgress?.toFixed(2),
                };
                break;
              }
            }
          }
        }
      }

      if (interiorWBSTowers?.length || exteriorWbs?.length) {
        response.statusCode = "CS200";
        exteriorWbs.length &&
          (response.exterior = {
            daysToComplete: maxFinishDateExterior.diff(today, "days"),
          });
        interiorWBSTowers.length &&
          (response.interior = {
            daysToComplete: maxFinishDateInterior.diff(today, "days"),
            progress,
          });
      } else {
        response = {
          statusCode: "CS404",
        };
      }

      res.json(response);
    } catch (err) {
      logger.error(err);
      next(err);
    }
  }
);

router.put(
  "/:project/cardview",
  auth.required,
  checkActiveUserProjectAccess,
  async (req, res, next) => {
    try {
      const {
        body: {
          dashboard: { overall: overallCards, me: meCards },
        },
        project: { projectId, users: projectUsers },
        payload: { email: payloadEmail },
      } = req;

      if (overallCards || meCards) {
        const projectUser = projectUsers.find(
          ({ email }) => email === payloadEmail
        );
        if (!projectUser.dashboard) {
          const updateQuery = {};
          if (overallCards) updateQuery.overall = overallCards;
          if (meCards) updateQuery.me = meCards;
          await Project.findOneAndUpdate(
            { projectId, "users.email": payloadEmail },
            {
              $set: {
                "users.$.dashboard": updateQuery,
              },
            }
          );
          return res.json({ status: "success" });
        } else {
          if (overallCards) {
            await Project.findOneAndUpdate(
              { projectId, "users.email": payloadEmail },
              {
                $set: {
                  "users.$.dashboard.overall": overallCards,
                },
              }
            );
          }
          if (meCards) {
            await Project.findOneAndUpdate(
              { projectId, "users.email": payloadEmail },
              {
                $set: {
                  "users.$.dashboard.me": meCards,
                },
              }
            );
          }
          return res.json({ status: "success" });
        }
      } else {
        return res.status(403);
      }
    } catch (err) {
      logger.error(err);
      next(err);
    }
  }
);

router.get(
  "/:project/alltasks/d3donut/:assignee",
  auth.required,
  checkActiveUserProjectAccess,
  async (req, res, next) => {
    try {
      const assignedToUser = req.params.assignee === "user" ? true : false;

      let pendingTaskCount = 0;
      let completedTaskCount = 0;
      let overdueTaskCount = 0;
      let assignedPendingTaskCount = 0;
      let assignedCompletedTaskCount = 0;
      let assignedOverdueTaskCount = 0;
      const {
        project: { projectId },
      } = req;
      let {
        payload: { email: payloadEmail },
      } = req;
      payloadEmail = payloadEmail.toLowerCase();
      let filterQuery = {};

      filterQuery = { projectId };
      if (assignedToUser) {
        filterQuery["assignee"] = payloadEmail;
      }
      const fieldIssues = await FieldIssue.find(filterQuery);
      if (!!fieldIssues.length) {
        const groupedFieldIssues = _.groupBy(fieldIssues, (ele) => ele.status);
        for (let status of Object.keys(groupedFieldIssues)) {
          if (status === "FIS10001" || status === "FIS10002") {
            for (let issue of groupedFieldIssues[status]) {
              if (moment(issue.dueDate).isBefore(moment.now())) {
                overdueTaskCount += 1;
              } else {
                pendingTaskCount += 1;
              }
            }
          } else if (status === "FIS10003" || status === "FIS10004") {
            completedTaskCount += groupedFieldIssues[status].length;
          }
        }
      }

      filterQuery = { projectId, isActive: true };
      if (assignedToUser) {
        filterQuery["$or"] = [
          { level1Users: { $in: [payloadEmail] } },
          { level2Users: { $in: [payloadEmail] } },
        ];
      }
      const projectTasks = await ProjectTask.find(filterQuery);
      if (!!projectTasks.length) {
        for (let task of projectTasks) {
          if (task.taskStatus.code === "TS10001") {
            if (moment(task.dueDate).isBefore(moment.now())) {
              overdueTaskCount += 1;
            } else {
              pendingTaskCount += 1;
            }
          } else {
            completedTaskCount += 1;
          }
        }
      }

      filterQuery = { projectId, isActive: true };
      if (assignedToUser) {
        filterQuery["currentAssignee.email"] = payloadEmail;
      }
      const rfis = await Rfi.find(filterQuery);
      if (!!rfis.length) {
        for (let rfi of rfis) {
          if (rfi.status.key === "RFI10001" || rfi.status.key === "RFI10002") {
            pendingTaskCount += 1;
          } else {
            completedTaskCount += 1;
          }
        }
      }

      res.json([
        { label: "pending", count: pendingTaskCount },
        { label: "completed", count: completedTaskCount },
        { label: "overdue", count: overdueTaskCount },
      ]);
    } catch (err) {
      logger.error(err);
      next(err);
    }
  }
);

router.get(
  "/:project/:taskType/chart/:chartType/:assignee",
  auth.required,
  checkActiveUserProjectAccess,
  async (req, res, next) => {
    try {
      const assignedToUser = req.params.assignee === "user" ? true : false;
      let labels;
      let statusCount;
      const {
        project: { projectId },
        params: { taskType: taskType, chartType: chartType },
      } = req;
      let {
        payload: { email: payloadEmail },
      } = req;
      payloadEmail = payloadEmail.toLowerCase();

      let response;
      let filterQuery = {};
      switch (taskType) {
        case "rfi":
          filterQuery = { projectId, isActive: true };
          if (assignedToUser) {
            filterQuery["currentAssignee.email"] = payloadEmail;
          }
          const rfiStatusLookUps = (
            await LookUp.find({ type: "rfiStatus" })
          ).map((el) => el.value);
          let rfis = await Rfi.find(filterQuery);
          if (!!rfis.length) {
            const c = rfiStatusLookUps.reduce(function (r, a, i) {
              r[a] = i;
              return r;
            }, {});
            rfis.sort((a, b) => {
              return c[a.status.value] - c[b.status.value];
            });
            let groupedRFI = _.groupBy(rfis, (rfi) => rfi.status.value);
            for (let status of rfiStatusLookUps) {
              groupedRFI[status] = groupedRFI[status]?.length || 0;
            }
            labels = Object.keys(groupedRFI);
            statusCount = Object.values(groupedRFI);
          } else {
            labels = rfiStatusLookUps;
            statusCount = [0, 0, 0];
          }
          break;
        case "fieldissue":
          filterQuery = { projectId };
          if (assignedToUser) {
            filterQuery["assignee"] = payloadEmail;
          }
          // sorting FIS based on key
          const fieldIssuesStatusLookUps = (
            await LookUp.find({ type: "fieldIssueStatus" })
          ).sort((a, b) => {
            if (a.key < b.key) {
              return -1;
            } else if (a.key > b.key) {
              return 1;
            } else {
              return 0;
            }
          });
          const fiStatusKeys = fieldIssuesStatusLookUps.map((el) => el.key);
          let fieldIssues = (await FieldIssue.find(filterQuery)).sort(
            (a, b) => {
              if (a.status < b.status) {
                return -1;
              } else if (a.status > b.status) {
                return 1;
              } else {
                return 0;
              }
            }
          );
          if (!!fieldIssues.length) {
            if (assignedToUser) {
              fieldIssues = fieldIssues.filter(
                (fieldIssue) =>
                  fieldIssue.assignee.toLowerCase() ===
                  payloadEmail.toLowerCase()
              );
            }
            const groupedFieldIssues = _.groupBy(
              fieldIssues,
              (ele) => ele.status
            );
            for (let status of fiStatusKeys) {
              groupedFieldIssues[status] =
                groupedFieldIssues[status]?.length || 0;
            }
            labels = fiStatusKeys;
            statusCount = Object.values(groupedFieldIssues);
          } else {
            labels = fiStatusKeys;
            statusCount = [0, 0, 0, 0];
          }
          // mapping FI status values to keys
          labels = labels.map((el) => {
            return fieldIssuesStatusLookUps.find((lookup) => lookup.key == el)
              .value;
          });

          break;
        case "punchlist":
          filterQuery = { projectId, isActive: true };
          if (assignedToUser) {
            filterQuery["$or"] = [
              { level1Users: { $in: [payloadEmail] } },
              { level2Users: { $in: [payloadEmail] } },
            ];
          }
          const projectTasks = await ProjectTask.find(filterQuery);
          const punchlistStatusLookUps = (
            await LookUp.find({ type: "taskStatus" })
          )
            .sort((a, b) => {
              if (a.key < b.key) {
                return -1;
              } else if (a.key > b.key) {
                return 1;
              } else {
                return 0;
              }
            })
            .map((el) => el.value);
          if (!!projectTasks.length) {
            const c = punchlistStatusLookUps.reduce(function (r, a, i) {
              r[a] = i;
              return r;
            }, {});
            projectTasks.sort((a, b) => {
              return c[a.taskStatus.desc] - c[b.taskStatus.desc];
            });
            let groupedPunchlist = _.groupBy(
              projectTasks,
              (rfi) => rfi.taskStatus.desc
            );
            for (let status of punchlistStatusLookUps) {
              groupedPunchlist[status] = groupedPunchlist[status]?.length || 0;
            }
            labels = Object.keys(groupedPunchlist);
            statusCount = Object.values(groupedPunchlist);
          } else {
            labels = punchlistStatusLookUps;
            statusCount = [0, 0, 0, 0];
          }
          // only for punchlist labels
          const joined_labels = [];
          for (let label of labels) {
            joined_labels.push(label.split(" ").join("_"));
          }
          labels = joined_labels;
          break;
      }

      if (chartType === "donut" || chartType === "pie") {
        response = [];
        for (let index in labels) {
          response.push({ label: labels[index], count: statusCount[index] });
        }
      } else if (chartType === "bar") {
        response = [];
        for (let index in labels) {
          response.push({ name: labels[index], value: statusCount[index] });
        }
      }
      res.json(response);
    } catch (err) {
      logger.error(err);
      next(err);
    }
  }
);

router.get(
  "/:project/latest/readytour",
  auth.required,
  checkActiveUserProjectAccess,
  async (req, res, next) => {
    try {
      let response = {};
      let interiorTourAvailable = false;
      let aerialTourAvailable = false;

      let matchedTowerName;
      let matchedInteriorTourId;
      let matchedInteriorTourDate;
      let matchedInteriorTourName;
      let matchedInteriorImage;

      let matchedAerialTourName;
      let matchedAerialTourDate;
      let matchedAerialTourCenter;

      const populatedProject = await populateProject(req.project);

      if (populatedProject.interiors?.length > 0) {
        let tourReadyFlag = false;
        for (let interiorTour of populatedProject.interiors) {
          if (interiorTour.isActive) {
            for (let walkthroughTour of interiorTour.floorWalkthough) {
              for (let tower of walkthroughTour.tours)
                if (tower.isPublished) {
                  tourReadyFlag = true;
                  if (tower.images?.length > 0) {
                    matchedInteriorTourId = tower.tourId;
                    matchedInteriorImage = tower.images[0];
                  }
                  break;
                }
              if (tourReadyFlag) {
                matchedTowerName = walkthroughTour.towerName;
                break;
              }
            }
          }
          if (tourReadyFlag) {
            matchedInteriorTourName = interiorTour.interiorName;
            matchedInteriorTourDate = interiorTour.interiorDate;
            break;
          }
        }

        if (tourReadyFlag) {
          interiorTourAvailable = true;
        }
      }

      if (populatedProject.aerialTours?.length > 0) {
        for (let aerialTour of populatedProject.aerialTours) {
          if (aerialTour.status.code === "AT10003") {
            matchedAerialTourDate = aerialTour.tourDate;
            matchedAerialTourName = aerialTour.tourName;
            matchedAerialTourCenter = [
              aerialTour.lng || 0,
              aerialTour.lat || 0,
            ];
            aerialTourAvailable = true;
            break;
          }
        }
      }

      let latestTourWinner;
      if (aerialTourAvailable && interiorTourAvailable) {
        if (
          moment(matchedAerialTourDate).isBefore(
            moment(matchedInteriorTourDate)
          )
        ) {
          latestTourWinner = "aerial";
        } else {
          latestTourWinner = "interior";
        }
      } else if (aerialTourAvailable) {
        latestTourWinner = "aerial";
      } else if (interiorTourAvailable) {
        latestTourWinner = "interior";
      } else {
        latestTourWinner = "none";
      }

      if (latestTourWinner === "aerial") {
        response = {
          tourName: matchedAerialTourName,
          tourDate: matchedAerialTourDate,
          tourType: latestTourWinner,
          center: matchedAerialTourCenter,
          statusCode: "CS200",
        };
      } else if (latestTourWinner === "interior") {
        response = {
          tourName: matchedInteriorTourName,
          tourDate: matchedInteriorTourDate,
          tourId: matchedInteriorTourId,
          towerName: matchedTowerName,
          tourType: latestTourWinner,
          statusCode: "CS200",
          image: matchedInteriorImage,
        };
      } else {
        response.statusCode = "CS404";
      }

      res.json({ ...response });
    } catch (err) {
      logger.error(err);
      next(err);
    }
  }
);

router.post(
  "/:project/alltasks/list",
  auth.required,
  checkActiveUserProjectAccess,
  async (req, res, next) => {
    try {
      const {
        fieldIssue: fieldIssueFlag,
        rfi: rfiFlag,
        punchlist: punchlistFlag,
      } = req.body.taskObj;
      const fieldIssueList = [];
      const rfiList = [];
      const punchlist = [];
      const responseObj = {};
      const {
        project: { projectId },
        payload: { email: payloadEmail },
      } = req;

      if (fieldIssueFlag) {
        const fieldIssues = await FieldIssue.find({ projectId });
        if (!!fieldIssues.length) {
          for (let fieldIssue of fieldIssues) {
            if (fieldIssue.assignee.toLowerCase() === payloadEmail) {
              const { issueId, description } = fieldIssue;
              fieldIssueList.push({ id: issueId, description });
            }
          }
        }
        responseObj.fieldIssueList = fieldIssueList;
      }

      if (rfiFlag) {
        const rfis = await Rfi.find({ projectId, isActive: true });
        if (!!rfis.length) {
          for (let rfi of rfis) {
            if (rfi.currentAssignee?.email.toLowerCase() === payloadEmail) {
              const { rfiId, wbsDescription } = rfi;
              rfiList.push({ id: rfiId, description: wbsDescription });
            }
          }
        }
        responseObj.rfiList = rfiList;
      }

      if (punchlistFlag) {
        const projectTasks = await ProjectTask.find({
          projectId,
          isActive: true,
        });
        if (!!projectTasks.length) {
          for (let task of projectTasks) {
            if (
              task.level1Users?.includes(payloadEmail.toLowerCase()) ||
              task.level2Users?.includes(payloadEmail.toLowerCase())
            ) {
              const { taskId, taskDescription } = task;
              punchlist.push({ id: taskId, description: taskDescription });
            }
          }
        }
        responseObj.punchlist = punchlist;
      }

      res.json(responseObj);
    } catch (err) {
      logger.error(err);
      next(err);
    }
  }
);

const populateProject = async (
  projectDoc,
  populateExterior = true,
  populateInterior = true
) => {
  const populateQuery = [];
  if (populateExterior) {
    populateQuery.push({
      path: "aerialTours",
      options: {
        sort: {
          createdAt: "desc",
        },
      },
    });
  }
  if (populateInterior) {
    populateQuery.push({
      path: "interiors",
      options: {
        sort: {
          createdAt: "desc",
        },
      },
      populate: {
        path: "floorWalkthough",
        populate: {
          path: "tours",
          model: "TourImage",
        },
      },
    });
  }
  return await projectDoc.populate(populateQuery).execPopulate();
};

module.exports = router;
