"use strict";

const {
  BucketsApi,
  ObjectsApi,
  PostBucketsPayload,
  DerivativesApi,
  JobPayload,
  JobPayloadInput,
  JobPayloadOutput,
  JobSvfOutputPayload,
} = require("forge-apis");
const mongoose = require("mongoose");
const fs = require("fs");
const router = require("express").Router();
const Project = mongoose.model("Project");
const InteriorTour = mongoose.model("InteriorTour");
const MasterData = mongoose.model("MasterData");

const { required } = require("../auth");
const { autocadForge } = require("../../config");
const logger = require("../../common/logger");
const {
  generateUUID,
  wait,
  getFilesFromRequest,
} = require("../../common/util");
const uuid = require("uuid");
const {
  getClient,
  getPublicToken,
  getInternalToken,
} = require("../../common/forge.oauth");
const asyncPackage = require("async");

// Preload project objects on routes with ":project"
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.param("interior", (req, res, next, interiorId) => {
  InteriorTour.findOne({
    interiorId: interiorId,
  })
    .then((interior) => {
      if (!interior) {
        return res.sendStatus(404);
      }
      req.interior = interior;
      return next();
    })
    .catch(next);
});

router.get("/oauth/token", required, async (req, res, next) => {
  if (req.payload.email) {
    try {
      const token = await getPublicToken();
      res.json({
        accessToken: token.access_token,
        expiresIn: token.expires_in,
      });
    } catch (err) {
      logger.err("Error while accessing oauth token: ", JSON.stringify(err));
      // next(err);
      res.sendStatus(500);
    }
  } else {
    res.sendStatus(403);
  }
});

// Middleware for obtaining a token for each request.
const setInternalToken = async (req, res, next) => {
  const token = await getInternalToken();
  req.oauthToken = token;
  req.oauthClient = getClient();
  next();
};

router.get(
  "/buckets/list",
  required,
  setInternalToken,
  async (req, res, next) => {
    if (req.payload.email) {
      const bucket_name = req.query.id;
      if (!bucket_name || bucket_name === "#") {
        try {
          // Retrieve up to 100 buckets from Forge using the [BucketsApi](https://github.com/Autodesk-Forge/forge-api-nodejs-client/blob/master/docs/BucketsApi.md#getBuckets)
          // Note: if there's more buckets, you should call the getBucket method in a loop, providing different 'startAt' params
          const buckets = await new BucketsApi().getBuckets(
            { limit: 100 },
            req.oauthClient,
            req.oauthToken
          );
          res.json(
            buckets.body.items.map((bucket) => {
              return {
                id: bucket.bucketKey,
                // Remove bucket key prefix that was added during bucket creation
                text: bucket.bucketKey.replace(
                  autocadForge.clientId.toLowerCase() + "-",
                  ""
                ),
                type: "bucket",
                children: true,
              };
            })
          );
        } catch (err) {
          next(err);
        }
      } else {
        try {
          // Retrieve up to 100 objects from Forge using the [ObjectsApi](https://github.com/Autodesk-Forge/forge-api-nodejs-client/blob/master/docs/ObjectsApi.md#getObjects)
          // Note: if there's more objects in the bucket, you should call the getObjects method in a loop, providing different 'startAt' params
          const objects = await new ObjectsApi().getObjects(
            bucket_name,
            { limit: 100 },
            req.oauthClient,
            req.oauthToken
          );
          res.json(
            objects.body.items.map((object) => {
              return {
                id: Buffer.from(object.objectId).toString("base64"),
                text: object.objectKey,
                type: "object",
                children: false,
              };
            })
          );
        } catch (err) {
          next(err);
        }
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/buckets/details/:bucketkey",
  required,
  setInternalToken,
  async (req, res, next) => {
    if (req.payload.email) {
      const bucketKey = req.params.bucketkey;
      try {
        const bucketDetails = await new BucketsApi().getBucketDetails(
          bucketKey,
          req.oauthClient,
          req.oauthToken
        );
        res.json(bucketDetails.body);
      } catch (err) {
        next(err);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

// POST /api/forge/oss/buckets - creates a new bucket.
// Request body must be a valid JSON in the form of { "bucketKey": "<new_bucket_name>" }.
router.post(
  "/buckets/:project/create",
  required,
  setInternalToken,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (!req.project.forgeBucketKey) {
              try {
                const forgeBucketKey = await createForgeBucket(req, res, next);

                res.json({
                  forgeBucketKey: forgeBucketKey,
                });
              } catch (err) {
                next({
                  message: err.statusMessage,
                  status: err.statusCode,
                  stack: err.statusBody,
                });
              }
            } else {
              res.json({
                forgeBucketKey: req.project.forgeBucketKey,
              });
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

const createForgeBucket = async (req, res, next) => {
  let payload = new PostBucketsPayload();
  payload.bucketKey =
    autocadForge.clientId.toLowerCase() + "-" + generateUUID();
  payload.policyKey = "persistent"; // does not expire
  // Create a bucket using [BucketsApi](https://github.com/Autodesk-Forge/forge-api-nodejs-client/blob/master/docs/BucketsApi.md#createBucket).
  await new BucketsApi().createBucket(
    payload,
    {},
    req.oauthClient,
    req.oauthToken
  );
  req.project.forgeBucketKey = payload.bucketKey;
  const { forgeBucketKey } = await req.project.save();
  return forgeBucketKey;
};

router.delete(
  "/buckets/delete/:project",
  required,
  setInternalToken,
  async (req, res, next) => {
    if (req.payload.email) {
      const { project, oauthClient, oauthToken, payload } = req;
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || payload.isAdmin) {
            try {
              if (project.forgeBucketKey) {
                // Create a bucket using [BucketsApi](https://github.com/Autodesk-Forge/forge-api-nodejs-client/blob/master/docs/BucketsApi.md#createBucket).
                await new BucketsApi().deleteBucket(
                  project.forgeBucketKey,
                  oauthClient,
                  oauthToken
                );

                await Project.updateOne(
                  { projectId: project.projectId },
                  {
                    $unset: { forgeBucketKey: 1 },
                  }
                ).then((_) => {
                  res.json({
                    status: "success",
                  });
                });
              } else {
                res.json({
                  status: "success",
                });
              }
            } catch (err) {
              next(err);
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// POST /api/forge/oss/objects - uploads new object to given bucket.
// Request body must be structured as 'form-data' dictionary
// with the uploaded file under "fileToUpload" key, and the bucket name under "bucketKey".
router.post(
  "/buckets/:project/:locationId/upload/objects",
  required,
  setInternalToken,
  async (req, res, next) => {
    if (req.payload.email) {
      const { project, oauthClient, oauthToken, params, files, payload, body } =
        req;
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || payload.isAdmin) {
            if (!files || Object.keys(files).length === 0) {
              return res.status(400).send("No files were uploaded.");
            }
            const { movedFiles: uploadedFiles, moveError: fileMoveError } =
              await getFilesFromRequest(
                files,
                req.payload.email,
                "forge_uploads"
              );
            await wait(1000);
            if (fileMoveError) {
              res.status(500).send(fileMoveError);
            } else {
              let file = uploadedFiles[0];
              fs.readFile(file.uploadPath, async (fileReadError, data) => {
                if (fileReadError) {
                  next(fileReadError);
                }
                if (!data) {
                  res.sendStatus(500);
                }
                let forgeObjectName;
                let forgeBucketKey;
                if (!project.forgeBucketKey) {
                  try {
                    forgeBucketKey = await createForgeBucket(req, res, next);
                  } catch (err) {
                    next({
                      message: err.statusMessage,
                      status: err.statusCode,
                      stack: err.statusBody,
                    });
                  }
                } else {
                  forgeBucketKey = project.forgeBucketKey;
                }

                let locationIds = [];
                await MasterData.findOne({
                  projectId: params.project,
                })
                  .then(async (masterdata) => {
                    const locations = masterdata.workLocation;
                    locationIds.push(params.locationId);

                    const currentLocation = locations.filter((loc) => {
                      return loc.locationId === params.locationId;
                    });
                    (currentLocation &&
                      currentLocation.length > 0 &&
                      currentLocation[0] &&
                      currentLocation[0].bim &&
                      currentLocation[0].bim.forgeObject &&
                      (forgeObjectName =
                        currentLocation[0].bim.forgeObject.name)) ||
                      (forgeObjectName =
                        uuid.v4() + "." + file.filename.split(".").pop());

                    try {
                      // Upload an object to bucket using [ObjectsApi](https://github.com/Autodesk-Forge/forge-api-nodejs-client/blob/master/docs/ObjectsApi.md#uploadObject).
                      const { statusCode: uploadStatusCode, body: uploadBody } =
                        await new ObjectsApi().uploadObject(
                          forgeBucketKey,
                          forgeObjectName,
                          data.length,
                          data,
                          {},
                          oauthClient,
                          oauthToken
                        );
                      if (uploadStatusCode === 200 && uploadBody) {
                        fs.unlinkSync(file.uploadPath);
                        const objectUrn = Buffer.from(
                          uploadBody.objectId
                        ).toString("base64");
                        const {
                          statusCode: translateStatusCode,
                          body: translateBody,
                          statusMessage: translateStatusMessage,
                        } = await translateModel(
                          objectUrn,
                          oauthClient,
                          oauthToken
                        );
                        if (translateStatusCode === 200 && translateBody) {
                          //update immediate child (level2)here
                          if (body.updateChild === "yes") {
                            const filteredIds = locations
                              .filter((loc) =>
                                locationIds.includes(loc.parentLocationId)
                              )
                              .map((l) => l.locationId);
                            locationIds = locationIds.concat(filteredIds);
                          }

                          const idsToUpdate = locationIds.filter(
                            (item, pos) => {
                              return locationIds.indexOf(item) == pos;
                            }
                          );

                          const bimObject = {
                            forgeObject: {
                              urn: translateBody.urn,
                              name: forgeObjectName,
                            },
                            offset: { x: 0, y: 0, z: 0 },
                            uploadedBy: req.payload.email,
                            uploadedAt: new Date(),
                          };

                          asyncPackage.eachSeries(
                            idsToUpdate,
                            (locationId, done) => {
                              MasterData.updateOne(
                                {
                                  projectId: project.projectId,
                                  "workLocation.locationId": locationId,
                                },
                                {
                                  $set: {
                                    "workLocation.$.bim": bimObject,
                                    "workLocation.$.floorplanMarkerPositions":
                                      [],
                                    "workLocation.$.updatedBy":
                                      req.payload.email,
                                  },
                                },
                                done
                              );
                            },
                            (err) => {
                              res.json({
                                status: "success",
                                objectUrn: translateBody.urn,
                              });
                            }
                          );
                        } else {
                          const {
                            statusCode: deleteStatusCode,
                            body: deleteBody,
                            statusMessage: deleteStatusMessage,
                          } = await deleteObjectsFromBucket(
                            forgeBucketKey,
                            forgeObjectName,
                            oauthClient,
                            oauthToken
                          );
                          if (deleteStatusCode === 200) {
                            res.statusMessage = translateBody.diagnostic
                              ? translateBody.diagnostic
                              : translateBody.developerMessage;
                            res.status(400);
                          }
                        }
                      } else {
                        res.statusMessage = uploadBody.diagnostic;
                        res.status(500);
                      }
                    } catch (err) {
                      next(err);
                    }
                  })
                  .catch(next);
              });
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/buckets/:project/:locationId/delete/objects",
  required,
  setInternalToken,
  async (req, res, next) => {
    if (req.payload.email) {
      const { project, oauthClient, oauthToken, params, payload } = req;
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || payload.isAdmin) {
            let forgeObjectName;
            const forgeBucketKey = project.forgeBucketKey;

            if (project.forgeBucketKey) {
              await MasterData.findOne({
                projectId: project.projectId,
                "workLocation.locationId": params.locationId,
              })
                .then(async (matchedMasterdata) => {
                  const locations = matchedMasterdata.workLocation;
                  const currentLocation = locations.filter((loc) => {
                    return loc.locationId === params.locationId;
                  });
                  currentLocation &&
                    currentLocation.length > 0 &&
                    currentLocation[0] &&
                    currentLocation[0].bim &&
                    currentLocation[0].bim.forgeObject &&
                    (forgeObjectName = currentLocation[0].bim.forgeObject.name);

                  if (forgeObjectName) {
                    const { statusCode, body, statusMessage } =
                      await deleteObjectsFromBucket(
                        forgeBucketKey,
                        forgeObjectName,
                        oauthClient,
                        oauthToken
                      );
                    if (statusCode === 200) {
                      let locationIds = [];
                      locationIds.push(params.locationId);
                      if (req.body.updateChildLocations === "yes") {
                        const filteredIds = locations
                          .filter((loc) => {
                            return locationIds.includes(loc.parentLocationId);
                          })
                          .map((l) => l.locationId);
                        locationIds = locationIds.concat(filteredIds);
                      }

                      const idsToUpdate = locationIds.filter((item, pos) => {
                        return locationIds.indexOf(item) == pos;
                      });

                      asyncPackage.eachSeries(
                        idsToUpdate,
                        (locationId, done) => {
                          MasterData.updateOne(
                            {
                              projectId: project.projectId,
                              "workLocation.locationId": locationId,
                            },
                            {
                              $set: {
                                "workLocation.$.updatedBy": req.payload.email,
                              },
                              $unset: {
                                "workLocation.$.bim": 1,
                                "workLocation.$.floorplanMarkerPositions": 1,
                                "workLocation.$.aecLevel": 1,
                                "workLocation.$.isAecLevelsFetched": 1,
                              },
                            },
                            done
                          );
                        },
                        (err) => {
                          res.json({
                            status: "success",
                          });
                        }
                      );
                    } else {
                      next({
                        message: statusMessage,
                        status: statusCode,
                        stack: body,
                      });
                    }
                  } else {
                    // res.statusMessage = "No object to delete";
                    res.status(400).send("No object to delete");
                  }
                })
                .catch((err) => {
                  next(err);
                });
            } else {
              // res.statusMessage = "Bucket does not exist";
              res.status(400).send("Bucket does not exist");
            }
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

const deleteObjectsFromBucket = async (
  forgeBucketKey,
  forgeObjectName,
  oauthClient,
  oauthToken
) => {
  try {
    const { statusCode, body } = await new ObjectsApi().deleteObject(
      forgeBucketKey,
      forgeObjectName,
      oauthClient,
      oauthToken
    );
    return { statusCode, body };
  } catch (err) {
    return {
      statusCode: err.statusCode,
      body: err.statusBody,
      statusMessage: err.statusMessage,
    };
  }
};

// start translate job
router.post(
  "/jobs/:project/:locationId",
  setInternalToken,
  async (req, res, next) => {
    const { project, params, oauthClient, oauthToken } = req;
    let forgeObjectUrn;
    await MasterData.findOne({
      projectId: project.projectId,
      "workLocation.locationId": params.locationId,
    }).then(async (matchedMasterdata) => {
      const locations = matchedMasterdata.workLocation;
      const currentLocation = locations.filter((loc) => {
        return loc.locationId === params.locationId;
      });
      currentLocation &&
        currentLocation.length > 0 &&
        currentLocation[0] &&
        currentLocation[0].bim &&
        currentLocation[0].bim.forgeObject &&
        (forgeObjectUrn = currentLocation[0].bim.forgeObject.urn);

      if (forgeObjectUrn) {
        const { statusCode, body, statusMessage } = await translateModel(
          forgeObjectUrn,
          oauthClient,
          oauthToken
        );
        if (statusCode === 200) {
          res.status(200).end();
        } else {
          next({
            message: statusMessage,
            status: statusCode,
            stack: body,
          });
        }
      } else {
        res.statusMessage = "No object to translate";
        res.sendStatus(400);
      }
    });
  }
);

// get translation status
router.get(
  "/translate/status/:urn",
  setInternalToken,
  async (req, res, next) => {
    const { oauthClient, oauthToken } = req;
    let forgeObjectUrn = req.params.urn;

    if (forgeObjectUrn) {
      try {
        const { statusCode, body } = await new DerivativesApi().getManifest(
          forgeObjectUrn,
          {},
          oauthClient,
          oauthToken
        );
        if (statusCode === 200) {
          res.json({ status: body.status });
        } else {
          res.statusMessage = body.diagnostic;
          res.status(500);
        }
      } catch (err) {
        res.statusMessage = err.statusBody.diagnostic;
        res.status(500);
      }
    } else {
      res.statusMessage = "No urn found";
      res.sendStatus(400);
    }
  }
);

const translateModel = async (objectUrn, oauthClient, oauthToken) => {
  let job = new JobPayload();
  job.input = new JobPayloadInput();
  job.input.urn = objectUrn;
  job.output = new JobPayloadOutput([new JobSvfOutputPayload()]);
  job.output.formats[0].type = "svf";
  job.output.formats[0].views = ["2d", "3d"];
  // Submit a translation job using [DerivativesApi](https://github.com/Autodesk-Forge/forge-api-nodejs-client/blob/master/docs/DerivativesApi.md#translate).
  try {
    const { statusCode, body } = await new DerivativesApi().translate(
      job,
      {},
      oauthClient,
      oauthToken
    );
    return { statusCode, body };
  } catch (err) {
    return {
      statusCode: err.statusCode,
      body: err.statusBody,
      statusMessage: err.statusMessage,
    };
  }
};

module.exports = router;
