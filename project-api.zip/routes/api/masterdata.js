const router = require("express").Router();
const mongoose = require("mongoose");
const MasterData = mongoose.model("MasterData");
const WorkLocation = mongoose.model("WorkLocation");
const auth = require("../auth");
const uuid = require("uuid");
const _ = require("underscore");
const asyncPackage = require("async");
const Util = require("../../common/util");
const { blobDrawingRef } =
  require("../../config/index").azureStorage.containers;
const logger = require("../../common/logger");

router.get("/:projectId", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await MasterData.findOne({
      projectId: req.params.projectId,
    })
      .then((data) => {
        res.json({
          master: data,
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.get(
  "/:projectId/getLocationFloorPlanVolume/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      MasterData.findOne({
        projectId: req.params.projectId,
      })
        .then(async (data) => {
          if (data.workLocation?.length > 0) {
            const blobReferences = new Set();

            for (const location of data.workLocation) {
              location.drawing?.blobContentId &&
                blobReferences.add(location.drawing.blobContentId);
            }

            const totSize = await Util.getTotalBlobSize(
              blobDrawingRef,
              Array.from(blobReferences)
            );
            res.json({
              total: totSize,
            });
          } else {
            res.json({ total: 0 });
          }
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:projectId/workPackage/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      MasterData.findOne({
        projectId: req.params.projectId,
      })
        .then((data) => {
          res.json({
            workPackage: data.workPackage,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/workPackage/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const wp = req.body.workPackage;

      let workPackage = {
        tradeId: uuid.v4(),
        tradeName: wp.tradeName,
        level1: wp.level1 ? wp.level1 : [],
        level2: wp.level2 ? wp.level2 : [],
        isActive: true,
        workFlow: wp.workFlow ? wp.workFlow : [],
        workPackageCost: wp.workPackageCost ? wp.workPackageCost : 0,
        createdBy: req.payload.email,
        updatedBy: req.payload.email,
      };

      await MasterData.findOneAndUpdate(
        {
          projectId: req.params.projectId,
        },
        {
          $push: {
            workPackage: workPackage,
          },
        },
        {
          new: true,
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:projectId/workPackage/:tradeId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.body.workPackage) {
        const wp = req.body.workPackage;

        await MasterData.findOneAndUpdate(
          {
            projectId: req.params.projectId,
            "workPackage.tradeId": req.params.tradeId,
          },
          {
            $set: {
              "workPackage.$[outer].tradeName": wp.tradeName,
              "workPackage.$[outer].level1": wp.level1 ? wp.level1 : [],
              "workPackage.$[outer].level2": wp.level2 ? wp.level2 : [],
              "workPackage.$[outer].workPackageCost": wp.workPackageCost
                ? wp.workPackageCost
                : 0,
              "workPackage.$[outer].updatedBy": req.payload.email,
            },
          },
          {
            arrayFilters: [
              {
                "outer.tradeId": req.params.tradeId,
              },
            ],
          }
        )
          .then(() => {
            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/workPackage/:tradeId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.tradeId) {
        await MasterData.findOneAndUpdate(
          {
            projectId: req.params.project,
            "workPackage.tradeId": req.params.tradeId,
          },
          {
            $pull: {
              workPackage: {
                tradeId: req.params.tradeId,
              },
            },
          },
          {
            new: true,
          }
        )
          .then(() => {
            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:projectId/worklocation/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await MasterData.findOne({
        projectId: req.params.projectId,
      })
        .then((data) => {
          res.json({
            location: data.workLocation,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/worklocation/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      MasterData.findOne({
        projectId: req.params.projectId,
      })
        .then(async (masterdata) => {
          if (masterdata) {
            await MasterData.findOne({
              workLocation: {
                $elemMatch: {
                  level1: req.body.location.level1,
                  level2: req.body.location.level2
                    ? req.body.location.level2
                    : "",
                  level3: req.body.location.level3
                    ? req.body.location.level3
                    : "",
                  level4: req.body.location.level4
                    ? req.body.location.level4
                    : "",
                },
              },
              projectId: req.params.projectId,
            }).then(async (data) => {
              if (!data) {
                const location = new WorkLocation();
                location.locationId = uuid.v4();
                location.parentLocationId = req.body.location.parentLocationId;
                location.level1 = req.body.location.level1;
                location.level2 = req.body.location.level2
                  ? req.body.location.level2
                  : "";
                location.level3 = req.body.location.level3
                  ? req.body.location.level3
                  : "";
                location.level4 = req.body.location.level4
                  ? req.body.location.level4
                  : "";
                location.createdBy = req.payload.email;
                location.updatedBy = req.payload.email;
                location.orderNo = req.body.location.orderNo
                  ? req.body.location.orderNo
                  : 0;
                masterdata.workLocation.push(location);

                await masterdata
                  .save()
                  .then(() => {
                    res.json({
                      status: "success",
                    });
                  })
                  .catch(next);
              } else {
                res.sendStatus(409);
              }
            });
          } else {
            res.sendStatus(403);
          }
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:projectId/worklocation/:locationId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.locationId && req.params.projectId) {
        let locationIds = [];
        await MasterData.findOne({
          projectId: req.params.projectId,
        })
          .then(async (data) => {
            const locations = data.workLocation;
            locationIds.push(req.params.locationId);

            for (i = 0; i < 4; i++) {
              filteredIds = locations
                .filter((loc) => locationIds.includes(loc.parentLocationId))
                .map((l) => l.locationId);
              locationIds = locationIds.concat(filteredIds);
            }

            await MasterData.findOneAndUpdate(
              {
                projectId: req.params.projectId,
              },
              {
                $pull: {
                  workLocation: {
                    locationId: {
                      $in: locationIds,
                    },
                  },
                },
                $set: {
                  updatedBy: req.payload.email,
                },
              },
              {
                new: true,
              }
            )
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:projectId/worklocation/:locationId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.locationId && req.params.projectId) {
        let locationIds = [];
        await MasterData.findOne({
          projectId: req.params.projectId,
        })
          .then(async (data) => {
            const drawing = req.body.drawing;
            const isApplyToAll = req.body.isApplyToAll;
            const locations = data.workLocation;
            locationIds.push(req.params.locationId);

            if (drawing.updateChild) {
              for (i = 0; i < 4; i++) {
                filteredIds = locations
                  .filter((loc) => locationIds.includes(loc.parentLocationId))
                  .map((l) => l.locationId);
                locationIds = locationIds.concat(filteredIds);
              }
            }
            if (isApplyToAll) {
              const locationsList = data.workLocation;
              const currentLocation = locationsList.find(
                (loc) => loc.locationId == req.params.locationId
              );

              const filteredIdsForCurrentLevel = locationsList
                .filter(
                  (loc) =>
                    loc.parentLocationId == currentLocation.parentLocationId &&
                    !!loc.drawing
                )
                .map((l) => l.locationId);

              locationIds = locationIds.concat(filteredIdsForCurrentLevel);
            }
            const idsToUpdate = locationIds.filter((item, pos) => {
              return locationIds.indexOf(item) == pos;
            });

            asyncPackage.eachSeries(
              idsToUpdate,
              (obj, done) => {
                if (isApplyToAll) {
                  MasterData.updateOne(
                    {
                      projectId: req.params.projectId,
                      "workLocation.locationId": obj,
                    },
                    {
                      $set: {
                        "workLocation.$.drawing.floorPlanOrientation":
                          drawing.reference?.floorPlanOrientation,
                        "workLocation.$.updatedBy": req.payload.email,
                      },
                    },
                    done
                  );
                } else {
                  MasterData.updateOne(
                    {
                      projectId: req.params.projectId,
                      "workLocation.locationId": obj,
                    },
                    {
                      $set: {
                        "workLocation.$.drawing": drawing.reference,
                        "workLocation.$.updatedBy": req.payload.email,
                      },
                    },
                    done
                  );
                }
              },
              () => {
                res.json({
                  status: "success",
                });
              }
            );
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:projectId/worklocation/upload/bulk",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      let parentLocationId = "";
      const pid = req.params.projectId;
      const createdBy = req.payload.email;

      if (req.params.projectId) {
        const locations = req.body.location;
        const copyOfLocation = [...locations];

        const level1List = _.chain([...copyOfLocation])
          .filter((e) => e.level1)
          .groupBy((e) => e.level1)
          .map((e) => e[0])
          .value();

        const level2List = _.chain([...copyOfLocation])
          .filter((e) => e.level1 && e.level2)
          .groupBy((e) => e.level1 + "|" + e.level2)
          .map((e) => e[0])
          .value();

        const level3List = _.chain([...copyOfLocation])
          .filter((e) => e.level1 && e.level2 && e.level3)
          .groupBy((e) => e.level1 + "|" + e.level2 + "|" + e.level3)
          .map((e) => e[0])
          .value();

        const level4List = _.chain([...copyOfLocation])
          .filter((e) => e.level1 && e.level2 && e.level3 && e.level4)
          .groupBy(
            (e) => e.level1 + "|" + e.level2 + "|" + e.level3 + "|" + e.level4
          )
          .map((e) => e[0])
          .value();

        level1List.forEach(async (l1) => {
          parentLocationId = "";
          const levelOneLocationId = uuid.v4();
          const levelOne = {
            levelOne: l1.level1,
            levelTwo: "",
            levelThree: "",
            levelFour: "",
          };
          createLocation(
            pid,
            levelOne,
            levelOneLocationId,
            parentLocationId,
            createdBy
          );

          level2List.forEach((l2) => {
            if (l1.level1 === l2.level1) {
              parentLocationId = levelOneLocationId;
              const levelTwoLocationId = uuid.v4();
              const levelTwo = {
                levelOne: l1.level1,
                levelTwo: l2.level2,
                levelThree: "",
                levelFour: "",
              };
              createLocation(
                pid,
                levelTwo,
                levelTwoLocationId,
                parentLocationId,
                createdBy
              );

              level3List.forEach((l3) => {
                if (l2.level1 === l3.level1 && l2.level2 === l3.level2) {
                  parentLocationId = levelTwoLocationId;
                  const levelThreeLocationId = uuid.v4();
                  const levelThree = {
                    levelOne: l2.level1,
                    levelTwo: l2.level2,
                    levelThree: l3.level3,
                    levelFour: "",
                  };
                  createLocation(
                    pid,
                    levelThree,
                    levelThreeLocationId,
                    parentLocationId,
                    createdBy
                  );

                  level4List.forEach((l4) => {
                    if (
                      l3.level1 === l4.level1 &&
                      l3.level2 === l4.level2 &&
                      l3.level3 === l4.level3
                    ) {
                      parentLocationId = levelThreeLocationId;
                      const levelFourLocationId = uuid.v4();
                      const levelFour = {
                        levelOne: l3.level1,
                        levelTwo: l3.level2,
                        levelThree: l3.level3,
                        levelFour: l4.level4,
                      };
                      createLocation(
                        pid,
                        levelFour,
                        levelFourLocationId,
                        parentLocationId,
                        createdBy
                      );
                    }
                  });
                }
              });
            }
          });
        });

        res.json({
          status: "success",
        });
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/workClassification/",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await MasterData.findOneAndUpdate(
        {
          projectId: req.params.projectId,
        },
        {
          $set: {
            workClassification: req.body.workClassification,
          },
        },
        {
          new: true,
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

const createLocation = async (
  projectId,
  loc,
  locationId,
  parentLocationId,
  createdBy
) => {
  MasterData.findOne({
    projectId: projectId,
  }).then(async (masterdata) => {
    if (masterdata) {
      await MasterData.findOne({
        workLocation: {
          $elemMatch: {
            level1: loc.levelOne,
            level2: loc.levelTwo ? loc.levelTwo : "",
            level3: loc.levelThree ? loc.levelThree : "",
            level4: loc.levelFour ? loc.levelFour : "",
          },
        },
        projectId: projectId,
      }).then(async (data) => {
        if (!data) {
          const location = new WorkLocation();
          location.locationId = locationId;
          location.parentLocationId = parentLocationId;
          location.level1 = loc.levelOne;
          location.level2 = loc.levelTwo ? loc.levelTwo : "";
          location.level3 = loc.levelThree ? loc.levelThree : "";
          location.level4 = loc.levelFour ? loc.levelFour : "";
          location.createdBy = createdBy;
          location.updatedBy = createdBy;
          masterdata.workLocation.push(location);

          await masterdata.save().then(async (locationData) => {
            return locationData.locationId;
          });
        }
      });
    }
  });
};

// update work location
router.put(
  "/:projectId/worklocation/:locationId/update",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.body.location) {
        let location = req.body.location;
        await MasterData.updateOne(
          {
            projectId: req.params.projectId,
            workLocation: {
              $elemMatch: { locationId: req.params.locationId },
            },
          },
          {
            $set: {
              "workLocation.$.level1": location.level1,
              "workLocation.$.level2": location.level2 ? location.level2 : "",
              "workLocation.$.level3": location.level3 ? location.level3 : "",
              "workLocation.$.level4": location.level4 ? location.level4 : "",
              "workLocation.$.updatedBy": req.payload.email,
            },
          }
        )
          .then(() => {
            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:projectId/worklocation/:locationId/removedrawing",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.locationId && req.params.projectId) {
        let locationIds = [];
        await MasterData.findOne({
          projectId: req.params.projectId,
        })
          .then(async (data) => {
            const drawing = undefined;
            const locations = data.workLocation;
            locationIds.push(req.params.locationId);

            for (i = 0; i < 4; i++) {
              filteredIds = locations
                .filter((loc) => locationIds.includes(loc.parentLocationId))
                .map((l) => l.locationId);
              locationIds = locationIds.concat(filteredIds);
            }

            const idsToUpdate = locationIds.filter((item, pos) => {
              return locationIds.indexOf(item) == pos;
            });

            asyncPackage.eachSeries(
              idsToUpdate,
              (obj, done) => {
                MasterData.updateOne(
                  {
                    projectId: req.params.projectId,
                    "workLocation.locationId": obj,
                  },
                  {
                    $set: {
                      "workLocation.$.drawing": drawing,
                      "workLocation.$.updatedBy": req.payload.email,
                    },
                  },
                  done
                );
              },
              () => {
                res.json({
                  status: "success",
                });
              }
            );
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

// change the order of the work location
router.put(
  "/:projectId/worklocation/:level/updateorder",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const createdBy = req.payload.email;
      const masterData = await MasterData.findOne({
        projectId: req.params.projectId,
      });
      const incomingLocation = req.body.location;

      masterData.workLocation.forEach((existingLocation) => {
        for (let loc of incomingLocation) {
          if (existingLocation.locationId == loc.locationId) {
            existingLocation.orderNo = loc.orderNo;
            existingLocation.updatedBy = createdBy;
          }
        }
      });
      await MasterData.updateOne(
        { projectId: req.params.projectId },
        { $set: { workLocation: masterData.workLocation } },
        function (err, docs) {
          if (err) {
            res.sendStatus(401);
          } else {
            res.json({
              status: "success",
            });
          }
        }
      );
    }
  }
);

router.put(
  "/:projectId/workpackage/upload/bulk",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const createdBy = req.payload.email;

      if (req.params.projectId) {
        const workPackages = req.body.workPackages;
        const workPackagesArray = [];

        for (let workPackage of workPackages) {
          workPackagesArray.push({
            tradeId: uuid.v4(),
            tradeName: workPackage.tradeName,
            level1: workPackage.level1 ? workPackage.level1 : [],
            level2: workPackage.level2 ? workPackage.level2 : [],
            isActive: true,
            workPackageCost: workPackage.workPackageCost
              ? workPackage.workPackageCost
              : 0,
            createdBy: createdBy,
            updatedBy: createdBy,
          });
        }

        await MasterData.findOneAndUpdate(
          {
            projectId: req.params.projectId,
          },
          {
            $push: {
              workPackage: {
                $each: workPackagesArray,
              },
            },
          },
          {
            upsert: true,
          }
        )
          .then(() => {
            res.json({
              status: "success",
            });
          })
          .catch(next);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/worklocation/:locationId/bim/offset",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      const { params, body: requestBody } = req;
      await MasterData.findOne({
        projectId: params.projectId,
        "workLocation.locationId": params.locationId,
      })
        .then(async (matchedMasterdata) => {
          const locations = matchedMasterdata.workLocation;

          let locationIds = [];
          locationIds.push(params.locationId);
          const filteredIds = locations
            .filter((loc) => {
              return locationIds.includes(loc.parentLocationId);
            })
            .map((l) => l.locationId);
          locationIds = locationIds.concat(filteredIds);

          const idsToUpdate = locationIds.filter((item, pos) => {
            return locationIds.indexOf(item) == pos;
          });

          asyncPackage.eachSeries(
            idsToUpdate,
            (locationId, done) => {
              MasterData.updateOne(
                {
                  projectId: params.projectId,
                  "workLocation.locationId": locationId,
                },
                {
                  $set: {
                    "workLocation.$.updatedBy": req.payload.email,
                    "workLocation.$.bim.offset": requestBody.offset,
                  },
                },
                done
              );
            },
            () => {
              res.json({
                status: "success",
              });
            }
          );
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/worklocation/:locationId/bim/aec/level",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      const { params, body: requestBody } = req;
      await MasterData.findOne({
        projectId: params.projectId,
        "workLocation.locationId": params.locationId,
      })
        .then(async (matchedMasterdata) => {
          const locations = matchedMasterdata.workLocation;
          let locationIds = [];
          locationIds.push(params.locationId);
          await MasterData.updateOne(
            {
              projectId: params.projectId,
              "workLocation.locationId": params.locationId,
            },
            {
              $set: {
                "workLocation.$.updatedBy": req.payload.email,
                "workLocation.$.bim.levels": requestBody.floorLevelAecData,
              },
            }
          ).then(async () => {
            const level2LocationIds = locations
              .filter((loc) => {
                return locationIds.includes(loc.parentLocationId);
              })
              .map((l) => l.locationId);
            asyncPackage.eachSeries(
              level2LocationIds,
              async (level2LocationId, done) => {
                await MasterData.updateOne(
                  {
                    projectId: params.projectId,
                    "workLocation.locationId": level2LocationId,
                  },
                  {
                    $set: {
                      "workLocation.$.updatedBy": req.payload.email,
                      "workLocation.$.isAecLevelsFetched": true,
                    },
                  },
                  done
                );
              },
              () => {
                res.json({
                  status: "success",
                });
              }
            );
          });
        })
        .catch(() => {
          logger.error("error in save bim aec level");
        });
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/worklocation/:level2LocationId/:parentLocationId/floorplanconfig",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      const { params, body: requestBody } = req;
      await MasterData.findOne({
        projectId: params.projectId,
        "workLocation.locationId": params.level2LocationId,
      })
        .then(async (matchedMasterdata) => {
          let locationIds = [];
          let idsToUpdate;
          const locations = matchedMasterdata.workLocation;
          const isLevel1Location =
            locations.filter((loc) => {
              return (
                loc.locationId === params.level2LocationId &&
                loc.parentLocationId == ""
              );
            }).length > 0;
          locationIds.push(params.level2LocationId);

          if (isLevel1Location) {
            const filteredIds = locations
              .filter((loc) => {
                return locationIds.includes(loc.parentLocationId);
              })
              .map((l) => l.locationId);
            locationIds = locationIds.concat(filteredIds);

            idsToUpdate = locationIds.filter((item, pos) => {
              return locationIds.indexOf(item) == pos;
            });

            // pull position from children before updating the new one
            await asyncPackage.eachSeries(
              idsToUpdate,
              async (locationId, done) => {
                await MasterData.updateOne(
                  {
                    projectId: params.projectId,
                    "workLocation.locationId": locationId,
                  },
                  {
                    $set: {
                      "workLocation.$.updatedBy": req.payload.email,
                    },
                    $pull: {
                      "workLocation.$.floorplanMarkerPositions": {
                        position: requestBody.markerPositionInfo.position,
                      },
                    },
                  }
                ).then(async () => {
                  await MasterData.updateOne(
                    {
                      projectId: params.projectId,
                      "workLocation.locationId": locationId,
                    },
                    {
                      $set: {
                        "workLocation.$.updatedBy": req.payload.email,
                      },
                      $push: {
                        "workLocation.$.floorplanMarkerPositions":
                          requestBody.markerPositionInfo,
                      },
                    },
                    done
                  );
                });
              },
              async () => {
                await MasterData.findOne({
                  projectId: params.projectId,
                  "workLocation.locationId": params.level2LocationId,
                }).then((masterdata) => {
                  res.json({
                    status: "success",
                    positions: masterdata.workLocation.find(
                      (location) =>
                        location.locationId === params.level2LocationId
                    ).floorplanMarkerPositions,
                  });
                });
              }
            );
          } else {
            idsToUpdate = locationIds.filter((item, pos) => {
              return locationIds.indexOf(item) == pos;
            });

            await asyncPackage.eachSeries(
              idsToUpdate,
              async (locationId, done) => {
                let query = {};
                if (requestBody.origin)
                  query = {
                    $set: {
                      "workLocation.$.updatedBy": req.payload.email,
                      "workLocation.$.bim.floorplanConfig.origin":
                        requestBody.origin,
                    },
                  };
                else {
                  query = {
                    $set: {
                      "workLocation.$.updatedBy": req.payload.email,
                      "workLocation.$.bim.floorplanConfig.distanceOnFloorPlan":
                        requestBody.distanceOnFloorPlan,
                      "workLocation.$.bim.floorplanConfig.point1":
                        requestBody.point1,
                      "workLocation.$.bim.floorplanConfig.point2":
                        requestBody.point2,
                    },
                  };
                }

                await MasterData.updateOne(
                  {
                    projectId: params.projectId,
                    "workLocation.locationId": locationId,
                  },
                  query,
                  done
                );
              },
              async () => {
                await MasterData.findOne({
                  projectId: params.projectId,
                  "workLocation.locationId": params.level2LocationId,
                }).then((masterdata) => {
                  res.json({
                    status: "success",
                    locations: masterdata.workLocation.filter(
                      (location) =>
                        location.parentLocationId === params.parentLocationId &&
                        location.level3 === "" &&
                        location.level4 === "" &&
                        location.aecLevel
                    ),
                  });
                });
              }
            );
          }
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:projectId/worklocation/:locationId/floorplan/marker",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      const { params, body: requestBody } = req;
      await MasterData.findOne({
        projectId: params.projectId,
        "workLocation.locationId": params.locationId,
      })
        .then(async (matchedMasterdata) => {
          const locations = matchedMasterdata.workLocation;

          let locationIds = [];
          locationIds.push(params.locationId);

          const isLevel1Location =
            locations.filter((loc) => {
              return (
                loc.locationId === params.locationId &&
                loc.parentLocationId == ""
              );
            }).length > 0;

          // include children for level1 location update
          if (isLevel1Location) {
            const filteredIds = locations
              .filter((loc) => {
                return locationIds.includes(loc.parentLocationId);
              })
              .map((l) => l.locationId);
            locationIds = locationIds.concat(filteredIds);
          }

          const idsToUpdate = locationIds.filter((item, pos) => {
            return locationIds.indexOf(item) == pos;
          });

          await asyncPackage.eachSeries(
            idsToUpdate,
            (locationId, done) => {
              MasterData.updateOne(
                {
                  projectId: params.projectId,
                  "workLocation.locationId": locationId,
                },
                {
                  $set: {
                    "workLocation.$.updatedBy": req.payload.email,
                  },
                  $pull: {
                    "workLocation.$.floorplanMarkerPositions": {
                      position: requestBody.markerPositionLabel,
                    },
                  },
                },
                done
              );
            },
            async () => {
              await MasterData.findOne({
                projectId: params.projectId,
                "workLocation.locationId": params.locationId,
              }).then((masterdata) => {
                res.json({
                  status: "success",
                  positions: masterdata.workLocation.find(
                    (location) => location.locationId === params.locationId
                  ).floorplanMarkerPositions,
                });
              });
            }
          );
        })
        .catch((err) => {
          logger.error(
            "Error in deleteFloorplanMarker route." + JSON.stringify(err)
          );
        });
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/worklocation/updateFloorNames",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      let masterData = await MasterData.findOne({
        projectId: req.params.projectId,
      });

      let locations = masterData.workLocation;

      req.body.matchedFloorNames.forEach((data) => {
        locations.map((location) => {
          if (location.locationId === data.locationId) {
            location.aecLevel = data.aecLevel;
          }
          return location;
        });
      });

      await MasterData.updateOne(
        { projectId: req.params.projectId },
        {
          $set: { workLocation: locations },
        }
      );

      res.json({
        status: "success",
      });
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/worklocation/:locationId/bim/modelbound",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      const { params, body: requestBody } = req;
      await MasterData.findOne({
        projectId: params.projectId,
        "workLocation.locationId": params.locationId,
      })
        .then(async (matchedMasterdata) => {
          const locations = matchedMasterdata.workLocation;

          let locationIds = [];
          locationIds.push(params.locationId);
          const filteredIds = locations
            .filter((loc) => {
              return locationIds.includes(loc.parentLocationId);
            })
            .map((l) => l.locationId);
          locationIds = locationIds.concat(filteredIds);

          const idsToUpdate = locationIds.filter((item, pos) => {
            return locationIds.indexOf(item) == pos;
          });

          asyncPackage.eachSeries(
            idsToUpdate,
            (locationId, done) => {
              MasterData.updateOne(
                {
                  projectId: params.projectId,
                  "workLocation.locationId": locationId,
                },
                {
                  $set: {
                    "workLocation.$.updatedBy": req.payload.email,
                    "workLocation.$.bim.modelBound": requestBody.distance,
                  },
                },
                done
              );
            },
            () => {
              res.json({
                status: "success",
              });
            }
          );
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/worklocation/:locationId/bim/angularDeviationFromTrueNorth",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      const { params, body: requestBody } = req;
      await MasterData.findOne({
        projectId: params.projectId,
        "workLocation.locationId": params.locationId,
      })
        .then(async (matchedMasterdata) => {
          const locations = matchedMasterdata.workLocation;

          let locationIds = [];
          locationIds.push(params.locationId);
          const filteredIds = locations
            .filter((loc) => {
              return locationIds.includes(loc.parentLocationId);
            })
            .map((l) => l.locationId);
          locationIds = locationIds.concat(filteredIds);

          const idsToUpdate = locationIds.filter((item, pos) => {
            return locationIds.indexOf(item) == pos;
          });

          asyncPackage.eachSeries(
            idsToUpdate,
            (locationId, done) => {
              MasterData.updateOne(
                {
                  projectId: params.projectId,
                  "workLocation.locationId": locationId,
                },
                {
                  $set: {
                    "workLocation.$.updatedBy": req.payload.email,
                    "workLocation.$.bim.bimAngularDeviationFromTrueNorth":
                      requestBody.bimAngularDeviationFromTrueNorth,
                  },
                },
                done
              );
            },
            () => {
              res.json({
                status: "success",
              });
            }
          );
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:projectId/worklocation/:locationId/bim/model/floorplan/scale",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const { params } = req;
      await MasterData.findOne({
        projectId: params.projectId,
      })
        .then(async (matchedMasterdata) => {
          const locations = matchedMasterdata.workLocation;
          const level1Location = locations.find((loc) => {
            return loc.locationId === params.locationId;
          });
          const modelBoundLength = level1Location.bim.modelBound;

          const level2Locations = locations.filter(
            (loc) =>
              loc.parentLocationId === params.locationId &&
              loc.bim &&
              loc.bim.floorplanConfig
          );

          asyncPackage.eachSeries(
            level2Locations,
            (level2Location, done) => {
              const transformationScale = parseFloat(
                modelBoundLength /
                  Math.abs(
                    level2Location.bim.floorplanConfig.distanceOnFloorPlan
                  )
              ).toFixed(6);
              MasterData.updateOne(
                {
                  projectId: params.projectId,
                  "workLocation.locationId": level2Location.locationId,
                },
                {
                  $set: {
                    "workLocation.$.updatedBy": req.payload.email,
                    "workLocation.$.bim.transformationScale":
                      transformationScale,
                  },
                },
                done
              );
            },
            () => {
              res.json({
                status: "success",
              });
            }
          );
        })
        .catch((err) => {
          console.log(err);
          next(err);
        });
    } else {
      res.sendStatus(403);
    }
  }
);

module.exports = router;
