"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const Util = require("../../common/util");
const logger = require("../../common/logger");

// Preload project objects on routes with ':project'
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.param("album", (req, res, next, albumId) => {
  ProjectAlbum.findOne({
    albumId: albumId,
  })
    .then((album) => {
      if (!album) {
        return res.sendStatus(404);
      }
      req.album = album;
      return next();
    })
    .catch(next);
});

router.param("annotation", (req, res, next, annotationId) => {
  MediaAnnotation.findOne({
    annotationId: annotationId,
  })
    .then((annotation) => {
      if (!annotation) {
        return res.sendStatus(404);
      }
      req.annotation = annotation;
      return next();
    })
    .catch(next);
});

router.param("media", (req, res, next, mediaId) => {
  ProjectAlbum.findOne({
    media: {
      $elemMatch: {
        mediaId: mediaId,
      },
    },
  })
    .then((album) => {
      if (!album) {
        return res.sendStatus(404);
      }
      req.media = album.media.find((m) => m.mediaId === mediaId);
      return next();
    })
    .catch(next);
});

router.param("tour", (req, res, next, tourId) => {
  AerialTour.findOne({
    tourId: tourId,
  })
    .then((tour) => {
      if (!tour) {
        return res.sendStatus(404);
      }
      req.tour = tour;
      return next();
    })
    .catch(next);
});

module.exports = router;
