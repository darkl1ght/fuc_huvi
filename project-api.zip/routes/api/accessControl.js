const router = require("express").Router();
const auth = require("../auth");
const mongoose = require("mongoose");
const AccessMapping = mongoose.model("AccessMapping");
const { Constants } = require("../../config/constants");
const {
  redisDeleteKey,
  redisGetJson,
  redisSetJson,
  redisGetAllKeys,
} = require("../../common/redisHelper");

router.get("/getprojectroles", auth.required, async (req, res, next) => {
  await AccessMapping.find(
    {
      isActive: true,
      role: { $ne: "Super Admin" },
    },
    {
      _id: 0,
      role: 1,
      desc: 1,
    },
    {
      sort: {
        desc: 1,
      },
    }
  )
    .then(async (data) => {
      res.json(data);
    })
    .catch(next);
});

//This is used in Orchestrator too for validation
router.get("/:role/getaccessmapping", auth.required, async (req, res, next) => {
  const role = req.params.role.trim();
  const accessMappingCacheKey =
    Constants.accessControlConfig.ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX + role;
  const accessMappingFromCache = await redisGetJson(accessMappingCacheKey);

  if (accessMappingFromCache) {
    return res.json(accessMappingFromCache);
  } else {
    await AccessMapping.findOne(
      {
        role: req.params.role.trim(),
        isActive: true,
      },
      {
        _id: 0,
        role: 1,
        desc: 1,
        "accessMapping.objectKey": 1,
        "accessMapping.desc": 1,
        "accessMapping.module": 1,
        "accessMapping.isAllowed": 1,
        "accessMapping.isRedactable": 1,
        "accessMapping.isRedacted": 1,
        "accessMapping.isAdminOnly": 1,
      }
    )
      .then(async (accessMappingFromDb) => {
        if (accessMappingFromDb) {
          await redisSetJson(accessMappingCacheKey, accessMappingFromDb);
          return res.json(accessMappingFromDb);
        } else {
          throw new Error();
        }
      })
      .catch(next);
  }
});

router.put("/:role/setaccessmapping", auth.required, async (req, res, next) => {
  const role = req.params.role.trim();

  if (role == "") {
    res.json({ status: "Error", msg: "Invalid role" });
  } else {
    if (req.body.accessMappings.length > 0) {
      await AccessMapping.findOne({
        role,
        isActive: true,
      })
        .then(async (data) => {
          if (!data) {
            res.json({ status: "Error", msg: "Role not found" });
          } else {
            await updateBulkAccessMapping(
              role,
              req.body.accessMappings,
              data.accessMapping,
              req.payload.email
            )
              .then((v) => Promise.all(v))
              .then(async (v) => {
                const accessMappingCacheKey =
                  Constants.accessControlConfig
                    .ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX + role.trim();
                await redisDeleteKey(accessMappingCacheKey);
                res.json(v);
              })
              .catch(next);
          }
        })
        .catch(next);
    } else {
      res.json([]);
    }
  }
});

const updateBulkAccessMapping = async (
  role,
  accessMappingsInput,
  accessMappingDb,
  email
) => {
  return accessMappingsInput.map(async (accessMappingInput) => {
    return new Promise(async (resolve) => {
      if (
        !("isRedacted" in accessMappingInput) ||
        !(typeof accessMappingInput.isRedacted == "boolean") ||
        !(typeof accessMappingInput.isAllowed == "boolean") ||
        !("isAllowed" in accessMappingInput) ||
        !accessMappingInput.objectKey ||
        accessMappingInput.objectKey.trim() == ""
      ) {
        resolve({
          objectKey: accessMappingInput.objectKey,
          status: "Error",
          msg: "Invalid input",
        });
      }

      const objectDb = accessMappingDb.find(
        (item) => item.objectKey == accessMappingInput.objectKey
      );

      if (objectDb) {
        await AccessMapping.updateOne(
          {
            role,
            "accessMapping.objectKey": accessMappingInput.objectKey,
          },
          {
            $set: {
              "accessMapping.$.isAllowed": objectDb.isRedactable
                ? accessMappingInput.isRedacted
                  ? false
                  : accessMappingInput.isAllowed
                : accessMappingInput.isAllowed,
              "accessMapping.$.isRedacted": objectDb.isRedactable
                ? accessMappingInput.isRedacted
                : false,
              "accessMapping.$.updatedBy": email,
            },
          }
        )
          .then(() => {
            resolve({
              objectKey: accessMappingInput.objectKey,
              status: "Success",
            });
          })
          .catch(() => {
            resolve({
              objectKey: accessMappingInput.objectKey,
              status: "Error",
              msg: "Update failed",
            });
          });
      } else {
        resolve({
          objectKey: accessMappingInput.objectKey,
          status: "Error",
          msg: "Key not found",
        });
      }
    });
  });
};

router.post("/createaccessmapping", auth.required, async (req, res, next) => {
  const role = req.body.role?.trim();
  const desc = req.body.desc?.trim() ?? role;
  const inputAccessMapping = req.body.accessMapping;

  if (!role || !inputAccessMapping || inputAccessMapping.length < 1) {
    res.json({ status: "Error", msg: "Invalid input" });
  } else {
    await AccessMapping.findOne({
      role,
      isActive: true,
    })
      .then(async (data) => {
        if (data) {
          res.json({ status: "Error", msg: "Role already exists" });
        } else {
          await AccessMapping.findOne({
            role: "Super Admin",
            isActive: true,
          })
            .then(async (sAdmin) => {
              const email = req.payload.email;
              const newAccessMapping = [];
              let isValidAccessMappings = true;

              sAdmin.accessMapping.forEach((adminAccessMapping) => {
                const inputObj = inputAccessMapping.find(
                  (item) => item.objectKey == adminAccessMapping.objectKey
                );

                if (inputObj) {
                  if (
                    !("objectKey" in inputObj) ||
                    !("isAllowed" in inputObj) ||
                    !(typeof inputObj.isAllowed == "boolean") ||
                    !("isRedacted" in inputObj) ||
                    !(typeof inputObj.isRedacted == "boolean")
                  ) {
                    isValidAccessMappings = false;
                  }

                  newAccessMapping.push({
                    objectKey: adminAccessMapping.objectKey,
                    desc: adminAccessMapping.desc,
                    module: adminAccessMapping.module,
                    type: adminAccessMapping.type,
                    isAllowed: adminAccessMapping.isRedactable
                      ? inputObj.isRedacted
                        ? false
                        : inputObj.isAllowed
                      : inputObj.isAllowed,
                    isRedactable: adminAccessMapping.isRedactable,
                    isRedacted: adminAccessMapping.isRedactable
                      ? inputObj.isRedacted
                      : false,
                    isAdminOnly: adminAccessMapping.isAdminOnly,
                    createdBy: email,
                    updatedBy: email,
                  });
                } else {
                  newAccessMapping.push({
                    objectKey: adminAccessMapping.objectKey,
                    desc: adminAccessMapping.desc,
                    module: adminAccessMapping.module,
                    type: adminAccessMapping.type,
                    isAllowed: false,
                    isRedactable: adminAccessMapping.isRedactable,
                    isRedacted: true,
                    isAdminOnly: adminAccessMapping.isAdminOnly,
                    createdBy: email,
                    updatedBy: email,
                  });
                }
              });

              if (isValidAccessMappings) {
                const acessMapping = new AccessMapping({
                  role,
                  desc,
                  isActive: true,
                  accessMapping: newAccessMapping,
                  createdBy: email,
                  updatedBy: email,
                });

                await acessMapping
                  .save()
                  .then(async () => {
                    res.json({
                      status: "Success",
                      msg: "Access mapping created",
                    });
                  })
                  .catch(next);
              } else {
                res.json({ status: "Error", msg: "Invalid access mappings" });
              }
            })
            .catch(next);
        }
      })
      .catch(next);
  }
});

router.post(
  "/:fromrole/:torole/copyaccessmapping",
  auth.required,
  async (req, res, next) => {
    const fromRole = req.params.fromrole.trim();
    const toRole = req.params.torole.trim();

    if ((fromRole == "") | (toRole == "")) {
      res.json({ status: "Error", msg: "Invalid role" });
    } else {
      const email = req.payload.email;
      await Promise.all([
        AccessMapping.findOne(
          {
            role: fromRole,
            isActive: true,
          },
          {
            _id: 0,
            "accessMapping.objectKey": 1,
            "accessMapping.desc": 1,
            "accessMapping.module": 1,
            "accessMapping.type": 1,
            "accessMapping.isAllowed": 1,
            "accessMapping.isRedactable": 1,
            "accessMapping.isRedacted": 1,
            "accessMapping.isAdminOnly": 1,
          }
        ),
        AccessMapping.findOne({
          role: toRole,
          isActive: true,
        }),
      ])
        .then(async (results) => {
          const [sourceRoleMapping, targetRoleMapping] = results;

          if (!sourceRoleMapping || !targetRoleMapping) {
            res.json({ status: "Error", msg: "Role not found" });
          } else {
            sourceRoleMapping.accessMapping.forEach((element) => {
              element.createdBy = email;
              element.updatedBy = email;
            });

            await AccessMapping.updateOne(
              {
                role: toRole,
              },
              {
                $set: {
                  accessMapping: sourceRoleMapping.accessMapping,
                  createdBy: email,
                  updatedBy: email,
                },
              }
            )
              .then(async () => {
                const accessMappingCacheKey =
                  Constants.accessControlConfig
                    .ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX + toRole;
                await redisDeleteKey(accessMappingCacheKey);

                AccessMapping.findOne(
                  {
                    role: toRole,
                    isActive: true,
                  },
                  {
                    _id: 0,
                    role: 1,
                    desc: 1,
                    "accessMapping.objectKey": 1,
                    "accessMapping.desc": 1,
                    "accessMapping.module": 1,
                    "accessMapping.type": 1,
                    "accessMapping.isAllowed": 1,
                    "accessMapping.isRedactable": 1,
                    "accessMapping.isRedacted": 1,
                    "accessMapping.isAdminOnly": 1,
                  }
                )
                  .then((data) => {
                    res.json(data);
                  })
                  .catch(next);
              })
              .catch(next);
          }
        })
        .catch(next);
    }
  }
);

router.post(
  "/createandcopyaccessmapping",
  auth.required,
  async (req, res, next) => {
    if (
      !("fromRole" in req.body) ||
      !("toNewRole" in req.body) ||
      req.body.fromRole.trim() == "" ||
      req.body.toNewRole.trim() == ""
    ) {
      res.json({ status: "Error", msg: "Invalid role" });
    } else {
      const fromRole = req.body.fromRole.trim();
      const toNewRole = req.body.toNewRole.trim();
      const toNewRoleDesc = req.body.toNewRoleDesc?.trim();

      await Promise.all([
        AccessMapping.findOne(
          {
            role: fromRole,
            isActive: true,
          },
          {
            _id: 0,
            "accessMapping.objectKey": 1,
            "accessMapping.desc": 1,
            "accessMapping.module": 1,
            "accessMapping.type": 1,
            "accessMapping.isAllowed": 1,
            "accessMapping.isRedactable": 1,
            "accessMapping.isRedacted": 1,
            "accessMapping.isAdminOnly": 1,
          }
        ),
        AccessMapping.findOne({
          role: toNewRole,
          isActive: true,
        }),
      ])
        .then(async (results) => {
          const [sourceRoleMapping, targetNewRoleMapping] = results;

          if (!sourceRoleMapping) {
            res.json({ status: "Error", msg: "Source role not found" });
          } else if (targetNewRoleMapping) {
            res.json({ status: "Error", msg: "Target role already exists" });
          } else {
            const email = req.payload.email;
            sourceRoleMapping.accessMapping.forEach((element) => {
              element.createdBy = email;
              element.updatedBy = email;
            });
            const accessMapping = new AccessMapping({
              role: toNewRole,
              desc: toNewRoleDesc,
              isActive: true,
              accessMapping: sourceRoleMapping.accessMapping,
              createdBy: email,
              updatedBy: email,
            });

            await accessMapping
              .save()
              .then(async () => {
                const accessMappingCacheKey =
                  Constants.accessControlConfig
                    .ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX + toNewRole;
                await redisDeleteKey(accessMappingCacheKey);

                AccessMapping.findOne(
                  {
                    role: toNewRole,
                    isActive: true,
                  },
                  {
                    _id: 0,
                    role: 1,
                    desc: 1,
                    "accessMapping.objectKey": 1,
                    "accessMapping.desc": 1,
                    "accessMapping.module": 1,
                    "accessMapping.type": 1,
                    "accessMapping.isAllowed": 1,
                    "accessMapping.isRedactable": 1,
                    "accessMapping.isRedacted": 1,
                    "accessMapping.isAdminOnly": 1,
                  }
                )
                  .then((data) => {
                    res.json(data);
                  })
                  .catch(next);
              })
              .catch(next);
          }
        })
        .catch(next);
    }
  }
);

/*
  Sample body format:
  {
    "objectKey": ["YOUR_ACCESS_POINT_KEY1", "YOUR_ACCESS_POINT_KEY2"]
  }
*/
router.post(
  "/getaccesspointallrolesformat",
  auth.required,
  async (req, res, next) => {
    if (req.body.objectKey && req.body.objectKey.length > 0) {
      await AccessMapping.find(
        {
          isActive: true,
        },
        {
          _id: 0,
          role: 1,
          desc: 1,
        },
        {
          sort: {
            desc: 1,
          },
        }
      )
        .then(async (data) => {
          const roles = [];

          data.forEach((role) => {
            roles.push({
              role: role.role,
              isAllowed: role.role == "Super Admin" ? true : false,
              isRedactable: false,
              isRedacted: false,
              isAdminOnly: false,
            });
          });

          const final = {
            accessPoints: req.body.objectKey.map((key) => ({
              objectKey: key,
              desc: "Unknown",
              module: "Unknown",
              type: "ui/api",
              roles: roles,
            })),
          };

          res.json(final);
        })
        .catch(next);
    } else {
      res.json({ msg: "Missing objectKeys" });
    }
  }
);

/* 
  Instruction:
  run POST /accesscontrol/getaccesspointallrolesformat with objectKeys (see api instructions)
  to get the body format for below api
*/
//For manual insert
router.put("/addaccesspointallroles", auth.required, async (req, res, next) => {
  let isValidInput = true;
  let msg = "";
  let result = {};

  const accessMappingDb = await AccessMapping.find(
    {
      isActive: true,
    },
    {
      _id: 0,
      role: 1,
      "accessMapping.objectKey": 1,
      "accessMapping.desc": 1,
      "accessMapping.isAllowed": 1,
      "accessMapping.isRedactable": 1,
      "accessMapping.isRedacted": 1,
      "accessMapping.isAdminOnly": 1,
    }
  );

  if (req.body.accessPoints && req.body.accessPoints.length > 0) {
    req.body.accessPoints.forEach((accessPointInput) => {
      if (
        accessPointInput.objectKey &&
        accessPointInput.desc &&
        accessPointInput.module &&
        accessPointInput.type &&
        accessPointInput.roles &&
        accessPointInput.roles.length > 0
      ) {
        //Check if the provided access points are already present in db
        accessMappingDb.forEach((roleDb) => {
          roleDb.accessMapping.forEach((objDb) => {
            if (accessPointInput.objectKey == objDb.objectKey) {
              isValidInput = false;
              msg =
                msg +
                ` objectKey '${accessPointInput.objectKey}' already present for role '${roleDb.role}';`;
            }
          });
        });

        accessPointInput.roles.forEach((roleInput) => {
          if (
            !roleInput.role ||
            !("isAllowed" in roleInput) ||
            !("isRedactable" in roleInput) ||
            !("isRedacted" in roleInput) ||
            !("isAdminOnly" in roleInput)
          ) {
            isValidInput = false;
            msg =
              msg +
              " Missing role/isAllowed/isRedactable/isRedacted/isAdminOnly;";
          }

          if (!roleInput.isRedactable && roleInput.isRedacted) {
            isValidInput = false;
            msg =
              msg +
              ` Invalid isRedacted value for role '${roleInput.role}' for objectKey '${accessPointInput.objectKey}';`;
          }

          //Check if the roles specified are actual roles in db
          let rolePresent = false;
          accessMappingDb.forEach((roleDb) => {
            if (roleDb.role == roleInput.role) {
              rolePresent = true;
            }
          });

          if (!rolePresent) {
            isValidInput = false;
            msg =
              msg +
              ` Role '${roleInput.role}' for objectKey '${accessPointInput.objectKey}' not exists;`;
          }
        });

        //Check if any roles missing for the input access mappings
        accessMappingDb.forEach((roleDb) => {
          let roleExists = false;
          accessPointInput.roles.forEach((roleInput) => {
            if (roleDb.role == roleInput.role) {
              roleExists = true;
            }
          });

          if (!roleExists) {
            isValidInput = false;
            msg =
              msg +
              ` Role '${roleDb.role}' missing for objectKey '${accessPointInput.objectKey}';`;
          }
        });
      } else {
        msg = msg = " Missing objectKey/module/type/roles;";
        isValidInput = false;
      }
    });
  } else {
    isValidInput = false;
  }

  if (!isValidInput) {
    result.status = "Error";
  }

  if (msg) {
    result.msg = msg;
  }

  if (isValidInput && !msg) {
    const email = req.payload.email;
    const tempInput = [];
    accessMappingDb.forEach((roleDb) => {
      tempInput.push({ role: roleDb.role, accessMapping: [] });
    });

    req.body.accessPoints.forEach((accessPointInput) => {
      accessPointInput.roles.forEach((roleInput) => {
        const tempRole = tempInput.find((item) => item.role == roleInput.role);
        tempRole.accessMapping.push({
          objectKey: accessPointInput.objectKey,
          desc: accessPointInput.desc,
          module: accessPointInput.module,
          type: accessPointInput.type,
          isAllowed: roleInput.isAllowed,
          isRedactable: roleInput.isRedactable,
          isRedacted: roleInput.isRedacted,
          isAdminOnly: roleInput.isAdminOnly,
          createdBy: email,
          updatedBy: email,
          createdAt: new Date(),
          updatedAt: new Date(),
        });
      });
    });

    await insertBulkNewAccessMappings(tempInput, email)
      .then((v) => Promise.all(v))
      .then(async (v) => {
        result.status = "Success";
        result.details = v;
      })
      .catch(next);
  }

  res.json(result);
});

router.delete("/removecachekey/:key", auth.required, async (req, res, next) => {
  if (req.params.key.trim()) {
    const cacheValue = await redisGetJson(req.params.key);

    if (cacheValue) {
      await redisDeleteKey(req.params.key);
      res.json({ status: "success", msg: "Key removed" });
    } else {
      res.json({ status: "error", msg: "Key not found" });
    }
  } else {
    res.json({ status: "error", msg: "Invalid key" });
  }
});

router.get("/getallcachekeys", auth.required, async (req, res, next) => {
  await redisGetAllKeys()
    .then((val) => {
      res.json(val);
    })
    .catch(next);
});

router.post("/setCache", auth.required, async (req, res, next) => {
  console.log(req.body.key, req.body.value);
  if (req.body.key && req.body.value) {
    redisSetJson(req.body.key, req.body.value)
      .then(() => {
        res.json({ status: "success" });
      })
      .catch(next);
  }
});

const insertBulkNewAccessMappings = async (input, email) => {
  return input.map(async (role) => {
    return new Promise(async (resolve) => {
      await AccessMapping.updateOne(
        {
          role: role.role,
        },
        {
          $set: {
            updatedBy: email,
          },
          $push: {
            accessMapping: role.accessMapping,
          },
        }
      )
        .then(async () => {
          const accessMappingCacheKey =
            Constants.accessControlConfig.ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX +
            role.role;
          await redisDeleteKey(accessMappingCacheKey);
          resolve({
            role: role.role,
            objectKeys: [...role.accessMapping.map((item) => item.objectKey)],
            status: "Success",
          });
        })
        .catch(() => {
          resolve({
            role: role.role,
            objectKeys: [...role.accessMapping.map((item) => item.objectKey)],
            status: "Error",
            msg: "Update failed",
          });
        });
    });
  });
};

//For manual delete
router.delete("/:objectkey/remove", auth.required, async (req, res, next) => {
  const objectKey = req.params.objectkey.trim();

  if (objectKey) {
    AccessMapping.find(
      {
        isActive: true,
      },
      {
        _id: 0,
        role: 1,
      }
    )
      .then(async (roles) => {
        if (roles) {
          await deleteBulkAccessMapping(roles, objectKey, req.payload.email)
            .then((v) => Promise.all(v))
            .then(async (v) => {
              res.json({
                status: "Success",
                details: v,
              });
            })
            .catch(next);
        } else {
          res.json({ status: "Error", msg: "Roles not found" });
        }
      })
      .catch(next);
  } else {
    res.json({ status: "Error", msg: "Invalid input" });
  }
});

const deleteBulkAccessMapping = async (roles, objectKey, email) => {
  return roles.map(async (role) => {
    return new Promise(async (resolve) => {
      await AccessMapping.updateOne(
        {
          role: role.role,
        },
        {
          $set: {
            updatedBy: email,
          },
          $pull: {
            accessMapping: { objectKey },
          },
        }
      )
        .then(async (data) => {
          const accessMappingCacheKey =
            Constants.accessControlConfig.ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX +
            role.role;
          await redisDeleteKey(accessMappingCacheKey);
          resolve({
            role: role.role,
            objectKey,
            status: "Removed",
          });
        })
        .catch(() => {
          resolve({
            role: role.role,
            objectKey,
            status: "Error",
            msg: "Delete failed",
          });
        });
    });
  });
};

module.exports = router;
