"use strict";
var Excel = require("exceljs");
const router = require("express").Router();
const mongoose = require("mongoose");
const MasterData = mongoose.model("MasterData");
const Project = mongoose.model("Project");
const ExteriorWBS = mongoose.model("ExteriorWBS");
const InteriorWBS = mongoose.model("InteriorWBS");
const WorkSchedule = mongoose.model("WorkSchedule");
const _ = require("underscore");
const auth = require("../auth");
const uuid = require("uuid");
const moment = require("moment-timezone");
const asyncPackage = require("async");

// Preload project objects on routes with ':project'
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

// return a list of tags
router.get("/:project/createExcel", auth.required, async (req, res, next) => {
  var workbook = new Excel.Workbook();
  let worksheet = workbook.addWorksheet("WBS");
  let worksheetMasterData = workbook.addWorksheet("MasterData");
  worksheetMasterData.state = "hidden";
  let worksheetCategoryData = workbook.addWorksheet("CategoryData");
  worksheetCategoryData.state = "hidden";
  let worksheetClassificationData = workbook.addWorksheet("ClassificationData");
  worksheetClassificationData.state = "hidden";
  let sheetName = req.project.projectName + ".xlsx";

  await MasterData.findOne({
    projectId: req.params.project,
  })
    .then(async (data) => {
      const locations = data?.workLocation;

      if (locations.length > 0) {
        _.each(locations, function (loc) {
          if (!loc.level3 && !loc.level4) {
            worksheetMasterData.addRow([
              loc.locationId,
              loc.level2 ? loc.level1 + "-" + loc.level2 : loc.level1,
            ]);
          }
        });
      }
      const categories = data?.workPackage;
      if (categories.length > 0) {
        _.each(categories, function (category) {
          if (!!category.tradeName) {
            worksheetCategoryData.addRow([
              category.tradeId,
              category.tradeName,
            ]);
          }
        });
      }
      let classifications = data?.workClassification;
      if (!classifications || classifications.length <= 0) {
        classifications = ["Dry", "Wet"];
      }
      _.each(classifications, function (classification) {
        if (!!classification) {
          worksheetClassificationData.addRow([classification]);
        }
      });
      worksheet.columns = [
        {
          header: "Activity",
          key: "activity",
          width: 32,
        },
        {
          header: "StartDate",
          key: "startDate",
          width: 25,
        },
        {
          header: "EndDate",
          key: "endDate",
          width: 25,
        },
        {
          header: "Type",
          key: "type",
          width: 22,
        },
        {
          header: "Location",
          key: "location",
          width: 35,
        },
        {
          header: "Category",
          key: "category",
          width: 35,
        },
        {
          header: "Classification",
          key: "classification",
          width: 35,
        },
      ];

      for (let i = 2; i < 1000; i++) {
        worksheet.getCell(`D${i}`).dataValidation = {
          type: "list",
          allowBlank: true,
          formulae: ['"none, interior, exterior"'],
          errorStyle: "error",
          errorTitle: "choose a gender ",
          error: "must be interior, exterior or none",
        };
      }

      worksheet.dataValidations.add("E2:E1000", {
        type: "list",
        allowBlank: false,
        formulae: ["=MasterData!$B$1:$B$9999"],
        showErrorMessage: true,
        errorStyle: "error",
        error: "Please select a valid value from the list",
      });
      worksheet.dataValidations.add("F2:F1000", {
        type: "list",
        allowBlank: true,
        formulae: ["=CategoryData!$B$1:$B$9999"],
        showErrorMessage: true,
        errorStyle: "error",
        error: "Please select a valid value from the list",
      });
      worksheet.dataValidations.add("G2:G1000", {
        type: "list",
        allowBlank: true,
        formulae: ["=ClassificationData!$A$1:$A$9999"],
        showErrorMessage: true,
        errorStyle: "error",
        error: "Please select a valid value from the list",
      });
      res.setHeader("Content-Type", "text/plain");
      const fileBuffer = await workbook.xlsx.writeBuffer();
      res.send(fileBuffer.toString("base64"));
    })
    .catch(next);
});

// remove wbs line item - interior
router.delete(
  "/:project/interior/remove/:towerId/:floorId/:wbsId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.wbsId) {
        const projectId = req.params.project;
        const towerId = req.params.towerId;
        const floorId = req.params.floorId;
        const projectData = await Project.findOne({
          projectId: projectId,
        }).exec();
        const isUnitLevel = projectData?.isUnitLevel;
        if (isUnitLevel) {
          InteriorWBS.find({
            projectId: req.params.project,
            towerId: req.params.towerId,
            floorId: req.params.floorId,
          }).then(async (wbsDataList) => {
            if (wbsDataList && wbsDataList.length > 0) {
              for (let wbsData of wbsDataList) {
                await InteriorWBS.findOneAndUpdate(
                  {
                    projectId: req.project.projectId,
                    towerId: req.params.towerId,
                    floorId: req.params.floorId,
                    unitId: wbsData.unitId,
                  },
                  {
                    $pull: {
                      wbsList: {
                        wbsId: req.params.wbsId,
                      },
                    },
                  },
                  {
                    new: true,
                  }
                )
                  .then(async () => {
                    await recalculateDurationAndWeightageInt(
                      projectId,
                      towerId,
                      floorId,
                      true,
                      wbsData.unitId
                    );
                  })
                  .catch(next);
              }
              res.json({
                status: "success",
              });
            }
          });
        } else {
          await InteriorWBS.findOneAndUpdate(
            {
              projectId: req.project.projectId,
              towerId: req.params.towerId,
              floorId: req.params.floorId,
            },
            {
              $pull: {
                wbsList: {
                  wbsId: req.params.wbsId,
                },
              },
            },
            {
              new: true,
            }
          )
            .then(async () => {
              await recalculateDurationAndWeightageInt(
                projectId,
                towerId,
                floorId
              );
              res.json({
                status: "success",
              });
            })
            .catch(next);
        }
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

// remove wbs line item - exterior
router.delete(
  "/:project/exterior/remove/:towerId/:wbsId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.params.wbsId) {
        const projectId = req.params.project;
        const towerId = req.params.towerId;
        await ExteriorWBS.findOneAndUpdate(
          {
            projectId: req.project.projectId,
            towerId: req.params.towerId,
          },
          {
            $pull: {
              wbsList: {
                wbsId: req.params.wbsId,
              },
            },
          },
          {
            new: true,
          }
        )
          .then(async () => {
            await recalculateDurationAndWeightageExt(projectId, towerId);
            res.json({
              status: "success",
            });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/interior/create/:towerId/:floorId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const wbsObj = req.body.wbs;
      const projectId = req.params.project;
      const towerId = req.params.towerId;
      const floorId = req.params.floorId;
      const projectData = await Project.findOne({
        projectId: projectId,
      }).exec();
      const isUnitLevel = projectData?.isUnitLevel;
      if (isUnitLevel) {
        const newWbsId = uuid.v4();
        InteriorWBS.find({
          projectId: req.params.project,
          towerId: req.params.towerId,
          floorId: req.params.floorId,
        })
          .then(async (wbsDataList) => {
            if (wbsDataList && wbsDataList.length > 0) {
              for (let wbsData of wbsDataList) {
                let wbs = {};
                wbs.wbsId = newWbsId;
                wbs.description = wbsObj.description;
                wbs.startDate = wbsObj.startDate;
                wbs.finishDate = wbsObj.finishDate;
                wbs.category = wbsObj.category;
                wbs.classification = wbsObj.classification;
                const taskStart = new Date(
                  moment(wbsObj.startDate).utcOffset(0)
                ).setHours(0, 0, 0, 0);

                const taskEnd = new Date(
                  moment(wbsObj.finishDate).utcOffset(0)
                ).setHours(0, 0, 0, 0);

                const diffTime = Math.abs(taskEnd - taskStart);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                wbs.duration = diffDays > 0 ? diffDays + 1 : 1;

                wbs.weightage = 0;
                wbs.planned = 0;
                wbs.actual = 0;
                wbs.comment = "";

                wbsData.wbsList.push(wbs);

                await wbsData
                  .save()
                  .then(async () => {
                    await recalculateDurationAndWeightageInt(
                      projectId,
                      towerId,
                      floorId,
                      true,
                      wbsData.unitId
                    );
                  })
                  .catch(next);
              }
              res.json({
                status: "success",
              });
            }
          })
          .catch(next);
      } else {
        InteriorWBS.findOne({
          projectId: req.params.project,
          towerId: req.params.towerId,
          floorId: req.params.floorId,
        })
          .then(async (wbsData) => {
            if (wbsData) {
              let wbs = {};
              wbs.wbsId = uuid.v4();
              wbs.description = wbsObj.description;
              wbs.startDate = wbsObj.startDate;
              wbs.finishDate = wbsObj.finishDate;
              wbs.category = wbsObj.category;
              wbs.classification = wbsObj.classification;
              const taskStart = new Date(
                moment(wbsObj.startDate).utcOffset(0)
              ).setHours(0, 0, 0, 0);

              const taskEnd = new Date(
                moment(wbsObj.finishDate).utcOffset(0)
              ).setHours(0, 0, 0, 0);

              const diffTime = Math.abs(taskEnd - taskStart);
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
              wbs.duration = diffDays > 0 ? diffDays + 1 : 1;

              wbs.weightage = 0;
              wbs.planned = 0;
              wbs.actual = 0;
              wbs.comment = "";

              wbsData.wbsList.push(wbs);

              await wbsData
                .save()
                .then(async () => {
                  await recalculateDurationAndWeightageInt(
                    projectId,
                    towerId,
                    floorId
                  );
                  res.json({
                    status: "success",
                  });
                })
                .catch(next);
            }
          })
          .catch(next);
      }
    } else {
      res.sendStatus(401);
    }
  }
);

router.post(
  "/:project/exterior/create/:towerId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const wbsObj = req.body.wbs;
      const projectId = req.params.project;
      const towerId = req.params.towerId;

      ExteriorWBS.findOne({
        projectId: req.params.project,
        towerId: req.params.towerId,
      })
        .then(async (wbsData) => {
          if (wbsData) {
            let wbs = {};
            wbs.wbsId = uuid.v4();
            wbs.description = wbsObj.description;
            wbs.startDate = wbsObj.startDate;
            wbs.finishDate = wbsObj.finishDate;

            const taskStart = new Date(
              moment(wbsObj.startDate).utcOffset(0)
            ).setHours(0, 0, 0, 0);

            const taskEnd = new Date(
              moment(wbsObj.finishDate).utcOffset(0)
            ).setHours(0, 0, 0, 0);

            const diffTime = Math.abs(taskEnd - taskStart);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            wbs.duration = diffDays > 0 ? diffDays + 1 : 1;

            wbs.weightage = 0;
            wbs.planned = 0;
            wbs.actual = 0;
            wbs.comment = "";

            wbsData.wbsList.push(wbs);

            await wbsData
              .save()
              .then(async () => {
                await recalculateDurationAndWeightageExt(projectId, towerId);
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          }
        })
        .catch(next);
    } else {
      res.sendStatus(401);
    }
  }
);

router.put(
  "/:project/interior/update/:towerId/:floorId/:wbsId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const wbsObj = req.body.wbs;
      const isRecalculate = req.body.isRecalculate;
      const projectId = req.params.project;
      const towerId = req.params.towerId;
      const floorId = req.params.floorId;
      const projectData = await Project.findOne({
        projectId: projectId,
      }).exec();
      const isUnitLevel = projectData?.isUnitLevel;
      if (isUnitLevel) {
        InteriorWBS.find({
          projectId: req.params.project,
          towerId: req.params.towerId,
          floorId: req.params.floorId,
        }).then(async (wbsDataList) => {
          if (wbsDataList && wbsDataList.length > 0) {
            for (let wbsData of wbsDataList) {
              if (wbsData) {
                wbsData.wbsList.forEach((wbs) => {
                  if (wbs.wbsId === req.params.wbsId) {
                    wbs.description = wbsObj.description;
                    wbs.startDate = wbsObj.startDate;
                    wbs.finishDate = wbsObj.finishDate;
                    wbs.category = wbsObj.category;
                    wbs.classification = wbsObj.classification;
                    const taskStart = new Date(
                      moment(wbsObj.startDate).utcOffset(0)
                    ).setHours(0, 0, 0, 0);

                    const taskEnd = new Date(
                      moment(wbsObj.finishDate).utcOffset(0)
                    ).setHours(0, 0, 0, 0);

                    const diffTime = Math.abs(taskEnd - taskStart);
                    const diffDays = Math.ceil(
                      diffTime / (1000 * 60 * 60 * 24)
                    );
                    wbs.duration = diffDays > 0 ? diffDays + 1 : 1;
                    if (isRecalculate) {
                      wbs.weightage = 0;
                      wbs.planned = 0;
                      wbs.actual = 0;
                      wbs.comment = "";
                    }
                  }
                });

                await wbsData
                  .save()
                  .then(async () => {
                    if (isRecalculate) {
                      await recalculateDurationAndWeightageInt(
                        projectId,
                        towerId,
                        floorId,
                        true,
                        wbsData.unitId
                      );
                    }
                  })
                  .catch(next);
              }
            }
            res.json({
              status: "success",
            });
          }
        });
      } else {
        InteriorWBS.findOne({
          projectId: req.params.project,
          towerId: req.params.towerId,
          floorId: req.params.floorId,
        })
          .then(async (wbsData) => {
            if (wbsData) {
              wbsData.wbsList.forEach((wbs) => {
                if (wbs.wbsId === req.params.wbsId) {
                  wbs.description = wbsObj.description;
                  wbs.startDate = wbsObj.startDate;
                  wbs.finishDate = wbsObj.finishDate;
                  wbs.category = wbsObj.category;
                  wbs.classification = wbsObj.classification;
                  const taskStart = new Date(
                    moment(wbsObj.startDate).utcOffset(0)
                  ).setHours(0, 0, 0, 0);

                  const taskEnd = new Date(
                    moment(wbsObj.finishDate).utcOffset(0)
                  ).setHours(0, 0, 0, 0);

                  const diffTime = Math.abs(taskEnd - taskStart);
                  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                  wbs.duration = diffDays > 0 ? diffDays + 1 : 1;
                  if (isRecalculate) {
                    wbs.weightage = 0;
                    wbs.planned = 0;
                    wbs.actual = 0;
                    wbs.comment = "";
                  }
                }
              });

              await wbsData
                .save()
                .then(async () => {
                  if (isRecalculate) {
                    await recalculateDurationAndWeightageInt(
                      projectId,
                      towerId,
                      floorId
                    );
                  }
                  res.json({
                    status: "success",
                  });
                })
                .catch(next);
            }
          })
          .catch(next);
      }
    } else {
      res.sendStatus(401);
    }
  }
);

router.put(
  "/:project/exterior/update/:towerId/:wbsId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const wbsObj = req.body.wbs;
      const projectId = req.params.project;
      const towerId = req.params.towerId;

      ExteriorWBS.findOne({
        projectId: req.params.project,
        towerId: req.params.towerId,
      })
        .then(async (wbsData) => {
          if (wbsData) {
            wbsData.wbsList.forEach((wbs) => {
              if (wbs.wbsId === req.params.wbsId) {
                wbs.description = wbsObj.description;
                wbs.startDate = wbsObj.startDate;
                wbs.finishDate = wbsObj.finishDate;

                const taskStart = new Date(
                  moment(wbsObj.startDate).utcOffset(0)
                ).setHours(0, 0, 0, 0);

                const taskEnd = new Date(
                  moment(wbsObj.finishDate).utcOffset(0)
                ).setHours(0, 0, 0, 0);

                const diffTime = Math.abs(taskEnd - taskStart);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                wbs.duration = diffDays > 0 ? diffDays + 1 : 1;

                wbs.weightage = 0;
                wbs.planned = 0;
                wbs.actual = 0;
                wbs.comment = "";
              }
            });

            await wbsData
              .save()
              .then(async () => {
                await recalculateDurationAndWeightageExt(projectId, towerId);

                res.json({
                  status: "success",
                });
              })
              .catch(next);
          }
        })
        .catch(next);
    } else {
      res.sendStatus(401);
    }
  }
);

router.put(
  "/:project/interior/calculateWeightage/:towerId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      const projectId = req.params.project;
      const towerId = req.params.towerId;
      const projectData = await Project.findOne({
        projectId: projectId,
      }).exec();
      if (!!projectData) {
        await updateInternalWeightage(projectId, towerId);
        res.json({
          status: "success",
        });
      }
    } else {
      res.sendStatus(401);
    }
  }
);

router.put(
  "/:project/performanceindex/:type/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      let performanceIndex;
      await MasterData.findOne({
        projectId: req.params.project,
      }).then((data) => {
        performanceIndex = data?.performanceIndex;
      });
      let performanceIndexData = {};
      let toBeUpdated = {};
      let isNewEntry = true;
      if (performanceIndex) {
        isNewEntry = false;
        performanceIndexData = performanceIndex;
      }
      if (isNewEntry) {
        performanceIndexData[req.params.type] = req.body.performanceIndex;
        performanceIndexData[req.params.type].createdAt = new Date();
        performanceIndexData[req.params.type].createdBy = req.payload.email;
        performanceIndexData[req.params.type].updatedAt = new Date();
        performanceIndexData[req.params.type].updatedBy = req.payload.email;
      } else {
        let existingCreatedAt = performanceIndex[req.params.type]?.createdAt;
        let existingCreatedBy = performanceIndex[req.params.type]?.createdBy;
        performanceIndexData[req.params.type] = req.body.performanceIndex;
        performanceIndexData[req.params.type].createdAt = existingCreatedAt
          ? existingCreatedAt
          : new Date();
        performanceIndexData[req.params.type].createdBy = existingCreatedBy
          ? existingCreatedBy
          : req.payload.email;
        performanceIndexData[req.params.type].updatedAt = new Date();
        performanceIndexData[req.params.type].updatedBy = req.payload.email;
      }
      toBeUpdated.performanceIndex = performanceIndexData;
      await MasterData.findOneAndUpdate(
        {
          projectId: req.params.project,
        },
        {
          $set: toBeUpdated,
        }
      )
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else {
      res.sendStatus(401);
    }
  }
);

const recalculateDurationAndWeightageInt = async (
  projectId,
  towerId,
  floorId,
  isUnitLevel = false,
  unitId = null
) => {
  if (isUnitLevel) {
    InteriorWBS.findOne({
      projectId: projectId,
      towerId: towerId,
      floorId: floorId,
      unitId: unitId,
    }).then(async (wbsData) => {
      if (wbsData) {
        let projectDuration = 0;
        projectDuration = wbsData.wbsList.reduce((s, f) => {
          return s + f.duration;
        }, 0);

        wbsData.projectDuration = projectDuration;
        wbsData.isActualPublished = false;

        await wbsData.save().then(async () => {
          await updateInternalWeightage(projectId, towerId);
        });
      }
    });
  } else {
    InteriorWBS.findOne({
      projectId: projectId,
      towerId: towerId,
      floorId: floorId,
    }).then(async (wbsData) => {
      if (wbsData) {
        let projectDuration = 0;
        projectDuration = wbsData.wbsList.reduce((s, f) => {
          return s + f.duration;
        }, 0);

        wbsData.projectDuration = projectDuration;
        wbsData.isActualPublished = false;

        await wbsData.save().then(async () => {
          await updateInternalWeightage(projectId, towerId);
        });
      }
    });
  }
};

const recalculateDurationAndWeightageExt = async (projectId, towerId) => {
  ExteriorWBS.findOne({
    projectId: projectId,
    towerId: towerId,
  }).then(async (wbsData) => {
    if (wbsData) {
      let projectDuration = 0;
      projectDuration = wbsData.wbsList.reduce((s, f) => {
        return s + f.duration;
      }, 0);

      wbsData.projectDuration = projectDuration;
      wbsData.isActualPublished = false;

      await wbsData.save().then(async () => {
        await updateExtWeightage(projectId);
      });
    }
  });
};

router.post("/:project/upload", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    const projectWBS = req.body.wbs;

    const pId = req.params.project;
    const createdBy = req.payload.email;
    var locations;

    await MasterData.findOne({
      projectId: req.params.project,
    }).then((data) => {
      locations = data?.workLocation;
    });

    await WorkSchedule.deleteMany(
      {
        projectId: req.params.project,
      },
      async (err) => {
        if (!err) {
          await ExteriorWBS.deleteMany({
            projectId: req.params.project,
          });
          await InteriorWBS.deleteMany({
            projectId: req.params.project,
          });
        }
      }
    );

    const schedule = new WorkSchedule(projectWBS);

    schedule.save(async function (err, wbsSchedule) {
      if (err) {
        console.log(err);
      } else {
        await processExteriorData(pId, createdBy, wbsSchedule, locations);

        await processInteriorData(pId, createdBy, wbsSchedule, locations);

        res.json({
          status: "success",
        });
      }
    });
  } else {
    res.sendStatus(403);
  }
});

const processExteriorData = async (pId, createdBy, wbsSchedule, locations) => {
  var wbsList = _.filter(wbsSchedule.wbsList, function (wbs) {
    return wbs.taskType == "exterior";
  });

  var grpData = _.groupBy(_.sortBy(wbsList, "taskType"), "location");

  if (grpData) {
    Project.findOneAndUpdate(
      {
        projectId: pId,
      },
      {
        $set: {
          isExteriorWBSPublished: true,
        },
      }
    ).exec();
  }

  _.each(grpData, async function (wbsGrp, key) {
    const location = locations.find(
      (loc) =>
        loc.level1 === key &&
        !loc.level2 &&
        !loc.level2 &&
        !loc.level3 &&
        !loc.level4
    );

    await processExtWBSParams(
      pId,
      createdBy,
      wbsGrp,
      wbsSchedule.startDate,
      wbsSchedule.finishDate,
      wbsSchedule.captureInterval,
      location.locationId
    );
  });
};

const processInteriorData = async (pId, createdBy, wbsSchedule, locations) => {
  var wbsList = _.filter(wbsSchedule.wbsList, function (wbs) {
    return wbs.taskType == "interior";
  });

  var grpData = _.groupBy(_.sortBy(wbsList, "taskType"), "location");

  if (grpData) {
    Project.findOneAndUpdate(
      {
        projectId: pId,
      },
      {
        $set: {
          isUnitLevel: !!wbsSchedule.isUnitLevel,
          isInteriorWBSPublished: true,
        },
      }
    ).exec();
  }

  _.each(grpData, async function (wbsGrp, key) {
    const levels = key.split("-");
    let level1 = levels[0];
    let level2 = levels[1];

    const location = locations.find(
      (loc) =>
        loc.level1 === level1 &&
        loc.level2 === level2 &&
        !loc.level3 &&
        !loc.level4
    );

    if (wbsSchedule.isUnitLevel) {
      const units = locations.filter(
        (loc) =>
          loc.level1 === level1 &&
          loc.level2 === level2 &&
          loc.parentLocationId == location.locationId &&
          !loc.level4
      );
      const unitLevelGrp = [];
      wbsGrp.forEach((wbsObj) => {
        let wbsGrpNew = wbsObj;
        wbsGrpNew.wbsId = uuid.v4();
        unitLevelGrp.push(wbsGrpNew);
      });
      _.each(units, async function (unit) {
        await processIntWBSParams(
          pId,
          createdBy,
          unitLevelGrp,
          wbsSchedule.startDate,
          wbsSchedule.finishDate,
          wbsSchedule.captureInterval,
          location.parentLocationId,
          location.locationId,
          true,
          unit.locationId
        );
      });
    } else {
      if (location) {
        await processIntWBSParams(
          pId,
          createdBy,
          wbsGrp,
          wbsSchedule.startDate,
          wbsSchedule.finishDate,
          wbsSchedule.captureInterval,
          location.parentLocationId,
          location.locationId
        );
      }
    }
  });
};

const processExtWBSParams = async (
  projectId,
  email,
  projectWBS,
  startDate,
  finishDate,
  captureInterval,
  towerId
) => {
  var projectDuration = 0;

  const wbsData = new ExteriorWBS();
  wbsData.projectId = projectId;
  wbsData.createdBy = email;
  wbsData.projectDuration = projectDuration;
  wbsData.captureInterval = captureInterval;
  wbsData.towerId = towerId;
  wbsData.projectStartDate = startDate;
  wbsData.projectFinishDate = finishDate;

  projectWBS.forEach((wbsObj) => {
    let wbs = {};
    wbs.wbsId = uuid.v4();
    wbs.description = wbsObj.activityName;
    wbs.startDate = wbsObj.taskStart;
    wbs.finishDate = wbsObj.taskEnd;
    wbs.category = wbsObj.category;
    wbs.classification = wbsObj.classification;
    const taskStart = new Date(moment(wbsObj.taskStart).utcOffset(0)).setHours(
      0,
      0,
      0,
      0
    );

    const taskEnd = new Date(moment(wbsObj.taskEnd).utcOffset(0)).setHours(
      0,
      0,
      0,
      0
    );

    const diffTime = Math.abs(taskEnd - taskStart);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    wbs.duration = diffDays > 0 ? diffDays + 1 : 1;

    wbs.weightage = 0;
    wbs.planned = 0;
    wbs.actual = 0;
    wbs.comment = "";

    wbsData.wbsList.push(wbs);
  });

  projectDuration = wbsData.wbsList.reduce((s, f) => {
    return s + f.duration;
  }, 0);

  wbsData.projectDuration = projectDuration;
  wbsData.isActualPublished = false;
  wbsData.save(async function (err, result) {
    if (!err) {
      await updateExtWeightage(projectId);
    }
  });
};

const processIntWBSParams = async (
  projectId,
  email,
  projectWBS,
  startDate,
  finishDate,
  captureInterval,
  towerId,
  floorId,
  isUnitLevel = false,
  unitId = null
) => {
  var projectDuration = 0;

  const wbsData = new InteriorWBS();
  wbsData.projectId = projectId;
  wbsData.createdBy = email;
  wbsData.projectDuration = projectDuration;
  wbsData.captureInterval = captureInterval;
  wbsData.towerId = towerId;
  wbsData.floorId = floorId;
  wbsData.projectStartDate = startDate;
  wbsData.projectFinishDate = finishDate;
  wbsData.unitId = !!isUnitLevel ? unitId : null;
  projectWBS.forEach((wbsObj) => {
    let wbs = {};
    wbs.wbsId = !!isUnitLevel ? wbsObj.wbsId : uuid.v4();
    wbs.description = wbsObj.activityName;
    wbs.startDate = wbsObj.taskStart;
    wbs.finishDate = wbsObj.taskEnd;
    wbs.category = wbsObj.category;
    wbs.classification = wbsObj.classification;
    const taskStart = new Date(moment(wbsObj.taskStart).utcOffset(0)).setHours(
      0,
      0,
      0,
      0
    );

    const taskEnd = new Date(moment(wbsObj.taskEnd).utcOffset(0)).setHours(
      0,
      0,
      0,
      0
    );

    const diffTime = Math.abs(taskEnd - taskStart);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    wbs.duration = diffDays > 0 ? diffDays + 1 : 1;

    wbs.weightage = 0;
    wbs.planned = 0;
    wbs.actual = 0;
    wbs.comment = "";

    wbsData.wbsList.push(wbs);
  });

  projectDuration = wbsData.wbsList.reduce((s, f) => {
    return s + f.duration;
  }, 0);

  wbsData.projectDuration = projectDuration;
  wbsData.isActualPublished = false;

  await wbsData.save().then(async () => {
    //skip weightage calculation while uploading the wbs data for unit level
    if (!isUnitLevel) {
      await updateInternalWeightage(projectId, towerId);
    }
  });
};

const updateExtWeightage = async (projectId) => {
  await ExteriorWBS.find({
    projectId: projectId,
  }).then(async (projectWBS) => {
    if (projectWBS) {
      var overAllDuration = 0;

      for (let wbsItem of projectWBS) {
        if (wbsItem) {
          overAllDuration = overAllDuration + wbsItem.projectDuration;
        }
      }

      asyncPackage.forEach(
        projectWBS,
        async function (wbsDoc, callback) {
          wbsDoc.wbsList.forEach((wbs) => {
            const weightage = (
              overAllDuration > 0
                ? wbs.duration / overAllDuration
                : wbs.weightage
            ).toFixed(4);
            wbs.weightage = weightage;
          });

          const updated = await wbsDoc.save(callback);
        },
        function (err) {
          return;
        }
      );
    }
  });
};

const updateInternalWeightage = async (projectId, towerId) => {
  await InteriorWBS.find({
    projectId: projectId,
    towerId: towerId,
  }).then(async (projectWBS) => {
    if (projectWBS) {
      var overAllDuration = 0;

      for (let wbsItem of projectWBS) {
        if (wbsItem) {
          overAllDuration = overAllDuration + wbsItem.projectDuration;
        }
      }

      asyncPackage.forEach(
        projectWBS,
        async function (wbsDoc, callback) {
          wbsDoc.wbsList.forEach((wbs) => {
            const weightage = (
              overAllDuration > 0
                ? wbs.duration / overAllDuration
                : wbs.weightage
            ).toFixed(4);
            wbs.weightage = weightage;
          });

          const updated = await wbsDoc.save(callback);
        },
        function (err) {
          return;
        }
      );
    }
  });
};

module.exports = router;
