"use strict";
const router = require("express").Router();
const mongoose = require("mongoose");
const CaptureAppLog = mongoose.model("CaptureAppLog");
const auth = require("../auth");

router.post("/log", auth.required, async (req, res, next) => {
  try {
    const logReq = req.body;
    if (!!logReq && !!logReq.logs && logReq.logs.length > 0) {
      let logList = [];
      logReq.logs.forEach((log) => {
        let captureAppLog = new CaptureAppLog();
        captureAppLog.type = log.type;
        captureAppLog.method = log.method;
        captureAppLog.additionalInfo = log.additionalInfo;
        captureAppLog.logDate = log.logDate;
        captureAppLog.logInfo = log.logInfo;
        captureAppLog.createdBy = logReq.createdBy;
        logList.push(captureAppLog);
      });
      await CaptureAppLog.insertMany(logList).catch((reason) =>
        res.json({
          status: `Error in inserting capture app logs to the database ${reason}`,
        })
      );
      res.json({
        status: "success",
      });
    }
  } catch (error) {
    next(error);
  }
});

module.exports = router;
