"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const LookUp = mongoose.model("LookUp");
const AerialTour = mongoose.model("AerialTour");
const AerialImage = mongoose.model("AerialImage");
const ProcessingStatistic = mongoose.model("ProcessingStatistic");
const ProjectChart = mongoose.model("ProjectChart");
const ProcessingParam = mongoose.model("ProcessingParam");
const MapVolume = mongoose.model("MapVolume");
const ElevationProfile = mongoose.model("ElevationProfile");
const MasterData = mongoose.model("MasterData");
const auth = require("../auth");
const uuid = require("uuid");
const GeoprocessingFastapi = require("../../common/geoprocessing.fastapi");
const Util = require("../../common/util");
const Logger = require("../../common/logger");
const MapboxUpload = require("../../common/mapbox.upload");
const ExteriorWBS = mongoose.model("ExteriorWBS");
const ExteriorCapture = mongoose.model("ExteriorCapture");
const prepareNotificationData = require("../../common/notification");
const _ = require("underscore");
const moment = require("moment-timezone");
const {
  notificationMiddleWare,
} = require("../../middlewares/notification.middleware");
const asyncPackage = require("async");
const {
  generateUUID,
  uploadElevationFileToBlob,
  getPayloadToSave,
  deleteElevationFileFromBlob,
  deleteAerialTourImageFolder,
} = require("../../common/util");
const { AERIAL_TOUR_CONTAINER_BASE_URL } =
  require("../../config").geoprocessingAPI;
const fs = require("fs");
var Excel = require("exceljs");
const { aerialtourContainer } =
  require("../../config/index").azureStorage.containers;
const Client = mongoose.model("Client");

// Preload project objects on routes with ":project"
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.param("tour", (req, res, next, tourId) => {
  AerialTour.findOne({
    tourId: tourId,
  })
    .then((tour) => {
      if (!tour) {
        return res.sendStatus(404);
      }
      req.tour = tour;
      return next();
    })
    .catch(next);
});

router.get("/:project/tour", auth.required, async (req, res, next) => {
  await req.project
    .populate({
      path: "aerialTours",
      options: {
        sort: {
          createdAt: "desc",
        },
      },
    })
    .execPopulate()
    .then(async () => {
      let tours = req.project.aerialTours;

      if (!!tours && tours.length > 0) {
        let tourWithSCurveData = [];
        let dataCaptureList = await ExteriorCapture.find({
          projectId: req.params.project,
        })
          .select({ wbsItem: 1, projectId: 1, tourId: 1 })
          .exec();
        for (let i = 0; i < tours.length; i++) {
          let dc = tours[i];

          let plannedProgress = 0;
          let actualProgress = 0;

          let dcList = _.filter(dataCaptureList, {
            projectId: dc.projectId,
            tourId: dc.tourId,
          });

          if (dcList && dcList.length > 0) {
            for (let i = 0; i < dcList.length; i++) {
              dcList[i].wbsItem.forEach((wbs) => {
                plannedProgress = plannedProgress + wbs.planned * wbs.weightage;
                if (wbs.actual) {
                  actualProgress = actualProgress + wbs.actual * wbs.weightage;
                }
              });
            }

            dc["planned"] =
              plannedProgress > 0.99 ? 100 : (plannedProgress * 100).toFixed(2);
            dc["actual"] =
              actualProgress?.toFixed(2) > 99.5
                ? 100
                : actualProgress?.toFixed(2);
          }
          tourWithSCurveData.push(dc);
        }

        res.json({
          tours: tourWithSCurveData,
        });
      } else {
        res.json({
          tours: tours,
        });
      }
    })
    .catch(next);
});

router.get("/:project/wbs", auth.required, async (req, res, next) => {
  await ExteriorWBS.findOne({ projectId: req.params.project }).then(
    async (projectWBS) => {
      if (projectWBS) {
        res.json({
          status: true,
        });
      } else {
        res.json({
          status: false,
        });
      }
    }
  );
});

router.post("/:project/tour", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },

      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let status;

          await LookUp.findOne({
            type: "aerialTourStatus",
            key: "AT10001",
          })
            .then((data) => {
              status = data;
            })
            .catch(next);

          const tour = new AerialTour(req.body.tour);
          tour.tourId = uuid.v4();
          tour.projectId = req.project.projectId;

          if (req.project.processingParams) {
            tour.processingParams = req.project.processingParams;
          }

          if (req.project.tourCategory) {
            tour.tourCategory = req.project.tourCategory;
          }

          tour.createdBy = req.payload.email;
          tour.updatedBy = req.payload.email;
          tour.status = status
            ? {
                code: status.key,
                desc: status.value,
              }
            : null;
          tour.lat = 0;
          tour.lng = 0;

          if (req.project.isExteriorWBSPublished) {
            tour.isSelfServe = true;
          }

          const punchListLocation = {
            location: req.body.tour.tourName,
            locationId: generateUUID(),
            tourId: tour.tourId,
          };

          MasterData.findOneAndUpdate(
            { projectId: req.project.projectId },
            {
              $push: {
                punchList: punchListLocation,
              },
            },
            {
              new: true,
            }
          )
            .then(() => {
              res.json({
                status: "success",
              });
            })
            .catch(next);

          await tour
            .save()
            .then(async () => {
              req.project.aerialTours.push(tour);
              await req.project.save().then((project) => {
                res.json({
                  aerialTour: project.aerialTour,
                });
              });
            })
            .catch(next);
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

// set center of aerial tour when images upload
router.post(
  "/:project/aerialtour/:tour/center",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (typeof req.body.lat !== "undefined") {
              req.tour.lat = req.body.lat;
            }
            if (typeof req.body.lng !== "undefined") {
              req.tour.lng = req.body.lng;
            }
            req.tour.updatedBy = req.payload.email;

            await req.tour
              .save()
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/aerialtour/statictour/:tour",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.tour) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const requestData = req.body.tour;

            const tour = {};
            tour.tourId = uuid.v4();
            tour.tourName = requestData.tourName;
            tour.tourUrl = requestData.tourUrl;
            req.tour.staticMap.urls.push(tour);

            req.tour.updatedBy = req.payload.email;

            await req.tour
              .save()
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/aerialtour/statictour/:tour/tour/:statictourid",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            AerialTour.findOneAndUpdate(
              { tourId: req.tour.tourId },
              {
                $pull: {
                  "staticMap.urls": { tourId: req.params.statictourid },
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/aerialtour/statictour/:tour/chart",
  auth.required,
  async (req, res, next) => {
    let charts;
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            charts = req.body.charts;
            req.tour.staticMap.charts = [];

            for (let i = 0; i < charts.length; i++) {
              const chart = new ProjectChart(charts[i]);
              chart.chartId = uuid.v4();
              chart.createdBy = req.payload.email;
              req.tour.staticMap.charts.push(chart);
            }

            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/aerialtour/statictour/:tour/removechart/:chartId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await AerialTour.findOneAndUpdate(
              { tourId: req.tour.tourId },
              {
                $pull: {
                  "staticMap.charts": { chartId: req.params.chartId },
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/aerialtour/statictour/:tour/publish",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let status;

            await LookUp.findOne({
              type: "aerialTourStatus",
              key: "AT10003",
            })
              .then((data) => {
                status = data;
              })
              .catch(next);

            req.tour.status = status
              ? {
                  code: status.key,
                  desc: status.value,
                }
              : null;

            req.tour.isPublished = true;
            req.tour.updatedBy = req.payload.email;
            return req.tour
              .save()
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete("/:project/aerialtour/:tour", auth.required, async (req, res) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          req.project.aerialTours.remove(req.tour._id);
          await req.project
            .save()
            .then(
              AerialTour.findOneAndUpdate(
                {
                  _id: req.tour._id,
                },
                {
                  $set: {
                    isActive: false,
                  },
                }
              ).exec()
            )
            .then(() => {
              res.sendStatus(204);
            });
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

// update tour
router.put(
  "/:project/aerialtour/:tour",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.tour) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (typeof req.body.tour.tourName !== "undefined") {
              req.tour.tourName = req.body.tour.tourName;
            }

            if (typeof req.body.tour.tourDate !== "undefined") {
              req.tour.tourDate = req.body.tour.tourDate;
            }
            req.tour.updatedBy = req.payload.email;

            await req.tour
              .save()
              .then(async (tour) => {
                await updateProgressByDate(
                  tour.projectId,
                  tour.tourDate,
                  tour.tourId,
                  req.payload.email
                );
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// update activity
router.put(
  "/:project/aerialtour/status/:tour",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      let status;
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (
              req.tour.status.code === "AT10001" &&
              req.tour.images.length > 10
            ) {
              if (req.tour.processingParams) {
                const processingParams = req.tour.processingParams;

                const client = await Client.findOne({
                  clientId: req.project.clientId,
                });
                await LookUp.findOne({
                  type: "aerialTourStatus",
                  key: "AT10002",
                })
                  .then((data) => {
                    status = data;
                  })
                  .catch(next);

                req.tour.status = status
                  ? {
                      code: status.key,
                      desc: status.value,
                    }
                  : null;
                req.tour.updatedBy = req.payload.email;
                let imageName;
                await req.tour
                  .populate({
                    path: "images",
                  })
                  .execPopulate()
                  .then((tour) => {
                    imageName = tour.images[0].blobImageId;
                  })
                  .catch(next);

                const tokenArray = req.headers.authorization.split(" ");
                const token = tokenArray[1];

                const blobPath = [
                  AERIAL_TOUR_CONTAINER_BASE_URL,
                  req.tour.tourId,
                  imageName,
                ].join("/");

                // Setting data for volume tool
                // set dsmProjectionCode only if the tour type is Land Survey, Mining, Construction or Forest
                if (
                  req.tour.tourCategory === "L" ||
                  req.tour.tourCategory === "M" ||
                  req.tour.tourCategory === "C" ||
                  req.tour.tourCategory === "F"
                ) {
                  processingParams.dsm_projection_code = Util.getEPSGProjection(
                    req.tour.lat,
                    req.tour.lng
                  );
                }

                const processingPayload = {
                  tour_id: req.tour.tourId,
                  project_id: req.project.projectId,
                  current_status: "New",
                  machine: "GeoProcessMachine1",
                  temp_machine: "GeoProcessMachine1",
                  overall_processing_time: 0,
                  overall_processing_status: "New",
                  map_urls: [],
                  events: [],
                  payload: JSON.stringify({
                    blob_path: blobPath,
                    tour_dir_created: false,
                    execution_step: 1,
                    tour_type: req.tour.tourCategory,
                    processing_params: processingParams,
                  }),
                  config: JSON.stringify(processingParams),
                  processing_params: JSON.stringify({
                    ...processingParams,
                    blob_path: blobPath,
                  }),
                };
                const newProcessingReq = new ProcessingStatistic(
                  processingPayload
                );
                await ProcessingStatistic.create(newProcessingReq);

                // const response = await GeoprocessingFastapi.startGeoprocessing(
                //   token,
                //   req.tour.tourId,
                //   req.project.projectId,
                //   req.tour.tourCategory,
                //   processingParams,
                //   imageName
                // );
                // if (response["status"] == "success") {
                const mailTo = [];
                for (let user of req.project.users) {
                  if (user.role.code === "Huviair Team") {
                    mailTo.push({
                      email: user.email,
                      name: user.firstName + " " + user.lastName,
                    });
                  }
                }
                if (mailTo.length > 0) {
                  await Util.sendProcessingStartEmail(
                    mailTo,
                    req.project.projectName,
                    req.tour.tourName
                  );
                }

                const [mailSentError, mailSentStatus] =
                  await Util.sendStartProcessingEmailOps(
                    client.clientName,
                    req.project.projectName,
                    req.tour,
                    blobPath,
                    processingParams
                  );
                if (mailSentError) {
                  Logger.error(
                    "Error while sending mail in Aerial Tour Start Processing " +
                      mailSentError
                  );
                }
                // }
                await req.tour
                  .save()
                  .then(() => {
                    res.json({
                      status: "success",
                    });
                  })
                  .catch(next);
                // } else {
                //   res.json({
                //     status: "failure",
                //     code: "10001",
                //   });
                // }
              } else {
                res.json({
                  status: "failure",
                  code: "10002",
                });
              }
            } else {
              res.json({
                status: "failure",
                code: "10003",
              });
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// add image
router.post(
  "/:project/aerialtour/:tour/image",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const image = new AerialImage(req.body.image);
            image.createdBy = req.payload.email;
            image.meta.createdByName =
              req.payload.firstName + " " + req.payload.lastName;

            await image
              .save()
              .then(async () => {
                req.tour.images.push(image);
                await req.tour.save().then(() => {
                  res.json({
                    status: "success",
                  });
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// add new annotation type
router.post(
  "/:project/aerialtour/:tour/newannotationtype",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const tour = req.tour;
            if (!tour.annotationTypes) {
              tour.annotationTypes = [];
            }
            let keyExist = false;
            for (let annotationType of tour.annotationTypes) {
              if (annotationType.key === req.body.newAnnotationType.key) {
                keyExist = true;
                break;
              }
            }
            if (!keyExist) {
              tour.annotationTypes.push(req.body.newAnnotationType);

              await tour.save().then(() => {
                res.json({
                  status: "success",
                  newAnnotationType: req.body.newAnnotationType,
                });
              });
            } else {
              res.json({
                status: "unchanged",
                newAnnotationType: [],
              });
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// add new annotation type to project

router.post(
  "/:project/aerialtour/:tour/saveannotationtypetoproject",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const project = await Project.findOne({
              projectId: req.project.projectId,
            });

            if (!project.annotationTypes) {
              project.annotationTypes = [];
            } else {
              const newAnnotationTypeKey = req.body.newAnnotationType.key;
              let annotationTypeExists = false;

              for (let annotationType of project.annotationTypes) {
                if (annotationType.key === newAnnotationTypeKey) {
                  annotationTypeExists = true;
                  break;
                }
              }

              if (!annotationTypeExists) {
                const newAnnotationType = req.body.newAnnotationType;

                project.annotationTypes.push(newAnnotationType);

                await project.save().then(() => {
                  res.json({
                    status: "success",
                    newAnnotationType: req.body.newAnnotationType,
                    project: req.project,
                  });
                });
              } else {
                res.json({
                  status: "unchanged",
                  newAnnotationType: [],
                });
              }
            }
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// add annotation type to all projects

router.post(
  "/:project/aerialtour/:tour/saveannotationtypetoallprojects",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const projects = await Project.find({
              clientId: req.project.clientId,
              isActive: true,
            });

            for (let project of projects) {
              if (!project.annotationTypes) {
                project.annotationTypes = [];
              } else {
                const newAnnotationTypeKey = req.body.newAnnotationType.key;
                let annotationTypeExists = false;

                for (let annotationType of project.annotationTypes) {
                  if (annotationType.key === newAnnotationTypeKey) {
                    annotationTypeExists = true;
                    break;
                  }
                }

                if (!annotationTypeExists) {
                  const newAnnotationType = req.body.newAnnotationType;

                  project.annotationTypes.push(newAnnotationType);

                  await project.save();
                } else {
                  res.json({
                    status: "failed",
                    project: req.project,
                    newAnnotationType: [],
                  });
                }
              }
            }
            res.json({
              status: "successful",
              newAnnotationType: req.body.newAnnotationType,
            });
          } else {
            res.sendStatus(403);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/aerialtour/:tour/annotationtypes",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (!req.tour.annotationTypes) {
              res.json({ annotationTypes: [] });
            }
            res.json({ annotationTypes: req.tour.annotationTypes });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// get annotation types fom project

router.get(
  "/:project/aerialtour/:tour/annotationtypesfromproject",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const project = await Project.findOne({
              projectId: req.project.projectId,
            });

            if (project.annotationTypes.length !== 0) {
              const annotationTypes = [];

              for (let annotationType of project.annotationTypes) {
                annotationTypes.push(annotationType);
              }

              res.send({
                status: "success",
                project: project,
                annotationTypes: annotationTypes,
              });
            } else {
              res.send({
                status: "failed",
                annotationTypes: [],
              });
            }
          }
        }
      );
    }
  }
);

router.get(
  "/:project/aerialtour/:tour/image",
  auth.required,
  async (req, res, next) => {
    await req.tour
      .populate({
        path: "images",
        options: {
          sort: {
            createdAt: "desc",
          },
        },
      })
      .execPopulate()
      .then(() => {
        res.json({
          images: req.tour.images,
        });
      })
      .catch(next);
  }
);

// return a project"s users
router.get(
  "/:project/aerialtour/:tour/chart",
  auth.required,
  async (req, res) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            res.json({
              charts: req.tour.charts,
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/aerialtour/:tour/chart",
  auth.required,
  async (req, res, next) => {
    let charts;
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            charts = req.body.charts;
            req.tour.charts = [];
            for (let i = 0; i < charts.length; i++) {
              const chart = new ProjectChart(charts[i]);
              chart.chartId = uuid.v4();
              chart.createdBy = req.payload.email;
              req.tour.charts.push(chart);
            }

            await req.tour
              .save()
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/aerialtour/:tour/removechart",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "charts.chartId": req.body.chart.chartId,
              },
              {
                $pull: {
                  charts: {
                    chartId: req.body.chart.chartId,
                  },
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/aerialtour/:tour/publish",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            req.tour.isPublished = true;
            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/aerialtour/:tour/mapboxmap/processingsuccess",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      let status;
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (
              req.tour.status.code === "AT10002" &&
              req.tour.images.length > 10
            ) {
              await LookUp.findOne({
                type: "aerialTourStatus",
                key: "AT10003",
              })
                .then((data) => {
                  status = data;
                })
                .catch(next);

              req.tour.status = status
                ? {
                    code: status.key,
                    desc: status.value,
                  }
                : null;
              req.tour.updatedBy = "system";
              const tokenArray = req.headers.authorization.split(" ");
              const token = tokenArray[1];
              const response = await GeoprocessingFastapi.getTourURLs(
                token,
                req.tour.tourId
              );
              if (response["url"]) {
                req.tour.mapUrls = response["url"];
                await req.tour
                  .save()
                  .then(() => {
                    res.json({
                      status: "success",
                    });
                  })
                  .catch(next);
              } else {
                res.json({
                  status: "success",
                });
              }
            } else {
              res.sendStatus(401);
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/aerialtour/:tour/mapboxmap/mapurl",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            // if (req.tour.status.code === "AT10003") {
            AerialTour.findOne({
              tourId: req.tour.tourId,
            })
              .then((tour) => {
                if (!tour) {
                  return res.sendStatus(404);
                }
                res.json({
                  urls: tour.mapUrls,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
          // } else {
          //   res.sendStatus(401);
          // }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/aerialtour/:tour/mapboxmap/mapurl",
  auth.required,
  async (req, res, next) => {
    if (req.body.mapUrls && req.body.mapUrls.length > 0) {
      req.tour.mapUrls = req.body.mapUrls;
      await req.tour
        .save()
        .then((tour) => {
          res.json({
            mapUrls: tour.mapUrls,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(500).json({
        error: "mapUrls not found",
      });
    }
  }
);

router.delete(
  "/:project/aerialtour/:tour/mapboxmap/:id",
  auth.required,
  async (req, res, next) => {
    if (req.params.id) {
      const id = req.params.id;
      const layer = req.tour.mapUrls.find(
        (mapUrl) => mapUrl.appendIndex === parseInt(id)
      );
      if (layer && layer.value.includes("mapbox://", 0)) {
        const reponse = await MapboxUpload.deleteTileset(layer.value);
        if (reponse.deleteStatus !== 200) {
          Logger.error(
            "Unable to delete tileset. Error: " +
              JSON.stringify(reponse.deleteResponse)
          );
        }
      }
      req.tour.mapUrls = req.tour.mapUrls.filter(
        (mapUrl) => mapUrl.appendIndex !== parseInt(id)
      );
      await req.tour
        .save()
        .then((tour) => {
          res.json({
            mapUrls: tour.mapUrls,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(500).json({
        error: "url not found",
      });
    }
  }
);

router.get(
  "/:project/aerialtour/:tour/mapboxmap/processingstatus",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await ProcessingStatistic.findOne({
              tour_id: req.tour.tourId,
            })
              .then((processingStatus) => {
                res.json({
                  processingStatus: processingStatus
                    ? processingStatus.toJSONFor()
                    : "",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// save url data, with order
router.post(
  "/:project/aerialtour/:tour/upload/processingparams",
  auth.required,
  async (req, res, next) => {
    if (req.body.params && req.body.tourCategory) {
      if (!req.project.processingParams || !req.project.tourCategory) {
        req.project.tourCategory = req.body.tourCategory;
        req.project.processingParams = req.body.params;
        await req.project.save((err) => {
          if (err) {
            res.sendStatus(500).json({
              error: "error while saving",
            });
          }
        });
      }

      req.tour.processingParams = req.body.params;
      req.tour.tourCategory = req.body.tourCategory;
      await req.tour
        .save()
        .then(() => {
          res.json({
            status: "success",
          });
        })
        .catch(next);
    } else {
      res.sendStatus(500).json({
        error: "no processing params",
      });
    }
  }
);

router.get(
  "/:project/aerialtour/:tour/processingparams",
  auth.required,
  async (req, res, next) => {
    let tourCategoryOptions;
    if (req.payload.email) {
      await LookUp.find({
        type: "tourCategory",
      })
        .then((data) => {
          tourCategoryOptions = data;
        })
        .catch(next);

      await ProcessingParam.find({})
        .then((data) => {
          res.json({
            params: data,
            selectedParam: req.tour.processingParams,
            tourCategoryOptions: tourCategoryOptions,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/aerialtour/:tour/volume",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          const volumeData = new MapVolume(req.body.volData);
          volumeData.volumeUniqueId = uuid.v4();
          volumeData.tourId = req.params.tour;
          volumeData.projectId = req.params.project;
          volumeData.status = "new";
          volumeData.tourType = req.tour.tourCategory; //tour category
          volumeData.createdBy = req.payload.email;
          await ProcessingStatistic.findOne({
            tour_id: req.params.tour,
          })
            .then((processingStatus) => {
              volumeData.machineId = processingStatus.temp_machine;
            })
            .catch(next);
          await volumeData
            .save()
            .then(() => {
              res.json({
                status: "success",
              });
            })
            .catch(next);
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/aerialtour/:tour/volume",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          MapVolume.find({
            tourId: req.params.tour,
          })
            .then((data) => {
              res.json({
                volumeList: data,
              });
            })
            .catch(next);
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/aerialtour/:tour/volume/:volumeId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          MapVolume.deleteOne({
            volumeUniqueId: req.params.volumeId,
          })
            .exec()
            .then((data) => {
              res.json({
                status: "success",
              });
            })
            .catch(next);
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/aerialtour/:tour/elevationprofile",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          const elevationProfileReq = new ElevationProfile(
            req.body.elevationProfile
          );
          elevationProfileReq.elevationProfileUniqueId = uuid.v4();
          elevationProfileReq.tourId = req.params.tour;
          elevationProfileReq.projectId = req.params.project;
          elevationProfileReq.status = "new";
          elevationProfileReq.tourType = req.tour.tourCategory; //tour category
          elevationProfileReq.createdBy = req.payload.email;
          await ProcessingStatistic.findOne({
            tour_id: req.params.tour,
          })
            .then((processingStatus) => {
              elevationProfileReq.machineId = processingStatus.temp_machine;
            })
            .catch(next);
          await elevationProfileReq
            .save()
            .then(() => {
              res.json({
                status: "success",
              });
            })
            .catch(next);
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/aerialtour/:tour/elevationProfile",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          ElevationProfile.find({
            tourId: req.params.tour,
          })
            .then((data) => {
              res.json({
                elevationProfileList: data,
              });
            })
            .catch(next);
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/aerialtour/:tour/elevationprofile/:elevationProfileId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          ElevationProfile.deleteOne({
            elevationProfileUniqueId: req.params.elevationProfileId,
          })
            .exec()
            .then((data) => {
              res.json({
                status: "success",
              });
            })
            .catch(next);
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/aerialtour/:tour/threedurl",
  auth.required,
  async (req, res, next) => {
    if (req.payload.isAdmin) {
      req.tour.threeDUrl = req.body.mapUrl;

      await req.tour
        .save()
        .then((tour) => {
          res.json({
            tour: tour,
          });
        })
        .catch(next);
    } else {
      res.sendStatus(500).json({
        error: "mapUrls not found",
      });
    }
  }
);

router.put("/:project/legend/:tour/", auth.required, async (req, res, next) => {
  if (req.payload.isAdmin) {
    req.tour.legend = req.body.legend;

    await req.tour
      .save()
      .then((tour) => {
        res.json({
          tour: tour,
        });
      })
      .catch(next);
  } else {
    res.sendStatus(500).json({
      error: "mapUrls not found",
    });
  }
});

router.get(
  "/:project/syncwbsmasterdata/:tour/",
  auth.required,
  async (req, res, next) => {
    await ExteriorWBS.find({
      projectId: req.params.project,
    }).then(async (projectWBS) => {
      if (projectWBS.length > 0 && project.isExteriorWBSPublished) {
        req.tour.isWBSPublished = true;
        await req.tour.save().then(async (tour) => {
          await updateActualData(
            tour.projectId,
            tour.tourDate,
            tour.tourId,
            req.payload.email
          );
          res.json({
            status: "success",
          });
        });
      } else {
        res.json({
          status: "success",
        });
      }
    });
  }
);

router.get(
  "/:project/publishwbstourdata/:tour/",
  auth.required,
  async (req, res, next) => {
    await ExteriorCapture.find({
      projectId: req.params.project,
      tourId: req.params.tour,
    }).then(async (capture) => {
      if (capture.length === 0 && req.project.isExteriorWBSPublished) {
        req.tour.isWBSPublished = true;

        await req.tour.save().then(async (tour) => {
          await updateActualData(
            tour.projectId,
            tour.tourDate,
            tour.tourId,
            req.payload.email
          );
        });
      }
      res.json({
        status: "success",
      });
    });
  }
);

const updateActualData = async (projectId, captureDate, tourId, email) => {
  await ExteriorWBS.find({
    projectId: projectId,
  }).then(async (wbsItems) => {
    if (wbsItems) {
      asyncPackage.forEach(
        wbsItems,
        async function (projectWBS, callback) {
          let insertNew = false;
          let extCapture = await ExteriorCapture.findOne({
            projectId: projectWBS.projectId,
            towerId: projectWBS.towerId,
            tourId: tourId,
          }).exec();

          if (extCapture) {
            if (!extCapture.isActualPublished) {
              await ExteriorCapture.deleteMany(
                {
                  projectId: req.params.project,
                  towerId: projectWBS.towerId,
                },
                function (err) {
                  if (err) console.log(err);
                }
              );
              insertNew = true;
            } else {
              extCapture.save(callback);
            }
          } else {
            insertNew = true;
          }

          if (insertNew) {
            const capture = new ExteriorCapture();
            capture.captureId = uuid.v4();
            capture.tourId = tourId;
            capture.captureDate = new Date(captureDate).setHours(0, 0, 0, 0);
            capture.projectId = projectWBS.projectId;
            capture.towerId = projectWBS.towerId;
            capture.projectDuration = projectWBS.projectDuration;
            capture.captureInterval = projectWBS.captureInterval;
            capture.projectStartDate = projectWBS.projectStartDate;
            capture.projectFinishDate = projectWBS.projectFinishDate;
            capture.isActualPublished = true;
            capture.createdBy = email;
            capture.updatedBy = email;

            let previousCapture = await ExteriorCapture.find({
              projectId: projectWBS.projectId,
              towerId: projectWBS.towerId,
            })
              .sort({
                _id: -1,
              })
              .limit(1)
              .exec();

            if (previousCapture && previousCapture.length > 0) {
              capture.wbsItem = previousCapture[0].wbsItem;

              capture.wbsItem.forEach((wbs) => {
                var progress = 0;
                const startDT = new Date(captureDate);
                let plannedCapture = new Date(startDT).setHours(0, 0, 0, 0);
                const taskStart = new Date(wbs.startDate);
                const taskEnd = new Date(wbs.finishDate);
                const duration = wbs.duration;

                if (plannedCapture < taskStart) {
                  progress = 0;
                } else {
                  if (plannedCapture > taskEnd) {
                    progress = 1;
                  } else {
                    const diffTime = Math.abs(plannedCapture - taskStart);
                    const diffDays = Math.ceil(
                      diffTime / (1000 * 60 * 60 * 24)
                    );
                    progress = (diffDays / duration).toFixed(3);
                  }
                }

                wbs.planned = progress;
                wbs.createdBy = email;
                wbs.createdAt = new Date();
                wbs.updatedBy = email;
                wbs.updatedAt = new Date();
              });
            } else {
              projectWBS.wbsList.forEach((wbs) => {
                const wbsId = wbs.wbsId;
                const description = wbs.description;
                const startDate = wbs.startDate;
                const finishDate = wbs.finishDate;
                const duration = wbs.duration;
                const weightage = wbs.weightage;

                var progress = 0;

                const startDT = new Date(
                  moment(captureDate).utcOffset(0)
                ).setHours(0, 0, 0, 0);

                let plannedCapture = new Date(startDT);
                const taskStart = new Date(
                  moment(startDate).utcOffset(0)
                ).setHours(0, 0, 0, 0);
                const taskEnd = new Date(
                  moment(finishDate).utcOffset(0)
                ).setHours(0, 0, 0, 0);

                const dataCaptureDate = new Date(plannedCapture);

                if (plannedCapture < taskStart) {
                  progress = 0;
                } else {
                  if (plannedCapture > taskEnd) {
                    progress = 1;
                  } else {
                    const diffTime = Math.abs(plannedCapture - taskStart);
                    const diffDays = Math.ceil(
                      diffTime / (1000 * 60 * 60 * 24)
                    );
                    progress = (diffDays / duration).toFixed(4);
                  }
                }

                let data = {
                  wbsId: wbsId,
                  description: description,
                  startDate: startDate,
                  finishDate: finishDate,
                  duration: duration,
                  weightage: weightage,
                  planned: progress,
                  actual: 0,
                  comment: "",
                  createdBy: email,
                  createdAt: new Date(),
                  updatedBy: email,
                  updatedAt: new Date(),
                };

                capture.wbsItem.push(data);
              });
            }

            capture.save(callback);
          }
        },
        function (err) {
          console.log(err);
          return;
        }
      );
    }
  });
};

router.post(
  "/:project/aerialTour/notify/:tour",
  auth.required,
  async (req, res, next) => {
    try {
      res.json({ status: "success" });

      let data = {
        messageType: "NT0008",
        appType: "APP002",
        ...req.project.toObject(),
        ...req.tour.toObject(),
        metaData: {
          actionType: "Aerial_tour_published",
          projectId: req.project.projectId,
          projectName: req.project.projectName,
          tourId: req.tour.tourId,
        },
      };

      req.notificationData = await prepareNotificationData(data);
      next();
    } catch (error) {
      next(error);
    }
  },
  notificationMiddleWare
);

router.post(
  "/:project/aerialTour/emailnotify/:tour",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            try {
              res.json({ status: "success" });
              const unblockedUser = req.project.users.filter(
                ({ isBlocked }) => !isBlocked
              );
              await Util.sendTourPublishEmail(
                Util.getMailToArrayFromEmailArray(
                  unblockedUser,
                  unblockedUser.map(({ email }) => email)
                ),
                {
                  tour: {
                    tourName: req.tour.tourName,
                    tourDate: req.tour.tourDate,
                  },
                  project: req.project,
                  shareLink: req.body.shareLink,
                  tourType: "Aerial",
                }
              );
            } catch (error) {
              next(error);
            }
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get("/:project/:tour", auth.required, async (req, res, next) => {
  await Project.countDocuments(
    {
      users: {
        $elemMatch: {
          email: req.payload.email,
          isActive: true,
          isBlocked: false,
        },
      },
      projectId: req.project.projectId,
      isActive: true,
    },
    async (err, count) => {
      if (count > 0 || req.payload.isAdmin) {
        res.json({
          tour: req.tour,
        });
      } else {
        res.sendStatus(401);
      }
    }
  );
});

router.get(
  "/:project/tour/:tour/tower/:towerId/wbs/ext/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.project,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let wbsData = [];
            await ExteriorCapture.findOne({
              projectId: req.params.project,
              towerId: req.params.towerId,
              tourId: req.params.tour,
            }).then(async (projectWBS) => {
              if (projectWBS) {
                const wbsList = projectWBS.wbsItem;
                res.json({
                  wbsData: wbsList,
                });
              } else {
                res.json({
                  wbsData: [],
                });
              }
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

const updateWbsProgressBulk = async (projectId, tourId, bulkPayload, email) => {
  return bulkPayload.map(async (payloadWbs) => {
    const updatedExtCapture = await ExteriorCapture.findOneAndUpdate(
      {
        "wbsItem.wbsId": payloadWbs.wbsId,
        tourId,
        projectId,
      },
      {
        $set: {
          updatedBy: email,
          "wbsItem.$.actual": payloadWbs.progress,
          "wbsItem.$.comment": payloadWbs.comment,
          "wbsItem.$.updatedBy": email,
          "wbsItem.$.updatedAt": new Date(),
        },
      }
    );
    return updatedExtCapture;
  });
};

router.put(
  "/:project/:tour/ext/wbs/progress/bulk",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.wbsProgress) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await updateWbsProgressBulk(
              req.params.project,
              req.params.tour,
              req.body.wbsProgress,
              req.payload.email
            )
              .then((v) => Promise.all(v))
              .then((v) => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/:tour/wbs/:wbsId/ext/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email && req.body.wbsProgress) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const wbsProgress = req.body.wbsProgress;

            await ExteriorCapture.findOneAndUpdate(
              {
                "wbsItem.wbsId": req.params.wbsId,
                tourId: req.params.tour,
                projectId: req.params.project,
              },
              {
                $set: {
                  updatedBy: req.payload.email,
                  "wbsItem.$.actual": wbsProgress.progress,
                  "wbsItem.$.comment": wbsProgress.comment,
                  "wbsItem.$.updatedBy": req.payload.email,
                  "wbsItem.$.updatedAt": new Date(),
                },
              }
            )
              .then(() => {
                res.json({
                  status: "success",
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/:tour/wbs/ext/:tower/chart",
  auth.required,
  async (req, res, next) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let response = {
            sCurve: {
              labels: [],
              planned: [],
              actual: [],
            },
            wbsChart: {
              labels: [],
              planned: [],
              actual: [],
              toolTip: [],
            },
          };

          let captureList = await AerialTour.find({
            projectId: req.params.project,
            tourDate: { $lte: req.tour.tourDate },
          })
            .sort({ captureDate: "asc" })
            .select({ projectId: 1, tourId: 1, tourDate: 1 })
            .exec();

          let dataCaptureList = await ExteriorCapture.find({
            projectId: req.params.project,
          })
            .select({ wbsItem: 1, projectId: 1, tourId: 1 })
            .exec();

          let sCurve = [];
          let barChart = [];

          if (
            captureList &&
            captureList.length > 0 &&
            dataCaptureList.length > 0
          ) {
            for (let i = 0; i < captureList.length; i++) {
              let dc = captureList[i];

              let dataCaptureDate = new Date(dc.tourDate);
              let plannedProgress = 0;
              let actualProgress = 0;

              let dcList = _.filter(dataCaptureList, {
                projectId: dc.projectId,
                tourId: dc.tourId,
              });

              if (dcList && dcList.length > 0) {
                for (let i = 0; i < dcList.length; i++) {
                  dcList[i].wbsItem.forEach((wbs) => {
                    plannedProgress =
                      plannedProgress + wbs.planned * wbs.weightage;
                    if (wbs.actual) {
                      actualProgress =
                        actualProgress + wbs.actual * wbs.weightage;
                    }
                  });
                }

                let point = {
                  captureDate: dataCaptureDate,
                  planned:
                    plannedProgress > 1 || plannedProgress > 0.99
                      ? 1
                      : plannedProgress,
                  actual: actualProgress,
                };

                sCurve.push(point);
              }
            }

            // add data for planned s curve till last date of the project
            if (sCurve.length > 0) {
              let intWBSList = await ExteriorWBS.find({
                projectId: req.params.project,
              });

              let projectFinishdate = await ExteriorWBS.findOne({
                projectId: req.params.project,
              })
                .sort({ projectFinishDate: "desc" })
                .exec();

              let finishDate = projectFinishdate.projectFinishDate;
              let captureInterval = projectFinishdate.captureInterval;

              let lastCaptureDate = new Date(
                sCurve[sCurve.length - 1].captureDate
              );

              let nextPlannedCapture = lastCaptureDate.setDate(
                lastCaptureDate.getDate() + captureInterval
              );
              let plannedEndDate = new Date(finishDate);
              let plannedDataCapture = new Date(nextPlannedCapture).setHours(
                0,
                0,
                0,
                0
              );
              let nextCapture = new Date(plannedDataCapture);

              while (nextCapture <= plannedEndDate) {
                const dataCaptureDate = new Date(nextCapture);
                let progress = 0;
                let overallAprogress = 0;

                for (let i = 0; i < intWBSList.length; i++) {
                  intWBSList[i].wbsList.forEach((wbs) => {
                    const taskStart = new Date(wbs.startDate);
                    const taskEnd = new Date(wbs.finishDate);

                    if (dataCaptureDate < taskStart) {
                      progress = 0;
                    } else {
                      if (dataCaptureDate > taskEnd) {
                        progress = 1;
                      } else {
                        const diffTime = Math.abs(
                          new Date(dataCaptureDate) - new Date(taskStart)
                        );
                        const diffDays = Math.ceil(
                          diffTime / (1000 * 60 * 60 * 24)
                        );

                        progress = (diffDays / wbs.duration).toFixed(3);
                      }
                    }

                    overallAprogress =
                      overallAprogress + progress * wbs.weightage;
                  });
                }

                let point = {
                  captureDate: dataCaptureDate,
                  planned: overallAprogress > 1 ? 1 : overallAprogress,
                  actual: 0,
                };

                sCurve.push(point);

                let nextPlannedCapture = nextCapture.setDate(
                  nextCapture.getDate() + captureInterval
                );
                nextCapture = new Date(nextPlannedCapture);
              }
            }

            let workSchedule = await ExteriorCapture.findOne({
              projectId: req.params.project,
              tourId: req.params.tour,
              towerId: req.params.tower,
            });

            if (workSchedule) {
              workSchedule.wbsItem.forEach((wbs) => {
                if (
                  (wbs.actual && wbs.actual > 0) ||
                  (wbs.planned && wbs.planned > 0)
                ) {
                  let bar = {
                    wbsName: wbs.description,
                    planned: wbs.planned,
                    actual: wbs.actual,
                    comment: wbs.comment ? wbs.comment : "",
                  };

                  barChart.push(bar);
                }
              });
            }

            sCurve.forEach((m) => {
              response.sCurve.labels.push(
                moment(m.captureDate).utcOffset(330).format("YYYY-MMM-DD")
              );
              response.sCurve.planned.push((m?.planned * 100)?.toFixed(2));
              if (m?.actual > 0) {
                const actual =
                  m?.actual?.toFixed(2) > 99.5 ? 100.0 : m?.actual?.toFixed(2);
                response.sCurve.actual.push(actual);
              }
            });

            barChart.forEach((m) => {
              response.wbsChart.labels.push(m.wbsName);
              response.wbsChart.planned.push((m.planned * 100).toFixed(2));
              if (m.actual > 0 || m.planned > 0) {
                response.wbsChart.actual.push(m.actual.toFixed(2));
              }
              response.wbsChart.toolTip.push(m.comment);
            });
          }

          res.json({
            response,
          });
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);

router.get(
  "/:project/:tour/wbs/ext/:tower/chart/by-tower",
  auth.required,
  async (req, res, next) => {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      async (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          let response = {
            sCurve: {
              labels: [],
              planned: [],
              actual: [],
            },
            wbsChart: {
              labels: [],
              planned: [],
              actual: [],
              toolTip: [],
            },
          };

          let captureList = await AerialTour.find({
            projectId: req.params.project,
            tourDate: { $lte: req.tour.tourDate },
          })
            .sort({ captureDate: "asc" })
            .select({ projectId: 1, tourId: 1, tourDate: 1 })
            .exec();

          let dataCaptureList = await ExteriorCapture.find({
            projectId: req.params.project,
            towerId: req.params.tower,
          })
            .select({ wbsItem: 1, projectId: 1, tourId: 1, towerId: 1 })
            .exec();

          let sCurve = [];
          let barChart = [];

          if (
            captureList &&
            captureList.length > 0 &&
            dataCaptureList.length > 0
          ) {
            for (let i = 0; i < captureList.length; i++) {
              let dc = captureList[i];
              let dataCaptureDate = new Date(dc.tourDate);
              let plannedProgress = 0;
              let actualProgress = 0;

              let dcList = _.filter(dataCaptureList, {
                projectId: dc.projectId,
                towerId: req.params.tower,
                tourId: dc.tourId,
              });

              if (dcList && dcList.length > 0) {
                for (let i = 0; i < dcList.length; i++) {
                  let totalDuration = 0;

                  //get the weightage
                  dcList[i].wbsItem.forEach((wbs) => {
                    totalDuration = totalDuration + wbs.duration;
                  });

                  dcList[i].wbsItem.forEach((wbs) => {
                    let weightage = wbs.duration / totalDuration;
                    plannedProgress = plannedProgress + wbs.planned * weightage;
                    if (wbs.actual) {
                      actualProgress = actualProgress + wbs.actual * weightage;
                    }
                  });
                }

                let point = {
                  captureDate: dataCaptureDate,
                  planned: plannedProgress > 1 ? 1 : plannedProgress,
                  actual: actualProgress,
                };

                sCurve.push(point);
              }
            }

            // add data for planned s curve till last date of the project
            if (sCurve.length > 0) {
              let intWBSList = await ExteriorWBS.find({
                projectId: req.params.project,
                towerId: req.params.tower,
              });

              let projectFinishdate = await ExteriorWBS.findOne({
                projectId: req.params.project,
              })
                .sort({ projectFinishDate: "desc" })
                .exec();

              let finishDate = projectFinishdate.projectFinishDate;
              let captureInterval = projectFinishdate.captureInterval;

              let lastCaptureDate = new Date(
                sCurve[sCurve.length - 1].captureDate
              );

              let nextPlannedCapture = lastCaptureDate.setDate(
                lastCaptureDate.getDate() + captureInterval
              );
              let plannedEndDate = new Date(finishDate);
              let plannedDataCapture = new Date(nextPlannedCapture).setHours(
                0,
                0,
                0,
                0
              );
              let nextCapture = new Date(plannedDataCapture);

              while (nextCapture <= plannedEndDate) {
                const dataCaptureDate = new Date(nextCapture);
                let progress = 0;
                let overallAprogress = 0;

                for (let i = 0; i < intWBSList.length; i++) {
                  let totalDuration = 0;

                  //get the weightage
                  intWBSList[i].wbsList.forEach((wbs) => {
                    totalDuration = totalDuration + wbs.duration;
                  });

                  intWBSList[i].wbsList.forEach((wbs) => {
                    let weightage = wbs.duration / totalDuration;
                    const taskStart = new Date(wbs.startDate);
                    const taskEnd = new Date(wbs.finishDate);

                    if (dataCaptureDate < taskStart) {
                      progress = 0;
                    } else {
                      if (dataCaptureDate > taskEnd) {
                        progress = 1;
                      } else {
                        const diffTime = Math.abs(
                          new Date(dataCaptureDate) - new Date(taskStart)
                        );
                        const diffDays = Math.ceil(
                          diffTime / (1000 * 60 * 60 * 24)
                        );

                        progress = (diffDays / wbs.duration).toFixed(3);
                      }
                    }

                    overallAprogress = overallAprogress + progress * weightage;
                  });
                }

                let point = {
                  captureDate: dataCaptureDate,
                  planned: overallAprogress > 1 ? 1 : overallAprogress,
                  actual: 0,
                };

                sCurve.push(point);

                let nextPlannedCapture = nextCapture.setDate(
                  nextCapture.getDate() + captureInterval
                );
                nextCapture = new Date(nextPlannedCapture);
              }
              sCurve = _.sortBy(sCurve, "captureDate");
            }

            let workSchedule = await ExteriorCapture.findOne({
              projectId: req.params.project,
              tourId: req.params.tour,
              towerId: req.params.tower,
            });

            if (workSchedule) {
              workSchedule.wbsItem.forEach((wbs) => {
                if (
                  (wbs.actual && wbs.actual > 0) ||
                  (wbs.planned && wbs.planned > 0)
                ) {
                  let bar = {
                    wbsName: wbs.description,
                    planned: wbs.planned,
                    actual: wbs.actual,
                    comment: wbs.comment ? wbs.comment : "",
                  };

                  barChart.push(bar);
                }
              });
            }
            await MasterData.findOne({
              projectId: req.params.project,
            }).then((data) => {
              response.performanceIndex = data?.performanceIndex;
            });
            sCurve.forEach((m) => {
              response.sCurve.labels.push(
                moment(m.captureDate).utcOffset(330).format("YYYY-MMM-DD")
              );
              response.sCurve.planned.push((m.planned * 100).toFixed(2));
              if (m.actual > 0) {
                response.sCurve.actual.push(m.actual.toFixed(2));
              }
            });

            barChart.forEach((m) => {
              response.wbsChart.labels.push(m.wbsName);
              response.wbsChart.planned.push((m.planned * 100).toFixed(2));
              if (m.actual > 0 || m.planned > 0) {
                response.wbsChart.actual.push(m.actual.toFixed(2));
              }
              response.wbsChart.toolTip.push(m.comment);
            });
          }

          res.json({
            response,
          });
        } else {
          res.sendStatus(401);
        }
      }
    );
  }
);

// uploading Elevation files to azure blob

router.post(
  "/:project/aerialtour/:tour/elevation-file-upload/:container",
  auth.required,
  async (req, res, next) => {
    const { name: fileName, tempFilePath: filePath } = req.files.file;

    try {
      if (req.payload.email) {
        let mapurl = req.tour.mapUrls.find(
          ({ filename: filenameFromDb }) => fileName === filenameFromDb
        );
        if (mapurl) {
          const blobname = mapurl.value.split("/").pop();

          const container = req.params.container;

          const result = deleteElevationFileFromBlob(container, blobname);

          //erasing the payload from mongodb

          const updatedPayload = req.tour.mapUrls.filter((item) => {
            return item.filename !== fileName;
          });

          req.tour.mapUrls = [...updatedPayload];
          await req.tour.save();
        }

        const container = req.params.container;
        const blobContentId = `${generateUUID()}-${fileName}`;

        const result = await uploadElevationFileToBlob(
          container,
          filePath,
          blobContentId
        );

        const uploadedAt = new Date();

        const payloadRequest = getPayloadToSave(
          req.payload.email,
          fileName,
          container,
          blobContentId,
          uploadedAt
        );

        req.tour.mapUrls = req.tour.mapUrls ? req.tour.mapUrls : [];
        req.tour.mapUrls.push(payloadRequest);

        let tourData = await req.tour.save();

        fs.unlinkSync(filePath);

        res.json({
          status: `Success`,
          payload: tourData,
        });
      }
    } catch (error) {
      next(error);
    }
  }
);

router.delete(
  "/:project/aerialtour/:tour/:container/:filename/delete",
  auth.required,
  async (req, res, next) => {
    for (let url of req.tour.mapUrls) {
      if (req.params.filename === url.filename) {
        try {
          {
            const blobname = url.value.split("/").pop();

            const container = req.params.container;

            const result = deleteElevationFileFromBlob(container, blobname);

            //erasing the payload from mongodb

            let updatedPayload = req.tour.mapUrls.filter(function (item) {
              return item.filename !== req.params.filename;
            });

            req.tour.mapUrls = [...updatedPayload];

            let tourData = await req.tour.save();

            res.json({
              status: `success`,
              tour: tourData,
            });
          }
        } catch (error) {
          next(error);
        }
      }
    }
  }
);

const updateProgressByDate = async (projectId, captureDate, tourId, email) => {
  await ExteriorCapture.find({
    tourId: tourId,
    projectId: projectId,
  }).then(async (wbsItems) => {
    if (wbsItems) {
      asyncPackage.forEach(
        wbsItems,
        async function (projectWBS, callback) {
          if (projectWBS) {
            projectWBS.captureDate = new Date(captureDate).setHours(0, 0, 0, 0);
            projectWBS.updatedBy = email;

            projectWBS.wbsItem.forEach((wbs) => {
              const startDate = wbs.startDate;
              const finishDate = wbs.finishDate;
              const duration = wbs.duration;
              var progress = 0;

              const startDT = new Date(
                moment(captureDate).utcOffset(0)
              ).setHours(0, 0, 0, 0);

              let plannedCapture = new Date(startDT);
              const taskStart = new Date(
                moment(startDate).utcOffset(0)
              ).setHours(0, 0, 0, 0);
              const taskEnd = new Date(
                moment(finishDate).utcOffset(0)
              ).setHours(0, 0, 0, 0);

              if (plannedCapture < taskStart) {
                progress = 0;
              } else {
                if (plannedCapture > taskEnd) {
                  progress = 1;
                } else {
                  const diffTime = Math.abs(plannedCapture - taskStart);
                  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                  progress = (diffDays / duration).toFixed(4);
                }
              }
              wbs.planned = progress;
              wbs.updatedBy = email;
              wbs.updatedAt = new Date();
            });
            projectWBS.save(callback);
          }
        },
        function (err) {
          console.log(err);
          return;
        }
      );
    }
  });
};

// check self serve access
router.get(
  "/:project/access/self-serve",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            res.json({ access: true });
          } else {
            res.json({ access: false });
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

//get aerial tour on basis of tourId

router.get("/:project/aerialtour/:tour", auth.required, async (req, res) => {
  if (req.payload.email) {
    await Project.countDocuments(
      {
        users: {
          $elemMatch: {
            email: req.payload.email,
            isBlocked: false,
            isActive: true,
          },
        },
        projectId: req.project.projectId,
        isActive: true,
      },
      (err, count) => {
        if (count > 0 || req.payload.isAdmin) {
          res.json({ tour: req.tour });
        } else {
          res.sendStatus(401);
        }
      }
    );
  } else {
    res.sendStatus(403);
  }
});

//remarks - pointer

router.put(
  "/:project/aerialtour/tour/:tour/remarks",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const remark = {};
            remark.remarkId = req.body.remark.id;
            remark.latitude = req.body.remark.latitude;
            remark.longitude = req.body.remark.longitude;
            remark.type = req.body.remark.type;
            remark.text = req.body.remark.text;
            remark.createdByEmail = req.payload.email;
            remark.createdByName =
              req.payload.firstName + " " + req.payload.lastName;
            req.tour.remarks.push(remark);

            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// remove remark - pointer

router.put(
  "/:project/aerialtour/tour/:tour/removeremark",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "remarks.remarkId": req.body.remark.remarkId,
              },
              {
                $pull: {
                  remarks: {
                    remarkId: req.body.remark.remarkId,
                  },
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// edit/update Remark description pointer
router.put(
  "/:project/aerialtour/tour/:tour/editRemark",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },

        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "remarks.remarkId": req.body.editedRemark.id,
              },
              {
                $set: {
                  "remarks.$.text": req.body.editedRemark.text,
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// edit/update Punch item description
router.put(
  "/:project/aerialtour/tour/:tour/editPunchItem",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },

        async (err, count) => {
          const editedPunchItemMarker = req.body.editedPunchItemMarker;

          if (count > 0 || req.payload.isAdmin) {
            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "punchItemMarkers.punchItemMarkerId":
                  editedPunchItemMarker.punchItemMarkerId,
              },
              {
                $set: {
                  "punchItemMarkers.$.punchItemMarkerTaskDescription":
                    editedPunchItemMarker.punchItemTaskDescription,
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// polygon remarks

router.post(
  "/:project/aerialtour/tour/:tour/polygonRemarks",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const remark = {};
            const polygonRemarkObject = req.body.polygonRemark;

            remark.remarkId = polygonRemarkObject.remarkId;
            remark.latitude = polygonRemarkObject.remarkLatitude;
            remark.longitude = polygonRemarkObject.remarkLongitude;
            remark.polygonCoordinates = polygonRemarkObject.remarkCoordinates;
            remark.type = polygonRemarkObject.remarkType;
            remark.text = polygonRemarkObject.remarkDescriptionText;
            remark.createdByEmail = req.payload.email;
            remark.createdByName =
              req.payload.firstName + " " + req.payload.lastName;

            req.tour.remarks.push(remark);

            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// punchItem markers

router.put(
  "/:project/aerialtour/tour/:tour/punchItemMarkers",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const punchItemMarker = {};
            const punchItemMarkerObject = req.body.punchItemMarker;

            punchItemMarker.punchItemMarkerId = punchItemMarkerObject.id;
            punchItemMarker.latitude = punchItemMarkerObject.latitude;
            punchItemMarker.longitude = punchItemMarkerObject.longitude;
            punchItemMarker.punchItemMarkerTaskDescription =
              punchItemMarkerObject.punchItemMarkerTaskDescription;
            punchItemMarker.createdByEmail = req.payload.email;
            punchItemMarker.createdByName =
              req.payload.firstName + " " + req.payload.lastName;

            req.tour.punchItemMarkers.push(punchItemMarker);

            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// polygon punch item

router.put(
  "/:project/aerialtour/tour/:tour/polygonPunchItemMarkers",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const punchItemMarker = {};
            const punchItemMarkerObject = req.body.punchItemMarker;

            punchItemMarker.punchItemMarkerId = punchItemMarkerObject.id;
            punchItemMarker.latitude = punchItemMarkerObject.latitude;
            punchItemMarker.longitude = punchItemMarkerObject.longitude;
            punchItemMarker.type = punchItemMarkerObject.type;
            punchItemMarker.punchItemPolygonCoordinates =
              punchItemMarkerObject.punchListPolygonCoordinates;
            (punchItemMarker.punchItemPolygonMarkerId =
              punchItemMarkerObject.punchItemPolygonMarkerId),
              (punchItemMarker.punchItemMarkerTaskDescription =
                punchItemMarkerObject.punchItemMarkerTaskDescription);
            punchItemMarker.createdByEmail = req.payload.email;
            punchItemMarker.createdByName =
              req.payload.firstName + " " + req.payload.lastName;

            req.tour.punchItemMarkers.push(punchItemMarker);

            req.tour.updatedBy = req.payload.email;
            await req.tour
              .save()
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.delete(
  "/:project/aerialtour/tour/:tour/:punchMarkerId",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "punchItemMarkers.punchItemMarkerId": req.params.punchMarkerId,
              },
              {
                $pull: {
                  punchItemMarkers: {
                    punchItemMarkerId: req.params.punchMarkerId,
                  },
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.put(
  "/:project/restore/ext/tour/:tour/:towerId/",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.params.project,
          isActive: true,
        },

        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            let projectId = req.params.project;
            let towerId = req.params.towerId;
            let tourId = req.params.tour;
            let captureDate = req.tour.tourDate;

            await ExteriorWBS.findOne({
              projectId: projectId,
              towerId: towerId,
            }).then(async (projectWBS) => {
              if (projectWBS) {
                let wbsItems = [];

                projectWBS.wbsList.forEach((wbs) => {
                  const wbsId = wbs.wbsId;
                  const description = wbs.description;
                  const startDate = wbs.startDate;
                  const finishDate = wbs.finishDate;
                  const duration = wbs.duration;
                  const weightage = wbs.weightage;

                  var progress = 0;
                  const startDT = new Date(captureDate);
                  let plannedCapture = new Date(startDT).setHours(0, 0, 0, 0);
                  const taskStart = new Date(startDate);
                  const taskEnd = new Date(finishDate);

                  if (plannedCapture < taskStart) {
                    progress = 0;
                  } else {
                    if (plannedCapture > taskEnd) {
                      progress = 1;
                    } else {
                      const diffTime = Math.abs(plannedCapture - taskStart);
                      const diffDays = Math.ceil(
                        diffTime / (1000 * 60 * 60 * 24)
                      );
                      progress = (diffDays / duration).toFixed(3);
                    }
                  }

                  let data = {
                    wbsId: wbsId,
                    description: description,
                    startDate: startDate,
                    finishDate: finishDate,
                    duration: duration,
                    weightage: weightage,
                    planned: progress,
                    actual: 0,
                    comment: "",
                    createdBy: req.payload.email,
                    createdAt: new Date(),
                    updatedBy: req.payload.email,
                    updatedAt: new Date(),
                  };

                  wbsItems.push(data);
                });

                await ExteriorCapture.findOneAndUpdate(
                  {
                    projectId: projectId,
                    towerId: towerId,
                    tourId: tourId,
                  },
                  {
                    $set: {
                      wbsItem: wbsItems,
                      updatedBy: req.payload.email,
                    },
                  },
                  {
                    upsert: true,
                  }
                ).exec();

                res.json({
                  status: "success",
                });
              }
            });
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// return a list of tags
router.get(
  "/:project/exportchartdata/ext",
  auth.required,
  async (req, res, next) => {
    var workbook = new Excel.Workbook();
    let worksheet = workbook.addWorksheet("Data");
    var sheetName = req.project.projectName + ".xlsx";
    let projectId = req.params.project;

    await MasterData.findOne({
      projectId: req.params.project,
    })
      .then(async (data) => {
        const locations = data?.workLocation;

        worksheet.columns = [
          {
            header: "Level1 Location",
            key: "level1",
            width: 35,
          },
          {
            header: "WBS Description",
            key: "wbs",
            width: 35,
          },
          {
            header: "Planned",
            key: "planned",
            width: 22,
          },
          {
            header: "Actual",
            key: "actual",
            width: 22,
          },
        ];

        let captureList = await ExteriorCapture.find({
          projectId: projectId,
        }).exec();

        for (let i = 0; i < captureList.length; i++) {
          let capture = captureList[i];
          let wbsItem = capture.wbsItem;
          if (wbsItem && wbsItem.length > 0) {
            let tower = locations.find(
              (l) => l.locationId === captureList[i].towerId
            );

            for (let j = 0; j < wbsItem.length; j++) {
              let wbs = [];

              wbs.push(tower.level1);
              wbs.push(wbsItem[j].description);
              wbs.push(wbsItem[j].planned * 100);
              wbs.push(wbsItem[j].actual);

              worksheet.addRow(wbs);
            }
          }
        }

        res.setHeader("Content-Type", "text/plain");

        const fileBuffer = await workbook.xlsx.writeBuffer();

        res.send(fileBuffer.toString("base64"));
      })
      .catch(next);
  }
);

const getActivityChart = async (projectId) => {
  try {
    let wbsList = [];
    let activityChart = {
      labels: [],
      planned: [],
      actual: [],
    };

    let captureList = await ExteriorCapture.find({
      projectId: projectId,
    });

    if (captureList && captureList.length > 0) {
      for (let i = 0; i < captureList.length; i++) {
        let capture = captureList[i];
        let wbsItem = capture.wbsItem;
        if (wbsItem && wbsItem.length > 0) {
          for (let j = 0; j < wbsItem.length; j++) {
            wbsList.push({
              activity: wbsItem[j].description,
              planned: wbsItem[j].planned * 100,
              actual: wbsItem[j].actual,
            });
          }
        }
      }

      var result = _.chain(wbsList)
        .groupBy("activity")
        .map(function (value, key) {
          return {
            activity: key,
            planned: activityAvg(_.pluck(value, "planned")),
            actual: activityAvg(_.pluck(value, "actual")),
          };
        })
        .value();

      for (let i = 0; i < result.length; i++) {
        activityChart.labels.push(result[i].activity);
        result[i].planned.then((val) => activityChart.planned.push(val));
        result[i].actual.then((val) => activityChart.actual.push(val));
      }

      return activityChart;
    } else {
      return activityChart;
    }
  } catch (ex) {
    console.log(ex);
  }
};

const activityAvg = async (numbers) => {
  return _.reduce(
    numbers,
    (result, current) => {
      return result + parseFloat(current);
    },
    0
  );
};

// update tour
router.put(
  "/:project/tour/:tour/pointcloudobjectcount",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            req.tour.updatedBy = req.payload.email;
            req.tour.objectCount = parseInt(req.body.objectCount);
            await req.tour
              .save()
              .then(async (tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

//Update Latitude and Longitude values

router.put(
  "/:project/aerialtour/tour/:tour/updateLatLng",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },

        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
              },
              {
                $set: {
                  lat: req.body.latLngValues.latitude,
                  lng: req.body.latLngValues.longitude,
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// mapbox layer re-ordering
router.put(
  "/:project/aerialtour/tour/:tour/updateMapboxLayerOrder",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },

        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const newMapURLs = req.body.newMapURLs;
            const mapURLsWithUpdatedAppendIndex = [];

            const dsmKey = "mapbox_dsm_url" || url.key === "DSM";
            const dtmKey = "mapbox_dtm_url" || url.key === "DTM";
            const orthomosaicKey =
              "mapbox_orthomosaic_url" || url.key === "ORTHOMOSAIC";

            const isDtm = (url) => url.key === dtmKey;

            const isDsm = (url) => url.key === dsmKey;

            const isOrtho = (url) => url.key === orthomosaicKey;

            const isDtmExists = newMapURLs.some((mapURL) => isDtm(mapURL));

            const isDsmExists = newMapURLs.some((mapURL) => isDsm(mapURL));

            const isOrthoExists = newMapURLs.some((mapURL) => isOrtho(mapURL));

            newMapURLs.forEach((mapURL, index) => {
              mapURL.appendIndex = index;

              if (isDtm(mapURL)) {
                mapURL.type = "dtm";
                mapURL.filename = "dtm.tif";
              } else if (isDsm(mapURL)) {
                mapURL.type = "dsm";
                mapURL.filename = "dsm.tif";
              } else if (isOrtho(mapURL)) {
                mapURL.type = "orthomosaic";
                mapURL.filename = "orthomosaic.tif";
              } else if (mapURL.type === "user_zipped_shapefile") {
                if (mapURL.key === "TREE CANOPIO") {
                  mapURL.filename = "Tree_Canopio.zip";
                } else if (mapURL.key === "TREE COUNT POINTS") {
                  mapURL.filename = "Tree_Count_points.zip";
                } else if (mapURL.key === "CONTOUR") {
                  mapURL.filename = "contour.zip";
                } else if (mapURL.key === "BOUNDARY") {
                  mapURL.filename = "boundary.zip";
                } else if (mapURL.key === "SHAPEFILE") {
                  mapURL.filename = "shapefile.zip";
                } else if (mapURL.key === "STREAM FLOW SIMULATION") {
                  mapURL.filename = "stream_flow_simulation.zip";
                } else {
                  mapURL.filename = "user_tif.zip";
                }
              } else if (mapURL.key === "DSM 1" && !isDsmExists) {
                mapURL.type = "dsm";
                mapURL.filename = "dsm.tif";
                mapURL.key = "DSM";
              } else if (mapURL.key === "DTM 1" && !isDtmExists) {
                mapURL.type = "dtm";
                mapURL.filename = "dtm.tif";
                mapURL.key = "DTM";
              } else if (mapURL.key === "ORTHOMOSAIC 1" && !isOrthoExists) {
                mapURL.type = "orthomosaic";
                mapURL.filename = "orthomosaic.tif";
                mapURL.key = "ORTHOMOSAIC";
              } else if (
                mapURL.key === "dsm_elevation_blob_url" ||
                mapURL.key === "dsm_blob_url"
              ) {
                mapURL.type = "blob_dsm_elevation";
                mapURL.appendIndex = -1;
              } else if (
                mapURL.key === "dtm_elevation_blob_url" ||
                mapURL.key === "dtm_blob_url"
              ) {
                mapURL.type = "blob_dtm_elevation";
                mapURL.appendIndex = -1;
              }

              mapURLsWithUpdatedAppendIndex.push(mapURL);
            });

            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
              },
              {
                $set: {
                  mapUrls: mapURLsWithUpdatedAppendIndex,
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({ tour: tour });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// Save drone flight data

router.put(
  "/:project/aerialtour/:tour/droneflightdata",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const droneFlightDataObject = {};
            const droneFlightData = req.body.droneFlightData;

            droneFlightDataObject.flightDataId =
              droneFlightData[0].flightDataId;
            droneFlightDataObject.uploadedDate =
              droneFlightData[0].uploadedDate;
            droneFlightDataObject.droneFlightData =
              droneFlightData[0].droneFlightData;
            droneFlightDataObject.uploadedByEmail = req.payload.email;
            droneFlightDataObject.uploadedBy =
              req.payload.firstName + " " + req.payload.lastName;

            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
              },
              {
                $set: {
                  droneFlightData: droneFlightDataObject,
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// Delete drone flight data

router.delete(
  "/:project/aerialtour/:tour/droneflightdata",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
              },
              {
                $set: {
                  droneFlightData: [],
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// save drone flight video details

router.put(
  "/:project/aerialtour/:tour/droneflightvideo",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const droneFlightVideoDataObject = {};
            const droneFlightData = req.body.droneFlightVideoData;

            droneFlightVideoDataObject.fileObjectId =
              droneFlightData[0].fileObjectId;
            droneFlightVideoDataObject.clientId = req.project.clientId;
            droneFlightVideoDataObject.uploadedByEmail = req.payload.email;
            droneFlightVideoDataObject.uploadedBy =
              req.payload.firstName + " " + req.payload.lastName;

            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
              },
              {
                $set: {
                  droneFlightVideoData: droneFlightVideoDataObject,
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// delete drone flight video details

router.delete(
  "/:project/aerialtour/:tour/droneflightvideo",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
              },
              {
                $set: {
                  droneFlightVideoData: [],
                },
              },
              {
                new: true,
              }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

//updating color of the shapefile (contour and boundary)

router.put(
  "/:project/aerialtour/:tour/shapefileColor",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            const {
              layerName: shapefileLayerName,
              newLayerColor: shapefileColor,
            } = req.body.shapeFileData[0];

            let mapurl = req.tour.mapUrls.find(
              ({ filename: filenameFromDb }) =>
                shapefileLayerName === filenameFromDb
            );

            await AerialTour.findOneAndUpdate(
              {
                tourId: req.tour.tourId,
                "mapUrls.filename": shapefileLayerName,
              },
              {
                $set: {
                  "mapUrls.$.shapefileColor": shapefileColor,
                },
              },
              { new: true }
            )
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

// Deleting Images from the Azure blob and reset tour

router.delete(
  "/:project/aerialtour/:tour/deleteTourImages",
  auth.required,
  async (req, res, next) => {
    try {
      const blobname = req.params.tour;
      const container = aerialtourContainer;

      const result = await deleteAerialTourImageFolder(container, blobname);

      if (result) {
        // Erasing the payload from MongoDB
        await Project.countDocuments(
          {
            users: {
              $elemMatch: {
                email: req.payload.email,
                isActive: true,
                isBlocked: false,
              },
            },
            projectId: req.project.projectId,
            isActive: true,
          },
          async (err, count) => {
            if (count > 0 || req.payload.isAdmin) {
              await AerialTour.findOneAndUpdate(
                {
                  tourId: req.params.tour,
                },
                {
                  $set: {
                    images: [],
                  },
                },
                { new: true }
              )
                .then((tour) => {
                  res.json({
                    tour: tour,
                  });
                })
                .catch(next);
            }
          }
        );
      } else {
        res.sendStatus(401);
      }
    } catch (error) {
      next(error);
    }
  }
);

router.put(
  "/:project/aerialtour/:tour/tags",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            if (!!req.body.tagList && req.body.tagList.length > 0) {
              req.tour.tagList = req.body.tagList;
            }
            req.tour.updatedBy = req.payload.email;

            await req.tour
              .save()
              .then((tour) => {
                res.json({
                  tour: tour,
                });
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

router.get(
  "/:project/:tour/status/:status",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      await Project.countDocuments(
        {
          users: {
            $elemMatch: {
              email: req.payload.email,
              isActive: true,
              isBlocked: false,
            },
          },
          projectId: req.project.projectId,
          isActive: true,
        },
        async (err, count) => {
          if (count > 0 || req.payload.isAdmin) {
            await ProcessingStatistic.updateOne(
              {
                tour_id: req.params.tour,
              },
              {
                $set: {
                  overall_processing_status: "Process Complete",
                },
              }
            )
              .then(async () => {
                const lookUp = await LookUp.findOne({
                  type: "aerialTourStatus",
                  key: req.params.status,
                });
                req.tour.status = {
                  code: lookUp.key,
                  desc: lookUp.value,
                };
                await req.tour
                  .save()
                  .then(() => {
                    res.json({
                      status: "success",
                    });
                  })
                  .catch(next);
              })
              .catch(next);
          } else {
            res.sendStatus(401);
          }
        }
      );
    } else {
      res.sendStatus(403);
    }
  }
);

module.exports = router;
