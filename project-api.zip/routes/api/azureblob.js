"use strict";

const router = require("express").Router();
const { AzureAccountName } = require("../../config").azureStorage;
const auth = require("../auth");
const getAzureSASToken = require("../../common/azure.access.token");

router.get("/sas/:container/", auth.required, (req, res) => {
  if (req.payload.email) {
    const container = req.params.container;
    const sasToken = getAzureSASToken(container, "w");

    res.json({
      sasToken: {
        token: sasToken,
        uri: `https://${AzureAccountName}.blob.core.windows.net/${container}?${sasToken}`,
      },
    });
  } else {
    res.sendStatus(403);
  }
});

router.get("/sas/:container/blob/:blobName", auth.required, (req, res) => {
  if (req.payload.email) {
    const container = req.params.container;
    const blobName = req.params.blobName;

    if (blobName) {
      const sasToken = getAzureSASToken(container);
      res.json({
        sasToken: {
          token: sasToken,
          uri: `https://${AzureAccountName}.blob.core.windows.net/${container}/${blobName}?${sasToken}`,
        },
      });
    } else {
      res.sendStatus(401);
    }
  } else {
    res.sendStatus(403);
  }
});

router.get("/sas/read/:container/", auth.required, (req, res) => {
  if (req.payload.email) {
    const container = req.params.container;

    const sasToken = getAzureSASToken(container);
    res.json({
      sasToken: {
        token: sasToken,
        uri: `https://${AzureAccountName}.blob.core.windows.net/${container}?${sasToken}`,
      },
    });
  } else {
    res.sendStatus(403);
  }
});

// Used for a longrunning task - (Aerial upload - Android)
router.get("/sas/longRunningTask/:container/", auth.required, (req, res) => {
  if (req.payload.email) {
    const container = req.params.container;

    const sasToken = getAzureSASToken(container, "w", 24 * 60 * 60);
    res.json({
      sasToken: {
        token: sasToken,
        uri: `https://${AzureAccountName}.blob.core.windows.net/${container}?${sasToken}`,
      },
    });
  } else {
    res.sendStatus(403);
  }
});

module.exports = router;
