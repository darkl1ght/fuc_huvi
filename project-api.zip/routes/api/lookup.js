"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const LookUp = mongoose.model("LookUp");
const auth = require("../auth");

// return a list of tags
router.get("/lookup/:type", auth.required, (req, res, next) => {
  const type = req.params.type;

  LookUp.find({
    type: type,
  })
    .then((data) => {
      res.json({
        lookups: data.map((lookup) => {
          return lookup.toJSONFor();
        }),
      });
    })
    .catch(next);
});

module.exports = router;
