"use strict";

const router = require("express").Router();
router.use("/azureblob", require("./azureblob"));
router.use("/", require("./projects"));
router.use("/lookups", require("./lookup"));
router.use("/client", require("./client"));
router.use("/dashboard", require("./dashboard"));
router.use("/virtualtour", require("./virtualtour"));
router.use("/projectmedia", require("./media"));
router.use("/aerialtour", require("./aerialtour"));
router.use("/accesscontrol", require("./accessControl"));
router.use("/integration", require("./integration"));
router.use("/mapboxupload", require("./mapbox.uploads"));
router.use("/mapboxannotation", require("./mapbox.annotation"));
router.use("/masterdata", require("./masterdata"));
router.use("/punchlist", require("./punchlist"));
router.use("/projectwbs", require("./projectwbs"));
router.use("/workschedule", require("./workschedule"));
router.use("/email", require("./email"));
router.use("/notifications", require("./notificationsmasterdata"));
router.use("/forge", require("./autocad.forge"));
router.use("/share", require("./share"));
router.use("/workflow", require("./workflow"));
router.use("/rfi", require("./rfi"));
router.use("/inspectionchecklist", require("./inspectionchecklist"));
router.use("/appmessage", require("./appmessage"));
router.use("/captureapplog", require("./captureapplog"));
router.use("/opsreports", require("./ops-reports"));
router.use((err, req, res, next) => {
  if (err.name === "ValidationError") {
    return res.status(422).json({
      errors: Object.keys(err.errors).reduce((errors, key) => {
        errors[key] = err.errors[key].message;

        return errors;
      }, {}),
    });
  }

  return next(err);
});

module.exports = router;
