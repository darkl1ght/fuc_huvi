"use strict";

const router = require("express").Router();
const fs = require("fs");
const util = require("util");
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const AerialTour = mongoose.model("AerialTour");
const path = require("path");
const rootDir = path.dirname(path.dirname(__dirname));
const execPromise = util.promisify(require("child_process").exec);
const csvParse = require("csv-parse");
const tmcwToGeojson = require("@tmcw/togeojson");
const { DOMParser } = require("xmldom");
const jsonpath = require("jsonpath");
const _ = require("lodash");
const StreamZip = require("node-stream-zip");
const { DBFFile } = require("dbffile");

const auth = require("../auth");
const MapboxUpload = require("../../common/mapbox.upload");
const { wait, getFilesFromRequest } = require("../../common/util");

// Preload project objects on routes with ":project"
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

// Preload tour objects on routes with ":tour"
router.param("tour", (req, res, next, tourId) => {
  AerialTour.findOne({
    tourId: tourId,
  })
    .then((tour) => {
      if (!tour) {
        return res.sendStatus(404);
      }
      req.tour = tour;
      return next();
    })
    .catch(next);
});

const flatten = (items) => {
  const flat = [];
  for (let item of items) {
    if (Array.isArray(item) && Array.isArray(item[0])) {
      flat.push(...flatten(item));
    } else {
      flat.push(item);
    }
  }
  return flat;
};

const addFeature = (layers, feature) => {
  const { length } = layers;
  const id = length + 1;
  const found = layers.some(
    (el) => el["source-layer"] === feature.properties.tilequery.layer
  );
  if (!found) {
    layers.push({
      geometry: feature.properties.tilequery.geometry,
      "source-layer": feature.properties.tilequery.layer,
      layerId: feature.properties.tilequery.layer + "_" + id,
    });
  }
  return layers;
};

const updateMapUrls = async (
  req,
  res,
  file,
  uploadCount,
  mapbox_url = "",
  tileset = "",
  coordinates = [[]],
  csvData = [[]],
  geojsonData = [],
  shapeFileData = {}
) => {
  if (!req.tour.mapUrls) {
    req.tour.mapUrls = [];
  }
  let prevLargestIndex = 20;
  for (let url of req.tour.mapUrls) {
    if (url.appendIndex && url.appendIndex > prevLargestIndex) {
      prevLargestIndex = url.appendIndex;
    }
  }
  let urlObj = {};
  if (req.params.type === "csv") {
    urlObj = {
      type: `user_csv`,
      csvData: csvData[0],
    };
  } else if (req.params.type === "geojson") {
    urlObj = {
      type: `user_geojson`,
      geojsonData: geojsonData,
    };
  } else if (req.params.type === "kml") {
    const flatCoordinates = flatten(coordinates);
    let layers = [];
    const features = await MapboxUpload.getTilequeryData(
      tileset,
      flatCoordinates[0] // taking only single coordinate and testing it
    );
    if (features.length > 0) {
      for (let feature of features) {
        if (
          feature.properties &&
          feature.properties.tilequery &&
          feature.properties.tilequery.layer
        )
          layers = addFeature(layers, feature);
      }
    }
    urlObj = {
      type: `user_kml`,
      kmlSourceLayers: layers,
    };
  } else if (req.params.type === "zip") {
    urlObj = {
      type: `user_zipped_shapefile`,
      shapeFileData: shapeFileData,
    };
  } else {
    urlObj = {
      type: `user_${req.params.type}`,
    };
  }

  urlObj.filename = file.filename;
  urlObj.uploadedAt = file.uploadedAt;
  urlObj.key = file.filename.split(".")[0].split("_").join(" ").toUpperCase(); //save only the basename without the extension
  urlObj.value = mapbox_url;
  urlObj.appendIndex = prevLargestIndex + 1;

  // whether the map-layer should be enabled or disabled by default based on filename
  const basename = file.filename.split(".")[0].toLowerCase();
  if (basename === "orthomosaic" || basename === "dtm" || basename === "dsm") {
    urlObj.disabled = false;
    urlObj.type = basename;
  } else {
    urlObj.disabled = true;
  }
  urlObj.addedBy = req.payload.email;
  req.tour.mapUrls.push(urlObj);
  await req.tour.save().then((tour) => {
    req.tour.mapUrls = tour.mapUrls;
    uploadCount += 1;
    try {
      fs.unlinkSync(file.uploadPath);
      //file removed
    } catch (err) {
      res.status(500).json({
        error: "error while removing the file:" + JSON.stringify(err),
      });
    }
  });

  return { uploadCount };
};

const aws_file_upload = async (req, file, credentialResponse) => {
  const csvData = [];
  let coordinates = [];
  let shapeFileData = {};
  let err = null;
  if (req.params.type === "csv") {
    fs.createReadStream(file.uploadPath)
      .pipe(
        csvParse({
          delimiter: ",",
        })
      )
      .on("data", (csvrow) => {
        //do something with csvrow
        csvData.push(csvrow);
      })
      .on("end", () => {
        //do something wiht csvData
      });
  } else if (req.params.type === "kml") {
    const kml = new DOMParser().parseFromString(
      fs.readFileSync(file.uploadPath, "utf8")
    );
    const converted = tmcwToGeojson.kml(kml);
    coordinates = jsonpath.query(converted, "$..coordinates");
  } else if (req.params.type == "zip") {
    // waiting 100ms just for the zip file to be loaded before being read
    await wait(100);

    const zip = new StreamZip.async({ file: file.uploadPath });
    const entries = await zip.entries();
    let isSHPFilePresent = false;
    let dbfFileNameInZip = "";
    let isDBFFilePresent = false;

    for (const entry of Object.keys(entries)) {
      const extension = entry.substr(entry.lastIndexOf(".") + 1);
      if (extension === "shp") isSHPFilePresent = true;
      if (extension === "dbf") {
        isDBFFilePresent = true;
        dbfFileNameInZip = entry;
      }
    }
    if (!isSHPFilePresent) {
      err = {
        status: 500,
        error: "Mandatory SHP file is missing from the zip.",
      };
    } else if (!isDBFFilePresent) {
      err = {
        status: 500,
        error: "Mandatory DBF file is missing from the zip.",
      };
    } else if (dbfFileNameInZip != "") {
      const fileName = file.filename.split(".")[0].toLowerCase();
      const uploadDir = path.join(rootDir, "mapbox_uploads");
      const dbfFilePath = path.join(uploadDir, fileName + ".dbf");
      await zip.extract(dbfFileNameInZip, dbfFilePath);
      await zip.close();
      let dbf = await DBFFile.open(dbfFilePath);
      const columns = dbf.fields.map((f) => f.name);

      if (fileName === "contour") {
        if (columns.includes("ELEVATION")) {
          shapeFileData.type = "contour";
          shapeFileData.columns = columns;
        } else {
          err = {
            status: 500,
            error: "Column named 'ELEVATION' is missing from the DBF file.",
          };
        }
      } else if (fileName === "stream_flow_simulation") {
        if (columns.includes("grid_code")) {
          shapeFileData.type = "stream_flow_simulation";
          shapeFileData.columns = columns;
        } else {
          err = {
            status: 500,
            error: "Column named 'grid_code' is missing from the DBF file.",
          };
        }
      } else if (fileName === "boundary") {
        shapeFileData.type = "boundary";
        shapeFileData.columns = columns;
      } else if (fileName.includes("points")) {
        shapeFileData.type = "points";
        shapeFileData.columns = columns;
      } else {
        shapeFileData.type = "other";
        shapeFileData.columns = columns;
      }
      fs.unlinkSync(dbfFilePath);
    }
  }

  if (!err) {
    const command = `aws s3 cp "${file.uploadPath}" s3://${credentialResponse["bucket"]}/${credentialResponse["key"]} --region us-east-1`;
    const { stdout, stderr } = await execPromise(command, {
      shell: true,
      env: {
        AWS_ACCESS_KEY_ID: credentialResponse["accessKeyId"],
        AWS_SECRET_ACCESS_KEY: credentialResponse["secretAccessKey"],
        AWS_SESSION_TOKEN: credentialResponse["sessionToken"],
      },
    });
    if (stderr) {
      err = {
        status: 500,
        error: stderr,
      };
    }
  }

  return { csvData, coordinates, shapeFileData, err };
};

router.post("/:project/:tour/:type", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    const files = req.files;
    if (!files || Object.keys(files).length === 0) {
      return res.status(400).send("No files were uploaded.");
    }
    const fileCount = Object.keys(files).length;
    let {
      movedFiles: uploadedFiles,
      moveCount: uploadCount,
      moveErr: err,
    } = await getFilesFromRequest(files, req.payload.email, "mapbox_uploads");
    if (!err) {
      for (let file of uploadedFiles) {
        if (req.params.type == "geojson") {
          // waiting 100ms just for the geojson file to be loaded before being read
          await wait(100);
          const strigifiedGeojson = fs.readFileSync(file.uploadPath, {
            encoding: "utf8",
          });
          const geojsonData =
            strigifiedGeojson && strigifiedGeojson !== ""
              ? JSON.parse(strigifiedGeojson)
              : {};
          const response = await updateMapUrls(
            req,
            res,
            file,
            uploadCount,
            null,
            null,
            null,
            null,
            geojsonData
          );
          uploadCount = response.uploadCount;
        } else {
          const credentialResponse = await MapboxUpload.getUploadCredentials();

          const uploadResponse = await aws_file_upload(
            req,
            file,
            credentialResponse
          );
          const { csvData, coordinates, shapeFileData, err } = uploadResponse;
          if (!err) {
            const { uploadIdStatus, uploadIdResponse } =
              await MapboxUpload.getUploadId(credentialResponse);
            if (uploadIdStatus == 201) {
              while (true) {
                const { uploadStatusStatus, uploadStatusResponse } =
                  await MapboxUpload.getUploadStatus(uploadIdResponse["id"]);
                await wait(5000);
                if (
                  uploadStatusStatus == 200 &&
                  uploadStatusResponse["complete"] &&
                  !uploadStatusResponse["error"]
                ) {
                  const tileset = uploadStatusResponse["tileset"];
                  const new_url = `mapbox://${tileset}`;
                  const response = await updateMapUrls(
                    req,
                    res,
                    file,
                    uploadCount,
                    new_url,
                    tileset,
                    coordinates,
                    csvData,
                    [],
                    shapeFileData
                  );
                  uploadCount = response.uploadCount;
                  break;
                } else if (uploadStatusResponse["error"]) {
                  res.sendStatus(500).json({
                    error: uploadStatusResponse["error"],
                  });
                } else {
                  await wait(15000);
                }
              }
            } else {
              res.sendStatus(500).json({
                error: "upload failed status: " + uploadIdStatus,
              });
            }
          } else {
            res.sendStatus(500).json({
              error: err,
            });
          }
        }
      }
      if (uploadCount == fileCount * 2) {
        res.json({
          status: "success",
          tour: req.tour,
        });
      } else {
        res.sendStatus(500);
      }
    } else {
      res.status(500).send(err);
    }
  } else {
    res.sendStatus(403);
  }
});

module.exports = router;
