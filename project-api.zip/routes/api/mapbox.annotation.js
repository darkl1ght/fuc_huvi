"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const AerialTour = mongoose.model("AerialTour");
const LookUp = mongoose.model("LookUp");
const auth = require("../auth");

// Preload project objects on routes with ":project"
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

// Preload project objects on routes with ":tour"
router.param("tour", (req, res, next, tourId) => {
  AerialTour.findOne({
    tourId: tourId,
  })
    .then((tour) => {
      if (!tour) {
        return res.sendStatus(404);
      }
      req.tour = tour;
      return next();
    })
    .catch(next);
});

// save mapbox tour annotation
router.post("/:project/:tour/", auth.required, async (req, res, next) => {
  if (!req.tour.annotations) {
    req.tour.annotations = [];
  }
  req.tour.annotations.push(req.body.annotation);
  await req.tour
    .save()
    .then((tour) => {
      res.json({
        annotations: tour.annotations,
      });
    })
    .catch(next);
});

// get all annotations of a mapbox tour
router.get("/:project/:tour/", auth.required, (req, res) => {
  if (!req.tour.annotations) {
    req.tour.annotations = [];
  }
  res.json({
    annotations: req.tour.annotations,
  });
});

router.delete(
  "/:project/:tour/:annotationId",
  auth.required,
  async (req, res, next) => {
    if (!req.tour.annotations) {
      req.tour.annotations = [];
    }
    const annotations = req.tour.annotations.filter((annotation) => {
      return annotation.drawnPolygonId !== req.params.annotationId;
    });
    req.tour.annotations = annotations;
    await req.tour
      .save()
      .then((tour) => {
        res.json({
          annotations: tour.annotations,
        });
      })
      .catch(next);
  }
);

// get annotations types based on color of a mapbox tour
router.get("/types", auth.required, async (req, res, next) => {
  await LookUp.find({
    type: "annotationType",
  })
    .then((types) => {
      if (types.length == 0) {
        res.json({
          data: [],
        });
      }
      const annotationTypes = [];
      for (let type of types) {
        annotationTypes.push({
          label: type["key"],
          value: type["value"],
        });
      }
      res.json({
        annotationTypes: annotationTypes,
      });
    })
    .catch(next);
});

module.exports = router;
