"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const DeepLink = mongoose.model("DeepLink");

const auth = require("../auth");
const uuid = require("uuid");
const moment = require("moment-timezone");
const _ = require("underscore");
const Util = require("../../common/util");
const logger = require("../../common/logger");
const Project = mongoose.model("Project");
// generate shared link
router.post("/generate", auth.required, async (req, res, next) => {
  let shareData = null;
  if (
    req.payload.email &&
    req.body.objectId &&
    req.body.moduleName &&
    req.body.shareInfo
  ) {
    await DeepLink.findOne({
      objectId: req.body.objectId,
      moduleName: req.body.moduleName,
      isActive: true,
    })
      .then((data) => {
        shareData = data;
      })
      .catch(next);
    if (!shareData) {
      const deepLink = new DeepLink({
        objectId: req.body.objectId,
        moduleName: req.body.moduleName,
        shareId: uuid.v4(),
        shareInfo: req.body.shareInfo,
        createdBy: req.payload.email,
      });

      await deepLink
        .save()
        .then((obj) => {
          res.json({
            share: obj.shareId,
          });
        })
        .catch(next);
    } else {
      res.json({
        share: shareData.shareId,
      });
    }
  } else {
    res.sendStatus(403);
  }
});

router.get("/:shareId", auth.required, async (req, res, next) => {
  if (req.payload.email && req.params.shareId) {
    await DeepLink.findOne({
      shareId: req.params.shareId,
      isActive: true,
    })
      .then(async (data) => {
        if (!!data) {
          if (req.payload.isAdmin) {
            const query = {
              projectId: data.shareInfo.projectId,
              isActive: true,
            };
            await Project.findOne(query).then((projectAccessible) => {
              if (!!projectAccessible) {
                res.json({
                  share: data,
                });
              } else {
                res.json({
                  share: null,
                });
              }
            });
          } else {
            const query = {
              projectId: data.shareInfo.projectId,
            };
            query.users = {
              $elemMatch: {
                email: req.payload.email.toLowerCase(),
                isBlocked: false,
                isActive: true,
              },
            };
            query.isActive = true;
            await Project.findOne(query).then((projectAccessible) => {
              if (!!projectAccessible) {
                res.json({
                  share: data,
                });
              } else {
                res.json({
                  share: null,
                });
              }
            });
          }
        } else {
          res.json({
            share: null,
          });
        }
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

module.exports = router;
