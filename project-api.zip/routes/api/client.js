"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const Client = mongoose.model("Client");
const ProcessingStatistic = mongoose.model("ProcessingStatistic");
const moment = require("moment-timezone");
const auth = require("../auth");
const uuid = require("uuid");

// Preload client object
router.param("client", (req, res, next, clientId) => {
  Client.findOne({
    clientId: clientId,
  })
    .then((client) => {
      if (!client) {
        return res.sendStatus(404);
      }
      req.client = client;
      return next();
    })
    .catch(next);
});

router.post("/", auth.required, async (req, res, next) => {
  if (req.payload.email && req.payload.isAdmin) {
    const existingClient = await Client.findOne({
      email: req.body.client.email,
    });
    if (!existingClient) {
      const client = new Client(req.body.client);
      client.clientId = uuid.v4();
      client.isActive = true;
      await client
        .save()
        .then((obj) => {
          res.json({
            client: obj,
          });
        })
        .catch(next);
    } else {
      // client already exists with given email ID and isActive
      res.status(400).send({
        status: "400",
        message: "Client with this email already exists.",
      });
    }
  } else {
    res.sendStatus(401);
  }
});

router.get("/clients/:client", auth.required, (req, res, next) => {
  if (req.payload.email || req.payload.isAdmin) {
    res.json({
      client: req.client,
    });
  } else {
    res.sendStatus(403);
  }
});

router.get("/clients/", auth.required, async (req, res, next) => {
  if (req.payload.email && req.payload.isAdmin) {
    await Client.find({
      isActive: true,
    })
      .then((data) => {
        res.json({
          clients: data,
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

// delete client
router.delete("/:client/", auth.required, async (req, res, next) => {
  if (req.payload.email && req.payload.isAdmin) {
    req.client.isActive = false;
    await req.client
      .save()
      .then(() => {
        res.json({
          status: "success",
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.put("/:client/", auth.required, async (req, res, next) => {
  if (req.payload.email && req.payload.isAdmin && req.body.client) {
    if (typeof req.body.client.email !== "undefined") {
      const existingClient = await Client.findOne({
        email: req.body.client.email,
      });
      if (!existingClient) {
        req.client.email = req.body.client.email;
      } else {
        // client already exists with given email ID
        res.status(409).send({
          status: "409",
          message: "This email already exists in a client.",
        });
      }
    }

    if (typeof req.body.client.clientName !== "undefined") {
      req.client.clientName = req.body.client.clientName;
    }

    if (typeof req.body.client.clientAdmin !== "undefined") {
      req.client.clientAdmin = req.body.client.clientAdmin;
    }

    if (typeof req.body.client.blobContentId !== "undefined") {
      req.client.blobContentId = req.body.client.blobContentId;
    }

    if (typeof req.body.client.firstName !== "undefined") {
      req.client.firstName = req.body.client.firstName;
    }

    if (typeof req.body.client.lastName !== "undefined") {
      req.client.lastName = req.body.client.lastName;
    }

    req.client.updatedBy = req.payload.email;

    await req.client
      .save()
      .then((client) => {
        res.json({
          client: client,
        });
      })
      .catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.post("/:client/tatreport/", auth.required, async (req, res, next) => {
  if (req.payload.isAdmin) {
    await req.client
      .populate({
        path: "projects",
        options: {
          sort: {
            createdAt: "desc",
          },
        },
      })
      .execPopulate()
      .then(async () => {
        let responseArray = [];
        for (let projectIndex in req.client.projects) {
          let currentProject = req.client.projects[projectIndex];
          if (currentProject.isActive) {
            await currentProject
              .populate({
                path: "aerialTours",
                options: {
                  sort: {
                    createdAt: "desc",
                  },
                },
              })
              .execPopulate()
              .then(async () => {
                for (let tourIndex in currentProject.aerialTours) {
                  let currentTour = currentProject.aerialTours[tourIndex];
                  let imageUploadTime;
                  let processingStartTime;
                  let processingEndTime;
                  let uploadCompleteTime;
                  if (
                    currentTour.isActive &&
                    currentTour.status.code === "AT10003"
                  ) {
                    await currentTour
                      .populate({
                        path: "images",
                        options: {
                          sort: {
                            createdAt: "asc",
                          },
                        },
                      })
                      .execPopulate()
                      .then(async () => {
                        currentTour.images && currentTour.images.length > 0
                          ? (imageUploadTime = new Date(
                              currentTour.images[0].createdAt
                            ).toISOString())
                          : null;
                      });

                    await ProcessingStatistic.findOne({
                      tour_id: currentTour.tourId,
                    })
                      .then((tourStatistics) => {
                        if (tourStatistics.events.length > 0) {
                          processingStartTime = new Date(
                            tourStatistics.events[0].time + "Z"
                          ).toISOString();
                          uploadCompleteTime = new Date(
                            tourStatistics.events[
                              tourStatistics.events.length - 1
                            ].time + "Z"
                          ).toISOString();
                          processingEndTime = new Date(
                            tourStatistics.events
                              .filter((event) => {
                                return (
                                  event.description
                                    .toLowerCase()
                                    .includes("step") &&
                                  event.description
                                    .toLowerCase()
                                    .includes("completed")
                                );
                              })
                              .pop().time + "Z"
                          ).toISOString();
                        }
                      })
                      .catch((err) => {
                        next(err);
                      });
                  }
                  responseArray.push({
                    projectName: currentProject.projectName,
                    tourName: currentTour.tourName,
                    imageUploadTime: imageUploadTime,
                    processingStartTime: processingStartTime,
                    tat1: timeDiff(imageUploadTime, processingStartTime),
                    processingEndTime: processingEndTime,
                    tat2: timeDiff(processingStartTime, processingEndTime),
                    orthomosaicUploadTime: uploadCompleteTime,
                    tat3: timeDiff(processingEndTime, uploadCompleteTime),
                  });
                }
              })
              .catch(next);
          }
        }
        res.json({ projectTATReport: responseArray });
      })
      .catch(next);
  }
});

const timeDiff = (imageUploadTime, processingStartTime) => {
  if (imageUploadTime != null && processingStartTime != null) {
    const date1 = new Date(imageUploadTime);
    const date2 = new Date(processingStartTime);
    const diff = date2.getTime() - date1.getTime();
    let msec = diff;
    const hh = Math.floor(msec / 1000 / 60 / 60);
    msec -= hh * 1000 * 60 * 60;
    const mm = Math.floor(msec / 1000 / 60);
    msec -= mm * 1000 * 60;
    const ss = Math.floor(msec / 1000);
    msec -= ss * 1000;
    return hh + ":" + mm + ":" + ss;
  }
  return "";
};

module.exports = router;
