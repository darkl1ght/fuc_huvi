const router = require("express").Router();
const axios = require("axios");
const auth = require("../auth");
const { procore: procoreConfig } = require("../../config");
const logger = require("../../common/logger");
const mongoose = require("mongoose");
const Project = mongoose.model("Project");

router.post(
  "/procore/procoretokenexchange",
  auth.required,
  async (req, res, next) => {
    if (req.body.code && req.body.code_verifier) {
      const redirectUri = `${procoreConfig.redirect_uri}?goback=${req.body.redirect_uri}`; //Should be the same as that used while getting auth code
      const payload = {
        grant_type: "authorization_code",
        client_id: procoreConfig.client_id,
        client_secret: procoreConfig.client_secret,
        code: req.body.code,
        code_verifier: req.body.code_verifier,
        redirect_uri: redirectUri,
      };

      await axios
        .post(procoreConfig.token_endpoint, payload)
        .then(async (response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in procore token exchange: " + JSON.stringify(error)
          );
          res.sendStatus(403);
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.post(
  "/procore/refreshprocoretoken",
  auth.required,
  async (req, res, next) => {
    if (req.body.access_token && req.body.refresh_token) {
      const payload = {
        grant_type: "refresh_token",
        client_id: procoreConfig.client_id,
        client_secret: procoreConfig.client_secret,
        refresh_token: req.body.refresh_token,
      };
      await axios
        .post(procoreConfig.token_endpoint, payload)
        .then(async (response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in procore token refresh: " + JSON.stringify(error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(500);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/getprocorecompanies",
  auth.required,
  async (req, res, next) => {
    if (req.headers["procore-token"]) {
      const token = `Bearer ${req.headers["procore-token"]}`;

      await axios
        .get(
          procoreConfig.endpoint_base +
            "/companies?include_free_companies=true",
          {
            //TBD: change to false; &page=1&per_page=5
            headers: {
              Authorization: token,
            },
          }
        )
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/observationtype/getcompanyobservationtypes",
  auth.required,
  async (req, res, next) => {
    if (req.headers["procore-token"] && req.params.company_id) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/companies/${req.params.company_id}/observation_types`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching procore company observation types: " +
              JSON.stringify(error.response.data.error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/:project_id/getprojectlocations",
  auth.required,
  async (req, res, next) => {
    if (
      req.headers["procore-token"] &&
      req.params.company_id &&
      req.params.project_id
    ) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/projects/${req.params.project_id}/locations`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching procore project locations: " +
              JSON.stringify(error.response.data.error)
          );

          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else if (error.response.status === 403) {
            res.status(403).json({ status: "Error", statusCode: 403 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/:project_id/getprocoreprojectusers",
  auth.required,
  async (req, res, next) => {
    if (
      req.headers["procore-token"] &&
      req.params.company_id &&
      req.params.project_id
    ) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/projects/${req.params.project_id}/users`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching procore project users: " +
              JSON.stringify(error.response.data.error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else if (error.response.status === 403) {
            res.status(403).json({ status: "Error", statusCode: 403 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/getcontributingconditions",
  auth.required,
  async (req, res, next) => {
    if (req.headers["procore-token"] && req.params.company_id) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/companies/${req.params.company_id}/contributing_conditions`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching contributing conditions: " +
              JSON.stringify(error.response.data.error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/getcontributingbehaviors",
  auth.required,
  async (req, res, next) => {
    if (req.headers["procore-token"] && req.params.company_id) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/companies/${req.params.company_id}/contributing_behaviors`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching procore contributing behaviors: " +
              JSON.stringify(error.response.data.error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/gethazards",
  auth.required,
  async (req, res, next) => {
    if (req.headers["procore-token"] && req.params.company_id) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/companies/${req.params.company_id}/hazards`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching procore hazards: " +
              JSON.stringify(error.response.data.error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/gettrades",
  auth.required,
  async (req, res, next) => {
    if (req.headers["procore-token"] && req.params.company_id) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/companies/${req.params.company_id}/trades`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching procore trades: " +
              JSON.stringify(error.response.data.error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/:project_id/getspecsections",
  auth.required,
  async (req, res, next) => {
    if (
      req.headers["procore-token"] &&
      req.params.company_id &&
      req.params.project_id
    ) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/specification_sections?project_id=${req.params.project_id}`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching procore spec sections: " +
              JSON.stringify(error.response.data.error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:company_id/getprojects",
  auth.required,
  async (req, res, next) => {
    if (req.headers["procore-token"] && req.params.company_id) {
      const token = `Bearer ${req.headers["procore-token"]}`;
      const endpoint = `${procoreConfig.endpoint_base}/companies/${req.params.company_id}/projects`;

      await axios
        .get(endpoint, {
          headers: {
            Authorization: token,
            "Procore-Company-Id": req.params.company_id,
          },
        })
        .then((response) => {
          res.json(response.data);
        })
        .catch((error) => {
          logger.error(
            "Error in fetching projects: " +
              JSON.stringify(error.response.data.error)
          );
          if (error.response.status === 401) {
            //Not to do any mix up with any future constra refresh token logic
            res.status(403).json({ status: "Error", statusCode: 401 });
          } else {
            res.sendStatus(error.response.status);
          }
        });
    } else {
      res.sendStatus(400);
    }
  }
);

router.get(
  "/procore/:projectId/getlinkedproject",
  auth.required,
  async (req, res, next) => {
    await Project.findOne(
      {
        projectId: req.params.projectId,
      },
      {
        _id: 0,
        procoreIntegration: 1,
      }
    )
      .then((data) => {
        res.json(data);
      })
      .catch((error) => {
        logger.error(
          "Error in fetching linked project: " + JSON.stringify(error)
        );
        res.sendStatus(500);
      });
  }
);

router.post(
  "/procore/:projectId/linkproject",
  auth.required,
  async (req, res, next) => {
    if (req.body.linkedProject) {
      if (req.payload.isAdmin) {
        //Check if current project is already linked
        await Project.findOne(
          {
            projectId: req.params.projectId,
          },
          {
            procoreIntegration: 1,
          }
        )
          .then(async (data) => {
            if (data.procoreIntegration?.projectId) {
              res.status(400).json({ error: "Project already linked" });
            } else {
              //Check if the procore project is linked to any Constra project
              await Project.findOne({
                "procoreIntegration.projectId":
                  req.body.linkedProject.projectId,
              })
                .then(async (data) => {
                  if (data) {
                    res.status(400).send({
                      status: "Error",
                      code: 10000,
                    });
                  } else {
                    await Project.findOneAndUpdate(
                      {
                        projectId: req.params.projectId,
                      },
                      {
                        $set: {
                          procoreIntegration: {
                            ...req.body.linkedProject,
                            createdBy: req.payload.email,
                          },
                        },
                      }
                    )
                      .then(() => {
                        res.status(201).send({ status: "Success" });
                      })
                      .catch((error) => {
                        logger.error(
                          "Error in updating linked project: " +
                            JSON.stringify(error)
                        );
                        res.sendStatus(500);
                      });
                  }
                })
                .catch((error) => {
                  logger.error(
                    "Error in updating linked project: " + JSON.stringify(error)
                  );
                  res.sendStatus(500);
                });
            }
          })
          .catch((error) => {
            logger.error(
              "Error in fetching linked project: " + JSON.stringify(error)
            );
            res.sendStatus(500);
          });
      } else {
        res.sendStatus(403);
      }
    } else {
      res.sendStatus(400);
    }
  }
);

module.exports = router;
