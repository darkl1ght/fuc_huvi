const router = require("express").Router();
const mongoose = require("mongoose");
const InspectionCheckList = mongoose.model("InspectionCheckList");
const Rfi = mongoose.model("Rfi");
const Project = mongoose.model("Project");
const auth = require("../auth");
const uuid = require("uuid");
const _ = require("underscore");
const asyncPackage = require("async");
const logger = require("../../common/logger");
const moment = require("moment-timezone");
const Util = require("../../common/util");
const { Constants } = require("../../config/constants");
const { getAccessMapping } = require("../../common/accesscontrol.helper");
const path = require("path");
const { saveForDownloadReport } = require("../../common/wir-report");
const fs = require("fs");
// const he = require("he");

// Preload project objects on routes with ':project'
router.param("project", (req, res, next, projectId) => {
  Project.findOne({
    projectId: projectId,
  })
    .then((project) => {
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
      return next();
    })
    .catch(next);
});

router.param("rfi", (req, res, next, rfiId) => {
  Rfi.findOne({
    rfiId: rfiId,
  })
    .then((rfi) => {
      if (!rfi) {
        return res.sendStatus(404);
      }
      req.rfi = rfi;
      return next();
    })
    .catch(next);
});

router.get("/:project/", auth.required, async (req, res, next) => {
  const email = req.payload.email;

  if (email) {
    const objectKey = Constants.accessObjectKeys.WIR_ACCESS_ALL_WIRS;
    const projectId = req.params.project;
    let role = "";

    if (req.payload.isAdmin) {
      await Rfi.find({
        projectId,
        isActive: true,
      })
        .then((data) => {
          res.json({
            rfiData: data,
          });
        })
        .catch(next);
    } else {
      if (req.project.users?.length > 0) {
        role = req.project.users.find(
          (item) => item.email?.toLowerCase() == email
        )?.role?.code;

        if (role) {
          await getAccessMapping(role)
            .then(async (accessMapping) => {
              if (accessMapping) {
                const objectMapping = accessMapping.accessMapping.find(
                  (item) => item.objectKey == objectKey
                );

                if (objectMapping) {
                  if (objectMapping.isAllowed) {
                    await Rfi.find({
                      projectId,
                      isActive: true,
                    })
                      .then((data) => {
                        res.json({
                          rfiData: data,
                        });
                      })
                      .catch(next);
                  } else {
                    await Rfi.find({
                      projectId,
                      isActive: true,
                      $or: [
                        { createdBy: email },
                        { "currentAssignee.email": email },
                        { "workFlow.approver": email },
                        { "watchList.email": email },
                      ],
                    })
                      .then((data) => {
                        res.json({
                          rfiData: data,
                        });
                      })
                      .catch(next);
                  }
                } else {
                  res.sendStatus(403);
                }
              } else {
                res.sendStatus(403);
              }
            })
            .catch(() => {
              res.sendStatus(403);
            });
        } else {
          res.sendStatus(403);
        }
      } else {
        res.sendStatus(403);
      }
    }
  } else {
    res.sendStatus(403);
  }
});

router.get("/:project/rfino/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Rfi.countDocuments(
      {
        projectId: req.params.project,
      },
      async (err, count) => {
        res.json({
          count: count + 1,
        });
      }
    ).catch((err) => {
      logger.error(
        "Error in RFI.countDocuments in checkAccess method. Error: " +
          JSON.stringify(err)
      );
    });
  } else {
    res.sendStatus(403);
  }
});

router.post("/:project/", auth.required, async (req, res, next) => {
  if (req.payload.email) {
    await Rfi.countDocuments(
      {
        projectId: req.params.project,
        rfiNo: req.body.rfi.rfiNo,
      },
      async (err, count) => {
        if (count == 0) {
          const rfiData = new Rfi(req.body.rfi);

          let checkList = [];
          await InspectionCheckList.findOne({
            projectId: req.params.project,
            "activities.wbsId": rfiData.wbsId,
          })
            .then((data) => {
              checkList = data?.questionnaire == null ? [] : data.questionnaire;
            })
            .catch(next);
          rfiData.rfiId = uuid.v4();
          rfiData.createdBy = req.payload.email;
          rfiData.updatedBy = req.payload.email;
          rfiData.checkList = checkList;
          rfiData.isActive = true;
          rfiData.history = [
            {
              status: "Created",
              createdAt: moment.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
              comments: "",
              name: req.payload.email,
            },
          ];
          if (req.body.rfi.rfiType == "New") {
            rfiData.status = { key: "RFI10001", value: "New" };
            rfiData.currentAssignee = {
              type: "Owner",
              email: req.payload.email,
            };
          } else {
            rfiData.status = { key: "RFI10002", value: "Pending" };
            let assignee = rfiData.workFlow.find((item) => item.orderNo == 0);
            rfiData.currentAssignee = {
              type: assignee.name,
              email: assignee.approver,
            };
            rfiData.history.push({
              status: "Sent for Review",
              createdAt: moment.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
              comments: rfiData.additionalComments,
              name: req.payload.email,
            });
          }
          // const lessThan = he.decode('foo&ampbar'); //unescape(rfiData.discussion);
          // rfiData.discussion = he.decode(rfiData.discussion);

          await rfiData
            .save()
            .then(async (rfiData) => {
              if (rfiData?.status?.key == "RFI10002") {
                const promises = [];
                let assigneeName = req.project.users.find(
                  (item) => item.email == rfiData?.currentAssignee?.email
                );
                rfiData.currentAssignee.firstName = assigneeName?.firstName;
                rfiData.currentAssignee.lastName = assigneeName?.lastName;
                promises.push(
                  new Promise(async (resolve, reject) => {
                    await Util.sendRFIAssigneeEmail(rfiData.currentAssignee, {
                      rfi: rfiData,
                      projectName: req.project.projectName,
                    }).then((data) => {
                      if (data[0]) {
                        Logger.error(
                          "Error while sending mail in sendAsigneeEmail in rfi.js Route " +
                            data[0]
                        );
                        reject(data[0]);
                      } else {
                        resolve(data[1]);
                      }
                    });
                  })
                );

                if (rfiData?.watchList?.length != 0) {
                  let mailFrom = req.project.users.find(
                    (item) => item.email == rfiData?.createdBy
                  );

                  promises.push(
                    new Promise(async (resolve, reject) => {
                      await Util.sendRFIWatchListEmail(
                        rfiData.watchList,
                        mailFrom,
                        {
                          rfi: rfiData,
                          projectName: req.project.projectName,
                        }
                      ).then((data) => {
                        if (data[0]) {
                          Logger.error(
                            "Error while sending mail in sendwatchlistEmail in rfi.js Route " +
                              data[0]
                          );
                          reject(data[0]);
                        } else {
                          resolve(data[1]);
                        }
                      });
                    })
                  );
                }
              }
            })
            .then(() => {
              res.json({
                status: "success",
              });
            })
            .catch(next);
        } else {
          res.status(401).send({
            status: "isExist",
          });
        }
      }
    ).catch(next);
  } else {
    res.sendStatus(403);
  }
});

router.put("/:project/:rfiId", auth.required, async (req, res, next) => {
  const rfi = req.body.rfi;
  await Rfi.countDocuments(
    {
      projectId: req.params.project,
      rfiId: req.params.rfiId,
    },
    async (err, count) => {
      if (count > 0) {
        let updatedData = {};
        let existingData = {};
        let workFlow = [];
        await Rfi.findOne({
          projectId: req.params.project,
          rfiId: req.params.rfiId,
        })
          .then((data) => {
            existingData = data;
            workFlow = existingData.workFlow;
          })
          .catch(next);
        updatedData = {
          inspectionDate: rfi.inspectionDate,
          inspectionTime: rfi.inspectionTime,
          sectionOfSpecification: rfi.sectionOfSpecification,
          drawingNumber: rfi.drawingNumber,
          watchList: rfi.watchList,
          descriptionOfInspectionRequested:
            rfi.descriptionOfInspectionRequested,
          sitePhotos: rfi.sitePhotos,
          discussion: rfi.discussion,
        };
        if (existingData.createdBy != req.payload.email) {
          updatedData.checkList = rfi.checkList;
        }
        if (
          existingData.createdBy == req.payload.email &&
          existingData.status?.key == "RFI10001"
        ) {
          workFlow = rfi.workFlow;
          updatedData.workFlow = rfi.workFlow;
        }
        let history = {};
        isHistory = false;
        if (rfi.rfiType == "Send For Review") {
          isHistory = true;
          updatedData.status = { key: "RFI10002", value: "Pending" };
          let assignee = workFlow.find((item) => item.orderNo == 0);
          updatedData.currentAssignee = {
            type: assignee.name,
            email: assignee.approver,
          };
          history = {
            status: "Sent for Review",
            createdAt: moment.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
            comments: rfi.additionalComments,
            name: req.payload.email,
          };
        }
        let toBeUpdated = {};
        if (isHistory) {
          toBeUpdated = {
            $push: { history: history },
            $set: updatedData,
          };
        } else {
          toBeUpdated = {
            $set: updatedData,
          };
        }
        await Rfi.findOneAndUpdate(
          {
            projectId: req.params.project,
            rfiId: req.params.rfiId,
          },
          toBeUpdated
        )
          .then((data) => {
            if (rfi.rfiType == "Send For Review") {
              const rfiData = existingData;
              rfiData.watchList = rfi.watchList;
              const promises = [];
              let assignee = workFlow.find((item) => item.orderNo == 0);
              let assigneeName = req.project.users.find(
                (item) => item.email == assignee?.approver
              );
              rfiData.currentAssignee.email = assignee?.approver;
              rfiData.currentAssignee.firstName = assigneeName?.firstName;
              rfiData.currentAssignee.lastName = assigneeName?.lastName;
              promises.push(
                new Promise(async (resolve, reject) => {
                  await Util.sendRFIAssigneeEmail(rfiData.currentAssignee, {
                    rfi: rfiData,
                    projectName: req.project.projectName,
                  }).then((data) => {
                    if (data[0]) {
                      Logger.error(
                        "Error while sending mail in sendAsigneeEmail in rfi.js Route " +
                          data[0]
                      );
                      reject(data[0]);
                    } else {
                      resolve(data[1]);
                    }
                  });
                })
              );

              if (rfiData?.watchList?.length != 0) {
                let mailFrom = req.project.users.find(
                  (item) => item.email == rfiData?.createdBy
                );

                promises.push(
                  new Promise(async (resolve, reject) => {
                    await Util.sendRFIWatchListEmail(
                      rfiData.watchList,
                      mailFrom,
                      {
                        rfi: rfiData,
                        projectName: req.project.projectName,
                      }
                    ).then((data) => {
                      if (data[0]) {
                        Logger.error(
                          "Error while sending mail in sendwatchlistEmail in rfi.js Route " +
                            data[0]
                        );
                        reject(data[0]);
                      } else {
                        resolve(data[1]);
                      }
                    });
                  })
                );
              }
            }
            res.json({ status: "success" });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    }
  );
});
router.put("/:project/:rfiId/:type", auth.required, async (req, res, next) => {
  const rfi = req.body.rfi;
  await Rfi.countDocuments(
    {
      projectId: req.params.project,
      rfiId: req.params.rfiId,
    },
    async (err, count) => {
      if (count > 0) {
        let existingData = {};
        await Rfi.findOne({
          projectId: req.params.project,
          rfiId: req.params.rfiId,
        })
          .then((data) => {
            existingData = data;
          })
          .catch(next);
        let approvalLevel = rfi.workFlow.find(
          (item) => item.approver == req.payload.email
        );
        const idIndex = rfi.workFlow.findIndex(
          (item) => item.approver === req.payload.email
        );
        const isLastItem = idIndex === rfi.workFlow.length - 1;

        let history = {};

        let currentAssignee = {};
        let toBeUpdated = {};
        if (req.params.type == "approve") {
          history = {
            status: "Approved",
            createdAt: moment.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
            comments: rfi.rfiReviewerApprovalComments,
            name: req.payload.email,
          };
          if (isLastItem) {
            currentAssignee = {
              type: approvalLevel.name,
              email: approvalLevel.approver,
            };
            toBeUpdated.status = { key: "RFI10003", value: "Approved" };
          } else {
            let assignee = rfi.workFlow.find(
              (item) => item.orderNo == approvalLevel.orderNo + 1
            );
            currentAssignee = {
              type: assignee.name,
              email: assignee.approver,
            };
          }
        } else {
          history = {
            status: "Rejected",
            createdAt: moment.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
            comments: rfi.rfiReviewerApprovalComments,
            name: req.payload.email,
          };
          currentAssignee = {
            type: "Owner",
            email: rfi.rfiCreatedBy,
          };
        }

        toBeUpdated.checkList = rfi.checkList;
        toBeUpdated.sitePhotos = rfi.sitePhotos;
        toBeUpdated.currentAssignee = currentAssignee;
        toBeUpdated.workFlow = rfi.workFlow;
        toBeUpdated.discussion = rfi.discussion;
        toBeUpdated.sectionOfSpecification = rfi.sectionOfSpecification;
        toBeUpdated.drawingNumber = rfi.drawingNumber;
        toBeUpdated.descriptionOfInspectionRequested =
          rfi.descriptionOfInspectionRequested;
        toBeUpdated.inspectionDate = rfi.inspectionDate;
        toBeUpdated.inspectionTime = rfi.inspectionTime;
        toBeUpdated.updatedBy = req.payload.email;

        await Rfi.findOneAndUpdate(
          {
            projectId: req.params.project,
            rfiId: req.params.rfiId,
          },
          {
            $push: { history: history },
            $set: toBeUpdated,
          }
        )
          .then(() => {
            let toMail = {};
            let mailContent = "";
            if (req.params.type == "approve") {
              if (isLastItem) {
                let assigneeName = req.project.users.find(
                  (item) => item.email == existingData?.createdBy
                );
                toMail.email = existingData?.createdBy;
                toMail.firstName = assigneeName?.firstName;
                toMail.lastName = assigneeName?.lastName;
                mailContent = "WIR has been approved.";
                existingData.status = { key: "RFI10003", value: "Approved" };
              } else {
                let assigneeName = req.project.users.find(
                  (item) => item.email == currentAssignee?.email
                );
                toMail.email = currentAssignee?.email;
                toMail.firstName = assigneeName?.firstName;
                toMail.lastName = assigneeName?.lastName;
                mailContent = "WIR has been updated & assigned to you.";
              }
            } else {
              let assigneeName = req.project.users.find(
                (item) => item.email == existingData?.createdBy
              );
              toMail.email = existingData?.createdBy;
              toMail.firstName = assigneeName?.firstName;
              toMail.lastName = assigneeName?.lastName;
              mailContent = "WIR has been rejected & assigned to you.";
            }
            const promises = [];
            existingData.inspectionDate = rfi.inspectionDate;
            existingData.inspectionTime = rfi.inspectionTime;
            promises.push(
              new Promise(async (resolve, reject) => {
                await Util.sendRFIApproveAndRejectEmail(toMail, {
                  rfi: existingData,
                  projectName: req.project.projectName,
                  mailContent,
                }).then((data) => {
                  if (data[0]) {
                    Logger.error(
                      "Error while sending mail in sendApproveAndRejectEmail in rfi.js Route " +
                        data[0]
                    );
                    reject(data[0]);
                  } else {
                    resolve(data[1]);
                  }
                });
              })
            );
            res.json({ status: "success" });
          })
          .catch(next);
      } else {
        res.sendStatus(401);
      }
    }
  );
});

router.delete("/:project/:rfiId", auth.required, async (req, res, next) => {
  await Rfi.findOneAndUpdate(
    {
      projectId: req.params.project,
      rfiId: req.params.rfiId,
    },
    {
      $set: {
        isActive: false,
      },
    }
  )
    .then(() => {
      res.json({
        status: "success",
      });
    })
    .catch(next);
});
/*updated Assessment image */
router.put(
  "/:project/:rfiId/assessment/:questionId",
  auth.required,
  async (req, res, next) => {
    const rfi = req.body.rfi;
    await Rfi.findOne({
      projectId: req.params.project,
      rfiId: req.params.rfiId,
    }).then(async (matchedRfiData) => {
      if (matchedRfiData) {
        const rfiData = new Rfi(matchedRfiData);
        for (let dat of rfiData.checkList) {
          if (dat.questionId == req.params.questionId) {
            let oldImages = dat.images == undefined ? [] : dat.images;
            dat.images = [...oldImages, ...rfi.images];
          }
        }
        rfiData.updatedBy = req.payload.email;
        await rfiData.save().then((data) => {
          res.json({
            status: "success",
            rfiData: data,
          });
        });
      } else {
        res.sendStatus(401);
      }
    });
  }
);
/* delete rfi Image  */

router.delete(
  "/:project/:rfiId/assessment/:questionId/:imageId",
  auth.required,
  async (req, res, next) => {
    await Rfi.findOne({
      projectId: req.params.project,
      rfiId: req.params.rfiId,
    }).then(async (matchedRfiData) => {
      if (matchedRfiData) {
        const rfiData = new Rfi(matchedRfiData);
        for (let dat of rfiData.checkList) {
          if (dat.questionId == req.params.questionId) {
            dat.images = dat.images.filter(
              (item) => item.blobContentId != req.params.imageId
            );
          }
        }
        rfiData.updatedBy = req.payload.email;

        await rfiData.save().then((data) => {
          res.json({
            status: "success",
            rfiData: data,
          });
        });
      } else {
        res.sendStatus(401);
      }
    });
    // await Rfi.findOneAndUpdate(
    //   {
    //     projectId: req.params.project,
    //     rfiId: req.params.rfiId,
    //   },
    //   {
    //     $set: {
    //       isActive: false,
    //     },
    //   }
    // )
    //   .then(() => {
    //     res.json({
    //       status: "success",
    //     });
    //   })
    //   .catch(next);
  }
);

router.get(
  "/:project/downloadpdfreport/:rfi",
  auth.required,
  async (req, res, next) => {
    if (req.payload.email) {
      if (req.project) {
        const rootDir = path.dirname(path.dirname(__dirname));
        const savePath = path.join(
          rootDir,
          "temp_report",
          req.rfi.rfiId + ".pdf"
        );

        await saveForDownloadReport(
          req.rfi,
          req.project.projectName,
          req.project.location,
          req.payload.firstName + " " + req.payload.lastName,
          savePath
        );
        await Util.wait(1000);

        var data = fs.readFileSync(savePath);

        res.setHeader("Content-Type", "text/plain");
        res.send(data.toString("base64"));

        fs.unlink(savePath, (_err) => {});
      } else {
        res.sendStatus(401);
      }
    } else {
      res.sendStatus(403);
    }
  }
);

router.post(
  "/:project/:rfiId/:questionId/:blobContentId/savemarkerannotation",
  auth.required,
  async (req, res, next) => {
    const maState = req.body.maState;
    await Rfi.findOne({
      projectId: req.params.project,
      rfiId: req.params.rfiId,
    }).then(async (matchedRfiData) => {
      if (matchedRfiData) {
        const rfiData = new Rfi(matchedRfiData);
        let checkList = rfiData.checkList.find(
          (item) => item.questionId == req.params.questionId
        );
        for (let dat of checkList.images) {
          if (dat.blobContentId == req.params.blobContentId) {
            dat.maState = maState;
          }
        }
        rfiData.updatedBy = req.payload.email;
        await rfiData.save().then((data) => {
          res.json({
            status: "success",
            rfiData: data,
          });
        });
      } else {
        res.sendStatus(401);
      }
    });
  }
);
module.exports = router;
