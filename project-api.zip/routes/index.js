"use strict";

const router = require("express").Router();
const auth = require("./auth");
const mongoose = require("mongoose");
const UserRequest = mongoose.model("UserRequest");
const LookUp = mongoose.model("LookUp");

router.use("/api/**", auth.required, async (req, res, next) => {
  const apiClient = {
    url: req.baseUrl,
    ip: req.ip,
    time: new Date(),
    host: req.hostname,
    method: req.method,
    email: req.payload.email,
  };
  const userReq = new UserRequest(apiClient);
  await userReq
    .save()
    .then(() => {
      next();
    })
    .catch(() => {
      res.status(500).json({
        msg: "unable to log user request",
      });
    });
});

router.use("/api", require("./api"));
router.get("/health", async (req, res, next) => {
  try {
    await LookUp.find()
      .countDocuments((err, _) => {
        if (err) {
          return res.sendStatus(500).json({
            status: "Unhealthy",
            error: JSON.stringify(err),
            uptime: process.uptime(),
            date: new Date(),
          });
        }

        return res.json({
          status: "Healthy",
          error: null,
          uptime: process.uptime(),
          date: new Date(),
        });
      })
      .catch(next);
  } catch (err) {
    res.sendStatus(500).json({
      status: "Unhealthy",
      error: "Catch Err: " + JSON.stringify(err),
      uptime: process.uptime(),
      date: new Date(),
    });
  }
});

module.exports = router;
