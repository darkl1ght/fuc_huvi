"use strict";

const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const InteriorTour = mongoose.model("InteriorTour");
const TourImage = mongoose.model("TourImage");

const virtualTourMiddleware = async (req, res, next) => {
  try {
    if (req.payload.email) {
      let count = await Project.countDocuments({
        users: {
          $elemMatch: {
            email: req.payload.email,
          },
        },
        projectId: req.params.project,
      });

      if (count === 0 && !req.payload.isAdmin) {
        return res.sendStatus(404);
      }
    }

    if (req.params.project) {
      let project = await Project.findOne({ projectId: req.params.project });
      if (!project) {
        return res.sendStatus(404);
      }
      req.project = project;
    }

    if (req.params.interior) {
      let interior = await InteriorTour.findOne({
        interiorId: req.params.interior,
      });

      if (!interior) {
        return res.sendStatus(404);
      }
      req.interior = interior;
    }

    if (req.params.tour) {
      let tour = await TourImage.findOne({ tourId: req.params.tour });

      if (!tour) {
        return res.sendStatus(404);
      }
      req.tour = tour;
    }
  } catch (error) {
    next();
  }

  next();
};

module.exports = { virtualTourMiddleware };
