const firebase = require("firebase-admin");
const logger = require("../common/logger");
const NotificationMessage = require("../models/Notification");
const NotificationMasterData = require("../models/NotificationMasterData");
const ERROR_MESSAGING = "messaging/registration-token-not-registered";

const notificationMiddleWare = async (req, res, next) => {
  if (!req.notificationData) return;

  let notificationData = req.notificationData;

  await invokeFireBaseAndSaveNotification(notificationData);

  /* On Success return, so that the express life-cycle ends here */
  return;
};

const invokeFireBaseAndSaveNotification = async (notificationData) => {
  try {
    response = await firebase
      .messaging()
      .sendMulticast(notificationData.message);

    /*
  Log notifications
  */
    let notifications = [];
    const failedTokens = [];
    response.responses.forEach((resp, index) => {
      let notification = new NotificationMessage();

      if (response.failureCount > 0) {
        if (!resp.success && ERROR_MESSAGING === resp.error.code) {
          failedTokens.push(notificationData.message.tokens[index]);
        }
      }

      // Populate schema
      notification.messageStatus = response.success;
      notification.token = notificationData.message.tokens[index];
      notification.messageId = response.messageId;
      notification.title = notificationData.message.data.title;
      notification.body = notificationData.message.data.body;
      notifications.push(notification);
    });

    if (failedTokens.length > 0) {
      await NotificationMasterData.updateMany(
        {
          "tokens.token": { $in: failedTokens },
        },
        { $set: { "tokens.$.disabled": true } }
      ).catch((reason) =>
        logger.error(`Error in disabling notification token  ${reason}`)
      );
    }

    await NotificationMessage.insertMany(notifications).catch((reason) =>
      logger.error(
        `Error in inserting notification log to the database ${reason}`
      )
    );
  } catch (error) {
    logger.error(
      `Error in sending notification to firebase ${JSON.stringify(error)}`
    );
  }
};

module.exports = {
  notificationMiddleWare,
  invokeFireBaseAndSaveNotification,
};
