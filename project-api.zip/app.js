"use strict";

const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const cors = require("cors");
const errorhandler = require("errorhandler");
const mongoose = require("mongoose");
const fileUpload = require("express-fileupload");
const morgan = require("morgan");
const requestIP = require("request-ip");
require("dotenv").config();
const initializeFirebaseSDK = require("./config/firebase.config");

const logger = require("./common/logger");

const isProduction = process.env.NODE_ENV === "production";

// Create global app object
const app = express();

app.use(cors());

// Initalize firebase SDK
initializeFirebaseSDK();

morgan.token("x-forward-for", (req) => {
  return requestIP.getClientIp(req);
});

// Normal express config defaults
app.use(
  morgan(":x-forward-for - :method :url HTTP/:http-version :status", {
    stream: logger.stream,
  })
);
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json({ limit: "50mb" }));
app.use(
  fileUpload({
    useTempFiles: true,
    limits: {
      fileSize: 10 * 1024 * 1024 * 1024,
    },
  })
);
app.use(require("method-override")());
app.use(express.static(__dirname + "/public"));

app.use(
  session({
    secret: "conduit",
    cookie: {
      maxAge: 60000,
    },
    resave: false,
    saveUninitialized: false,
  })
);

if (!isProduction) {
  app.use(errorhandler());
}

const mongooseOptions = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
};

if (isProduction) {
  mongoose.connect(process.env.MONGODB_URI, mongooseOptions);
} else {
  mongoose.connect(
    "mongodb+srv://huviair_dev:eiIjYR1dXhetzyWu@cluster0.emp41.mongodb.net/project?retryWrites=true&w=majority",
    mongooseOptions
  );
  mongoose.set("debug", true);
}

require("./models/LookUp");
require("./models/Project");
require("./models/ProjectUser");
require("./models/Document");
require("./models/Device");
require("./models/InteriorTour");
require("./models/TourImage");
require("./models/InteriorImage");
require("./models/ProjectChart");
require("./models/ExteriorTour");
require("./models/ProjectMedia");
require("./models/ProjectTask");
require("./models/ProjectAlbum");
require("./models/MediaAnnotation");
require("./models/AerialTour");
require("./models/AerialImage");
require("./models/WorkPackage");
require("./models/MasterData");
require("./models/WorkLocation");
require("./models/VideoProcessingQueue");
require("./models/ProcessingStatistic");
require("./models/ProcessingParam");
require("./models/UserRequest");
require("./models/Client");
require("./models/AccessMapping");
require("./models/ProjectUsersRoleMigration");
require("./models/EmailTemplate");
require("./models/MapVolume");
require("./models/MapElevationProfile");
require("./models/ExteriorWBS");
require("./models/InteriorWBS");
require("./models/ExteriorChart");
require("./models/InteriorChart");
require("./models/ExteriorCapture");
require("./models/InteriorCapture");
require("./models/WorkSchedule");
require("./models/DeepLink");
require("./models/FieldIssue");
require("./models/WorkFlow");
require("./models/Rfi");
require("./models/InspectionCheckList");
require("./models/RfiWorkFlow");
require("./models/AppMessage");
require("./models/CaptureAppLog");
require("./models/EmailNotification");
require("./models/Debug");
require("./models/DeletedTourFeature");
require("./models/OnsiteTask");

// Initialize jobs
require("./jobs/notification.job");
require("./jobs/contractNotification.job");
require("./jobs/punchListSummaryNotification.job.js");

app.use("/v1/project", require("./routes"));

// catch 404 and forward to error handler
app.use((req, res, next) => {
  const err = new Error("Not Found");
  err.status = 404;
  next(err);
});

//  error handlers

// development error handler
// will print stacktrace
if (!isProduction) {
  app.use((err, req, res, next) => {
    console.log(err.stack);

    res.status(err.status || 500);

    res.json({
      errors: {
        message: err.message,
        error: err,
      },
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use((err, req, res, next) => {
  res.status(err.status || 500);
  res.json({
    errors: {
      message: err.message,
      error: {},
    },
  });
});

// finally, let's start our server...
var server = app.listen(process.env.PORT || 4001, () => {
  console.log("Listening on port " + server.address().port);
});
