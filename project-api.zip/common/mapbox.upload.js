"use strict";

const axios = require("axios");
const { generateUUID } = require("./util");

const config = require("../config");
const {
  BASE_URL,
  UPLOADS_RESOURCE,
  TILEQUERY_RESOURCE,
  CREDENTIALS_PATH,
  UPLOAD_ID_PATH,
  UPLOAD_STATUS_PATH,
  MAPBOX_USERNAME,
  TILESET_DELETE_RESOURCE,
} = config.mapboxAPI;
const MAPBOX_ACCESS_TOKEN = config.mapboxAccessToken;
const MAPBOX_TILEQUERY_ACCESS_TOKEN = config.mapboxTilequeryAccessToken;
const MAPBOX_TILESET_DELETE_TOKEN = config.mapboxTilesetDeleteToken;

const logger = require("./logger");

module.exports = {
  async getUploadCredentials() {
    let data;
    const url = BASE_URL + UPLOADS_RESOURCE;
    const path = CREDENTIALS_PATH.replace("{username}", MAPBOX_USERNAME);
    const params = {
      access_token: MAPBOX_ACCESS_TOKEN,
    };
    await axios
      .post(url + path, null, {
        params,
      })
      .then((res) => {
        data = res.data;
      })
      .catch((error) => {
        logger.error(
          "Error in getUploadCredentials method. Error: " +
            JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
  async getUploadId(bucket_credentials) {
    let data;
    const url = BASE_URL + UPLOADS_RESOURCE;
    const path = UPLOAD_ID_PATH.replace("{username}", MAPBOX_USERNAME);
    const params = {
      access_token: MAPBOX_ACCESS_TOKEN,
    };
    const headers = {
      "Content-Type": "application/json",
      "Cache-Control": "no-cache",
    };
    const tileset_name = generateUUID();
    const payload = {
      url: `http://${bucket_credentials["bucket"]}.s3.amazonaws.com/${bucket_credentials["key"]}`,
      tileset: `${MAPBOX_USERNAME}.${tileset_name}`,
      name: tileset_name,
    };
    await axios
      .post(url + path, payload, {
        params,
        headers: headers,
      })
      .then((res) => {
        data = {
          uploadIdStatus: res.status,
          uploadIdResponse: res.data,
        };
      })
      .catch((error) => {
        logger.error(
          "Error in getUploadId method. Error: " + JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
  async getUploadStatus(upload_id) {
    let data;
    const url = BASE_URL + UPLOADS_RESOURCE;
    const path = UPLOAD_STATUS_PATH.replace(
      "{username}",
      MAPBOX_USERNAME
    ).replace("{upload_id}", upload_id);
    const params = {
      access_token: MAPBOX_ACCESS_TOKEN,
    };
    const headers = {
      "Content-Type": "application/json",
      "Cache-Control": "no-cache",
    };
    await axios
      .get(url + path, {
        headers: headers,
        params: params,
      })
      .then((res) => {
        data = {
          uploadStatusStatus: res.status,
          uploadStatusResponse: res.data,
        };
      })
      .catch((error) => {
        logger.error(
          "Error in getUploadStatus method. Error: " + JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
  async getTilequeryData(tilesetId, coord) {
    let data;
    const url = BASE_URL;
    const path = TILEQUERY_RESOURCE.replace("{tileset_id}", tilesetId)
      .replace("{lon}", coord[0])
      .replace("{lat}", coord[1]);
    const params = {
      access_token: MAPBOX_TILEQUERY_ACCESS_TOKEN,
      radius: 4000, //4000m
    };
    const headers = {
      "Content-Type": "application/json",
      "Cache-Control": "no-cache",
    };
    await axios
      .get(url + path, {
        headers: headers,
        params: params,
      })
      .then((res) => {
        data = res.data.features;
      })
      .catch((error) => {
        logger.error(
          "Error in getTilequeryData method. Error: " + JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
  async deleteTileset(tilesetId) {
    let data;
    const url = BASE_URL;
    const path = TILESET_DELETE_RESOURCE.replace(
      "{tileset_id}",
      tilesetId.split("//")[1]
    );
    const params = {
      access_token: MAPBOX_TILESET_DELETE_TOKEN,
    };
    const headers = {
      "Content-Type": "application/json",
      "Cache-Control": "no-cache",
    };
    await axios
      .delete(url + path, {
        headers: headers,
        params: params,
      })
      .then((res) => {
        data = {
          deleteStatus: res.status,
          deleteResponse: res.data,
        };
      })
      .catch((error) => {
        logger.error(
          "Error in deleteTileset method. Error: " + JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
};
