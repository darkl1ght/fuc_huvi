"use strict";
const fs = require("fs");
// const PDFDocument = require("pdfkit");
const PDFDocument = require("pdfkit-table");
const path = require("path");
const rootDir = path.dirname(__dirname);
const SendGridMail = require("@sendgrid/mail");
const fromEmail = require("../config").email.fromEmail;
const sendGridKey = require("../config").email.sendGridKey;
SendGridMail.setApiKey(sendGridKey);
const axios = require("axios");
const moment = require("moment-timezone");
const config = require("../config");
const {
  blobRawdataSMRef,
  blobContainerBaseUrl,
  blobMediaRef,
  blobDrawingRef,
  blobSignatureRef,
} = config.azureStorage.containers;
const getAzureSASToken = require("./azure.access.token");
const { createCanvas, Image } = require("canvas");
const logger = require("./logger");

const downloadReport = async (
  data,
  mailTo,
  subject,
  emailContent,
  projectName,
  projectLocation = "",
  generatedBy = "",
  signatureBlobContentId = null
) => {
  try {
    let doc = new PDFDocument({ size: "A4", margin: 50 });

    let buffers = [];
    doc.on("data", buffers.push.bind(buffers));
    doc.on("end", () => {
      let pdfData = Buffer.concat(buffers);
      sendReport(mailTo, subject, emailContent, pdfData);
    });

    // await doc.on("pageAdded", async () => {
    //   await generateHeader(doc, projectName);
    //   await generateFooter(doc, generatedBy, signatureBlobContentId);
    // });

    await generateHeader(doc, projectName);
    await generateFooter(doc, generatedBy, signatureBlobContentId);
    await generateSummary(
      doc,
      data,
      projectName,
      generatedBy,
      signatureBlobContentId
    );

    doc.end();
  } catch (err) {
    // throw err;
    logger.error(
      "Error in downloadReport method. Error: " + JSON.stringify(err)
    );
  }
  //doc.pipe(fs.createWriteStream(path));
};

const createReport = async (
  data,
  mailTo,
  subject,
  emailContent,
  projectName,
  projectLocation = "",
  generatedBy = ""
) => {
  try {
    let doc = new PDFDocument({ size: "A4", margin: 50 });
    let buffers = [];
    let emailContentTemp = emailContent.replace(
      "{description}",
      data.taskDescription
    );

    doc.on("data", buffers.push.bind(buffers));
    doc.on("end", () => {
      let pdfData = Buffer.concat(buffers);
      sendReport(mailTo, subject, emailContentTemp, pdfData);
    });

    // doc.on("pageAdded", async () => {
    //   await generateHeader(doc, projectName);
    //   await generateFooter(doc, generatedBy);
    // });

    await generateHeader(doc, projectName);
    await generateFooter(doc, generatedBy);
    await generateSummary(doc, data, projectName, generatedBy);

    doc.end();
  } catch (err) {
    logger.error("Error in createReport method. Error: " + JSON.stringify(err));
  }
  //doc.pipe(fs.createWriteStream(path));
};

const saveForDownloadReport = async (
  data,
  projectName,
  projectLocation,
  generatedBy,
  path
) => {
  try {
    const doc = new PDFDocument({ size: "A4", margin: 50 });
    doc.pipe(fs.createWriteStream(path));

    // doc.on("pageAdded", async () => {
    //   await generateHeader(doc, projectName);
    //   await generateFooter(doc, generatedBy);
    // });

    await generateHeader(doc, projectName);
    await generateFooter(doc, generatedBy);
    await generateSummary(doc, data, projectName, generatedBy);

    doc.end();
  } catch (err) {
    logger.error(
      "Error in saveForDownloadReport method. Error: " + JSON.stringify(err)
    );
  }
};

const generateHeader = async (doc, projectName) => {
  try {
    const imagePath = path.join(rootDir, "images");
    const logo = path.join(imagePath, "logo_constra.png");

    doc
      .image(logo, 50, 30, {
        width: 200,
      })
      .fillColor("#444444")
      .fontSize(10)
      .font("Helvetica-Bold")
      .text("Project Name :", 350, 30)
      .font("Helvetica")
      .text(projectName, 460, 30);

    generateHr(doc, 65);
  } catch (err) {
    logger.error(
      "Error in generateHeader method. Error: " + JSON.stringify(err)
    );
  }
};

const generateSummary = async (
  doc,
  snag,
  projectName,
  generatedBy,
  signatureBlobContentId = null
) => {
  try {
    doc.fillColor("#444444").fontSize(16).text("Punch Item Summary", 50, 100);
    generateHrTble(doc, 120);
    const customerInformationTop = 135;

    doc
      .fontSize(10)
      .font("Helvetica-Bold")
      .text("Punch Item Id:", 50, customerInformationTop)
      .font("Helvetica")
      .text(snag.punchId, 200, customerInformationTop)
      .fontSize(12)
      .font("Helvetica-Bold")
      .text("Punch Item Type:", 50, customerInformationTop + 35)
      .font("Helvetica")
      .text(
        snag.isNonConformity
          ? snag.punchListId === "OB"
            ? "Observation"
            : "Non Conformity"
          : "Conformity",
        200,
        customerInformationTop + 35
      )
      .font("Helvetica-Bold")
      .text("Description:", 50, customerInformationTop + 70)
      .font("Helvetica")
      .text(snag.taskDescription, 200, customerInformationTop + 70)
      .font("Helvetica-Bold")
      .text("Work Trade:", 50, customerInformationTop + 110)
      .font("Helvetica")
      .text(snag.workPackage.tradeName, 200, customerInformationTop + 110)
      .font("Helvetica-Bold")
      .text("Work Location:", 50, customerInformationTop + 145)
      .font("Helvetica")
      .text(
        snag.workLocation.level1 +
          (snag.workLocation.level2 ? " - " + snag.workLocation.level2 : "") +
          (snag.workLocation.level3 ? " - " + snag.workLocation.level3 : "") +
          (snag.workLocation.level4 ? " - " + snag.workLocation.level4 : ""),
        200,
        customerInformationTop + 145
      )
      .font("Helvetica-Bold")
      .text("Overall Status:", 50, customerInformationTop + 180)
      .font("Helvetica")
      .text(snag.taskStatus.desc, 200, customerInformationTop + 180)
      .font("Helvetica-Bold")
      .text("Work Priority:", 50, customerInformationTop + 215)
      .font("Helvetica")
      .text(snag.taskPriority.desc, 200, customerInformationTop + 215)
      .font("Helvetica-Bold")
      .text("Created Date:", 50, customerInformationTop + 250)
      .font("Helvetica")
      .text(
        moment(snag.createdAt).tz("Asia/Kolkata").format("DD MMM, YYYY"),
        200,
        customerInformationTop + 250
      )
      .font("Helvetica-Bold")
      .text("Due Date:", 50, customerInformationTop + 285)
      .font("Helvetica")
      .text(
        moment(snag.dueDate).tz("Asia/Kolkata").format("DD MMM, YYYY"),
        200,
        customerInformationTop + 285
      )
      .font("Helvetica-Bold")
      .text("Level 1 Status:", 50, customerInformationTop + 320)
      .font("Helvetica")
      .text(snag.level1Status.status.desc, 200, customerInformationTop + 320)
      .font("Helvetica-Bold")
      .text("Level 2 Status:", 50, customerInformationTop + 355)
      .font("Helvetica")
      .text(snag.level2Status.status.desc, 200, customerInformationTop + 355)
      .font("Helvetica-Bold")
      .text("Level1 Assignee:", 50, customerInformationTop + 390)
      .font("Helvetica")
      .text(snag.level1Users.join(", "), 200, customerInformationTop + 390)
      .font("Helvetica-Bold")
      .text("Level2 Assignee:", 50, customerInformationTop + 425)
      .font("Helvetica")
      .text(snag.level2Users.join(", "), 200, customerInformationTop + 425)
      .font("Helvetica-Bold")
      .text("Remarks:", 50, customerInformationTop + 460);

    let snagRemark = snag.remark.split("\n");
    const pageHeight = doc.page.height;
    const footerHeight = 30;
    const lineSpacing = 15;
    let charLimitPerLine = 60;

    snagRemark.length > 0 &&
      snagRemark.forEach(async (remark) => {
        let words = remark.split(" ");

        while (words.length > 0) {
          let line = "";
          while (
            words.length > 0
            // && line.length + words[0].length < charLimitPerLine
          ) {
            let word = words[0];
            if (word.length > charLimitPerLine) {
              // handle very long word
              if (line.length == 0) {
                // if it's the first word in the line, split it
                line += word.slice(0, charLimitPerLine);
                words[0] = word.slice(charLimitPerLine);
              }
              break; // end this line
            } else if (line.length + word.length <= charLimitPerLine) {
              // handle normal word
              line += words.shift() + " ";
            } else {
              break; // end this line
            }
          }

          if (doc.y > pageHeight - footerHeight - 70) {
            await doc.addPage();
            await generateHeader(doc, projectName);
            await generateFooter(doc, generatedBy, signatureBlobContentId);
            doc.y = customerInformationTop - 30;
            doc
              .fontSize(12)
              .font("Helvetica-Bold")
              .text("Remarks (cont'd):", 50, doc.y - lineSpacing);
          }

          doc
            .fontSize(12)
            .font("Helvetica")
            .text(line, 200, doc.y - lineSpacing);

          doc.moveDown();
        }
      });

    await addFloorPlan(
      doc,
      snag,
      projectName,
      generatedBy,
      signatureBlobContentId
    );

    await addMediaList(
      doc,
      snag,
      projectName,
      generatedBy,
      signatureBlobContentId
    );

    await addLogs(doc, snag, projectName, generatedBy, signatureBlobContentId);
  } catch (err) {
    logger.error(
      "Error in generateSummary method. Error: " + JSON.stringify(err)
    );
  }
};

const generateFooter = async (
  doc,
  generatedBy,
  signatureBlobContentId = null
) => {
  try {
    generateHr(doc, 760);

    doc.fontSize(10).text("Generated By: " + generatedBy, 50, 780, {
      align: "left",
      width: 500,
    });

    if (signatureBlobContentId) {
      const token = await getAzureSASToken(blobSignatureRef);
      const url =
        blobContainerBaseUrl +
        blobSignatureRef +
        "/" +
        signatureBlobContentId +
        "?" +
        token;

      const result = await axios.get(url, {
        responseType: "arraybuffer",
      });

      const image = new Buffer.from(result.data, "base64");

      doc.image(image, 50, 800, {
        width: 70,
        height: 30,
      });
    }

    const currentdate = new Date();
    const datetime =
      "Generated At: " +
      moment(currentdate).tz("Asia/Kolkata").format("DD MMM, YYYY");

    doc.fontSize(10).text(datetime, 50, 780, {
      align: "right",
      width: 500,
    });
  } catch (err) {
    logger.error(
      "Error in generateFooter method. Error: " + JSON.stringify(err)
    );
  }
};

const addFloorPlan = async (
  doc,
  snag,
  projectName,
  generatedBy,
  signatureBlobContentId
) => {
  try {
    if (
      snag &&
      (snag.floorPlan.blobReference || snag.floorPlan.latestSnapshotBlobId)
    ) {
      await doc.addPage();
      await generateHeader(doc, projectName);
      await generateFooter(doc, generatedBy, signatureBlobContentId);
      let url;
      let token;

      if (snag.floorPlan.latestSnapshotBlobId) {
        token = await getAzureSASToken(blobMediaRef);
        url =
          blobContainerBaseUrl +
          blobMediaRef +
          "/" +
          snag.floorPlan.latestSnapshotBlobId +
          "?" +
          token;
      } else if (snag.floorPlan.blobReference) {
        token = await getAzureSASToken(blobDrawingRef);
        url =
          blobContainerBaseUrl +
          blobDrawingRef +
          "/" +
          snag.floorPlan.blobReference +
          "?" +
          token;
      }

      doc
        .fontSize(10)
        .font("Helvetica-Bold")
        .text("Snag Location:", 50, 100)
        .font("Helvetica")
        .text(
          snag.workLocation.level1 +
            (snag.workLocation.level2 ? " - " + snag.workLocation.level2 : "") +
            (snag.workLocation.level3 ? " - " + snag.workLocation.level3 : "") +
            (snag.workLocation.level4 ? " - " + snag.workLocation.level4 : ""),
          200,
          100
        );

      const result = await axios.get(url, {
        responseType: "arraybuffer",
      });

      const { image, width, height } = getPDFImageDimensions(result.data);

      doc.image(image, 70, 120, {
        width: width,
        height: height,
      });
    }
  } catch (err) {
    logger.error("Error in addFloorPlan method. Error: " + JSON.stringify(err));
  }
};
const addMediaList = async (
  doc,
  snag,
  projectName,
  generatedBy,
  signatureBlobContentId
) => {
  try {
    if (snag && snag.mediaList && snag.mediaList.length > 0) {
      const token = getAzureSASToken(blobMediaRef);

      const mediaPromises = snag.mediaList.map(async (media) => {
        try {
          const arrayBuffer = await downloadMedia(media.blobReference, token);
          const { image, width, height } =
            getPDFMediaImageDimensions(arrayBuffer);

          media.image = image;
          media.width = width;
          media.height = height;
          return media;
        } catch (error) {
          logger.error(
            "Error in fetching media. Error: " + JSON.stringify(error)
          );
          return null; // Returning null for failed media
        }
      });

      const processedMedia = await Promise.all(mediaPromises);
      // Filter out failed media (where processedMedia entry is null)
      const validProcessedMedia = processedMedia.filter(
        (entry) => entry !== null
      );

      // Process validProcessedMedia and call addMediaImage
      // validProcessedMedia.forEach(async (media) => {
      // const { media, image, width, height } = processedEntry;
      await addMediaImage(
        doc,
        validProcessedMedia,
        snag,
        projectName,
        generatedBy,
        signatureBlobContentId
      );
      // });
    }
  } catch (err) {
    logger.error("Error in addMediaList method. Error: " + JSON.stringify(err));
  }
};

const downloadMedia = async (blobReference, token) => {
  const url = `${blobContainerBaseUrl}${blobMediaRef}/${blobReference}?${token}`;
  const response = await axios.get(url, { responseType: "arraybuffer" });
  const data = response.data;
  return new Uint8Array(data).buffer;
};

const addMediaImage = async (
  doc,
  media,
  snag,
  projectName,
  generatedBy,
  signatureBlobContentId
) => {
  try {
    let countRecord = [];
    const filterCreatedStage = media.filter((item) => item.state == "created");
    const filterLevel1Stage = media.filter(
      (item) => item.state == "level1Updated"
    );
    const filterLevel2Stage = media.filter(
      (item) => item.state == "level2Updated"
    );
    countRecord.push(filterCreatedStage.length);
    countRecord.push(filterLevel1Stage.length);
    countRecord.push(filterLevel2Stage.length);
    const highestNumber = Math.max(...countRecord);
    let stage = "Created";
    let level1 = "Level 1 Approved";
    let level2 = "Level 2 Approved";
    for (let i = 0; i < highestNumber; i++) {
      await doc.addPage();
      await generateHeader(doc, projectName);
      await generateFooter(doc, generatedBy, signatureBlobContentId);
      if (i == 0) {
        doc
          .fontSize(10)
          .font("Helvetica-Bold")
          .text("Snag Images ", 70, 80)
          .font("Helvetica");
      }
      doc
        .font("Helvetica")
        .fontSize(10)
        .font("Helvetica-Bold")
        .text(`Stage: ${stage}`, 70, 90)
        .font("Helvetica");
      if (filterCreatedStage[i]) {
        doc.image(filterCreatedStage[i].image, 70, 100, {
          width: 200,
          height: 180,
        });
        doc
          .fontSize(10)
          .font("Helvetica-Bold")
          .text(snag?.remark, 280, 150)
          .font("Helvetica");
      }
      doc
        .font("Helvetica")
        .fontSize(10)
        .font("Helvetica-Bold")
        .text(`Stage: ${level1}`, 70, 310)
        .font("Helvetica");
      if (filterLevel1Stage[i]) {
        doc.image(filterLevel1Stage[i].image, 70, 320, {
          width: 200,
          height: 180,
        });
        doc
          .fontSize(10)
          .font("Helvetica-Bold")
          .text(snag?.level1Status?.comment, 280, 370)
          .font("Helvetica");
      }
      doc
        .font("Helvetica")
        .fontSize(10)
        .font("Helvetica-Bold")
        .text(`Stage: ${level2}`, 70, 530)
        .font("Helvetica");
      if (filterLevel2Stage[i]) {
        doc.image(filterLevel2Stage[i].image, 70, 540, {
          width: 200,
          height: 180,
        });
        doc
          .fontSize(10)
          .font("Helvetica-Bold")
          .text(snag?.level2Status?.comment, 280, 590)
          .font("Helvetica");
      }
    }
  } catch (err) {
    logger.error(
      "Error in addMediaImage method. Error: " + JSON.stringify(err)
    );
  }
};

const getPDFMediaImageDimensions = (arrayBuffer) => {
  let image = new Buffer.from(arrayBuffer, "base64");

  const img = new Image();
  img.src = `data:image/jpeg;base64,${Buffer.from(
    arrayBuffer,
    "base64"
  ).toString("base64")}`;

  const width = img.width;
  const height = img.height;
  let newWidth;
  let newHeight;
  if (width > height) {
    // Create an off-screen canvas
    const offScreenCanvas = createCanvas(width, height);
    const ctx = offScreenCanvas.getContext("2d");

    // Draw the image onto the canvas without rotation
    ctx.drawImage(img, 0, 0);

    // Convert the canvas to a Data URL (image/jpeg format)
    image = offScreenCanvas.toDataURL("image/jpeg");

    // Calculate new dimensions while maintaining the aspect ratio
    newHeight = 630;
    newWidth = parseInt((width * newHeight) / height); // Calculate new width based on aspect ratio
  } else if (width <= 550 && height <= 630) {
    // if width is less than 550, then any height is fine
    newHeight = height;
    newWidth = width;
  } else {
    // limiting the height and width now to specific value
    newHeight = 630;
    newWidth = parseInt((width * newHeight) / height);
  }

  return { image, height: newHeight, width: newWidth };
};

const getPDFImageDimensions = (arrayBuffer) => {
  let image = new Buffer.from(arrayBuffer, "base64");

  const img = new Image();
  img.src = `data:image/jpeg;base64,${Buffer.from(
    arrayBuffer,
    "base64"
  ).toString("base64")}`;

  const width = img.width;
  const height = img.height;
  let newWidth;
  let newHeight;
  if (width > height) {
    const offScreenCanvas = createCanvas(width, height);
    const ctx = offScreenCanvas.getContext("2d");
    offScreenCanvas.height = width;
    offScreenCanvas.width = height;
    ctx.rotate((90 * Math.PI) / 180);
    ctx.translate(0, -offScreenCanvas.width);
    ctx.drawImage(img, 0, 0);
    image = offScreenCanvas.toDataURL("image/jpeg");
    newHeight = 630;
    newWidth = parseInt((height * newHeight) / width);
  } else if (width <= 550 && height <= 630) {
    // if width is less than 550, then any height is fine
    newHeight = height;
    newWidth = width;
  } else {
    // limiting the height and width now to specific value
    newHeight = 630;
    newWidth = parseInt((width * newHeight) / height);
  }

  return { image, height: newHeight, width: newWidth };
};

const generateHr = (doc, y) => {
  doc.strokeColor("#2d4059").lineWidth(2).moveTo(50, y).lineTo(550, y).stroke();
};

const generateHrTble = (doc, y) => {
  doc.strokeColor("#2d4059").lineWidth(1).moveTo(50, y).lineTo(550, y).stroke();
};

const formatDate = (date) => {
  const day = date.getDate();
  const month = date.getMonth() + 1;
  const year = date.getFullYear();

  return year + "/" + month + "/" + day;
};

const formatCurrency = (cents) => {
  return "$" + (cents / 100).toFixed(2);
};

const sendReport = async (mailTo, subject, emailContent, report) => {
  let sendGridStatus;
  let sendGridError = null;
  const messages = [];
  const encodedString = report.toString("base64");

  for (let user of mailTo) {
    messages.push({
      to: `<${user.email}>`,
      subject: subject,
      from: fromEmail,
      html: emailContent
        .replace("{user}", user.firstName)
        .replace(`${user.email}`, `<strong>${user.email}</strong>`),
      attachments: [
        {
          content: encodedString,
          filename: "attachment.pdf",
          type: "application/pdf",
          disposition: "attachment",
        },
      ],
    });
  }

  await (async () => {
    try {
      await SendGridMail.send(messages).then(() => {
        sendGridStatus = "success";
      });
    } catch (error) {
      logger.error(
        "Error in sendReport method. Error: " + JSON.stringify(error)
      );
      sendGridError = error;
      if (error.response) {
        logger.error(
          "Error in Send Grid Response. Error: " +
            JSON.stringify(error.response.body)
        );
      }
    }
  })();

  return [sendGridError, sendGridStatus];
};

const addLogs = async (
  doc,
  snag,
  projectName,
  generatedBy,
  signatureBlobContentId
) => {
  try {
    await doc.addPage();
    await generateHeader(doc, projectName);
    await generateFooter(doc, generatedBy, signatureBlobContentId);
    doc.fillColor("#444444").fontSize(16).text("Logs", 50, 80);
    generateHrTble(doc, 100);
    doc.moveDown();
    const datas = [];
    for (let log of snag.logs) {
      datas.push({
        timestamp: moment(log.timestamp)
          .tz("Asia/Kolkata")
          .format("DD-MMM-YYYY HH:mm:ss"),
        user: `${log.user.firstName} ${log.user.lastName}\n(${log.user.email})`,
        description:
          log.fieldNames && log.fieldNames.length > 0
            ? `${log.description}\nUpdated: ${log.fieldNames.join(", ")}`
            : log.description,
      });
    }
    const table = {
      // title: "Logs",
      // subtitle: "Updates",
      headers: [
        {
          label: "Time",
          property: "timestamp",
          width: 90,
          renderer: null,
        },
        {
          label: "Action",
          property: "description",
          width: 260,
          renderer: null,
        },
        {
          label: "User",
          property: "user",
          width: 150,
          renderer: null,
        },
      ],
      datas: datas,
    };

    doc.table(table, {
      prepareHeader: () => doc.font("Helvetica-Bold").fontSize(12),
      prepareRow: (row, indexColumn, indexRow, rectRow) => {
        doc.font("Helvetica").fontSize(12);
        indexColumn === 0 && doc.addBackground(rectRow, "#2d4059", 0.2);
      },
    });
  } catch (err) {
    logger.error("Error in addLogs method. Error: " + JSON.stringify(err));
  }
};

module.exports = {
  createReport,
  downloadReport,
  saveForDownloadReport,
};
