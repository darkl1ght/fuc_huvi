"use strict";

const { AuthClientTwoLegged } = require("forge-apis");
const { autocadForge } = require("../config");
// Initialize the 2-legged OAuth2 client, set specific scopes and optionally set the `autoRefresh` parameter to true
// if you want the token to auto refresh
const autoRefresh = true; // or false

const getClient = (scopes) => {
  const { clientId, clientSecret } = autocadForge;
  return new AuthClientTwoLegged(
    clientId,
    clientSecret,
    scopes || autocadForge.scopes.internal,
    autoRefresh
  );
};

let cache = new Map();

const getToken = async (scopes) => {
  const key = scopes.join("+");
  if (cache.has(key) && cache.get(key).expires_at > Date.now()) {
    return cache.get(key);
  }
  const client = getClient(scopes);
  let credentials = await client.authenticate();
  credentials.expires_at = Date.now() + credentials.expires_in * 1000;
  cache.set(key, credentials);
  return credentials;
};

/**
 * Retrieves a 2-legged authentication token for preconfigured public scopes.
 * @returns Token object: { "access_token": "...", "expires_at": "...", "expires_in": "...", "token_type": "..." }.
 */
const getPublicToken = async () => {
  return getToken(autocadForge.scopes.public);
};

/**
 * Retrieves a 2-legged authentication token for preconfigured internal scopes.
 * @returns Token object: { "access_token": "...", "expires_at": "...", "expires_in": "...", "token_type": "..." }.
 */
const getInternalToken = async () => {
  return getToken(autocadForge.scopes.internal);
};

module.exports = {
  getClient,
  getPublicToken,
  getInternalToken,
};
