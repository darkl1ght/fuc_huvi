const { Constants } = require("../config/constants");
const { redisGetJson } = require("./redisHelper");
const mongoose = require("mongoose");
const AccessMapping = mongoose.model("AccessMapping");
const Project = mongoose.model("Project");

const getAccessMapping = async (role) => {
  const accessMappingCacheKey =
    Constants.accessControlConfig.ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX + role;
  const accessMappingFromCache = await redisGetJson(accessMappingCacheKey);

  if (accessMappingFromCache) {
    return accessMappingFromCache;
  } else {
    await AccessMapping.findOne(
      {
        role,
        isActive: true
      },
      {
        _id: 0,
        role: 1,
        desc: 1,
        "accessMapping.objectKey": 1,
        "accessMapping.desc": 1,
        "accessMapping.module": 1,
        "accessMapping.isAllowed": 1,
        "accessMapping.isRedactable": 1,
        "accessMapping.isRedacted": 1,
        "accessMapping.isAdminOnly": 1,
      }
    ).then(async (accessMappingFromDb) => {
      if (accessMappingFromDb?.accessMapping) {
        await redisSetJson(accessMappingCacheKey, accessMappingFromDb);
        return accessMappingFromDb;
      } else {
        return null;
      }
    }).catch(() => null);
  }
};

const getProjectUsers = async (projectId) => {
  const projectUsersCacheKey =
    Constants.accessControlConfig.PROJECT_USERS_CACHE_KEY_PREFIX + projectId;
  const projectUsersFromCache = await redisGetJson(projectUsersCacheKey);

  if (projectUsersFromCache) {
    return projectUsersFromCache;
  } else {
    await Project.findOne(
      {
        projectId: projectId
      }
    ).then(async (projectFromDb) => {
      if (projectFromDb.users) {
        await redisSetJson(projectUsersCacheKey, projectFromDb.users);
        return projectFromDb.users;
      } else {
        return null;
      }
    }).catch(() => null);
  }
};

module.exports = { getAccessMapping, getProjectUsers };