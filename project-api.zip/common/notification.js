const NotificationTemplate = require("../models/NotificationTemplate");
const NotificationMasterData = require("../models/NotificationMasterData");
const logger = require("./logger");

module.exports = async (data) => {
  try {
    // Fetch notification message details
    let { title, body } = await NotificationTemplate.findOne({
      code: data.messageType,
    });

    /*
     Dynamically populate the body from the data
     A sample string from the database - 
     -- Virtual tour dated {interiorDate} at {towerName} - {tourName} has been published for {projectName}
     populate the values dynamically on items enclosed with {}
    */
    body = body
      .split(" ")
      .map((word) => {
        if (word.startsWith("{") && word.endsWith("}")) {
          return data[word.substring(1, word.length - 1)];
        }
        return word;
      })
      .join(" ");

    // If user emails present in data take them, else get it from the project users
    let { notificationUserEmails } = data;

    if (!notificationUserEmails) {
      notificationUserEmails = data["users"]
        .filter((user) => !user.isBlocked)
        .map((user) => user.email);
    }

    let tokens = await NotificationMasterData.aggregate([])
      .unwind("tokens")
      .match({
        userEmail: {
          $in: notificationUserEmails,
        },
        "tokens.disabled": false,
        "tokens.appType.key": data.appType,
      })
      .project({ token: "$tokens.token", _id: 0 });

    let notificationData;

    if (tokens.length > 0) {
      tokens = tokens.map((token) => token.token);
      notificationData = {
        message: {
          data: {
            title,
            body,
            projectName: data.projectName,
            projectId: data.projectId,
            ...data.metaData,
          },
          android: {
            priority: "high",
          },
          apns: {
            payload: {
              aps: {
                contentAvailable: true,
              },
            },
            headers: {
              "apns-push-type": "background",
              "apns-priority": "5",
              "apns-topic": "com.huviair.constra", // your app bundle identifier
            },
          },
          tokens,
          users: notificationUserEmails,
        },
      };
    }

    return notificationData;
  } catch (error) {
    logger.error("Error in sending data", error);
  }
};
