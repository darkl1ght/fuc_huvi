"use strict";

const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const logger = require("./logger");

const checkAccess = async (payload, queryKey, queryValue) => {
  try {
    let access;
    if (payload.isAdmin) {
      access = true;
    } else {
      const query = {
        users: {
          $elemMatch: {
            email: payload.email,
            isActive: true,
            isBlocked: false,
          },
        },
        isActive: true,
      };
      switch (queryKey) {
        case "activities":
          query[queryKey] = {
            $in: queryValue,
          };
          break;
        case "projectId":
          query[queryKey] = queryValue;
          break;
      }
      await Project.countDocuments(query, async (err, count) => {
        if (count > 0) {
          access = true;
        } else {
          access = false;
        }
      }).catch((err) => {
        logger.error(
          "Error in Project.countDocuments in checkAccess method. Error: " +
            JSON.stringify(err)
        );
      });
    }

    return access;
  } catch (err) {
    logger.error("Error in checkAccess method. Error: " + JSON.stringify(err));
  }
};

module.exports = checkAccess;
