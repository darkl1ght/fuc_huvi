"use strict";

const axios = require("axios");

const {
  LIVE_STREAM_HOST,
  WITHOUT_REC,
  DELETE_SOURCE,
  STREAM_STATISTICS,
  REC_OPTION,
  PASSWORD,
} = require("../config").livestream;
const logger = require("./logger");

module.exports = {
  async registerDevice(deviceName, record, token) {
    let data = "";
    let url = LIVE_STREAM_HOST;
    let path = WITHOUT_REC;
    let headers = {
      Authorization: `Bearer ${token}`,
    };
    let params = {
      name: deviceName,
      password: PASSWORD,
    };
    await axios
      .post(url + path, params, {
        headers: headers,
      })
      .then((res) => {
        data = res.data;
      })
      .catch((error) => {
        logger.error(
          "Error in registerDevice method. Error: " + JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
  async deleteDevice(deviceName, token) {
    let data;
    let url = LIVE_STREAM_HOST;
    let path = DELETE_SOURCE.replace("{{source_name}}", deviceName);
    let headers = {
      Authorization: `Bearer ${token}`,
    };
    let params = {
      name: deviceName,
      password: PASSWORD,
    };
    await axios
      .delete(url + path, {
        headers: headers,
      })
      .then((res) => {
        data = res.data;
      })
      .catch((error) => {
        logger.error(
          "Error in deleteDevice method. Error: " + JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
  async getStatistics(deviceName, token) {
    let data;
    let url = LIVE_STREAM_HOST;
    let path = STREAM_STATISTICS.replace("{{source_name}}", deviceName);
    let headers = {
      Authorization: `Bearer ${token}`,
    };

    await axios
      .get(url + path, {
        headers: headers,
      })
      .then((res) => {
        data = res.data;
      })
      .catch((error) => {
        logger.error(
          "Error in getStatistics method. Error: " + JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
  async recordStream(deviceName, token) {
    let data;
    let url = LIVE_STREAM_HOST;
    let path = REC_OPTION.replace("{{source_name}}", deviceName);
    let headers = {
      Authorization: `Bearer ${token}`,
    };
    await axios
      .get(url + path, {
        headers: headers,
      })
      .then((res) => {
        data = res.data;
      })
      .catch((error) => {
        logger.error(
          "Error in recordStream method. Error: " + JSON.stringify(error)
        );
        data = "";
      });

    return data;
  },
};
