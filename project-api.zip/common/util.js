"use strict";

const EmailService = require("./emails");
const mongoose = require("mongoose");
const EmailTemplate = mongoose.model("EmailTemplate");
const EmailNotification = require("../models/EmailNotification");
const { createReport, downloadReport } = require("./snag-report");
const moment = require("moment-timezone");
const logger = require("./logger");
const path = require("path");
const rootDir = path.dirname(__dirname);

const getAzureSASToken = require("./azure.access.token");
const { AzureAccountName } = require("../config").azureStorage;
const { BlobServiceClient } = require("@azure/storage-blob");

const sendProcessingStartEmail = async (mailTo, projectName, tourName) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10002",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject
        .replace("{project}", projectName)
        .replace("{tour}", tourName);
      emailContent = emailTemplate.body
        .replace("{user}", "User")
        .replace("{project}", projectName)
        .replace("{tour}", tourName);
      const [sendGridError, sendGridStatus] = await EmailService.sendMail(
        mailTo,
        subject,
        emailContent
      );
      if (sendGridError) {
        throw sendGridError;
      } else {
        mailSentStatus = "success";
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendProcessingStartEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendStartProcessingEmailOps = async (
  clientName,
  projectName,
  tour,
  blobPath,
  parameters
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10019",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      const mailTo = emailTemplate.to;
      const subject = emailTemplate.subject
        .replace("{project}", projectName)
        .replace("{tourName}", tour.tourName);
      const emailContent = emailTemplate.body
        .replace("{clientName}", clientName)
        .replace("{project}", projectName)
        .replace("{tourName}", tour.tourName)
        .replace(
          "{tourDate}",
          moment(tour.tourDate).tz("Asia/Kolkata").format("DD MMM, YYYY")
        )
        .replace("{tourId}", tour.tourId)
        .replace("{blobPath}", blobPath)
        .replace("{parameters}", JSON.stringify(parameters, null, 4));

      const [sendGridError, sendGridStatus] = await EmailService.sendMail(
        mailTo,
        subject,
        emailContent
      );
      if (sendGridError) {
        throw sendGridError;
      } else {
        mailSentStatus = "success";
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendProcessingStartEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendMediaTagEmail = async (mailTo, projectName, comment) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10001",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject;
      emailContent = emailTemplate.body
        .replace("{project}", projectName)
        .replace("{comment}", comment);
      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          mailTo,
          subject,
          emailContent
        );
      if (sendGridError) {
        throw sendGridError;
      } else {
        mailSentStatus = "success";
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendMediaTagEmail method. Error: " + JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendInteriorTagEmail = async (
  mailTo,
  projectName,
  interior,
  tour,
  remark,
  comment
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10008",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject;
      emailContent = emailTemplate.body
        .replace("{project}", projectName)
        .replace("{comment}", comment)
        .replace("{interior}", interior)
        .replace("{tour}", tour)
        .replace("{remark}", remark ? remark : "");
      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          mailTo,
          subject,
          emailContent
        );
      if (sendGridError) {
        throw sendGridError;
      } else {
        mailSentStatus = "success";
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendInteriorTagEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendNonConfirmityPunchlistEmail = async (
  mailTo,
  templateCode,
  mailData
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    const projectName = mailData.projectName;
    await EmailTemplate.findOne({
      code: templateCode,
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject.replace("{project}", projectName);
      emailContent = emailTemplate.body
        .replace("{project}", projectName)
        .replace("{workTrade}", mailData.workTrade)
        .replace("{priority}", mailData.priority)
        .replace("{description}", mailData.description)
        .replace("{dueDate}", mailData.dueDate)
        .replace("{level1Assignee}", mailData.level1Assignee.join(", "))
        .replace("{level2Assignee}", mailData.level2Assignee.join(", "))
        .replace("{locationList}", mailData.locations.join(""));

      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          mailTo,
          subject,
          emailContent
        );
      if (sendGridError) {
        throw sendGridError;
      } else {
        mailSentStatus = "success";
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendNonConfirmityPunchlistEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendConfirmityPunchlistEmail = async (mailTo, templateCode, mailData) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    const projectName = mailData.projectName;
    await EmailTemplate.findOne({
      code: templateCode,
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject.replace("{project}", projectName);
      emailContent = emailTemplate.body
        .replace("{project}", projectName)
        .replace("{punchListId}", mailData.punchListId)
        .replace("{workTrade}", mailData.workTrade)
        .replace("{priority}", mailData.priority)
        .replace("{dueDate}", mailData.dueDate)
        .replace("{level1Assignee}", mailData.level1Assignee.join(", "))
        .replace("{level2Assignee}", mailData.level2Assignee.join(", "))
        .replace("{locationList}", mailData.locations.join(""))
        .replace("{punchlistItems}", mailData.punchListItems.join(""));

      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          mailTo,
          subject,
          emailContent
        );
      if (sendGridError) {
        throw sendGridError;
      } else {
        mailSentStatus = "success";
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendConfirmityPunchlistEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendContractReminderEmail = async (
  mailTo,
  mailCc,
  mailBcc,
  fromEmail,
  templateCode,
  mailData
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: templateCode,
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });

    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject.replace(
        "{clientName}",
        mailData.clientName
      );
      emailContent = emailTemplate.body
        .replace("{projectName}", mailData.projectName)
        .replace("{clientName}", mailData.clientName)
        .replace("{contractEndDate}", mailData.contractEndDateDisplay)
        .replace("{renewBeforeDate}", mailData.renewBeforeDateDisplay);

      const [sendGridError, sendGridStatus] =
        await EmailService.sendContractReminderEmail(
          mailTo,
          mailCc,
          mailBcc,
          fromEmail,
          subject,
          emailContent
        );

      //db logging
      await EmailNotification.findOne({
        templateCode,
        "additionalInfo.projectId": mailData.projectId,
        "additionalInfo.contractEndDate": mailData.contractEndDate,
        "additionalInfo.daysOffset": mailData.daysOffset,
        "additionalInfo.cronId": mailData.cronId,
        status: "inprogress",
        createdAt: {
          $gte: new Date(moment().add(-1, "day")), //Checking for a range for 2 days
          $lte: new Date(moment().add(1, "day")),
        },
      })
        .then((data) => {
          if (data) {
            data.to = mailTo.join(", ");
            data.cc = mailCc.join(", ");
            data.bcc = mailBcc.join(", ");
            data.subject = subject;
            data.body = emailContent;
            data.status = sendGridError ? "error" : "success";

            data.save().catch((err) => {
              logger.error(
                "Error in saving EmailNotification in sendContractReminderEmail() in util. Error: " +
                  JSON.stringify(err)
              );
            });
          }
        })
        .catch((err) => {
          logger.error(
            "Error in fetching EmailNotification in sendContractReminderEmail() in util. Error: " +
              JSON.stringify(err)
          );
        });

      if (sendGridError) {
        throw sendGridError;
      } else {
        mailSentStatus = "success";
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "Error in sendContractReminderEmail() in util. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendPunchlistUpdateEmail = async (
  mailTo,
  mailData,
  snag,
  generatedBy = ""
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    const projectName = mailData.projectName;
    await EmailTemplate.findOne({
      code: "ET10007",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject.replace("{project}", projectName);
      emailContent = emailTemplate.body
        .replace("{updatedBy}", mailData.updatedBy)
        .replace("{updateFor}", mailData.updateFor)
        .replace("{project}", projectName)
        .replace("{punchItemId}", mailData.punchItemId)
        .replace("{workTrade}", mailData.workTrade)
        .replace("{priority}", mailData.priority)
        .replace("{description}", mailData.description)
        .replace("{dueDate}", mailData.dueDate)
        .replace("{overallStatus}", mailData.overallStatus)
        .replace("{level1Status}", mailData.level1Status)
        .replace("{level1ApproverComment}", mailData.level1ApproverComment)
        .replace("{level2Status}", mailData.level2Status)
        .replace("{level2ApproverComment}", mailData.level2ApproverComment);

      try {
        await downloadReport(
          snag,
          mailTo,
          subject,
          emailContent,
          projectName,
          "",
          generatedBy
        );

        mailSentStatus = "success";
      } catch (err) {
        if (err) {
          mailSentError = err;
          mailSentStatus = "failure";
          logger.error(
            "mailSentError in downloadReport in sendPunchlistUpdateEmail method. Error: " +
              JSON.stringify(err)
          );
        }
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendPunchlistUpdateEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendNonConfirmityPunchlistEmailWithReport = async (
  mailTo,
  templateCode,
  mailData,
  snagList,
  projectName,
  projectLocation,
  generatedBy
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    const projectName = mailData.projectName;
    await EmailTemplate.findOne({
      code: templateCode,
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject.replace("{project}", projectName);
      emailContent = emailTemplate.body
        .replace("{project}", projectName)
        .replace("{projectName}", projectName)
        .replace("{workTrade}", mailData.workTrade)
        .replace("{priority}", mailData.priority)
        .replace("{dueDate}", mailData.dueDate)
        .replace("{level1Assignee}", mailData.level1Assignee.join(", "))
        .replace("{level2Assignee}", mailData.level2Assignee.join(", "));

      try {
        await Promise.all(
          snagList.map(async (snag) => {
            await createReport(
              snag,
              mailTo,
              subject,
              emailContent,
              projectName,
              projectLocation,
              generatedBy
            );
          })
        );

        mailSentStatus = "success";
      } catch (err) {
        if (err) {
          mailSentError = err;
          mailSentStatus = "failure";
          logger.error(
            "mailSentError in createReport in sendNonConfirmityPunchlistEmailWithReport method. Error: " +
              JSON.stringify(err)
          );
        }
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendNonConfirmityPunchlistEmailWithReport method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendNonConfirmityPunchlistEmailWithTeam = async (
  mailTo,
  templateCode,
  snag,
  projectName,
  projectLocation = "",
  generatedBy = "",
  signatureBlobContentId = null
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: templateCode,
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });

    if (!mailSentError) {
      let subject;
      let emailContent;

      subject = emailTemplate.subject
        .replace("{project}", projectName)
        .replace("{punchId}", snag.punchId);

      emailContent = emailTemplate.body
        .replace("{project}", projectName)
        .replace("{projectName}", projectName)
        .replace("{workTrade}", snag.workPackage.tradeName)
        .replace("{priority}", snag.taskPriority.desc)
        .replace("{description}", snag.taskDescription)
        .replace(
          "{dueDate}",
          moment(snag.dueDate).tz("Asia/Kolkata").format("DD MMM, YYYY")
        )
        .replace("{level1Assignee}", snag.level1Users.join(", "))
        .replace("{level2Assignee}", snag.level1Users.join(", "))
        .replace("{generatedBy}", generatedBy);

      try {
        await downloadReport(
          snag,
          mailTo,
          subject,
          emailContent,
          projectName,
          projectLocation,
          generatedBy,
          signatureBlobContentId
        );

        mailSentStatus = "success";
      } catch (err) {
        if (err) {
          mailSentError = err;
          mailSentStatus = "failure";
          logger.error(
            "mailSentError in downloadReport in sendNonConfirmityPunchlistEmailWithTeam method. Error: " +
              JSON.stringify(err)
          );
        }
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendNonConfirmityPunchlistEmailWithTeam method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const getEPSGProjection = (lat, lng) => {
  const firstCoord = [lng, lat];
  const offset = Math.round((183 + firstCoord[0]) / 6);
  return firstCoord[1] > 0 ? 32600 + offset : 32700 + offset;
};

// important method to keep the node service waiting
const wait = async (ms) => {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
};

const generateLogObject = (
  user,
  description,
  request = {},
  fieldNames = [],
  fromState = "",
  toState = "",
  level = "info"
) => {
  return {
    request: request,
    user: {
      email: user.email,
      userId: user.id,
      isAdmin: user.isAdmin,
      firstName: user.firstName,
      lastName: user.lastName,
    },
    timestamp: moment.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
    description: description,
    fieldNames: fieldNames,
    fromState: fromState,
    toState: toState,
    level: level,
  };
};

const generateUUID = () => {
  const d = new Date();
  const k = d.getTime();
  const str = k.toString(16).slice(2);
  const UUID = "xxxx-4xxx-yxzx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    let v = c == "x" ? r : (r & 3) | 8;
    return v.toString(16);
  });
  const newString = UUID.replace(/[z]/, str);
  return newString;
};

const getFilesFromRequest = async (files, email, folderName) => {
  const movedFiles = [];
  let moveError;
  let moveCount = 0;
  for (let file of Object.keys(files)) {
    const currFile = files[file];
    const uploadPath = path.join(rootDir, folderName, currFile.name);
    // Use the mv() method to place the file somewhere on your server
    await currFile.mv(uploadPath, async (err) => {
      if (err) {
        moveError = err;
        return err;
      }
    });
    if (moveError) {
      break;
    }
    movedFiles.push({
      filename: currFile.name,
      uploadPath: uploadPath,
      uploadedBy: email,
      uploadedAt: new Date(),
    });
    moveCount += 1;
  }

  return { movedFiles, moveCount, moveError };
};

const getTotalBlobSize = async (container, blobs) => {
  try {
    if (blobs.length < 1) return 0;
    const sasToken = getAzureSASToken(container, "r");
    const blobSASurl = `https://${AzureAccountName}.blob.core.windows.net/?${sasToken}`;
    const blobServiceClient = new BlobServiceClient(blobSASurl);
    const containerClient = blobServiceClient.getContainerClient(container);
    const result = await Promise.all(
      blobs.map(async (blob) => {
        const blockBlobClient = containerClient.getBlockBlobClient(blob);
        if (blob) {
          try {
            const blobProperties = await blockBlobClient.getProperties();
            return blobProperties;
          } catch (err) {
            return {
              contentLength: 0,
            };
          }
        } else {
          return {
            contentLength: 0,
          };
        }
      })
    );
    const sizes = result.map((res) => res.contentLength);
    return sizes.reduce((x, y) => x + y) || 0;
  } catch (err) {
    return -1;
  }
};

// functions for  uploading and deleting elevation files to azure blob

const uploadElevationFileToBlob = async (
  container,
  filePath,
  blobContentId
) => {
  try {
    const sasToken = getAzureSASToken(container, "w");

    const blobSASurl = `https://${AzureAccountName}.blob.core.windows.net/?${sasToken}`;

    const blobServiceClient = new BlobServiceClient(blobSASurl);

    const containerClient = blobServiceClient.getContainerClient(container);

    const blockBlobClient = containerClient.getBlockBlobClient(blobContentId);

    if (blockBlobClient !== undefined) {
      try {
        const result = await blockBlobClient.uploadFile(filePath);

        return {
          result,
        };
      } catch (err) {
        next(err);
      }
    }

    const result = await blockBlobClient.uploadFile(filePath);

    return {
      result,
    };
  } catch (err) {
    next(err);
  }
};

//payload of uploaded file to be saved in DB

const getPayloadToSave = (
  email,
  fileName,
  container,
  blobContentId,
  uploadedAt
) => {
  try {
    const nameWithoutExt =
      fileName.substring(0, fileName.lastIndexOf(".")) || fileName;

    const elevationType = fileName.split("-")[0].toLowerCase();

    return {
      type: `blob-${nameWithoutExt}`,
      key: `${elevationType}_blob_url`,
      value: `https://${AzureAccountName}.blob.core.windows.net/${container}/${blobContentId}`,
      appendIndex: -1,
      disabled: true,
      addedBy: email,
      uploadedAt: uploadedAt,
      filename: fileName,
      uploadedTo: "blob",
    };
  } catch (error) {
    next(error);
  }
};

//deleting the elevation file from blob

const deleteElevationFileFromBlob = (
  container,
  blobname,
  options = {
    deleteSnapshots: "include",
  }
) => {
  try {
    const sasToken = getAzureSASToken(container, "d");

    const blobSASurl = `https://${AzureAccountName}.blob.core.windows.net/?${sasToken}`;

    const blobServiceClient = new BlobServiceClient(blobSASurl);

    const containerClient = blobServiceClient.getContainerClient(container);

    const blockBlobClient = containerClient.getBlockBlobClient(blobname);

    const result = blockBlobClient.delete(options);

    return {
      result,
    };
  } catch (err) {
    next(error);
  }
};

// deleting aerialtour image folder and its blobs from the azure storage

const deleteAerialTourImageFolder = async (container, folderName) => {
  try {
    const sasToken = getAzureSASToken(container, "rld");

    const blobSASurl = `https://${AzureAccountName}.blob.core.windows.net/?${sasToken}`;

    const blobServiceClient = new BlobServiceClient(blobSASurl);

    const containerClient = blobServiceClient.getContainerClient(container);

    const delimiter = "/";
    const prefix = folderName + delimiter;

    for await (const blob of containerClient.listBlobsFlat({ prefix })) {
      const blobClient = containerClient.getBlobClient(blob.name);
      await blobClient.delete();
    }
    return true;
  } catch (error) {
    return false;
  }
};

const sendFIDiscussionEmail = async (mailToArray, mailFrom, options) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10012",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      const {
        projectName,
        issueNumber,
        discussion: { content },
        projectTeam,
      } = options;
      const comment = content.replace(
        /@([a-zA-Z0-9]+_[a-zA-Z0-9]+)/g,
        (match, key) => {
          const person = projectTeam.find(
            ({ firstName, lastName }) =>
              `${firstName}_${lastName}`.toLowerCase() === key.toLowerCase()
          );
          return person
            ? `<a href='mailto:${person.email}'>@${person.firstName}_${person.lastName}</a>`
            : match;
        }
      );
      const subject = emailTemplate.subject.replace("{project}", projectName);
      const emailContent = emailTemplate.body
        .replace("{from}", `${mailFrom.firstName} ${mailFrom.lastName}`)
        .replace("{issueNumber}", issueNumber)
        .replace("{comment}", comment);

      await new Promise(async (res, rej) => {
        const [sendGridError, sendGridStatus] =
          await EmailService.sendPersonalizationTagMail(
            mailToArray,
            subject,
            emailContent
          );
        if (sendGridError) {
          rej(sendGridError);
        } else {
          res(mailSentStatus);
        }
      }).then((_) => {
        mailSentStatus = _;
        return _;
      });
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendFIDiscussionEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendFIWatchlistEmail = async (mailToArray, options) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    const { projectName, issueNumber, fields, uploadedFileObject } = options;
    const { viewUrl } = uploadedFileObject;
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10011",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      const fieldTemplate = emailTemplate.fieldTemplate;
      const subject = emailTemplate.subject
        .replace("{project}", projectName)
        .replace("{issueNumber}", issueNumber);
      const modifiedFieldRows = getModifiedFieldRowTemplate(
        fields,
        fieldTemplate
      );
      const emailContent = emailTemplate.body
        .replace("{viewUrl}", viewUrl)
        .replace("{issueNumber}", issueNumber)
        .replace("{modifiedFieldRows}", modifiedFieldRows);

      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          mailToArray,
          subject,
          emailContent
        );

      if (sendGridError) {
        throw sendGridError;
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendFIWatchlistEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendAsigneeEmail = async (mailToArray, options) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    const { projectName, issueNumber, fields, uploadedFileObject } = options;
    const { viewUrl } = uploadedFileObject;
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10016",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      const fieldTemplate = emailTemplate.fieldTemplate;
      const subject = emailTemplate.subject
        .replace("{project}", projectName)
        .replace("{issueNumber}", issueNumber);
      const modifiedFieldRows = getModifiedFieldRowTemplate(
        fields,
        fieldTemplate
      );
      const emailContent = emailTemplate.body
        .replace("{viewUrl}", viewUrl)
        .replace("{issueNumber}", issueNumber)
        .replace("{modifiedFieldRows}", modifiedFieldRows);

      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          mailToArray,
          subject,
          emailContent
        );

      if (sendGridError) {
        throw sendGridError;
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendAsigneeEmail method. Error: " + JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendFIUpdateEmail = async (mailToArray, options) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    const {
      projectName,
      fi: { issueNumber },
      fields,
    } = options;
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10013",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      const fieldTemplate = emailTemplate.fieldTemplate;
      const subject = emailTemplate.subject
        .replace("{project}", projectName)
        .replace("{issueNumber}", issueNumber);
      const modifiedFieldRows = getModifiedFieldRowTemplate(
        fields,
        fieldTemplate
      );
      const emailContent = emailTemplate.body
        .replace("{issueNumber}", issueNumber)
        .replace("{modifiedFieldRows}", modifiedFieldRows);

      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          mailToArray,
          subject,
          emailContent
        );
      if (sendGridError) {
        throw sendGridError;
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendFIUpdateEmail method. Error: " + JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const getModifiedFieldRowTemplate = (fields, fieldTemplate) => {
  let modifiedFieldRows = "";
  for (let field of fields) {
    if (field.fieldName == "status") {
      modifiedFieldRows += fieldTemplate
        .replace("{fieldName}", "Status")
        .replace("{prevValue}", `${field.prevValue}`)
        .replace("{newValue}", `${field.newValue}`);
    } else if (field.fieldName == "assignee") {
      modifiedFieldRows += fieldTemplate
        .replace("{fieldName}", "Assignee")
        .replace(
          "{prevValue}",
          `${field.prevValue.firstName} ${field.prevValue.lastName}`
        )
        .replace(
          "{newValue}",
          `<a href='mailto:${field.newValue.email}'>${field.newValue.firstName} ${field.newValue.lastName}</a>`
        );
    } else if (field.fieldName == "dueDate") {
      modifiedFieldRows += fieldTemplate
        .replace("{fieldName}", "Due Date")
        .replace(
          "{prevValue}",
          `${moment(field.prevValue)
            .tz("Asia/Kolkata")
            .format("Do MMM YYYY, HH:mm:ss Z z")}`
        )
        .replace(
          "{newValue}",
          `${moment(field.newValue)
            .tz("Asia/Kolkata")
            .format("Do MMM YYYY, HH:mm:ss Z z")}`
        );
    } else if (field.fieldName == "priority") {
      modifiedFieldRows += fieldTemplate
        .replace("{fieldName}", "Priority")
        .replace("{prevValue}", `${field.prevValue}`)
        .replace("{newValue}", `${field.newValue}`);
    } else if (field.fieldName == "workTrade") {
      modifiedFieldRows += fieldTemplate
        .replace("{fieldName}", "Work Trade")
        .replace("{prevValue}", `${field.prevValue}`)
        .replace("{newValue}", `${field.newValue}`);
    } else if (field.fieldName == "description") {
      modifiedFieldRows += fieldTemplate
        .replace("{fieldName}", "Description")
        .replace("{prevValue}", `${field.prevValue}`)
        .replace("{newValue}", `${field.newValue}`);
    } else if (field.fieldName == "wbsItems") {
      modifiedFieldRows += fieldTemplate
        .replace("{fieldName}", "Linked WBS Items")
        .replace("{prevValue}", `${field.prevValue}`)
        .replace("{newValue}", `${field.newValue}`);
    }
  }

  return modifiedFieldRows;
};

const sendRFIAssigneeEmail = async (mailTo, options) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    const { projectName, rfi } = options;
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10014",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      mailTo.name = `${mailTo.firstName} ${mailTo.lastName}`;
      subject = emailTemplate.subject.replace("{project}", projectName);
      emailContent = emailTemplate.body
        .replace("{user}", `${mailTo.name}`)
        .replace("{wirNumber}", rfi.rfiNo)
        .replace("{status}", rfi.status.value)
        .replace(
          "{dueDate}",
          `${moment(rfi.inspectionDate)
            .tz("Asia/Kolkata")
            .format("Do MMM YYYY")}` +
            " " +
            `${moment(rfi.inspectionTime)
              .tz("Asia/Kolkata")
              .format("HH:mm:ss Z z")}`
        );
      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          [mailTo],
          subject,
          emailContent
        );
      if (sendGridError) {
        throw sendGridError;
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendRFIAsigneeEmail method. Error: " +
        JSON.stringify(err)
    );
  }
  return [mailSentError, mailSentStatus];
};

const sendRFIApproveAndRejectEmail = async (mailTo, options) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    const { projectName, rfi, mailContent } = options;
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10018",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      mailTo.name = `${mailTo.firstName} ${mailTo.lastName}`;
      subject = emailTemplate.subject.replace("{project}", projectName);
      emailContent = emailTemplate.body
        .replace("{user}", `${mailTo.name}`)
        .replace("{content}", mailContent)
        .replace("{wirNumber}", rfi.rfiNo)
        .replace("{status}", rfi.status.value)
        .replace(
          "{dueDate}",
          `${moment(rfi.inspectionDate)
            .tz("Asia/Kolkata")
            .format("Do MMM YYYY")}` +
            " " +
            `${moment(rfi.inspectionTime)
              .tz("Asia/Kolkata")
              .format("HH:mm:ss Z z")}`
        );
      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          [mailTo],
          subject,
          emailContent
        );
      if (sendGridError) {
        throw sendGridError;
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendRFIApprovAndRejectEmail method. Error: " +
        JSON.stringify(err)
    );
  }
  return [mailSentError, mailSentStatus];
};

const sendRFIWatchListEmail = async (mailToArray, mailFrom, options) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10015",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      const { projectName, rfi } = options;

      const subject = emailTemplate.subject.replace("{project}", projectName);
      // const emailContent = emailTemplate.body.replace("{rfiNo}", rfi.rfiNo);
      const emailContent = emailTemplate.body
        .replace("{from}", `${mailFrom.firstName} ${mailFrom.lastName}`)
        .replace("{rfiNo}", rfi.rfiNo);

      await new Promise(async (res, rej) => {
        const [sendGridError, sendGridStatus] =
          await EmailService.sendPersonalizationTagMail(
            mailToArray,
            subject,
            emailContent
          );
        if (sendGridError) {
          rej(sendGridError);
        } else {
          res(mailSentStatus);
        }
      }).then((_) => {
        mailSentStatus = _;
        return _;
      });
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendRFIWatchlistEmail method. Error: " +
        JSON.stringify(err)
    );
  }
  return [mailSentError, mailSentStatus];
};

const sendTourPublishEmail = async (mailToArray, options) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    const {
      project: { projectName },
      tour: { tourName, tourDate },
      shareLink,
      tourType,
      floorPublishedCount,
    } = options;
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10017",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      const subject = emailTemplate.subject
        .replace("{tourType}", tourType)
        .replace("{project}", projectName)
        .replace("{tour}", tourName);

      let emailContent = emailTemplate.body
        .replace("{tourType}", tourType)
        .replace("{project}", projectName)
        .replace("{href}", shareLink)

        .replace(
          "{tourDate}",
          `${moment(tourDate).tz("GMT").format("Do MMM YYYY HH:mm:ss z")}`
        );

      if (tourType == "Aerial") {
        emailContent = emailContent.replace("{displayPlaceholder}", "none");
      } else if (tourType == "Virtual") {
        emailContent = emailContent
          .replace("{displayPlaceholder}", "block")
          .replace("{floorPublishedCount}", floorPublishedCount);
      }

      const [sendGridError, sendGridStatus] =
        await EmailService.sendPersonalizationTagMail(
          mailToArray,
          subject,
          emailContent
        );
      if (sendGridError) {
        throw sendGridError;
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendTourPublishEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const getMailToArrayFromEmailArray = (projectTeam, emailArray = []) => {
  const mailToArray = [];
  for (let mail of emailArray) {
    const { firstName, lastName, email } = projectTeam.find(
      ({ email }) => email == mail
    );
    mailToArray.push({
      firstName,
      lastName,
      email,
      name: `${firstName} ${lastName}`,
    });
  }

  return mailToArray;
};
const sendPunchListSummaryEmail = async (
  mailTo,
  mailData,
  templateCode = "ET10040"
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: templateCode,
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject.replace(
        "{project}",
        mailData.projectName
      );
      emailContent = emailTemplate.body
        .replace("{project}", mailData.projectName)
        .replace("{createdAt}", mailData.createdAt)
        .replace("{assignedTo}", mailData.assignedTo)
        .replace(
          "{noOfLevel1PunchListItems}",
          mailData.noOfLevel1PunchListItems
        )
        .replace(
          "{noOfLevel2PunchListItems}",
          mailData.noOfLevel2PunchListItems
        );
      try {
        const [sendGridError, sendGridStatus] =
          await EmailService.sendPersonalizationTagMail(
            [mailTo],
            subject,
            emailContent
          );

        if (sendGridError) {
          throw sendGridError;
        } else {
          mailSentStatus = "success";
        }
      } catch (err) {
        if (err) {
          mailSentError = err;
          mailSentStatus = "failure";
          logger.error(
            "mailSentError in sendPunchListSummaryEmail method. Error: " +
              JSON.stringify(err)
          );
        }
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendPunchListSummaryEmail method. Error: " +
        JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

const sendPunchListDynamicSummaryEmail = async (
  mailTo,
  mailData,
  templateCode = "ET10041"
) => {
  let mailSentError = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: templateCode,
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject.replace(
        "{project}",
        mailData.projectName
      );
      emailContent = emailTemplate.body
        .replace("{project}", mailData.projectName)
        .replace("{createdAt}", mailData.createdAt)
        .replace("{assignedTo}", mailData.assignedTo)
        .replace("{locationInfo}", mailData.locationPunchListInfo.join(""));
      try {
        const [sendGridError, sendGridStatus] =
          await EmailService.sendPersonalizationTagMail(
            [mailTo],
            subject,
            emailContent
          );

        if (sendGridError) {
          throw sendGridError;
        } else {
          mailSentStatus = "success";
        }
      } catch (err) {
        if (err) {
          mailSentError = err;
          mailSentStatus = "failure";
          logger.error(
            "mailSentError in sendPunchListSummaryEmail method. Error: " +
              JSON.stringify(err)
          );
        }
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    logger.error(
      "mailSentError in sendPunchListSummaryEmail method. Error: " +
        JSON.stringify(err)
    );
  }
  return [mailSentError, mailSentStatus];
};

module.exports = {
  sendProcessingStartEmail,
  sendStartProcessingEmailOps,
  sendMediaTagEmail,
  sendInteriorTagEmail,
  sendNonConfirmityPunchlistEmail,
  sendConfirmityPunchlistEmail,
  sendContractReminderEmail,
  sendPunchlistUpdateEmail,
  getEPSGProjection,
  sendNonConfirmityPunchlistEmailWithReport,
  sendNonConfirmityPunchlistEmailWithTeam,
  wait,
  generateLogObject,
  generateUUID,
  getFilesFromRequest,
  getAzureSASToken,
  getTotalBlobSize,
  uploadElevationFileToBlob,
  getPayloadToSave,
  deleteElevationFileFromBlob,
  sendFIDiscussionEmail,
  sendFIWatchlistEmail,
  sendAsigneeEmail,
  sendRFIAssigneeEmail,
  sendRFIApproveAndRejectEmail,
  sendRFIWatchListEmail,
  sendFIUpdateEmail,
  sendTourPublishEmail,
  getMailToArrayFromEmailArray,
  deleteAerialTourImageFolder,
  sendPunchListSummaryEmail,
  sendPunchListDynamicSummaryEmail,
};
