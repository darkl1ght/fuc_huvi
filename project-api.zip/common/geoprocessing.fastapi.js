"use strict";

const axios = require("axios");

const {
  AERIAL_TOUR_CONTAINER_BASE_URL,
  BASE_URL,
  PORT,
  PROCESSING_PATH,
  MAP_PROCESSED_URLS_PATH,
} = require("../config").geoprocessingAPI;
const logger = require("./logger");

module.exports = {
  async startGeoprocessing(
    token,
    tourId,
    projectId,
    tourType,
    processingParams,
    imageName
  ) {
    try {
      let data;
      const url = `http://${BASE_URL}:${PORT}`;
      const path = PROCESSING_PATH.replace("{projectId}", projectId).replace(
        "{tourId}",
        tourId
      );
      const blobPath = [AERIAL_TOUR_CONTAINER_BASE_URL, tourId, imageName].join(
        "/"
      );
      const headers = {
        Authorization: `Bearer ${token}`,
      };
      const payload = {
        blob_path: blobPath,
        tour_type: tourType,
        processing_params: processingParams,
      };
      await axios
        .post(url + path, payload, {
          headers: headers,
        })
        .then((res) => {
          data = res.data;
        })
        .catch((error) => {
          logger.error(
            "Error in axios response in startGeoprocessing method. Error: " +
              JSON.stringify(error)
          );
          data = "";
        });

      return data;
    } catch (err) {
      logger.error(
        "Error in startGeoprocessing method. Error: " + JSON.stringify(err)
      );
    }
  },
  async getTourURLs(token, tourId) {
    try {
      let data;
      const url = `http://${BASE_URL}:${PORT}`;
      const path = MAP_PROCESSED_URLS_PATH.replace("{tourId}", tourId);
      const headers = {
        Authorization: `Bearer ${token}`,
      };

      await axios
        .get(url + path, {
          headers: headers,
        })
        .then((res) => {
          data = res.data;
        })
        .catch((error) => {
          logger.error(
            "Error in axios response in getTourURLs method. Error: " +
              JSON.stringify(error)
          );
          data = "";
        });

      return data;
    } catch (err) {
      logger.error(
        "Error in getTourURLs method. Error: " + JSON.stringify(err)
      );
    }
  },
};
