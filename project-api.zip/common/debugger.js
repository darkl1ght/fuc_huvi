const { redisGetJson } = require("../common/redisHelper");
const mongoose = require("mongoose");
const Debug = mongoose.model("Debug");

const debugLog = async (data) => {
  const isDebug = await redisGetJson("isDebug");

  if (typeof isDebug === "boolean" && isDebug) {
    const debugData = new Debug(data);
    debugData.save().catch(() => {});
  }
};

module.exports = { debugLog };
