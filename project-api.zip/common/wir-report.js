"use strict";
const fs = require("fs");
const PDFDocument = require("pdfkit-table");
const path = require("path");
const rootDir = path.dirname(__dirname);
const axios = require("axios");
const moment = require("moment-timezone");
const config = require("../config");
const {
  blobRawdataSMRef,
  blobContainerBaseUrl,
  blobMediaRef,
  blobSignatureRef,
} = config.azureStorage.containers;
const getAzureSASToken = require("./azure.access.token");
const { createCanvas, Image } = require("canvas");
const logger = require("./logger");

const saveForDownloadReport = async (
  data,
  projectName,
  projectLocation,
  generatedBy,
  path
) => {
  try {
    const doc = new PDFDocument({ size: "A4", margin: 50 });
    doc.pipe(fs.createWriteStream(path));

    doc.on("pageAdded", async () => {
      await generateFooter(doc, generatedBy);
      await generateHeader(doc, projectName, projectLocation);
    });

    await generateFooter(doc, generatedBy);
    await generateHeader(doc, projectName, projectLocation, generatedBy);
    await generateSummary(doc, data);

    doc.end();
  } catch (err) {
    logger.error(
      "Error in saveForDownloadReport method. Error: " + JSON.stringify(err)
    );
  }
};

const generateHeader = async (
  doc,
  projectName,
  projectLocation = "",
  generatedBy = ""
) => {
  try {
    const imagePath = path.join(rootDir, "images");
    const logo = path.join(imagePath, "logo_constra.png");

    doc
      .image(logo, 50, 30, {
        width: 200,
      })
      .fillColor("#444444")
      .fontSize(10)
      .font("Helvetica-Bold")
      .text("Project Name :", 350, 30)
      .font("Helvetica")
      .text(projectName, 460, 30);

    generateHr(doc, 65);
  } catch (err) {
    logger.error(
      "Error in generateHeader method. Error: " + JSON.stringify(err)
    );
  }
};

const generateSummary = async (doc, wir) => {
  try {
    doc.fillColor("#444444").fontSize(16).text("WIR Item Summary", 50, 100);
    generateHrTble(doc, 120);
    const customerInformationTop = 150;

    doc
      .fontSize(12)
      .font("Helvetica-Bold")
      .text("WIR No:", 50, customerInformationTop)
      .font("Helvetica")
      .text(wir.rfiNo, 200, customerInformationTop)
      .font("Helvetica-Bold")
      .text("Description:", 50, customerInformationTop + 50)
      .font("Helvetica")
      .text(
        wir.descriptionOfInspectionRequested,
        200,
        customerInformationTop + 50
      )
      .font("Helvetica-Bold")
      .text("Work Location:", 50, customerInformationTop + 100)
      .font("Helvetica")
      .text(
        wir.towerName + " - " + wir.floorName,
        200,
        customerInformationTop + 100
      )
      .font("Helvetica-Bold")
      .text("Activity Name:", 50, customerInformationTop + 150)
      .font("Helvetica")
      .text(wir.wbsDescription, 200, customerInformationTop + 150)
      .font("Helvetica-Bold")
      .text("Current Status:", 50, customerInformationTop + 200)
      .font("Helvetica")
      .text(wir.status.value, 200, customerInformationTop + 200)
      .font("Helvetica-Bold")
      .text("Created Date:", 50, customerInformationTop + 250)
      .font("Helvetica")
      .text(
        moment(wir.createdAt).tz("Asia/Kolkata").format("DD MMM, YYYY"),
        200,
        customerInformationTop + 250
      )
      .font("Helvetica-Bold")
      .text("Inspection Date:", 50, customerInformationTop + 300)
      .font("Helvetica")
      .text(
        moment(wir.inspectionDate).tz("Asia/Kolkata").format("DD MMM, YYYY"),
        200,
        customerInformationTop + 300
      )
      .font("Helvetica-Bold")
      .text("Current Assignee:", 50, customerInformationTop + 350)
      .font("Helvetica")
      .text(wir.currentAssignee.email, 200, customerInformationTop + 350)
      .font("Helvetica-Bold")
      .text("Current Assignee Role :", 50, customerInformationTop + 400)
      .font("Helvetica")
      .text(wir.currentAssignee.type, 200, customerInformationTop + 400)
      .font("Helvetica-Bold")
      .text("Work Trade :", 50, customerInformationTop + 450)
      .font("Helvetica")
      .text(wir.workTradeId, 200, customerInformationTop + 450)
      .font("Helvetica-Bold")
      .text("Additional Comments :", 50, customerInformationTop + 490)
      .font("Helvetica")
      .text(wir.additionalComments, 200, customerInformationTop + 490)
      .font("Helvetica-Bold")
      .text("Discussion:", 50, customerInformationTop + 540);
    const pageHeight = doc.page.height;
    const footerHeight = 30;
    const lineSpacing = 15;
    let charLimitPerLine = 60;
    let result = wir.discussion.replace(/&lt;[^>]+>|&nbsp;/g, " ").trim();
    let wirDiscussion = result.split("\n");
    wirDiscussion.length > 0 &&
      wirDiscussion.forEach((discussion) => {
        let words = discussion.split(" ");

        while (words.length > 0) {
          let line = "";
          while (words.length > 0) {
            let word = words[0];
            if (word.length > charLimitPerLine) {
              // handle very long word
              if (line.length == 0) {
                // if it's the first word in the line, split it
                line += word.slice(0, charLimitPerLine);
                words[0] = word.slice(charLimitPerLine);
              }
              break; // end this line
            } else if (line.length + word.length <= charLimitPerLine) {
              // handle normal word
              line += words.shift() + " ";
            } else {
              break; // end this line
            }
          }

          if (doc.y > pageHeight - footerHeight - 70) {
            doc.addPage();
            doc.y = customerInformationTop - 30;
            doc
              .fontSize(12)
              .font("Helvetica-Bold")
              .text("Discussion (cont'd):", 50, doc.y - lineSpacing);
          }

          doc
            .fontSize(12)
            .font("Helvetica")
            .text(line, 200, doc.y - lineSpacing);

          doc.moveDown();
        }
      });

    await addMediaList(doc, wir);

    await addCheckList(doc, wir);

    await addWorkflow(doc, wir);

    await addHistory(doc, wir);
  } catch (err) {
    logger.error(
      "Error in generateSummary method. Error: " + JSON.stringify(err)
    );
  }
};

const generateFooter = async (
  doc,
  generatedBy,
  signatureBlobContentId = null
) => {
  try {
    generateHr(doc, 760);

    doc.fontSize(10).text("Generated By: " + generatedBy, 50, 780, {
      align: "left",
      width: 500,
    });

    if (signatureBlobContentId) {
      const token = await getAzureSASToken(blobSignatureRef);
      const url =
        blobContainerBaseUrl +
        blobSignatureRef +
        "/" +
        signatureBlobContentId +
        "?" +
        token;

      const result = await axios.get(url, {
        responseType: "arraybuffer",
      });

      const image = new Buffer.from(result.data, "base64");

      doc.image(image, 50, 800, {
        width: 70,
        height: 30,
      });
    }

    const currentdate = new Date();
    const datetime =
      "Generated At: " +
      moment(currentdate).tz("Asia/Kolkata").format("DD MMM, YYYY");

    doc.fontSize(10).text(datetime, 50, 780, {
      align: "right",
      width: 500,
    });
  } catch (err) {
    logger.error(
      "Error in generateFooter method. Error: " + JSON.stringify(err)
    );
  }
};

const addMediaList = async (doc, wir) => {
  try {
    if (wir && wir.sitePhotos && wir.sitePhotos.length > 0) {
      let token = getAzureSASToken(blobMediaRef);

      await Promise.all(
        wir.sitePhotos.map(async (media) => {
          let url =
            blobContainerBaseUrl + blobRawdataSMRef + "/" + media.drawingId;
          try {
            const response = await axios.get(url, {
              responseType: "arraybuffer",
            });
            const data = response.data;
            const arrayBuffer = new ArrayBuffer(data.length);
            const uint8Array = new Uint8Array(arrayBuffer);
            for (let i = 0; i < data.length; i++) {
              uint8Array[i] = data[i];
            }
            const { image, width, height } = getPDFImageDimensions(arrayBuffer);
            await addMediaImage(doc, image, width, height);
          } catch (error) {
            if (error.response && error.response.status === 404) {
              const newUrl = `${blobContainerBaseUrl}${blobMediaRef}/${media.drawingId}?${token}`;
              const response = await axios.get(newUrl, {
                responseType: "arraybuffer",
              });
              const data = response.data;
              const arrayBuffer = new ArrayBuffer(data.length);
              const uint8Array = new Uint8Array(arrayBuffer);
              for (let i = 0; i < data.length; i++) {
                uint8Array[i] = data[i];
              }
              const { image, width, height } =
                getPDFImageDimensions(arrayBuffer);
              await addMediaImage(doc, image, width, height);
            } else {
              logger.error(
                "Error in fetching media. Error: " + JSON.stringify(error)
              );
            }
          }
        })
      );
    }
  } catch (err) {
    logger.error("Error in addMediaList method. Error: " + JSON.stringify(err));
  }
};

const addMediaImage = async (doc, image, width, height) => {
  try {
    if (image) {
      doc.addPage();

      doc
        .fontSize(10)
        .font("Helvetica-Bold")
        .text("WIR Images ", 70, 100)
        .font("Helvetica");

      doc.image(image, 70, 140, {
        width: (width * (height - 20)) / height,
        height: height - 20,
      });
    }
  } catch (err) {
    logger.error(
      "Error in addMediaImage method. Error: " + JSON.stringify(err)
    );
  }
};

const getPDFImageDimensions = (arrayBuffer) => {
  let image = new Buffer.from(arrayBuffer, "base64");

  const img = new Image();
  img.src = `data:image/jpeg;base64,${Buffer.from(
    arrayBuffer,
    "base64"
  ).toString("base64")}`;

  const width = img.width;
  const height = img.height;
  let newWidth;
  let newHeight;
  if (width > height) {
    const offScreenCanvas = createCanvas(width, height);
    const ctx = offScreenCanvas.getContext("2d");
    offScreenCanvas.height = width;
    offScreenCanvas.width = height;
    ctx.rotate((90 * Math.PI) / 180);
    ctx.translate(0, -offScreenCanvas.width);
    ctx.drawImage(img, 0, 0);
    image = offScreenCanvas.toDataURL("image/jpeg");
    newHeight = 630;
    newWidth = parseInt((height * newHeight) / width);
  } else if (width <= 550 && height <= 630) {
    // if width is less than 550, then any height is fine
    newHeight = height;
    newWidth = width;
  } else {
    // limiting the height and width now to specific value
    newHeight = 630;
    newWidth = parseInt((width * newHeight) / height);
  }

  return { image, height: newHeight, width: newWidth };
};

const generateHr = (doc, y) => {
  doc.strokeColor("#2d4059").lineWidth(2).moveTo(50, y).lineTo(550, y).stroke();
};

const generateHrTble = (doc, y) => {
  doc.strokeColor("#2d4059").lineWidth(1).moveTo(50, y).lineTo(550, y).stroke();
};

const addHistory = async (doc, wir) => {
  try {
    doc.addPage();
    doc.fillColor("#444444").fontSize(16).text("History", 50, 80);
    generateHrTble(doc, 100);
    doc.moveDown();
    const datas = [];
    for (let log of wir.history) {
      datas.push({
        timestamp: moment(log.createdAt)
          .tz("Asia/Kolkata")
          .format("DD-MMM-YYYY HH:mm:ss"),
        user: log.name,
        description: log.status,
      });
    }
    const table = {
      headers: [
        {
          label: "Time",
          property: "timestamp",
          width: 130,
          renderer: null,
        },
        {
          label: "Action",
          property: "description",
          width: 160,
          renderer: null,
        },
        {
          label: "User",
          property: "user",
          width: 200,
          renderer: null,
        },
      ],
      datas: datas,
    };

    doc.table(table, {
      prepareHeader: () => doc.font("Helvetica-Bold").fontSize(12),
      prepareRow: (row, indexColumn, indexRow, rectRow) => {
        doc.font("Helvetica").fontSize(12);
        indexColumn === 0 && doc.addBackground(rectRow, "#2d4059", 0.2);
      },
    });
  } catch (err) {
    logger.error("Error in addLogs method. Error: " + JSON.stringify(err));
  }
};

const addWorkflow = async (doc, wir) => {
  try {
    doc.addPage();
    doc.fillColor("#444444").fontSize(16).text("WorkFlow", 50, 80);
    generateHrTble(doc, 100);
    doc.moveDown();
    const datas = [];
    for (let log of wir.workFlow) {
      datas.push({
        role: log.name,
        user: log.approver,
        description: log.status,
      });
    }
    const table = {
      headers: [
        {
          label: "Role",
          property: "role",
          width: 130,
          renderer: null,
        },
        {
          label: "User",
          property: "user",
          width: 200,
          renderer: null,
        },
        {
          label: "Status",
          property: "description",
          width: 180,
          renderer: null,
        },
      ],
      datas: datas,
    };

    doc.table(table, {
      prepareHeader: () => doc.font("Helvetica-Bold").fontSize(12),
      prepareRow: (row, indexColumn, indexRow, rectRow) => {
        doc.font("Helvetica").fontSize(12);
        indexColumn === 0 && doc.addBackground(rectRow, "#2d4059", 0.2);
      },
    });
  } catch (err) {
    logger.error("Error in addLogs method. Error: " + JSON.stringify(err));
  }
};

const addCheckList = async (doc, wir) => {
  try {
    if (wir && wir.checkList && wir.checkList.length > 0) {
      doc.addPage();
      doc.fillColor("#444444").fontSize(16).text("Assesment", 50, 80);
      generateHrTble(doc, 100);
      doc.moveDown();
      const datas = [];
      for (let log of wir.checkList) {
        datas.push({
          question: log.question,
          status: log.status,
          description: log.comments,
        });
      }
      const table = {
        headers: [
          {
            label: "Checklist",
            property: "question",
            width: 200,
            renderer: null,
          },
          {
            label: "Status",
            property: "status",
            width: 150,
            renderer: null,
          },
          {
            label: "comments",
            property: "description",
            width: 150,
            renderer: null,
          },
        ],
        datas: datas,
      };

      doc.table(table, {
        prepareHeader: () => doc.font("Helvetica-Bold").fontSize(12),
        prepareRow: (row, indexColumn, indexRow, rectRow) => {
          doc.font("Helvetica").fontSize(12);
          indexColumn === 0 && doc.addBackground(rectRow, "#2d4059", 0.2);
        },
      });
    }
  } catch (err) {
    logger.error("Error in addLogs method. Error: " + JSON.stringify(err));
  }
};

module.exports = {
  saveForDownloadReport,
};
