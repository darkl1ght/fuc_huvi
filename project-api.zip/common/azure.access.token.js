const {
  generateBlobSASQueryParameters,
  ContainerSASPermissions,
  StorageSharedKeyCredential,
} = require("@azure/storage-blob");

const { AzureAccountName, AzureAccountKey } = require("../config").azureStorage;

const getAzureSASToken = (
  container,
  permissionString = "r",
  endTimeInSeconds = 3600
) => {
  const sharedKeyCredential = new StorageSharedKeyCredential(
    AzureAccountName,
    AzureAccountKey
  );
  // Create a SAS token that expires in an hour (default unless endTimeInSeconds is specified)
  // Set start time to five minutes ago to avoid clock skew.
  // permissionString values= "crawpd"
  const sasOptions = {
    containerName: container,
    permissions: ContainerSASPermissions.parse(permissionString),
    startsOn: new Date(new Date().valueOf() - 300 * 1000),
    expiresOn: new Date(new Date().valueOf() + (endTimeInSeconds - 300) * 1000),
  };

  const sasToken = generateBlobSASQueryParameters(
    sasOptions,
    sharedKeyCredential
  ).toString();

  return sasToken;
};

module.exports = getAzureSASToken;
