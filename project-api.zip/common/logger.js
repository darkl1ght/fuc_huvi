const path = require("path");
const { createLogger, format } = require("winston");
const { combine, timestamp, printf } = format;
const DailyRotateFile = require("winston-daily-rotate-file");

const rotateTransport = new DailyRotateFile({
  filename: "project-api-%DATE%",
  datePattern: "YYYY-MM-DD",
  zippedArchive: true,
  maxSize: "50m",
  maxFiles: "30d",
  utc: true,
  extension: ".log",
  dirname: path.join(path.dirname(__dirname), "logs"),
  level: process.env.NODE_ENV === "production" ? process.env.LOG_LEVEL : "info",
});

const exceptionTransport = new DailyRotateFile({
  filename: "exception-%DATE%",
  datePattern: "YYYY-MM-DD",
  zippedArchive: true,
  maxSize: "50m",
  maxFiles: "30d",
  utc: true,
  extension: ".log",
  dirname: path.join(path.dirname(__dirname), "logs"),
});

const winstonLogger = createLogger({
  level:
    process.env.NODE_ENV === "production" ? process.env.LOG_LEVEL : "error",
  format: combine(
    timestamp(),
    printf(({ timestamp, level, message }) => {
      return `${timestamp}|${level.padEnd(5, " ")}|${message}`;
    })
  ),
  handleExceptions: true,
  transports: [rotateTransport],
  exceptionHandlers: [exceptionTransport],
  exitOnError: false,
});

winstonLogger.stream = {
  write: (message, encoding) => {
    const status = message.substring(message.length - 4, message.length - 3);
    status === "4" || status === "5"
      ? winstonLogger.error(message.trim())
      : winstonLogger.info(message.trim());
  },
};

module.exports = winstonLogger;
