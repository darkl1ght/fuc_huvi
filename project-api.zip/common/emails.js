"use strict";

const SendGridMail = require("@sendgrid/mail");
const fromEmail = require("../config").email.fromEmail;
const sendGridKey = require("../config").email.sendGridKey;
const logger = require("./logger");
const _ = require("lodash");
SendGridMail.setApiKey(sendGridKey);

const EmailService = {};

EmailService.sendMail = async (mailTo, subject, emailContent) => {
  try {
    let sendGridStatus;
    let sendGridError = null;
    const to = [];
    for (let user of mailTo) {
      to.push(`${user.name}<${user.email}>`);
    }
    const message = {
      to: to,
      from: fromEmail,
      subject: subject,
      html: emailContent,
    };

    await (async () => {
      try {
        await SendGridMail.send(message).then(() => {
          sendGridStatus = "success";
        });
      } catch (error) {
        sendGridError = error;
        if (error.response) {
          console.error(error.response.body);
        }
      }
    })();

    return [sendGridError, sendGridStatus];
  } catch (err) {
    logger.error("Error in sendMail method. Error: " + JSON.stringify(err));
  }
};

EmailService.sendPersonalizationTagMail = async (
  mailTo,
  subject,
  emailContent
) => {
  try {
    let sendGridStatus;
    let sendGridError = null;
    const messages = [];
    const uniqueMailTo = _.uniqBy(mailTo, "email");
    for (let user of uniqueMailTo) {
      messages.push({
        to: user.name ? `${user.name}<${user.email}>` : user.email,
        subject: subject,
        from: fromEmail,
        html: emailContent.replace("{user}", user.firstName),
        // .replace(`${user.email}`, `<strong>${user.email}</strong>`),
      });
    }

    await (async () => {
      try {
        await SendGridMail.send(messages).then(() => {
          sendGridStatus = "success";
        });
      } catch (error) {
        sendGridError = error;
        if (error.response) {
          console.error(error.response.body);
          logger.error(
            "Error in SendGridMail response in sendPersonalizationTagMail method. Error: " +
              JSON.stringify(error)
          );
        }
      }
    })();

    return [sendGridError, sendGridStatus];
  } catch (err) {
    logger.error(
      "Error in sendPersonalizationTagMail method. Error: " +
        JSON.stringify(err)
    );
  }
};

EmailService.sendContractReminderEmail = async (
  mailTo,
  mailCc,
  mailBcc,
  fromEmail,
  subject,
  emailContent
) => {
  try {
    let sendGridStatus;
    let sendGridError = null;
    const messages = [
      {
        to: mailTo,
        cc: mailCc,
        bcc: mailBcc,
        subject: subject,
        from: fromEmail,
        html: emailContent,
      },
    ];

    await (async () => {
      try {
        await SendGridMail.send(messages).then(() => {
          sendGridStatus = "success";
        });
      } catch (error) {
        sendGridError = error;
        if (error.response) {
          console.error(error.response.body);
          logger.error(
            "Error in SendGridMail response in sendContractReminderEmail method. Error: " +
              JSON.stringify(error)
          );
        }
      }
    })();

    return [sendGridError, sendGridStatus];
  } catch (err) {
    logger.error(
      "Error in sendContractReminderEmail method. Error: " + JSON.stringify(err)
    );
  }
};

module.exports = EmailService;
