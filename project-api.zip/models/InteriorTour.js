"use strict";

const mongoose = require("mongoose");
const { stringify } = require("qs");

const InteriorTourSchema = new mongoose.Schema(
  {
    interiorId: String,
    projectId: String,
    interiorName: String,
    interiorDate: String,
    status: {},
    tours: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "TourImage",
      },
    ],
    staticMap: {
      charts: [],
      urls: [{ tourId: String, tourName: String, tourUrl: String }],
    },
    floorWalkthough: [
      {
        towerId: String,
        interiorId: String,
        towerName: String,
        captureDate: Date,
        orderNo: Number,
        tours: [
          {
            type: mongoose.Schema.Types.ObjectId,
            ref: "TourImage",
          },
        ],
        bim: {
          forgeObject: {
            urn: String,
            name: String,
          },
          levels: Array,
          offset: Object,
          trasformationScale: Number,
        },
      },
    ],
    mapType: String,
    isPannellum: Boolean,
    tagList: [
      {
        type: String,
      },
    ],
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("InteriorTour", InteriorTourSchema);
