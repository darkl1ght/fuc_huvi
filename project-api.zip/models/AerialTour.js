"use strict";

const mongoose = require("mongoose");

const AerialTourSchema = new mongoose.Schema(
  {
    tourId: String,
    projectId: String,
    tourName: String,
    tourDate: String,
    threeDUrl: String,
    status: {},
    images: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "AerialImage",
      },
    ],
    charts: [],
    remarks: [],
    punchItemMarkers: [],
    droneFlightData: [],
    droneFlightVideoData: [],
    isPublished: Boolean,
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
    staticMap: {
      charts: [],
      urls: [{ tourId: String, tourName: String, tourUrl: String }],
    },
    mapType: String,
    mapUrls: [
      // {
      //   type: String,
      //   key: String,
      //   value: String,
      //   appendIndex: Number,
      // },
    ],
    annotations: [],
    legend: Object,
    processingParams: Object,
    tourCategory: String,
    lat: Number,
    lng: Number,
    isSelfServe: Boolean,
    isWBSPublished: Boolean,
    isDashboardPublished: Boolean,
    annotationTypes: [],
    tagList: [
      {
        type: String,
      },
    ],
    objectCount: Number,
    planned: Number,
    actual: Number,
  },
  {
    timestamps: true,
  }
);

mongoose.model("AerialTour", AerialTourSchema);
