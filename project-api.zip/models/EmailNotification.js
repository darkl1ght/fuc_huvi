"use strict";
const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const emailNotificationSchema = new Schema(
  {
    from: String,
    to: String,
    cc: String,
    bcc: String,
    subject: String,
    body: String,
    templateCode: String,
    additionalInfo: Object,
    status: String,
    comments: String,
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

module.exports = model("EmailNotification", emailNotificationSchema);
