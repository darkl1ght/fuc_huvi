"use strict";

const mongoose = require("mongoose");

const ProjectUserSchema = new mongoose.Schema(
  {
    memberId: String,
    firstName: String,
    lastName: String,
    contact: String,
    email: String,
    role: {
      code: String,
      desc: String,
    },
    isBlocked: Boolean,
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
    signature: Object,
  },
  {
    timestamps: true,
  }
);

mongoose.model("ProjectUser", ProjectUserSchema);
