"use strict";
const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const debugSchema = new Schema(
  {
    module: String,
    file: String,
    function: String,
    message: String,
    error: String,
    data: Object,
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

module.exports = model("Debug", debugSchema);
