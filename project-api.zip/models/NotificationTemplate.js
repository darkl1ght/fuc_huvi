"use strict";
const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const notificationTemplateSchema = new Schema({
  code: String,
  title: String,
  body: String,
});

module.exports = model("NotificationTemplate", notificationTemplateSchema);
