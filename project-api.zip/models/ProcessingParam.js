"use strict";

const mongoose = require("mongoose");

const ProcessingParamSchema = new mongoose.Schema({
  tourType: String,
  config: Object,
});

mongoose.model("ProcessingParam", ProcessingParamSchema);
