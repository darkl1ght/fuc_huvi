"use strict";

const mongoose = require("mongoose");
const InteriorChartSchema = new mongoose.Schema(
  {
    interiorId: String,
    tourId: String,
    towerId: String,
    floorId: String,
    sCurve: [
      {
        captureId: String,
        captureDate: Date,
        plannedProgress: Number,
        actualProgress: Number,
      },
    ],
    barChart: [
      {
        wbsName: String,
        plannedProgress: Number,
        actualProgress: Number,
        comment: String,
      },
    ],
  },
  {
    timestamps: true,
  }
);

mongoose.model("InteriorChart", InteriorChartSchema);
