"use strict";
const mongoose = require("mongoose");

const InspectionCheckListSchema = new mongoose.Schema(
  {
    projectId: String,
    inspectionId: String,
    checkListName: String,
    questionnaire: { type: Array, default: [] },
    activities: { type: Array, default: [] },
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("InspectionCheckList", InspectionCheckListSchema);
