"use strict";

const mongoose = require("mongoose");

const ProcoreIntegrationSchema = new mongoose.Schema(
  {
    companyId: Number,
    companyName: String,
    projectId: Number,
    projectName: String,
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

const ProjectSchema = new mongoose.Schema(
  {
    projectId: {
      type: String,
      unique: true,
    },
    clientId: String,
    projectAdmin: String,
    projectName: {
      type: String,
      required: [true, "can't be blank"],
    },
    location: String,
    lat: Number,
    lng: Number,
    type: {
      code: String,
      desc: String,
    },
    isActive: Boolean,
    users: [],
    interiors: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "InteriorTour",
      },
    ],
    documents: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Document",
      },
    ],
    devices: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Device",
      },
    ],
    task: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "ProjectTask",
      },
    ],
    aerialTours: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "AerialTour",
      },
    ],
    album: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "ProjectAlbum",
      },
    ],
    procoreIntegration: {
      type: ProcoreIntegrationSchema,
    },
    annotationTypes: [],
    processingParams: Object,
    tourCategory: String,
    isCompleted: Boolean,
    contractEndDate: Date,
    isSelfServe: Boolean,
    isExteriorWBSPublished: Boolean,
    isInteriorWBSPublished: Boolean,
    isUnitLevel: Boolean,
    forgeBucketKey: String,
    createdBy: String,
    updatedBy: String,
    virtualVideoCaptureDurationLimit: Number,
    excludeSendEmailForSnag: Boolean,
    emailGroupingForSnag: Number,
    excludeCaptureDateForInterior: Boolean,
  },
  {
    timestamps: true,
  }
);

// Requires population of author
ProjectSchema.methods.toJSONForMap = function () {
  return {
    id: this._id,
    projectName: this.projectName,
    projectId: this.projectId,
    location: this.location,
    users: this.users,
    isCompleted: this.isCompleted ? "Completed" : "Active",
    contractEndDate: this.contractEndDate,
    type: this.type.desc,
    lat: this.lat,
    lng: this.lng,
    isSelfServe: this.isSelfServe,
    forgeBucketKey: this.forgeBucketKey,
    updatedAt: this.updatedAt,
    clientId: this.clientId,
    interiors: this.interiors,
    aerialTours: this.aerialTours,
    virtualVideoCaptureDurationLimit:
      this.virtualVideoCaptureDurationLimit || 14,
  };
};

ProjectSchema.methods.projectsAndInteriorsToJSON = function () {
  return {
    id: this._id,
    projectName: this.projectName,
    projectId: this.projectId,
    location: this.location,
    type: this.type.desc,
    lat: this.lat,
    lng: this.lng,
    isSelfServe: this.isSelfServe,
    forgeBucketKey: this.forgeBucketKey,
    updatedAt: this.updatedAt,
    interiors: this.interiors,
  };
};

mongoose.model("Project", ProjectSchema);
