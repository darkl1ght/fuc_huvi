"use strict";

const mongoose = require("mongoose");

const UserRequestSchema = new mongoose.Schema(
  {
    url: String,
    ip: String,
    time: Date,
    host: String,
    method: String,
    email: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("UserRequest", UserRequestSchema);
