"use strict";

const mongoose = require("mongoose");

const wbsItemSchema = new mongoose.Schema(
  {
    wbsId: String,
    description: String,
    startDate: String,
    finishDate: String,
    duration: Number,
    weightage: String,
    planned: Number,
    actual: Number,
    comment: String,
    createdBy: String,
    updatedBy: String,
  },
  { timestamps: true }
);

const ExteriorCaptureSchema = new mongoose.Schema(
  {
    captureId: String,
    tourId: String,
    captureDate: Date,
    towerId: String,
    projectId: String,
    projectDuration: Number,
    captureInterval: Number,
    projectStartDate: Date,
    projectFinishDate: Date,
    isActualPublished: Boolean,
    wbsItem: [
      {
        type: wbsItemSchema,
      },
    ],
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("ExteriorCapture", ExteriorCaptureSchema);
