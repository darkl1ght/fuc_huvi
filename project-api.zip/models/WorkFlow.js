const mongoose = require("mongoose");

const WorkFlowSchema = new mongoose.Schema(
  {
    projectId: String,
    workFlowId: String,
    name: String,
    orderNo: Number,
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("WorkFlow", WorkFlowSchema);
