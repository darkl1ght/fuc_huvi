"use strict";

const mongoose = require("mongoose");

const ExteriorTourSchema = new mongoose.Schema(
  {
    activityId: String,
    projectId: String,
    activityName: String,
    activityDate: String,
    status: {},
    charts: [],
    images: [],
    isPublished: Boolean,
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("ExteriorTour", ExteriorTourSchema);
