"use strict";

const mongoose = require("mongoose");
const ClientSchema = new mongoose.Schema(
  {
    clientId: {
      type: String,
      unique: true,
    },
    email: {
      type: String,
      unique: true,
    },
    firstName: String,
    lastName: String,
    clientName: {
      type: String,
      required: [true, "can't be blank"],
    },
    projects: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Project",
      },
    ],
    blobContentId: String,
    isActive: Boolean,
    isCustomIntegration: { type: Boolean, default: false },
    siteAdmins: [String],
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("Client", ClientSchema);
