"use strict";
const mongoose = require("mongoose");

const RfiSchema = new mongoose.Schema(
  {
    projectId: String,
    rfiId: String,
    rfiNo: String,
    inspectionDate: String,
    inspectionTime: String,
    wbsId: String,
    wbsDescription: String,
    workTradeId: String,
    towerId: String,
    towerName: String,
    floorId: String,
    floorName: String,
    unitId: String,
    unitName: String,
    sectionOfSpecification: String,
    drawingNumber: String,
    descriptionOfInspectionRequested: String,
    workFlow: { type: Array, default: [] },
    checkList: { type: Array, default: [] },
    history: { type: Array, default: [] },
    watchList: { type: Array, default: [] },
    sitePhotos: { type: Array, default: [] },
    discussion: String,
    additionalComments: String,
    currentAssignee: {},
    status: {},
    createdBy: String,
    updatedBy: String,
    isActive: Boolean,
  },
  {
    timestamps: true,
  }
);

mongoose.model("Rfi", RfiSchema);
