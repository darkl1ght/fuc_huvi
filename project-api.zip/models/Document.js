"use strict";

const mongoose = require("mongoose");

const DocumentSchema = new mongoose.Schema(
  {
    documentId: String,
    blobDocId: String,
    projectId: String,
    name: String,
    size: String,
    tagList: [
      {
        type: String,
      },
    ],
    isActive: Boolean,
    history: [
      {
        blobDocId: String,
        name: String,
        size: String,
        lastUpdated: String,
        updatedAt: String,
      },
    ],
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("Document", DocumentSchema);
