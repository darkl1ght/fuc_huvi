"use strict";

const mongoose = require("mongoose");

const ProcessingStatisticSchema = new mongoose.Schema(
  {
    tour_id: String,
    project_id: String,
    current_status: String,
    machine: String,
    temp_machine: String,
    overall_processing_time: String,
    overall_processing_status: String,
    processing_params: Object,
    map_urls: [
      {
        type: String,
        key: String,
        value: String,
        appendIndex: Number,
      },
    ],
    events: [
      {
        description: String,
        status: String,
        time: String,
      },
    ],
    payload: String,
    config: String,
    last_dem_built: String,
  },
  {
    timestamps: true,
  }
);

ProcessingStatisticSchema.methods.toJSONFor = function () {
  return {
    id: this._id,
    tour_id: this.tour_id,
    project_id: this.project_id,
    current_status: this.current_status,
    machine: this.machine,
    overall_processing_time: this.overall_processing_time,
    overall_processing_status: this.overall_processing_status,
    map_urls: this.map_urls,
    processing_params: this.processing_params,
    events: this.events,
    payload: this.payload,
    config: this.config,
    last_dem_built: this.last_dem_built,
  };
};

mongoose.model("ProcessingStatistic", ProcessingStatisticSchema);
