"use strict";

const mongoose = require("mongoose");

const DeepLinkSchema = new mongoose.Schema(
  {
    objectId:  {
      type: String,
      required: [true, "can't be blank"],
    },
    moduleName: {
      type: String,
      required: [true, "can't be blank"],
    },
    shareId: {
      type: String,
      required: [true, "can't be blank"],
    },
    shareInfo: {
       type: Object,
      required: [true, "can't be blank"],
    },
    isActive: { type: Boolean, default: true },
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("DeepLink", DeepLinkSchema);
