"use strict";

const mongoose = require("mongoose");
const CaptureAppLogSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: [true, "can't be blank"],
    },
    method: {
      type: String,
      required: [true, "can't be blank"],
    },
    logDate: {
      type: String,
      required: [true, "can't be blank"],
    },
    logInfo: {
      type: String,
      required: [true, "can't be blank"],
    },
    additionalInfo: {
      type: String,
      required: [true, "can't be blank"],
    },
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("CaptureAppLog", CaptureAppLogSchema);
