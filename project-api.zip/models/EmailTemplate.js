"use strict";

const mongoose = require("mongoose");

const EmailTemplate = new mongoose.Schema({
  code: String,
  subject: String,
  body: String,
  to: [{ name: String, email: String }],
  cc: [{ name: String, email: String }],
  bcc: [{ name: String, email: String }],
  fieldTemplate: Object,
});

mongoose.model("EmailTemplate", EmailTemplate);
