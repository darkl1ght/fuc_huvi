"use strict";

const mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate-v2");

const OnsiteTaskSchema = new mongoose.Schema(
  {
    taskId: String,
    punchId: String,
    punchListId: String,
    projectId: String,
    taskDescription: String,
    remark: String,
    workLocation: {
      locationId: String,
      level1: String,
      level2: String,
      level3: String,
      level4: String,
    },
    workPackage: {
      tradeId: String,
      tradeName: String,
    },
    mediaList: [
      {
        mediaId: String,
        blobReference: String,
        fileName: String,
        features: Object,
        mediaCreateDate: String,
        state: { type: String, default: "created" },
        maState: Object,
      },
    ],
    isNonConformity: Boolean,
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
    logs: [],
  },
  { timestamps: true }
);

OnsiteTaskSchema.plugin(mongoosePaginate);

mongoose.model("OnsiteTask", OnsiteTaskSchema);
