"use strict";

const mongoose = require("mongoose");

const ProjectMediaSchema = new mongoose.Schema(
  {
    mediaId: String,
    projectId: String,
    mediaName: String,
    mediaDescription: String,
    fileDate: String,
    blobContentId: String,
    albumId: String,
    mediaType: {},
    videoSource: {
      isVimeo: Boolean,
      vimeoId: String,
    },
    tags: [],
    comments: [
      {
        commentId: String,
        comment: String,
        createdAt: String,
        createdBy: String,
      },
    ],
    meta: {},
    features: Object,
    annotations: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "MediaAnnotation",
      },
    ],
    isActive: Boolean,
    isPublished: Boolean,
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("ProjectMedia", ProjectMediaSchema);
