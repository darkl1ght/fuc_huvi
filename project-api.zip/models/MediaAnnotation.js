"use strict";

const mongoose = require("mongoose");

const MediaAnnotationSchema = new mongoose.Schema(
  {
    annotationId: String,
    mediaId: String,
    annotationTitle: String,
    description: String,
    tags: [],
    shape: {},
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("MediaAnnotation", MediaAnnotationSchema);
