"use strict";
const mongoose = require("mongoose");
const WorkScheduleSchema = new mongoose.Schema(
  {
    captureInterval: Number,
    startDate: Date,
    finishDate: Date,
    projectId: String,
    wbsList: [
      {
        activityName: String,
        taskType: String,
        location: String,
        taskStart: Date,
        taskEnd: Date,
        category: String,
        classification:String
      },
    ],
    isUnitLevel:Boolean,
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("WorkSchedule", WorkScheduleSchema);
