"use strict";

const mongoose = require("mongoose");

const wbsItemSchema = new mongoose.Schema(
  {
    wbsId: String,
    description: String,
    startDate: String,
    finishDate: String,
    duration: Number,
    weightage: String,
    planned: Number,
    actual: Number,
    comment: String,
    category: String,
    classification: String,
    createdBy: String,
    updatedBy: String,
  },
  { timestamps: true }
);

const InteriorCaptureSchema = new mongoose.Schema(
  {
    captureId: String,
    tourId: String,
    captureDate: Date,
    projectId: String,
    interiorId: String,
    towerId: String,
    floorId: String,
    unitId: String,
    projectDuration: Number,
    captureInterval: Number,
    projectStartDate: Date,
    projectFinishDate: Date,
    isActualPublished: Boolean,
    wbsItem: [
      {
        type: wbsItemSchema,
      },
    ],
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("InteriorCapture", InteriorCaptureSchema);
