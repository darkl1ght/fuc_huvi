"use strict";

const mongoose = require("mongoose");

const DeletedTourFeatureSchema = new mongoose.Schema(
  {
    projectId: String,
    tourId: String,
    features: [],
    deletedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("DeletedTourFeature", DeletedTourFeatureSchema);
