"use strict";
const mongoose = require("mongoose");
const { Schema, model } = mongoose;
const uuid = require("uuid");

const tokenSchema = new Schema({
  _id: false,
  appType: {
    key: String,
    value: String,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  deviceId: String,
  token: String,
});

const notificationMasterDataSchema = new Schema(
  {
    userId: {
      type: String,
      default: uuid.v4(),
    },
    userEmail: String,
    tokens: [tokenSchema],
  },
  { timestamps: true }
);

module.exports = model("NotificationMasterData", notificationMasterDataSchema);
