"use strict";

const mongoose = require("mongoose");

const FieldIssueSchema = new mongoose.Schema(
  {
    issueId: String,
    issueNumber: String,
    tourId: String,
    projectId: String,
    towerId: String,
    floorId: String,
    interiorId: String,
    status: String,
    priority: String,
    dueDate: String,
    description: String,
    wbsLinks: Array,
    assignee: String,
    workTrade: Object,
    watchList: Array,
    tags: Array,
    discussion: [
      {
        discussionId: String,
        from: String,
        createdAt: String,
        updatedAt: String,
        content: String,
        mention: Array,
        isEdited: Boolean,
        isEditedByUser: Boolean,
        isDeleted: Boolean,
      },
    ],
    hotspot: Object,
    snapshot: Object,
    attachments: [{ type: String, name: String, size: Number }],
    createdBy: String,
    updatedBy: String,
    currentImageId: String,
    maState: Object,
  },
  {
    timestamps: true,
  }
);

mongoose.model("FieldIssue", FieldIssueSchema);
