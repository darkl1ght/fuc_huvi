"use strict";

const mongoose = require("mongoose");

const DeviceSchema = new mongoose.Schema(
  {
    deviceId: String,
    deviceName: String,
    projectId: String,
    deviceType: {},
    recording: Boolean,
    isActive: Boolean,
    rtmpUrl: String,
    upTime: Number,
    bytesInRate: Number,
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("Device", DeviceSchema);
