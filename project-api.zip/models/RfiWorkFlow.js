const mongoose = require("mongoose");

const RfiWorkFlowSchema = new mongoose.Schema(
  {
    projectId: String,
    rfiId: String,
    name: String,
    orderNo: Number,
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("RfiWorkFlow", RfiWorkFlowSchema);
