"use strict";

const mongoose = require("mongoose");

const InteriorImageSchema = new mongoose.Schema(
  {
    imageId: String,
    blobImageId: String,
    imageName: String,
    imageBlobUrl: String,
    offsetFromNorth: Number,
    linkage: [],
    createdBy: String,
    createdAt: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("InteriorImage", InteriorImageSchema);
