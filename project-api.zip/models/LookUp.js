"use strict";

const mongoose = require("mongoose");

const LookUpSchema = new mongoose.Schema(
  {
    type: String,
    key: String,
    value: String,
  },
  {
    timestamps: true,
  }
);

LookUpSchema.methods.toJSONFor = function () {
  return {
    id: this._id,
    type: this.type,
    key: this.key,
    value: this.value,
  };
};

mongoose.model("LookUp", LookUpSchema);
