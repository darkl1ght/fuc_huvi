"use strict";

const mongoose = require("mongoose");

const VideoCaptureSchema = new mongoose.Schema(
  {
    rawVideoStorageRefs: [String],
    mediaBlobContentId: String,
    captureStartPoint: { x: Number, y: Number },
    captureEndPoint: { x: Number, y: Number },
    exportedCoordinates: [],
  },
  { _id: false }
);

const TourImageSchema = new mongoose.Schema(
  {
    tourId: String,
    isWBSPublished: Boolean,
    isSelfServe: Boolean,
    isDashboardPublished: Boolean,
    interiorId: String,
    projectId: String,
    towerId: String,
    locationId: String,
    tourName: String,
    floorPlanBlobId: String,
    floorPlanOrientation: Number,
    remarks: [],
    charts: [],
    images: [],
    aecLevel: Object,
    transformationScale: Number,
    bimAngularDeviationFromTrueNorth: Number,
    orderNo: Number,
    origin: Object,
    isPublished: Boolean,
    features: Object,
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
    tourPublishDate: String,
    videoCaptureDetails: VideoCaptureSchema,
    lastFieldIssueNumber: Number,
  },
  {
    timestamps: true,
  }
);

mongoose.model("TourImage", TourImageSchema);
