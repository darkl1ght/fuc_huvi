const mongoose = require("mongoose");

const VideoProcessingQueueSchema = new mongoose.Schema(
  {
    mediaId: String,
    projectId: String,
    albumId: String,
    blobContentId: String,
    status: String,
    meta: {},
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("VideoProcessingQueue", VideoProcessingQueueSchema);
