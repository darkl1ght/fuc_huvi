const mongoose = require("mongoose");

const WorkLocationSchema = new mongoose.Schema(
  {
    locationId: String,
    parentLocationId: String,
    orderNo: Number,
    drawing: {
      drawingId: String,
      drawingName: String,
      blobContentId: String,
      floorPlanOrientation: Number,
    },
    bim: {
      forgeObject: {
        name: String,
        urn: String,
      },
      levels: Array,
      offset: Object,
      modelBound: { type: Object, default: null },
      bimAngularDeviationFromTrueNorth: Number,
      transformationScale: Number,
      uploadedBy: String,
      uploadedAt: Date,
    },
    floorplanMarkerPositions: { type: Array, default: [] },
    isAecLevelsFetched: { type: Boolean, default: false },
    aecLevel: Object,
    level1: String,
    level2: String,
    level3: String,
    level4: String,
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("WorkLocation", WorkLocationSchema);
