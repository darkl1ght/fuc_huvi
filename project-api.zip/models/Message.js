class Message {
  constructor(type, content) {
    this.type = type;
    this.message = {
      ...content,
    };
  }
}

module.exports = Message;
