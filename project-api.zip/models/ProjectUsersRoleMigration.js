"use strict";

const mongoose = require("mongoose");

//TBD: To be removed
const ProjectUsersRoleMigrationSchema = new mongoose.Schema(
  {
    projectId: String,
    projectName: String,
    users: [],
    isMigrated: Boolean
  },
  {
    timestamps: true,
  }
);

mongoose.model("ProjectUsersRoleMigration", ProjectUsersRoleMigrationSchema);