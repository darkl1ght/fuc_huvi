const mongoose = require("mongoose");

const MapVolumeSchema = new mongoose.Schema(
  {
    volumeUniqueId: String,
    label: String,
    volume: Object,
    polygonGeojson: Object,
    pointGeojson: Object,
    tourId: String,
    projectId: String,
    machineId: String,
    tourType: String,
    status: String,
    createdBy: String,
    isSurfaceElevationRequest: { type: Boolean, default: false },
    surfaceElevation: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("MapVolume", MapVolumeSchema);
