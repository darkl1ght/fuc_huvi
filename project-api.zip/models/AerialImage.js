"use strict";

const mongoose = require("mongoose");

const AerialImageSchema = new mongoose.Schema(
  {
    imageId: String,
    blobImageId: String,
    imageName: String,
    meta: {},
    createdBy: String,
    createdAt: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("AerialImage", AerialImageSchema);
