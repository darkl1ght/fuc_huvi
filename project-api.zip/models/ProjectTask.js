"use strict";

const mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate-v2");

const ProjectTaskSchema = new mongoose.Schema(
  {
    taskId: String,
    punchId: String,
    punchListId: String,
    projectId: String,
    tourId: String,
    taskDescription: String,
    remark: String,
    workLocation: {
      locationId: String,
      level1: String,
      level2: String,
      level3: String,
      level4: String,
    },
    workPackage: {
      tradeId: String,
      tradeName: String,
    },
    taskPriority: {},
    level1Users: [],
    level2Users: [],
    level1Status: {
      status: {},
      comment: String,
      verifiedBy: String,
    },
    level2Status: {
      status: {},
      comment: String,
      verifiedBy: String,
    },
    dueDate: String,
    mediaList: [
      {
        mediaId: String,
        blobReference: String,
        fileName: String,
        features: Object,
        mediaCreateDate: String,
        state: { type: String, default: "created" },
        maState: Object,
      },
    ],
    punchItemMarkerId: String,
    punchItemMarkerLat: String,
    punchItemMarkerLng: String,
    punchItemPolygonMarkerId: String,
    markerType: String,
    floorPlan: {
      blobReference: String,
      features: Object,
      latestSnapshotBlobId: String,
    },
    tags: [],
    comments: [
      {
        commentId: String,
        body: String,
        createdAt: String,
        createdByName: String,
        createdByEmail: String,
      },
    ],
    isNonConformity: Boolean,
    taskStatus: {},
    action: {
      rootCause: String,
      dueDate: String,
      action: String,
    },
    isActive: Boolean,
    createdBy: String,
    updatedBy: String,
    logs: [],
  },
  { timestamps: true }
);

ProjectTaskSchema.plugin(mongoosePaginate);

mongoose.model("ProjectTask", ProjectTaskSchema);
