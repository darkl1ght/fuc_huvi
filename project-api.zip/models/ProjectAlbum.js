"use strict";

const mongoose = require("mongoose");

const ProjectAlbumSchema = new mongoose.Schema(
  {
    albumId: String,
    albumName: {
      type: String,
      required: [true, "can't be blank"],
    },
    albumDate: String,
    media: [],
    projectId: String,
    isActive: Boolean,
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("ProjectAlbum", ProjectAlbumSchema);
