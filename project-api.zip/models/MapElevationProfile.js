const mongoose = require("mongoose");

const MapElevationProfileSchema = new mongoose.Schema(
  {
    elevationProfileUniqueId: String,
    lineString: Object,
    label: String,
    tourId: String,
    projectId: String,
    machineId: String,
    tourType: String,
    status: String,
    createdBy: String,
    resolution: String,
    elevProfileChartInfo: Object,
  },
  {
    timestamps: true,
  }
);

mongoose.model("ElevationProfile", MapElevationProfileSchema);
