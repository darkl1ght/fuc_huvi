"use strict";

const mongoose = require("mongoose");

const ProjectChartSchema = new mongoose.Schema(
  {
    chartId: String,
    chartTitle: String,
    chartType: String,
    chartData: Object,
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("ProjectChart", ProjectChartSchema);
