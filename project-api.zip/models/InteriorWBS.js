"use strict";

const mongoose = require("mongoose");

const InteriorWBSSchema = new mongoose.Schema(
  {
    projectId: String,
    towerId: String,
    floorId: String,
    unitId:String,
    projectDuration: Number,
    captureInterval: Number,
    projectStartDate: Date,
    projectFinishDate: Date,
    isActualPublished: Boolean,
    wbsList: [
      {
        wbsId: String,
        description: String,
        startDate: String,
        finishDate: String,
        duration: Number,
        weightage: String,
        planned: Number,
        actual: Number,
        comment: String,
        category: String,
        classification: String,
      },
    ],
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("InteriorWBS", InteriorWBSSchema);
