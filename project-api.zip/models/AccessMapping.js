"use strict";

const mongoose = require("mongoose");

const AccessSchema = new mongoose.Schema({
  objectKey: String,
  desc: String,
  module: String,
  type: String,
  isAllowed: { type: Boolean, default: false },
  isRedactable: { type: Boolean, default: false },
  isRedacted: { type: Boolean, default: false },
  isAdminOnly: { type: Boolean, default: false },
  createdBy: String,
  updatedBy: String,
},
  {
    timestamps: true,
  }
);

const AccessMappingSchema = new mongoose.Schema(
  {
    role: String,
    desc: String,
    isActive: Boolean,
    accessMapping: [
      {
        type: AccessSchema,
      }
    ],
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("AccessMapping", AccessMappingSchema);