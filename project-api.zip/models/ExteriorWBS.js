// "use strict";

// const mongoose = require("mongoose");

// const ExteriorWBSSchema = new mongoose.Schema(
//   {
//     projectId: String,
//     towerId: String,
//     projectDuration: Number,
//     captureInterval: Number,
//     projectStartDate: Date,
//     projectFinishDate: Date,
//     isActualPublished: Boolean,
//     wbsList: [
//       {
//         wbsId: String,
//         description: String,
//         startDate: String,
//         finishDate: String,
//         duration: Number,
//         weightage: String,
//         plannedCapture: [
//           {
//             captureId: String,
//             captureDate: Date,
//             progress: Number,
//             isDataCaptureDone: Boolean,
//           },
//         ],
//         actualCapture: [
//           {
//             captureId: String,
//             tourId: String,
//             captureDate: Date,
//             progress: Number,
//             comment: String,
//           },
//         ],
//         createdBy: String,
//         updatedBy: String,
//       },
//     ],
//     createdBy: String,
//   },
//   {
//     timestamps: true,
//   }
// );

// mongoose.model("ExteriorWBS", ExteriorWBSSchema);

"use strict";

const mongoose = require("mongoose");

const ExteriorWBSSchema = new mongoose.Schema(
  {
    projectId: String,
    towerId: String,
    projectDuration: Number,
    captureInterval: Number,
    projectStartDate: Date,
    projectFinishDate: Date,
    isActualPublished: Boolean,
    wbsList: [
      {
        wbsId: String,
        description: String,
        startDate: String,
        finishDate: String,
        duration: Number,
        weightage: String,
        planned: Number,
        actual: Number,
        comment: String,
      },
    ],
    createdBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("ExteriorWBS", ExteriorWBSSchema);
