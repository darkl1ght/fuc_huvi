"use strict";

const mongoose = require("mongoose");

const VirtualTourProcessingStatsSchema = new mongoose.Schema(
  {
    tourId: String,
    projectId: String,
    interiorId: String,
    towerId: String,
    processingMachine: String,
    isProcessingComplete: { type: Boolean, default: false },
    processTriggeredBy: String,
    processingTime: String,
    events: { type: [new mongoose.Schema({ type: String })] },
    startTime: String,
    endTime: String,
    status: {},
    authToken: String
  },
  {
    timestamps: true,
  }
);

VirtualTourProcessingStatsSchema.methods.toJSONFor = function () {
  return {
    id: this._id,
    tourId: this.tourId,
    projectId: this.projectId,
    interiorId: this.interiorId,
    towerId: this.towerId,
    processingMachine: this.processingMachine,
    isProcessingComplete: this.isProcessingComplete,
    processTriggeredBy: this.processTriggeredBy,
    processingTime: this.processingTime,
    events: this.events,
    startTime: this.startTime,
    endTime: this.endTime,
    status: this.status,
  };
};

module.exports.VirtualTourProcessingStats = mongoose.model(
  "VirtualTourProcessingStats",
  VirtualTourProcessingStatsSchema
);
