"use strict";
const mongoose = require("mongoose");
const { Schema, model } = mongoose;
const uuid = require("uuid");

const notificationMessageSchema = new Schema(
  {
    token: String,
    messageStatus: String,
    messageId: String,
    title: String,
    body: String,
  },
  {
    timestamps: true,
  }
);

module.exports = model("NotificationMessage", notificationMessageSchema);
