const mongoose = require("mongoose");

const MasterDataSchema = new mongoose.Schema(
  {
    projectId: String,
    workPackage: [],
    workLocation: [],
    workClassification: [],
    workFlow: [],
    rfi: [],
    punchList: [],
    performanceIndex: {},
    directory: [
      {
        userId: String,
        firstName: String,
        lastName: String,
        contact: String,
        email: String,
        isActive: Boolean,
        createdBy: String,
        updatedBy: String,
      },
    ],
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

mongoose.model("MasterData", MasterDataSchema);
