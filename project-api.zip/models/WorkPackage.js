const mongoose = require("mongoose");

const WorkPackageSchema = new mongoose.Schema(
  {
    tradeId: String,
    tradeName: String,
    isActive: String,
    createdBy: String,
    updatedBy: String,
    workPackageCost: { type: Number, default: 0 },
  },
  {
    timestamps: true,
  }
);

mongoose.model("WorkPackage", WorkPackageSchema);
