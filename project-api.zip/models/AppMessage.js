"use strict";
const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const appMessageSchema = new Schema(
  {
    messageId: String,
    messageTitle: String,
    messageContent: String,
    sortOrder: Number,
    isActive: Boolean,
  },
  {
    timestamps: true,
  }
);

module.exports = model("AppMessage", appMessageSchema);
