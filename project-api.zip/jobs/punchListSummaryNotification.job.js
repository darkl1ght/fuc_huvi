"use strict";
const schedule = require("node-schedule");
const mongoose = require("mongoose");
const uuid = require("uuid");
const EmailNotification = require("../models/EmailNotification");
const Project = mongoose.model("Project");
const LookUp = mongoose.model("LookUp");
const Utils = require("../common/util");
const moment = require("moment-timezone");
const logger = require("../common/logger");
const _ = require("underscore");
const summaryEndDateReminderRule = new schedule.RecurrenceRule();
const cronJobCacheKey = "cronStarted";
const cronStartHour = 9; //9 AM, IST
const cronStartMinute = 0;
summaryEndDateReminderRule.tz = "Asia/Kolkata";
const {
  redisDeleteKey,
  redisGetJson,
  redisSetJson,
} = require("../common/redisHelper");

(async () => {
  const cronId = uuid.v4();

  LookUp.find({
    type: "summaryReminderCronConfig",
  })
    .then((cronConfig) => {
      const startHour =
        cronConfig.find((item) => item.key === "cronJobStartHour")?.value ||
        cronStartHour;
      const startMinute =
        cronConfig.find((item) => item.key === "cronJobStartMinute")?.value ||
        cronStartMinute;
      summaryEndDateReminderRule.hour = startHour;
      summaryEndDateReminderRule.minute = startMinute;

      schedule.scheduleJob(
        summaryEndDateReminderRule, //Prod
        // "5 * * * * * ", //For testing - 5th second of every minute
        // "*/1 * * * * ", //For testing - every 1 mins
        async () => {
          const delay = Math.floor(Math.random() * 10) * 1000;
          await redisSetJson(cronJobCacheKey, {
            cronId: cronId,
          });
          await stall(delay); //0-9 Mitigate multiple cron instance effect
          const cronJobFromCache = await redisGetJson(cronJobCacheKey);
          if (cronId == cronJobFromCache?.cronId) {
            await LookUp.find({
              type: "summaryReminderCronConfig",
            })
              .then(async (cronConfig) => {
                //Kill switch
                const isCronJobEnabled =
                  cronConfig.find((item) => item.key === "isCronJobEnabled")
                    ?.value === "true";

                if (!isCronJobEnabled) return; //Comment for debugging if isCronJobEnabled = false

                const fromEmail = cronConfig.find(
                  (item) => item.key === "fromEmail"
                )?.value;
                const config = {
                  fromEmail,
                };
                console.log(delay);

                console.log(cronJobFromCache);

                sendSummarySnagNotification(config);
              })
              .catch((err) => {
                logger.error(
                  "Error fetching Lookup in summaryReminderCronConfig.job startup 1: " +
                    JSON.stringify(err)
                );
              });
          }
        }
      );
    })
    .catch((err) => {
      logger.error(
        "Error fetching Lookup in summaryReminderCronConfig.job startup 2: " +
          JSON.stringify(err)
      );
    });
})();

const sendSummarySnagNotification = async (config) => {
  //Find all projects in the date range and  excludeSendEmailForSnag is set to true

  const currentDate = new Date(moment().add(-1, "day"));
  console.log(currentDate);
  let dailySnagList = await Project.aggregate([])
    .match({ isActive: true, excludeSendEmailForSnag: true })
    .lookup({
      from: "projecttasks",
      localField: "projectId",
      foreignField: "projectId",
      as: "allProjectTasks",
    })
    .unwind("allProjectTasks")
    .match({
      $and: [
        {
          "allProjectTasks.createdAt": {
            $gte: currentDate,
          },
        },
        { "allProjectTasks.isActive": true },
      ],
    })
    .group({
      _id: "$projectId",
      tasks: {
        $push: {
          projectName: "$projectName",
          level1Users: "$allProjectTasks.level1Users",
          level2Users: "$allProjectTasks.level2Users",
          punchId: "$allProjectTasks.punchId",
          workLocation: "$allProjectTasks.workLocation",
          users: "$users",
          emailGroupingForSnag: "$emailGroupingForSnag",
          taskId: "$allProjectTasks.taskId",
        },
      },
    });

  if (!!dailySnagList && dailySnagList.length > 0) {
    dailySnagList.map(async (project) => {
      let userSnagSummary = [];

      project.createdAt = moment(new Date())
        .tz("Asia/Kolkata")
        .format("Do MMM YYYY");
      project.tasks.forEach((task) => {
        let groupingLevel =
          task.emailGroupingForSnag > 0 ? task.emailGroupingForSnag : 0;

        const getTaskLocationLevel =
          task.workLocation?.level4?.length > 0
            ? 4
            : task.workLocation?.level3?.length > 0
            ? 3
            : task.workLocation?.level2?.length > 0
            ? 2
            : task.workLocation?.level1?.length > 0
            ? 1
            : 0;
        const getTaskLocationLevelText =
          getTaskLocationLevel == 4
            ? task.workLocation?.level1 +
              "-" +
              task.workLocation?.level2 +
              "-" +
              task.workLocation?.level3 +
              "-" +
              task.workLocation?.level4
            : getTaskLocationLevel == 3
            ? task.workLocation?.level1 +
              "-" +
              task.workLocation?.level2 +
              "-" +
              task.workLocation?.level3
            : getTaskLocationLevel == 2
            ? task.workLocation?.level1 + "-" + task.workLocation?.level2
            : task.workLocation?.level1;
        const isOthers = groupingLevel != getTaskLocationLevel ? true : false;

        task.level1Users.forEach((email) => {
          let userSummaryObject = {
            projectName: task.projectName,
            createdAt: project.createdAt,
            email: email,
            location: [],
            users: task.users,
          };

          let doesEmailExist = userSnagSummary.findIndex(
            (summary) => summary.email == email
          );
          if (doesEmailExist == -1) {
            if (isOthers) {
              userSummaryObject.location.push({
                locationId: null,
                location: "Others",
                level1Tasks: 1,
                level2Tasks: 0,
              });
            } else {
              userSummaryObject.location.push({
                locationId: task.workLocation?.locationId,
                location: getTaskLocationLevelText,
                level1Tasks: 1,
                level2Tasks: 0,
              });
            }
            userSnagSummary.push(userSummaryObject);
          } else {
            let objectToReplace = userSnagSummary[doesEmailExist];
            let doesLocationExist = !!isOthers
              ? objectToReplace.location.findIndex(
                  (loc) => loc.locationId == null
                )
              : objectToReplace.location.findIndex(
                  (loc) => loc.locationId == task.workLocation?.locationId
                );

            if (doesLocationExist == -1) {
              if (isOthers) {
                objectToReplace.location.push({
                  locationId: null,
                  location: "Others",
                  level1Tasks: 1,
                  level2Tasks: 0,
                });
              } else {
                objectToReplace.location.push({
                  locationId: task.workLocation?.locationId,
                  location: getTaskLocationLevelText,
                  level1Tasks: 1,
                  level2Tasks: 0,
                });
              }
            } else {
              let locationToReplace =
                objectToReplace.location[doesLocationExist];
              locationToReplace.level1Tasks = locationToReplace.level1Tasks + 1;
              objectToReplace.location[doesLocationExist] = locationToReplace;
            }
            userSnagSummary[doesEmailExist] = objectToReplace;
          }
        });
        task.level2Users.forEach((email) => {
          let userSummaryObject = {
            projectName: task.projectName,
            createdAt: project.createdAt,
            email: email,
            location: [],
            users: task.users,
          };

          let doesEmailExist = userSnagSummary.findIndex(
            (summary) => summary.email == email
          );

          if (doesEmailExist == -1) {
            if (isOthers) {
              userSummaryObject.location.push({
                locationId: null,
                location: "Others",
                level2Tasks: 1,
                level1Tasks: 0,
              });
            } else {
              userSummaryObject.location.push({
                locationId: task.workLocation?.locationId,
                location: getTaskLocationLevelText,
                level2Tasks: 1,
                level1Tasks: 0,
              });
            }
            userSnagSummary.push(userSummaryObject);
          } else {
            let objectToReplace = userSnagSummary[doesEmailExist];
            let doesLocationExist = !!isOthers
              ? objectToReplace.location.findIndex(
                  (loc) => loc.locationId == null
                )
              : objectToReplace.location.findIndex(
                  (loc) => loc.locationId == task.workLocation?.locationId
                );

            if (doesLocationExist == -1) {
              if (isOthers) {
                objectToReplace.location.push({
                  locationId: null,
                  location: "Others",
                  level2Tasks: 1,
                  level1Tasks: 0,
                });
              } else {
                objectToReplace.location.push({
                  locationId: task.workLocation?.locationId,
                  location: getTaskLocationLevelText,
                  level2Tasks: 1,
                  level1Tasks: 0,
                });
              }
            } else {
              let locationToReplace =
                objectToReplace.location[doesLocationExist];
              locationToReplace.level2Tasks = locationToReplace.level2Tasks + 1;
              objectToReplace.location[doesLocationExist] = locationToReplace;
            }
            userSnagSummary[doesEmailExist] = objectToReplace;
          }
        });
      });

      project.notificationUserEmails = userSnagSummary;
      if (userSnagSummary.length > 0) {
        await Promise.all(
          userSnagSummary?.map(
            (snagInfo) =>
              new Promise(async (resolve) => {
                const emailInfo = {
                  email: snagInfo.email,
                  userInfo: snagInfo.users.find(
                    (user) => user.email == snagInfo.email
                  ),
                  projectName: snagInfo.projectName,
                  createdAt: snagInfo.createdAt,
                  assignedTo: snagInfo.email,
                  locationPunchListInfo: [],
                };

                if (!!snagInfo.location && snagInfo.location.length > 0) {
                  emailInfo.locationPunchListInfo = [];
                  snagInfo.location.forEach((locPunchInfo) => {
                    const location = locPunchInfo.location;
                    const level1Tasks = locPunchInfo.level1Tasks;
                    const level2Tasks = locPunchInfo.level2Tasks;
                    const punchListStringBuilder = `<tr style="border:1px solid #000"> <td style="border:1px solid #000" colspan="2"><strong> ${location} </strong></td> </tr> <tr style="border:1px solid #000"> <td style="border:1px solid #000"><strong>Number of Level1 Punch item(s)</strong></td> <td style="border:1px solid #000"> ${level1Tasks} </td> </tr> <tr style="border:1px solid #000"> <td style="border:1px solid #000"><strong>Number of Level2 Punch item(s)</strong></td> <td style="border:1px solid #000"> ${level2Tasks}  </td> </tr>`;

                    emailInfo.locationPunchListInfo.push(
                      punchListStringBuilder
                    );
                  });
                }
                const [mailSentError, mailSentStatus] =
                  await Utils.sendPunchListDynamicSummaryEmail(
                    emailInfo.userInfo,
                    emailInfo
                  );

                resolve("Success");
              })
          )
        );
      }
      return project;
    });
  }
};

const stall = async (delay) => {
  await new Promise((resolve) => {
    setTimeout(resolve, delay);
  });
};
