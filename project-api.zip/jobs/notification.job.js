"use strict";
const schedule = require("node-schedule");
const mongoose = require("mongoose");
const Project = mongoose.model("Project");
const _ = require("underscore");
const prepareNotificationData = require("../common/notification");
const {
  invokeFireBaseAndSaveNotification,
} = require("../middlewares/notification.middleware");

const SNAG_PENDING_VERIFICATION = "TS10001";
const SNAG_NOT_ACCEPTED = "TS10003";

const INVALID_SNAGS = ["VS10001", "VS10003"];

const rule = new schedule.RecurrenceRule();

rule.hour = 11;
rule.minute = 0;
rule.tz = "Asia/Kolkata";
const currentDate = new Date().toISOString();

const job = schedule.scheduleJob(rule, async function () {
  let overDueSnags = await Project.aggregate([])
    .match({ isActive: true })
    .lookup({
      from: "projecttasks",
      localField: "projectId",
      foreignField: "projectId",
      as: "allProjectTasks",
    })
    .unwind("allProjectTasks")
    .match({
      $and: [
        {
          $or: [
            {
              "allProjectTasks.taskStatus.code":
                SNAG_PENDING_VERIFICATION,
            },
            {
              "allProjectTasks.taskStatus.code": SNAG_NOT_ACCEPTED,
            },
          ],
        },
        {
          "allProjectTasks.dueDate": {
            $lte: currentDate,
          },
        },
        { "allProjectTasks.isActive": true },
      ],
    })
    .group({
      _id: "$projectId",
      tasks: {
        $push: {
          projectName: "$projectName",
          level1Status: "$allProjectTasks.level1Status",
          level2Status: "$allProjectTasks.level2Status",
          level1Users: "$allProjectTasks.level1Users",
          level2Users: "$allProjectTasks.level2Users",
          punchId: "$allProjectTasks.punchId",
        },
      },
    });

  // Transform snags to get unique email Ids
  overDueSnags.map((project) => {
    let userEmailIds = [];
    project.tasks.forEach((task) => {
      if (INVALID_SNAGS.indexOf(task.level1Status.status.code) !== -1) {
        task.level1Users.forEach((email) => userEmailIds.push(email));
      }
      if (INVALID_SNAGS.indexOf(task.level2Status.status.code) !== -1) {
        task.level2Users.forEach((email) => userEmailIds.push(email));
      }
    });
    project.notificationUserEmails = _.uniq(userEmailIds);
    return project;
  });

  overDueSnags.forEach(async (project) => {
    let notificationData = {
      messageType: "NT0006",
      appType: "APP001",
      notificationUserEmails: project.notificationUserEmails,
      projectId: project._id,
      projectName: project.tasks[0].projectName,
      metaData: {
        actionType: "SnagOverdue",
      },
    };
    const data = await prepareNotificationData(notificationData);
    if (data) await invokeFireBaseAndSaveNotification(data);
  });
});

module.exports = job;
