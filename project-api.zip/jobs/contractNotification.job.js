"use strict";
const schedule = require("node-schedule");
const mongoose = require("mongoose");
const uuid = require("uuid");
const EmailNotification = require("../models/EmailNotification");
const Project = mongoose.model("Project");
const LookUp = mongoose.model("LookUp");
const Utils = require("../common/util");
const moment = require("moment-timezone");
const logger = require("../common/logger");
const contractEndDateReminderRule = new schedule.RecurrenceRule();
const toTeams = ["Management Team", "Project Admin", "Project Incharge"];
const ccTeams = ["Huviair Team"];
const cronStartHour = 11; //11 AM, IST
const cronStartMinute = 0;
contractEndDateReminderRule.tz = "Asia/Kolkata";
const frequencies = [
  {
    templateCode: "ET10030",
    daysOffset: -30,
    frequency: "30 days prior",
    renewBeforeDays: -1,
  },
  {
    templateCode: "ET10030",
    daysOffset: -15,
    frequency: "15 days prior",
    renewBeforeDays: -1,
  },
  {
    templateCode: "ET10030",
    daysOffset: -7,
    frequency: "7 days prior",
    renewBeforeDays: -1,
  },
  {
    templateCode: "ET10030",
    daysOffset: -4,
    frequency: "4 days prior",
    renewBeforeDays: -1,
  },
  {
    templateCode: "ET10030",
    daysOffset: -2,
    frequency: "2 days prior",
    renewBeforeDays: -1,
  },
  {
    templateCode: "ET10030",
    daysOffset: -1,
    frequency: "1 day prior",
    renewBeforeDays: -1,
  },
  {
    templateCode: "ET10031",
    daysOffset: 0,
    frequency: "On the day",
    renewBeforeDays: 15,
  },
  {
    templateCode: "ET10032",
    daysOffset: 1,
    frequency: "1 day after",
    renewBeforeDays: 15,
  },
  {
    templateCode: "ET10032",
    daysOffset: 7,
    frequency: "7 days after",
    renewBeforeDays: 15,
  },
  {
    templateCode: "ET10033",
    daysOffset: 15,
    frequency: "15 days after",
    renewBeforeDays: 15,
  },
];

(async () => {
  const cronId = uuid.v4();

  LookUp.find({
    type: "contractReminderCronConfig",
  })
    .then((cronConfig) => {
      const startHour =
        cronConfig.find((item) => item.key === "cronJobStartHour")?.value ||
        cronStartHour;
      const startMinute =
        cronConfig.find((item) => item.key === "cronJobStartMinute")?.value ||
        cronStartMinute;
      contractEndDateReminderRule.hour = startHour;
      contractEndDateReminderRule.minute = startMinute;

      schedule.scheduleJob(
        contractEndDateReminderRule, //Prod
        // "5 * * * * * ", //For testing - 5th second of every minute
        // "*/1 * * * * ", //For testing - every 1 mins
        async () => {
          await stall(Math.floor(Math.random() * 10) * 1000); //0-9 Mitigate multiple cron instance effect

          await LookUp.find({
            type: "contractReminderCronConfig",
          })
            .then((cronConfig) => {
              //Kill switch
              const isCronJobEnabled =
                cronConfig.find((item) => item.key === "isCronJobEnabled")
                  ?.value === "true";

              if (!isCronJobEnabled) return; //Comment for debugging if isCronJobEnabled = false

              const ccList = cronConfig.find(
                (item) => item.key === "ccList"
              )?.value;
              const bccList = cronConfig.find(
                (item) => item.key === "bccList"
              )?.value;
              const fromEmail = cronConfig.find(
                (item) => item.key === "fromEmail"
              )?.value;
              const config = {
                ccList: ccList ? ccList.split(",") : [],
                bccList: bccList ? bccList.split(",") : [],
                fromEmail,
              };

              sendNotification(config, cronId);
            })
            .catch((err) => {
              logger.error(
                "Error fetching Lookup in contractNotification.job startup 1: " +
                  JSON.stringify(err)
              );
            });
        }
      );
    })
    .catch((err) => {
      logger.error(
        "Error fetching Lookup in contractNotification.job startup 2: " +
          JSON.stringify(err)
      );
    });
})();

const sendNotification = async (config, cronId) => {
  const rangeStart = moment().add(
    -Math.max(...frequencies.map((item) => item.daysOffset)) - 2,
    "day"
  ); //-15 - 2, 15 days after, 2 days margin
  const rangeEnd = moment().add(
    -Math.min(...frequencies.map((item) => item.daysOffset)) + 2,
    "day"
  ); //30 + 2, 30 days prior, 2 days margin

  //Find all projects in the date range
  await Project.aggregate([
    {
      $match: {
        isActive: true,
        isCompleted: false,
        contractEndDate: {
          $gte: new Date(rangeStart),
          $lte: new Date(rangeEnd),
        },
      },
    },
    {
      $lookup: {
        from: "clients",
        localField: "clientId",
        foreignField: "clientId",
        as: "client_collection",
      },
    },
    {
      $unwind: "$client_collection",
    },
    {
      $project: {
        _id: 0,
        projectId: 1,
        projectName: 1,
        contractEndDate: 1,
        users: 1,
        clientId: "$client_collection.clientId",
        clientName: "$client_collection.clientName",
      },
    },
    {
      $sort: {
        _id: Math.floor(Math.random() * 2) === 0 ? -1 : 1, //Mitigate multiple crome instance effect
      },
    },
  ]).then(async (projects) => {
    if (projects.length > 0) {
      await Promise.all(
        projects.map(
          (project) =>
            new Promise(async (resolve) => {
              const endOfContract = moment(project.contractEndDate).add(
                86399999 //a day minus 1ms
              ); //Any timezone end of that day
              const now = moment(); //Job run time
              let dateDiff = now.diff(endOfContract, "days");

              if (endOfContract < now) {
                dateDiff = dateDiff + 1;
              }

              if (
                frequencies.map((item) => item.daysOffset).includes(dateDiff)
              ) {
                const frequencyConfig = frequencies.find(
                  (item) => item.daysOffset === dateDiff
                );

                await EmailNotification.find({
                  templateCode: frequencyConfig.templateCode,
                  "additionalInfo.projectId": project.projectId,
                  "additionalInfo.contractEndDate": project.contractEndDate,
                  "additionalInfo.daysOffset": frequencyConfig.daysOffset,
                  status: { $in: ["success", "inprogress"] },
                  createdAt: {
                    $gte: new Date(moment().add(-1, "day")), //Checking for a range for 2 days
                    $lte: new Date(moment().add(1, "day")),
                  },
                })
                  .then(async (notifications) => {
                    if (notifications.length > 0) {
                      resolve(
                        `Notification already sent/in-progress - ${project.projectId}, ${frequencyConfig.frequency}`
                      );
                    } else {
                      //Log inprogress
                      const emailNotification = new EmailNotification({
                        templateCode: frequencyConfig.templateCode,
                        additionalInfo: {
                          projectId: project.projectId,
                          projectName: project.projectName,
                          contractEndDate: project.contractEndDate,
                          daysOffset: frequencyConfig.daysOffset,
                          frequency: frequencyConfig.frequency,
                          cronId,
                        },
                        status: "inprogress",
                        createdBy: "System",
                      });

                      await emailNotification.save().catch((err) => {
                        logger.error(
                          "Error saving EmailNotification in sendNotification() in contractNotification.job: " +
                            JSON.stringify(err)
                        );
                        throw err;
                      });

                      const mailTo = project.users
                        .filter((user) => toTeams.includes(user.role.code))
                        .map(
                          (user) =>
                            `${user.firstName} ${user.lastName}<${user.email}>`
                        );
                      const mailCc = project.users
                        .filter((user) => ccTeams.includes(user.role.code))
                        .map(
                          (user) =>
                            `${user.firstName} ${user.lastName}<${user.email}>`
                        );

                      if (mailTo.length === 0) {
                        //Sendgrid declines to send email if To is empty
                        mailTo.push(...config.ccList);
                      } else {
                        mailCc.push(...config.ccList);
                      }

                      const mailBcc = config.bccList;

                      const hrsOffset =
                        (moment(project.contractEndDate).valueOf() % 86400000) /
                        (1000 * 60 * 60); //Pick 18.5 from "2023-09-13T18:30:00.000+0000"
                      let contractEndDateDisplay;

                      if (hrsOffset > 12) {
                        contractEndDateDisplay = moment(
                          project.contractEndDate
                        ).add(24 - hrsOffset, "hours");
                      } else {
                        contractEndDateDisplay = moment(
                          project.contractEndDate
                        );
                      }

                      const renewBeforeDateDisplay = moment(
                        contractEndDateDisplay
                      ).add(frequencyConfig.renewBeforeDays, "days");

                      const emailTemplateParams = {
                        projectId: project.projectId, //for logging
                        daysOffset: frequencyConfig.daysOffset, //for logging
                        frequency: frequencyConfig.frequency, //for logging
                        projectName: project.projectName,
                        clientName: project.clientName,
                        contractEndDate: project.contractEndDate,
                        contractEndDateDisplay: moment(
                          contractEndDateDisplay
                        ).format("DD-MMM-YYYY"),
                        renewBeforeDateDisplay: moment(
                          renewBeforeDateDisplay
                        ).format("DD-MMM-YYYY"),
                        cronId,
                      };

                      //Abort based on createdAt
                      await EmailNotification.find(
                        {
                          templateCode: frequencyConfig.templateCode,
                          "additionalInfo.projectId": project.projectId,
                          "additionalInfo.contractEndDate":
                            project.contractEndDate,
                          "additionalInfo.daysOffset":
                            frequencyConfig.daysOffset,
                          status: "inprogress",
                          createdAt: {
                            $gte: new Date(moment().add(-1, "day")), //Checking for a range for 2 days
                            $lte: new Date(moment().add(1, "day")),
                          },
                        },
                        {},
                        {
                          sort: {
                            createdAt: "asc", //Decide winner based on createdAt
                          },
                        }
                      )
                        .then(async (data) => {
                          if (data.length > 0) {
                            if (data[0].additionalInfo.cronId === cronId) {
                              //I win
                              if (data.length > 1) {
                                //abort others
                                await EmailNotification.updateMany(
                                  {
                                    templateCode: frequencyConfig.templateCode,
                                    "additionalInfo.projectId":
                                      project.projectId,
                                    "additionalInfo.contractEndDate":
                                      project.contractEndDate,
                                    "additionalInfo.daysOffset":
                                      frequencyConfig.daysOffset,
                                    "additionalInfo.cronId": {
                                      $ne: cronId,
                                    },
                                    status: "inprogress",
                                    createdAt: {
                                      $gte: new Date(moment().add(-1, "day")), //Checking for a range for 2 days
                                      $lte: new Date(moment().add(1, "day")),
                                    },
                                  },
                                  {
                                    $set: {
                                      status: "aborted",
                                    },
                                  }
                                ).catch((err) => {
                                  logger.error(
                                    "Error while updating EmailNotification in sendNotification() in contractNotification.job: " +
                                      JSON.stringify(mailSentError)
                                  );
                                });
                              }

                              //continue sending email
                              const [mailSentError, mailSentStatus] =
                                await Utils.sendContractReminderEmail(
                                  mailTo,
                                  mailCc,
                                  mailBcc,
                                  config.fromEmail,
                                  frequencyConfig.templateCode,
                                  emailTemplateParams
                                );

                              if (mailSentError) {
                                logger.error(
                                  "Error while sending Contract Notification email in sendNotification() in contractNotification.job: " +
                                    JSON.stringify(mailSentError)
                                );
                                resolve(
                                  `Error sending email - ${project.projectId}, ${frequencyConfig.frequency}`
                                );
                              } else {
                                resolve(
                                  `Success - ${project.projectId}, ${frequencyConfig.frequency}`
                                );
                              }
                            } else {
                              resolve(
                                "I shouldn't send email - ${project.projectId}, ${frequencyConfig.frequency}"
                              );
                            }
                          } else {
                            resolve("Nothing to send");
                          }
                        })
                        .catch((err) => {
                          logger.error(
                            "Error fetching EmailNotification in sendNotification() in contractNotification.job: " +
                              JSON.stringify(mailSentError)
                          );
                          throw err;
                        });
                    }
                  })
                  .catch((err) => {
                    logger.error(
                      "Error reading EmailNotification in sendNotification() in contractNotification.job: " +
                        JSON.stringify(err)
                    );
                    resolve(
                      `Error reading EmailNotification - ${project.projectId}, ${frequencyConfig.frequency}`
                    );
                  });
              } else {
                resolve(null);
              }
            })
        )
      );
    }
  });
};

const stall = async (delay) => {
  await new Promise((resolve) => {
    setTimeout(resolve, delay);
  });
};

// module.exports = { contractEndDateReminderJob };
