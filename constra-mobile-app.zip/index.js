/**
 * @format
 * @lint-ignore-every XPLATJSCOPYRIGHT1
 */
import React from 'react';
import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
import messaging from '@react-native-firebase/messaging';
import notifee, { AndroidStyle } from '@notifee/react-native';
import colors from './src/styles/colors';
import Config from './src/modules/utils/config';
import uuid from 'react-native-uuid';
import { store } from './src/redux/store';
import { saveNotification } from './src/modules/notifications/NotificationsState';
import format from 'date-fns/format';
import { parseISO, isValid } from 'date-fns/esm';
import { persistStore } from 'redux-persist';

const SMALL_ICON_NAME = 'ic_small_icon';

let isValidDate = function(string) {
  try {
    return isValid(parseISO(string));
  } catch (error) {
    return false;
  }
};

// App background logic
async function onMessageReceived(remoteMessage) {
  const { data } = remoteMessage;

  switch (data.actionType) {
    case Config.get('INTERIOR_TOUR'):
      await displayNotification(data, 'Interiors');
      break;

    case Config.get('MEDIA_UPLOADED'):
      await displayNotification(data, 'Media');
      break;

    case Config.get('AERIAL_TOUR_PUBLISHED'):
      await displayNotification(data, 'Aerials');
      break;
    default:
      break;
  }
}

// App foreground logic
async function onForegroundMessage(remoteMessage) {
  const { data } = remoteMessage;
  data.messageId = uuid.v4();
  data.body = data.body
    .split(' ')
    .map(word => {
      if (isValidDate(word)) word = format(parseISO(word), 'LLLL dd yyyy');
      return word;
    })
    .join(' ');

  switch (data.actionType) {
    case Config.get('INTERIOR_TOUR'):
    case Config.get('MEDIA_UPLOADED'):
    case Config.get('AERIAL_TOUR_PUBLISHED'):
      store.dispatch(saveNotification(data));
      break;

    default:
      break;
  }
}

async function displayNotification(data, channel) {
  data.messageId = uuid.v4();
  data.body = data.body
    .split(' ')
    .map(word => {
      if (isValidDate(word)) word = format(parseISO(word), 'LLLL dd yyyy');
      return word;
    })
    .join(' ');

  //Save notification after store has rehydrated
  persistStore(store, null, () => {
    store.dispatch(saveNotification(data));
  });

  let channelId = await notifee.createChannel({
    id: channel,
    name: channel,
  });

  await notifee.requestPermission();

  // Display a notification
  await notifee.displayNotification({
    title: data.title,
    body: data.body,
    id: data.messageId,
    android: {
      pressAction: {
        id: 'default',
      },
      showTimestamp: true,
      channelId,
      color: colors.primary,
      smallIcon: SMALL_ICON_NAME,
      style: { type: AndroidStyle.BIGTEXT, text: data.body },
    },
    data: { ...data },
  });
}

function HeadlessCheck({ isHeadless }) {
  if (isHeadless) {
    // App has been launched in the background by iOS, ignore
    return null;
  }

  return <App />;
}
// Register background handler
messaging().setBackgroundMessageHandler(onMessageReceived);
messaging().onMessage(onForegroundMessage);

AppRegistry.registerComponent(appName, () => HeadlessCheck);
