import React from 'react';
import AuthNavigator from './navigation/AuthNavigator';
import RootNavigator from './navigation/RootNavigator';
import messaging from '@react-native-firebase/messaging';
import { getUniqueId } from 'react-native-device-info';
import { useEffect } from 'react';

export default function AppView({ isUserLoggedIn, isUserAdmin, saveGCMToken }) {
  async function requestUserPermission() {
    await messaging().requestPermission();
  }
  useEffect(() => {
    if (isUserLoggedIn) {
      requestUserPermission();
      // On login - register the token to server
      messaging()
        .getToken()
        .then(token => saveGCMToken(token, getUniqueId()));
    }
  }, [isUserLoggedIn]);

  return isUserLoggedIn ? (
    <RootNavigator
      isAdmin={isUserAdmin}
      onNavigationStateChange={() => {}}
      uriPrefix="/app"
    />
  ) : (
    <AuthNavigator />
  );
}
