// @flow
import React from 'react';
import { ScrollView } from 'react-native-gesture-handler';
import { Divider, List } from 'react-native-paper';

export default ({ navigation }) => (
  <ScrollView>
    <List.Section style={{ margin: 2 }}>
      <List.Item
        title="Profile"
        style={{
          marginTop: 10,
          elevation: 3,
        }}
        onPress={() => navigation.navigate('Profile')}
        left={() => <List.Icon icon="account" />}
        right={() => <List.Icon icon="chevron-right" />}
      />
      <Divider />

      <List.Item
        title="Reset Password"
        style={{
          elevation: 3,
        }}
        onPress={() => navigation.navigate('Reset Password')}
        left={() => <List.Icon icon="key" />}
        right={() => <List.Icon icon="chevron-right" />}
      />

      <Divider />
    </List.Section>
  </ScrollView>
);
