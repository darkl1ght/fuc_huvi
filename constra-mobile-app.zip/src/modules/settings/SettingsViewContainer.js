// @flow
import { compose } from 'recompose';
import { connect } from 'react-redux';

import SettingsView from './SettingsView';

export default compose(
  connect(
    (state) => ({}),
    (dispatch) => ({}),
  ),
)(SettingsView);
