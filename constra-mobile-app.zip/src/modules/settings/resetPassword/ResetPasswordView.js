// @flow
import { Formik } from 'formik';
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Button, Snackbar, TextInput, useTheme } from 'react-native-paper';
import * as Yup from 'yup';
import ActivityIndicator from '../../../components/ActivityIndicator';
import { Text } from '../../../components/StyledText';

let passwordPlaceholder = 'New Password';
let newPasswordPlaceholder = 'Confirm New Password';

const profileFormSchema = Yup.object().shape({
  password: Yup.string()
    .min(8)
    .label('Password')
    .required(),
  confirmPassword: Yup.string()
    .min(8)
    .label('Confirm Password')
    .when('password', {
      is: val => (val && val.length > 0 ? true : false),
      then: Yup.string().oneOf(
        [Yup.ref('password')],
        'Entered Passwords do not match',
      ),
    })
    .required(),
});

export default function ResetPasswordView(props) {
  const { colors } = useTheme();
  return (
    <>
      <View style={styles.container}>
        <Formik
          initialValues={{ password: '', confirmPassword: '' }}
          onSubmit={({ password }) => {
            let user = props.user;
            user.password = password;
            props.updatePassword(user);
          }}
          validationSchema={profileFormSchema}
        >
          {({
            handleChange,
            handleSubmit,
            errors,
            setFieldTouched,
            touched,
          }) => (
            <>
              <TextInput
                mode="outlined"
                label="New password"
                autoCapitalize="none"
                autoCorrect={false}
                style={styles.password}
                secureTextEntry
                dense
                textContentType="password"
                underlineColor={colors.primary}
                selectionColor={colors.primary}
                onBlur={() => setFieldTouched('password')}
                onChangeText={handleChange('password')}
                placeholder={passwordPlaceholder}
                error={errors.password}
              />
              {touched.password && errors.password && (
                <Text style={styles.error}>{errors.password}</Text>
              )}
              <TextInput
                autoCapitalize="none"
                label="Confirm password"
                mode="outlined"
                dense
                autoCorrect={false}
                style={styles.password}
                secureTextEntry
                textContentType="password"
                underlineColor={colors.primary}
                selectionColor={colors.primary}
                onBlur={() => setFieldTouched('confirmPassword')}
                onChangeText={handleChange('confirmPassword')}
                placeholder={newPasswordPlaceholder}
                error={errors.confirmPassword}
              />
              {touched.confirmPassword && errors.confirmPassword && (
                <Text style={styles.error}>{errors.confirmPassword}</Text>
              )}
              <Button
                color={colors.primary}
                style={{ marginTop: 10 }}
                mode="contained"
                icon="content-save"
                uppercase={false}
                accessibilityLabel="Save"
                onPress={handleSubmit}
                disabled={props.isLoading}
              >
                Update Password
              </Button>
            </>
          )}
        </Formik>
      </View>
      <>
        <ActivityIndicator visible={props.isLoading} />
        <Snackbar
          visible={props.error}
          duration={1500}
          onDismiss={() => props.resetError()}
        >
          Something Went Wrong.
        </Snackbar>
        <Snackbar
          visible={props.success}
          duration={1500}
          onDismiss={() => props.resetSuccess()}
        >
          Your password has been changed successfully.
        </Snackbar>
      </>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 30,
    padding: 20,
    alignContent: 'center',
  },
  view: {
    paddingTop: 10,
  },
  password: {
    marginBottom: 20,
  },
  error: {
    paddingBottom: 8,
    marginTop: -10,
    color: 'red',
  },
});
