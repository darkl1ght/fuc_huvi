// Initial state
const initialState = {
  isLoading: false,
  isErrorInLogging: false,
  isSuccessInLogging: false,
  user: {},
};

// Actions
const START_PROFILE_LOADING = 'PROFILE_STATE/START_LOADING';
const PROFILE_SUCCESS = 'PROFILE_STATE/PROFILE_SUCCESS';
const PROFILE_ERROR = 'PROFILE_STATE/PROFILE_ERROR';
const RESET_PROFILE_SUCCESS = 'PROFILE_STATE/RESET_PROFILE_SUCCESS';
const RESET_PROFILE_ERROR = 'PROFILE_STATE/RESET_PROFILE_ERROR';

// Action creators
function startProfileLoading() {
  return { type: START_PROFILE_LOADING };
}

export function updatePassword(user) {
  return dispatch => {
    dispatch(startProfileLoading());
    dispatch({
      isProjectApi: false,
      type: 'apiCallBegan',
      payload: {
        url: '/user',
        method: 'PUT',
        data: {
          user: user,
        },
        onSuccess: PROFILE_SUCCESS,
        onError: PROFILE_ERROR,
      },
    });
  };
}

export function resetError() {
  return { type: RESET_PROFILE_ERROR };
}

export function resetSuccess() {
  return { type: RESET_PROFILE_SUCCESS };
}

// Reducer
export default function ResetPasswordStateReducer(
  state = initialState,
  action = {},
) {
  switch (action.type) {
    case START_PROFILE_LOADING:
      return Object.assign({}, state, {
        isLoading: true,
        isSuccessInLogging: false,
        isErrorInLogging: false,
      });
    case PROFILE_SUCCESS:
      return Object.assign({}, state, {
        isLoading: false,
        isSuccessInLogging: true,
        isErrorInLogging: false,
      });
    case PROFILE_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: true,
      });
    case RESET_PROFILE_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
      });
    case RESET_PROFILE_SUCCESS:
      return Object.assign({}, state, {
        isLoading: false,
        isSuccessInLogging: false,
      });
    default:
      return state;
  }
}
