// @flow
import { compose } from 'recompose';
import { connect } from 'react-redux';

import ResetPasswordView from './ResetPasswordView';
import { resetError, resetSuccess, updatePassword } from './ResetPasswordState';
export default compose(
  connect(
    ({ resetPassword, login }) => ({
      isLoading: resetPassword.isLoading,
      user: login.user,
      error: resetPassword.isErrorInLogging,
      success: resetPassword.isSuccessInLogging,
    }),
    dispatch => ({
      updatePassword: user => dispatch(updatePassword(user)),
      resetError: () => dispatch(resetError()),
      resetSuccess: () => dispatch(resetSuccess()),
    }),
  ),
)(ResetPasswordView);
