export default Object.freeze({
  BOTTOM_TAB_DISABLED_NAVIGATOR: 'NavigatorWithoutBottomTabs',
  WALKTHROUGH_VIRTUAL_TOUR: 'Walkthrough-Virtual-Tour',
  BOTTOM_TAB_NAVIGATOR: 'BottomTabNavigator',
  PROJECTS: 'Projects',
  ALBUMS: 'Albums',
  AERIAL_SELF_SERVE: 'Aerial self serve',
  INTERIORS_SELF_SERVE: 'Interiors self serve',
  BIM_VIEWER: 'Bim viewer',
});
