import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import LoginScreen from '../login/LoginViewContainer';
import WelcomeScreen from '../welcome/WelcomeViewContainer';
import headerStyleSide from '../../styles/header';
import ForgotPasswordView from '../forgotPassword/ForgotPasswordViewContainer';

const Stack = createStackNavigator();

const headerStyleBack = {
  ...headerStyleSide.headerStyleSide,
  headerTintColor: '#fff',
  headerStyle: {
    backgroundColor: '#2d4059',
    elevation: 0,
    shadowOpacity: 0,
    borderBottomWidth: 0,
  },
};
export default function AuthNavigator() {
  return (
    <Stack.Navigator screenOptions={headerStyleBack}>
      <Stack.Screen
        name="Welcome"
        component={WelcomeScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen
        options={{ headerTitle: '' }}
        name="Forgot Password"
        component={ForgotPasswordView}
      />
    </Stack.Navigator>
  );
}
