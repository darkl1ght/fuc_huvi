import { createStackNavigator } from '@react-navigation/stack';
import React from 'react';
import 'react-native-gesture-handler';
import useNotification from '../../hooks/useNotification';
import NavigatorWithoutBottomTabs from './bottomTabDisabled/NavigatorWithoutBottomTabs';
import BottomTabNavigator from './bottomTabEnabled/BottomTabNavigator';
import Routes from './routes';

const Stack = createStackNavigator();

export default ({ isAdmin }) => {
  // Invoke the use notification hook
  useNotification();

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="BottomTabNavigator"
        children={props => <BottomTabNavigator isAdmin={isAdmin} {...props} />}
      />
      <Stack.Screen
        name={Routes.BOTTOM_TAB_DISABLED_NAVIGATOR}
        component={NavigatorWithoutBottomTabs}
      />
    </Stack.Navigator>
  );
};
