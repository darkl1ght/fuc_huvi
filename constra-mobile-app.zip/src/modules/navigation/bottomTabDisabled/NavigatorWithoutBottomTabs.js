import { createStackNavigator } from '@react-navigation/stack';
import * as React from 'react';
import PanoramaViewer from '../../interiors/panoramaViewer/PanoramaViewerViewContainer';
import WalkthroughVirtualTourScreen from '../../interiors/walkthroughvirtualtour/WalkthroughvirtualtourViewContainer';
import MapScreen from '../../map/MapViewContainer';
import ChartScreen from '../../charts/ChartsViewContainer';
import headerStyleSide from '../../../styles/header';
import VideoplayerView from '../../videoplayer/VideoplayerView';
import AerialSelfServeView from '../../aerial/AerialSelfServeView';
import routes from '../routes';
import InteriorSelfServeView from '../../interiors/interiorwalkthroughlist/InteriorSelfServeView';
import BimViewerView from '../../interiors/bimViewer/BimViewerViewContainer';

const BottomTabDisabledStack = createStackNavigator();

export default () => {
  const headerStyleBack = {
    ...headerStyleSide.headerStyleSide,
    headerTintColor: '#fff',
  };
  return (
    <BottomTabDisabledStack.Navigator>
      <BottomTabDisabledStack.Screen
        name="Map"
        component={MapScreen}
        options={{ headerShown: false }}
      />
      <BottomTabDisabledStack.Screen
        name="Walkthrough-Virtual-Tour"
        component={WalkthroughVirtualTourScreen}
        options={{ headerShown: false }}
      />
      <BottomTabDisabledStack.Screen
        name="Media Video Player"
        component={VideoplayerView}
        options={{ headerShown: false }}
      />
      <BottomTabDisabledStack.Screen
        name="Panorama player"
        component={PanoramaViewer}
        options={{ headerShown: false }}
      />
      <BottomTabDisabledStack.Screen
        name="Progress Charts"
        options={({ route }) => ({
          ...headerStyleBack,
          title: route.params.title,
        })}
        component={ChartScreen}
      />
      <BottomTabDisabledStack.Screen
        name={routes.AERIAL_SELF_SERVE}
        options={({ route }) => ({
          ...headerStyleBack,
          title: route.params.title,
        })}
        component={AerialSelfServeView}
      />
      <BottomTabDisabledStack.Screen
        name={routes.INTERIORS_SELF_SERVE}
        options={({ route }) => ({
          ...headerStyleBack,
          title: route.params.title,
        })}
        component={InteriorSelfServeView}
      />
      <BottomTabDisabledStack.Screen
        name={routes.BIM_VIEWER}
        options={{ headerShown: false }}
        component={BimViewerView}
      />
    </BottomTabDisabledStack.Navigator>
  );
};
