import { createStackNavigator } from '@react-navigation/stack';
import React from 'react';
import { Image, TouchableOpacity } from 'react-native';
import 'react-native-gesture-handler';
import { useTheme } from 'react-native-paper';
import headerStyleSide from '../../../styles/header';
import AerialView from '../../aerial/AerialViewContainer';

const Stack = createStackNavigator();

export default function App({ projectName, navigation }) {
  const headerLeftComponentMenu = () => {
    return (
      <TouchableOpacity
        onPress={() => navigation.toggleDrawer()}
        style={{
          paddingHorizontal: 16,
          paddingVertical: 12,
        }}
      >
        <Image
          source={require('../../../../assets/images/drawer/menu.png')}
          resizeMode="contain"
          style={{
            height: 20,
          }}
        />
      </TouchableOpacity>
    );
  };

  const { colors } = useTheme();

  const headerStyle = {
    ...headerStyleSide.headerStyleSide,
    headerLeft: headerLeftComponentMenu,
    headerStyle: {
      backgroundColor: colors.navigationBarColor,
    },
  };

  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Aerial"
        component={AerialView}
        options={{ ...headerStyle, title: `Aerials - ${projectName}` }}
      />
    </Stack.Navigator>
  );
}
