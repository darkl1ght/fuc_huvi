import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import headerStyleSide from '../../../styles/header';
import DocumentsScreen from '../../documents/DocumentsViewContainer';
import { TouchableOpacity, Image } from 'react-native';
import { useTheme } from 'react-native-paper';

const Stack = createStackNavigator();

export default function App({ navigation, projectName }) {
  const headerLeftComponentMenu = () => {
    return (
      <TouchableOpacity
        onPress={() => navigation.toggleDrawer()}
        style={{
          paddingHorizontal: 16,
          paddingVertical: 12,
        }}
      >
        <Image
          source={require('../../../../assets/images/drawer/menu.png')}
          resizeMode="contain"
          style={{
            height: 20,
          }}
        />
      </TouchableOpacity>
    );
  };

  const { colors } = useTheme();

  const headerStyle = {
    ...headerStyleSide.headerStyleSide,
    headerLeft: headerLeftComponentMenu,
    headerStyle: {
      backgroundColor: colors.navigationBarColor,
    },
  };

  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Documents"
        component={DocumentsScreen}
        options={{ ...headerStyle, title: `Documents - ${projectName}` }}
      />
    </Stack.Navigator>
  );
}
