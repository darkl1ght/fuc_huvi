import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import headerStyleSide from '../../../styles/header';
import TeamScreen from '../../team/TeamViewContainer';
import { TouchableOpacity, Image } from 'react-native';
import { useTheme } from 'react-native-paper';

const Stack = createStackNavigator();

export default function App({ navigation, projectName }) {
  const headerLeftComponentMenu = () => {
    return (
      <TouchableOpacity
        onPress={() => navigation.toggleDrawer()}
        style={{
          paddingHorizontal: 16,
          paddingVertical: 12,
        }}
      >
        <Image
          source={require('../../../../assets/images/drawer/menu.png')}
          resizeMode="contain"
          style={{
            height: 20,
          }}
        />
      </TouchableOpacity>
    );
  };

  const headerStyle = {
    ...headerStyleSide.headerStyleSide,
    headerLeft: headerLeftComponentMenu,
  };

  const { colors } = useTheme();

  headerStyle.headerStyle.backgroundColor = colors.navigationBarColor;

  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Team"
        component={TeamScreen}
        options={{ ...headerStyle, title: `Team - ${projectName}` }}
      />
    </Stack.Navigator>
  );
}
