import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React from 'react';
import { Text } from 'react-native';
import 'react-native-gesture-handler';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useTheme } from 'react-native-paper';
import { useSelector } from 'react-redux';
import ClientsNavigator from './ClientsNavigator';
import SettingsNavigator from './SettingsNavigator';
import NotificationScreen from '../../notifications/NotificationsView';
import { fonts } from '../../../styles';

const OPACITY_TAB_NOT_FOCUSED = 0.6;
const OPACITY_TAB_FOCUSED = 1.0;

export default function BottomTabNavigator({ isAdmin }) {
  const Tab = createBottomTabNavigator();

  const getOpacityByFocus = focus => {
    return focus ? OPACITY_TAB_FOCUSED : OPACITY_TAB_NOT_FOCUSED;
  };

  const { colors } = useTheme();
  const counter = useSelector(({ notification }) => {
    return notification.notifications.filter(
      notification => notification.notificationSeen === false,
    ).length;
  });

  return (
    <Tab.Navigator
      tabBarOptions={{
        adaptive: false,
      }}
    >
      {isAdmin ? (
        <Tab.Screen
          name="Clients"
          children={() => <ClientsNavigator initialRouteName="Clients" />}
          options={{
            tabBarIcon: ({ focused, size }) => (
              <Icon
                name={
                  focused ? 'account-supervisor' : 'account-supervisor-outline'
                }
                color={colors.primary}
                style={{
                  opacity: getOpacityByFocus(focused),
                }}
                size={size}
              />
            ),
            tabBarLabel: ({ focused, size }) => (
              <Text
                style={{
                  fontSize: size,
                  color: colors.primary,
                  fontFamily: fonts.primaryBold,
                  opacity: getOpacityByFocus(focused),
                }}
              >
                Clients
              </Text>
            ),
          }}
        />
      ) : (
        <Tab.Screen
          name="Projects"
          children={() => <ClientsNavigator initialRouteName="Projects" />}
          options={{
            tabBarIcon: ({ focused, size }) => (
              <Icon
                name={focused ? 'view-module' : 'view-module-outline'}
                color={colors.primary}
                style={{
                  opacity: getOpacityByFocus(focused),
                }}
                size={size}
              />
            ),
            tabBarLabel: ({ focused, size }) => (
              <Text
                style={{
                  fontSize: size,
                  fontFamily: fonts.primaryBold,
                  color: colors.primary,
                  opacity: getOpacityByFocus(focused),
                }}
              >
                Projects
              </Text>
            ),
          }}
        />
      )}

      <Tab.Screen
        name="Notifications"
        component={NotificationScreen}
        options={{
          tabBarIcon: ({ focused, size }) => (
            <Icon
              name={focused ? 'bell' : 'bell-outline'}
              color={colors.primary}
              style={{ opacity: getOpacityByFocus(focused) }}
              size={size}
            />
          ),
          tabBarLabel: ({ focused, size }) => (
            <Text
              style={{
                fontSize: size,
                fontFamily: fonts.primaryBold,
                color: colors.primary,
                opacity: getOpacityByFocus(focused),
              }}
            >
              Notifications
            </Text>
          ),
          tabBarBadge: counter > 0 ? counter : null,
        }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsNavigator}
        options={{
          tabBarIcon: ({ focused, size }) => (
            <Icon
              name={focused ? 'cog' : 'cog-outline'}
              color={colors.primary}
              style={{ opacity: getOpacityByFocus(focused) }}
              size={size}
            />
          ),
          tabBarLabel: ({ focused, size }) => (
            <Text
              style={{
                fontSize: size,
                fontFamily: fonts.primaryBold,
                color: colors.primary,
                opacity: getOpacityByFocus(focused),
              }}
            >
              Settings
            </Text>
          ),
        }}
      />
    </Tab.Navigator>
  );
}
