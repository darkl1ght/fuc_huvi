import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import headerStyleSide from '../../../styles/header';
import LiveStreamScreen from '../../livestream/LivestreamViewContainer';
import VideoplayerView from '../../videoplayer/VideoplayerViewContainer';
import { TouchableOpacity, Image } from 'react-native';
import { useTheme } from 'react-native-paper';

const Stack = createStackNavigator();

export default function App(props) {
  const headerLeftComponentMenu = () => {
    return (
      <TouchableOpacity
        onPress={() => props.navigation.toggleDrawer()}
        style={{
          paddingHorizontal: 16,
          paddingVertical: 12,
        }}
      >
        <Image
          source={require('../../../../assets/images/drawer/menu.png')}
          resizeMode="contain"
          style={{
            height: 20,
          }}
        />
      </TouchableOpacity>
    );
  };
  const { colors } = useTheme();

  const headerStyle = {
    ...headerStyleSide.headerStyleSide,
    headerLeft: headerLeftComponentMenu,
    headerStyle: {
      backgroundColor: colors.navigationBarColor,
    },
  };
  const headerStyleBack = {
    ...headerStyleSide.headerStyleSide,
    headerTintColor: '#fff',
    headerStyle: {
      backgroundColor: colors.navigationBarColor,
    },
  };

  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Livestream"
        component={LiveStreamScreen}
        options={headerStyle}
      />
      <Stack.Screen
        name="Video Player"
        component={VideoplayerView}
        options={headerStyleBack}
      />
    </Stack.Navigator>
  );
}
