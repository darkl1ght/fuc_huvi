import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator, Header } from '@react-navigation/stack';
import ProfileScreen from '../../profile/ProfileViewContainer';
import headerStyleSide from '../../../styles/header';
import { useTheme } from 'react-native-paper';

const Stack = createStackNavigator();

let headerStyleBack = {
  ...headerStyleSide.headerStyleSide,
  headerTintColor: '#fff',
};

export default function ProfileView() {
  const { colors } = useTheme();

  headerStyleBack.headerStyle.backgroundColor = colors.navigationBarColor;

  return (
    <Stack.Navigator screenOptions={headerStyleBack}>
      <Stack.Screen name="Profile" component={ProfileScreen} />
    </Stack.Navigator>
  );
}
