import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItem,
} from '@react-navigation/drawer';
import * as React from 'react';
import { StyleSheet, View } from 'react-native';
import { useTheme } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { Colors } from 'react-native/Libraries/NewAppScreen';
import { Text } from '../../../components/StyledText';
import AerialNavigator from './AerialsNavigator';
import DocumentsNavigator from './DocumentsNavigator';
import InteriorsNavigator from './InteriorsNavigator';
import MediaNavigator from './MediaNavigator';
import TeamNavigator from './TeamNavigator';

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props) {
  return (
    <DrawerContentScrollView {...props} style={{ padding: 0 }}>
      <View style={styles.avatarContainer}>
        <Text style={styles.userName} numberOfLines={3}>
          {props.projectName}
        </Text>
      </View>
      <View style={styles.divider} />

      <DrawerItem
        label={() => (
          <View>
            <Text style={styles.menuTitle}>Aerial</Text>
          </View>
        )}
        icon={({ size }) => (
          <Icon color={Colors.white} size={size} name="public" />
        )}
        onPress={() => props.navigation.navigate('Aerial Navigator')}
      />
      <DrawerItem
        label={() => (
          <View style={styles.menuLabelFlex}>
            <Text style={styles.menuTitle}>Virtual Tour</Text>
          </View>
        )}
        icon={({ size }) => (
          <Icon color={Colors.white} size={size} name="switch-video" />
        )}
        onPress={() => props.navigation.navigate('Interior Navigator')}
      />

      <DrawerItem
        label={() => (
          <View style={styles.menuLabelFlex}>
            <Text style={styles.menuTitle}>Media</Text>
          </View>
        )}
        icon={({ size }) => (
          <Icon color={Colors.white} size={size} name="photo-library" />
        )}
        onPress={() => props.navigation.navigate('Media Navigator')}
      />
      <DrawerItem
        label={() => (
          <View style={styles.menuLabelFlex}>
            <Text style={styles.menuTitle}>Team</Text>
          </View>
        )}
        icon={({ size }) => (
          <Icon
            color={Colors.white}
            size={size}
            name="supervised-user-circle"
          />
        )}
        onPress={() => props.navigation.navigate('Team Navigator')}
      />
      <DrawerItem
        label={() => (
          <View style={styles.menuLabelFlex}>
            <Text style={styles.menuTitle}>Documents</Text>
          </View>
        )}
        icon={({ size }) => (
          <Icon color={Colors.white} size={size} name="folder" />
        )}
        onPress={() => props.navigation.navigate('Documents Navigator')}
      />
    </DrawerContentScrollView>
  );
}

export default function App({ route }) {
  const { colors } = useTheme();
  const { projectName, isNavigateToInteriors } = route.params;

  return (
    <>
      {isNavigateToInteriors ? (
        <Drawer.Navigator
          drawerStyle={{
            backgroundColor: colors.navigationBarColor,
          }}
          drawerContent={props => (
            <CustomDrawerContent {...props} projectName={projectName} />
          )}
        >
          <Drawer.Screen
            name="Interior Navigator"
            children={props => (
              <InteriorsNavigator projectName={projectName} {...props} />
            )}
          />
          <Drawer.Screen
            name="Aerial Navigator"
            children={props => (
              <AerialNavigator projectName={projectName} {...props} />
            )}
          />

          <Drawer.Screen
            name="Documents Navigator"
            children={props => (
              <DocumentsNavigator projectName={projectName} {...props} />
            )}
          />

          <Drawer.Screen
            name="Team Navigator"
            children={props => (
              <TeamNavigator projectName={projectName} {...props} />
            )}
          />
          <Drawer.Screen
            name="Media Navigator"
            children={props => (
              <MediaNavigator projectName={projectName} {...props} />
            )}
          />
        </Drawer.Navigator>
      ) : (
        <Drawer.Navigator
          drawerStyle={{
            backgroundColor: colors.navigationBarColor,
          }}
          drawerContent={props => (
            <CustomDrawerContent {...props} projectName={projectName} />
          )}
        >
          <Drawer.Screen
            name="Aerial Navigator"
            children={props => (
              <AerialNavigator projectName={projectName} {...props} />
            )}
          />
          <Drawer.Screen
            name="Interior Navigator"
            children={props => (
              <InteriorsNavigator projectName={projectName} {...props} />
            )}
          />
          <Drawer.Screen
            name="Documents Navigator"
            children={props => (
              <DocumentsNavigator projectName={projectName} {...props} />
            )}
          />

          <Drawer.Screen
            name="Team Navigator"
            children={props => (
              <TeamNavigator projectName={projectName} {...props} />
            )}
          />
          <Drawer.Screen
            name="Media Navigator"
            children={props => (
              <MediaNavigator projectName={projectName} {...props} />
            )}
          />
        </Drawer.Navigator>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  menuTitle: {
    marginLeft: 1,
    color: '#fff',
  },
  menuLabelFlex: {
    display: 'flex',
    flexDirection: 'row',
  },
  userName: {
    color: '#fff',
    fontSize: 18,
  },
  divider: {
    borderBottomColor: 'white',
    opacity: 0.2,
    borderBottomWidth: 1,
    margin: 15,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  avatarContainer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    margin: 20,
    marginBottom: 10,
  },
});
