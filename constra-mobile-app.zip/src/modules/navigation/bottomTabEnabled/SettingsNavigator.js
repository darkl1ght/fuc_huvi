import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import SettingsScreen from '../../settings/SettingsViewContainer';
import ResetPasswordScreen from '../../settings/resetPassword/ResetPasswordViewContainer';
import headerStyleSide from '../../../styles/header';
import { useTheme } from 'react-native-paper';
import ProfileView from '../../profile/ProfileViewContainer';

const Stack = createStackNavigator();

let headerStyleBack = {
  ...headerStyleSide.headerStyleSide,
  headerTintColor: '#fff',
};

export default function SettingsNavigator() {
  const { colors } = useTheme();

  headerStyleBack.headerStyle.backgroundColor = colors.navigationBarColor;

  return (
    <Stack.Navigator screenOptions={headerStyleBack}>
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="Reset Password" component={ResetPasswordScreen} />
      <Stack.Screen name="Profile" component={ProfileView} />
    </Stack.Navigator>
  );
}
