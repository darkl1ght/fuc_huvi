import { useTheme } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import React from 'react';
import 'react-native-gesture-handler';
import headerStyleSide from '../../../styles/header';
import ClientsScreen from '../../clients/ClientsViewContainer';
import ProjectsScreen from '../../projects/ProjectsViewContainer';
import ProjectDetailsNavigator from './ProjectDetailsNavigator';

const Stack = createStackNavigator();

let headerStyleBack = {
  ...headerStyleSide.headerStyleSide,
  headerTintColor: '#fff',
};

export default function App({ initialRouteName }) {
  const { colors } = useTheme();

  headerStyleBack.headerStyle.backgroundColor = colors.navigationBarColor;

  return (
    <Stack.Navigator
      initialRouteName={initialRouteName}
      screenOptions={headerStyleBack}
    >
      <Stack.Screen name="Clients" component={ClientsScreen} />
      <Stack.Screen name="Projects" component={ProjectsScreen} />

      <Stack.Screen
        name="Project Details"
        component={ProjectDetailsNavigator}
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
}
