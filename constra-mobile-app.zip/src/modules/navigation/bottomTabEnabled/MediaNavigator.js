import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { Image, TouchableOpacity } from 'react-native';
import ProjectAlbumsScreen from '../../albums/AlbumViewContainer';
import ProjectMediaScreen from '../../albums/media/MediaViewContainer';
import headerStyleSide from '../../../styles/header';
import PanoramaVideoPlayer from '../../interiors/panoramavideoplayer/PanoramavideoplayerViewContainer';
import DiscussionView from '../../discussion/DiscussionViewContainer';
import { useTheme } from 'react-native-paper';

const Stack = createStackNavigator();

export default function App({ navigation, projectName }) {
  const headerLeftComponentMenu = () => {
    return (
      <TouchableOpacity
        onPress={() => navigation.toggleDrawer()}
        style={{
          paddingHorizontal: 16,
          paddingVertical: 12,
        }}
      >
        <Image
          source={require('../../../../assets/images/drawer/menu.png')}
          resizeMode="contain"
          style={{
            height: 20,
          }}
        />
      </TouchableOpacity>
    );
  };

  const { colors } = useTheme();

  const headerStyle = {
    ...headerStyleSide.headerStyleSide,
    headerLeft: headerLeftComponentMenu,
    headerStyle: {
      backgroundColor: colors.navigationBarColor,
    },
  };

  const headerStyleBack = {
    ...headerStyleSide.headerStyleSide,
    headerTintColor: '#fff',
    headerStyle: {
      backgroundColor: colors.navigationBarColor,
    },
  };

  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Albums"
        component={ProjectAlbumsScreen}
        options={{ ...headerStyle, title: `Albums - ${projectName}` }}
      />
      <Stack.Screen
        name="Media"
        component={ProjectMediaScreen}
        options={({ route }) => ({
          ...headerStyleBack,
          title: route.params.albumName,
        })}
      />

      <Stack.Screen
        name="Panorama Video Player"
        component={PanoramaVideoPlayer}
        options={headerStyleBack}
      />
      <Stack.Screen
        name="Media Discussion"
        component={DiscussionView}
        options={headerStyleBack}
      />
    </Stack.Navigator>
  );
}
