// @flow
import React from 'react';
import { Divider, FAB, List } from 'react-native-paper';
import { View, FlatList, SafeAreaView } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import Config from '../utils/config';
import Routes from '../navigation/routes';
import { saveProject } from '../projects/ProjectsState';
import { useTheme } from 'react-native-paper';
import reverse from 'lodash/reverse';
import {
  marknotificationRead,
  markAllNotificationsRead,
} from './NotificationsState';
import groupBy from 'lodash/groupBy';
import {
  parseISO,
  format,
  isToday,
  isYesterday,
  isThisWeek,
} from 'date-fns/esm';
import map from 'lodash/map';
import { Text } from '../../components/StyledText';
import notifee from '@notifee/react-native';

const getIconByNotificationType = notificationType => {
  switch (notificationType) {
    case Config.get('INTERIOR_TOUR'):
      return 'map-marker-distance';
    case Config.get('MEDIA_UPLOADED'):
      return 'folder-multiple-image';
    case Config.get('AERIAL_TOUR_PUBLISHED'):
      return 'earth-box';
    default:
      break;
  }
};

export default ({ navigation }) => {
  const dispatch = useDispatch();

  const notifications = useSelector(
    ({ notification }) => notification.notifications,
  );

  const theme = useTheme();

  const markNotificationAsRead = messageId =>
    dispatch(marknotificationRead(messageId));

  const markAllNotificationsAsRead = () => dispatch(markAllNotificationsRead());

  const handleNotificationPressEvent = async notification => {
    switch (notification.actionType) {
      case Config.get('INTERIOR_TOUR'):
        if (!notification.notificationSeen)
          markNotificationAsRead(notification.messageId);

        await notifee.cancelNotification(notification.messageId);

        navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
          screen: Routes.WALKTHROUGH_VIRTUAL_TOUR,
          params: {
            ...notification,
            isPushNotification: true,
          },
        });
        break;
      case Config.get('MEDIA_UPLOADED'):
        if (!notification.notificationSeen)
          markNotificationAsRead(notification.messageId);

        await notifee.cancelNotification(notification.messageId);

        dispatch(saveProject(notification.projectId));

        navigation.navigate('Project Details', {
          screen: 'Media Navigator',
          params: {
            screen: 'Media',
            params: {
              ...notification,
              isPushNotification: true,
            },
          },
        });
        break;
      case Config.get('AERIAL_TOUR_PUBLISHED'):
        if (!notification.notificationSeen)
          markNotificationAsRead(notification.messageId);

        await notifee.cancelNotification(notification.messageId);
        navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
          screen: 'Map',
          params: {
            ...notification,
            isPushNotification: true,
          },
        });
        break;
      default:
        break;
    }
  };

  let groupedByDate = groupBy(notifications, n => {
    let parsedDate = parseISO(n.date);
    if (isToday(parsedDate)) return 'Today';
    else if (isYesterday(parsedDate)) return 'Yesterday';
    else if (isThisWeek(parsedDate)) return 'This week';
    else return format(parsedDate, 'LLLL dd, yyyy');
  });

  let groupedNotificationsArray = map(groupedByDate, function(items, date) {
    return {
      date,
      notifications: reverse(items),
    };
  });

  const listItem = ({ item }) => {
    return (
      <>
        <List.Section style={{ elevation: 10, margin: 5 }}>
          <List.Subheader>{item.date}</List.Subheader>
          {item.notifications.map(notification => (
            <List.Item
              style={{
                backgroundColor: theme.colors.surface,
              }}
              key={notification.messageId}
              titleStyle={{
                fontWeight: notification.notificationSeen ? 'normal' : 'bold',
              }}
              descriptionStyle={{
                fontWeight: notification.notificationSeen ? 'normal' : 'bold',
              }}
              descriptionNumberOfLines={4}
              title={notification.title}
              description={notification.body}
              left={props => (
                <List.Icon
                  {...props}
                  color={theme.colors.primary}
                  icon={getIconByNotificationType(notification.actionType)}
                />
              )}
              onPress={async () =>
                await handleNotificationPressEvent(notification)
              }
            />
          ))}
        </List.Section>
        <Divider style={{ borderColor: theme.colors.onSurface }} />
      </>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      {notifications.length > 0 && (
        <FlatList
          data={reverse(groupedNotificationsArray)}
          renderItem={listItem}
          keyExtractor={item => item.date}
          contentContainerStyle={{ padding: 5, marginTop: 10 }}
        />
      )}
      {notifications.length === 0 && (
        <View
          style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
        >
          <Text color={theme.colors.onSurface} size={24}>
            No notifications to show
          </Text>
        </View>
      )}
      {notifications?.some(notification => !notification.notificationSeen) && (
        <FAB
          label={'Mark all as read'}
          small
          animated
          uppercase={false}
          icon="check-all"
          style={{
            position: 'absolute',
            margin: 16,
            right: 0,
            bottom: 0,
          }}
          onPress={markAllNotificationsAsRead}
        />
      )}
    </SafeAreaView>
  );
};
