// Initial state
const initialState = {
  notifications: [],
};

const SAVE_NOTIFICATION = 'NOTIFICATION_STATE/SAVE_NOTIFICATION';
const NOTIFICATION_READ = 'NOTIFICATION_STATE/NOTIFICATION_READ';
const ALL_NOTIFICATIONS_READ = 'NOTIFICATION_STATE/ALL_NOTIFICATIONS_READ';

// Action creators
export function saveNotification(notification) {
  return {
    type: SAVE_NOTIFICATION,
    payload: {
      notification,
    },
  };
}

export function marknotificationRead(messageId) {
  return {
    type: NOTIFICATION_READ,
    payload: {
      messageId,
    },
  };
}
export function markAllNotificationsRead() {
  return {
    type: ALL_NOTIFICATIONS_READ,
  };
}
// Reducer
export default function NotificatonsStateReducer(
  state = initialState,
  action = {},
) {
  switch (action.type) {
    case SAVE_NOTIFICATION:
      let notifications = [...state.notifications];
      notifications.push({
        ...action.payload.notification,
        notificationSeen: false,
        date: new Date().toISOString(),
      });
      return Object.assign({}, state, {
        notifications,
      });
    case NOTIFICATION_READ:
      let modifiedNotifications = state.notifications.map(notification => {
        if (notification.messageId === action.payload.messageId)
          notification.notificationSeen = true;
        return notification;
      });
      return Object.assign({}, state, {
        notifications: modifiedNotifications,
      });
    case ALL_NOTIFICATIONS_READ:
      let allNotifications = state.notifications.map(notification => {
        notification.notificationSeen = true;
        return notification;
      });
      return Object.assign({}, state, {
        notifications: allNotifications,
      });
    default:
      return state;
  }
}
