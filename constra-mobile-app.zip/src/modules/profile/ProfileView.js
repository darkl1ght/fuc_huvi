import messaging from '@react-native-firebase/messaging';
import { Formik } from 'formik';
import * as React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { getUniqueId } from 'react-native-device-info';
import {
  Button,
  Dialog,
  Paragraph,
  Portal,
  Snackbar,
  TextInput,
  useTheme,
} from 'react-native-paper';
import * as Yup from 'yup';
import ActivityIndicator from '../../components/ActivityIndicator';
import { Text } from '../../components/StyledText';
import notiffee from '@notifee/react-native';

let fNamePlaceholder = 'First Name';
let lNamePlaceholder = 'Last Name';
let emailPlaceholder = 'Email';
let phonePlaceholder = 'Phone';
const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

const profileFormSchema = Yup.object().shape({
  fName: Yup.string()
    .required()
    .label('First Name'),
  lName: Yup.string()
    .required()
    .label('Last Name'),
  email: Yup.string()
    .required()
    .label('Email'),
  phone: Yup.string().matches(phoneRegExp, 'Phone number is not valid'),
});

export default function ProfileView(props) {
  const { colors } = useTheme();
  const [dialogVisible, setDialogVisible] = React.useState(false);

  const showDialog = () => setDialogVisible(true);

  const hideDialog = () => setDialogVisible(false);

  return (
    <>
      <View>
        <Formik
          enableReinitialize={true}
          initialValues={{
            fName: props.user.firstName,
            lName: props.user.lastName,
            email: props.user.email,
            phone: props.user.phone,
          }}
          onSubmit={({ fName, lName, email, phone }) => {
            let user = props.user;
            user.firstName = fName;
            user.lastName = lName;
            user.email = email;
            user.phone = phone;
            props.updateUser(user);
          }}
          validationSchema={profileFormSchema}
        >
          {({
            handleChange,
            handleSubmit,
            errors,
            setFieldTouched,
            touched,
          }) => (
            <>
              <ScrollView>
                <View style={styles.container}>
                  <TextInput
                    mode="outlined"
                    autoCapitalize="none"
                    label="Email"
                    autoCorrect={false}
                    dense
                    disabled={true}
                    onBlur={() => setFieldTouched('email')}
                    style={styles.input}
                    onChangeText={handleChange('email')}
                    placeholder={emailPlaceholder}
                    defaultValue={props.user.email}
                  />
                  <TextInput
                    mode="outlined"
                    autoCapitalize="none"
                    style={styles.input}
                    autoCorrect={false}
                    label="First Name"
                    dense
                    onBlur={() => setFieldTouched('fName')}
                    onChangeText={handleChange('fName')}
                    placeholder={fNamePlaceholder}
                    defaultValue={props.user.firstName}
                  />
                  {touched.fName && errors.fName !== undefined && (
                    <Text style={styles.error}>{errors.fName}</Text>
                  )}
                  <TextInput
                    mode="outlined"
                    autoCapitalize="none"
                    dense
                    label="Last Name"
                    autoCorrect={false}
                    style={styles.input}
                    onBlur={() => setFieldTouched('lName')}
                    onChangeText={handleChange('lName')}
                    placeholder={lNamePlaceholder}
                    error={errors.lName}
                    defaultValue={props.user.lastName}
                  />
                  {touched.lName && errors.lName && (
                    <Text style={styles.error}>{errors.lName}</Text>
                  )}

                  <TextInput
                    autoCapitalize="none"
                    mode="outlined"
                    label="Contact Number"
                    autoCorrect={false}
                    dense
                    style={styles.input}
                    onBlur={() => setFieldTouched('phone')}
                    onChangeText={handleChange('phone')}
                    placeholder={phonePlaceholder}
                    error={errors.phone}
                    defaultValue={props.user.phone}
                  />
                  {touched.phone && errors.phone && (
                    <Text style={styles.error}>{errors.phone}</Text>
                  )}
                  <Button
                    style={{ margin: 10, marginTop: 15 }}
                    uppercase={false}
                    mode="contained"
                    icon="content-save"
                    accessibilityLabel="Save"
                    onPress={handleSubmit}
                    disabled={props.isLoading}
                  >
                    Save Profile
                  </Button>

                  <Button
                    style={{ margin: 10 }}
                    uppercase={false}
                    icon="logout"
                    mode="contained"
                    onPress={showDialog}
                  >
                    Logout
                  </Button>
                </View>

                <Portal>
                  <Dialog visible={dialogVisible} onDismiss={hideDialog}>
                    <Dialog.Title>Are you sure ?</Dialog.Title>
                    <Dialog.Content>
                      <Paragraph>
                        This will log you out of the application
                      </Paragraph>
                    </Dialog.Content>
                    <Dialog.Actions>
                      <Button
                        onPress={async () => {
                          hideDialog();
                          await notiffee.cancelAllNotifications();
                          messaging()
                            .getToken()
                            .then(token =>
                              props.deleteGCMToken(token, getUniqueId()),
                            );
                        }}
                      >
                        Yes
                      </Button>
                      <Button onPress={hideDialog}>No</Button>
                    </Dialog.Actions>
                  </Dialog>
                </Portal>
              </ScrollView>
            </>
          )}
        </Formik>
      </View>
      <>
        <ActivityIndicator visible={props.isLoading} />
        <Snackbar
          visible={props.error}
          duration={1500}
          onDismiss={() => props.resetError()}
        >
          Something Went Wrong.
        </Snackbar>
        <Snackbar
          visible={props.success}
          duration={1500}
          onDismiss={() => props.resetSuccess()}
        >
          Profile details saved successfully.
        </Snackbar>
      </>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 10,
    marginTop: 20,
  },
  view: {
    paddingTop: 10,
  },
  input: {
    margin: 10,
  },
  submitButton: {
    backgroundColor: '#7a42f4',
    padding: 10,
    margin: 15,
    height: 40,
  },
  submitButtonText: {
    color: 'white',
  },
  error: {
    margin: 10,
    marginTop: -1,
    color: 'red',
  },
});
