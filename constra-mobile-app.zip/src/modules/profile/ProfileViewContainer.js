// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import ProfileView from './ProfileView';
import {
  resetError,
  resetSuccess,
  updateUser,
  deleteGCMToken,
} from './ProfileState';
export default compose(
  connect(
    ({ profile, login, projects }) => ({
      isLoading: profile.isLoading,
      user: login.user,
      projectId: projects.projectId,
      error: profile.isErrorInLogging,
      success: profile.isSuccessInLogging,
    }),
    dispatch => ({
      updateUser: user => dispatch(updateUser(user)),
      resetError: () => dispatch(resetError()),
      resetSuccess: () => dispatch(resetSuccess()),
      deleteGCMToken: (token, deviceId) =>
        dispatch(deleteGCMToken(token, deviceId)),
    }),
  ),
  lifecycle({
    componentDidMount() {
      this.focusListener = this.props.navigation.addListener('focus', () => {
        this.setState({
          fName: this.props.user.firstName,
          lName: this.props.user.lastName,
          email: this.props.user.email,
        });
      });
    },
    componentWillUnmount() {
      this.setState = (state, callback) => {
        return;
      };
    },
  }),
)(ProfileView);
