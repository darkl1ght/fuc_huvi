// Initial state
const initialState = {
  isLoading: false,
  isErrorInLogging: false,
  user: {},
  isUserLoggedIn: false,
};

// Actions
const START_LOGIN_LOADING = 'LoginState/START_LOADING';
const USER_LOADED = 'LoginState/USER_LOADED';
const USER_ERROR = 'LoginState/USER_ERROR';
const RESET_USER_ERROR = 'LoginState/RESET_USER_ERROR';

// Action creators
function startLoginLoading() {
  return { type: START_LOGIN_LOADING };
}

export function loginUser(email, password) {
  return dispatch => {
    dispatch(startLoginLoading());

    dispatch({
      isProjectApi: false,
      type: 'apiCallBegan',
      payload: {
        url: '/users/login',
        method: 'POST',
        data: {
          user: {
            email,
            password,
          },
        },
        onSuccess: USER_LOADED,
        onError: USER_ERROR,
      },
    });
  };
}

export function resetError() {
  return { type: RESET_USER_ERROR };
}

// Reducer
export default function LoginStateReducer(state = initialState, action = {}) {
  switch (action.type) {
    case START_LOGIN_LOADING:
      return Object.assign({}, state, {
        isLoading: true,
        isErrorInLogging: false,
      });
    case USER_LOADED:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
        isUserLoggedIn: true,
        user: action.payload.user,
      });
    case USER_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: true,
      });
    case RESET_USER_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
      });
    default:
      return state;
  }
}
