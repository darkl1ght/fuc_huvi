import React, { useState } from 'react';
import {
  Image,
  StyleSheet,
  View,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import {
  Button,
  TextInput,
  Snackbar,
  useTheme,
  Colors,
} from 'react-native-paper';
import colors from '../../styles/colors';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { Text } from '../../components/StyledText';
import ActivityIndicator from '../../components/ActivityIndicator';

let emailInputPlaceholder = 'Email';
let passwordInputPlaceholder = 'Password';

const loginFormSchema = Yup.object().shape({
  email: Yup.string()
    .required()
    .email()
    .label('Email'),
  password: Yup.string()
    .required()
    .min(8)
    .label('Password'),
});

export default function LoginScreen(props) {
  const { colors } = useTheme();
  // Show and hide password input icon
  const [isPasswordVisible, setPasswordVisible] = useState(false);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ActivityIndicator
        visible={props.isLoading}
        style={{ backgroundColor: Colors.grey900 }}
      />
      <ScrollView style={styles.container}>
        <Image
          resizeMode="contain"
          style={styles.brandLogo}
          source={require('../../../assets/images/constra-logo.png')}
        />
        <Text style={styles.header} size={18} white>
          Login to Constra
        </Text>
        <Formik
          initialValues={{ email: '', password: '' }}
          onSubmit={({ email, password }) => {
            props.loginUser(email, password);
          }}
          validationSchema={loginFormSchema}
        >
          {({
            handleChange,
            handleSubmit,
            errors,
            setFieldTouched,
            touched,
          }) => (
            <View style={styles.loginForm}>
              <TextInput
                autoCapitalize="none"
                autoCorrect={false}
                textContentType="emailAddress"
                keyboardType="email-address"
                onBlur={() => setFieldTouched('email')}
                style={styles.email}
                onChangeText={handleChange('email')}
                placeholder={emailInputPlaceholder}
                error={errors.email}
              />
              {touched.email && errors.email !== undefined && (
                <Text style={styles.error}>{errors.email}</Text>
              )}
              <TextInput
                autoCapitalize="none"
                autoCorrect={false}
                style={styles.password}
                secureTextEntry={!isPasswordVisible}
                textContentType="password"
                onBlur={() => setFieldTouched('password')}
                onChangeText={handleChange('password')}
                right={
                  <TextInput.Icon
                    name={isPasswordVisible ? 'eye-off' : 'eye'}
                    forceTextInputFocus={false}
                    onPress={() => setPasswordVisible(!isPasswordVisible)}
                  />
                }
                placeholder={passwordInputPlaceholder}
                error={errors.password}
              />
              {touched.password && errors.password && (
                <Text style={styles.error}>{errors.password}</Text>
              )}
              <Button
                color={colors.surface}
                icon="login"
                mode="contained"
                accessibilityLabel="Login Button"
                onPress={handleSubmit}
                disabled={props.isLoading}
              >
                Login
              </Button>

              <Button
                mode="text"
                style={styles.forgotPassword}
                color={'#ffffff'}
                onPress={() => props.navigation.navigate('Forgot Password')}
                compact={true}
                uppercase={false}
              >
                Forgot password?
              </Button>
            </View>
          )}
        </Formik>
      </ScrollView>
      <Snackbar
        visible={props.error}
        duration={1500}
        onDismiss={() => props.resetError()}
      >
        Invalid credentials, please check your email and password.
      </Snackbar>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primary,
  },
  brandLogo: {
    width: 200,
    height: 150,
    alignSelf: 'center',
  },
  loginForm: {
    margin: 20,
  },
  password: {
    height: 46,
    marginBottom: 20,
  },
  email: {
    height: 46,
    marginBottom: 15,
  },
  loginButton: {
    margin: 10,
  },

  header: {
    margin: 5,
    marginBottom: 5,
    marginTop: 10,
    justifyContent: 'center',
    textAlign: 'center',
  },

  error: {
    paddingBottom: 8,
    marginTop: -10,
    color: '#DDE809',
  },
  forgotPassword: {
    marginTop: 20,
  },
});
