// @flow
import { compose } from 'recompose';
import { connect } from 'react-redux';

import LoginScreen from './LoginView';
import { loginUser, resetError } from './LoginState';
export default compose(
  connect(
    ({ login }) => ({
      isLoading: login.isLoading,
      user: login.user,
      error: login.isErrorInLogging,
    }),
    dispatch => ({
      loginUser: (email, password) => dispatch(loginUser(email, password)),
      resetError: () => dispatch(resetError()),
    }),
  ),
)(LoginScreen);
