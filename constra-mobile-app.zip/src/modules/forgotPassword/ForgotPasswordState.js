export const initialState = {
  isLoading: false,
  responseStatus: '',
  isErrorInSendingEmail: false,
  timer: 0,
};

// Actions
const START_FORGOT_PASSWORD_LOADING = 'ForgotpasswordState/START_LOADING';
const FORGOT_PASSWORD_LOADED = 'ForgotpasswordState/FORGOT_PASSWORD_LOADED';
const FORGOT_PASSWORD_ERROR = 'ForgotpasswordState/FORGOT_PASSWORD_ERROR';
const RESET_FORGOT_PASSWORD_ERROR =
  'ForgotpasswordState/RESET_FORGOT_PASSWORD_ERROR';
const RESET_FORGOT_PASSWORD_RESPONSE =
  'ForgotpasswordState/RESET_FORGOT_PASSWORD_RESPONSE';
const START_RESET_EMAIL_TIMER = 'ForgotpasswordState/START_RESET_EMAIL_TIMER';
const STOP_RESET_EMAIL_TIMER = 'ForgotpasswordState/STOP_RESET_EMAIL_TIMER';

let timer;

// Action creators
function startForgotPasswordLoading() {
  return { type: START_FORGOT_PASSWORD_LOADING };
}

export function sendForgotPasswordEmail(email) {
  return dispatch => {
    dispatch(startForgotPasswordLoading());

    dispatch({
      isProjectApi: false,
      type: 'apiCallBegan',
      payload: {
        url: '/users/forgot',
        method: 'POST',
        data: {
          email,
        },
        onSuccess: FORGOT_PASSWORD_LOADED,
        onError: FORGOT_PASSWORD_ERROR,
      },
    });
  };
}
export function startEmailTimer(isReset = false) {
  return dispatch => {
    if (!isReset) {
      timer = setInterval(() => {
        dispatch(startResetEmailTimer());
      }, 1000);
    }
    if (isReset) {
      clearInterval(timer);
      dispatch(stopEmailTimer());
    }
  };
}

export function stopEmailTimerOnDestroy() {
  clearInterval(timer);
  timer = null;
}

function startResetEmailTimer() {
  return { type: START_RESET_EMAIL_TIMER };
}

export function stopEmailTimer() {
  return { type: STOP_RESET_EMAIL_TIMER };
}

export function resetError() {
  return { type: RESET_FORGOT_PASSWORD_ERROR };
}
export function resetResponse() {
  return { type: RESET_FORGOT_PASSWORD_RESPONSE };
}

// Reducer
export default function ForgotPasswordStateReducer(
  state = initialState,
  action = {},
) {
  console.log(action.type);
  switch (action.type) {
    case START_FORGOT_PASSWORD_LOADING:
      return Object.assign({}, state, {
        isLoading: true,
        isErrorInSendingEmail: false,
      });
    case START_RESET_EMAIL_TIMER:
      return Object.assign({}, state, {
        timer: state.timer + 1,
      });
    case STOP_RESET_EMAIL_TIMER:
      return Object.assign({}, state, {
        timer: 0,
      });
    case FORGOT_PASSWORD_LOADED:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInSendingEmail: false,
        responseStatus: action.payload.status,
      });
    case FORGOT_PASSWORD_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInSendingEmail: true,
      });
    case RESET_FORGOT_PASSWORD_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInSendingEmail: false,
        responseStatus: '',
      });
    case RESET_FORGOT_PASSWORD_RESPONSE:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInSendingEmail: false,
        responseStatus: '',
      });
    default:
      return state;
  }
}
