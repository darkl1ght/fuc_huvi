// @flow
import { Formik } from 'formik';
import React, { useEffect } from 'react';
import { Text } from '../../components/StyledText';
import * as Yup from 'yup';
import { View, StyleSheet } from 'react-native';
import { TextInput, Button, Colors, Snackbar } from 'react-native-paper';
import { colors } from '../../styles';
import ActivityIndicator from '../../components/ActivityIndicator';
import { stopEmailTimerOnDestroy } from './ForgotPasswordState';

const forgotPasswordSchema = Yup.object().shape({
  email: Yup.string()
    .required()
    .email()
    .label('Email'),
});
const successState = '00000';
const errorState = '10001';
const technicalErrorMessage =
  'Unable to send reset password email, please try again.';
const invalidEmailErrorMessage = 'Please enter a valid registered email.';

export default props => {
  // Effect hook
  useEffect(() => {
    if (props.timer > 0) props.startEmailTimer();
    return () => {
      stopEmailTimerOnDestroy();
    };
  }, []);

  useEffect(() => {
    if (props.timer === 30) props.resetTimer();
  }, [props.timer]);

  return (
    <>
      <ActivityIndicator
        visible={props.isLoading}
        style={{ backgroundColor: Colors.grey900 }}
      />
      <View style={styles.container}>
        <Text bold size={30} style={styles.title} white>
          Forgot password ?
        </Text>
        <Text size={16} style={styles.header} white>
          Enter the email associated with your account and we'll send an email
          with instructions to reset your password
        </Text>
        <Formik
          initialValues={{ email: '' }}
          onSubmit={({ email }) => {
            props.sendForgotPasswordEmail(email);
          }}
          validationSchema={forgotPasswordSchema}
        >
          {({
            handleChange,
            handleSubmit,
            errors,
            setFieldTouched,
            touched,
          }) => (
            <View style={styles.resetForm}>
              <Text white size={12} style={{ marginBottom: 5 }}>
                Email address
              </Text>
              <TextInput
                autoCapitalize="none"
                autoCorrect={false}
                textContentType="emailAddress"
                keyboardType="email-address"
                onBlur={() => setFieldTouched('email')}
                style={styles.email}
                onChangeText={handleChange('email')}
                error={errors.email}
              />
              {touched.email && errors.email !== undefined && (
                <Text style={styles.error}>{errors.email}</Text>
              )}
              <Button
                color={colors.white}
                icon="lock-reset"
                mode="contained"
                uppercase={false}
                accessibilityLabel="Reset email Button"
                onPress={props.timer > 0 ? () => {} : handleSubmit}
                disabled={props.isLoading}
                style={styles.resetEmailButton}
              >
                {props.timer > 0
                  ? `${30 - props.timer} seconds remaining`
                  : 'Send email to reset password'}
              </Button>
            </View>
          )}
        </Formik>
      </View>
      <Snackbar
        visible={props.error || props.responseStatus === errorState}
        duration={3000}
        onDismiss={() => props.resetError()}
      >
        {props.error && technicalErrorMessage}
        {props.responseStatus === errorState && invalidEmailErrorMessage}
      </Snackbar>
      <Snackbar
        visible={props.responseStatus === successState}
        duration={1800}
        onDismiss={() => {
          props.startEmailTimer();
          props.resetResponse();
        }}
      >
        Reset email has been sent successfully
      </Snackbar>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primary,
    padding: 20,
  },
  resetForm: {
    marginTop: 40,
  },
  title: {
    padding: 5,
  },
  email: {
    height: 46,
    marginBottom: 15,
  },
  header: {
    marginTop: 10,
    padding: 5,
  },
  error: {
    paddingBottom: 8,
    marginTop: -10,
    color: '#DDE809',
  },
  resetEmailButton: {
    marginTop: 20,
  },
});
