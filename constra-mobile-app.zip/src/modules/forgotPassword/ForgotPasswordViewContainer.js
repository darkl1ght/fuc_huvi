import { compose } from 'recompose';
import { connect } from 'react-redux';

import ForgotPasswordView from './ForgotPasswordView';

import {
  sendForgotPasswordEmail,
  resetError,
  resetResponse,
  startEmailTimer,
} from './ForgotPasswordState';

export default compose(
  connect(
    ({ forgotPassword }) => ({
      isLoading: forgotPassword.isLoading,
      responseStatus: forgotPassword.responseStatus,
      error: forgotPassword.isErrorInSendingEmail,
      timer: forgotPassword.timer,
    }),
    dispatch => ({
      sendForgotPasswordEmail: email =>
        dispatch(sendForgotPasswordEmail(email)),
      resetError: () => dispatch(resetError()),
      resetResponse: () => dispatch(resetResponse()),
      resetTimer: () => dispatch(startEmailTimer(true)),
      startEmailTimer: () => dispatch(startEmailTimer()),
    }),
  ),
)(ForgotPasswordView);
