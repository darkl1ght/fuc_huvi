// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';
import MapView from './MapView';
import Orientation from 'react-native-orientation-locker';
import { getAllLayerLookUps, resetError, getTourDetails } from './MapState';

export default compose(
  connect(
    ({ map }) => ({
      isLoading: map.isLoading,
      map: map.map,
      error: map.isErrorInLogging,
      tour: map.tour,
    }),
    dispatch => ({
      getAllLayerLookUps: () => dispatch(getAllLayerLookUps()),
      resetError: () => dispatch(resetError()),
      getTourDetails: (projectId, tourId) =>
        dispatch(getTourDetails(projectId, tourId)),
    }),
  ),
  lifecycle({
    componentDidMount() {
      // Hide status bar to make it full screen
      Orientation.lockToLandscape();

      const { route, getTourDetails, getAllLayerLookUps } = this.props;
      const { isPushNotification = false, projectId, tourId } = route.params;

      if (isPushNotification) getTourDetails(projectId, tourId);

      this.focusListener = this.props.navigation.addListener('focus', () => {
        getAllLayerLookUps();
      });
    },
    componentWillUnmount() {
      // Unlock orientations and enable status bar
      Orientation.unlockAllOrientations();
    },
  }),
)(MapView);
