// Initial state
const initialState = {
  isLoading: false,
  isErrorInLogging: false,
  map: [],
};

// Actions
const START_LAYER_LOADING = 'MAP_STATE/START_LOADING';
const LAYER_LOADED = 'MAP_STATE/LAYER_LOADED';
const LAYER_ERROR = 'MAP_STATE/LAYER_ERROR';
const RESET_LAYER_ERROR = 'MAP_STATE/RESET_LAYER_ERROR';

const FETCH_TOUR_DETAILS_STARTED = 'MAP_STATE/START_LOADING_TOUR_DETAILS';
const TOUR_DETAILS_LOADED = 'MAP_STATE/TOURS_LOADED';
const TOUR_DETAILS_ERROR = 'MAP_STATE/ERROR_IN_LOADING_TOURS';

// Action creators
function startLayerLoading() {
  return { type: START_LAYER_LOADING };
}

function startLoadingTourDetails() {
  return { type: FETCH_TOUR_DETAILS_STARTED };
}

export function getAllLayerLookUps() {
  return dispatch => {
    dispatch(startLayerLoading());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: '/lookups/lookup/layerColor',
        onSuccess: LAYER_LOADED,
        onError: LAYER_ERROR,
      },
    });
  };
}

export function getTourDetails(projectId, tourId) {
  return dispatch => {
    dispatch(startLoadingTourDetails());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/aerialTour/${projectId}/${tourId}`,
        onSuccess: TOUR_DETAILS_LOADED,
        onError: TOUR_DETAILS_ERROR,
      },
    });
  };
}

export function resetError() {
  return { type: RESET_LAYER_ERROR };
}

// Reducer
export default function MapStateReducer(state = initialState, action = {}) {
  switch (action.type) {
    case START_LAYER_LOADING:
    case FETCH_TOUR_DETAILS_STARTED:
      return Object.assign({}, state, {
        isLoading: true,
        isErrorInLogging: false,
      });
    case LAYER_LOADED:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
        map: action.payload.lookups,
      });
    case TOUR_DETAILS_LOADED:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
        tour: action.payload.tour,
      });
    case LAYER_ERROR:
    case TOUR_DETAILS_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: true,
      });
    case RESET_LAYER_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
      });
    default:
      return state;
  }
}
