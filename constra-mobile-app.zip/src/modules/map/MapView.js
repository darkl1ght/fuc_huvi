import React, { useEffect, useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  SafeAreaView,
  Alert,
} from 'react-native';
import MapboxGL from '@react-native-mapbox-gl/maps';
import { colors } from '../../styles';
import { Button, Checkbox, Colors, IconButton } from 'react-native-paper';
import { BottomSheet } from 'react-native-btr';
import Routes from '../navigation/routes';
import { OrientationLocker, LANDSCAPE } from 'react-native-orientation-locker';
import Slider from '@react-native-community/slider';
import config from '../utils/config';
import ActivityIndicator from '../../components/ActivityIndicator';
import { useAsyncStorage } from '@react-native-async-storage/async-storage';

const clientOptions = { accessToken: config.get('accessToken') };
MapboxGL.setAccessToken(clientOptions.accessToken);

export default function MapView({ route, navigation, map, tour, isLoading }) {
  this.state = {
    opacity: 1,
    annotationsDataState: [],
  };

  const [visible, setVisible] = useState(false);
  const [dataMapAnn, setDataMapAnn] = useState([]);
  const [dataAnn, setDataAnn] = useState([]);
  const [dataCustomLayer, setDataCustomLayer] = useState([]);
  const [dataLayer, setDataLayer] = useState([]);
  const [mapRasterData, setMapRasterData] = useState([]);
  const [mapData, setMapData] = useState();

  const [layersVisible, setLayersVisible] = useState(true);
  const [layerOpacity, setLayerOpacity] = useState(1);

  const [customAnnVisible, setCustomAnnVisible] = useState(true);

  //Map Vector Layer Data
  const [mapVectorData, setMapVectorData] = useState([]);

  //Bottom Layer CheckBox Layer Data
  const prefixMapUrl = 'https://api.mapbox.com/v4/';
  const suffixMapUrl =
    '/{z}/{x}/{y}.png?access_token=' + clientOptions.accessToken;

  const isRasterLayerSelected = () => {
    return mapRasterData.some(rasterData => !rasterData.disabled);
  };

  const toggleBottomNavigationView = () => {
    setVisible(!visible);
  };

  const toggleAllLayers = () => {
    setMapRasterData(
      mapRasterData.map(data => {
        data.disabled = layersVisible;
        return data;
      }),
    );
    setMapVectorData(
      mapVectorData.map(data => {
        data.disabled = layersVisible;
        return data;
      }),
    );

    setDataMapAnn(
      dataMapAnn.map(data => {
        data.isEnabled = !layersVisible;
        return data;
      }),
    );

    setDataLayer(
      dataLayer.map(layer => {
        layer.disabled = layersVisible;
        return layer;
      }),
    );
  };

  const toggleCustomAnnotationsAndLayers = () => {
    setDataMapAnn(
      dataMapAnn.map(data => {
        data.isEnabled = !customAnnVisible;
        return data;
      }),
    );
    setDataCustomLayer(
      dataCustomLayer.map(layer => {
        layer.isEnabled = !customAnnVisible;
        return layer;
      }),
    );
    setDataAnn(
      dataAnn.map(data => {
        data.isEnabled = !customAnnVisible;
        return data;
      }),
    );
  };

  //Bottom Layer checkbox for Custom layer
  const customLayerData = map.map(data => ({
    ...data,
    isEnabled: true,
  }));

  // Used to determine app rating screen
  useEffect(() => {
    const aerialViewCount = async () => {
      const { getItem, setItem } = useAsyncStorage('aerial_tour_view_count');

      const count = await getItem();
      if (count == null) {
        setItem(JSON.stringify(0));
      } else setItem(JSON.stringify(parseInt(count) + 1));
    };
    aerialViewCount();
  }, []);

  useEffect(() => {
    setMapData(route.params.isPushNotification ? tour : route.params.data);

    if (mapData) {
      const layerOrder = [];

      const currMapUrls = [...mapData.mapUrls];
      for (const url of currMapUrls) {
        if (
          url.appendIndex !== null &&
          url.appendIndex !== undefined &&
          url.appendIndex >= 0
        ) {
          layerOrder.push({
            code: url.key,
            order: url.appendIndex,
          });
        }
      }
      layerOrder.sort((a, b) => {
        return a.order - b.order;
      });
      const sortedMapUrls = [
        ...layerOrder.map(i =>
          currMapUrls.find(j => j.appendIndex === i.order),
        ),
      ];
      const overlayLayers = [];
      for (const layer of sortedMapUrls) {
        const layerCopy = Object.assign({}, layer);
        if (layerCopy.type == 'shapefile') {
          layerCopy.code = 'Contour';
          layerCopy.minZoom = 14;
          layerCopy.maxZoom = 24;
          layerCopy.dataType = 'vector';
          layerCopy.sourceLayer = layerCopy.value.split('.')[1];
          layerCopy.url = layerCopy.value;
        } else if (
          layerCopy.type == 'orthomosaic' ||
          layerCopy.type == 'dsm' ||
          layerCopy.type == 'dtm'
        ) {
          layerCopy.code = layerCopy.type;
          layerCopy.minZoom = 14;
          layerCopy.maxZoom = 24;
          layerCopy.dataType = 'raster';
          layerCopy.url = layerCopy.value;
          layerCopy.tilesize = 256;
        } else if (layerCopy.type == 'user_tif') {
          layerCopy.code = layerCopy.key;
          layerCopy.minZoom = 14;
          layerCopy.maxZoom = 24;
          layerCopy.dataType = 'raster';
          layerCopy.url = layerCopy.value;
          layerCopy.tilesize = 256;
        } else if (layerCopy.type == 'user_zipped_shapefile') {
          layerCopy.code = layerCopy.key;
          layerCopy.minZoom = 14;
          layerCopy.maxZoom = 24;
          layerCopy.dataType = 'vector';
          layerCopy.sourceLayer = layerCopy.value.split('.')[1];
          layerCopy.url = layerCopy.value;
        } else if (layerCopy.type == 'user_csv') {
          layerCopy.code = layerCopy.key;
          layerCopy.minZoom = 14;
          layerCopy.maxZoom = 24;
          layerCopy.dataType = 'vector';
          layerCopy.url = layerCopy.value;
          layerCopy.sourceLayer = layerCopy.value.split('.')[1];
          layerCopy.tilesize = 256;
        } else if (layerCopy.type == 'user_geojson') {
          layerCopy.code = layerCopy.key;
          layerCopy.minZoom = 14;
          layerCopy.maxZoom = 24;
          layerCopy.dataType = 'vector';
          layerCopy.url = layerCopy.value;
          layerCopy.tilesize = 256;
        } else if (layerCopy.type == 'user_kml') {
          layerCopy.code = layerCopy.key;
          layerCopy.minZoom = 14;
          layerCopy.maxZoom = 24;
          layerCopy.dataType = 'vector';
          layerCopy.url = layerCopy.value;
          layerCopy.tilesize = 256;
        }

        overlayLayers.push(layerCopy);
      }

      this.currMapLayers = [...overlayLayers];
      const mapRaster = [];
      const mapVector = [];

      const annotationsData = mapData.annotations;
      const annotations = annotationsData.map(data => ({
        ...data,
        isEnabled: true,
      }));

      setDataMapAnn(annotations);

      const filterPolyLayer = [];
      for (const poly of annotations) {
        filterPolyLayer.push({
          drawnPolygonId: poly.drawnPolygonId,
          isEnabled: poly.isEnabled,
          polygon_label: poly.polygon_label,
        });
      }

      setDataAnn(filterPolyLayer);
      setDataLayer(overlayLayers);

      for (const layer of overlayLayers) {
        if (layer.dataType === 'raster') {
          const conMapUrl =
            prefixMapUrl + layer.url.split('//')[1] + suffixMapUrl;
          mapRaster.push({
            index: layer.appendIndex,
            url: conMapUrl,
            key: layer.key,
            disabled: layer.disabled,
          });
        } else if (layer.dataType === 'vector') {
          let layerKey = 'OTHERS';
          if (layer.shapeFileData && layer.shapeFileData.type === 'contour') {
            layerKey = 'CONTOUR';
          } else if (
            layer.shapeFileData &&
            layer.shapeFileData.type === 'stream_flow_simulation'
          ) {
            layerKey = 'STREAM FLOW SIMULATION';
          } else if (
            layer.shapeFileData &&
            layer.shapeFileData.type === 'boundary'
          ) {
            layerKey = 'BOUNDARY';
          } else if (
            layer.shapeFileData &&
            layer.shapeFileData.type === 'other'
          ) {
            layerKey = 'OTHERS';
          } else if (
            layer.shapeFileData &&
            layer.shapeFileData.type === 'points'
          ) {
            layerKey = 'OTHERS';
          } else {
            layerKey = 'OTHERS';
          }
          mapVector.push({
            index: layer.appendIndex,
            url: layer.url,
            key: layerKey,
            disabled: layer.disabled,
            sourceLayer: layer.sourceLayer,
          });
        }
      }
      setMapRasterData(mapRaster);
      setMapVectorData(mapVector);
    }
    //Map Raster Layer Data
  }, [tour, mapData]);

  useEffect(() => {
    if (mapData && map) {
      let types = mapData.annotationTypes?.map(type => ({
        ...type,
        isEnabled: true,
      }));
      setDataCustomLayer([...customLayerData, ...types]);
    }
  }, [map, mapData]);

  const toggleSwitch = polygonId => {
    const newDataAnn = dataAnn.map(dat => {
      if (dat.drawnPolygonId === polygonId) {
        dat.isEnabled = !dat.isEnabled;
      }
      return dat;
    });
    setDataAnn(newDataAnn);
  };

  const toggleSwitchLayer = key => {
    const newDataLayer = dataLayer.map(dat => {
      if (dat.key === key) {
        dat.disabled = !dat.disabled;
      }
      return dat;
    });
    setDataLayer(newDataLayer);
  };

  const toggleSwitchCustomLayer = key => {
    const newDataAnn = dataCustomLayer.map(dat => {
      if (dat.key === key) {
        dat.isEnabled = !dat.isEnabled;
      }
      return dat;
    });
    setDataCustomLayer(newDataAnn);
  };

  const onClickCustomLayer = () => {
    const newDataAnnLayer = dataMapAnn.map(dat => {
      for (const lay of dataCustomLayer) {
        if (dat.polygon_color === lay.key) {
          dat.isEnabled = lay.isEnabled;
        }
      }
      return dat;
    });
    setDataMapAnn(newDataAnnLayer);
    setVisible(!visible);
  };

  const onClickLayer = () => {
    const filterMapRater = [];
    const filterMapVector = [];

    //Layer Change
    for (const layer of dataLayer) {
      if (layer.dataType === 'raster') {
        const conMapUrl =
          prefixMapUrl + layer.url.split('//')[1] + suffixMapUrl;
        filterMapRater.push({
          index: layer.appendIndex,
          url: conMapUrl,
          key: layer.key,
          disabled: layer.disabled,
        });
      } else if (layer.dataType === 'vector') {
        const conMapUrl = layer.url;
        let layerKey = 'OTHERS';
        if (layer.shapeFileData && layer.shapeFileData.type === 'contour') {
          layerKey = 'CONTOUR';
        } else if (
          layer.shapeFileData &&
          layer.shapeFileData.type === 'stream_flow_simulation'
        ) {
          layerKey = 'STREAM FLOW SIMULATION';
        } else if (
          layer.shapeFileData &&
          layer.shapeFileData.type === 'boundary'
        ) {
          layerKey = 'BOUNDARY';
        } else if (
          layer.shapeFileData &&
          layer.shapeFileData.type === 'other'
        ) {
          layerKey = 'OTHERS';
        } else if (
          layer.shapeFileData &&
          layer.shapeFileData.type === 'points'
        ) {
          layerKey = 'OTHERS';
        } else {
          layerKey = 'OTHERS';
        }

        filterMapVector.push({
          index: layer.appendIndex,
          url: conMapUrl,
          key: layerKey,
          disabled: layer.disabled,
          sourceLayer: layer.sourceLayer,
        });
      }
    }
    setMapRasterData(filterMapRater);
    let emptyVectDataAnn = [];
    setMapVectorData(emptyVectDataAnn);
    setTimeout(() => {
      setMapVectorData(filterMapVector);
    }, 30);
    let emptyDataAnn = [];
    setDataMapAnn(emptyDataAnn);
    setTimeout(() => {
      const newDataAnn = dataMapAnn.map(dat => {
        for (const shape of dataAnn) {
          if (dat.drawnPolygonId === shape.drawnPolygonId) {
            dat.isEnabled = shape.isEnabled;
          }
        }
        return dat;
      });
      setDataMapAnn(newDataAnn);
    }, 50);
    setVisible(!visible);
  };

  const onClickAnnotation = () => {
    //Annotations Change
    let emptyDataAnn = [];
    setDataMapAnn(emptyDataAnn);
    setTimeout(() => {
      const newDataAnn = dataMapAnn.map(dat => {
        for (const shape of dataAnn) {
          if (dat.drawnPolygonId === shape.drawnPolygonId) {
            dat.isEnabled = shape.isEnabled;
          }
        }
        return dat;
      });
      setDataMapAnn(newDataAnn);
    }, 50);

    setVisible(!visible);
  };

  return (
    <>
      <OrientationLocker orientation={LANDSCAPE} />
      <ActivityIndicator visible={isLoading} />
      <View style={styles.page}>
        {!isLoading && mapData && (
          <>
            <View style={styles.container}>
              <SafeAreaView style={styles.backButton}>
                <IconButton
                  icon="arrow-left"
                  color={colors.darkerWhite}
                  size={30}
                  style={styles.backButton}
                  onPress={() => navigation.goBack()}
                />
              </SafeAreaView>
              <MapboxGL.MapView
                styleURL={MapboxGL.StyleURL.Street}
                zoomLevel={16}
                centerCoordinate={[mapData.lng, mapData.lat]}
                style={styles.map}
                ref={c => (this._map = c)}
                localizeLabels
                pitchEnabled
                zoomEnabled
                compassEnabled={true}
                compassViewPosition={3}
                logoEnabled={false}
                attributionEnabled={true}
                onPress={({ geometry }) =>
                  Alert.alert(
                    'Geometry',
                    `Latitude ${geometry.coordinates[1].toFixed(
                      4,
                    )}\nLongitude ${geometry.coordinates[0].toFixed(4)}`,
                  )
                }
              >
                <MapboxGL.Camera
                  zoomLevel={16}
                  animationMode={'flyTo'}
                  centerCoordinate={[mapData.lng, mapData.lat]}
                />

                {mapRasterData.map(raster => {
                  if (!raster.disabled) {
                    return (
                      <MapboxGL.RasterSource
                        key={`${Math.random()} raster`}
                        id={`${raster.index}source`}
                        tileUrlTemplates={[raster.url]}
                      >
                        <MapboxGL.RasterLayer
                          id={`${Math.random()}layer`}
                          sourceID={`${raster.index}source`}
                          style={{ rasterOpacity: layerOpacity }}
                        />
                      </MapboxGL.RasterSource>
                    );
                  }
                })}

                {mapVectorData.map(vector => {
                  if (!vector.disabled) {
                    return (
                      <MapboxGL.VectorSource
                        key={`${Math.random()} vector`}
                        id={`${vector.index}vector`}
                        url={vector.url}
                      >
                        {('CONTOUR' === vector.key ||
                          'OTHERS' === vector.key) && (
                          <>
                            <MapboxGL.LineLayer
                              key={`${Math.random()}vecLayerFill`}
                              id={`${vector.index}vecLayerFill`}
                              sourceID={`${vector.index}vector`}
                              sourceLayerID={`${vector.sourceLayer}`}
                              style={{ lineJoin: 'round', lineCap: 'round' }}
                            />
                            <MapboxGL.SymbolLayer
                              key={`${Math.random()} symbol layer`}
                              id={`${vector.index}symbol layer`}
                              sourceID={`${vector.index}vector`}
                              sourceLayerID={`${vector.sourceLayer}`}
                              style={mapBoxStyles.symbolLayerContour}
                            />
                          </>
                        )}
                        {'STREAM FLOW SIMULATION' === vector.key && (
                          <MapboxGL.LineLayer
                            id={`${vector.index}vecLayerstream`}
                            sourceID={`${vector.index}vector`}
                            sourceLayerID={`${vector.sourceLayer}`}
                            style={mapBoxStyles.streamFlowLayer}
                          />
                        )}
                        {'BOUNDARY' === vector.key && (
                          <MapboxGL.LineLayer
                            id={`${vector.index}vecLayerBoundary`}
                            sourceID={`${vector.index}vector`}
                            sourceLayerID={`${vector.sourceLayer}`}
                            style={mapBoxStyles.boundaryLayer}
                          />
                        )}
                      </MapboxGL.VectorSource>
                    );
                  }
                })}

                {dataMapAnn.map(shapeAnn => {
                  if (shapeAnn.isEnabled) {
                    return (
                      <MapboxGL.ShapeSource
                        key={`${Math.random()} polygon`}
                        id={shapeAnn.drawnPolygonId}
                        shape={{
                          type: 'FeatureCollection',
                          features: [
                            {
                              type: 'Feature',
                              geometry: {
                                type: 'Polygon',
                                coordinates: shapeAnn.polygonVertices,
                              },
                              properties: {
                                area: shapeAnn.area,
                                perimeter: shapeAnn.perimeter,
                                polygon_label: shapeAnn.polygon_label,
                              },
                            },
                          ],
                        }}
                        onPress={event => {
                          const {
                            area,
                            perimeter,
                            polygon_label,
                          } = event.features[0].properties;
                          Alert.alert(
                            polygon_label,
                            `Area : ${area}\nPerimeter : ${perimeter}`,
                          );
                        }}
                      >
                        <MapboxGL.FillLayer
                          key={`${shapeAnn.drawnPolygonId} fill`}
                          id={shapeAnn.drawnPolygonId}
                          style={{
                            fillAntialias: true,
                            fillColor: shapeAnn.polygon_color,
                            fillOutlineColor: 'rgba(255, 255, 255, 0.84)',
                            fillOpacity: 0.5,
                          }}
                        />
                      </MapboxGL.ShapeSource>
                    );
                  }
                })}
              </MapboxGL.MapView>

              <SafeAreaView
                style={{
                  backgroundColor: 'transparent',
                  position: 'absolute',
                  top: 15,
                  right: 10,
                  zIndex: 10,
                }}
              >
                <IconButton
                  icon="layers"
                  color={Colors.black}
                  style={{ position: 'relative', top: 15 }}
                  size={40}
                  onPress={toggleBottomNavigationView}
                />

                {mapData.charts.length > 0 && (
                  <IconButton
                    icon="chart-box"
                    color={Colors.black}
                    onPress={() =>
                      navigation.navigate(
                        Routes.BOTTOM_TAB_DISABLED_NAVIGATOR,
                        {
                          screen: 'Progress Charts',
                          params: {
                            data: mapData.charts,

                            title: `${mapData.tourName}`,
                          },
                        },
                      )
                    }
                    size={40}
                  />
                )}
              </SafeAreaView>
            </View>
            <SafeAreaView>
              <BottomSheet
                visible={visible}
                onBackButtonPress={toggleBottomNavigationView}
                onBackdropPress={toggleBottomNavigationView}
              >
                <SafeAreaView style={styles.bottomNavigationView}>
                  <View
                    style={{
                      flex: 1,
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                    }}
                  >
                    <View style={styles.flexContainer}>
                      <View
                        style={{
                          width: '26%',
                          borderColor: colors.primary,
                          borderEndWidth: 2,
                        }}
                      >
                        <View style={styles.header}>
                          <Text style={styles.headerText}>Layers</Text>
                          <Button
                            color={colors.primary}
                            mode="outlined"
                            icon="content-save"
                            style={styles.headerButton}
                            vb
                            compact
                            uppercase={false}
                            accessibilityLabel="Apply"
                            onPress={onClickLayer}
                          />
                          <Button
                            color={colors.primary}
                            mode="outlined"
                            icon={layersVisible ? 'eye-off' : 'eye'}
                            style={styles.headerButton}
                            vb
                            uppercase={false}
                            compact
                            accessibilityLabel="Show all"
                            onPress={() => {
                              setLayersVisible(!layersVisible);
                              toggleAllLayers();
                            }}
                          />
                        </View>

                        <ScrollView>
                          {dataLayer.map(data => {
                            return (
                              <View
                                style={styles.checkboxInput}
                                key={`${data.key} layer`}
                              >
                                <Checkbox.Android
                                  status={
                                    data.disabled ? 'unchecked' : 'checked'
                                  }
                                  onPress={() => {
                                    toggleSwitchLayer(data.key);
                                  }}
                                  color={'black'}
                                  uncheckedColor="grey"
                                />
                                <Text numberOfLines={3} style={styles.label}>
                                  {data.code}
                                </Text>
                              </View>
                            );
                          })}
                        </ScrollView>
                      </View>

                      <View
                        style={{
                          width: '37%',
                          paddingLeft: 10,
                          borderColor: colors.primary,
                          borderEndWidth: 2,
                        }}
                      >
                        <View style={styles.header}>
                          <Text style={styles.headerText}>Annotations</Text>
                          <Button
                            color={colors.primary}
                            mode="outlined"
                            icon="content-save"
                            vb
                            style={styles.headerButton}
                            uppercase={false}
                            compact
                            accessibilityLabel="Apply"
                            onPress={onClickAnnotation}
                          />

                          <Button
                            color={colors.primary}
                            mode="outlined"
                            icon={customAnnVisible ? 'eye-off' : 'eye'}
                            style={styles.headerButton}
                            vb
                            compact
                            uppercase={false}
                            accessibilityLabel="Apply"
                            onPress={() => {
                              setCustomAnnVisible(!customAnnVisible);
                              toggleCustomAnnotationsAndLayers();
                            }}
                          />
                        </View>

                        <ScrollView>
                          {dataAnn.map(shapeData => {
                            return (
                              <View
                                style={styles.checkboxInput}
                                key={`${Math.random()} annotation`}
                              >
                                <Checkbox.Android
                                  name={shapeData.drawnPolygonId}
                                  status={
                                    shapeData.isEnabled
                                      ? 'checked'
                                      : 'unchecked'
                                  }
                                  onPress={() => {
                                    toggleSwitch(shapeData.drawnPolygonId);
                                  }}
                                  color={'black'}
                                  uncheckedColor="grey"
                                />
                                <Text numberOfLines={7} style={styles.label}>
                                  {shapeData.polygon_label}
                                </Text>
                              </View>
                            );
                          })}
                        </ScrollView>
                      </View>

                      <View
                        style={{
                          width: '37%',
                          paddingLeft: 10,
                        }}
                      >
                        <View style={styles.header}>
                          <Text style={styles.headerText}>Custom Layers</Text>
                          <Button
                            color={colors.primary}
                            mode="outlined"
                            icon="content-save"
                            vb
                            style={styles.headerButton}
                            compact
                            uppercase={false}
                            accessibilityLabel="Apply"
                            onPress={onClickCustomLayer}
                          />

                          <Button
                            color={colors.primary}
                            mode="outlined"
                            style={styles.headerButton}
                            vb
                            icon={customAnnVisible ? 'eye-off' : 'eye'}
                            compact
                            uppercase={false}
                            accessibilityLabel="Toggle custom layers"
                            onPress={() => {
                              setCustomAnnVisible(!customAnnVisible);
                              toggleCustomAnnotationsAndLayers();
                            }}
                          />
                        </View>

                        <ScrollView>
                          {dataCustomLayer.map(layerData => {
                            return (
                              <View
                                style={{
                                  flexDirection: 'row',
                                  backgroundColor: layerData.key,
                                }}
                                key={`${layerData.key} layer`}
                              >
                                <Checkbox.Android
                                  status={
                                    layerData.isEnabled
                                      ? 'checked'
                                      : 'unchecked'
                                  }
                                  onPress={() => {
                                    toggleSwitchCustomLayer(layerData.key);
                                  }}
                                  color={'black'}
                                  uncheckedColor="grey"
                                />
                                <Text numberOfLines={3} style={styles.label}>
                                  {layerData.value}
                                </Text>
                              </View>
                            );
                          })}
                        </ScrollView>
                      </View>
                    </View>
                  </View>
                </SafeAreaView>
              </BottomSheet>
            </SafeAreaView>
          </>
        )}

        {isRasterLayerSelected() && (
          <Slider
            style={{
              width: '20%',
              height: 80,
              position: 'absolute',
              bottom: '5%',
              borderColor: '#2d4059',
            }}
            minimumValue={0}
            maximumValue={1}
            value={layerOpacity}
            onSlidingComplete={value => setLayerOpacity(value)}
            minimumTrackTintColor="#413d65"
            maximumTrackTintColor="#C0dad3"
            thumbTintColor="#413d65"
          />
        )}
      </View>
    </>
  );
}

const mapBoxStyles = {
  symbolLayerContour: {
    symbolPlacement: 'point',
    textAnchor: 'bottom',
    textField: ['concat', ['to-string', ['get', 'ELEVATION']], ' m'],
    textFont: ['literal', ['DIN Pro Italic', 'Arial Unicode MS Regular']],
    textSize: 10,
    textLineHeight: 1.2,
    textRotationAlignment: 'map',
    textColor: '#000000',
    textHaloColor: '#FFFDD0',
    textHaloWidth: 3,
    textHaloBlur: 0.5,
  },
  streamFlowLayer: {
    lineJoin: 'round',
    lineCap: 'butt',
    lineRoundLimit: 0.75,
    lineColor: [
      'match',
      ['get', 'grid_code'],
      1,
      '#caf0f8',
      2,
      '#90e0ef',
      3,
      '#00b4d8',
      4,
      '#0077b6',
      5,
      '#1f45fc',
      6,
      '#023e8a',
      '#000000',
    ],
    lineWidth: ['get', 'grid_code'],
  },
  boundaryLayer: {
    lineJoin: 'miter',
    lineCap: 'butt',
    lineMiterLimit: 2,
    lineColor: '#660000',
    lineWidth: 1.2,
  },
};

const styles = StyleSheet.create({
  flexContainer: {
    flex: 1,
    flexDirection: 'row', // set elements horizontally, try column.
  },
  checkboxInput: {
    flexDirection: 'row',
  },
  label: {
    margin: 8,
    flexShrink: 1,
    color: colors.black,
  },
  bottomNavigationView: {
    backgroundColor: '#fff',
    width: '100%',
    height: 250,
  },
  zoom: {
    padding: 1,
    backgroundColor: '#FFFFFF',
  },
  page: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.primary,
  },
  container: {
    height: '100%',
    width: '100%',
    backgroundColor: 'white',
  },
  map: {
    flex: 1,
  },
  backButton: {
    position: 'absolute',
    left: 24,
    top: 15,
    zIndex: 5,
    backgroundColor: colors.black,
    zIndex: 1000000,
  },
  headerText: {
    fontSize: 18,
    paddingHorizontal: 10,
    color: colors.black,
  },
  header: {
    flexDirection: 'row',
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerButton: {
    borderColor: colors.primary,
    borderWidth: 1,
    marginRight: 5,
  },
});
