// @flow
import { compose } from 'recompose';
import { connect } from 'react-redux';

import VideoplayerView from './VideoplayerView';

export default compose(
  connect(
    ({ login }) => ({
      authToken: login.user.token,
    }),
    dispatch => ({}),
  ),
)(VideoplayerView);
