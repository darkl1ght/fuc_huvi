// @flow
import React, { useEffect, useState } from 'react';
import { StyleSheet, SafeAreaView } from 'react-native';
import VideoPlayer from '../../components/VideoPlayer';
import axios from 'axios';
import config from '../utils/config';
import ActivityIndicator from '../../components/ActivityIndicator';
import { useSelector } from 'react-redux';

const hlsStreamingUrl = config.get('hlsStreamingUrl');
const projectApiUrl = config.get('projectAPI');

export default ({ route, navigation }) => {
  const { deviceId, vimeoId, title } = route.params;

  const [url, setUrl] = useState('');
  const [isFetchingUrl, setFetchingUrl] = useState(true);
  const authToken = useSelector(({ login }) => login.user.token);

  const getHlsVimeoIdStreamUrl = async vimeoId => {
    try {
      const Authorization = 'Token ' + authToken;

      let response = await axios.get(
        `${projectApiUrl}/projectmedia/vimeo/${vimeoId}`,
        { headers: { Authorization } },
      );

      // 540p video
      let { link: streamingUrl } = response.data.data.find(
        stream => stream.width === 960 && stream.height === 540,
      );

      setUrl(streamingUrl);
      setFetchingUrl(false);
    } catch (error) {}
  };

  const getHlsStreamingUrl = deviceId => {
    let streamingUrl = hlsStreamingUrl.replace('deviceId', deviceId);
    setUrl(streamingUrl);
    setFetchingUrl(false);
  };

  useEffect(() => {
    vimeoId ? getHlsVimeoIdStreamUrl(vimeoId) : getHlsStreamingUrl(deviceId);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <ActivityIndicator visible={isFetchingUrl} />
      {!isFetchingUrl && (
        <VideoPlayer
          uri={url}
          style={styles.backgroundVideo}
          onBackPressed={() => navigation.goBack()}
          title={title}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  backgroundVideo: {
    flex: 1,
  },
});
