// @flow
export const initialState = {
  isFirstOpen: true,
  isTokenSavedSuccess: false,
};

export const SET_FIRST_OPEN = 'AppState/SET_FIRST_OPEN';
const SAVE_TOKEN = 'AppState/SAVE_TOKEN';
const SAVE_TOKEN_ERROR = 'AppState/SAVE_TOKEN_ERROR';

export function setAppOpened() {
  return {
    type: SET_FIRST_OPEN,
  };
}

export function saveGCMToken(token, deviceId) {
  return dispatch => {
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: '/notifications/APP002',
        method: 'POST',
        data: {
          token,
          deviceId,
        },
        onSuccess: SAVE_TOKEN,
        onError: SAVE_TOKEN_ERROR,
      },
    });
  };
}

export default function AppStateReducer(state = initialState, action) {
  switch (action.type) {
    case SET_FIRST_OPEN:
      return {
        ...state,
        isFirstOpen: false,
      };
    case SAVE_TOKEN:
      return {
        ...state,
        isTokenSavedSuccess: true,
      };
    case SAVE_TOKEN_ERROR:
    default:
      return state;
  }
}
