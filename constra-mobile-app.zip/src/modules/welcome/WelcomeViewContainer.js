// @flow
import { compose } from 'recompose';
import { connect } from 'react-redux';

import WelcomeView from './WelcomeView';

export default compose(
  connect(
    state => ({}),
    dispatch => ({}),
  ),
)(WelcomeView);
