import React from 'react';
import { Image, ImageBackground, SafeAreaView, StyleSheet } from 'react-native';
import { Button, useTheme } from 'react-native-paper';

export default props => {
  const { colors } = useTheme();

  return (
    <ImageBackground
      source={require('../../../assets/images/welcome-background.jpg')}
      style={styles.container}
    >
      <Image
        source={require('../../../assets/images/constra-logo.png')}
        style={styles.logo}
      />
      <SafeAreaView style={styles.buttonContainer}>
        <Button
          icon="login"
          mode="contained"
          color={colors.welcomeScreenButton}
          contentStyle={{ padding: 5 }}
          uppercase={false}
          style={styles.loginButton}
          onPress={() => props.navigation.navigate('Login')}
        >
          Login to Constra
        </Button>
      </SafeAreaView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
  },
  logo: {
    marginTop: 25,
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    width: '100%',
    marginBottom: 10,
  },
  loginButton: {
    marginHorizontal: 15,
    borderRadius: 25,
  },
});
