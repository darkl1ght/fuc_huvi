// @flow
import { compose } from 'recompose';
import { connect } from 'react-redux';

import LivestreamView from './LivestreamView';
import lifecycle from 'recompose/lifecycle';
import { getAllDevices, resetDevices } from './LivestreamState';

export default compose(
  connect(
    ({ projects, livestream }) => ({
      selectedProjectId: projects.projectId,
      devices: livestream.devices,
      isLoading: livestream.isLoading,
    }),
    dispatch => ({
      getAllDevices: projectId => dispatch(getAllDevices(projectId)),
      resetDevices: () => dispatch(resetDevices()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const { getAllDevices, selectedProjectId } = this.props;
      getAllDevices(selectedProjectId);
    },
    componentWillUnmount() {
      this.props.resetDevices();
    },
  }),
)(LivestreamView);
