// @flow

export const initialState = {
  devices: [],
  isLoading: false,
  isErrorInLoading: false,
};

const FETCHING_DEVICES_STARTED = 'LivestreamState/FETCHING_DEVICES';
const FETCHING_DEVICES_COMPLETED = 'LivestreamState/FETCHING_DEVICES_COMPLETED';
const FETCHING_DEVICES_ERROR = 'LivestreamState/FETCHING_DEVICES_ERROR';
const RESET_DEVICES = 'LivestreamState/RESET_DEVICES';

export function fetchingDevices() {
  return {
    type: FETCHING_DEVICES_STARTED,
  };
}
export function resetDevices() {
  return {
    type: RESET_DEVICES,
  };
}

export function getAllDevices(projectId) {
  return dispatch => {
    dispatch(fetchingDevices());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `${projectId}/livestream/devices`,
        onSuccess: FETCHING_DEVICES_COMPLETED,
        onError: FETCHING_DEVICES_ERROR,
      },
    });
  };
}

export default function LivestreamStateReducer(state = initialState, action) {
  switch (action.type) {
    case FETCHING_DEVICES_STARTED:
      return {
        ...state,
        isLoading: true,
      };
    case FETCHING_DEVICES_COMPLETED:
      return {
        ...state,
        isLoading: false,
        devices: action.payload.devices,
      };
    case FETCHING_DEVICES_ERROR:
      return {
        ...state,
        isLoading: false,
        isErrorInLoading: true,
      };
    case RESET_DEVICES:
      return {
        ...state,
        isLoading: false,
        isErrorInLoading: false,
        devices: [],
      };
    default:
      return state;
  }
}
