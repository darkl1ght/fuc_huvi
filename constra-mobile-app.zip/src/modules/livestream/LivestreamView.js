// @flow
import React from 'react';
import { StyleSheet, FlatList, RefreshControl } from 'react-native';
import { Divider, Surface, Button } from 'react-native-paper';
import { Text } from '../../components/StyledText';
import ActivityIndicator from '../../components/ActivityIndicator';
import LottieView from 'lottie-react-native';

export default ({
  devices,
  isLoading,
  navigation,
  getAllDevices,
  selectedProjectId,
}) => {
  const renderItem = ({ item }) => {
    // item.upTime = 1;
    return (
      <Surface style={styles.surface}>
        <Text size={20} style={styles.header}>
          {item.deviceName}
        </Text>
        <Text style={styles.subheading} size={12}>
          {item.deviceType.desc}
        </Text>
        <Divider style={styles.divider} />
        {item.upTime === 0 && (
          <Text style={styles.bottomheader} size={16}>
            Not streaming
          </Text>
        )}
        {item.upTime > 0 && (
          <Button
            mode="contained"
            loading
            onPress={() =>
              navigation.navigate('Video Player', { deviceId: item.deviceId })
            }
          >
            Streaming Now
          </Button>
        )}
      </Surface>
    );
  };

  const onRefresh = () => getAllDevices(selectedProjectId);

  return (
    <>
      {/* <LottieView
        source={require('../../../assets/animations/under-construction.json')}
        autoPlay
        loop
      /> */}
      {/* <ActivityIndicator visible={isLoading} />
      <FlatList
        data={devices}
        renderItem={renderItem}
        keyExtractor={item => item.deviceId}
        refreshControl={
          <RefreshControl refreshing={isLoading} onRefresh={onRefresh} />
        }
      />
      {devices.length == 0 && !isLoading && (
        <Text style={styles.searchNoItems} size={24}>
          No devices found.
        </Text>
      )} */}
    </>
  );
};

const styles = StyleSheet.create({
  surface: {
    padding: 12,
    margin: 8,
    elevation: 4,
  },
  header: {
    margin: 8,
  },
  subheading: {
    margin: 8,
    marginTop: 2,
    opacity: 0.8,
  },
  bottomheader: {
    color: 'green',
    margin: 8,
    marginTop: 3,
  },
  searchNoItems: {
    flex: 1,
    textAlign: 'center',
  },
  divider: {
    margin: 3,
  },
});
