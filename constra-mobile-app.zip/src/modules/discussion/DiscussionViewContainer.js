// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import DiscussionView from './DiscussionView';
import {
  fetchAllComments,
  fetchAllUsers,
  addComment,
  removeComment,
} from './DiscussionState';

export default compose(
  connect(
    ({ projects, discussion, login }) => ({
      selectedProjectId: projects.projectId,
      isLoading: discussion.isLoading,
      comments: discussion.comments,
      users: discussion.users,
      loggedInemail: login.user.email,
    }),
    dispatch => ({
      fetchAllComments: (projectId, requestedId) =>
        dispatch(fetchAllComments(projectId, requestedId)),
      fetchAllUsers: projectId => dispatch(fetchAllUsers(projectId)),
      addComment: (projectId, requestId, comment) =>
        dispatch(addComment(projectId, requestId, comment)),
      removeComment: (projectId, requestId, commentId) =>
        dispatch(removeComment(projectId, requestId, commentId)),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const {
        fetchAllComments,
        selectedProjectId,
        route,
        fetchAllUsers,
      } = this.props;
      const requestedId = route.params ? route.params.requestedId : null;

      fetchAllComments(selectedProjectId, requestedId);
      fetchAllUsers(selectedProjectId);
    },
  }),
)(DiscussionView);
