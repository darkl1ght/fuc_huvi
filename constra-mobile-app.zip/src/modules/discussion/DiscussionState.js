export const initialState = {
  comments: [],
  isLoading: false,
  isError: false,
  users: [],
};

const FETCH_COMMENTS_STARTED = 'DiscussionState/FETCH_COMMENTS_STARTED';
const FETCH_COMMENTS_LOADED = 'DiscussionState/FETCH_COMMENTS_LOADED';
const FETCH_COMMENTS_ERROR = 'DiscussionState/FETCH_COMMENTS_ERROR';

const FETCH_USERS_STARTED = 'DiscussionState/FETCH_USERS_STARTED';
const FETCH_USERS_LOADED = 'DiscussionState/FETCH_USERS_LOADED';
const FETCH_USERS_ERROR = 'DiscussionState/FETCH_USERS_ERROR';

const ADD_COMMENT_STARTED = 'DiscussionState/ADD_COMMENT_STARTED';
const ADD_COMMENT_COMPLETED = 'DiscussionState/ADD_COMMENT_COMPLETED';
const ADD_COMMENT_ERROR = 'DiscussionState/ADD_COMMENT_ERROR';

const REMOVE_COMMENT_STARTED = 'DiscussionState/REMOVE_COMMENT_STARTED';
const REMOVE_COMMENT_COMPLETED = 'DiscussionState/REMOVE_COMMENT_COMPLETED';
const REMOVE_COMMENT_ERROR = 'DiscussionState/REMOVE_COMMENT_ERROR';

function fetchingComments() {
  return { type: FETCH_COMMENTS_STARTED };
}

function fetchingUsersStarted() {
  return { type: FETCH_USERS_STARTED };
}
function addCommentStarted() {
  return { type: ADD_COMMENT_STARTED };
}

function removeCommentStarted() {
  return { type: REMOVE_COMMENT_STARTED };
}

export function fetchAllComments(projectId, requestedId) {
  return dispatch => {
    dispatch(fetchingComments());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/projectmedia/${projectId}/media/${requestedId}/comments/`,
        onSuccess: FETCH_COMMENTS_LOADED,
        onError: FETCH_COMMENTS_ERROR,
      },
    });
  };
}

export function addComment(projectId, requestedId, comment) {
  return dispatch => {
    dispatch(addCommentStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        method: 'POST',
        data: {
          comment,
        },
        url: `/projectmedia/${projectId}/media/${requestedId}/comment/`,
        onSuccess: ADD_COMMENT_COMPLETED,
        onError: ADD_COMMENT_ERROR,
      },
    });
  };
}

export function removeComment(projectId, requestedId, commentId) {
  return dispatch => {
    dispatch(removeCommentStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        method: 'PUT',
        data: {
          commentId,
        },
        url: `/projectmedia/${projectId}/media/${requestedId}/removecomment/`,
        onSuccess: REMOVE_COMMENT_COMPLETED,
        onError: REMOVE_COMMENT_ERROR,
      },
    });
  };
}

export function fetchAllUsers(projectId) {
  return dispatch => {
    dispatch(fetchingUsersStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/${projectId}/users/`,
        onSuccess: FETCH_USERS_LOADED,
        onError: FETCH_USERS_ERROR,
      },
    });
  };
}

export default function DiscussionStateReducer(state = initialState, action) {
  switch (action.type) {
    case FETCH_COMMENTS_STARTED:
    case ADD_COMMENT_STARTED:
    case FETCH_USERS_STARTED:
    case REMOVE_COMMENT_STARTED:
      return {
        ...state,
        isLoading: true,
      };
    case FETCH_COMMENTS_LOADED:
      return {
        ...state,
        isLoading: false,
        comments: action.payload.comments,
      };
    case FETCH_COMMENTS_ERROR:
    case ADD_COMMENT_ERROR:
    case REMOVE_COMMENT_ERROR:
      return {
        ...state,
        isLoading: false,
        isError: true,
      };
    case FETCH_USERS_LOADED:
      return {
        ...state,
        isLoading: false,
        users: action.payload.users,
      };
    case FETCH_USERS_ERROR:
      return {
        ...state,
        isLoading: false,
        isError: true,
      };
    case ADD_COMMENT_COMPLETED:
    case REMOVE_COMMENT_COMPLETED:
      return {
        ...state,
        isLoading: false,
        isError: false,
      };

    default:
      return state;
  }
}
