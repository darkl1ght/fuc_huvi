import React, { useCallback, useEffect, useState } from 'react';
import {
  Platform,
  Pressable,
  SafeAreaView,
  StyleSheet,
  View,
} from 'react-native';
import {
  MentionInput,
  replaceMentionValues,
} from 'react-native-controlled-mentions';
import { Bubble, Day, GiftedChat, Send } from 'react-native-gifted-chat';
import { Avatar, useTheme } from 'react-native-paper';
import ActivityIndicator from '../../components/ActivityIndicator';
import { Text } from '../../components/StyledText';
import { colors } from '../../styles';

export default ({
  comments,
  users,
  isLoading,
  loggedInemail,
  addComment,
  removeComment,
  selectedProjectId,
  route,
}) => {
  const [allComments, setComments] = useState([]);
  const [value, setValue] = useState('');

  const { colors } = useTheme();

  useEffect(() => {
    if (comments) {
      let transformedComments = comments.map(comment => {
        return {
          _id: comment.commentId,
          text: comment.body,
          createdAt: new Date(comment.createdAt),
          user: {
            _id: comment.createdByEmail,
            name: comment.createdByName,
          },
        };
      });
      setComments(transformedComments);
    }
  }, [comments]);

  const onSendFromUser = (messages = []) => {
    const createdAt = new Date();
    const text = replaceMentionValues(value, ({ name }) => `${name}`);

    const messagesToUpload = messages.map(message => ({
      ...message,
      text,
      createdAt,
      _id: Math.round(Math.random() * 1000000),
    }));

    addComment(selectedProjectId, route.params.requestedId, text);
    setValue('');
    onSend(messagesToUpload);
  };

  const onSend = useCallback((messages = []) => {
    setComments(previousMessages =>
      GiftedChat.prepend(previousMessages, messages),
    );
  }, []);

  const renderSuggestions = ({ keyword, onSuggestionPress }) => {
    if (keyword == null) {
      return null;
    }

    return (
      <View>
        {users
          .filter(user =>
            user.email
              .toLocaleLowerCase()
              .includes(keyword.toLocaleLowerCase()),
          )
          .map(user => {
            return { ...user, id: user._id, name: user.email };
          })
          .map(user => (
            <Pressable
              key={user.id}
              onPress={() => onSuggestionPress(user)}
              style={{ padding: 12 }}
            >
              <Text>{`${user.firstName} ${user.lastName} (${user.email})`}</Text>
            </Pressable>
          ))}
      </View>
    );
  };

  const renderSend = props => {
    return null;
  };

  const renderComposer = props => {
    return (
      <SafeAreaView
        style={{
          flex: 1,
          flexDirection: 'row',
          borderColor: colors.primary,
          borderTopWidth: 0.25,
          borderBottomWidth: 0.25,
          marginHorizontal: 10,
        }}
      >
        <MentionInput
          {...props}
          placeholder={'Type message...'}
          value={value}
          multiline={true}
          onChange={value => setValue(value)}
          containerStyle={{
            padding: Platform.OS === 'ios' ? 10 : 0,
            flex: 3,
            marginHorizontal: 5,
          }}
          partTypes={[
            {
              trigger: '@', // Should be a single character like '@' or '#'
              renderSuggestions,
              textStyle: { fontWeight: 'bold', color: colors.primary }, // The mention style in the input
            },
          ]}
        />

        <Send
          {...props}
          containerStyle={{ flex: 1, justifyContent: 'flex-end' }}
        >
          <Avatar.Icon
            size={40}
            icon="send"
            style={{
              alignSelf: 'flex-end',
              padding: 5,
              alignContent: 'center',
              justifyContent: 'center',
            }}
          />
        </Send>
      </SafeAreaView>
    );
  };

  const onLongPress = (context, message) => {
    const options = ['Delete Message', 'Cancel'];
    const cancelButtonIndex = options.length - 1;
    context.actionSheet().showActionSheetWithOptions(
      {
        options,
        cancelButtonIndex,
      },
      buttonIndex => {
        switch (buttonIndex) {
          case 0:
            removeComment(
              selectedProjectId,
              route.params.requestedId,
              message._id,
            );
            setComments(
              allComments.filter(
                individualMessage => message._id !== individualMessage._id,
              ),
            );
            break;
          case 1:
            break;
        }
      },
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, padding: 10, width: '100%' }}>
      <ActivityIndicator visible={isLoading} />
      <GiftedChat
        inverted={false}
        messages={allComments}
        onSend={messages => onSendFromUser(messages)}
        user={{
          _id: loggedInemail,
        }}
        renderUsernameOnMessage
        text={value}
        infiniteScroll
        scrollToBottom
        renderComposer={renderComposer}
        renderSend={renderSend}
        messagesContainerStyle={{
          backgroundColor: colors.surface,
        }}
        renderChatEmpty={props => (
          <Text
            size={20}
            style={{
              transform: [{ scaleY: -1 }],
              textAlignVertical: 'center',
              flex: 1,
              alignSelf: 'center',
              color: colors.onSurface,
            }}
          >
            No messages found ...
          </Text>
        )}
        timeTextStyle={{ left: {}, right: { color: 'white' } }}
        renderBubble={props => (
          <Bubble
            {...props}
            wrapperStyle={{ right: { backgroundColor: colors.primary } }}
          />
        )}
        onLongPress={onLongPress}
        renderAvatarOnTop
        renderDay={props => (
          <Day
            {...props}
            wrapperStyle={{ paddingTop: 10, paddingBottom: 0 }}
            textStyle={{ color: colors.primary }}
          />
        )}
      />
    </SafeAreaView>
  );
};
