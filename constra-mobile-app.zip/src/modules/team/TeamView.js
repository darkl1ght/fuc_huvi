import React from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { Avatar, Divider, useTheme } from 'react-native-paper';
import ActivityIndicator from '../../components/ActivityIndicator';
import { colors, fonts } from '../../styles';
const colorCode = [
  '#0F2347',
  '#1C3F6E',
  '#2196F3',
  '#7b1fa2',
  '#512da8',
  '#00AA55',
  '#009FD4',
  '#B381B3',
  '#80C271',
  '#E3BC00',
  '#D47500',
  '#DC2A2A',
  '#939393',
];
export default props => {
  const { colors } = useTheme();

  const renderItem = ({ item: user, index }) => {
    return (
      <View key={user.memberId} style={{ backgroundColor: colors.surface }}>
        <View style={styles.container}>
          <Avatar.Text
            color={'white'}
            size={50}
            label={user.firstName.charAt(0).toUpperCase()}
            style={{ marginBottom: 20, backgroundColor: colorCode[index] }}
          />
          <View style={styles.content}>
            <View>
              <Text style={[styles.title, { color: colors.team?.title }]}>
                {user.firstName} {user.lastName}
              </Text>
              <Text style={styles.subtitle} numberOfLines={2}>
                {user.email}
              </Text>
              <View style={styles.metadata}>
                <View
                  style={[
                    styles.badge,
                    { backgroundColor: colors.team?.badge },
                  ]}
                >
                  <Text
                    white
                    size={12}
                    style={{ color: colors.surface }}
                    styleName="bright"
                  >
                    {user.role.desc}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
        <Divider />
      </View>
    );
  };
  return (
    <View style={{ flex: 1 }}>
      <ActivityIndicator visible={props.isLoading} />
      <FlatList
        keyExtractor={item => item.memberId}
        style={{
          paddingHorizontal: 15,
          marginVertical: 5,
        }}
        data={props.team}
        renderItem={renderItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  metadata: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  badge: {
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  container: {
    flexDirection: 'row',
    paddingVertical: 10,
  },
  content: {
    flex: 1,
    paddingLeft: 15,
    justifyContent: 'space-between',
  },
  subtitle: {
    fontFamily: fonts.primaryRegular,
    fontSize: 16,
    color: '#617ae1',
    marginBottom: 6,
  },
  title: {
    fontFamily: fonts.primaryBold,
    fontSize: 20,
    marginBottom: 6,
  },
});
