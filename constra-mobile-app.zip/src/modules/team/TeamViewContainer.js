// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import TeamView from './TeamView';
import { getAllTeam, resetError } from './TeamState';
export default compose(
  connect(
    state => ({
      isLoading: state.team.isLoading,
      projectId: state.projects.projectId,
      team: state.team.team,
      error: state.team.isErrorInLogging,
    }),
    dispatch => ({
      getAllTeam: projectId => dispatch(getAllTeam(projectId)),
      resetError: () => dispatch(resetError()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      this.focusListener = this.props.navigation.addListener('focus', () => {
        this.props.getAllTeam(this.props.projectId);
      });
    },
  }),
)(TeamView);
