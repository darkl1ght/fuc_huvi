// Initial state
const initialState = {
  isLoading: false,
  isErrorInLogging: false,
  team: [],
};

// Actions
const START_TEAM_LOADING = 'TEAM_STATE/START_LOADING';
const TEAM_LOADED = 'TEAM_STATE/TEAM_LOADED';
const TEAM_ERROR = 'TEAM_STATE/TEAM_ERROR';
const RESET_TEAM_ERROR = 'TEAM_STATE/RESET_TEAM_ERROR';

// Action creators
function startTeamLoading() {
  return { type: START_TEAM_LOADING };
}

export function getAllTeam(projectId) {
  return dispatch => {
    dispatch(startTeamLoading());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: projectId + '/users/',
        onSuccess: TEAM_LOADED,
        onError: TEAM_ERROR,
      },
    });
  };
}

export function resetError() {
  return { type: RESET_TEAM_ERROR };
}

// Reducer
export default function TeamStateReducer(state = initialState, action = {}) {
  switch (action.type) {
    case START_TEAM_LOADING:
      return Object.assign({}, state, {
        isLoading: true,
        isErrorInLogging: false,
      });
    case TEAM_LOADED:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
        team: action.payload.users,
      });
    case TEAM_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: true,
      });
    case RESET_TEAM_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
      });
    default:
      return state;
  }
}
