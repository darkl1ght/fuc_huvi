import React, { useEffect, useState } from 'react';
import { FlatList, SafeAreaView, StatusBar, View } from 'react-native';
import Orientation, {
  OrientationLocker,
  LANDSCAPE,
} from 'react-native-orientation-locker';
import { useSelector } from 'react-redux';
import axios from 'axios';
import config from '../utils/config';
import DropDown from 'react-native-paper-dropdown';
import { bar, sCurveData } from '../selfserve/SelfServeDefaults';
import { Checkbox } from 'react-native-paper';
import ActivityIndicator from '../../components/ActivityIndicator';
import SelfServeChartItem from '../selfserve/ChartItemView';
import { colors } from '../../styles';
import uuid from 'react-native-uuid';

const PROJECT_API = config.get('projectAPI');

export default ({ route }) => {
  let { tour } = route.params;

  const userToken = useSelector(({ login }) => login.user.token);

  const [showTowerDropDown, setShowTowerDropDown] = useState(false);
  const [locationsList, setLocationsList] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState({});
  const [charts, setCharts] = useState([]);
  const [isChartsByProject, setChartsByProject] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    try {
      async function getMasterData() {
        setIsLoading(true);

        const { data } = await axios.get(
          `${PROJECT_API}/masterdata/${tour.projectId}/`,
          {
            headers: { Authorization: `Token ${userToken}` },
          },
        );

        let locations = data.master?.workLocation.filter(
          location => location.parentLocationId === '',
        );
        setLocationsList(
          locations.map(location => ({
            label: location.level1,
            value: location.locationId,
          })),
        );
        setSelectedLocation(locations[0].locationId);
      }
      getMasterData();
    } catch (error) {
      setIsLoading(false);
    }

    return function cleanup() {
      Orientation.unlockAllOrientations();
      StatusBar.setHidden(false);
    };
  }, []);

  useEffect(() => {
    try {
      async function getChartsForSelectedLocation() {
        if (locationsList.length > 0) {
          setIsLoading(true);
          let projectCharts = [];

          const {
            data: { response: chartsData },
          } = await axios.get(
            `${PROJECT_API}/aerialtour/${tour.projectId}/${
              tour.tourId
            }/wbs/ext/${selectedLocation}/chart/${
              isChartsByProject ? '' : 'by-tower'
            }`,
            {
              headers: { Authorization: `Token ${userToken}` },
            },
          );

          let sCurve = {
            chartName: isChartsByProject
              ? 'S Curve structure - Project'
              : 'S Curve structure',
            chartType: 'line',
          };
          let wbsChart = {
            chartName: 'Work Breakdown Structure',
            chartType: 'bar',
          };

          if (chartsData.sCurve && chartsData.sCurve.labels.length > 0) {
            projectCharts = [];

            sCurveData.labels = chartsData.sCurve.labels;
            sCurveData.datasets[0].data = chartsData.sCurve.planned;
            sCurveData.datasets[1].data = chartsData.sCurve.actual;
            sCurveData.id = uuid.v4();
            sCurve.data = sCurveData;
            projectCharts.push(sCurve);
          }

          if (
            chartsData.wbsChart &&
            chartsData.wbsChart.labels.length > 0 &&
            !isChartsByProject
          ) {
            bar.labels = chartsData.wbsChart.labels;

            bar.datasets[0].data = chartsData.wbsChart.planned;
            bar.datasets[1].data = chartsData.wbsChart.actual;
            bar.datasets[1].toolTip = chartsData.wbsChart.toolTip;
            bar.id = uuid.v4();

            wbsChart.data = bar;
            projectCharts.push(wbsChart);
          }

          setCharts(projectCharts);
          setIsLoading(false);
        }
      }
      getChartsForSelectedLocation();
    } catch (error) {
      setIsLoading(false);
    }
  }, [selectedLocation, isChartsByProject]);

  return (
    <>
      <ActivityIndicator visible={isLoading} />
      <SafeAreaView style={{ flex: 1 }}>
        <OrientationLocker orientation={LANDSCAPE} />
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: 5,
          }}
        >
          <View
            style={{ maxWidth: '45%', marginVertical: 2, marginHorizontal: 4 }}
          >
            {!isChartsByProject && (
              <DropDown
                label={'Location'}
                mode={'outlined'}
                visible={showTowerDropDown}
                showDropDown={() => setShowTowerDropDown(true)}
                onDismiss={() => setShowTowerDropDown(false)}
                value={selectedLocation}
                setValue={value => {
                  if (value !== selectedLocation) {
                    setSelectedLocation(value);
                  }
                }}
                list={locationsList}
                key={item => item.locationId}
              />
            )}
          </View>
          <View style={{ alignSelf: 'flex-end' }}>
            <Checkbox.Item
              label="S Curve by project"
              status={isChartsByProject ? 'checked' : 'unchecked'}
              onPress={() => setChartsByProject(!isChartsByProject)}
              mode="android"
              position="leading"
              color={colors.secondary}
            />
          </View>
        </View>
        <FlatList
          data={charts}
          renderItem={SelfServeChartItem}
          keyExtractor={item => item.id}
          style={{ flex: 1, flexDirection: 'column' }}
        />
      </SafeAreaView>
    </>
  );
};
