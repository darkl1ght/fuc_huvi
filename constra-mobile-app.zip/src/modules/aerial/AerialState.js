// Initial state
const initialState = {
  isLoading: false,
  isErrorInLogging: false,
  aerial: [],
};

// Actions
const START_AERIAL_LOADING = 'AERIAL_STATE/START_LOADING';
const AERIAL_LOADED = 'AERIAL_STATE/AERIAL_LOADED';
const AERIAL_ERROR = 'AERIAL_STATE/AERIAL_ERROR';
const RESET_AERIAL_ERROR = 'AERIAL_STATE/RESET_AERIAL_ERROR';

// Action creators
function startAerialLoading() {
  return { type: START_AERIAL_LOADING };
}

export function getAllAerial(projectId) {
  return dispatch => {
    dispatch(startAerialLoading());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: '/aerialtour/' + projectId + '/tour/',
        onSuccess: AERIAL_LOADED,
        onError: AERIAL_ERROR,
      },
    });
  };
}

export function resetError() {
  return { type: RESET_AERIAL_ERROR };
}

// Reducer
export default function AerialStateReducer(state = initialState, action = {}) {
  switch (action.type) {
    case START_AERIAL_LOADING:
      return Object.assign({}, state, {
        isLoading: true,
        isErrorInLogging: false,
      });
    case AERIAL_LOADED:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
        aerial: action.payload.tours,
      });
    case AERIAL_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: true,
      });
    case RESET_AERIAL_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
      });
    default:
      return state;
  }
}
