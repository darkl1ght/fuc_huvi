import { useAsyncStorage } from '@react-native-async-storage/async-storage';
import format from 'date-fns/format';
import * as React from 'react';
import { FlatList, RefreshControl, StyleSheet, View } from 'react-native';
import { Button, Card, IconButton, useTheme } from 'react-native-paper';
import ActivityIndicator from '../../components/ActivityIndicator';
import { Text } from '../../components/StyledText';
import useAppReview from '../../hooks/useAppReview';
import { fonts } from '../../styles';
import Routes from '../navigation/routes';

export default ({ navigation, isLoading, aerial, getAllAerial, projectId }) => {
  const { colors } = useTheme();
  const { onReview } = useAppReview();
  const { getItem } = useAsyncStorage('aerial_tour_view_count');

  let onMapViewClick = tour => {
    if (tour.mapType !== 'S' && tour.status.code === 'AT10003') {
      // Navigating to a nested navigator without bottom tabs
      navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
        screen: 'Map',
        params: {
          data: tour,
        },
      });
    }
  };

  React.useEffect(() => {
    async function review() {
      const count = await getItem();
      if (count != null && parseInt(count) > 5) {
        await onReview();
      }
    }
    if (aerial.length > 0) {
      review();
    }
  }, [aerial]);

  let aerialItem = ({ item: tour }) => (
    <View style={styles.container}>
      <Card elevation={8} onPress={() => onMapViewClick(tour)}>
        <Card.Title
          numberOfLines={3}
          title={tour.tourName}
          subtitle={format(new Date(tour.createdAt), 'LLLL dd yyyy')}
        />
        <Card.Actions>
          {tour.isSelfServe &&
            (tour.isWBSPublished || tour.charts.length === 0) && (
              <IconButton
                icon="chart-bar"
                color={colors.onSurface}
                onPress={() =>
                  navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
                    screen: Routes.AERIAL_SELF_SERVE,
                    params: {
                      tour,
                      title: `${tour.tourName}`,
                    },
                  })
                }
              />
            )}
          {!tour.isSelfServe && tour.charts.length > 0 && (
            <IconButton
              icon="chart-bar"
              color={colors.onSurface}
              onPress={() =>
                navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
                  screen: 'Progress Charts',
                  params: {
                    data: tour.charts,
                    title: `${tour.tourName}`,
                  },
                })
              }
            />
          )}
          <Button
            icon={tour.status.code === 'AT10001' ? 'cloud-upload' : 'earth'}
            onPress={() => onMapViewClick(tour)}
            uppercase={false}
            color={colors.onSurface}
            loading={tour.status.code === 'AT10002'}
            labelStyle={{
              fontSize: 16,
              fontFamily: fonts.primarySemiBold,
            }}
          >
            {tour.status.code === 'AT10003' && 'Visualize'}
            {tour.status.code === 'AT10001' && 'Upload data'}
            {tour.status.code === 'AT10002' && 'Processing'}
          </Button>
        </Card.Actions>
      </Card>
    </View>
  );

  return (
    <View style={{ flex: 1 }}>
      <ActivityIndicator visible={isLoading} />
      <FlatList
        keyExtractor={item => item._id}
        data={aerial}
        renderItem={aerialItem}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={() => getAllAerial(projectId)}
          />
        }
      />
      {aerial != null && aerial.length == 0 && !isLoading && (
        <Text
          style={{ flex: 1, textAlign: 'center', color: colors.onSurface }}
          size={24}
        >
          No Aerial tours found
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 10,
  },
  mapIcon: {
    paddingLeft: 20,
  },
});
