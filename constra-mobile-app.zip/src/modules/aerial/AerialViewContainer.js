// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import AerialView from './AerialView';
import { getAllAerial, resetError } from './AerialState';
export default compose(
  connect(
    state => ({
      isLoading: state.aerial.isLoading,
      projectId: state.projects.projectId,
      aerial: state.aerial.aerial,
      error: state.aerial.isErrorInLogging,
    }),
    dispatch => ({
      getAllAerial: projectId => dispatch(getAllAerial(projectId)),
      resetError: () => dispatch(resetError()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      this.props.getAllAerial(this.props.projectId);
    },
  }),
)(AerialView);
