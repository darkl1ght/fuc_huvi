// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import ClientsView from './ClientsView';
import {
  getAllClients,
  getAzureBlobReadToken,
  resetError,
} from './ClientsState';

export default compose(
  connect(
    ({ clients }) => ({
      isLoading: clients.isLoading,
      clients: clients.clients,
      azureBlobToken: clients.azureMediaContainerToken,
      error: clients.isErrorInLogging,
    }),
    dispatch => ({
      getAllClients: () => dispatch(getAllClients()),
      getAzureBlobReadToken: () => dispatch(getAzureBlobReadToken()),
      resetError: () => dispatch(resetError()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      this.props.getAllClients();
      this.props.getAzureBlobReadToken();
    },
  }),
)(ClientsView);
