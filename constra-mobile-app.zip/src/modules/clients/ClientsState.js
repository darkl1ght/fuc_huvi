// Initial state
const initialState = {
  isLoading: false,
  isError: false,
  clients: [],
  azureMediaContainerToken: '',
};

// Actions
const START_CLIENTS_LOADING = 'CLIENTS_STATE/START_LOADING';
const CLIENTS_LOADED = 'CLIENTS_STATE/CLIENTS_LOADED';
const CLIENTS_ERROR = 'CLIENTS_STATE/CLIENTS_ERROR';
const RESET_CLIENTS_ERROR = 'CLIENTS_STATE/RESET_CLIENTS_ERROR';

const BLOB_TOKEN_LOADING_STARTED = 'CLIENTS_STATE/BLOB_TOKEN_LOADING_STARTED';
const BLOB_TOKEN_LOADING_COMPLETED =
  'CLIENTS_STATE/BLOB_TOKEN_LOADING_COMPLETED';
const BLOB_TOKEN_LOADING_ERROR = 'CLIENTS_STATE/BLOB_TOKEN_ERROR';

// Action creators
function startClientsLoading() {
  return { type: START_CLIENTS_LOADING };
}
function startTokenCall() {
  return { type: BLOB_TOKEN_LOADING_STARTED };
}

export function getAllClients() {
  return dispatch => {
    dispatch(startClientsLoading());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: '/client/clients',
        onSuccess: CLIENTS_LOADED,
        onError: CLIENTS_ERROR,
      },
    });
  };
}

export function getAzureBlobReadToken() {
  return dispatch => {
    dispatch(startTokenCall());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/azureblob/sas/read/media/`,
        onSuccess: BLOB_TOKEN_LOADING_COMPLETED,
        onError: BLOB_TOKEN_LOADING_ERROR,
      },
    });
  };
}

export function resetError() {
  return { type: RESET_CLIENTS_ERROR };
}

// Reducer
export default function ClientsStateReducer(state = initialState, action = {}) {
  switch (action.type) {
    case START_CLIENTS_LOADING:
      return Object.assign({}, state, {
        isLoading: true,
        isError: false,
      });
    case CLIENTS_LOADED:
      return Object.assign({}, state, {
        isLoading: false,
        isError: false,
        clients: action.payload.clients,
      });
    case CLIENTS_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isError: true,
      });
    case RESET_CLIENTS_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isError: false,
      });
    case BLOB_TOKEN_LOADING_STARTED:
      return Object.assign({}, state, {
        isLoading: true,
      });
    case BLOB_TOKEN_LOADING_COMPLETED:
      return Object.assign({}, state, {
        isLoading: false,
        azureMediaContainerToken: action.payload.sasToken.token,
      });
    case BLOB_TOKEN_LOADING_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isError: true,
      });
    default:
      return state;
  }
}
