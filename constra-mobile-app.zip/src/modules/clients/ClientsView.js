import React, { useEffect, useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Image,
  RefreshControl,
} from 'react-native';
import ActivityIndicator from '../../components/ActivityIndicator';
import { fonts } from '../../styles';
import Config from '../utils/config';
import format from 'date-fns/format';
import { parseISO } from 'date-fns/esm';
import { Divider, Searchbar, useTheme } from 'react-native-paper';
import { filter } from 'lodash-es';

const AZURE_MEDIA_CONTAINER_URL = Config.get('azureMediaContainer');

export default ({
  azureBlobToken,
  navigation,
  isLoading,
  clients,
  getAllClients,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [allClients, setAllClients] = useState([]);

  const { colors } = useTheme();

  useEffect(() => {
    setAllClients(clients);
  }, [clients]);

  const getLogoUrl = blobContentId =>
    AZURE_MEDIA_CONTAINER_URL + `${blobContentId}?${azureBlobToken}`;

  const renderItem = ({ item: client }) => {
    let clientLogoUrl = client.blobContentId
      ? { uri: getLogoUrl(client.blobContentId) }
      : require('../../../assets/images/placeholder-media.jpg');

    return (
      <TouchableOpacity
        key={client._id}
        onPress={() =>
          navigation.navigate('Projects', { clientId: client.clientId })
        }
      >
        <View style={styles.subContainer}>
          <Image source={clientLogoUrl} style={styles.image} />
          <View style={styles.contentContainer}>
            <View>
              <Text style={{ ...styles.title, color: colors.client?.title }}>
                {client.clientName}
              </Text>
              <Text
                style={{ ...styles.subTitle, color: colors.client?.subTitle }}
                numberOfLines={1}
              >
                {format(parseISO(client.createdAt), 'LLLL dd yyyy')}
              </Text>
            </View>
            <View style={styles.metaDataContainer}>
              <Text
                style={{
                  fontFamily: fonts.primaryRegular,
                  fontSize: 16,
                  color: colors.client?.metaData,
                  textAlign: 'right',
                }}
              >
                {client.projects.length} Project(s)
              </Text>
            </View>
          </View>
        </View>
        <Divider />
      </TouchableOpacity>
    );
  };

  const onChangeSearch = query => {
    const formattedQuery = query.toLowerCase();
    let filteredClients = filter(clients, client =>
      client.clientName.toLowerCase().includes(formattedQuery),
    );
    setSearchQuery(query);
    setAllClients(filteredClients);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <ActivityIndicator visible={isLoading} />
      <Searchbar
        placeholder="Search clients"
        onChangeText={onChangeSearch}
        value={searchQuery}
        style={styles.searchBar}
        inputStyle={{ fontSize: 18, padding: 5 }}
      />
      <FlatList
        keyExtractor={item => item.clientId}
        style={{
          paddingHorizontal: 15,
        }}
        data={allClients}
        renderItem={renderItem}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={() => {
              setSearchQuery('');
              getAllClients();
            }}
          />
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  searchBar: {
    margin: 5,
    marginBottom: 10,
    borderRadius: 20,
    elevation: 5,
  },
  subContainer: {
    flexDirection: 'row',
    paddingVertical: 10,
  },
  image: {
    height: 110,
    width: 120,
    resizeMode: 'contain',
  },
  contentContainer: {
    flex: 1,
    paddingLeft: 15,
    justifyContent: 'space-between',
  },
  subTitle: {
    fontFamily: fonts.primaryRegular,
    fontSize: 16,
    marginVertical: 6,
  },
  title: {
    fontFamily: fonts.primaryBold,
    fontSize: 20,
  },
  metaDataContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
