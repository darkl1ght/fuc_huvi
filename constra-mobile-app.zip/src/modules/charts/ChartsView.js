// @flow
import React from 'react';
import { FlatList, SafeAreaView } from 'react-native';
import Chart from '../../components/Chart';
import { OrientationLocker, LANDSCAPE } from 'react-native-orientation-locker';
export default ({ route }) => {
  let { data: charts } = route.params;

  const renderItem = ({ item: chart }) => {
    return (
      <Chart
        key={chart.chartId}
        title={chart.chartTitle}
        labels={chart.chartData.labels}
        datasets={chart.chartData.datasets}
        type={chart.chartType}
      />
    );
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <OrientationLocker orientation={LANDSCAPE} />

      <FlatList
        data={charts}
        renderItem={renderItem}
        keyExtractor={item => item.chartId}
      />
    </SafeAreaView>
  );
};
