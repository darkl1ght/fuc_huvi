// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import ChartsView from './ChartsView';
import Orientation from 'react-native-orientation-locker';

export default compose(
  connect(
    state => ({}),
    dispatch => ({}),
  ),
  lifecycle({
    componentWillUnmount() {
      // Unlock orientations and enable status bar
      Orientation.unlockAllOrientations();
    },
  }),
)(ChartsView);
