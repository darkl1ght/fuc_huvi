import { Platform, UIManager } from 'react-native';
import { connect } from 'react-redux';
import { compose, lifecycle } from 'recompose';
import { saveGCMToken } from './AppState';
import AppView from './AppView';

export default compose(
  connect(
    state => ({
      isUserLoggedIn: state.login.isUserLoggedIn,
      isUserAdmin: state.login.user.isAdmin,
    }),
    dispatch => ({
      saveGCMToken: (token, deviceId) =>
        dispatch(saveGCMToken(token, deviceId)),
    }),
  ),
  lifecycle({
    componentDidMount() {
      if (Platform.OS === 'android') {
        // eslint-disable-next-line no-unused-expressions
        UIManager.setLayoutAnimationEnabledExperimental &&
          UIManager.setLayoutAnimationEnabledExperimental(true);
      }
    },
  }),
)(AppView);
