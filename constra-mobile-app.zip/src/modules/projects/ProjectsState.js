// Initial state
const initialState = {
  isLoading: false,
  isErrorInLogging: false,
  projects: [],
};

// Actions
const START_PROJECTS_LOADING = 'PROJECTS_STATE/START_LOADING';
const PROJECTS_LOADED = 'PROJECTS_STATE/PROJECTS_LOADED';
const PROJECTS_ERROR = 'PROJECTS_STATE/PROJECTS_ERROR';
const RESET_PROJECTS_ERROR = 'PROJECTS_STATE/RESET_PROJECTS_ERROR';
const SAVE_PROJECT = 'PROJECTS_STATE/SAVE_PROJECT';

// Action creators
function startProjectsLoading() {
  return { type: START_PROJECTS_LOADING };
}

export function getProjectsByClientId(clientId) {
  return dispatch => {
    dispatch(startProjectsLoading());
    // Connect to the API here
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: '/searchbyclientId/' + clientId,
        onSuccess: PROJECTS_LOADED,
        onError: PROJECTS_ERROR,
      },
    });
  };
}

export function getAllProjects() {
  return dispatch => {
    dispatch(startProjectsLoading());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: '',
        onSuccess: PROJECTS_LOADED,
        onError: PROJECTS_ERROR,
      },
    });
  };
}

export function saveProject(projectId) {
  return dispatch => {
    dispatch({
      type: SAVE_PROJECT,
      payload: {
        projectId,
      },
    });
  };
}

export function resetError() {
  return { type: RESET_PROJECTS_ERROR };
}

// Reducer
export default function ProjectsStateReducer(
  state = initialState,
  action = {},
) {
  switch (action.type) {
    case START_PROJECTS_LOADING:
      return Object.assign({}, state, {
        isLoading: true,
        isErrorInLogging: false,
      });
    case PROJECTS_LOADED:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
        projects: action.payload.projects,
      });
    case SAVE_PROJECT:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
        projectId: action.payload.projectId,
      });
    case PROJECTS_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: true,
      });
    case RESET_PROJECTS_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isErrorInLogging: false,
      });
    default:
      return state;
  }
}
