import React from 'react';
import {
  FlatList,
  Image,
  RefreshControl,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import { Divider, useTheme } from 'react-native-paper';
import ActivityIndicator from '../../components/ActivityIndicator';
import { Text } from '../../components/StyledText';
import { fonts } from '../../styles';

export default ({
  saveProject,
  navigation,
  isLoading,
  projects,
  isUserAdmin,
  route,
  getProjectsByClientId,
  getAllProjects,
}) => {
  const { colors } = useTheme();

  const onProjectSelect = project => {
    saveProject(project.projectId);

    navigation.navigate('Project Details', {
      projectName: project.projectName,
      isNavigateToInteriors:
        project.aerialTours?.length === 0 && project.interiors?.length > 0,
    });
  };

  const projectItem = ({ item: project }) => (
    <TouchableOpacity
      key={project.id}
      style={{ backgroundColor: colors.surface }}
      onPress={() => onProjectSelect(project)}
    >
      <View style={styles.cardSubContainer}>
        <Image
          source={getBackgroundByProjectType(project.type)}
          style={styles.image}
          resizeMode="cover"
        />
        <View style={styles.contentContainer}>
          <View>
            <Text
              style={{
                fontFamily: fonts.primaryBold,
                fontSize: 18,
                color: colors.projects?.title,
              }}
            >
              {project.projectName}
            </Text>
            <Text
              style={{ ...styles.subtitle, color: colors.projects?.subTitle }}
              numberOfLines={2}
            >
              {project.location}
            </Text>
          </View>
          <View style={styles.metaDataContainer}>
            <View
              style={[
                styles.badge,
                { backgroundColor: colors.projects?.badge },
              ]}
            >
              <Text
                style={{ color: colors.surface }}
                size={12}
                styleName="bright"
              >
                {project.type}
              </Text>
            </View>
          </View>
        </View>
      </View>
      <Divider />
    </TouchableOpacity>
  );

  return (
    <View style={{ flex: 1 }}>
      <ActivityIndicator visible={isLoading} />
      <FlatList
        keyExtractor={item => item.id}
        style={{ paddingHorizontal: 15 }}
        data={projects}
        renderItem={projectItem}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={() => {
              isUserAdmin
                ? getProjectsByClientId(route.params.clientId)
                : getAllProjects();
            }}
          />
        }
      />
    </View>
  );
};

let getBackgroundByProjectType = projectType => {
  let assetUrl;
  switch (projectType) {
    case 'Residential':
      assetUrl = require('../../../assets/images/project-types/Residential.jpg');
      break;
    case 'Commercial':
      assetUrl = require('../../../assets/images/project-types/Commercial.jpg');
      break;
    case 'Highway/Expressway':
      assetUrl = require('../../../assets/images/project-types/Road.jpg');
      break;
    case 'Railway':
    case 'Metro':
      assetUrl = require('../../../assets/images/project-types/Metro.jpg');
      break;
    case 'Mining':
      assetUrl = require('../../../assets/images/project-types/Mining.jpg');
      break;
    case 'Solar PV':
      assetUrl = require('../../../assets/images/project-types/Solar.jpg');
      break;
    case 'Wind Power Plant':
      assetUrl = require('../../../assets/images/project-types/Wind.jpg');
      break;
    case 'Natural Resources':
      assetUrl = require('../../../assets/images/project-types/NaturalResource.jpg');
      break;
    case 'Agriculture':
      assetUrl = require('../../../assets/images/project-types/Agriculture.jpg');
      break;
    case 'Land Survey':
      assetUrl = require('../../../assets/images/project-types/LandSurvey.jpg');
      break;
    default:
      assetUrl = require('../../../assets/images/project-types/Other.jpg');
      break;
  }
  return assetUrl;
};

const styles = StyleSheet.create({
  cardSubContainer: {
    flexDirection: 'row',
    paddingVertical: 10,
  },
  image: {
    height: 110,
    width: 140,
  },
  contentContainer: {
    flex: 1,
    paddingLeft: 15,
    paddingTop: 5,
    justifyContent: 'space-between',
  },

  subtitle: {
    fontFamily: fonts.primaryRegular,
    fontSize: 14,
    marginVertical: 5,
  },
  metaDataContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  badge: {
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
});
