// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import ProjectsView from './ProjectsView';
import {
  getProjectsByClientId,
  saveProject,
  getAllProjects,
  resetError,
} from './ProjectsState';

export default compose(
  connect(
    state => ({
      isLoading: state.projects.isLoading,
      projects: state.projects.projects,
      clients: state.clients.clients,
      error: state.projects.isErrorInLogging,
      isUserAdmin: state.login.user.isAdmin,
    }),
    dispatch => ({
      getProjectsByClientId: clientId =>
        dispatch(getProjectsByClientId(clientId)),
      getAllProjects: () => dispatch(getAllProjects()),
      saveProject: projectId => dispatch(saveProject(projectId)),
      resetError: () => dispatch(resetError()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const {
        isUserAdmin,
        route,
        getProjectsByClientId,
        getAllProjects,
      } = this.props;

      const clientId = route.params ? route.params.clientId : null;

      isUserAdmin ? getProjectsByClientId(clientId) : getAllProjects();
    },
  }),
)(ProjectsView);
