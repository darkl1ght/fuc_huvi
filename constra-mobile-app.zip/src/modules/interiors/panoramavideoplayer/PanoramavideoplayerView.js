import React from 'react';
import { Dimensions } from 'react-native';
import Config from '../../utils/config';
import LottieView from 'lottie-react-native';

const PanoramaVideoPlayer = ({ route }) => {
  const MEDIA_STREAM_URL = Config.get('hlsStreamingUrl');

  const { deviceId } = route.params;

  const { height, width } = Dimensions.get('window');

  return (
    <LottieView
      source={require('../../../../assets/animations/under-construction.json')}
      autoPlay
      loop
    />
  );
};

export default PanoramaVideoPlayer;
