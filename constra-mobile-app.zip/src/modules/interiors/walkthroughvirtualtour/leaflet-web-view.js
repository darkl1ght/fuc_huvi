import { chain } from 'lodash';
import format from 'date-fns/format';

import { parseISO } from 'date-fns/esm';

const sortTourFeatures = features => {
  return chain(features)
    .uniqBy('properties.imageNumber')
    .orderBy(({ properties }) => properties.imageNumber, ['asc'])
    .value();
};

const populateTourDetailsAndFetchHtml = (
  tour,
  azureBlobToken,
  floorPlanToken,
  interiorDate,
) => {
  let { features: featuresToSort } = tour.features;
  tour.features.features = sortTourFeatures(featuresToSort);
  let features = JSON.stringify(tour.features);

  tour.images.forEach(image => {
    if (image) {
      image.imageBlobUrl = `https://huviairinspection.blob.core.windows.net/virtualtour/${tour.tourId}/${image.blobImageId}?${azureBlobToken}`;
    }
  });

  let images = JSON.stringify(tour.images);
  let floorPlanUri = JSON.stringify(floorPlanToken);
  let title = `${tour.towerName} - ${tour.tourName} \n ${format(
    parseISO(interiorDate),
    'LLLL dd yyyy',
  )}`;

  return `<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"/>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
   
   
    <link rel="stylesheet" href="https://constra.huviair.com/assets/pannellum/pannellum.css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
    <script type="text/javascript" src="https://huviairblob.blob.core.windows.net/templates/pannellum.js" ></script>
    
    <script>
    (function(L) {
      if (typeof L === 'undefined') {
      throw new Error('Leaflet must be included first');
      }

      L.Control.Resizer = L.Control.extend({
      options: {
        direction: 'e', // valid values e, s, se
        onlyOnHover: false,
        updateAlways: true,
        pan: false,
      },

    _END: {
      mousedown: 'mouseup',
      touchstart: 'touchend',
      pointerdown: 'touchend',
      MSPointerDown: 'touchend',
    },

    _MOVE: {
      mousedown: 'mousemove',
      touchstart: 'touchmove',
      pointerdown: 'touchmove',
      MSPointerDown: 'touchmove',
    },

    initialize: function(options) {
      L.Util.setOptions(this, options);
      this._initialOffsetX = 0;
      this._initialOffsetY = 0;
      this.options.position =
        'leaflet-control-resizer-corner-' + this.options.direction;
      this.enable();
    },

    enable: function() {
      this._enabled = true;
      return this;
    },

    disable: function() {
      this._enabled = false;
      return this;
    },

    onAdd: function(map) {
      this._prepareLocation(map);

      var className = 'leaflet-control-resizer';
      var classNameTransp =
        className + (this.options.onlyOnHover ? '-transparent' : '-opaque');
      var classNameLoc = className + '-' + this.options.direction;
      this._container = L.DomUtil.create(
        'div',
        className + ' ' + classNameTransp + ' ' + classNameLoc,
        map.getContainer(),
      );
      var container = this._container;

      L.DomEvent.on(
        container,
        'mousedown mouseup click touchstart drag',
        L.DomEvent.stopPropagation,
      );

      /* IE11 seems to process events in the wrong order, so the only way to prevent map movement while dragging the
       * slider is to disable map dragging when the cursor enters the slider (by the time the mousedown event fires
       * it's too late becuase the event seems to go to the map first, which results in any subsequent motion
       * resulting in map movement even after map.dragging.disable() is called.
       */
      /*
        L.DomEvent.on(container, 'mouseenter', function (e) { map.dragging.disable(); });
        L.DomEvent.on(container, 'mouseleave', function (e) { map.dragging.enable(); });
        */

      L.DomEvent.on(container, 'mousedown touchstart', this._initResize, this);

      return this._container;
    },

    onRemove: function(map) {
      L.DomEvent.off(
        this._container,
        'mousedown touchstart',
        this._initResize,
        this,
      );
      L.DomEvent.off(
        this._container,
        'mousedown mouseup click touchstart drag',
        L.DomEvent.stopPropagation,
      );
    },

    fakeHover: function(ms) {
      var className = 'leaflet-control-resizer-transparent-fakedhover';
      var cont = this._container;
      L.DomUtil.addClass(cont, className);
      setTimeout(function() {
        L.DomUtil.removeClass(cont, className);
      }, ms | 1000);
    },

    _prepareLocation: function(map) {
      var corners = map._controlCorners;
      var l = 'leaflet-control-resizer-corner-' + this.options.direction;
      var container = map._controlContainer;

      corners[l] = L.DomUtil.create('div', l, container);
    },

    _initResize: function(e) {
      if (e._simulated || !this._enabled) {
        return;
      }

      if (this._started) return;
      this._started = true;
      this._moved = false;

      var first = e.touches && e.touches.length === 1 ? e.touches[0] : e;

      L.DomUtil.disableImageDrag();
      L.DomUtil.disableTextSelection();

      this.fire('down', e);

      var mapCont = this._map.getContainer();
      this._initialOffsetX =
        mapCont.offsetWidth + mapCont.offsetLeft - first.clientX;
      this._initialOffsetY =
        mapCont.offsetHeight + mapCont.offsetTop - first.clientY;

      L.DomEvent.on(document, this._END[e.type], this._stopResizing, this);
      L.DomEvent.on(
        this._container,
        this._END[e.type],
        this._stopResizing,
        this,
      );

      L.DomEvent.on(document, this._MOVE[e.type], this._duringResizing, this);
    },

    _duringResizing: function(e) {
      if (e._simulated) {
        return;
      }

      var first = e.touches && e.touches.length === 1 ? e.touches[0] : e;

      L.DomEvent.preventDefault(e);

      if (!this._moved) {
        this.fire('dragstart', e);
      }
      this.fire('predrag', e);

      var mapCont = this._map.getContainer();
      if (this.options.direction.indexOf('e') >= 0) {
        mapCont.style.width =
          first.clientX - mapCont.offsetLeft + this._initialOffsetX + 'px';
        this._moved = true;
      }
      if (this.options.direction.indexOf('s') >= 0) {
        mapCont.style.height =
          first.clientY - mapCont.offsetTop + this._initialOffsetY + 'px';
        this._moved = true;
      }
      this._moved = true;

      if (this.options.updateAlways) {
        this._map.invalidateSize({ pan: this.options.pan });
      }

      this.fire('drag', e);
    },

    _stopResizing: function(e) {
      if (e._simulated) {
        return;
      }

      for (var i in this._MOVE) {
        L.DomEvent.off(document, this._MOVE[i], this._duringResizing, this);

        L.DomEvent.off(document, this._END[i], this._stopResizing, this);
        L.DomEvent.off(this._container, this._END[i], this._stopResizing, this);
      }

      this._map.invalidateSize({ pan: this.options.pan });

      L.DomUtil.enableImageDrag();
      L.DomUtil.enableTextSelection();
      this._started = false;
      this.fire('dragend', e);
    },
  });

    L.Control.Resizer.include(L.Evented.prototype);

    L.control.resizer = function(options) {
      return new L.Control.Resizer(options);
    };
  })(L);

  </script>
    <style>
      .material-symbols-outlined {
        font-variation-settings:
        'FILL' 0,
        'wght' 400,
        'GRAD' 0,
        'opsz' 48
      }

      html {
       height: 100%;
      }
      #controls {
        position: absolute;
        bottom: 10px;
        z-index: 2;
        text-align: center;
        width: 100%;
        padding-bottom: 3px;
      }
      .ctrl {
          padding: 8px 5px;
          width: 30px;
          text-align: center;
          background: rgba(200, 200, 200, 0.8);
          display: inline-block;
          cursor: pointer;
      }
      body {
        margin: 0;
        padding: 0;
        overflow: hidden;
        position: fixed;
        cursor: default;
        width: 100%;
        height: 100%;
      }
        #panorama {
          margin-bottom : 5px; 
           positive : relative;
           width: 100%;
           height: 100%;
        }
        .location-pin {
          margin-left: -12px !important;
          margin-top: -12px !important;
        }

        .location-pin img {
          width: 28px;
          height: 28px;
          position: relative;
        }

        .location-pin-text {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          font-weight: bolder;
          color: #000000;
        }
        .location-pin-container {
          position: relative;
          text-align: center;
          width: 28px;
          height: 28px;
        }
       

        a {
          text-decoration: none;
          display: inline-block;
          
        }

        .previous, .next {
          margin : 0;
          position : absolute;
          float:left;
          background-color: black;
          color: white;
          z-index : 12
        }


        .pnlm-panorama-info {
            position: absolute;
            bottom: 4px;
            right : 0;
            background-color: rgba(0,0,0,0.7);
            border-radius: 0 3px 3px 0;
            padding-right: 10px;
            color: #fff;
            text-align: left;
            display: none;
            z-index: 2;
            /* Fix Safari fullscreen bug */
            -webkit-transform: translateZ(9999px);
            transform: translateZ(9999px);
        }

        .pnlm-about-msg {
          visibility : hidden
        }

        .leaflet-control-resizer-corner-e,
        .leaflet-control-resizer-corner-s,
        .leaflet-control-resizer-corner-se {
            z-index: 1000;
            position: absolute;
        }

        .leaflet-control-resizer-corner-e {
            right: 0;
            height: 100%;
        }

        .leaflet-control-resizer-corner-s {
            bottom: 0;
            width: 100%;
        }

        .leaflet-control-resizer-corner-se {
            right: 0;
            bottom: 0;
        }


        .leaflet-control-resizer-transparent {
            background-color: transparent;
            user-select: none;
            transition: 0.5s;
        }
        .leaflet-control-resizer-transparent::after {
            border-color: transparent;
            transition: 0.5s;
        }

        .leaflet-control-resizer-opaque,
        .leaflet-control-resizer-transparent:hover,
        .leaflet-control-resizer-transparent-fakedhover {
            background-color: rgba(255, 250, 170, 0.8);
        }

        .leaflet-control-resizer-opaque::after,
        .leaflet-control-resizer-transparent:hover::after,
        .leaflet-control-resizer-transparent-fakedhover::after {
            border-color: rgba(85, 85, 85, 0.9);
        }

        .leaflet-control-resizer-e {
            width: 25px;
            height: 50px;
            border-top-left-radius: 25px;
            border-bottom-left-radius: 25px;
            cursor: e-resize;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
        }

        .leaflet-control-resizer-s {
            width: 50px;
            height: 25px;
            border-top-left-radius: 25px;
            border-top-right-radius: 25px;
            cursor: s-resize;
            left: 50%;
            bottom: 0;
            transform: translateX(-50%);
        }

        .leaflet-control-resizer-se {
            width: 35px;
            height: 35px;
            border-top-left-radius: 35px;
            cursor: se-resize;
            right: 0;
            bottom: 0;
            position: absolute;
        }

        .leaflet-control-resizer-e::after,
        .leaflet-control-resizer-s::after,
        .leaflet-control-resizer-se::after {
            content: '';
            position: absolute;
            z-index: 999;
            border-width: 1px;
            bottom: 20%;
            right: 20%;
        }

        .leaflet-control-resizer-e::after,
        .leaflet-control-resizer-s::after {
            width: 60%;
            height: 60%;

        }

        .leaflet-control-resizer-se::after {
            width: 40%;
            height: 40%;
        }

        .leaflet-control-resizer-e::after,
        .leaflet-control-resizer-se::after {
            border-right-style: solid;
        }
        .leaflet-control-resizer-s:after,
        .leaflet-control-resizer-se::after {
            border-bottom-style: solid;
        }

        .pnlm-title-box {
            font-size: 1rem;
            display: table;
            padding-left: 5px;
            margin-bottom: 3px;
        }

        .pnlm-panorama-info{
          max-width : 35%
        }
    </style>
  
  </head>
  <body>
    <div id="panorama">
    <div id="controls">
        <div class="ctrl" id="previous-image"><span class="material-symbols-outlined">skip_previous</span></div>
        <div class="ctrl" id="floorplan" onclick="toggleFloorPlan()"><span class="material-symbols-outlined" id="floorPlanIcon">image</span></div>
        <div class="ctrl" id="next-image"><span class="material-symbols-outlined">skip_next</span></div>
       
    </div>
     
    </div>
    <div id="mapid" style="height : 50%; position: absolute; top: 20px; left: 20px; width: 35%; z-index : 1000;"></div>

    <script>
      let isShowingFloorPlan = true;
      let selectedImageNumber = 1;
      const markers = [];

       document.getElementById('previous-image').addEventListener('click', function(e) {
           navigateImage("previous");
        });

      document.getElementById('next-image').addEventListener('click', function(e) {
          navigateImage("next");
        });

      
      function navigateImage(direction) {
        if (viewer) {
          if(direction === "next"){
            selectedImageNumber = selectedImageNumber + 1
              let marker = markers.find(
              (marker) => marker.feature.properties.imageNumber === selectedImageNumber
            );
           
            marker.fireEvent("click");
          }
          else {
            if(selectedImageNumber > 1){
              selectedImageNumber = selectedImageNumber - 1
              
              let marker = markers.find(
              (marker) => marker.feature.properties.imageNumber === selectedImageNumber
            );
           
            marker.fireEvent("click");
            }
          }

        }
      }

      function toggleFloorPlan(){
        isShowingFloorPlan = !isShowingFloorPlan;
        let leafletMap = document.getElementById("mapid");
        let panorama = document.getElementById("panorama");
        let floorPlanButton = document.getElementById("floorPlanIcon");

        if (leafletMap.style.display === "none") {
          leafletMap.style.display = "block";
          floorPlanButton.textContent="image";
        } 
        else {
          leafletMap.style.display = "none";
          floorPlanButton.textContent = "hide_image";
        }
        if(window.ReactNativeWebView) {
           window.ReactNativeWebView.postMessage(JSON.stringify({ type : 'hideDropdown', value: isShowingFloorPlan }));
         }
      } 

          
      let getPathCoordinates = (data) => {
        let coordinates = [];
        for (let index in data._layers) {
          const x = data._layers[index]._latlng.lat;
          const y = data._layers[index]._latlng.lng;
          coordinates.push([x, y]);
        }
        return coordinates;
      }

  
      let getMarkerIcon = (isActiveImage, imageNumber) => {
        let imagePath = isActiveImage ? 'https://constra.huviair.com/assets/images/circle2.png' : 'https://constra.huviair.com/assets/images/marker-inactive.png';
        return new L.DivIcon({
            className: "location-pin",
            html: '<div class="location-pin-container"><img src="'+imagePath+'"><span class="location-pin-text">'+imageNumber+'</span></div>',
          });
        
      }

      let getMarker = (latlng, {imageName, imageNumber, imageId}) => {
        const marker = L.marker(latlng, {
            icon: imageNumber === 1 ? getMarkerIcon(true,imageNumber): getMarkerIcon(false, imageNumber)
          });

        marker.feature = {
              type: "Feature",
              properties: {
                imageName,
                imageId,
                imageNumber,
              },
              geometry: null,
              id: L.Util.stamp(marker),
            };
          return marker;
    }

    </script>

    <script>

      let floorPlanMap = L.map("mapid", { crs: L.CRS.Simple, minZoom: -5, maxBoundsViscosity: 1, zoomControl : true, attributionControl:false});
      floorPlanMap.zoomControl.setPosition('topright');

      let featureGroup = L.geoJSON(${features});
      let viewer;
      let polyLineLayer;
      
      const img = new Image();
      img.id = "mapImage";
      img.src = ${floorPlanUri};
      img.onload = () => {
        const w = img.width;
        const h = img.height;
        const bounds = [ [-10, -10], [h, w],];
      
        L.imageOverlay(${floorPlanUri}, bounds).addTo(floorPlanMap);
    
        floorPlanMap.fitBounds(bounds);
        floorPlanMap.setMaxBounds(bounds);
        floorPlanMap.addLayer(featureGroup)
      }
      
      // Remove each layer to add custom layers
      const featureGroupCopy = featureGroup;
      featureGroupCopy.eachLayer((layer) => {
        if (featureGroup.hasLayer(layer)) {
            featureGroup.removeLayer(layer);
        }
      });

      floorPlanMap.addLayer(featureGroup);

      floorPlanMap.on("load", () => {
        let map = document.getElementById("mapid");
        map.style.display = "block";

       if(window.ReactNativeWebView) {
          window.ReactNativeWebView.postMessage(JSON.stringify({"loadingComplete": true}))
        }
      });

     
      const currFlrFeatGroup = ${features} ? L.geoJSON(${features}): undefined;
      let imageNumber = 0;

      if (currFlrFeatGroup) {
          currFlrFeatGroup.eachLayer((layer) => {
              const latlng = layer.getLatLng();
              const marker = {};
              marker.imageId = layer.feature.properties.imageId;
              marker.imageName = layer.feature.properties.imageName;
              marker.imageNumber = ++imageNumber;
              
              let addedMarker = getMarker(latlng, marker)

              addedMarker.on("click", () => {
                
                  selectedImageNumber = addedMarker.feature.properties.imageNumber;
                  let sceneId = addedMarker.feature.properties.imageId;

                  if(window.ReactNativeWebView) {  
                    window.ReactNativeWebView.postMessage(JSON.stringify({"imageChanged": selectedImageNumber}));
                  }


                  let { scenes } = viewer.getConfig();
                  if(Object.keys(scenes).length === selectedImageNumber){
                      document.getElementById('next-image').style.pointerEvents = 'none';
                  }
                  else {
                      document.getElementById('next-image').style.pointerEvents = 'auto';
                  }
         
                  
                  featureGroup.eachLayer( layer => {
                      if(layer !== polyLineLayer){
                        layer.setIcon(getMarkerIcon(false, layer.feature.properties.imageNumber));
                      }
                  })
                  addedMarker.setIcon(getMarkerIcon(true, addedMarker.feature.properties.imageNumber));
                  viewer.loadScene(sceneId);
          })
          
          addedMarker.addTo(featureGroup);

          markers.push(addedMarker);
        });
      }
      
      
      // Fetch path coordinates and draw a line
      let pathCoordinates = getPathCoordinates(currFlrFeatGroup);

      polyLineLayer = L.polyline(pathCoordinates, {
        color: "#C0C0C0",
        weight: 5,
        opacity: 0.65,
      }).addTo(featureGroup);

      // Pannellum
      viewer = pannellum.viewer("panorama", {
                  scenes: {},
                  showZoomCtrl: false,
                  sceneFadeDuration: 1000,
                  title: ${JSON.stringify(title)}
              });
    
      function debounce(func, wait, immediate) {
          var timeout;
          return function() {
              var context = this, args = arguments;
              var later = function() {
                  timeout = null;
                  if (!immediate) func.apply(context, args);
              };
              var callNow = immediate && !timeout;
              clearTimeout(timeout);
              timeout = setTimeout(later, wait);
              if (callNow) func.apply(context, args);
          };
      };

      const storageEventCb = () => {
         if(window.ReactNativeWebView) {
          let viewerData = {
            pitch : viewer.getPitch(),
            yaw : viewer.getYaw(),
            fov : viewer.getHfov()
          }
          window.ReactNativeWebView.postMessage(JSON.stringify({"viewer":viewerData}));
        }
      }; 

      // Define the debounced function
      const debouncedCb = debounce(storageEventCb, 0.50);
     
      viewer.on("panorama-orientation-changed",debouncedCb);

       viewer.on("touchstart", () => {
         if(window.ReactNativeWebView) {
          window.ReactNativeWebView.postMessage(JSON.stringify({"type" : "touchStart", "value": true }));
        }
      });

      viewer.on("touchend", () => {
         if(window.ReactNativeWebView) {
          window.ReactNativeWebView.postMessage(JSON.stringify({"type" : "touchStart", "value": false }));
        }
      });
      


      ${images}.forEach((x) => {
          viewer.addScene(x.imageId, {
            type: "equirectangular",
            panorama: x.imageBlobUrl,
            autoLoad: true,
            pitch: 2.3,
            yaw: -135.4,
            hfov: 120
          });
      });

      let sceneId = ${images}[0].imageId;
      viewer.loadScene(sceneId);

     
      L.control.resizer({ direction: 'se' }).addTo(floorPlanMap);

     
     function updateViewer(viewerData) {
        if(viewer){
          viewer.lookAt(
            viewerData.pitch,
            viewerData.yaw,
            viewerData.fov,
            false
          );
        }
      }

       function updateImageNumber(imageNumber) {
          let marker = markers.find(
                (marker) => marker.feature.properties.imageNumber === imageNumber
              );
          if(marker) marker.fireEvent("click");
       }

      function updateCompareMode(isCompareMode) {
        if(isCompareMode){
          document.getElementById('controls').style.display = 'none'
        }
        else {
          document.getElementById('controls').style.display = 'block'
        }
      }
    
        
  </script>

  
  </body>
</html>`;
};

export default populateTourDetailsAndFetchHtml;
