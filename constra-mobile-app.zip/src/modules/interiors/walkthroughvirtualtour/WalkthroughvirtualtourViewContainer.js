// @flow
import { compose } from 'recompose';
import { connect } from 'react-redux';

import WalkthroughvirtualtourView from './WalkthroughvirtualtourView';
import Orientation from 'react-native-orientation-locker';
import {
  fetchAzureBlobToken,
  fetchFloorPlanToken,
  fetchSecondFloorPlanToken,
  fetchWalkthroughDetails,
  fetchAllInteriors,
  resetWalkthroughData,
} from './WalkthroughvirtualtourState';
import lifecycle from 'recompose/lifecycle';
import { StatusBar } from 'react-native';

export default compose(
  connect(
    ({ walkthroughvirtualtour }) => ({
      azureBlobToken: walkthroughvirtualtour.azureBlobToken,
      floorPlanToken: walkthroughvirtualtour.floorPlanToken,
      secondFloorPlanToken: walkthroughvirtualtour.secondFloorPlanToken,
      isLoading: walkthroughvirtualtour.isLoading,
      tour: walkthroughvirtualtour.tour,
      allInteriors: walkthroughvirtualtour.allInteriors,
    }),
    dispatch => ({
      fetchAzureBlobToken: () => dispatch(fetchAzureBlobToken()),
      fetchFloorPlanToken: floorPlanBlobId =>
        dispatch(fetchFloorPlanToken(floorPlanBlobId)),
      fetchSecondFloorPlanToken: floorPlanBlobId =>
        dispatch(fetchSecondFloorPlanToken(floorPlanBlobId)),
      fetchWalkthroughDetails: (projectId, walkthroughId) =>
        dispatch(fetchWalkthroughDetails(projectId, walkthroughId)),
      fetchAllInteriors: projectId => dispatch(fetchAllInteriors(projectId)),
      resetWalkthroughData: () => dispatch(resetWalkthroughData()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      Orientation.lockToLandscape();

      const {
        fetchAzureBlobToken,
        route,
        fetchWalkthroughDetails,
        fetchAllInteriors,
      } = this.props;

      const { projectId, tourId } = route.params;

      // API call
      fetchAzureBlobToken();

      fetchWalkthroughDetails(projectId, tourId);
      fetchAllInteriors(projectId);
    },
    componentWillUnmount() {
      // Unlock orientations and enable status bar
      const { resetWalkthroughData } = this.props;
      resetWalkthroughData();

      Orientation.unlockAllOrientations();
      StatusBar.setHidden(false);
    },
  }),
)(WalkthroughvirtualtourView);
