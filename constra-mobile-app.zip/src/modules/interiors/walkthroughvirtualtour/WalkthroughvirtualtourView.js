import React, { useEffect, useRef, useState } from 'react';
import { Dimensions, SafeAreaView, StyleSheet, View } from 'react-native';
import { LANDSCAPE, OrientationLocker } from 'react-native-orientation-locker';
import { Button, IconButton } from 'react-native-paper';
import WebView from 'react-native-webview';
import ActivityIndicator from '../../../components/ActivityIndicator';
import populateTourDetailsAndFetchHtml from './leaflet-web-view';
import colors from '../../../styles/colors';
import { useAsyncStorage } from '@react-native-async-storage/async-storage';
import { Select } from '@mobile-reality/react-native-select-pro';

import { format, parseISO } from 'date-fns';

const WalkthroughvirtualtourView = ({
  azureBlobToken,
  floorPlanToken,
  secondFloorPlanToken,
  isLoading,
  navigation,
  tour,
  allInteriors,
  fetchFloorPlanToken,
  fetchSecondFloorPlanToken,
  fetchAzureBlobToken,
}) => {
  const { getItem, setItem } = useAsyncStorage('virtual_tour_view_count');

  const [towers, setTowers] = useState();
  const [floors, setFloors] = useState();
  const [previousCaptures, setPreviousCaptures] = useState();

  const [width, setWidth] = useState();
  const [height, setHeight] = useState();

  const [interiorDate, setInteriorDate] = useState();

  const [isCompareLocked, setCompareLocked] = useState(true);
  const [isCompareApplicable, setCompareApplicable] = useState(false);

  const [towerName, setTowerName] = useState('');
  const [selectedTower, setSelectedTower] = useState();
  const [selectedFloor, setSelectedFloor] = useState();
  const [selectedCapture, setSelectedCapture] = useState();

  const [isViewerOneTouchEvent, setViewerOneTouchEvent] = useState(false);
  const [isViewerTwoTouchEvent, setIsViewerTwoTouchEvent] = useState(false);

  const [selectedImageNumber, setSelectedImageNumber] = useState(1);

  const [hideDropDowns, setHideDropDowns] = useState(false);

  const [walkthroughDetails, setWalkthroughDetails] = useState();
  const [
    walkthroughDetailsCompareView,
    setwalkthroughDetailsCompareView,
  ] = useState();

  const [isCompareMode, setCompareMode] = useState(false);

  const splitViewWebView1Ref = useRef();
  const splitViewWebView2Ref = useRef();

  const onSuccesfullLoad = async () => {
    const count = await getItem();
    if (count == null) {
      setItem(JSON.stringify(0));
    } else setItem(JSON.stringify(parseInt(count) + 1));
  };

  const getDateToCompare = () => {
    return allInteriors.find(
      interior => interior.interiorId === selectedCapture.value,
    ).interiorDate;
  };

  useEffect(() => {
    if (allInteriors && tour) compareApplicableStatus();
  }, [walkthroughDetails]);

  useEffect(() => {
    setWidth(Dimensions.get('window').width);
    setHeight(Dimensions.get('window').height);
  }, [Dimensions.get('window').height, Dimensions.get('window').width]);

  useEffect(() => {
    if (allInteriors && tour) {
      setWalkthroughDetails(tour);

      fetchFloorPlanToken(tour.floorPlanBlobId);

      let interior = allInteriors.find(
        interior => interior.interiorId === tour.interiorId,
      );

      setInteriorDate(interior?.interiorDate);

      setTowers(
        interior?.floorWalkthough
          .filter(
            tour =>
              tour.tours.length > 0 &&
              tour.tours.some(tour => tour.isActive && tour.isPublished),
          )
          .map(tour => ({
            label: tour.towerName,
            value: tour.towerId,
          })),
      );

      let tower = interior?.floorWalkthough.find(
        existingTour => existingTour.towerId === tour.towerId,
      );

      setTowerName(tower?.towerName);

      setSelectedTower({ label: tower?.towerName, value: tour.towerId });

      let publishedTours = tower?.tours.filter(
        tour => tour.isActive && tour.isPublished,
      );

      setFloors(
        publishedTours?.map(walkthrough => ({
          label: walkthrough.tourName,
          value: walkthrough.tourId,
        })),
      );

      setSelectedFloor({ label: tour.tourName, value: tour.tourId });

      compareApplicableStatus();
    }
  }, [allInteriors, tour]);

  const getWalkthroughForCompare = interiorId => {
    let mostRecentInterior = allInteriors.find(
      interior => interior.interiorId === interiorId,
    );

    let tour = mostRecentInterior.floorWalkthough
      .find(walkthrough => walkthrough.towerId === selectedTower.value)
      .tours?.find(tour => tour.locationId === walkthroughDetails.locationId);

    fetchSecondFloorPlanToken(tour.floorPlanBlobId);

    setwalkthroughDetailsCompareView(tour);
  };

  const getPreviousCaptures = () => {
    let walkthroughDetailsIncoming = walkthroughDetails
      ? walkthroughDetails
      : tour;
    return allInteriors
      .filter(interior => {
        let walkthrough = interior.floorWalkthough.find(
          walkthrough =>
            walkthrough.towerId === walkthroughDetailsIncoming.towerId,
        );
        return walkthrough?.tours.find(
          existingTour =>
            existingTour.tourId !== walkthroughDetailsIncoming.tourId &&
            existingTour.locationId === walkthroughDetailsIncoming.locationId &&
            existingTour.isActive &&
            existingTour.isPublished,
        );
      })
      .map(interior => ({
        label: format(parseISO(interior.interiorDate), 'dd LLL yyyy'),
        value: interior.interiorId,
      }));
  };

  const populatePreviousCaptures = () => {
    let availableCaptures = getPreviousCaptures();
    if (availableCaptures.length > 0) {
      setPreviousCaptures(availableCaptures);
      setSelectedCapture({
        label: availableCaptures[0].label,
        value: availableCaptures[0].value,
      });

      getWalkthroughForCompare(availableCaptures[0].value);
    }
  };

  const compareApplicableStatus = () => {
    setCompareApplicable(getPreviousCaptures().length > 0);
  };

  const [isWebViewLoading, setWebViewLoading] = useState(true);

  return (
    <>
      <ActivityIndicator visible={isWebViewLoading || isLoading} />
      <SafeAreaView style={{ flex: 1, backgroundColor: '#000000' }}>
        <OrientationLocker orientation={LANDSCAPE} />
        <IconButton
          icon="arrow-left"
          color={'#FFFFFF'}
          size={30}
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        />
        {width && (
          <View
            style={{
              ...styles.dropDownStyle,
              flexDirection: 'row',
              width: '35%',
              left: width / 2 - 0.1 * width,
            }}
          >
            {!isCompareMode && !hideDropDowns && towers && towers.length > 1 && (
              <Select
                selectContainerStyle={{
                  flex: floors && floors.length > 1 ? 1 : 0.5,
                  marginEnd: 5,
                }}
                defaultOption={selectedTower}
                clearable={false}
                onSelect={({ label, value }) => {
                  if (value !== selectedTower.value) {
                    fetchAzureBlobToken();

                    setSelectedTower({ label, value });

                    let interior = allInteriors.find(
                      interior => interior.interiorId === tour.interiorId,
                    );
                    let tower = interior.floorWalkthough.find(
                      tour => tour.towerId === value,
                    );

                    setTowerName(tower.towerName);

                    let publishedTours = tower.tours.filter(
                      tour => tour.isActive && tour.isPublished,
                    );

                    setFloors(
                      publishedTours.map(walkthrough => ({
                        label: walkthrough.tourName,
                        value: walkthrough.tourId,
                      })),
                    );

                    fetchFloorPlanToken(publishedTours[0].floorPlanBlobId);

                    setSelectedFloor({
                      label: publishedTours[0].tourName,
                      value: publishedTours[0].tourId,
                    });

                    setWalkthroughDetails(publishedTours[0]);
                  }
                }}
                options={towers}
              />
            )}
            {!isCompareMode && !hideDropDowns && floors && floors.length > 1 && (
              <Select
                defaultOption={selectedFloor}
                clearable={false}
                selectContainerStyle={{
                  flex: towers && towers.length > 1 ? 1 : 0.5,
                }}
                onSelect={({ label, value }) => {
                  if (value !== selectedFloor.value) {
                    setSelectedFloor({ label, value });

                    fetchAzureBlobToken();

                    let interior = allInteriors.find(
                      interior =>
                        interior.interiorId === walkthroughDetails.interiorId,
                    );

                    let walkthrough = interior.floorWalkthough
                      .find(tour => tour.towerId === selectedTower.value)
                      .tours.find(walkthrough => walkthrough.tourId === value);

                    setWalkthroughDetails(walkthrough);

                    fetchFloorPlanToken(walkthrough.floorPlanBlobId);
                  }
                }}
                options={floors}
              />
            )}
          </View>
        )}

        {allInteriors && tour && isCompareApplicable && height && (
          <Button
            color={colors.primary}
            mode="outlined"
            icon="compare"
            style={{ ...styles.compareButton, top: height / 2 }}
            vb
            compact
            accessibilityLabel="Show all"
            onPress={() => {
              setCompareMode(!isCompareMode);

              populatePreviousCaptures();

              splitViewWebView1Ref?.current?.injectJavaScript(
                `updateCompareMode(${!isCompareMode})`,
              );
            }}
          />
        )}

        {isCompareMode && (
          <Button
            color={colors.primary}
            mode="outlined"
            icon={isCompareLocked ? 'lock' : 'lock-open-outline'}
            style={{
              ...styles.lockButton,
              left: width / 2 - 25,
              top: height / 2 + 5,
            }}
            vb
            compact
            accessibilityLabel="Show all"
            onPress={() => {
              setCompareLocked(!isCompareLocked);
            }}
          />
        )}

        {previousCaptures && isCompareMode && (
          <View
            style={{
              ...styles.dropDownStyle,
              width: '20%',
              left:
                Dimensions.get('window').width / 2 +
                Dimensions.get('window').width / 4 -
                20,
            }}
          >
            <Select
              clearable={false}
              defaultOption={selectedCapture}
              onSelect={({ label, value }) => {
                if (value != selectedCapture.value) {
                  setSelectedCapture({ label, value });
                  getWalkthroughForCompare(value);
                }
              }}
              options={previousCaptures}
            />
          </View>
        )}

        {/* Webview showing the virtual tour, split functionality */}
        <View style={{ flexDirection: 'row', flex: 1 }}>
          {interiorDate && walkthroughDetails && (
            <WebView
              javaScriptEnabled={true}
              originWhitelist={['*']}
              ref={splitViewWebView1Ref}
              onLoad={onSuccesfullLoad}
              onLoadStart={() => setWebViewLoading(true)}
              onLoadEnd={() => {
                setWebViewLoading(false);
              }}
              onMessage={event => {
                let parsedData = JSON.parse(event.nativeEvent.data);

                if (parsedData.loadingComplete) {
                  setWebViewLoading(false);
                }
                if (parsedData.type === 'hideDropdown') {
                  setHideDropDowns(!JSON.parse(event.nativeEvent.data).value);
                }
                if (parsedData.imageChanged) {
                  setSelectedImageNumber(parsedData.imageChanged);
                  splitViewWebView2Ref?.current?.injectJavaScript(
                    `updateImageNumber(${parsedData.imageChanged}); true;`,
                  );
                }
                if (parsedData.type === 'touchStart') {
                  setViewerOneTouchEvent(parsedData.value);
                }
                if (
                  isCompareLocked &&
                  parsedData.viewer &&
                  !isViewerTwoTouchEvent
                ) {
                  splitViewWebView2Ref?.current?.injectJavaScript(
                    `if (typeof(updateViewer) == 'function') updateViewer(${JSON.stringify(
                      parsedData.viewer,
                    )}); true;`,
                  );
                }
              }}
              source={{
                html: populateTourDetailsAndFetchHtml(
                  { ...walkthroughDetails, towerName },
                  azureBlobToken,
                  floorPlanToken,
                  interiorDate,
                ),
              }}
              style={{ flex: 1 }}
            />
          )}

          {!isLoading &&
            walkthroughDetailsCompareView &&
            selectedCapture &&
            isCompareMode && (
              <WebView
                javaScriptEnabled={true}
                originWhitelist={['*']}
                onLoad={onSuccesfullLoad}
                ref={splitViewWebView2Ref}
                source={{
                  html: populateTourDetailsAndFetchHtml(
                    { ...walkthroughDetailsCompareView, towerName },
                    azureBlobToken,
                    secondFloorPlanToken,
                    getDateToCompare(),
                  ),
                }}
                onLoadStart={() => setWebViewLoading(true)}
                onLoadEnd={() => {
                  splitViewWebView2Ref?.current?.injectJavaScript(
                    `updateImageNumber(${selectedImageNumber}); true;`,
                  );
                  setWebViewLoading(false);
                }}
                onMessage={event => {
                  let parsedData = JSON.parse(event.nativeEvent.data);

                  if (parsedData.loadingComplete) {
                    splitViewWebView2Ref?.current?.injectJavaScript(
                      `updateCompareMode(${isCompareMode}); true;`,
                    );
                  }
                  if (parsedData.type === 'touchStart') {
                    setIsViewerTwoTouchEvent(parsedData.value);
                  }
                  if (
                    isCompareLocked &&
                    parsedData.viewer &&
                    !isViewerOneTouchEvent
                  ) {
                    splitViewWebView1Ref?.current?.injectJavaScript(
                      `if (typeof(updateViewer) == 'function') updateViewer(${JSON.stringify(
                        parsedData.viewer,
                      )}); true;`,
                    );
                  }
                }}
                style={{ flex: 1 }}
              />
            )}
        </View>

        <View></View>
      </SafeAreaView>
    </>
  );
};

const styles = StyleSheet.create({
  backButton: {
    position: 'absolute',
    left: 20,
    right: 20,
    top: 30,
    zIndex: 5,
    backgroundColor: colors.black,
  },
  dropDownStyle: {
    position: 'absolute',
    top: '5%',
    zIndex: 10,
  },
  compareButton: {
    position: 'absolute',
    right: 0,
    backgroundColor: 'white',
    borderRadius: 5,
    borderColor: colors.primary,
    borderWidth: 1,
    marginRight: 5,
    zIndex: 100000,
  },
  lockButton: {
    position: 'absolute',

    zIndex: 10,
    width: 50,
    backgroundColor: 'white',
    borderColor: colors.primary,
    borderWidth: 1,
    borderRadius: 5,
  },
});

export default WalkthroughvirtualtourView;
