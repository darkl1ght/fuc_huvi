export const initialState = {
  azureBlobToken: '',
  floorPlanToken: '',
  secondFloorPlanToken: '',
  isLoading: false,
  isErrorInLoading: false,
  tour: undefined,
  allInteriors: undefined,
};

const AZURE_BLOB_CALL_STARTED =
  'WalkthroughVirtualTourState/START_LOADING_BLOB';
const AZURE_BLOB_CALL_COMPLETED =
  'WalkthroughVirtualTourState/FINISHED_LOADING_BLOB';
const AZURE_BLOB_CALL_ERROR = 'WalkthroughVirtualTourState/ERROR_LOADING_BLOB';
const AZURE_FLOOR_PLAN_CALL_STARTED =
  'WalkthroughVirtualTourState/START_LOADING_FLOOR_PLAN';
const AZURE_FLOOR_PLAN_CALL_COMPLETED =
  'WalkthroughVirtualTourState/FINISHED_LOADING_FLOOR_PLAN';
const AZURE_SECOND_FLOOR_PLAN_CALL_COMPLETED =
  'WalkthroughVirtualTourState/FINISHED_LOADING_SECOND_FLOOR_PLAN';
const AZURE_FLOOR_PLAN_CALL_ERROR =
  'WalkthroughVirtualTourState/ERROR_LOADING_FLOOR_PLAN';

const WALKTHROUGH_API_CALL_STARTED =
  'WalkthroughVirtualTourState/LOADING_STARTED';

const WALKTHROUGH_API_COMPLETED =
  'WalkthroughVirtualTourState/FINISHED_LOADING_WALKTHROUGH';
const WALKTHROUGH_RESET_DATA =
  'WalkthroughVirtualTourState/WALKTHROUGH_RESET_DATA';

const WALKTHROUGH_API_ERROR = 'WalkthroughVirtualTourState/WALKTHROUGH_ERROR';

const FETCH_ALL_INTERIORS_API_CALL_STARTED =
  'WalkthroughVirtualTourState/ALL_INTERIORS_LOADING_STARTED';

const FETCH_ALL_INTERIORS_API_CALL_COMPLETED =
  'WalkthroughVirtualTourState/ALL_INTERIORS_LOADING_COMPLETED';

const FETCH_ALL_INTERIORS_API_CALL_ERROR =
  'WalkthroughVirtualTourState/ALL_INTERIORS_LOADING_ERROR';

export function loadingBlobTokenStarted() {
  return {
    type: AZURE_BLOB_CALL_STARTED,
  };
}
export function loadingFloorPlanTokenStarted() {
  return {
    type: AZURE_FLOOR_PLAN_CALL_STARTED,
  };
}

export function loadingWalkthroughStarted() {
  return {
    type: WALKTHROUGH_API_CALL_STARTED,
  };
}

export function resetWalkthroughData() {
  return {
    type: WALKTHROUGH_RESET_DATA,
  };
}

export function loadingAllInteriorsStarted() {
  return {
    type: FETCH_ALL_INTERIORS_API_CALL_STARTED,
  };
}

export function fetchAzureBlobToken() {
  return dispatch => {
    dispatch(loadingBlobTokenStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/azureblob/sas/read/virtualtour/`,
        onSuccess: AZURE_BLOB_CALL_COMPLETED,
        onError: AZURE_BLOB_CALL_ERROR,
      },
    });
  };
}

export function fetchFloorPlanToken(floorPlanBlobId) {
  return dispatch => {
    dispatch(loadingFloorPlanTokenStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/azureblob/sas/floor-plan/blob/${floorPlanBlobId}`,
        onSuccess: AZURE_FLOOR_PLAN_CALL_COMPLETED,
        onError: AZURE_FLOOR_PLAN_CALL_ERROR,
      },
    });
  };
}

export function fetchSecondFloorPlanToken(floorPlanBlobId) {
  return dispatch => {
    dispatch(loadingFloorPlanTokenStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/azureblob/sas/floor-plan/blob/${floorPlanBlobId}`,
        onSuccess: AZURE_SECOND_FLOOR_PLAN_CALL_COMPLETED,
        onError: AZURE_FLOOR_PLAN_CALL_ERROR,
      },
    });
  };
}

export function fetchWalkthroughDetails(projectId, walkthroughId) {
  return dispatch => {
    dispatch(loadingWalkthroughStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/virtualtour/${projectId}/interiors/tour/${walkthroughId}`,
        onSuccess: WALKTHROUGH_API_COMPLETED,
        onError: WALKTHROUGH_API_ERROR,
      },
    });
  };
}

export function fetchAllInteriors(projectId) {
  return dispatch => {
    dispatch(loadingAllInteriorsStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/virtualtour/${projectId}/interiors`,
        onSuccess: FETCH_ALL_INTERIORS_API_CALL_COMPLETED,
        onError: FETCH_ALL_INTERIORS_API_CALL_ERROR,
      },
    });
  };
}

export default function WalkthroughvirtualtourStateReducer(
  state = initialState,
  action,
) {
  switch (action.type) {
    case AZURE_BLOB_CALL_STARTED:
    case AZURE_FLOOR_PLAN_CALL_STARTED:
    case WALKTHROUGH_API_CALL_STARTED:
    case FETCH_ALL_INTERIORS_API_CALL_STARTED:
      return Object.assign({}, state, {
        isLoading: true,
      });
    case AZURE_BLOB_CALL_COMPLETED:
      return Object.assign({}, state, {
        azureBlobToken: action.payload.sasToken.token,
        isLoading: false,
      });
    case AZURE_BLOB_CALL_ERROR:
      return Object.assign({}, state, {
        isErrorInLoading: true,
        isLoading: false,
      });
    case AZURE_FLOOR_PLAN_CALL_COMPLETED:
      return Object.assign({}, state, {
        floorPlanToken: action.payload.sasToken.uri,
        isLoading: false,
      });
    case AZURE_SECOND_FLOOR_PLAN_CALL_COMPLETED:
      return Object.assign({}, state, {
        secondFloorPlanToken: action.payload.sasToken.uri,
        isLoading: false,
      });
    case AZURE_FLOOR_PLAN_CALL_ERROR:
      return Object.assign({}, state, {
        isErrorInLoading: true,
        isLoading: false,
      });
    case WALKTHROUGH_API_COMPLETED:
      return Object.assign({}, state, {
        tour: action.payload.tour,
        isLoading: false,
      });

    case FETCH_ALL_INTERIORS_API_CALL_COMPLETED:
      return Object.assign({}, state, {
        allInteriors: action.payload.interiors,
        isLoading: false,
      });

    case FETCH_ALL_INTERIORS_API_CALL_ERROR:
      return Object.assign({}, state, {
        isErrorInLoading: true,
        isLoading: false,
      });

    case WALKTHROUGH_RESET_DATA:
      return Object.assign({}, state, {
        allInteriors: undefined,
        tour: undefined,
      });

    default:
      return state;
  }
}
