import { filter } from 'lodash-es';

export const initialState = {
  isLoadingTours: false,
  interiorTours: [],
  isToursFetched: false,
  isErrorInGettingTours: false,
  filteredInteriors: [],
};

const LOADING_TOURS_STARTED = 'InteriorsState/START_LOADING';
const LOADING_TOURS_COMPLETED = 'InteriorsState/FINISHED_LOADING';
const LOADING_TOURS_ERROR = 'InteriorsState/ERROR_LOADING';
const RESET_INTERIORS = 'InteriorsState/RESET_INTERIORS';
const FILTER_INTERIORS = 'InteriorsState/FILTER_INTERIORS';

export function getToursStarted() {
  return {
    type: LOADING_TOURS_STARTED,
  };
}

export function getToursCompleted() {
  return {
    type: LOADING_TOURS_COMPLETED,
  };
}

export function loadingToursError() {
  return {
    type: LOADING_TOURS_ERROR,
  };
}

export function resetInteriors() {
  return {
    type: RESET_INTERIORS,
  };
}
export function filterInteriors(searchQuery) {
  return {
    type: FILTER_INTERIORS,
    payload: {
      interiorSearchQuery: searchQuery,
    },
  };
}
export function getAllInteriors(projectId) {
  return dispatch => {
    dispatch(getToursStarted());
    // Connect to the API here
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/virtualtour/${projectId}/interiors-without-tours`,
        onSuccess: LOADING_TOURS_COMPLETED,
        onError: LOADING_TOURS_ERROR,
      },
    });
  };
}

export default function InteriorsStateReducer(state = initialState, action) {
  switch (action.type) {
    case LOADING_TOURS_STARTED:
      return Object.assign({}, state, {
        isLoadingTours: true,
        isErrorInGettingTours: false,
      });
    case LOADING_TOURS_COMPLETED:
      return Object.assign({}, state, {
        isLoadingTours: false,
        isErrorInGettingTours: false,
        isToursFetched: true,
        interiorTours: action.payload.interiors,
        filteredInteriors: action.payload.interiors,
      });
    case LOADING_TOURS_ERROR:
      return Object.assign({}, state, {
        isLoadingTours: false,
        isErrorInGettingTours: true,
        interiorTours: action.payload.interiors,
      });
    case RESET_INTERIORS:
      return Object.assign({}, state, {
        isLoadingTours: false,
        isErrorInGettingTours: false,
        interiorTours: [],
        filteredInteriors: [],
      });
    case FILTER_INTERIORS:
      return Object.assign({}, state, {
        filteredInteriors: filter(state.interiorTours, tour =>
          tour.interiorName
            .toLowerCase()
            .includes(action.payload.interiorSearchQuery),
        ),
      });
    default:
      return state;
  }
}
