// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';
import {
  filterInteriors,
  getAllInteriors,
  resetInteriors,
} from './InteriorsState';
import InteriorsView from './InteriorsView';

export default compose(
  connect(
    ({ interiors, projects }) => ({
      isLoading: interiors.isLoadingTours,
      interiorTours: interiors.filteredInteriors,
      error: interiors.isErrorInGettingTours,
      selectedProjectId: projects.projectId,
      isApiCallFinished: interiors.isToursFetched,
    }),
    dispatch => ({
      getAllInteriors: projectId => dispatch(getAllInteriors(projectId)),
      clearInteriors: () => dispatch(resetInteriors()),
      filterInteriors: searchQuery => dispatch(filterInteriors(searchQuery)),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const { selectedProjectId, getAllInteriors } = this.props;
      getAllInteriors(selectedProjectId);
    },
    componentWillUnmount() {
      this.props.clearInteriors();
    },
  }),
)(InteriorsView);
