// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import PanoramaViewerView from './PanoramaViewerView';
import { getAzureBlobReadToken } from './PanoramaViewerState';
import Orientation from 'react-native-orientation-locker';
import { StatusBar } from 'react-native';

export default compose(
  connect(
    ({ panoramaViewer }) => ({
      azureBlobToken: panoramaViewer.azureMediaContainerToken,
      isLoading: panoramaViewer.isLoading,
    }),
    dispatch => ({
      getAzureBlobReadToken: () => dispatch(getAzureBlobReadToken()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      this.props.getAzureBlobReadToken();
      StatusBar.setHidden(true);
      Orientation.lockToLandscape();
    },
    componentWillUnmount() {
      StatusBar.setHidden(false);
      Orientation.unlockAllOrientations();
    },
  }),
)(PanoramaViewerView);
