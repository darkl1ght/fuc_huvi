// Initial state
const initialState = {
  isLoading: false,
  isError: false,
  azureMediaContainerToken: '',
};

const BLOB_TOKEN_LOADING_STARTED = 'CLIENTS_STATE/BLOB_TOKEN_LOADING_STARTED';
const BLOB_TOKEN_LOADING_COMPLETED =
  'CLIENTS_STATE/BLOB_TOKEN_LOADING_COMPLETED';
const BLOB_TOKEN_LOADING_ERROR = 'CLIENTS_STATE/BLOB_TOKEN_ERROR';

// Action creators
function startTokenCall() {
  return { type: BLOB_TOKEN_LOADING_STARTED };
}

export function getAzureBlobReadToken() {
  return dispatch => {
    dispatch(startTokenCall());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/azureblob/sas/read/media/`,
        onSuccess: BLOB_TOKEN_LOADING_COMPLETED,
        onError: BLOB_TOKEN_LOADING_ERROR,
      },
    });
  };
}

// Reducer
export default function PanoramaViewReducer(state = initialState, action = {}) {
  switch (action.type) {
    case BLOB_TOKEN_LOADING_STARTED:
      return Object.assign({}, state, {
        isLoading: true,
      });
    case BLOB_TOKEN_LOADING_COMPLETED:
      return Object.assign({}, state, {
        isLoading: false,
        azureMediaContainerToken: action.payload.sasToken.token,
      });
    case BLOB_TOKEN_LOADING_ERROR:
      return Object.assign({}, state, {
        isLoading: false,
        isError: true,
      });
    default:
      return state;
  }
}
