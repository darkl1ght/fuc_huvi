import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import { IconButton } from 'react-native-paper';
import WebView from 'react-native-webview';
import ActivityIndicator from '../../../components/ActivityIndicator';
import { colors } from '../../../styles';
import Config from '../../utils/config';

const AZURE_MEDIA_CONTAINER_URL = Config.get('azureMediaContainer');

const PanoramaViewer = ({ route, azureBlobToken, isLoading, navigation }) => {
  const { blobContentId } = route.params;
  const imageUrl =
    AZURE_MEDIA_CONTAINER_URL + `${blobContentId}?${azureBlobToken}`;
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#2d4059' }}>
      <ActivityIndicator visible={isLoading} />

      <IconButton
        icon="arrow-left"
        color={colors.darkerWhite}
        size={24}
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      />
      {!isLoading && (
        <WebView
          javaScriptEnabled={true}
          originWhitelist={['*']}
          source={{
            html: `<!DOCTYPE HTML>
                 <html>
                 <head>
                 <meta charset="utf-8">
                 <meta name="viewport" content="width=device-width, initial-scale=1.0">
                 <title>Panorama</title>
                 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css"/>
                 <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.js"></script>
                 <style>
                  html {
                   height: 100%;
                  }
                  body {
                    margin: 0;
                    padding: 0;
                    overflow: hidden;
                    position: fixed;
                    cursor: default;
                    width: 100%;
                    height: 100%;
                  }
                  #panorama {
                    margin-bottom : 5px; 
                    positive : relative;
                    width: 100%;
                    height: 100%;
                  }
                
                 </style>
                 </head>
                 <body>

                  <div id="panorama"></div>
                    <script>
                    pannellum.viewer('panorama', {
                        "panorama": ${JSON.stringify(imageUrl)},
                        "autoLoad" : true,
                        "showZoomCtrl": false,
                        "compass" : true,
                        "author" : "Huviair",
                       
                    });
                    </script>

                 </body>
                  </html>`,
          }}
          style={{ flex: 1 }}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  backButton: {
    position: 'absolute',
    left: 20,
    right: 20,
    top: 10,
    zIndex: 5,
    backgroundColor: colors.black,
  },
});

export default PanoramaViewer;
