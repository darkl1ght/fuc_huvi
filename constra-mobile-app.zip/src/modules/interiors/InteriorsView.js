// @flow
import format from 'date-fns/format';
import React, { useState } from 'react';
import { FlatList, SafeAreaView, StyleSheet } from 'react-native';
import {
  Divider,
  List,
  Searchbar,
  Snackbar,
  useTheme,
} from 'react-native-paper';
import ActivityIndicator from '../../components/ActivityIndicator';
import { Text } from '../../components/StyledText';

export default ({ isLoading, interiorTours, navigation, filterInteriors }) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Snackbar
  const [snackBarVisibility, setSnackBarVisible] = useState(false);
  const onDismissSnackBar = () => setSnackBarVisible(false);
  const snackBarVisibilityDuration = 3000;

  const { colors } = useTheme();

  const renderItem = ({ item }) => (
    <>
      <List.Item
        onPress={() => {
          if (item.floorWalkthough.length > 0) {
            // Navigate to walkthrough component
            navigation.navigate('Walkthroughs', {
              selectedInteriorId: item.interiorId,
              selectedTourName: item.interiorName,
            });
          } else setSnackBarVisible(true);
        }}
        titleNumberOfLines={2}
        descriptionNumberOfLines={1}
        key={item.interiorId}
        title={item.interiorName}
        description={`${format(
          new Date(item.interiorDate),
          'LLLL dd yyyy',
        )} | ${item.floorWalkthough.length} ${
          item.floorWalkthough.length === 1 ? 'Walkthrough' : 'Walkthroughs'
        }`}
        left={props => <List.Icon {...props} icon="video-switch" />}
        style={{
          elevation: 6,
        }}
      />

      <Divider />
    </>
  );

  const onChangeSearch = query => {
    const formattedQuery = query.toLowerCase();
    filterInteriors(formattedQuery);
    setSearchQuery(query);
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ActivityIndicator visible={isLoading} />
      <Searchbar
        placeholder="Search virtual tours"
        onChangeText={onChangeSearch}
        value={searchQuery}
        style={styles.searchBar}
      />
      <FlatList
        data={interiorTours}
        renderItem={renderItem}
        keyExtractor={item => item.interiorId}
        style={{ paddingHorizontal: 5 }}
      />
      {interiorTours.length == 0 && !isLoading && (
        <Text
          style={{ flex: 1, textAlign: 'center', color: colors.onSurface }}
          size={24}
        >
          No virtual tours found
        </Text>
      )}
      <Snackbar
        visible={snackBarVisibility}
        onDismiss={onDismissSnackBar}
        duration={snackBarVisibilityDuration}
      >
        No walkthroughs available
      </Snackbar>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  searchBar: {
    margin: 10,
  },
});
