import React, { useEffect, useState } from 'react';
import { FlatList, SafeAreaView, StatusBar } from 'react-native';
import Orientation, {
  OrientationLocker,
  LANDSCAPE,
} from 'react-native-orientation-locker';
import { useSelector } from 'react-redux';
import axios from 'axios';
import { bar, sCurveData } from '../../selfserve/SelfServeDefaults';
import SelfServeChartItem from '../../selfserve/ChartItemView';
import config from '../../utils/config';
import ActivityIndicator from '../../../components/ActivityIndicator';
import uuid from 'react-native-uuid';

const PROJECT_API = config.get('projectAPI');

export default ({ route }) => {
  let {
    tour: { projectId, tourId, interiorId, towerId, locationId },
  } = route.params;

  const userToken = useSelector(({ login }) => login.user.token);

  const [charts, setCharts] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    try {
      async function getChartsForSelectedLocation() {
        setIsLoading(true);
        let projectCharts = [];

        const {
          data: { response: chartsData },
        } = await axios.get(
          `${PROJECT_API}/virtualtour/${projectId}/${interiorId}/wbs/int/chart/${tourId}/${towerId}/${locationId}/`,
          {
            headers: { Authorization: `Token ${userToken}` },
          },
        );

        let sCurve = {
          chartName: 'S Curve structure',
          chartType: 'line',
        };
        let wbsChart = {
          chartName: 'Work Breakdown Structure',
          chartType: 'bar',
        };

        if (chartsData.sCurve && chartsData.sCurve.labels.length > 0) {
          projectCharts = [];

          sCurveData.labels = chartsData.sCurve.labels;
          sCurveData.datasets[0].data = chartsData.sCurve.planned;
          sCurveData.datasets[1].data = chartsData.sCurve.actual;
          sCurveData.id = uuid.v4();

          sCurve.data = sCurveData;
          projectCharts.push(sCurve);
        }

        if (chartsData.wbsChart && chartsData.wbsChart.labels.length > 0) {
          bar.labels = chartsData.wbsChart.labels;
          bar.id = uuid.v4();
          bar.datasets[0].data = chartsData.wbsChart.planned;
          bar.datasets[1].data = chartsData.wbsChart.actual;
          bar.datasets[1].toolTip = chartsData.wbsChart.toolTip;

          wbsChart.data = bar;
          projectCharts.push(wbsChart);
        }

        setCharts(projectCharts);
        setIsLoading(false);
      }
      getChartsForSelectedLocation();
    } catch (error) {
      setIsLoading(false);
    }
    return function cleanup() {
      Orientation.unlockAllOrientations();
      StatusBar.setHidden(false);
    };
  }, []);

  return (
    <>
      <ActivityIndicator visible={isLoading} />
      <SafeAreaView style={{ flex: 1 }}>
        <OrientationLocker orientation={LANDSCAPE} />
        <FlatList
          data={charts}
          renderItem={SelfServeChartItem}
          keyExtractor={item => item.id}
          style={{ flex: 1, flexDirection: 'column' }}
        />
      </SafeAreaView>
    </>
  );
};
