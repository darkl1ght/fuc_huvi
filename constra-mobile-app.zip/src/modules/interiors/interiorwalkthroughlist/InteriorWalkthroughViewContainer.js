// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';
import InteriorWalkthroughView from './InteriorWalkthroughView';
import {
  getWalkthroughsForInterior,
  resetWalkthroughs,
} from './InteriorWalkthroughState';

export default compose(
  connect(
    ({ projects, interiorWalkthrough }) => ({
      isLoading: interiorWalkthrough.isLoadingWalkthroughs,
      selectedProjectId: projects.projectId,
      walkthroughs: interiorWalkthrough.walkthroughs,
    }),
    dispatch => ({
      fetchWalkthroughs: (selectedProjectId, selectedInteriorId) =>
        dispatch(
          getWalkthroughsForInterior(selectedProjectId, selectedInteriorId),
        ),
      clearWalkthroughs: () => dispatch(resetWalkthroughs()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const { route, fetchWalkthroughs, selectedProjectId } = this.props;
      const { selectedInteriorId } = route.params;

      // API call
      fetchWalkthroughs(selectedProjectId, selectedInteriorId);
    },

    componentWillUnmount() {
      this.props.clearWalkthroughs();
    },
  }),
)(InteriorWalkthroughView);
