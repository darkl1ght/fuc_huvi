import sortBy from 'lodash/sortBy';

export const initialState = {
  isLoadingWalkthroughs: false,
  walkthroughs: [],
  isErrorInGettingWalkthroughs: false,
};

const LOADING_WALKTHROUGH_STARTED = 'InteriorWalkthroughState/START_LOADING';
const LOADING_WALKTHROUGH_COMPLETED =
  'InteriorWalkthroughState/FINISHED_LOADING';
const LOADING_WALKTHROUGH_ERROR = 'InteriorWalkthroughState/ERROR_LOADING';
const RESET_WALKTHROUGHS = 'InteriorWalkthroughState/RESET_WALKTHROUGHS';

export function getWalkthroughsStarted() {
  return {
    type: LOADING_WALKTHROUGH_STARTED,
  };
}

export function getWalkthroughsCompleted() {
  return {
    type: LOADING_WALKTHROUGH_COMPLETED,
  };
}

export function loadingWalkthroughsError() {
  return {
    type: LOADING_WALKTHROUGH_ERROR,
  };
}

export function resetWalkthroughs() {
  return {
    type: RESET_WALKTHROUGHS,
  };
}

export function getWalkthroughsForInterior(projectId, interiorTourId) {
  return dispatch => {
    dispatch(getWalkthroughsStarted());
    // Connect to the API here
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/virtualtour/${projectId}/interior/${interiorTourId}`,
        onSuccess: LOADING_WALKTHROUGH_COMPLETED,
        onError: LOADING_WALKTHROUGH_ERROR,
      },
    });
  };
}

export default function InteriorWalkthroughReducer(
  state = initialState,
  action,
) {
  switch (action.type) {
    case LOADING_WALKTHROUGH_STARTED:
      return Object.assign({}, state, {
        isLoadingWalkthroughs: true,
        isErrorInGettingWalkthroughs: false,
      });
    case LOADING_WALKTHROUGH_COMPLETED:
      let sortedTours = action.payload.tours.map(tower => {
        tower.tours = sortBy(tower.tours, ['tourName']);
        return tower;
      });
      return Object.assign({}, state, {
        isLoadingWalkthroughs: false,
        isErrorInGettingWalkthroughs: false,
        walkthroughs: sortedTours,
      });
    case LOADING_WALKTHROUGH_ERROR:
      return Object.assign({}, state, {
        isLoadingWalkthroughs: false,
        isErrorInGettingWalkthroughs: true,
      });
    case RESET_WALKTHROUGHS:
      return Object.assign({}, state, {
        isLoadingWalkthroughs: false,
        isErrorInGettingWalkthroughs: false,
        walkthroughs: [],
      });

    default:
      return state;
  }
}
