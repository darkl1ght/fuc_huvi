// @flow
import { useAsyncStorage } from '@react-native-async-storage/async-storage';
import React, { useEffect, useState } from 'react';
import { FlatList, SafeAreaView } from 'react-native';
import {
  Divider,
  IconButton,
  List,
  Snackbar,
  useTheme,
  Text,
  Button,
} from 'react-native-paper';
import ActivityIndicator from '../../../components/ActivityIndicator';
import useAppReview from '../../../hooks/useAppReview';
import routes from '../../navigation/routes';
import Routes from '../../navigation/routes';

export default ({ walkthroughs, navigation, isLoading }) => {
  // Snackbar
  const [snackBarVisibility, setSnackBarVisible] = useState(false);
  const onDismissSnackBar = () => setSnackBarVisible(false);
  const snackBarVisibilityDuration = 3000;

  const { onReview } = useAppReview();
  const { getItem } = useAsyncStorage('virtual_tour_view_count');

  const getPublishedToursSize = tours =>
    tours.filter(tour => tour.isPublished).length;

  const { colors } = useTheme();

  useEffect(() => {
    async function review() {
      const count = await getItem();
      if (count != null && parseInt(count) > 5) {
        await onReview();
      }
    }
    if (walkthroughs.length > 0) {
      review();
    }
  }, [walkthroughs]);

  const renderItem = ({ item: walkthrough }) => {
    const publishedToursSize = getPublishedToursSize(walkthrough.tours);
    return (
      <>
        <List.Accordion
          key={walkthrough.towerId}
          title={walkthrough.towerName}
          description={`Published ${publishedToursSize} of ${walkthrough.tours.length}`}
          left={props => <List.Icon {...props} icon="domain" />}
          style={{
            elevation: 6,
          }}
        >
          {walkthrough.tours.every(tour => !tour.isPublished) ? (
            <Text
              variant="bodyMedium"
              style={{ textAlign: 'auto', padding: 20 }}
            >
              No walkthroughs published
            </Text>
          ) : (
            walkthrough.tours.map(tour => (
              <List.Item
                right={props => (
                  <>
                    {walkthrough.bim?.forgeObject && tour.isPublished && (
                      <Button
                        {...props}
                        icon="office-building"
                        mode="text"
                        compact={true}
                        onPress={() => {
                          navigation.navigate(
                            Routes.BOTTOM_TAB_DISABLED_NAVIGATOR,
                            {
                              screen: Routes.BIM_VIEWER,
                              params: {
                                urn: walkthrough.bim?.forgeObject.urn,
                              },
                            },
                          );
                        }}
                      >
                        BIM
                      </Button>
                    )}
                    <IconButton
                      {...props}
                      icon={
                        tour.isPublished
                          ? 'check-decagram'
                          : 'dots-horizontal-circle'
                      }
                      color={tour.isPublished ? '#28b463' : '#d35400'}
                      onPress={() => {
                        if (tour.isPublished)
                          navigation.navigate(
                            Routes.BOTTOM_TAB_DISABLED_NAVIGATOR,
                            {
                              screen: 'Walkthrough-Virtual-Tour',
                              params: {
                                ...tour,
                                towerName: walkthrough.towerName,
                              },
                            },
                          );
                        else setSnackBarVisible(true);
                      }}
                    />
                    {tour.isSelfServe &&
                      (tour.isWBSPublished || tour.charts.length === 0) && (
                        <IconButton
                          {...props}
                          icon="chart-bar"
                          color={colors.primary}
                          onPress={() =>
                            navigation.navigate(
                              Routes.BOTTOM_TAB_DISABLED_NAVIGATOR,
                              {
                                screen: routes.INTERIORS_SELF_SERVE,
                                params: {
                                  tour,
                                  title: `${walkthrough.towerName} - ${tour.tourName}`,
                                },
                              },
                            )
                          }
                        />
                      )}
                    {!tour.isSelfServe && tour.charts.length > 0 && (
                      <IconButton
                        {...props}
                        icon="chart-bar"
                        color={colors.primary}
                        onPress={() =>
                          navigation.navigate(
                            Routes.BOTTOM_TAB_DISABLED_NAVIGATOR,
                            {
                              screen: 'Progress Charts',
                              params: {
                                data: tour.charts,
                                title: `${walkthrough.towerName} - ${tour.tourName}`,
                              },
                            },
                          )
                        }
                      />
                    )}
                  </>
                )}
                onPress={() => {
                  if (tour.isPublished)
                    navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
                      screen: 'Walkthrough-Virtual-Tour',
                      params: { ...tour, towerName: walkthrough.towerName },
                    });
                  else setSnackBarVisible(true);
                }}
                key={tour.tourId}
                title={tour.tourName}
                style={{
                  elevation: 6,
                }}
              />
            ))
          )}
        </List.Accordion>

        <Divider />
      </>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ActivityIndicator visible={isLoading} />
      <FlatList
        data={walkthroughs}
        renderItem={renderItem}
        keyExtractor={item => item.towerId}
      />
      <Snackbar
        visible={snackBarVisibility}
        onDismiss={onDismissSnackBar}
        duration={snackBarVisibilityDuration}
      >
        Selected walkthrough is not published
      </Snackbar>
    </SafeAreaView>
  );
};
