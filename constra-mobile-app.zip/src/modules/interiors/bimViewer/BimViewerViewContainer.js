// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';

import BimViewerView from './BimViewerView';
import { getForgeObjectManifest, getForgeToken } from './BimViewerState';

export default compose(
  connect(
    ({ bimViewer }) => ({
      translationStatus: bimViewer.translationStatus,
      isLoading: bimViewer.isLoading,
      isError: bimViewer.isError,
      forgeToken: bimViewer.token,
      expiresIn: bimViewer.expiryTime,
    }),
    dispatch => ({
      getForgeObjectManifest: urn => dispatch(getForgeObjectManifest(urn)),
      getForgeToken: () => dispatch(getForgeToken()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const { urn } = this.props.route.params;

      this.props.getForgeObjectManifest(urn);
      this.props.getForgeToken();
    },
    componentWillUnmount() {},
  }),
)(BimViewerView);
