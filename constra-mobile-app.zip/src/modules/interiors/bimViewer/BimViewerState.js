// @flow
// Initial state
const initialState = {
  isLoading: false,
  isError: false,
  translationStatus: '',
  token: undefined,
  expiryTime: undefined,
};

export const FETCHING_MANIFEST_COMPLETE =
  'BimViewerState/FETCHING_MANIFEST_COMPLETE';
export const FETCHING_TOKEN_COMPLETE = 'BimViewerState/FETCHING_TOKEN_COMPLETE';
export const ERROR_FETCHING_DATA = 'BimViewerState/ERROR_FETCHING_DATA';
export const LOADING = 'BimViewerState/LOADING';

export function getForgeObjectManifest(urn) {
  return dispatch => {
    dispatch(startLoading());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/forge/translate/status/${urn}`,
        onSuccess: FETCHING_MANIFEST_COMPLETE,
        onError: ERROR_FETCHING_DATA,
      },
    });
  };
}

export function getForgeToken() {
  return dispatch => {
    dispatch(startLoading());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/forge/oauth/token/`,
        onSuccess: FETCHING_TOKEN_COMPLETE,
        onError: ERROR_FETCHING_DATA,
      },
    });
  };
}

// Action creators
function startLoading() {
  return { type: LOADING };
}

// Reducer
export default function BimViewerStateReducer(
  state = initialState,
  action = {},
) {
  switch (action.type) {
    case LOADING:
      return Object.assign({}, state, {
        isLoading: true,
        isError: false,
      });
    case FETCHING_MANIFEST_COMPLETE:
      return Object.assign({}, state, {
        isLoading: false,
        translationStatus: action.payload.status,
      });
    case FETCHING_TOKEN_COMPLETE:
      return Object.assign({}, state, {
        isLoading: false,
        token: action.payload.accessToken,
        expiryTime: action.payload.expiresIn,
      });
    case ERROR_FETCHING_DATA:
      return Object.assign({}, state, {
        isLoading: false,
        isError: true,
      });
    default:
      return state;
  }
}
