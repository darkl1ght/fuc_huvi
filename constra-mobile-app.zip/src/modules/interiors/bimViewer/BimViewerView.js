// @flow
import React from 'react';
import { Dimensions, SafeAreaView, StyleSheet } from 'react-native';
import ActivityIndicator from '../../../components/ActivityIndicator';

import { IconButton } from 'react-native-paper';
import { colors } from '../../../styles';
import WebView from 'react-native-webview';

export default props => {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#2d4059' }}>
      <ActivityIndicator visible={props.isLoading} />

      <IconButton
        icon="arrow-left"
        color={colors.darkerWhite}
        size={24}
        style={styles.backButton}
        onPress={() => props.navigation.goBack()}
      />
      {!props.isLoading && props.forgeToken !== undefined && (
        <WebView
          style={styles.webview}
          javaScriptEnabled={true}
          scrollEnabled={false}
          injectedJavaScript={`initializeViewer("urn:${props.route.params.urn}","${props.forgeToken}")`}
          source={{
            html: `
        <!DOCTYPE html>
        <head>
           <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
            <meta name="apple-mobile-web-app-capable" content="yes" />
            <link rel="stylesheet" href="https://developer.api.autodesk.com/derivativeservice/v2/viewers/style.min.css?v=v2.17" type="text/css">
            <script src="https://developer.api.autodesk.com/derivativeservice/v2/viewers/three.min.js?v=v2.17"></script>
            <script src="https://developer.api.autodesk.com/derivativeservice/v2/viewers/viewer3D.js?v=v2.17"></script>
        </head>
        <style>
          body {
              margin: 0;
          }
          #forgeViewer {
              width: 100%;
              height: 100%;
              margin: 0;
              background-color: #F0F8FF;
          }
         </style>
        <body><div id="forgeViewer"></div></body>
        <script>
            var viewer;
              function initializeViewer(urn, token) {
               var options = {
                    env: "AutodeskProduction",
                    useConsolidation: false,
                    useADP: false,
                    accessToken: token
                };

                function onSuccess(doc) {
                    // A document contains references to 3D and 2D viewables.
                    var viewables = Autodesk.Viewing.Document.getSubItemsWithProperties(doc.getRootItem(), {'type':'geometry'}, true);
                    var initialViewable = viewables[0];
                    var svfUrl = doc.getViewablePath(initialViewable);
                    var modelOptions = {
                        sharedPropertyDbPath: doc.getPropertyDbPath()
                    };
                    var viewerDiv = document.getElementById('forgeViewer');
                    viewer = new Autodesk.Viewing.Private.GuiViewer3D(viewerDiv);
                    viewer.start(svfUrl, modelOptions);
                };

                 Autodesk.Viewing.Initializer(options, function onInitialized(){
                    Autodesk.Viewing.Document.load(urn, onSuccess);
                });
               
               
            }
          
        </script>
    `,
          }}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  backButton: {
    position: 'absolute',
    left: 20,
    right: 20,
    top: 40,
    zIndex: 5,
    backgroundColor: colors.black,
  },
  webview: {
    flex: 1,
    width: Dimensions.get('window').width,
  },
});
