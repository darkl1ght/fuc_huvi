let barChartOptions = {
  scaleShowVerticalLines: false,
  responsive: true,
  scales: {
    yAxes: [
      {
        ticks: {
          beginAtZero: true,
          precision: 0,
        },
      },
    ],
  },
  tooltips: {
    callbacks: {
      label: function(tooltipItems, data) {
        if (tooltipItems.datasetIndex == 0) {
          return (
            data.datasets[tooltipItems.datasetIndex].label +
            ': ' +
            tooltipItems.yLabel +
            '%'
          );
        } else if (tooltipItems.datasetIndex == 1) {
          return (
            data.datasets[tooltipItems.datasetIndex].label +
            ': ' +
            tooltipItems.yLabel +
            '%' +
            '  ' +
            (data.datasets[tooltipItems.datasetIndex].toolTip &&
            data.datasets[tooltipItems.datasetIndex].toolTip[tooltipItems.index]
              ? data.datasets[tooltipItems.datasetIndex].toolTip[
                  tooltipItems.index
                ]
              : '')
          );
        }
      },
    },
  },
};

let sCurveData = {
  labels: [],
  datasets: [
    {
      label: 'Planned ',
      backgroundColor: '#42A5F5',
      borderColor: '#1E88E5',
      fill: false,
      data: [],
    },
    {
      label: 'Actual ',
      backgroundColor: '#9CCC65',
      borderColor: '#7CB342',
      fill: false,
      data: [],
    },
  ],
};

let bar = {
  labels: [],
  datasets: [
    {
      label: 'Planned ',
      backgroundColor: '#42A5F5',
      borderColor: '#1E88E5',
      fill: false,
      data: [],
    },
    {
      label: 'Actual ',
      backgroundColor: '#9CCC65',
      borderColor: '#7CB342',
      fill: false,
      data: [],
      toolTip: [],
    },
  ],
};

export { barChartOptions, bar, sCurveData };
