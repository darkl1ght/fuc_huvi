import { SafeAreaView, StyleSheet } from 'react-native';
import React from 'react';
import WebView from 'react-native-webview';
import { barChartOptions } from './SelfServeDefaults';

const populateChartHtml = config => {
  let chartConfig = JSON.stringify(config);
  return `
        <html>
        <head>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        </head>
        <body>
        <div>
          <canvas id="myChart"></canvas>
        </div>
        <script>

          var myChart = new Chart(
            document.getElementById('myChart'),
            ${chartConfig}
          );
        </script>
        </body>
        </html>

`;
};

export default chartItem = ({ item: chart }) => {
  let data = {
    labels: chart.data.labels,
    datasets: chart.data.datasets,
  };
  const config = {
    type: chart.chartType,
    data,
    options: {
      ...barChartOptions,
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: chart.chartName,
          font: {
            size: 25,
          },
        },
      },
    },
  };
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <WebView
        source={{ html: populateChartHtml(config) }}
        style={styles.chart}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  chart: {
    minHeight: 450,
    marginTop: 15,
    marginEnd: 5,
    marginStart: 5,
  },
});
