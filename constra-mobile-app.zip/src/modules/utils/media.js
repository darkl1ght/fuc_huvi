const isImageMedia = mediaType =>
  mediaType.code === 'MT10001' || mediaType.code === 'MT10003';

const isVideoMedia = mediaType =>
  mediaType.code === 'MT10002' || mediaType.code === 'MT10004';

const is360Image = mediaType => mediaType.code === 'MT10003';
const is360Video = mediaType => mediaType.code === 'MT10004';

export { isImageMedia, isVideoMedia, is360Image, is360Video };
