import { PermissionsAndroid } from 'react-native';

export default async (permissionType, title, message) => {
  try {
    const result = await PermissionsAndroid.requestMultiple(permissionType, {
      title,
      message,
      buttonNeutral: 'Ask Me Later',
      buttonNegative: 'Cancel',
      buttonPositive: 'OK',
    });

    return permissionType.every(
      permission => result[permission] === PermissionsAndroid.RESULTS.GRANTED,
    );
  } catch (err) {
    console.warn(err);
  }
};
