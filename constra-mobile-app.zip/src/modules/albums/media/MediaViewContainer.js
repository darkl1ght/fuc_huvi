// @flow
import { connect } from 'react-redux';
import { compose, lifecycle } from 'recompose';
import { getMediaForAlbum } from './MediaState';
import MediaView from './MediaView';

export default compose(
  connect(
    ({ media, projects }) => ({
      media: media.media,
      selectedProjectId: projects.projectId,
      isLoading: media.isLoading,
    }),
    dispatch => ({
      getMediaForAlbum: (albumId, albums) =>
        dispatch(getMediaForAlbum(albumId, albums)),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const { route, getMediaForAlbum, selectedProjectId } = this.props;
      getMediaForAlbum(selectedProjectId, route.params.albumId);
    },
  }),
)(MediaView);
