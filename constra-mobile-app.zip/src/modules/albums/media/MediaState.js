// @flow

export const initialState = {
  media: [],
  isLoading: false,
  isError: false,
};

export const MEDIA_CALL_STARTED = 'MediaState/MEDIA_CALL_STARTED';
export const MEDIA_CALL_COMPLETE = 'MediaState/MEDIA_CALL_COMPLETE';
export const MEDIA_CALL_ERROR = 'MediaState/MEDIA_CALL_ERROR';

function mediaAlbumsStarted() {
  return {
    type: MEDIA_CALL_STARTED,
  };
}

export function getMediaForAlbum(projectId, albumId) {
  return dispatch => {
    dispatch(mediaAlbumsStarted());
    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/projectmedia/${projectId}/album/${albumId}/`,
        onSuccess: MEDIA_CALL_COMPLETE,
        onError: MEDIA_CALL_ERROR,
      },
    });
  };
}

export default function MediaStateReducer(state = initialState, action) {
  switch (action.type) {
    case MEDIA_CALL_COMPLETE:
      return {
        ...state,
        media: action.payload.media,
        isLoading: false,
      };
    case MEDIA_CALL_STARTED:
      return {
        ...state,
        isLoading: true,
      };
    case MEDIA_CALL_ERROR:
      return {
        ...state,
        isLoading: false,
        isError: true,
      };
    default:
      return state;
  }
}
