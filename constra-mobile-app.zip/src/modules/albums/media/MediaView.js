import { isMatch } from 'date-fns/esm';
import format from 'date-fns/format';
import parse from 'date-fns/parse';
import get from 'lodash/get';
import memoize from 'lodash/memoize';
import React, { useState } from 'react';
import {
  FlatList,
  ImageBackground,
  Platform,
  SafeAreaView,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import { Divider, IconButton, useTheme } from 'react-native-paper';
import ActivityIndicator from '../../../components/ActivityIndicator';
import { Modal } from 'react-native';
import ImageViewer from 'react-native-image-zoom-viewer';
import ImageFooter from '../../../components/ImageViewerFooter';
import ImageHeader from '../../../components/ImageViewerHeader';
import { Text } from '../../../components/StyledText';
import { colors } from '../../../styles';
import Config from '../../utils/config';
import {
  is360Image,
  isImageMedia,
  isVideoMedia,
  is360Video,
} from '../../utils/media';

import Routes from '../../navigation/routes';

const THUMBNAIL_CONTAINER = Config.get('azureBlobThumbnailContainer');
const numberOfColumns = Platform.isPad ? 4 : 3;

export default ({ media, navigation, isLoading }) => {
  const { colors } = useTheme();

  const mediaItem = ({ item: mediaCard, index }) => (
    <View key={`${mediaCard.mediaId} parent`} style={styles.imagesRow}>
      {isVideoMedia(mediaCard.mediaType) && (
        <View
          key={`${mediaCard.mediaId} video view`}
          style={{
            flex: 1,
            padding: 5,
            elevation: 5,
            backgroundColor: colors.surface,
          }}
        >
          <ImageBackground
            style={styles.video}
            source={{
              uri: THUMBNAIL_CONTAINER + mediaCard.mediaId + '.png',
            }}
            defaultSource={require('../../../../assets/images/placeholder-media.jpg')}
          >
            <IconButton
              icon="play-circle"
              color={colors.surface}
              size={40}
              style={styles.overlayButton}
              onPress={() => {
                if (is360Video(mediaCard.mediaType))
                  navigation.navigate('Panorama Video Player', 123);
                else {
                  let videoId = mediaCard.videoSource
                    ? {
                        vimeoId: mediaCard.videoSource.vimeoId,
                        title: mediaCard.mediaName,
                      }
                    : {
                        deviceId: mediaCard.deviceId,
                        title: mediaCard.mediaName,
                      };
                  navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
                    screen: 'Media Video Player',
                    params: videoId,
                  });
                }
              }}
            />
            <Text style={styles.mediaText} size={12} bold white>
              {format(new Date(mediaCard.fileDate), 'dd LLL yy HH:mm')}
            </Text>
          </ImageBackground>
          <IconButton
            icon="message-text"
            size={18}
            onPress={() =>
              navigation.navigate('Media Discussion', {
                requestedId: mediaCard.mediaId,
              })
            }
          />
        </View>
      )}
      {isImageMedia(mediaCard.mediaType) && (
        <View
          style={{
            flex: 1,
            padding: 5,
            elevation: 5,
            backgroundColor: colors.surface,
          }}
        >
          <TouchableOpacity
            key={`${mediaCard.mediaId} image view`}
            onPress={() => {
              is360Image(mediaCard.mediaType)
                ? navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
                    screen: 'Panorama player',
                    params: {
                      blobContentId: mediaCard.blobContentId,
                      title: mediaCard.mediaName,
                    },
                  })
                : onImageSelect(index);
            }}
          >
            <ImageBackground
              style={styles.image}
              source={{
                uri: THUMBNAIL_CONTAINER + mediaCard.blobContentId,
              }}
              defaultSource={require('../../../../assets/images/placeholder-media.jpg')}
            >
              <Text style={styles.mediaText} size={12} white bold>
                {isMatch(mediaCard.fileDate, 'yyyy:MM:dd HH:mm:ss')
                  ? format(
                      parse(
                        mediaCard.fileDate,
                        'yyyy:MM:dd HH:mm:ss',
                        new Date(),
                      ),
                      'dd LLL yy HH:mm',
                    )
                  : format(new Date(mediaCard.fileDate), 'dd LLLL MM')}
              </Text>
            </ImageBackground>
          </TouchableOpacity>
          <IconButton
            icon="message-text"
            size={18}
            onPress={() =>
              navigation.navigate('Media Discussion', {
                requestedId: mediaCard.mediaId,
              })
            }
          />
        </View>
      )}
    </View>
  );

  const [currentImageIndex, setImageIndex] = useState(0);
  const [isImageViewerVisible, setImageViewerVisible] = useState(false);

  const onImageSelect = index => {
    setImageIndex(index);
    setImageViewerVisible(true);
  };

  const getImageUrls = memoize(() => {
    return media.map(mediaObject => ({
      url: THUMBNAIL_CONTAINER + mediaObject.blobContentId,
    }));
  });

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ActivityIndicator visible={isLoading} />
      <FlatList
        keyExtractor={item => item.mediaId}
        data={media}
        numColumns={numberOfColumns}
        renderItem={mediaItem}
        ItemSeparatorComponent={() => <Divider />}
      />
      <Modal
        visible={isImageViewerVisible}
        onRequestClose={() => setImageViewerVisible(false)}
      >
        <ImageViewer
          imageUrls={getImageUrls()}
          index={currentImageIndex}
          onSwipeDown={() => setImageViewerVisible(false)}
          enableSwipeDown
          saveToLocalByLongPress={false}
          enablePreload
          loadingRender={() => <ActivityIndicator visible={true} />}
          renderHeader={currentIndex => {
            return (
              <ImageHeader
                onRequestClose={() => {
                  setImageViewerVisible(false);
                }}
              />
            );
          }}
        />
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cardTitleStyle: {
    marginVertical: 6,
  },
  noMedia: {
    flex: 1,
    textAlign: 'center',
  },
  imagesRow: {
    flex: 1 / numberOfColumns,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  mediaText: {
    marginBottom: 10,
    padding: 1,
    textAlign: 'center',
    backgroundColor: colors.primary,
  },
  video: {
    flex: 1,
    height: Platform.isPad ? 200 : 130,
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    flex: 1,
    height: Platform.isPad ? 200 : 130,
    borderRadius: 5,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  overlayButton: {
    alignSelf: 'center',
  },
});
