// @flow
import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';
import AlbumView from './AlbumView';
import { getProjectAlbums } from './AlbumState';

export default compose(
  connect(
    ({ projects, projectAlbums }) => ({
      selectedProjectId: projects.projectId,
      albums: projectAlbums.album,
      isLoading: projectAlbums.isLoading,
    }),
    dispatch => ({
      getProjectAlbums: projectId => dispatch(getProjectAlbums(projectId)),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const { getProjectAlbums, selectedProjectId } = this.props;

      getProjectAlbums(selectedProjectId);
    },
  }),
)(AlbumView);
