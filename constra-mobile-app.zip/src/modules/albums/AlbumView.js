import format from 'date-fns/format';
import React, { useState } from 'react';
import {
  FlatList,
  ImageBackground,
  Platform,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  TouchableHighlight,
  View,
} from 'react-native';
import { Snackbar, Surface, useTheme } from 'react-native-paper';
import ActivityIndicator from '../../components/ActivityIndicator';
import { Text } from '../../components/StyledText';
import { colors } from '../../styles';
import Config from '../utils/config';

const THUMBNAIL_CONTAINER = Config.get('azureBlobThumbnailContainer');
const numberOfColumns = Platform.isPad ? 3 : 2;

export default ({
  isLoading,
  albums,
  navigation,
  getProjectAlbums,
  selectedProjectId,
}) => {
  // Snackbar
  const [snackBarVisibility, setSnackBarVisible] = useState(false);
  const onDismissSnackBar = () => setSnackBarVisible(false);
  const snackBarVisibilityDuration = 3000;

  const { colors } = useTheme();

  const album = ({ item: album }) => (
    <TouchableHighlight
      activeOpacity={0.6}
      underlayColor="#DDDDDD"
      style={styles.cardContainer}
      onPress={() => {
        if (album.media.length > 0)
          navigation.navigate('Media', {
            albumId: album.albumId,
            albumName: album.albumName,
          });
        else setSnackBarVisible(true);
      }}
    >
      <Surface style={styles.surface}>
        <ImageBackground
          style={styles.image}
          source={{
            uri:
              THUMBNAIL_CONTAINER +
              `${album.media.length > 0 ? album.media[0].blobContentId : ''}`,
          }}
          defaultSource={require('../../../assets/images/placeholder-media.jpg')}
        />
        <View style={styles.metadataContainer}>
          <Text
            size={14}
            bold
            style={{ marginVertical: 6, color: colors.onSurface }}
          >
            {album.albumName}
          </Text>
          <Text size={10} style={{ color: colors.onSurface }}>
            {format(new Date(album.albumDate), 'LLL dd yyyy')}
          </Text>
        </View>
      </Surface>
    </TouchableHighlight>
  );

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ActivityIndicator visible={isLoading} />
      <FlatList
        numColumns={numberOfColumns}
        keyExtractor={item => item._id}
        data={albums}
        renderItem={album}
        style={{ paddingHorizontal: 5 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={() => getProjectAlbums(selectedProjectId)}
          />
        }
      />
      {albums.length == 0 && !isLoading && (
        <Text
          style={{ flex: 1, textAlign: 'center', color: colors.onSurface }}
          size={24}
        >
          No media found
        </Text>
      )}
      <Snackbar
        visible={snackBarVisibility}
        onDismiss={onDismissSnackBar}
        duration={snackBarVisibilityDuration}
      >
        No media available in the selected album
      </Snackbar>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  cardContainer: {
    width: `${100 / numberOfColumns}%`,
    margin: 5,
  },
  metadataContainer: {
    padding: 8,
  },
  image: {
    flex: 1,
    height: Platform.isPad ? 250 : 150,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomColor: colors.primary,
    borderBottomWidth: 0.2,
  },
  surface: {
    flex: 1,
    elevation: 3,
  },
});
