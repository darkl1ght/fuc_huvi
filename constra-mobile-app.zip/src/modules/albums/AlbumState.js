// @flow

export const initialState = {
  album: [],
  isLoading: false,
  isErrorInApiLoading: false,
};

export const FETCH_ALBUMS_STARTED = 'MediaState/FETCH_ALBUMS_STARTED';

export const FETCH_ALBUMS_COMPLETED = 'MediaState/FETCH_ALBUMS_COMPLETED';

export const FETCH_ALBUMS_ERROR = 'MediaState/FETCH_ALBUMS_ERROR';

export function fetchAlbumsStarted() {
  return {
    type: FETCH_ALBUMS_STARTED,
  };
}
export function getProjectAlbums(projectId) {
  return dispatch => {
    dispatch(fetchAlbumsStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/projectmedia/${projectId}/album/`,
        onSuccess: FETCH_ALBUMS_COMPLETED,
        onError: FETCH_ALBUMS_ERROR,
      },
    });
  };
}

export default function MediaStateReducer(state = initialState, action) {
  switch (action.type) {
    case FETCH_ALBUMS_STARTED:
      return {
        ...state,
        isLoading: true,
      };
    case FETCH_ALBUMS_COMPLETED:
      return {
        ...state,
        isLoading: false,
        album: action.payload.album,
      };
    case FETCH_ALBUMS_ERROR:
      return {
        ...state,
        isLoading: false,
        isErrorInApiLoading: true,
      };
    default:
      return state;
  }
}
