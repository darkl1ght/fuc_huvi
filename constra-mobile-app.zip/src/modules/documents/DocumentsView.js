import { parseISO } from 'date-fns/esm';
import format from 'date-fns/format';
import React, { useState } from 'react';
import {
  Alert,
  Dimensions,
  FlatList,
  Image,
  PermissionsAndroid,
  Platform,
  SafeAreaView,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import FileViewer from 'react-native-file-viewer';
import {
  DocumentDirectoryPath,
  downloadFile,
  ExternalDirectoryPath,
} from 'react-native-fs';
import Modal from 'react-native-modal';
import {
  Divider,
  IconButton,
  List,
  Snackbar,
  useTheme,
} from 'react-native-paper';
import ActivityIndicator from '../../components/ActivityIndicator';
import { Text } from '../../components/StyledText';
import { fonts } from '../../styles';
import getPermissions from '../utils/androidPermissions';
import Config from '../utils/config';

const AZURE_DOCUMENTS_CONTAINER_URL = Config.get('azureDocumentsContainer');
const numberOfColumns = Platform.isPad ? 4 : 3;

const SNACKBAR_VISIBILITY_DURATION = 3000;

export default props => {
  const { colors } = useTheme();
  // Snackbar notification messages
  const [snackBarVisibility, setSnackBarVisible] = useState(false);
  const [snackBarMessage, setSnackBarMessage] = useState('');
  const onDismissSnackBar = () => setSnackBarVisible(false);

  //Download progress
  const [fileDownloadProgress, setFileDownloadProgress] = useState('');
  const [isDownloadingFile, setDownloadingFile] = useState(false);

  //Modal - History
  const [isModalVisible, setModalVisible] = useState(false);
  const [documentHistory, setDocumentHistory] = useState([]);

  const renderItemHistory = ({ item: document }) => (
    <List.Item
      titleNumberOfLines={2}
      key={document.blobDocId}
      title={document.name}
      description={`${format(new Date(document.updatedAt), 'LLL dd yyyy')}`}
      right={props => (
        <IconButton
          icon="cloud-download"
          size={30}
          onPress={() => {
            setModalVisible(false);
            createTwoButtonAlert(document);
          }}
        />
      )}
      style={{
        elevation: 6,
      }}
    />
  );

  const createTwoButtonAlert = document =>
    Alert.alert(
      'Download File and preview ?',
      'This will download the file and open the preview',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        { text: 'OK', onPress: () => requestPermissionsAndDownload(document) },
      ],
    );

  const renderModalHistoryContent = history => {
    return (
      <FlatList
        keyExtractor={item => item._id}
        data={history}
        renderItem={renderItemHistory}
      />
    );
  };

  const renderItem = ({ item: document }) => {
    return (
      <TouchableOpacity
        key={document._id}
        onPress={() => createTwoButtonAlert(document)}
        style={{
          flex: 1 / numberOfColumns,
          padding: 5,
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <Image
          style={styles.itemOneImage}
          resizeMode="contain"
          source={getFileTypeImageUrl(document.name.split('.')[1])}
        />
        <Text style={[styles.itemOneTitle, { color: colors.onSurface }]}>
          {document.name}
        </Text>
        <Text style={[styles.itemOneSubTitle]}>
          {format(parseISO(document.createdAt), 'LLL dd yyyy')}
        </Text>
        <Text
          style={[styles.documentSize, { color: colors.primary }]}
          numberOfLines={1}
        >
          {document.size}
        </Text>
        {document.history.length > 0 && (
          <IconButton
            icon="history"
            size={20}
            onPress={() => {
              setModalVisible(true);
              setDocumentHistory(document.history);
            }}
          />
        )}
      </TouchableOpacity>
    );
  };

  const getBlobUrl = documentBlobId => {
    return `${AZURE_DOCUMENTS_CONTAINER_URL}${documentBlobId}?${props.azureDocumentsToken}`;
  };

  const requestPermissionsAndDownload = async ({ name, blobDocId }) => {
    let granted =
      Platform.OS === 'android'
        ? await getPermissions(
            [
              PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
              PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
            ],
            'Huviair constra storage permission',
            'Constra needs permissions to store your documents',
          )
        : true;

    if (granted) {
      //Start the activity loader
      setDownloadingFile(true);

      // ON ios - DocumentDirectoryPath, on Android - Downloads
      let downloadFilePath = `${
        Platform.OS === 'android'
          ? ExternalDirectoryPath
          : DocumentDirectoryPath
      }/${name}`;

      const download = downloadFile({
        fromUrl: getBlobUrl(blobDocId),
        toFile: downloadFilePath,
        begin: res => {},
        progress: res => {
          setFileDownloadProgress(
            `Downloading ${Math.round(
              (100 * res.bytesWritten) / res.contentLength,
            )}%`,
          );
        },
        progressDivider: 10,
      });

      download.promise
        .then(data => {
          setDownloadingFile(false);
          setFileDownloadProgress('');

          FileViewer.open(downloadFilePath, {
            showOpenWithDialog: true,
            showAppsSuggestions: true,
          })
            .then(() => {
              /*do nothing*/
            })
            .catch(error => {
              setSnackBarMessage('No supported app exists to open this file');
              setSnackBarVisible(true);
            });
        })
        .catch(error => {
          setDownloadingFile(false);
          setFileDownloadProgress('');
          setSnackBarMessage(
            'Error in downloading the requsted document, please try again',
          );
          setSnackBarVisible(true);
        });
    } else {
      setSnackBarMessage('Please provide storage permissions');
      setSnackBarVisible(true);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ActivityIndicator
        visible={props.isLoading || isDownloadingFile}
        overlayText={fileDownloadProgress}
      />
      {props.documents.length > 0 && !props.isLoading && (
        <FlatList
          keyExtractor={item => item._id}
          style={{
            paddingHorizontal: 15,
          }}
          numColumns={numberOfColumns}
          data={props.documents}
          renderItem={renderItem}
        />
      )}

      {props.documents.length == 0 && !props.isLoading && (
        <View
          style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
        >
          <Text
            style={[styles.noDocuments, { color: colors.onSurface }]}
            size={24}
          >
            No documents found.
          </Text>
        </View>
      )}

      <Snackbar
        visible={snackBarVisibility}
        onDismiss={onDismissSnackBar}
        duration={SNACKBAR_VISIBILITY_DURATION}
      >
        {snackBarMessage}
      </Snackbar>

      <Modal
        isVisible={isModalVisible}
        style={[styles.modalStyle, { backgroundColor: colors.surface }]}
        onBackdropPress={() => setModalVisible(false)}
      >
        <View style={{ padding: 10, flexDirection: 'row' }}>
          <Text size={25} underline style={{ color: colors.onSurface }}>
            Document History
          </Text>
          <TouchableOpacity onPress={() => setModalVisible(false)}>
            <Text
              size={20}
              style={{
                alignSelf: 'flex-end',
                marginLeft: 10,
                color: colors.onSurface,
              }}
            >
              X
            </Text>
          </TouchableOpacity>
        </View>
        <Divider />
        {renderModalHistoryContent(documentHistory)}
      </Modal>
    </SafeAreaView>
  );
};

const getFileTypeImageUrl = extension => {
  let imageUrl;
  switch (extension) {
    case ('docx', 'doc'):
      imageUrl = require('../../../assets/images/file-types/word.png');
      break;
    case 'pdf':
      imageUrl = require('../../../assets/images/file-types/pdficon.png');
      break;
    case ('xls', 'xlsx'):
      imageUrl = require('../../../assets/images/file-types/excel.png');
      break;
    case 'dwg':
      imageUrl = require('../../../assets/images/file-types/dwgfile.png');
      break;
    default:
      imageUrl = require('../../../assets/images/file-types/OtherFile.png');
      break;
  }
  return imageUrl;
};

const styles = StyleSheet.create({
  tabsContainer: {
    alignSelf: 'stretch',
    marginTop: 30,
  },
  itemOneContainer: {
    flex: 1,
    width: Dimensions.get('window').width / 2 - 40,
  },
  itemOneImageContainer: {
    textAlign: 'center',
    justifyContent: 'center',
    borderRadius: 3,
    overflow: 'hidden',
  },
  itemOneImage: {
    height: 100,
    width: Dimensions.get('window').width / 2 - 40,
    marginVertical: 5,
  },
  noDocuments: {
    textAlign: 'center',
  },
  itemOneTitle: {
    fontFamily: fonts.primaryRegular,
    fontSize: 15,
    alignSelf: 'center',
    textAlign: 'center',
  },
  itemOneSubTitle: {
    fontFamily: fonts.primaryRegular,
    fontSize: 13,
    color: '#B2B2B2',
    marginVertical: 3,
    alignSelf: 'center',
  },
  documentSize: {
    fontFamily: fonts.primaryRegular,
    fontSize: 15,
    alignSelf: 'center',
  },
  itemOneRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
  },
  itemOneContent: {
    marginTop: 5,
    marginBottom: 10,
  },
  modalStyle: {
    maxHeight: 400,
    marginTop: 60,
    padding: 10,
    justifyContent: 'flex-end',
  },
  modalHeaderCloseText: {
    textAlign: 'center',
    paddingLeft: 5,
    paddingRight: 5,
  },
});
