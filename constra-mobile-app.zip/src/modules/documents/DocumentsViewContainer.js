// @flow
import { compose } from 'recompose';
import { connect } from 'react-redux';

import DocumentsView from './DocumentsView';
import { fetchAllDocuments, fetchAzureDocumentsToken } from './DocumentsState';
import lifecycle from 'recompose/lifecycle';

export default compose(
  connect(
    ({ projects, documents }) => ({
      isLoading: documents.isLoading,
      selectedProjectId: projects.projectId,
      documents: documents.documents,
      azureDocumentsToken: documents.azureDocumentsToken,
    }),
    dispatch => ({
      fetchAllDocuments: projectId => dispatch(fetchAllDocuments(projectId)),
      fetchAzureDocumentsToken: () => dispatch(fetchAzureDocumentsToken()),
    }),
  ),
  lifecycle({
    componentDidMount() {
      const {
        selectedProjectId,
        fetchAllDocuments,
        fetchAzureDocumentsToken,
      } = this.props;
      fetchAllDocuments(selectedProjectId);
      fetchAzureDocumentsToken();
    },
  }),
)(DocumentsView);
