// @flow

export const initialState = {
  isLoading: false,
  iErrorInLoading: false,
  documents: [],
  azureDocumentsToken: '',
};

const DOCUMENTS_START_LOADING = 'DocumentsState/FETCHING_DOCUMENTS_STARTED';
const DOCUMENTS_LOADING_COMPLETED =
  'DocumentsState/FETCHING_DOCUMENTS_COMPLETED';
const DOCUMENTS_ERROR = 'DocumentsState/ERROR_IN_FETCHING_DOCUMENTS';

const DOCUMENTS_TOKEN_START_LOADING =
  'DocumentsState/FETCHING_AZURE_TOKEN_STARTED';
const DOCUMENTS_TOKEN_COMPLETED =
  'DocumentsState/FETCHING_AZURE_TOKEN_COMPLETED';
const DOCUMENTS_TOKEN_ERROR = 'DocumentsState/ERROR_IN_FETCHING_TOKEN';

function loadingDocumentsStarted() {
  return { type: DOCUMENTS_START_LOADING };
}

function loadingDocumentsTokenStarted() {
  return { type: DOCUMENTS_TOKEN_START_LOADING };
}

export function fetchAllDocuments(projectId) {
  return dispatch => {
    dispatch(loadingDocumentsStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/${projectId}/documents`,
        onSuccess: DOCUMENTS_LOADING_COMPLETED,
        onError: DOCUMENTS_ERROR,
      },
    });
  };
}

export function fetchAzureDocumentsToken() {
  return dispatch => {
    dispatch(loadingDocumentsTokenStarted());

    dispatch({
      isProjectApi: true,
      type: 'apiCallBegan',
      payload: {
        url: `/azureblob/sas/read/documents/`,
        onSuccess: DOCUMENTS_TOKEN_COMPLETED,
        onError: DOCUMENTS_TOKEN_ERROR,
      },
    });
  };
}

export default function DocumentsStateReducer(state = initialState, action) {
  switch (action.type) {
    case DOCUMENTS_START_LOADING:
      return {
        ...state,
        isLoading: true,
      };
    case DOCUMENTS_LOADING_COMPLETED:
      return {
        ...state,
        isLoading: false,
        documents: action.payload.documents,
      };

    case DOCUMENTS_ERROR:
      return {
        ...state,
        isLoading: false,
        isErrorInLoading: true,
      };
    case DOCUMENTS_TOKEN_START_LOADING:
      return {
        ...state,
        isLoading: true,
      };
    case DOCUMENTS_TOKEN_COMPLETED:
      return {
        ...state,
        isLoading: false,
        azureDocumentsToken: action.payload.sasToken.token,
      };

    case DOCUMENTS_TOKEN_ERROR:
      return {
        ...state,
        isLoading: false,
        isErrorInLoading: true,
      };

    default:
      return state;
  }
}
