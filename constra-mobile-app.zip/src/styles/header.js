import { colors, fonts } from '../styles';

const headerStyleSide = {
  headerStyle: {
    // backgroundColor: '#2d4059',
  },
  headerTitleStyle: {
    fontFamily: fonts.primaryRegular,
    color: colors.white,
    fontSize: 18,
  },
  headerBackTitleVisible: false,
  headerTitleAllowFontScaling: true,
};

export default { headerStyleSide: headerStyleSide };
