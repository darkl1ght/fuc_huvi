import { DefaultTheme, DarkTheme, configureFonts } from 'react-native-paper';
import colors from './colors';
import fontConfig from './fontConfig';
export default Object.freeze({
  lightTheme: {
    ...DefaultTheme,
    roundness: 2,
    fonts: configureFonts(fontConfig),
    colors: {
      ...DefaultTheme.colors,
      primary: colors.primary,
      accent: '#f1c40f',
      welcomeScreenButton: colors.darkerWhite,
      background: colors.white,
      card: colors.white,
      border: 'rgb(216, 216, 216)',
      client: {
        title: '#5F5F5F',
        divider: '#e3e3e3',
        subTitle: '#617ae1',
        metaData: '#5f5f5f',
      },
      projects: {
        title: '#5F5F5F',
        divider: '#e3e3e3',
        subTitle: '#617ae1',
        badge: colors.primary,
      },
      team: { badge: colors.primary, title: '#5F5F5F', divider: '#e3e3e3' },
      navigationBarColor: colors.primary,
      statusBarColor: colors.primary,
    },
  },
  darkTheme: {
    ...DarkTheme,
    roundness: 2,
    fonts: configureFonts(fontConfig),
    colors: {
      ...DarkTheme.colors,
      welcomeScreenButton: colors.darkerWhite,
      primary: colors.blue,
      client: {
        title: '#BBE1FA',
        divider: DarkTheme.colors.surface,
        subTitle: DarkTheme.colors.primary,
        metaData: '#EDEDED',
      },
      projects: {
        title: '#BBE1FA',
        divider: DarkTheme.colors.surface,
        subTitle: DarkTheme.colors.primary,
        badge: '#EDEDED',
      },
      team: { badge: '#EDEDED', title: '#BBE1FA' },
      navigationBarColor: '#141d26',
      statusBarColor: '#141d26',
    },
  },
});
