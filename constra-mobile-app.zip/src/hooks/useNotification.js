import React, { useEffect, useState } from 'react';
import notifee from '@notifee/react-native';
import navigation from '../modules/navigation/NavigationRef';
import Routes from '../modules/navigation/routes';
import Config from '../modules/utils/config';
import { useDispatch } from 'react-redux';
import { saveProject } from '../modules/projects/ProjectsState';
import { marknotificationRead } from '../modules/notifications/NotificationsState';

export default () => {
  const dispatch = useDispatch();

  const [loading, setLoading] = useState(true);

  const markNotificationAsRead = messageId =>
    dispatch(marknotificationRead(messageId));

  async function bootstrap() {
    const initialNotification = await notifee.getInitialNotification();

    if (initialNotification) {
      const { data: notification } = initialNotification.notification;

      switch (notification.actionType) {
        case Config.get('INTERIOR_TOUR'):
          markNotificationAsRead(notification.messageId);
          navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
            screen: Routes.WALKTHROUGH_VIRTUAL_TOUR,
            params: {
              ...notification,
              isPushNotification: true,
            },
          });
          break;
        case Config.get('MEDIA_UPLOADED'):
          markNotificationAsRead(notification.messageId);
          dispatch(saveProject(notification.projectId));

          navigation.navigate('Project Details', {
            screen: 'Media Navigator',
            params: {
              screen: 'Media',
              params: {
                ...notification,
                isPushNotification: true,
              },
            },
          });
          break;

        case Config.get('AERIAL_TOUR_PUBLISHED'):
          markNotificationAsRead(notification.messageId);
          navigation.navigate(Routes.BOTTOM_TAB_DISABLED_NAVIGATOR, {
            screen: 'Map',
            params: {
              ...notification,
              isPushNotification: true,
            },
          });
          break;
        default:
          break;
      }
    }
  }

  useEffect(() => {
    bootstrap()
      .then(() => setLoading(false))
      .catch(error => console.log(error));
  }, []);

  if (loading) {
    return null;
  }
};
