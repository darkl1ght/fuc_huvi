import { combineReducers } from 'redux';

import media from '../modules/albums/media/MediaState';
import team from '../modules/team/TeamState';
import projectAlbums from '../modules/albums/AlbumState';
import resetPassword from '../modules/settings/resetPassword/ResetPasswordState';
import documents from '../modules/documents/DocumentsState';
import livestream from '../modules/livestream/LivestreamState';
import walkthroughvirtualtour from '../modules/interiors/walkthroughvirtualtour/WalkthroughvirtualtourState';
import interiorWalkthrough from '../modules/interiors/interiorwalkthroughlist/InteriorWalkthroughState';
import interiors from '../modules/interiors/InteriorsState';
import panoramaViewer from '../modules/interiors/panoramaViewer/PanoramaViewerState';
import map from '../modules/map/MapState';
import profile from '../modules/profile/ProfileState';
import aerial from '../modules/aerial/AerialState';
import projects from '../modules/projects/ProjectsState';
import clients from '../modules/clients/ClientsState';
import login from '../modules/login/LoginState';
import app from '../modules/AppState';
import AsyncStorage from '@react-native-async-storage/async-storage';
import discussion from '../modules/discussion/DiscussionState';
import notification from '../modules/notifications/NotificationsState';
import forgotPassword from '../modules/forgotPassword/ForgotPasswordState';
import bimViewer from '../modules/interiors/bimViewer/BimViewerState';
const appReducer = combineReducers({
  // ## Generator Reducers
  bimViewer,
  forgotPassword,
  notification,
  discussion,
  media,
  team,
  projectAlbums,
  resetPassword,
  documents,
  livestream,
  walkthroughvirtualtour,
  interiorWalkthrough,
  interiors,
  panoramaViewer,
  map,
  profile,
  aerial,
  projects,
  clients,
  login,
  app,
});

const rootReducer = (state, action) => {
  // when a logout action is dispatched it will reset redux state
  if (action.type === 'USER_LOGGED_OUT') {
    // Delete existing data from storage
    AsyncStorage.removeItem('root');

    // cut the current reference to in-memory store
    state = undefined;
  }

  return appReducer(state, action);
};

export default rootReducer;
