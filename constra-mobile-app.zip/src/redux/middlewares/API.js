import axios from 'axios';
import config from '../../modules/utils/config';

const PROJECT_API = config.get('projectAPI');
const SECURITY_API = config.get('securityAPI');

const api = store => next => async action => {
  if (action.type !== 'apiCallBegan') return next(action);

  const { url, method, data, onSuccess, onError } = action.payload;

  // Fetch token from the store and populate header
  const { login } = store.getState();
  const Authorization = 'Token ' + (login.user ? login.user.token : '');

  try {
    const response = await axios.request({
      baseURL: action.isProjectApi ? PROJECT_API : SECURITY_API,
      url,
      method,
      data,
      headers: {
        Authorization,
      },
      timeout: 10000,
    });

    store.dispatch({
      type: onSuccess,
      payload: response.data,
    });
  } catch (error) {
    store.dispatch({
      type: onError,
      payload: error,
    });
  }
};

export default api;
