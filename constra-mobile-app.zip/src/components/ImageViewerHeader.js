import React from 'react';
import { StyleSheet, SafeAreaView, View } from 'react-native';
import { Button } from 'react-native-paper';

const ImageHeader = ({ onRequestClose }) => (
  <SafeAreaView style={styles.root}>
    <Button
      style={styles.closeButton}
      color={'#FFFFFF'}
      mode="outlined"
      icon="close"
      vb
      compact
      accessibilityLabel="Show all"
      onPress={onRequestClose}
    />
  </SafeAreaView>
);

const styles = StyleSheet.create({
  root: {
    backgroundColor: '#00000077',
    zIndex: 1000000,
    position: 'absolute',
    right: 0,
  },

  closeButton: {
    flexDirection: 'row-reverse',
    width: 40,
    height: 40,
  },

  text: {
    textAlign: 'center',
    fontSize: 17,
    lineHeight: 17,
    color: '#FFF',
  },
});

export default ImageHeader;
