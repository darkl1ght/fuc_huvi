import React from 'react';
import { View, StyleSheet } from 'react-native';
import LottieView from 'lottie-react-native';
import { Text } from './StyledText';
import { useTheme } from 'react-native-paper';

function ActivityIndicator({ visible = false, overlayText = '', style }) {
  if (!visible) return null;

  const { colors, dark } = useTheme();

  return (
    <View style={[styles.overlay, { backgroundColor: colors.surface }, style]}>
      <LottieView
        autoPlay
        loop
        source={
          dark
            ? require('../../assets/animations/data-dark.json')
            : require('../../assets/animations/data.json')
        }
        style={{ width: 150, height: 150 }}
      />
      <Text size={15} style={{ color: colors.onSurface }}>
        {overlayText}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    height: '100%',
    opacity: 0.75,
    width: '100%',
    zIndex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default ActivityIndicator;
