/* eslint-disable no-undef */
import React from 'react';
import { shallow } from 'enzyme';

import {
  VideoPlayer,
} from '../index';

describe('VideoPlayer Component', () => {
  it('renders as expected', () => {
  const wrapper = shallow(
    <VideoPlayer />,
  );
  expect(wrapper).toMatchSnapshot();
});
