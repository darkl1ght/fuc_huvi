/* eslint-disable no-undef */
import React from 'react';
import { shallow } from 'enzyme';

import {
  Chart,
} from '../index';

describe('Chart Component', () => {
  it('renders as expected', () => {
  const wrapper = shallow(
    <Chart />,
  );
  expect(wrapper).toMatchSnapshot();
});
