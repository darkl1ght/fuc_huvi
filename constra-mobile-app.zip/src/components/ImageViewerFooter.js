import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ImageFooter = ({ title }) => (
  <View style={styles.root}>
    {title && <Text style={styles.text}>{title}</Text>}
  </View>
);

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  text: {
    fontSize: 17,
    color: '#FFF',
  },
});

export default ImageFooter;
