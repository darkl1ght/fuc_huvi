import { useNetInfo } from '@react-native-community/netinfo';
import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import { Banner } from 'react-native-paper';
import { Text } from '../components/StyledText';
import colors from '../styles/colors';

function AppOffline(props) {
  const netInfo = useNetInfo();

  if (netInfo.type !== 'unknown' && netInfo.isInternetReachable === false)
    return (
      <SafeAreaView style={styles.container}>
        <Banner visible={true} actions={[]} style={styles.container}>
          <Text style={styles.text} bold>
            You are offline !
          </Text>
        </Banner>
      </SafeAreaView>
    );

  return null;
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.red,
  },
  text: {
    color: colors.darkerWhite,
    textAlign: 'center',
  },
});

export default AppOffline;
