import React, { useEffect } from 'react';
import { Platform } from 'react-native';
import { Banner, useTheme } from 'react-native-paper';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import SpInAppUpdates, {
  IAUUpdateKind,
  IAUAvailabilityStatus,
  IAUInstallStatus,
} from 'sp-react-native-in-app-updates';
import { colors } from '../styles';

const HIGH_PRIORITY_UPDATE = 5;
export default () => {
  const [visible, setVisible] = React.useState(false);

  const theme = useTheme();

  const inAppUpdates = new SpInAppUpdates(
    false, // isDebug
  );
  const listener = ({ status }) => {
    if (status === IAUInstallStatus.DOWNLOADED) {
      setVisible(true);
    }
  };

  useEffect(() => {
    inAppUpdates.addStatusUpdateListener(listener);

    inAppUpdates.checkNeedsUpdate().then(result => {
      if (
        result.shouldUpdate ||
        IAUAvailabilityStatus.DEVELOPER_TRIGGERED ===
          result.other?.updateAvailability
      ) {
        let updateOptions = {};
        if (Platform.OS === 'android') {
          updateOptions = {
            updateType:
              HIGH_PRIORITY_UPDATE === result.other?.updatePriority
                ? IAUUpdateKind.IMMEDIATE
                : IAUUpdateKind.FLEXIBLE,
          };
        }

        inAppUpdates.startUpdate(updateOptions);
      }
    });

    return function cleanup() {
      inAppUpdates.removeStatusUpdateListener(listener);
    };
  }, []);

  return (
    <Banner
      visible={visible}
      actions={[
        {
          label: 'Install',
          onPress: () => {
            inAppUpdates.installUpdate();
            setVisible(false);
          },
        },
        {
          label: 'Install later',
          onPress: () => setVisible(false),
        },
      ]}
      icon={({ size }) => (
        <MaterialCommunityIcons
          name="download"
          size={size}
          style={{
            width: size,
            height: size,
          }}
          color={theme.dark ? colors.white : colors.primary}
        />
      )}
    >
      An app update downloaded successfully, and is available for installation
    </Banner>
  );
};
