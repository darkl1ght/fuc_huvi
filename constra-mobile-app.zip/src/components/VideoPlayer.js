import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import VideoPlayerWithcontrols from 'react-native-video-controls';
import { Text } from './StyledText';

export default ({ uri, onBackPressed, title }) => {
  const [isErrorInPlaying, setError] = useState(false);

  return (
    <View style={styles.container}>
      <VideoPlayerWithcontrols
        source={{ uri }} // Can be a URL or a local file.
        onBack={onBackPressed}
        controlAnimationTiming={1000}
        title={title}
        onError={() => setError(true)}
      />
      {isErrorInPlaying && (
        <Text size={14} style={styles.errorText} white bold>
          Couldn't play the video, please try again or contact Huviair Support
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignContent: 'center',
    justifyContent: 'center',
    backgroundColor: 'black',
    flex: 1,
  },
  errorText: {
    textAlign: 'center',
    position: 'absolute',
    alignSelf: 'center',
    textAlignVertical: 'center',
    paddingTop: 50,
  },
});
