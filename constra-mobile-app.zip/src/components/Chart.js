// @flow
import React from 'react';
import { StyleSheet, SafeAreaView } from 'react-native';
import WebView from 'react-native-webview';
const populateChartHtml = config => {
  let chartConfig = JSON.stringify(config);
  return `
        <html>
        <head>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        </head>
        <body>
        <div>
          <canvas id="myChart"></canvas>
        </div>
        <script>

          var myChart = new Chart(
            document.getElementById('myChart'),
            ${chartConfig}
          );
        </script>
        </body>
        </html>

`;
};
export default ({ type, labels, datasets, title }) => {
  let data = {
    labels,
    datasets,
  };
  const config = {
    type,
    data,
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: title,
          font: {
            size: 20,
          },
        },
      },
    },
  };
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <WebView
        source={{ html: populateChartHtml(config) }}
        style={styles.chart}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  chart: {
    minHeight: 450,
    marginTop: 15,
    marginEnd: 5,
    marginStart: 5,
  },
});
