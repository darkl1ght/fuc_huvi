import { NavigationContainer } from '@react-navigation/native';
import React from 'react';
import {
  ActivityIndicator,
  StatusBar,
  StyleSheet,
  useColorScheme,
  View,
} from 'react-native';
import RNBootSplash from 'react-native-bootsplash';
import { Provider as PaperProvider } from 'react-native-paper';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import AppOffline from './src/components/AppOffline';
import AppUpdate from './src/components/AppUpdate';
import AppView from './src/modules/AppViewContainer';
import { navigationRef } from './src/modules/navigation/NavigationRef';
import { persistor, store } from './src/redux/store';
import { SelectProvider } from '@mobile-reality/react-native-select-pro';
import { colors } from './src/styles';
import Themes from './src/styles/devicethemes';

export default function App() {
  const colorScheme = useColorScheme();

  const appTheme =
    colorScheme === 'dark' ? Themes.darkTheme : Themes.lightTheme;

  return (
    <Provider store={store}>
      <NavigationContainer
        onReady={() => RNBootSplash.hide({ fade: true })}
        theme={appTheme}
        ref={navigationRef}
      >
        <PersistGate
          loading={
            <View style={styles.container}>
              <ActivityIndicator color={colors.primary} />
            </View>
          }
          persistor={persistor}
        >
          <PaperProvider theme={appTheme}>
            <SelectProvider>
              <AppUpdate />
              <AppOffline />
              <StatusBar
                barStyle="light-content"
                backgroundColor={appTheme.colors.statusBarColor}
              />
              <AppView />
            </SelectProvider>
          </PaperProvider>
        </PersistGate>
      </NavigationContainer>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
});
