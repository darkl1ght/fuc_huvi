# Huviair Constra Mobile App 

One stop destination for visualization of CONSTRA web data on your device. Check out live demo on [App Store](https://play.google.com/store/apps/details?id=com.huviair.constra)

![React Native Starter](https://constra.huviair.com/assets/images/banner3.png)


## Getting Started

#### 1. Clone and Install

```bash
# Clone the repo
git clone https://huviairtech@dev.azure.com/huviairtech/huviair-app/_git/constra-mobile-app

# Navigate to clonned folder and Install dependencies
cd constra-mobile-app && yarn install

# Install Pods (IOS)
cd ios && pod install
```

#### 2. Open CONSTRA in your iOS/Android simulator

Run this command to start the development server and to start your app on iOS simulator:
```
yarn run:ios
```

Run this command to start the development server and to start your app on android simulator:
```
yarn run:android
```

### 3.Development 
Adding a new Module

plop module moduleName
 Option 1: Statefull module has connection to redux store.
 Option 2: Stateless doesn't has connection to redux store.