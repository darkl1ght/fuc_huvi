#!/usr/bin/env python
import os
from time import sleep
import json
import logging
import asyncio
import motor.motor_asyncio
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, __version__
import vimeo
from dotenv import load_dotenv
from bson.objectid import ObjectId
load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MONGODB_CONN_STRING = os.environ.get("MONGODB_CONN_STRING")
MONGODB_DB_NAME = os.environ.get("MONGODB_DB_NAME")
BLOB_CONTAINER = os.environ.get("BLOB_CONTAINER")
AZURE_STORAGE_CONNECTION_STRING = os.environ.get(
    "AZURE_STORAGE_CONNECTION_STRING")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_CONN_STRING)
database = client[MONGODB_DB_NAME]
media_albums_collection = database.get_collection(
    "projectalbums")
video_processing_queue_collection = database.get_collection(
    "videoprocessingqueues")
vimeo_client = vimeo.VimeoClient(
    token=os.environ.get("VIMEO_PERSONAL_ACCESS_TOKEN"),
    key=os.environ.get("VIMEO_CLIENT_ID"),
    secret=os.environ.get("VIMEO_CLIENT_SECRET"),
)


async def download_media_blob(file_name):
    try:
        data_dir = os.path.join(BASE_DIR, "temp_blob_downloads")
        if not os.path.isdir(data_dir):
            os.makedirs(data_dir, exist_ok=True)

        def download_blob(blob_client, destination_file):
            with open(destination_file, "wb") as my_blob:
                blob_data = blob_client.download_blob()
                blob_data.readinto(my_blob)

        blob_service_client = BlobServiceClient.from_connection_string(
            AZURE_STORAGE_CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(
            BLOB_CONTAINER)
        blob_list = container_client.list_blobs()
        blob_download_path = ""
        blob_name = ""
        for blob in blob_list:
            # Finally, download the blob
            if blob.name == file_name:
                blob_client = container_client.get_blob_client(blob.name)
                blob_download_path = os.path.join(data_dir, blob.name)
                download_blob(
                    blob_client,
                    blob_download_path
                )
                break
        if blob_download_path == "":
            raise Exception("Blob File not found")
        return {"success": True, "download_path": blob_download_path}
    except Exception as err:
        error = "Error in download_media_blob function : {}".format(
            err)
        print(error)
        return {"success": False, "error": error}


async def check_transcoder_progress(uri):
    response = ""
    while True:
        response = vimeo_client.get(uri + '?fields=transcode.status').json()
        try:
            if response['transcode']['status'] == 'in_progress':
                sleep(30)
            else:
                break
        except Exception as e:
            return "error"

    if response['transcode']['status'] == 'complete':
        return "success"
    elif response['transcode']['status'] == 'error':
        return "error"


async def upload_to_vimeo(file_path, upload_file_name, count):
    file_ext = os.path.basename(file_path).split(".").pop()
    try:
        uri = vimeo_client.upload(file_path, data={
            'name': "%s.%s" % (upload_file_name, file_ext),
            'description': os.path.basename(file_path)
        })
        progress = await check_transcoder_progress(uri)
        if progress == "error" and count <= 3:
            count += 1
            await upload_to_vimeo(file_path, count)
        elif progress == "error" and count > 3:
            raise Exception(
                "Video Upload Stopped after 3 retries for transcoding")
        else:
            response = vimeo_client.get(uri + '?fields=link').json()
            vimeo_id = response['link'].split(".com/")[1]
            return {"success": True, "error": None, "vimeo_id": vimeo_id}
    except Exception as err:
        error = "Error in Vimeo Upload: %s" % err
        return {"success": False, "error": error}


async def download_and_upload_blob_to_vimeo(video_to_upload):
    try:
        # await update_video_processing_status(
        #     video_to_upload,
        #     "processing"
        # )
        file_name = video_to_upload["blob_content_id"]
        download_status = await download_media_blob(file_name)
        if download_status["success"]:
            await update_video_processing_status(
                video_to_upload,
                "processing"
            )
            vimeo_upload_status = {}
            vimeo_upload_status = await upload_to_vimeo(
                download_status["download_path"],
                file_name,
                1
            )
            if vimeo_upload_status.get("success", False):
                update_status = await update_project_album_collection(
                    video_to_upload,
                    vimeo_upload_status["vimeo_id"]
                )
                if update_status.get("success"):
                    await delete_video_processing_status(video_to_upload)
                else:
                    await update_video_processing_status(video_to_upload, update_status.get("error"))
            else:
                await update_video_processing_status(
                    video_to_upload,
                    vimeo_upload_status["error"]
                )
                print(vimeo_upload_status["error"])
            os.remove(download_status["download_path"])
        else:
            print(download_status["error"])
    except Exception as err:
        print(err)


unprocessed_video_queue = []


def video_helper(video):
    return {
        "id": str(video["_id"]),
        "media_id": str(video["mediaId"]),
        "album_id": str(video["albumId"]),
        "project_id": video["projectId"],
        "blob_content_id": video["blobContentId"],
        "status": video["status"],
        "meta": video["meta"],
    }


async def retrieve_upload_queue():
    global unprocessed_video_queue
    async for video in video_processing_queue_collection.find({"status": "new"}):
        unprocessed_video_queue.append(video_helper(video))
    return


async def update_video_processing_status(video, status):
    await video_processing_queue_collection.find_one_and_update(
        {"_id": ObjectId(video["id"])},
        {"$set": {"status": status}}
    )


async def delete_video_processing_status(video):
    await video_processing_queue_collection.delete_one(
        {"_id": ObjectId(video["id"])}
    )


async def update_project_album_collection(video, vimeo_id):
    try:
        album = await media_albums_collection.find_one(
            {
                "albumId": video["album_id"],
                "isActive": True
            }
        )
        media = await media_albums_collection.find_one(
            {
                "albumId": video["album_id"],
                "media.mediaId": video["media_id"],
                "isActive": True
            }
        )
        if not album:
            vimeo_id = None
            return {
                "success": False,
                "error": "Error: Album does not exist"
            }
        # superplayers = [
        #     single_media for single_media in media if single_media['mediaId'] == video["media_id"]]
        if not media:
            vimeo_id = None
            return {
                "success": False,
                "error": "Error: Media does not exist"
            }
        if album and media:
            await media_albums_collection.find_one_and_update(
                {
                    "albumId": video["album_id"],
                    "media.mediaId": video["media_id"]
                },
                {
                    "$set": {
                        "media.$.isPublished": True,
                        "isActive": True,
                        "media.$.videoSource": {
                            "isVimeo": True,
                            "vimeoId": vimeo_id
                        }
                    }
                }
            )
            vimeo_id = None
            return {
                "success": True,
                "error": None
            }

    except Exception as err:
        print(err)
        vimeo_id = None
        return {
            "success": False,
            "error": "Error: {}".format(err)
        }

logger = logging.getLogger(__name__)
if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    while True:
        unprocessed_video_queue = []
        try:
            loop.run_until_complete(retrieve_upload_queue())
            video_to_upload = None
            for video in unprocessed_video_queue:
                if video["status"] == "new":
                    video_to_upload = video
                    break
            if video_to_upload:
                loop.run_until_complete(
                    download_and_upload_blob_to_vimeo(
                        video_to_upload
                    )
                )
            else:
                sleep(60)
        except Exception as e:
            logger.info(e)
            client.close()
    client.close()

    # ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of default=nw=1
