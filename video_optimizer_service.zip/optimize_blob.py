#!/usr/bin/env python
import sys
import os
import csv
from time import sleep
import shutil
import random
import logging
import asyncio
import subprocess
from pathlib import Path
import datetime as dt
from datetime import datetime
from zoneinfo import ZoneInfo
import uuid
from bson.objectid import ObjectId
import motor.motor_asyncio
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, __version__
from dotenv import load_dotenv
load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MONGODB_CONN_STRING = os.environ.get("MONGODB_CONN_STRING")
MONGODB_DB_NAME = os.environ.get("MONGODB_DB_NAME")
BLOB_CONTAINER = os.environ.get("BLOB_CONTAINER")
AZURE_STORAGE_CONNECTION_STRING = os.environ.get(
    "AZURE_STORAGE_CONNECTION_STRING")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_CONN_STRING)
database = client[MONGODB_DB_NAME]
media_albums_collection = database.get_collection(
    "projectalbums")
video_processing_queue_collection = database.get_collection(
    "videoprocessingqueues")


async def upload_file_to_blob(file_path):
    try:
        if(os.path.exists(file_path)):
            local_file_name = os.path.basename(file_path)
            blob_name = local_file_name
            # Create the BlobServiceClient object which will be used to create a container client
            blob_service_client = BlobServiceClient.from_connection_string(
                AZURE_STORAGE_CONNECTION_STRING)
            # Create a blob client using the local file name as the name for the blob
            blob_client = blob_service_client.get_blob_client(
                container=BLOB_CONTAINER,
                blob=blob_name
            )

            # Upload the created file
            with open(file_path, "rb") as data:
                blob_client.upload_blob(data)

            blob_url = blob_client.url
            os.remove(file_path)
        else:
            print("File to upload does not exist")
            sys.exit(0)
    except Exception as err:
        error = "Error in upload_file_to_blob function: {}".format(str(err))
        print(error)
        return {"success": False, "error": error}
    else:
        return {"success": True, "blob_url": blob_url, "blob_ref": blob_name}


async def download_and_delete_media_blob(file_name):
    try:
        data_dir = os.path.join(BASE_DIR, "temp_blob_downloads")
        if not os.path.isdir(data_dir):
            os.makedirs(data_dir, exist_ok=True)

        def download_blob(blob_client, destination_file):
            with open(destination_file, "wb") as my_blob:
                blob_data = blob_client.download_blob()
                blob_data.readinto(my_blob)
            print("Blob file downloaded")
            blob_client.delete_blob()
            print("Blob file deleted")

        blob_service_client = BlobServiceClient.from_connection_string(
            AZURE_STORAGE_CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(
            BLOB_CONTAINER)
        blob_list = container_client.list_blobs()
        blob_download_path = ""
        for blob in blob_list:
            # Finally, download the blob
            if(blob.name == file_name):
                blob_client = container_client.get_blob_client(blob.name)
                blob_download_path = os.path.join(data_dir, blob.name)
                download_blob(
                    blob_client,
                    blob_download_path
                )
                break
        if (blob_download_path == ""):
            raise Exception("Blob File not found")
        return {"success": True, "download_path": blob_download_path}
    except Exception as err:
        error = "Error in download_and_delete_media_blob function : {}".format(
            err)
        print(error)
        return {"success": False, "error": error}


async def optimize_media_with_ffmpeg(input_file_path):
    try:
        output_file_path = input_file_path[:-4]+"_ffmpeg"+input_file_path[-4:]
        args = [
            "ffmpeg",
            "-hide_banner", "-nostats",
            "-loglevel", "warning",
            "-i", input_file_path,
            "-pix_fmt", "yuv420p",
            "-deinterlace",
            "-vf", "scale=852:480",
            "-vsync", "1",
            "-vcodec", "libx264",
            "-r", "59.940",
            "-threads", "0",
            "-crf", "23",
            "-preset", "medium",
            "-profile:v", "baseline",
            "-tune", "film",
            "-g", "60",
            "-sc_threshold", "0",
            "-f", "mp4",
            "-y", output_file_path
        ]
        process = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            universal_newlines=True
        )
        # print("ffmpeg conversion Started...")
        while True:
            output = process.stdout.readline()
            # print(output.strip())
            return_code = process.poll()
            if return_code is not None:
                print("RETURN CODE {}".format(return_code))
                # Process has finished, read rest of the output
                if return_code == 0:
                    pass
                    # print("ffmpeg conversion Completed.")
                else:
                    for output in process.stdout.readlines():
                        # pass
                        print(output.strip())
                    print(
                        "Some Error occured during script execution. Script: '{}'".format(
                            " ".join(args)
                        )
                    )
                break
    except Exception as err:
        error = "Error in optimize_media_with_ffmpeg function: {}".format(err)
        return {"success": False, "error": error}
    else:
        os.remove(input_file_path)
        os.rename(output_file_path, input_file_path)
        return {"success": True, "output_file_path": input_file_path}


async def update_blob_media_with_ffmpeg(file_name):
    # download
    print("Media Found: {}".format(file_name))
    download_and_delete_status = await download_and_delete_media_blob(file_name)
    if (download_and_delete_status["success"]):
        print("Blob downloaded to location: {}".format(
            download_and_delete_status["download_path"])
        )
        # convert
        optimize_status = await optimize_media_with_ffmpeg(
            download_and_delete_status["download_path"]
        )
        if (optimize_status["success"]):
            print("Blob optimized location: {}".format(
                optimize_status["output_file_path"])
            )
            # upload
            upload_status = await upload_file_to_blob(
                optimize_status["output_file_path"]
            )
            if (upload_status["success"]):
                print(upload_status["blob_url"])
                print("Exiting")
                # update db the state
            else:
                print(upload_status["error"])
        else:
            print(optimize_status["error"])
    else:
        print(download_and_delete_media_blob["error"])


all_videos_processing = []


async def retrieve_all_videos():
    global all_videos_processing
    async for video in video_processing_queue_collection.find():
        all_videos_processing.append(video)
    return all_videos_processing


async def update_video_processing_status(video):
    await video_processing_queue_collection.find_one_and_update(
        {"_id": video["_id"]},
        {"$set": {"status": "processing"}}
    )


async def delete_video_processing_status(video):
    await video_processing_queue_collection.delete_one(
        {"_id": video["_id"]}
    )


async def update_project_album_collection(video):
    await media_albums_collection.find_one_and_update(
        {
            "albumId": video["albumId"],
            "media.mediaId": video["mediaId"]
        },
        {
            "$set": {
                "media.$.isPublished": True,
                "isActive": True
            }
        }
    )

logger = logging.getLogger(__name__)
if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    while True:
        all_videos_processing = []
        try:
            loop.run_until_complete(retrieve_all_videos())
            video_to_convert = False
            for video in all_videos_processing:
                if video["status"] == "new":
                    video_to_convert = video
                    break
            if video_to_convert:
                loop.run_until_complete(
                    update_video_processing_status(video_to_convert))
                loop.run_until_complete(
                    update_blob_media_with_ffmpeg(
                        video_to_convert["blobContentId"]
                    )
                )
                loop.run_until_complete(
                    delete_video_processing_status(video_to_convert),
                )
                loop.run_until_complete(
                    update_project_album_collection(video_to_convert)
                )
            else:
                sleep(60)
        except Exception as e:
            logger.info(e)
            client.close()
    client.close()

    # ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of default=nw=1
