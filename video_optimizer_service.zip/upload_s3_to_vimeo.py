#!/usr/bin/env python
import os
import time
from time import sleep
import json
import functools
import threading
from pymongo import MongoClient
import vimeo
import boto3
from botocore.config import Config
from message_reciever import BasicMessageReceiver
from dotenv import load_dotenv
load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MONGODB_CONN_STRING = os.environ.get("MONGODB_CONN_STRING")
MONGODB_DB_NAME = os.environ.get("MONGODB_DB_NAME")

VIMEO_UPLOAD_QUEUE = os.environ.get('VIMEO_UPLOAD_QUEUE')
MESSAGING_BROKER_ID = os.environ.get('MESSAGING_BROKER_ID')
MESSAGING_USER_ID = os.environ.get('MESSAGING_USER_ID')
MESSAGING_USER_PASSWORD = os.environ.get('MESSAGING_USER_PASSWORD')
MESSAGING_BROKER_REGION = os.environ.get('MESSAGING_BROKER_REGION')

AWS_ACCESS_KEY_ID = os.environ.get('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
S3_BUCKET_ID = os.environ.get('S3_BUCKET_ID')
TEMP_S3_DOWNLOAD_FOLDER = "temp_s3_download"

client = MongoClient(MONGODB_CONN_STRING)
database = client[MONGODB_DB_NAME]
video_processing_stats_collection = database["videoprocessingstats"]
file_collection = database["files"]
vimeo_client = vimeo.VimeoClient(
    token=os.environ.get("VIMEO_PERSONAL_ACCESS_TOKEN"),
    key=os.environ.get("VIMEO_CLIENT_ID"),
    secret=os.environ.get("VIMEO_CLIENT_SECRET"),
)

MAX_TRANSCODE_TIME_IN_MINUTES = 30


def ack_message(ch, delivery_tag):
    """Note that `ch` must be the same pika channel instance via which
    the message being ACKed was retrieved (AMQP protocol constraint).
    """
    if ch.is_open:
        ch.basic_ack(delivery_tag)
    else:
        # Channel is already closed, so we can't ACK this message;
        # log and/or do something that makes sense for your app in this case.
        pass


def update_file_collection(file_object_id, vimeo_id):
    try:
        file = file_collection.find_one(
            {
                "fileObjectId": file_object_id,
                "status": "Active"
            }
        )

        if not file:
            vimeo_id = None
            return {
                "success": False,
                "error": f"Error: File does not exist in files collection - fileObjectId: {file_object_id}"
            }
        else:
            file_collection.find_one_and_update(
                {
                    "fileObjectId": file_object_id,
                    "metadata.label": "VideoSourceType"
                },
                {
                    "$set": {
                        "metadata.$.value": "vimeo"
                    }
                }
            )
            file_collection.find_one_and_update(
                {
                    "fileObjectId": file_object_id,
                    "metadata.label": "VideoSourceId"
                },
                {
                    "$set": {
                        "metadata.$.value": vimeo_id
                    }
                }
            )
            file_collection.find_one_and_update(
                {
                    "fileObjectId": file_object_id,
                    "metadata.label": "IsPublished"
                },
                {
                    "$set": {
                        "metadata.$.value": True
                    }
                }
            )

            vimeo_id = None
            return {
                "success": True,
                "error": None
            }
    except Exception as err:
        print(err)
        vimeo_id = None
        return {
            "success": False,
            "error": "Error: {}".format(err)
        }


def update_video_processing_status(file_object_id, status):
    video_processing_stats_collection.find_one_and_update(
        {
            "fileObjectId": file_object_id,
        },
        {
            "$set": {"status": status}
        }
    )
    print(f"{file_object_id} - Video processing status updated - {status}")


def update_events(file_object_id, msg):
    video_processing_stats_collection.find_one_and_update(
        {
            "fileObjectId": file_object_id,
        },
        {
            "$push": {
                "events": msg
            }
        }
    )
    print(f"{file_object_id} - {msg}")


def check_transcoder_progress(uri, start_time, file_object_id):
    response = ""
    transcode_time_limit = False

    while True:
        response = vimeo_client.get(uri + '?fields=transcode.status').json()
        try:
            if response['transcode']['status'] == 'in_progress':
                end_time = time.time()

                if (end_time - start_time > MAX_TRANSCODE_TIME_IN_MINUTES * 60):
                    transcode_time_limit = True
                    update_events(
                        file_object_id, f"Transcode time exceeded {MAX_TRANSCODE_TIME_IN_MINUTES} minutes")
                    break
                sleep(30)
            else:
                break
        except Exception as e:
            return "error"

    if response['transcode']['status'] == 'complete':
        return "success"
    elif response['transcode']['status'] == 'error':
        return "error"
    elif transcode_time_limit:
        return "error"


def upload_to_vimeo(file_object_id, file_path, upload_file_name, count, start_time):
    file_ext = os.path.basename(file_path).split(".").pop()
    update_events(file_object_id,
                  f"Uploading to Vimeo - try: {count}")

    try:
        uri = vimeo_client.upload(file_path, data={
            'name': "%s.%s" % (upload_file_name, file_ext),
            'description': os.path.basename(file_path)
        })
        progress = check_transcoder_progress(uri, start_time, file_object_id)

        if progress == "error" and count < 3:
            count += 1
            return upload_to_vimeo(file_object_id, file_path, upload_file_name, count, time.time())
        elif progress == "error" and count >= 3:
            raise Exception(
                "Video Upload Stopped after 3 retries for transcoding")
        else:
            response = vimeo_client.get(uri + '?fields=link').json()
            vimeo_id = response['link'].split(".com/")[1]
            return {"success": True, "error": None, "vimeo_id": vimeo_id}
    except Exception as err:
        return {"success": False, "error": f"{err}"}


def do_work(ch, delivery_tag, body):
    thread_id = threading.get_ident()
    print(thread_id)
    print("[x] Received %r" % body)
    message = json.loads(body)
    msg = message.get("message")
    file_object_id = msg.get("fileObjectId")
    module = msg.get("module")
    company_id = msg.get("companyId")

    cb = functools.partial(ack_message, ch, delivery_tag)
    ch.connection.add_callback_threadsafe(cb)

    if file_object_id is not None and module is not None and company_id is not None:
        video = video_processing_stats_collection.find_one(
            {
                "fileObjectId": file_object_id,
                "status": "New"
            }
        )

        if not video:
            print(
                f"Video does't exist in VideoProcessingStats with fileObjectId: '{file_object_id}' and status: 'New'")
        else:
            update_events(
                file_object_id, "Message received by service. Starting processing.")
            update_video_processing_status(file_object_id, "Processing")

            _config = Config(
                region_name=os.environ['AWS_REGION_NAME'])
            s3 = boto3.client('s3',
                              aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
                              aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'], config=_config)
            data_dir = os.path.join(BASE_DIR, TEMP_S3_DOWNLOAD_FOLDER)
            s3_src_file_path = os.path.join(module, company_id, file_object_id)
            temp_dst_file_path = os.path.join(data_dir, file_object_id)

            if not os.path.isdir(data_dir):
                os.makedirs(data_dir, exist_ok=True)

            update_events(
                file_object_id, "Downloading file from S3 to server folder")
            download_sucess = False

            try:
                with open(temp_dst_file_path, 'wb') as f:
                    s3.download_fileobj(
                        S3_BUCKET_ID, s3_src_file_path, f)
                    download_sucess = True
            except Exception as err:
                download_sucess = False
                update_video_processing_status(file_object_id, "Error")
                update_events(
                    file_object_id, f"Download file from S3 failed - {S3_BUCKET_ID}/{s3_src_file_path} - {str(err)}")

            if download_sucess:
                update_events(
                    file_object_id, "File downloaded successfully. Starting upload to Vimeo.")
                vimeo_upload_status = {}

                try:
                    vimeo_upload_status = upload_to_vimeo(
                        file_object_id,
                        temp_dst_file_path,
                        file_object_id,
                        1,
                        time.time()
                    )

                    if vimeo_upload_status.get("success", False):
                        vimeo_id = vimeo_upload_status["vimeo_id"]
                        update_events(
                            file_object_id, f"Uploaded video to Vimeo - vimeo_id: {vimeo_id}")
                        update_status = update_file_collection(
                            file_object_id,
                            vimeo_id
                        )

                        if update_status.get("success"):
                            update_events(
                                file_object_id, f"Files collection metadata updated. Processing completed.")
                            update_video_processing_status(
                                file_object_id, "Completed")
                            # video_processing_stats_collection.delete_one(
                            #     {"fileObjectId": file_object_id})
                        else:
                            update_video_processing_status(
                                file_object_id, "Error")
                            update_events(
                                file_object_id, update_status.get("error"))

                    else:
                        update_video_processing_status(file_object_id, "Error")
                        update_events(
                            file_object_id, vimeo_upload_status["error"])
                except Exception as err:
                    update_video_processing_status(file_object_id, "Error")
                    update_events(file_object_id, str(err))
                os.remove(temp_dst_file_path)
    else:
        print(
            f"Invalid fileObjectId/module/companyId in message: {file_object_id}/{module}/{company_id}")


def callback(ch, method_frame, _header_frame, body, args):
    thrds = args
    delivery_tag = method_frame.delivery_tag
    t = threading.Thread(target=do_work, args=(ch, delivery_tag, body))
    t.start()
    thrds.append(t)


# Create Basic Message Receiver which creates a connection and channel for consuming messages.
basic_message_receiver = BasicMessageReceiver(
    MESSAGING_BROKER_ID,
    MESSAGING_USER_ID,
    MESSAGING_USER_PASSWORD,
    MESSAGING_BROKER_REGION
)

threads = []

# Consume multiple messages in an event loop.
basic_message_receiver.consume_messages(
    VIMEO_UPLOAD_QUEUE, callback=functools.partial(callback, args=(threads)))

# Wait for all to complete
for thread in threads:
    thread.join()

# Close connections.
basic_message_receiver.close()

# ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of default=nw=1
