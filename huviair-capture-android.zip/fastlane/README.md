fastlane documentation
----

# Installation

Make sure you have the latest version of the Xcode command line tools installed:

```sh
xcode-select --install
```

For _fastlane_ installation instructions, see [Installing _fastlane_](https://docs.fastlane.tools/#installing-fastlane)

# Available Actions

## Android

### android build

```sh
[bundle exec] fastlane android build
```

Build the debug and release .aab files

### android sign_bundle

```sh
[bundle exec] fastlane android sign_bundle
```

Sign the Android App Bundle

### android internal_testing

```sh
[bundle exec] fastlane android internal_testing
```

Upload the release .aab file to internal testing track on Google Play

### android deploy

```sh
[bundle exec] fastlane android deploy
```

Build, sign, and upload the release .aab file to internal testing track on Google Play

----

This README.md is auto-generated and will be re-generated every time [_fastlane_](https://fastlane.tools) is run.

More information about _fastlane_ can be found on [fastlane.tools](https://fastlane.tools).

The documentation of _fastlane_ can be found on [docs.fastlane.tools](https://docs.fastlane.tools).
