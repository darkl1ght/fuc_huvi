package com.huviair.capture.data.model.api.media;

import java.io.Serializable;
import java.util.List;

public class Album implements Serializable, Comparable {

    private List<Media> media;
    private String albumId;
    private String albumName;
    private String albumDate;
    private String projectId;
    private boolean isActive;


    public Album(String albumName, String albumDate, String albumId, boolean isActive) {
        this.albumDate = albumDate;
        this.albumName = albumName;
        this.albumId = albumId;
        this.isActive = isActive;
    }

    public String getAlbumId() {
        return albumId;
    }

    public void setAlbumId(String albumId) {
        this.albumId = albumId;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getAlbumDate() {
        return albumDate;
    }

    public void setAlbumDate(String albumDate) {
        this.albumDate = albumDate;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public List<Media> getMedia() {
        return media;
    }

    public void setMedia(List<Media> media) {
        this.media = media;
    }

    @Override
    public String toString() {
        return "Album{" +
                "media=" + media +
                ", albumId='" + albumId + '\'' +
                ", albumName='" + albumName + '\'' +
                ", albumDate=" + albumDate +
                ", projectId='" + projectId + '\'' +
                '}';
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Override
    public int compareTo(Object o) {
        Album album = (Album) o;
        if (this.albumId.equals(album.getAlbumId())
                && this.albumName.equals(album.getAlbumName())
                && this.media.equals(album.getMedia())
                && this.projectId.equals(album.getProjectId())
        )
            return 0;

        return 1;
    }
}
