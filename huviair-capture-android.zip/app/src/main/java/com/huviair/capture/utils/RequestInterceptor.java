package com.huviair.capture.utils;

import androidx.annotation.Keep;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.logging.Logger;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;

@Keep
public class RequestInterceptor implements Interceptor {
    private final String authToken;

    public RequestInterceptor(String authToken) {
        this.authToken = authToken;
    }

    @NotNull
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request r = chain.request()
                .newBuilder()
                .addHeader("Authorization", "Bearer".concat(" ").concat(this.authToken))
                .build();

        RequestBody requestBody = r.body();
        String body = null;

        if (requestBody != null) {
            Buffer buffer = new Buffer();
            requestBody.writeTo(buffer);
            body = buffer.readUtf8();
        }

        Logger.getAnonymousLogger().info(String.format("Sending %s request %s with body %s", r.method(),
                r.url(), body));

        return chain.proceed(r);
    }
}