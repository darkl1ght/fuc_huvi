package com.huviair.capture.data.model.api.snags;

import com.google.gson.annotations.Expose;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

public class Snag implements Serializable, Comparable {

    private String punchId;
    private String punchListId;
    private String taskDescription;
    private WorkLocation workLocation;
    private WorkPackage workPackage;
    private TaskStatus taskStatus;
    private ApproverDetails level1Status;
    private ApproverDetails level2Status;
    private TaskPriority taskPriority;
    private String remark;
    private String[] level1Users;
    private String[] level2Users;
    private String taskId;
    private String projectId;
    private String dueDate;
    private String updatedAt;
    private String[] tags;
    private List<SnagMedia> mediaList;
    private final boolean isNonConformity = false;
    private SnagMediaFloorPlan floorPlan;

    @Expose(deserialize = false, serialize = false)
    private int listPositionOfTheSnag;

    @Expose(deserialize = false, serialize = false)
    private boolean isViewExpanded = false;

    @Expose(deserialize = false, serialize = false)
    private boolean isOnsiteSnag = false;

    public WorkLocation getWorkLocation() {
        return workLocation;
    }

    public WorkPackage getWorkPackage() {
        return workPackage;
    }

    public TaskStatus getTaskStatus() {
        return taskStatus;
    }

    public String getPunchListId() {
        return punchListId;
    }

    public ApproverDetails getLevel1Status() {
        return level1Status;
    }

    public ApproverDetails getLevel2Status() {
        return level2Status;
    }

    public TaskPriority getTaskPriority() {
        return taskPriority;
    }

    public String getRemark() {
        return remark;
    }

    public String[] getLevel1Users() {
        return level1Users;
    }

    public String[] getLevel2Users() {
        return level2Users;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getDueDate() {
        return dueDate;
    }

    public String[] getTags() {
        return tags;
    }

    public List<SnagMedia> getMediaList() {
        return mediaList;
    }

    public boolean isNonConformity() {
        return isNonConformity;
    }

    public String getPunchId() {
        return punchId;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public boolean isViewExpanded() {
        return isViewExpanded;
    }

    public void setViewExpanded(boolean viewExpanded) {
        isViewExpanded = viewExpanded;
    }

    public boolean isOnsiteSnag() {
        return isOnsiteSnag;
    }

    public void setIsOnsiteSnag(boolean isOnsiteSnag) {
        this.isOnsiteSnag = isOnsiteSnag;
    }
    public String getUpdatedAt() {
        return updatedAt;
    }

    public int getListPositionOfTheSnag() {
        return listPositionOfTheSnag;
    }

    public void setListPositionOfTheSnag(int listPositionOfTheSnag) {
        this.listPositionOfTheSnag = listPositionOfTheSnag;
    }

    public void setTags(String[] tags) {
        this.tags = tags;
    }

    public void setTaskPriority(TaskPriority taskPriority) {
        this.taskPriority = taskPriority;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public SnagMediaFloorPlan getFloorPlan() {
        return floorPlan;
    }

    public void setFloorPlan(SnagMediaFloorPlan floorPlan) {
        this.floorPlan = floorPlan;
    }

    public void setMediaList(List<SnagMedia> mediaList) {
        this.mediaList = mediaList;
    }

    @Override
    public int compareTo(Object snagCompareObject) {
        Snag newSnag = (Snag) snagCompareObject;
        if (newSnag.getPunchId()!=null && punchId!=null && newSnag.getPunchId().equals(punchId)
                && newSnag.level1Status!=null && level1Status!=null && newSnag.level1Status.equals(level1Status)
                && newSnag.level2Status!=null && level2Status!=null && newSnag.level2Status.equals(level2Status)
                && newSnag.taskStatus!=null && taskStatus!=null && newSnag.taskStatus.equals(taskStatus)
                && newSnag.level1Users!=null && level1Users!=null && Arrays.equals(newSnag.level1Users, level1Users)
                && newSnag.level2Users!=null && level2Users!=null && Arrays.equals(newSnag.level2Users, level2Users)
                && newSnag.taskDescription!=null && taskDescription!=null && newSnag.taskDescription.equals(taskDescription)
                && newSnag.dueDate!=null && dueDate!=null && newSnag.dueDate.equals(dueDate)
                && newSnag.tags!=null && tags!=null && Arrays.equals(newSnag.tags, tags)
                && newSnag.taskPriority!=null && taskPriority!=null && newSnag.taskPriority.equals(taskPriority)
        ) {
            if (newSnag.remark != null && remark != null && newSnag.remark.equals(remark)) {
                return 0;
            }
            return 0;
        }

        return 1;
    }

    public Snag floorPlanBuilder(FloorPlanDrawing drawing) {
        this.floorPlan = new SnagMediaFloorPlan(drawing.getBlobContentId(), null);
        return this;
    }
}
