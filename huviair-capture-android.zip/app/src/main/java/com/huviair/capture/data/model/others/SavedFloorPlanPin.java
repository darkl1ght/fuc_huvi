package com.huviair.capture.data.model.others;

import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;

public class SavedFloorPlanPin implements Parcelable {

    private final PointF savedPointOnFloorPlan;
    private final long savedImageNumber;
    private final long imageNumberToDisplay;

    public SavedFloorPlanPin(PointF savedPointOnFloorPlan, long savedImageNumber, long imageNumberToDisplay) {
        this.savedPointOnFloorPlan = savedPointOnFloorPlan;
        this.savedImageNumber = savedImageNumber;
        this.imageNumberToDisplay = imageNumberToDisplay;
    }

    protected SavedFloorPlanPin(Parcel in) {
        savedPointOnFloorPlan = in.readParcelable(PointF.class.getClassLoader());
        savedImageNumber = in.readLong();
        imageNumberToDisplay = in.readLong();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(savedPointOnFloorPlan, flags);
        dest.writeLong(savedImageNumber);
        dest.writeLong(imageNumberToDisplay);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<SavedFloorPlanPin> CREATOR = new Creator<SavedFloorPlanPin>() {
        @Override
        public SavedFloorPlanPin createFromParcel(Parcel in) {
            return new SavedFloorPlanPin(in);
        }

        @Override
        public SavedFloorPlanPin[] newArray(int size) {
            return new SavedFloorPlanPin[size];
        }
    };

    public PointF getSavedPointOnFloorPlan() {
        return savedPointOnFloorPlan;
    }

    public long getSavedImageNumber() {
        return savedImageNumber;
    }

    public long getImageNumberToDisplay() {
        return imageNumberToDisplay;
    }
}
