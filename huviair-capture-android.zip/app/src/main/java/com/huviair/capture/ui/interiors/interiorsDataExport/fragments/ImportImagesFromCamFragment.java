package com.huviair.capture.ui.interiors.interiorsDataExport.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.arashivision.sdkcamera.camera.callback.ICameraChangedCallback;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.databinding.FragmentImportImagesBinding;
import com.huviair.capture.ui.insta360.CameraConnectionBottomSheetFragment;
import com.huviair.capture.ui.interiors.interiorsDataExport.TourDataTransferFragmentActivity;
import com.huviair.capture.utils.CommonConstants;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.FileCallback;
import com.lzy.okgo.model.Response;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class ImportImagesFromCamFragment extends Fragment implements ICameraChangedCallback {

    public static final String TOUR_ID = "TOUR_ID";

    public static String[] imagesToBeDownloaded = null;
    private static String HDR_FOLDER_PATH = null;

    private FragmentImportImagesBinding importImagesBinding;

    private CameraConnectionBottomSheetFragment cameraConnectionBottomSheetFragment;


    public ImportImagesFromCamFragment() {
        // Required empty public constructor
    }

    public static ImportImagesFromCamFragment newInstance(String tourId) {
        ImportImagesFromCamFragment fragment = new ImportImagesFromCamFragment();
        Bundle args = new Bundle();
        args.putString(TOUR_ID, tourId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        InstaCameraManager.getInstance().registerCameraChangedCallback(this);
        importImagesBinding = FragmentImportImagesBinding.inflate(inflater, container, false);
        return importImagesBinding.getRoot();
    }

    @Override
    public void onViewCreated(@androidx.annotation.NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        importImagesBinding.backNavigation.setOnClickListener(view1 -> requireActivity().onBackPressed());
        importImagesBinding.nextPage.setOnClickListener(v -> ((TourDataTransferFragmentActivity) requireActivity()).jumpToNextPage(view));

        //Initialize folder paths
        HDR_FOLDER_PATH = requireContext().getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER;

    }

    @Override
    public void onStart() {
        super.onStart();

        View view = getView();
        if (view != null) {
            assert getArguments() != null;
            if (getArguments().getString(TOUR_ID) != null) {
                importImagesBinding.downloadImages.setOnClickListener(v -> fetchImageUrlsAndDownload(getArguments().getString(TOUR_ID)));
            }
        }
    }

    private void fetchImageUrlsAndDownload(String tourId) {
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(getContext());
        Single<List<TourDetails>> fetchTours = database.tourDetailsDAO().getSavedTourDetails(tourId);
        fetchTours.observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<List<TourDetails>>() {
                    @Override
                    public void onSuccess(@NonNull List<TourDetails> tourDetails) {
                        if (!tourDetails.isEmpty()) {
                            String[] imageUrls = isFilesAvailableForDownload(tourDetails);

                            // If no images to import -> do nothing
                            if (imageUrls.length == 0) {
                                Snackbar.make(importImagesBinding.getRoot(), "All files downloaded already...", Snackbar.LENGTH_LONG)
                                        .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                        .show();
                                return;
                            }

                            imagesToBeDownloaded = imageUrls;
                            checkConnectionAndDownloadFiles(imagesToBeDownloaded);
                        } else {
                            Snackbar.make(importImagesBinding.getRoot(), "No images associated with the selected walk-through..", Snackbar.LENGTH_LONG)
                                    .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                    .show();
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        Snackbar.make(importImagesBinding.getRoot(), "Unable to fetch saved tour details..", Snackbar.LENGTH_INDEFINITE)
                                .setAction("RETRY", v -> fetchImageUrlsAndDownload(tourId))
                                .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                .show();
                    }
                });
    }

    private void checkConnectionAndDownloadFiles(String[] urls) {

        if (InstaCameraManager.getInstance().getCameraConnectedType() == InstaCameraManager.CONNECT_TYPE_NONE) {
            openBottomSheetForConnection();
        }
        else {
            downloadImages(urls);
        }

    }

    /**
     * Display a bottom sheet for showing user to connect
     */
    private void openBottomSheetForConnection() {
       cameraConnectionBottomSheetFragment = CameraConnectionBottomSheetFragment.newInstance();
        cameraConnectionBottomSheetFragment.show(getChildFragmentManager(), "this");
    }


    //  Searches for files in the respective folders
    private String[] isFilesAvailableForDownload(List<TourDetails> tourDetails) {

        // Remove any image url = null and further split the image urls by "," and get the array of image URLS
        Stream<String[]> splitImageUrlStream = tourDetails.stream().filter(individualRow -> individualRow.getImageUrl() != null)
                .map(TourDetails::getImageUrl)
                .map(urls -> urls.split(","));


        return splitImageUrlStream.flatMap(Arrays::stream)
                .filter(url -> !new File(HDR_FOLDER_PATH + "/" + getFileNameFromUrl(url)).exists())
                .toArray(String[]::new);

    }

    // Import images from the camera using okgo
    private void downloadImages(String[] urls) {

        String[] fileNames = new String[urls.length];
        String[] localPaths = new String[urls.length];

        for (int i = 0; i < localPaths.length; i++) {
            fileNames[i] = getFileNameFromUrl(urls[i]);
            localPaths[i] = HDR_FOLDER_PATH + "/" + fileNames[i];
        }

        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Downloading images.. ")
                .setMessage(getString(R.string.download_status, urls.length, 0, 0))
                .setIcon(R.drawable.ic_baseline_arrow_downward_24)
                .setCancelable(false)
                .show();

        AtomicInteger successfulCount = new AtomicInteger(0);
        AtomicInteger errorCount = new AtomicInteger(0);

        // Import images
        for (int i = 0; i < localPaths.length; i++) {
            String url = urls[i];

            OkGo.<File>get(url)
                    .execute(new FileCallback(HDR_FOLDER_PATH, fileNames[i]) {

                        @Override
                        public void onError(Response<File> response) {
                            super.onError(response);
                            errorCount.incrementAndGet();
                            checkDownloadCount();
                        }

                        @Override
                        public void onSuccess(Response<File> response) {
                            successfulCount.incrementAndGet();
                            checkDownloadCount();
                        }

                        private void checkDownloadCount() {
                            dialog.setMessage(getString(R.string.download_status, urls.length, successfulCount.intValue(), errorCount.intValue()));
                            if (successfulCount.intValue() + errorCount.intValue() >= urls.length) {
                                Toast.makeText(getContext(), "Success", Toast.LENGTH_LONG).show();

                                importImagesBinding.importTextProgress.setVisibility(View.VISIBLE);
                                importImagesBinding.importTextProgress.setText(getString(R.string.import_images_completed, successfulCount.intValue(), urls.length));
                                dialog.dismiss();
                            }
                        }
                    });
        }
    }

    private String getFileNameFromUrl(String url) {
        return url.substring(url.lastIndexOf("/") + 1);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (importImagesBinding != null) {
            importImagesBinding = null;
        }
        InstaCameraManager.getInstance().unregisterCameraChangedCallback(this);
        InstaCameraManager.getInstance().closeCamera();
    }

    @Override
    public void onCameraStatusChanged(boolean enabled){
        if(cameraConnectionBottomSheetFragment != null) cameraConnectionBottomSheetFragment.dismiss();

        downloadImages(imagesToBeDownloaded);
    }


}