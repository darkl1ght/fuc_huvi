package com.huviair.capture.services;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.TaskStackBuilder;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.huviair.capture.R;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.Notification;
import com.huviair.capture.ui.snags.SnagActivity;
import com.huviair.capture.utils.SharedPreferencesManager;

import java.util.Map;
import java.util.UUID;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;


public class CaptureFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "CaptureFirebaseMessagingService";
    private static final String APP_TYPE_CAPTURE = "APP001";


    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
             sendNotification(remoteMessage.getData());
        }
    }
    // [END receive_message]


    // [START on_new_token]

    /**
     * There are two scenarios when onNewToken is called:
     * 1) When a new token is generated on initial app startup
     * 2) Whenever an existing token is changed
     * Under #2, there are three scenarios when the existing token is changed:
     * A) App is restored to a new device
     * B) User uninstalls/reinstalls the app
     * C) User clears app data
     */
    @Override
    public void onNewToken(@NonNull String token) {
         saveRegistrationToken(token);
    }

    // [END on_new_token]

    /**
     * Persist token to third-party servers.
     * <p>
     * Modify this method to associate the user's FCM registration token with any
     * server-side account maintained by your application.
     *
     * @param token The new token.
     */
    private void saveRegistrationToken(String token) {
        SharedPreferencesManager sharedPreferencesManager = new SharedPreferencesManager(this);
        sharedPreferencesManager.setGcmRegistrationToken(token);

        // Save the token to server if the user is logged in
        if (sharedPreferencesManager.isLoggedIn()) {
            String androidUniqueDeviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

            APIService apiService = APIClient.createService(APIService.class, this, APIClient.getProjectApiBaseUrl(), sharedPreferencesManager.getJwtToken());
            apiService.saveMessagingToken(APP_TYPE_CAPTURE, new Notification(token, androidUniqueDeviceId))
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .subscribe();
        }
    }

    /**
     * Create and show a simple notification containing the received FCM message.
     *
     * @param messageBody FCM message body received.
     */
    private void sendNotification(Map<String, String> messageBody) {

        // Create an Intent for the activity you want to start
        Intent resultIntent = new Intent(this, SnagActivity.class);
        messageBody.forEach(resultIntent::putExtra);

        // Create the TaskStackBuilder and add the intent, which inflates the back stack
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addNextIntentWithParentStack(resultIntent);


        // Get the PendingIntent containing the entire back stack
        PendingIntent resultPendingIntent =
                stackBuilder.getPendingIntent(UUID.randomUUID().hashCode(), PendingIntent.FLAG_IMMUTABLE);

        String channelId = "Capture channel";
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
        bigTextStyle.bigText(messageBody.get("body"));
        bigTextStyle.setSummaryText("Tap to view details");

        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(this, channelId)
                        .setSmallIcon(R.drawable.ic_stat_image_1)
                        .setLargeIcon(Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.notification_punch_list_icon), 128, 128, false))
                        .setStyle(bigTextStyle)
                        .setColor(getColor(R.color.brand_color))
                        .setContentTitle(messageBody.get("title"))
                        .setContentText(messageBody.get("body"))
                        .setAutoCancel(true)
                        .setSound(defaultSoundUri)
                        .setContentIntent(resultPendingIntent)
                        .setLights(Color.BLUE, 3000, 3000);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId,
                    "Snags",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify( UUID.randomUUID().hashCode(), notificationBuilder.build());
    }
}