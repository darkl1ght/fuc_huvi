package com.huviair.capture.data.model.api.aerial;

public class AerialImageRequest {
    private AerialTourRequest image;

    public AerialTourRequest getImage() {
        return image;
    }

    public void setImage(AerialTourRequest image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "AerialImageRequest{" +
                "image=" + image +
                '}';
    }
}
