package com.huviair.capture.data.model.api.snags;

import com.google.gson.annotations.Expose;

public class SavedSnagResponse {

    private Snag punchItem;

    public SavedSnagResponse(Snag punchItem) {
        this.punchItem = punchItem;
    }

    @Expose(deserialize = false, serialize = false)
    private int position;

    public Snag getPunchItem() {
        return punchItem;
    }

    public void setPunchItem(Snag punchItem) {
        this.punchItem = punchItem;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }


}

