package com.huviair.capture.ui.interiors.tours;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.work.WorkInfo;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.arashivision.sdkcamera.camera.callback.ICaptureStatusListener;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.bumptech.glide.signature.ObjectKey;
import com.davemorrissey.labs.subscaleview.ImageSource;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.model.database.InteriorWalkthrough;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.data.model.others.SavedFloorPlanPin;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.databinding.ActivityTourMapBinding;
import com.huviair.capture.ui.insta360.BaseObserveCameraActivity;
import com.huviair.capture.ui.insta360.CameraConnectionBottomSheetFragment;
import com.huviair.capture.ui.insta360.CaptureActivity;
import com.huviair.capture.ui.insta360.PreviewImageActivity;
import com.huviair.capture.ui.interiors.help.InteriorHelpActivity;
import com.huviair.capture.ui.interiors.interiorsDataExport.InteriorTourSettingsActivity;
import com.huviair.capture.ui.interiors.interiorsDataExport.TourDataTransferFragmentActivity;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.GlideApp;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.viewmodels.WalkthroughMapViewModel;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.FileCallback;
import com.lzy.okgo.model.Response;

import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class WalkThroughPlanActivity extends BaseObserveCameraActivity implements SensorEventListener, ICaptureStatusListener {

    public static final String WALK_THROUGH_DETAILS = "WALK_THROUGH_DETAILS";
    public static final String PROJECT_ID = "PROJECT_ID";
    public static double percentIncreaseDecreaseWidth;
    public static double percentIncreaseDecreaseHeight;
    private MaterialAlertDialogBuilder manualPublishDialog, readyForCaptureDialog;
    private CameraConnectionBottomSheetFragment cameraConnectionBottomSheetFragment;

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();

    // Sensor related variables
    private final float[] accelerometerReading = new float[3];
    private final float[] magnetometerReading = new float[3];
    private final float[] rotationMatrix = new float[9];
    private final float[] orientationAngles = new float[3];

    private ActivityTourMapBinding walkThroughPlanBinding;
    private WalkthroughMapViewModel walkthroughMapViewModel;

    private boolean isAllFabsVisible = false;
    private double floorPlanOrigHeight, floorPlanOrigWidth;
    private String IMPORTED_IMAGES_PATH = null;

    ActivityResultLauncher<Intent> startCaptureActivity = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent activityResult = result.getData();

                    boolean saveImage = activityResult.getBooleanExtra(CaptureActivity.SAVE_IMAGE, false);
                    String capturedImagePath = activityResult.getStringExtra(CaptureActivity.CAPTURED_IMAGE_PATH);
                    double offsetFromNorth = activityResult.getDoubleExtra(CaptureActivity.OFFSET_FROM_NORTH, 0);

                    if (saveImage) {
                        //Projecting the coordinates back to original scale
                        double projectedXCoordinate = walkthroughMapViewModel.getCurrentMarkerCoordinates().x / percentIncreaseDecreaseWidth;
                        double projectedYCoordinate = floorPlanOrigHeight - (walkthroughMapViewModel.getCurrentMarkerCoordinates().y / percentIncreaseDecreaseHeight);

                        DataCaptureRoomDatabase db = DataCaptureRoomDatabase.getDatabase(this);
                        TourDetails tourDetails = new TourDetails(capturedImagePath, walkthroughMapViewModel.getSelectedWalkThrough().getTourId(),
                                walkthroughMapViewModel.getSelectedWalkThrough().getInteriorId(), false, projectedXCoordinate, projectedYCoordinate, null, offsetFromNorth);

                        db.tourDetailsDAO().getLastInsertedWalkThroughCount(tourDetails.getTourId())
                                .flatMap(count -> {
                                    tourDetails.setImageNumber(count.intValue() + 1);
                                    return db.tourDetailsDAO().insertTour(tourDetails);
                                }).observeOn(AndroidSchedulers.mainThread())
                                .subscribeOn(Schedulers.io())
                                .subscribe(new DisposableSingleObserver<Long>() {
                                    @Override
                                    public void onSuccess(@io.reactivex.annotations.NonNull Long count) {
                                        PointF coordinatesOfImage = new PointF(walkthroughMapViewModel.getCurrentMarkerCoordinates().x, walkthroughMapViewModel.getCurrentMarkerCoordinates().y);
                                        walkThroughPlanBinding.imageView.setPin(new SavedFloorPlanPin(coordinatesOfImage, tourDetails.getImageNumber(), tourDetails.getImageNumber()));
                                        walkThroughPlanBinding.imageView.setVisibility(View.GONE);
                                        walkThroughPlanBinding.loadingImage.setVisibility(View.VISIBLE);

                                        // Download image to storage in the background
                                        importImagesToStorage(tourDetails.getImageUrl());
                                    }

                                    @Override
                                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                                        walkThroughPlanBinding.imageView.setVisibility(View.VISIBLE);
                                        Toast.makeText(WalkThroughPlanActivity.this, "Something went wrong.. Try Again", Toast.LENGTH_LONG).show();
                                    }
                                });
                    }
                }
            }
    );

    private SensorManager sensorManager;
    private SharedPreferencesManager sharedPreferencesManager;
    private double capturedOrientationAngle = 0.0d;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        IMPORTED_IMAGES_PATH = getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER;

        walkThroughPlanBinding = ActivityTourMapBinding.inflate(getLayoutInflater());
        setContentView(walkThroughPlanBinding.getRoot());

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        //Setup view model
        walkthroughMapViewModel = new ViewModelProvider(this).get(WalkthroughMapViewModel.class);

        // Get the project details from parent intent
        if (getIntent().getExtras() != null) {
            String projectId = getIntent().getStringExtra(PROJECT_ID);

            Tour selectedWalkthrough = (Tour) getIntent().getSerializableExtra(WALK_THROUGH_DETAILS);

            //Safety Check
            if (projectId == null) {
                finish();
            }
            walkthroughMapViewModel.setProjectId(projectId);
            walkthroughMapViewModel.setSelectedWalkThrough(selectedWalkthrough);
        }

        // Disable expandable fabs
        toggleFabAndCorrespondingTextViews(false);

        listenForFabClicks();

        // Show loaders
        walkThroughPlanBinding.loadingImage.setVisibility(View.VISIBLE);
        walkThroughPlanBinding.loadingText.setVisibility(View.VISIBLE);


        compositeDisposable.add(fetchTourDetailsFromDatabase(walkthroughMapViewModel.getSelectedWalkThrough().getTourId())
                .doAfterSuccess(interiorWalkthrough -> {
                    //Populate existing floor plan path
                    walkthroughMapViewModel.getSelectedWalkThrough().builder(interiorWalkthrough);
                    loadImages(walkthroughMapViewModel.getSelectedWalkThrough().getFloorPlanPath());

                    sharedPreferencesManager = new SharedPreferencesManager(this);

                    if (!sharedPreferencesManager.isInstaCameraPreviewEnabled() && super.isCameraConnected()) {
                        InstaCameraManager.getInstance().setCaptureStatusListener(this);
                    }

                    final GestureDetector gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
                        // On Single tap, if image exists get image number
                        @Override
                        public boolean onSingleTapConfirmed(MotionEvent e) {
                            if (walkThroughPlanBinding.imageView.isReady()) {
                                walkthroughMapViewModel.setCurrentMarkerCoordinates(walkThroughPlanBinding.imageView.viewToSourceCoord(e.getX(), e.getY()));

                                long imageNumber = walkThroughPlanBinding.imageView.getImageNumber(walkthroughMapViewModel.getCurrentMarkerCoordinates());
                                long displayImageNumber = walkThroughPlanBinding.imageView.getDisplayImageNumber(walkthroughMapViewModel.getCurrentMarkerCoordinates());

                                // if image number is invalid, do nothing
                                if (imageNumber != -1)
                                    openBottomSheetForReview(displayImageNumber, imageNumber);

                            } else {
                                Toast.makeText(getApplicationContext(), "Image not ready...", Toast.LENGTH_SHORT).show();
                            }
                            return super.onSingleTapConfirmed(e);
                        }

                        // On long press, get the coordinates and invoke respective activities for data capture
                        @Override
                        public void onLongPress(MotionEvent e) {
                            if (walkThroughPlanBinding.imageView.isReady()) {
                                walkthroughMapViewModel.setCurrentMarkerCoordinates(walkThroughPlanBinding.imageView.viewToSourceCoord(e.getX(), e.getY()));

                                // Get Coordinates of the image surface only
                                if ((0 < walkthroughMapViewModel.getCurrentMarkerCoordinates().y) &&
                                        (walkthroughMapViewModel.getCurrentMarkerCoordinates().y <= walkThroughPlanBinding.imageView.getSHeight())) {

                                    if (sharedPreferencesManager.isInstaCameraPreviewEnabled()) {
                                        captureImageWithCameraPreview();
                                    } else {
                                        captureImageWithoutPreview();
                                    }
                                }
                            } else {
                                Toast.makeText(getApplicationContext(), "Image not ready...", Toast.LENGTH_SHORT).show();
                            }
                        }

                    });

                    walkThroughPlanBinding.imageView.setOnTouchListener((view, motionEvent) -> gestureDetector.onTouchEvent(motionEvent));

                    addViewModelDataObservers();
                })
                .subscribe());


        buildDialogs();
    }

    private void buildDialogs(){

        manualPublishDialog = new MaterialAlertDialogBuilder(this)
                .setTitle("Facing issues in processing data?")
                .setMessage("Try the manual publish way")
                .setPositiveButton(getResources().getString(R.string.publish_manually), (dialog, which) -> {
                    Intent intent = new Intent(this, TourDataTransferFragmentActivity.class);
                    intent.putExtra(TourDataTransferFragmentActivity.TOUR_ID, walkthroughMapViewModel.getSelectedWalkThrough().getTourId());
                    intent.putExtra(TourDataTransferFragmentActivity.INTERIOR_ID, walkthroughMapViewModel.getSelectedWalkThrough().getInteriorId());
                    intent.putExtra(TourDataTransferFragmentActivity.PROJECT_ID, walkthroughMapViewModel.getSelectedWalkThrough().getProjectId());
                    startActivity(intent);
                })
                .setNegativeButton(getResources().getString(R.string.ignore), null)
                .setIcon(R.drawable.exclamation_icon);


        readyForCaptureDialog = new MaterialAlertDialogBuilder(this)
                .setTitle("Ready for capture !!")
                .setMessage("Camera connected successfully, long press at the desired location to start the capture")
                .setPositiveButton(getResources().getString(R.string.button_ok), null)
                .setIcon(R.drawable.add_photo_icon);


    }


    private void addViewModelDataObservers() {
        walkthroughMapViewModel.isImageDeleted.observe(this, isRefreshed -> {
            if (isRefreshed) {
                populateSavedPointsOnMap();
            }
        });

        walkthroughMapViewModel.isImageReviewed.observe(this, number -> {
            DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(this);
            compositeDisposable.add(database.tourDetailsDAO().getImageUrls(walkthroughMapViewModel.getSelectedWalkThrough().getTourId(), number)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(imageDetails -> {
                        walkthroughMapViewModel.setCurrentImage(imageDetails.split(","));
                        startImagePreviewActivity();
                    }));
        });

        walkthroughMapViewModel.previousMarkerCoordinates.observe(this, previousFeatures -> {
            if (previousFeatures != null) {
                walkThroughPlanBinding.imageView.clearPreviousMarkers();

                for (int imageNumber = 0; imageNumber < previousFeatures.size(); imageNumber++) {
                    // Project back the y coordinate to the coordinate system of android
                    double projectedYCoordinate = floorPlanOrigHeight - previousFeatures.get(imageNumber).getGeometry().getYCoordinate();
                    double xCoordinate = previousFeatures.get(imageNumber).getGeometry().getXCoordinate();
                    // Create a new point and add to the plan
                    PointF point = new PointF((float) xCoordinate, (float) projectedYCoordinate);

                    // Populate coordinates and draw marker
                    walkThroughPlanBinding.imageView.populatePreviousPinCoordinates(new SavedFloorPlanPin(point, imageNumber, imageNumber + 1));
                }
                if (walkThroughPlanBinding.imageView.isReady()) {
                    walkThroughPlanBinding.imageView.initialiseAndInvalidate();
                }
            }

        });

        walkthroughMapViewModel.isShowingPreviousMarkers.observe(this, isShowingMarkers -> {
            walkThroughPlanBinding.togglePreviousMarkers.setImageResource(isShowingMarkers ?
                    R.drawable.eye_not_visible_icon : R.drawable.eye_visible_icon);
            walkThroughPlanBinding.toggleMarkersTextView.setText(isShowingMarkers ? R.string.hide_captured_points
                    : R.string.view_captured_points);
        });

        walkthroughMapViewModel.showLoadingState.observe(this, isLoading -> {
            walkThroughPlanBinding.imageView.setVisibility(isLoading ? View.GONE : View.VISIBLE);
            walkThroughPlanBinding.loadingImage.setVisibility(isLoading ? View.VISIBLE : View.GONE);

            if (isLoading) walkThroughPlanBinding.downloadOneTimeFloorPlan.setVisibility(View.GONE);

            isAllFabsVisible = false;
            toggleFabAndCorrespondingTextViews(false);
        });

        walkthroughMapViewModel.noMarkersAvailable.observe(this, noMarkers -> showSnackBarMessage(getString(R.string.no_capture_points_available), R.color.snackbar_error));

        walkthroughMapViewModel.isErrorInFetchingMarkers.observe(this, isError -> showSnackBarMessage(getString(R.string.unable_to_fetch_markers), R.color.snackbar_error));

        walkthroughMapViewModel.isFloorPlanDownloaded.observe(this, floorPlanDownloaded -> {
            if (floorPlanDownloaded) {
                walkThroughPlanBinding.downloadOneTimeFloorPlan.setVisibility(View.GONE);
                loadImages(walkthroughMapViewModel.getSelectedWalkThrough().getFloorPlanPath());
            }
        });

        walkthroughMapViewModel.getWorkManager().getWorkInfosForUniqueWorkLiveData(walkthroughMapViewModel.getSelectedWalkThrough().getTourId())
                .observe(this, workInfos -> {
                    if (workInfos.size() > 0) {
                        if (workInfos.stream().anyMatch(workInfo -> WorkInfo.State.CANCELLED == workInfo.getState())) {
                            walkthroughMapViewModel.clearAllProcessedData();
                            walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.GONE);
                            walkThroughPlanBinding.cancelProcessing.setVisibility(View.GONE);
                            walkThroughPlanBinding.captureStatus.setText(R.string.capture_capture_working);
                        }
                        else if (workInfos.stream().allMatch(workInfo -> WorkInfo.State.SUCCEEDED == workInfo.getState())) {
                            walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.GONE);
                            walkThroughPlanBinding.cancelProcessing.setVisibility(View.GONE);
                            walkThroughPlanBinding.captureStatus.setText(R.string.capture_capture_working);
                            showSnackBarMessage("Walkthrough processing complete", R.color.snackbar_success);
                        }
                        else if (workInfos.stream().anyMatch(workInfo ->
                                WorkInfo.State.RUNNING == workInfo.getState())) {
                            walkThroughPlanBinding.captureStatus.setText(R.string.processing_data);
                            walkThroughPlanBinding.cancelProcessing.setVisibility(View.VISIBLE);
                            walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.VISIBLE);
                        }
                        else if (workInfos.stream().anyMatch(workInfo ->
                                WorkInfo.State.FAILED == workInfo.getState())) {
                            walkthroughMapViewModel.clearAllProcessedData();
                            walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.GONE);
                            walkThroughPlanBinding.cancelProcessing.setVisibility(View.GONE);
                            walkThroughPlanBinding.captureStatus.setText(R.string.capture_capture_working);
                            manualPublishDialog.show();
                        }
                    }
                });
    }


    private Single<InteriorWalkthrough> fetchTourDetailsFromDatabase(String tourId) {
        DataCaptureRoomDatabase captureRoomDatabase = DataCaptureRoomDatabase.getDatabase(this);
        return captureRoomDatabase.projectCacheDAO()
                .getSavedTourDetails(tourId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    /**
     * Display a bottom sheet for deleting or reviewing image
     *
     * @param displayImageNumber
     * @param imageNumber
     */
    private void openBottomSheetForReview(long displayImageNumber, long imageNumber) {
        ReviewMarkerBottomSheetFragment reviewMarkerBottomSheetFragment = ReviewMarkerBottomSheetFragment.newInstance(displayImageNumber, imageNumber);
        reviewMarkerBottomSheetFragment.show(getSupportFragmentManager(), "this");
    }

    /**
     * Display a bottom sheet for showing user to connect
     */
    private void openBottomSheetForConnection() {
        cameraConnectionBottomSheetFragment = CameraConnectionBottomSheetFragment.newInstance();
        cameraConnectionBottomSheetFragment.show(getSupportFragmentManager(), "this");
    }

    private void listenForFabClicks() {
        walkThroughPlanBinding.actionsExtendedFab.setOnClickListener(v -> {
            if (!isAllFabsVisible) {
                toggleFabAndCorrespondingTextViews(true);
                isAllFabsVisible = true;
            } else {
                toggleFabAndCorrespondingTextViews(false);
                isAllFabsVisible = false;
            }
        });

        walkThroughPlanBinding.tourSettingsFab.setOnClickListener(v -> startInteriorSettingsActivity());

        walkThroughPlanBinding.startProcessingTour.setOnClickListener(v -> {
            DataCaptureRoomDatabase captureRoomDatabase = DataCaptureRoomDatabase.getDatabase(this);
            compositeDisposable.add(captureRoomDatabase.tourDetailsDAO().getSavedTourDetails(walkthroughMapViewModel.getSelectedWalkThrough().getTourId())
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(tourDetails -> {
                        if (!tourDetails.isEmpty()) {
                            walkthroughMapViewModel.startProcessingCapturedImages();
                        } else showSnackBarMessage("No images available to process", R.color.snackbar_error);
                    }, throwable -> showSnackBarMessage("Walk-through couldn't be processed due to technical issues", R.color.snackbar_error)));

        });

        walkThroughPlanBinding.togglePreviousMarkers.setOnClickListener(v -> {
            if (walkthroughMapViewModel.isPreviousMarkerFetched && walkthroughMapViewModel.isShowingPreviousMarkers != null &&
                    !walkthroughMapViewModel.isShowingPreviousMarkers.getValue()) {
                walkthroughMapViewModel.previousMarkerCoordinates.setValue(walkthroughMapViewModel.previousMarkerCoordinatesClone.getValue());
                walkthroughMapViewModel.isShowingPreviousMarkers.setValue(true);
            } else {
                walkthroughMapViewModel.isShowingPreviousMarkers.setValue(false);
                walkthroughMapViewModel.previousMarkerCoordinates.setValue(Collections.emptyList());
                walkThroughPlanBinding.imageView.clearPreviousMarkers();
            }
        });

        walkThroughPlanBinding.help.setOnClickListener(v -> startInteriorHelpActivity());

        walkThroughPlanBinding.downloadOneTimeFloorPlan.setOnClickListener(view -> walkthroughMapViewModel.downloadFloorPlan());

        walkThroughPlanBinding.cancelProcessing.setOnClickListener(view -> {
            walkthroughMapViewModel.cancelProcessing();
            manualPublishDialog.show();
        });

        walkthroughMapViewModel.isAllLoadingComplete.observe(this, isAllLoadingComplete -> {
            if(isAllLoadingComplete && !super.isCameraConnected()) openBottomSheetForConnection();
        });

        walkthroughMapViewModel.isProcessingNotComplete.observe(this, isProcessingNotComplete -> {
            if(isProcessingNotComplete){
                new MaterialAlertDialogBuilder(this)
                        .setIcon(R.drawable.alert_icon_light_dark)
                        .setTitle("Leave without processing the data?")
                        .setCancelable(false)
                        .setMessage("Are you sure you want to leave without processing the captured data")
                        .setPositiveButton("Yes", (dialog, which) -> finish())
                        .setNegativeButton("No", null)
                        .show();
            }
            else finish();
        });
    }

    private void toggleFabAndCorrespondingTextViews(boolean enabled) {
        // Extended FAB shrink/extend
        if (enabled) walkThroughPlanBinding.actionsExtendedFab.extend();
        else walkThroughPlanBinding.actionsExtendedFab.shrink();

        int visibility = enabled ? View.VISIBLE : View.GONE;

        walkThroughPlanBinding.tourSettingsFab.setVisibility(visibility);
        walkThroughPlanBinding.startProcessingTour.setVisibility(visibility);
        walkThroughPlanBinding.togglePreviousMarkers.setVisibility(visibility);
        walkThroughPlanBinding.tourSettingsTextView.setVisibility(visibility);
        walkThroughPlanBinding.startProcessingTourTextView.setVisibility(visibility);
        walkThroughPlanBinding.toggleMarkersTextView.setVisibility(visibility);
        walkThroughPlanBinding.help.setVisibility(visibility);
        walkThroughPlanBinding.helpTextView.setVisibility(visibility);
    }

    private void loadImages(String urlToLoad) {
        // Load image using glide
        if (urlToLoad != null) {
            GlideApp.with(this).asBitmap()
                    .load(urlToLoad)
                    .apply(new RequestOptions().signature(new ObjectKey(String.valueOf(System.currentTimeMillis()))))
                    .listener(new RequestListener<Bitmap>() {
                        @Override
                        public boolean onLoadFailed(@androidx.annotation.Nullable GlideException e, Object model, Target<Bitmap> target, boolean isFirstResource) {
                            // On Image load fail
                            walkThroughPlanBinding.loadingImage.setVisibility(View.GONE);
                            walkThroughPlanBinding.loadingText.setText(getResources().getString(R.string.loading_floor_plan_failed));

                            Snackbar.make(findViewById(R.id.tour_map_layout), "Couldn't load floor plan, if it's uploaded already please sync the latest data", BaseTransientBottomBar.LENGTH_INDEFINITE)
                                    .setAnchorView(walkThroughPlanBinding.actionsExtendedFab)
                                    .show();
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Bitmap resource, Object model, Target<Bitmap> target, DataSource dataSource, boolean isFirstResource) {
                            return false;
                        }
                    })
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            floorPlanOrigHeight = resource.getHeight();
                            floorPlanOrigWidth = resource.getWidth();
                            walkThroughPlanBinding.imageView.setImage(ImageSource.bitmap(resource));

                            walkThroughPlanBinding.loadingImage.setVisibility(View.GONE);
                            walkThroughPlanBinding.loadingText.setVisibility(View.GONE);

                            percentIncreaseDecreaseHeight = walkThroughPlanBinding.imageView.getSHeight() / floorPlanOrigHeight;
                            percentIncreaseDecreaseWidth = walkThroughPlanBinding.imageView.getSWidth() / floorPlanOrigWidth;

                            populateSavedPointsOnMap();

                            // Fetch previous markers by default
                            walkthroughMapViewModel.getPreviousMarkersForInterior();

                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }

                    });

        }
        else {
            walkThroughPlanBinding.loadingImage.setVisibility(View.GONE);
            walkThroughPlanBinding.downloadOneTimeFloorPlan.setVisibility(View.VISIBLE);
            walkThroughPlanBinding.loadingText.setText("");

            Snackbar.make(findViewById(R.id.tour_map_layout), "Please download floor plan to get started", BaseTransientBottomBar.LENGTH_LONG)
                    .setAnchorView(walkThroughPlanBinding.actionsExtendedFab)
                    .show();
        }

    }

    /**
     * Used to prepopulate the saved markers (if any) on the respective tour floor plan
     */
    private void populateSavedPointsOnMap() {
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(this);
        database.tourDetailsDAO().getAllTourDetails(walkthroughMapViewModel.getSelectedWalkThrough().getTourId())
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<List<TourDetails>>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) {
                    }

                    @Override
                    public void onSuccess(@io.reactivex.annotations.NonNull List<TourDetails> tourDetails) {
                        // images Count
                        long mappedImagesCount = 0;

                        // Remove existing marker points (if any)
                        walkThroughPlanBinding.imageView.clearExistingImageCoordinates();

                        for (TourDetails tourFromDb : tourDetails) {
                            // Project back the y coordinate to the coordinate system of android
                            double projectedYCoordinate = floorPlanOrigHeight - tourFromDb.getYCoordinate();

                            // Create a new point and add to the plan
                            PointF point = new PointF((float) tourFromDb.getXCoordinate(), (float) projectedYCoordinate);

                            // Populate coordinates and draw marker
                            walkThroughPlanBinding.imageView.populatePinCoordinates(new SavedFloorPlanPin(point, tourFromDb.getImageNumber(), ++mappedImagesCount));
                        }
                        if (walkThroughPlanBinding.imageView.isReady()) {
                            walkThroughPlanBinding.imageView.initialiseAndInvalidate();
                        }
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {

                    }
                });

    }

    private void importImagesToStorage(@NonNull String imageUrl) {
        String[] imageUrls = imageUrl.split(",");

        AtomicInteger imagesDownloadedCount = new AtomicInteger(0);
        // Import images
        for (String url : imageUrls) {
            OkGo.<File>get(url)
                    .execute(new FileCallback(IMPORTED_IMAGES_PATH, getFileNameFromUrl(url)) {
                        @Override
                        public void onSuccess(Response<File> response) {
                            imagesDownloadedCount.getAndIncrement();
                            if (imagesDownloadedCount.get() == imageUrls.length) {
                                walkThroughPlanBinding.imageView.setVisibility(View.VISIBLE);
                                walkThroughPlanBinding.loadingImage.setVisibility(View.GONE);
                                walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.GONE);


                                Snackbar.make(findViewById(R.id.tour_map_layout), "Images downloaded successfully", BaseTransientBottomBar.LENGTH_SHORT)
                                        .setBackgroundTint(ContextCompat.getColor(WalkThroughPlanActivity.this, R.color.snackbar_success))
                                        .setAnchorView(walkThroughPlanBinding.actionsExtendedFab)
                                        .show();
                            }
                        }

                        @Override
                        public void onError(Response<File> response) {
                            super.onError(response);

                        }
                    });

        }
    }

    private String getFileNameFromUrl(String url) {
        return url.substring(url.lastIndexOf("/") + 1);
    }

    private void captureImageWithCameraPreview() {
        // If camera is already connected straightaway start the CaptureActivity, else open connection screen
        if (super.isCameraConnected())
            startCaptureActivity.launch(new Intent(this, CaptureActivity.class));

        else openBottomSheetForConnection();
    }

    private void startInteriorSettingsActivity() {
        Intent tourStatsIntent = new Intent(this, InteriorTourSettingsActivity.class);
        tourStatsIntent.putExtra(InteriorTourSettingsActivity.TOUR_ID, walkthroughMapViewModel.getSelectedWalkThrough().getTourId());
        tourStatsIntent.putExtra(InteriorTourSettingsActivity.INTERIOR_ID, walkthroughMapViewModel.getSelectedWalkThrough().getInteriorId());
        tourStatsIntent.putExtra(InteriorTourSettingsActivity.PROJECT_ID, walkthroughMapViewModel.getSelectedWalkThrough().getProjectId());
        startActivity(tourStatsIntent);
    }

    private void startInteriorHelpActivity() {
        startActivity(new Intent(this, InteriorHelpActivity.class));
    }

    private void startImagePreviewActivity() {
            Intent previewImageIntent = new Intent(this, PreviewImageActivity.class);
            previewImageIntent.putExtra(PreviewImageActivity.WORK_URLS, walkthroughMapViewModel.getCurrentImage());
            startActivity(previewImageIntent);

    }

    private void showSnackBarMessage(String text, int color) {
        Snackbar.make(walkThroughPlanBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_LONG)
                .setBackgroundTint(ContextCompat.getColor(this, color))
                .setTextColor(ContextCompat.getColor(this, R.color.white))
                .setAnchorView(walkThroughPlanBinding.actionsExtendedFab)
                .show();
    }

    private void showIndeterminateSnackBarMessage(String text, int color) {
        Snackbar.make(walkThroughPlanBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_INDEFINITE)
                .setBackgroundTint(ContextCompat.getColor(this, color))
                .setTextColor(ContextCompat.getColor(this, R.color.white))
                .setAnchorView(walkThroughPlanBinding.actionsExtendedFab)
                .show();
    }

    private void captureImageWithoutPreview() {
        if (!super.isCameraConnected()) {  openBottomSheetForConnection(); }
        else {
             capturedOrientationAngle = fetchCurrentOrientationAngle();

            // Set camera mode to panorama and start capture
            InstaCameraManager.getInstance().switchCameraMode(InstaCameraManager.CAMERA_MODE_PANORAMA, InstaCameraManager.FOCUS_SENSOR_ALL, null);
            InstaCameraManager.getInstance().startHDRCapture(false);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        InstaCameraManager.getInstance().setCaptureStatusListener(null);
        if (compositeDisposable != null && !compositeDisposable.isDisposed())
            compositeDisposable.dispose();
    }

    private String convertFilePathsToString(String[] filePaths) {
        StringBuilder filePathsToString = new StringBuilder();
        if (filePaths.length > 1) {
            for (int i = 0; i < filePaths.length; i++) {
                if (i == filePaths.length - 1) filePathsToString.append(filePaths[i]);
                else filePathsToString.append(filePaths[i]).append(",");
            }
            return filePathsToString.toString();
        }
        filePathsToString.append(filePaths[0]);
        return filePathsToString.toString();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            System.arraycopy(event.values, 0, accelerometerReading,
                    0, accelerometerReading.length);
        } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            System.arraycopy(event.values, 0, magnetometerReading,
                    0, magnetometerReading.length);
        }
    }

    // Compute the three orientation angles based on the most recent readings from
    // the device's accelerometer and magnetometer.
    public double fetchCurrentOrientationAngle() {
        // Update rotation matrix, which is needed to update orientation angles.
        SensorManager.getRotationMatrix(rotationMatrix, null,
                accelerometerReading, magnetometerReading);

        // "rotationMatrix" now has up-to-date information.
        float[] orientation = SensorManager.getOrientation(rotationMatrix, orientationAngles);

        // Convert output of -pi to pi --> 0 - 360
        return (Math.toDegrees(orientation[0]) + 360) % 360;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    @Override
    protected void onResume() {
        super.onResume();

        super.registerListener();

        // Get updates from the accelerometer and magnetometer at a constant rate.
        // To make batch operations more efficient and reduce power consumption,
        // provide support for delaying updates to the application.
        //
        // In this example, the sensor reporting delay is small enough such that
        // the application receives an update before the system checks the sensor
        // readings again.
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
        }
        Sensor magneticField = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (magneticField != null) {
            sensorManager.registerListener(this, magneticField,
                    SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
        }
    }

    // INSTA 360 overrides
    @Override
    public void onCameraBatteryLow() {
        super.onCameraBatteryLow();
        showIndeterminateSnackBarMessage("Camera battery running low", R.color.danger);
    }

    @Override
    public void onCameraStorageChanged(long freeSpace, long totalSpace) {
        super.onCameraStorageChanged(freeSpace, totalSpace);
        // 100mb threshold
        if(freeSpace < 100000000) showIndeterminateSnackBarMessage("Camera SD card storage running low", R.color.danger);
    }

    // Capture listener
    @Override
    public void onCaptureStarting() {
        ICaptureStatusListener.super.onCaptureStarting();
        walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.VISIBLE);
    }

    @Override
    public void onCaptureWorking() {
        ICaptureStatusListener.super.onCaptureWorking();
        walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.VISIBLE);
    }

    @Override
    public void onCaptureStopping() {
        ICaptureStatusListener.super.onCaptureStopping();
    }

    @Override
    public void onCaptureFinish(String[] fileUrls) {
        if (fileUrls != null && fileUrls.length > 0) {
            String capturedImagePath = convertFilePathsToString(fileUrls);
            //Projecting the coordinates back to original scale
            double projectedXCoordinate = walkthroughMapViewModel.getCurrentMarkerCoordinates().x / percentIncreaseDecreaseWidth;
            double projectedYCoordinate = floorPlanOrigHeight - (walkthroughMapViewModel.getCurrentMarkerCoordinates().y / percentIncreaseDecreaseHeight);

            DataCaptureRoomDatabase db = DataCaptureRoomDatabase.getDatabase(WalkThroughPlanActivity.this);
            TourDetails tourDetails = new TourDetails(capturedImagePath, walkthroughMapViewModel.getSelectedWalkThrough().getTourId(),
                    walkthroughMapViewModel.getSelectedWalkThrough().getInteriorId(), false,
                    projectedXCoordinate, projectedYCoordinate, null, capturedOrientationAngle);

            db.tourDetailsDAO().getLastInsertedWalkThroughCount(tourDetails.getTourId())
                    .flatMap(count -> {
                        tourDetails.setImageNumber(count.intValue() + 1);
                        return db.tourDetailsDAO().insertTour(tourDetails);
                    }).observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .subscribe(new DisposableSingleObserver<Long>() {
                        @Override
                        public void onSuccess(@io.reactivex.annotations.NonNull Long count) {
                            PointF coordinatesOfImage = new PointF(walkthroughMapViewModel.getCurrentMarkerCoordinates().x, walkthroughMapViewModel.getCurrentMarkerCoordinates().y);
                            walkThroughPlanBinding.imageView.setPin(new SavedFloorPlanPin(coordinatesOfImage, tourDetails.getImageNumber(), tourDetails.getImageNumber()));

                            // Download image to storage in the background
                            importImagesToStorage(tourDetails.getImageUrl());
                        }

                        @Override
                        public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                            walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.GONE);
                            Toast.makeText(WalkThroughPlanActivity.this, "Something went wrong.. Try Again", Toast.LENGTH_LONG).show();
                        }
                    });
        } else walkThroughPlanBinding.imageCaptureOverlay.setVisibility(View.GONE);
    }

    @Override
    public void onCameraStatusChanged(boolean enabled) {
        super.onCameraStatusChanged(enabled);
        if(enabled){
            // Switch camera mode
            InstaCameraManager.getInstance().switchCameraMode(InstaCameraManager.CAMERA_MODE_PANORAMA, InstaCameraManager.FOCUS_SENSOR_ALL, null);

            if(cameraConnectionBottomSheetFragment != null) cameraConnectionBottomSheetFragment.dismiss();

            if(sharedPreferencesManager != null && !sharedPreferencesManager.isInstaCameraPreviewEnabled()){
                InstaCameraManager.getInstance().setCaptureStatusListener(WalkThroughPlanActivity.this);
            }

            readyForCaptureDialog.show();

            Toast.makeText(this, R.string.main_toast_camera_connected, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.main_toast_camera_disconnected, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onCameraConnectError(int errorCode) {
        super.onCameraConnectError(errorCode);

        if(cameraConnectionBottomSheetFragment != null)
            cameraConnectionBottomSheetFragment.showProgressBarAndDisableButtons( true);

        Toast.makeText(this, R.string.error_in_camera_connection, Toast.LENGTH_SHORT).show();

        if(sharedPreferencesManager != null && !sharedPreferencesManager.isInstaCameraPreviewEnabled())
            InstaCameraManager.getInstance().setCaptureStatusListener(null);
    }

    @Override
    protected void onStop() {
        super.onStop();
        sensorManager.unregisterListener(this);
        super.unregisterListener();
    }

    @Override
    public void onBackPressed() {
        walkthroughMapViewModel.checkProcessingStatus();
    }
}