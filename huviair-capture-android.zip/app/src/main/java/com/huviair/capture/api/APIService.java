package com.huviair.capture.api;

import com.huviair.capture.data.model.api.ForgotPasswordRequest;
import com.huviair.capture.data.model.api.ForgotPasswordResponse;
import com.huviair.capture.data.model.api.LoggedInUser;
import com.huviair.capture.data.model.api.LoginRequest;
import com.huviair.capture.data.model.api.Notification;
import com.huviair.capture.data.model.api.UsersResponse;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.common.CommonResponse;
import com.huviair.capture.data.model.api.projects.ProjectList;
import com.huviair.capture.data.model.api.tours.InteriorsResponse;
import com.huviair.capture.data.model.api.tours.TourWalkThroughRequest;
import com.huviair.capture.data.model.api.tours.VideocaptureRequest;
import com.huviair.capture.data.model.api.tours.Walkthrough;
import com.huviair.capture.data.model.api.tours.interiorsResponse.WalkThroughResponse;
import com.huviair.capture.data.model.api.SendLogRequest;

import io.reactivex.Completable;
import io.reactivex.Single;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Url;

/**
 * Interface provides different API functionality for interacting with the Node.js backend
 */
public interface APIService {

    @POST
    Single<LoggedInUser> login(@Url String url, @Body LoginRequest loginRequest);

    @POST("users/forgot")
    Single<ForgotPasswordResponse> resetPassword(@Body ForgotPasswordRequest forgotPasswordRequest);

    @POST("api/notifications/{appType}")
    Completable saveMessagingToken(@Path("appType") String appType , @Body Notification notification);

    @DELETE("api/notifications/{appType}/{token}/{deviceId}")
    Completable deleteMessagingToken(@Path("appType") String appType, @Path("token") String token , @Path("deviceId") String deviceId);

    @GET("api/")
    Single<ProjectList> getProjects();

    @GET("api/{project_id}/users")
    Single<UsersResponse> getUsersAssociatedToProject(String projectId);

    @GET("api/virtualtour/{project_id}/interiors-and-walkthroughs")
    Single<InteriorsResponse> getInteriorsAndWalkthroughs(@Path("project_id") String projectId);

    @PUT("api/virtualtour/{project_id}/interiors/{interior_id}/tour/{tour_id}/publish")
    Call<Void> updateInteriorPublishDetails(@Path("project_id") String projectId, @Path("interior_id") String interiorId, @Path("tour_id") String tourId);

    @GET("api/virtualtour/{project_id}/interior/{tour_id}")
    Single<WalkThroughResponse> getWalkThroughDetails(@Path("project_id") String projectId, @Path("tour_id") String tourId);

    @GET("api/azureblob/sas/read/{request_type}/")
    Call<AzureTokenResponse> getAzureToken(@Path("request_type") String reqType);

    @GET("api/azureblob/sas/read/{request_type}/")
    Single<AzureTokenResponse> getAzureTokenByRequest(@Path("request_type") String reqType);

    @GET("api/azureblob/sas/{request_type}/")
    Single<AzureTokenResponse> getAzureTokenWritePermission(@Path("request_type") String reqType);

    @GET("api/azureblob//sas/longRunningTask/{request_container}/")
    Single<AzureTokenResponse> getAzureTokenForLongRunningTask(@Path("request_container") String reqType);

    @PUT("api/virtualtour/{project_id}/interiors/{interior_id}/tour/{tour_id}/imagesAndFeatures")
    Single<CommonResponse> updateTourDetails(@Path("project_id") String projectId, @Path("interior_id") String interiorId, @Path("tour_id") String tourId, @Body TourWalkThroughRequest request);

    @GET("api/virtualtour/{project_id}/interiors/{interior_id}/tour/{tour_id}/previous-tour-details")
    Single<Walkthrough> getPreviousWalkthrough(@Path("project_id") String projectId, @Path("interior_id") String interiorId, @Path("tour_id") String tourId);

    @PUT("api/virtualtour/videocapture/{project_id}/tour/{tour_id}/video-capture-details")
    Single<CommonResponse> updateVideoCaptureDetails(@Path("project_id") String projectId, @Path("tour_id") String tourId, @Body VideocaptureRequest request);

    @POST("api/captureapplog/log")
    Single<CommonResponse> sendLogs(@Body SendLogRequest sendLogs);
}
