package com.huviair.capture.data.model.api.tours;

import com.huviair.capture.ui.interiors.tours.Coordinates;

public class VideocaptureRequest {

    private String[] rawVideoStorageRefs;
    private Coordinates captureStartPoint;

    public VideocaptureRequest(String[] rawVideoStorageRefs, Coordinates captureStartPoint, Coordinates captureEndPoint) {
        this.rawVideoStorageRefs = rawVideoStorageRefs;
        this.captureStartPoint = captureStartPoint;
        this.captureEndPoint = captureEndPoint;
    }

    private Coordinates captureEndPoint;


    public String[] getRawVideoStorageRefs() {
        return rawVideoStorageRefs;
    }

    public void setRawVideoStorageRefs(String[] rawVideoStorageRefs) {
        this.rawVideoStorageRefs = rawVideoStorageRefs;
    }

    public Coordinates getCaptureStartPoint() {
        return captureStartPoint;
    }

    public void setCaptureStartPoint(Coordinates captureStartPoint) {
        this.captureStartPoint = captureStartPoint;
    }

    public Coordinates getCaptureEndPoint() {
        return captureEndPoint;
    }

    public void setCaptureEndPoint(Coordinates captureEndPoint) {
        this.captureEndPoint = captureEndPoint;
    }
}
