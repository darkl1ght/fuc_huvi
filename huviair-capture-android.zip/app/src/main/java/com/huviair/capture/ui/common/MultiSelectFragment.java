package com.huviair.capture.ui.common;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.huviair.capture.adapters.MultiSelectRecyclerViewAdapter;
import com.huviair.capture.databinding.MultiselectFragmentBinding;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * A fragment representing a list of Items.
 */
public class MultiSelectFragment extends DialogFragment {

    private List<MultiSelectViewItem> multiSelectViewItemList;
    private MultiselectFragmentBinding multiselectFragmentBinding;
    private MultiSelectRecyclerViewAdapter multiSelectRecyclerViewAdapter;

    private OnSaveClickListener onSaveClickListener;
    private final static String MULTI_SELECT_LIST = "MULTI_SELECT_LIST";
    private final static String TITLE = "TITLE";
    private final static String SEARCH_HINT = "SEARCH_HINT";

    private String title;
    private String searchHint;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public MultiSelectFragment() {

    }

    public interface OnSaveClickListener {
        void onSave(List<MultiSelectViewItem> multiSelectViewItems);
    }

    public static MultiSelectFragment newInstance(List<MultiSelectViewItem> multiSelectViewItemsList, String title, String searchHint) {
        MultiSelectFragment fragment = new MultiSelectFragment();
        Bundle args = new Bundle();
        args.putParcelableArrayList(MULTI_SELECT_LIST, (ArrayList<? extends Parcelable>) multiSelectViewItemsList);
        args.putString(TITLE, title);
        args.putString(SEARCH_HINT, searchHint);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            multiSelectViewItemList = getArguments().getParcelableArrayList(MULTI_SELECT_LIST);
            title = getArguments().getString(TITLE);
            searchHint = getArguments().getString(SEARCH_HINT);
        }
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        multiselectFragmentBinding = MultiselectFragmentBinding.inflate(inflater, container, false);

        View view = multiselectFragmentBinding.getRoot();
        Context context = view.getContext();
        RecyclerView recyclerView = multiselectFragmentBinding.list;
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        multiSelectRecyclerViewAdapter = new MultiSelectRecyclerViewAdapter(multiSelectViewItemList);
        recyclerView.setAdapter(multiSelectRecyclerViewAdapter);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        multiselectFragmentBinding.closeItem.setOnClickListener(v -> dismiss());
        multiselectFragmentBinding.saveItems.setOnClickListener(v -> {
            onSaveClickListener.onSave(multiSelectRecyclerViewAdapter.getFilteredValues());
            dismiss();
        });

        multiselectFragmentBinding.multiselectDialogTitle.setText(title);
        multiselectFragmentBinding.searchView.setHint(searchHint);

        multiselectFragmentBinding.searchView.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (multiSelectRecyclerViewAdapter != null) {
                    multiSelectRecyclerViewAdapter.getFilter().filter(s);
                }
            }
        });

    }

    public void setOnSaveClickListener(OnSaveClickListener onSaveClickListener) {
        this.onSaveClickListener = onSaveClickListener;
    }
}