package com.huviair.capture.data.model.api.tours;

import java.io.Serializable;
import java.util.List;

public class Interior implements Serializable {

    private String interiorId;
    private String projectId;
    private String interiorName;
    private String interiorDate;
    private List<FloorWalkThroughCacheData> floorWalkthough;

    public Interior(String interiorId, String projectId, String interiorName) {
        this.interiorId = interiorId;
        this.projectId = projectId;
        this.interiorName = interiorName;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public void setInteriorId(String interiorId) {
        this.interiorId = interiorId;
    }

    public String getInteriorName() {
        return interiorName;
    }

    public void setInteriorName(String interiorName) {
        this.interiorName = interiorName;
    }

    public String getInteriorDate() {
        return interiorDate;
    }

    public void setInteriorDate(String interiorDate) {
        this.interiorDate = interiorDate;
    }

    public List<FloorWalkThroughCacheData> getFloorWalkthough() {
        return floorWalkthough;
    }

    public void setFloorWalkthough(List<FloorWalkThroughCacheData> floorWalkthough) {
        this.floorWalkthough = floorWalkthough;
    }

    @Override
    public String toString() {
        return "Interior{" +
                "interiorId='" + interiorId + '\'' +
                ", interiorName='" + interiorName + '\'' +
                ", interiorDate='" + interiorDate + '\'' +
                ", floorWalkThrough=" + floorWalkthough +
                '}';
    }
}