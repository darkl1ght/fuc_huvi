package com.huviair.capture.data.model.api.snags;

public class CreateOnsiteSnagRequest {
    private CreateOnsiteSnagDetails punchList;

    public CreateOnsiteSnagDetails getPunchList() {
        return punchList;
    }

    public void setPunchList(CreateOnsiteSnagDetails punchList) {
        this.punchList = punchList;
    }
}
