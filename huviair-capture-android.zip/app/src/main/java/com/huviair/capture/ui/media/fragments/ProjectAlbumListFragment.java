package com.huviair.capture.ui.media.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.databinding.FragmentAlbumListBinding;
import com.huviair.capture.viewmodels.AlbumsListViewModel;
import com.huviair.capture.adapters.ProjectAlbumsAdapter;

import org.jetbrains.annotations.NotNull;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProjectAlbumListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProjectAlbumListFragment extends Fragment {

    private static final String PROJECT_ID = "PROJECT_ID";

    private FragmentAlbumListBinding fragmentAlbumListBinding;
    private ProjectAlbumsAdapter albumsAdapter;
    private AlbumsListViewModel albumsListViewModel;

    private Parcelable state;
    private RecyclerView.LayoutManager layoutManager;

    private String projectId;
    private Snackbar snackbar;


    public ProjectAlbumListFragment() {
        // Required empty public constructor
    }


    public static ProjectAlbumListFragment newInstance(String projectId) {
        ProjectAlbumListFragment fragment = new ProjectAlbumListFragment();
        Bundle args = new Bundle();
        args.putString(PROJECT_ID, projectId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
        }
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        fragmentAlbumListBinding = FragmentAlbumListBinding.inflate(inflater, container, false);
        return fragmentAlbumListBinding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Enable bottom nav
        requireActivity().findViewById(R.id.bottom_navigation_media).setVisibility(View.VISIBLE);

        // Get the ViewModel bound to the activity
        albumsListViewModel = new ViewModelProvider(requireActivity()).get(AlbumsListViewModel.class);

        fragmentAlbumListBinding.listAlbumsBar.toolBar.setTitle("Albums");
        fragmentAlbumListBinding.listAlbumsBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        fragmentAlbumListBinding.listAlbumsBar.toolBar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        fragmentAlbumListBinding.loadingMedia.setVisibility(View.VISIBLE);

        // Fetch Albums
        albumsListViewModel.fetchMediaAlbums(projectId);

        // Set transition
        ViewCompat.setTransitionName(fragmentAlbumListBinding.fab, String.valueOf(fragmentAlbumListBinding.fab));

        fragmentAlbumListBinding.fab.setOnClickListener(v -> {
            CreateAlbumDialogFragment dialogFragment = CreateAlbumDialogFragment.newInstance(projectId);
            dialogFragment.show(getChildFragmentManager(), "Sample Fragment");
        });


        // Hide and show FAB add media based on scroll
        fragmentAlbumListBinding.recyclerAlbumsView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NotNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (dy > 0) {
                    // Scroll Down
                    if (fragmentAlbumListBinding.fab.isShown()) {
                        fragmentAlbumListBinding.fab.hide();
                    }
                } else if (dy < 0) {
                    // Scroll Up
                    if (!fragmentAlbumListBinding.fab.isShown()) {
                        fragmentAlbumListBinding.fab.show();
                    }
                }
            }
        });


        swipeToRefreshAlbums();

        observeForAlbumsChange();

        observeForLoadingStates();

        observeInternetConnection();
    }

    private void observeInternetConnection() {
        albumsListViewModel.isDataConnectionAvailable.observe(getViewLifecycleOwner(), isDataConnectionAvailable -> {
            if (!isDataConnectionAvailable) {
                fragmentAlbumListBinding.loadingMedia.setVisibility(View.GONE);

                Snackbar.make(fragmentAlbumListBinding.getRoot(), "No internet connection available", BaseTransientBottomBar.LENGTH_SHORT)
                        .setAnchorView(requireActivity().findViewById(R.id.bottom_navigation_media))
                        .show();
            }
        });
    }

    private void observeForLoadingStates() {

        albumsListViewModel.getIsLoadingData().observe(getViewLifecycleOwner(), isLoading -> {
            int visibility = isLoading ? View.VISIBLE : View.GONE;
            fragmentAlbumListBinding.loadingMedia.setVisibility(visibility);

            if (isLoading) {
                fragmentAlbumListBinding.fab.hide();
            } else fragmentAlbumListBinding.fab.show();

            // Disable recycler view and remove the no album found
            fragmentAlbumListBinding.recyclerAlbumsView.setVisibility(isLoading ? View.GONE : View.VISIBLE);
            fragmentAlbumListBinding.noAlbumFoundLayout.setVisibility(View.GONE);

        });

        // On error do stuff
        albumsListViewModel.getIsErrorInRetrieving().observe(getViewLifecycleOwner(), isError -> {
            int visibility = isError ? View.VISIBLE : View.GONE;
            fragmentAlbumListBinding.technicalErrorView.getRoot().setVisibility(visibility);
            fragmentAlbumListBinding.loadingMedia.setVisibility(isError ? View.GONE : View.VISIBLE);
            if (isError) {
                //Hide the existing recycler view
                fragmentAlbumListBinding.recyclerAlbumsView.setVisibility(View.GONE);

                snackbar = Snackbar.make(fragmentAlbumListBinding.getRoot(), "Oops..something went wrong", Snackbar.LENGTH_INDEFINITE);
                snackbar.setAction("RETRY", v -> albumsListViewModel.fetchMediaAlbums(projectId))
                        .setAnchorView(fragmentAlbumListBinding.fab)
                        .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                        .show();

            }
        });
    }

    private void observeForAlbumsChange() {
        albumsListViewModel.getProjectAlbums().observe(getViewLifecycleOwner(), albums -> {
            if (albums.size() > 0) {
                if (albumsAdapter == null) {
                    albumsAdapter = new ProjectAlbumsAdapter(requireActivity());
                    albumsAdapter.setAdapterData(albums);
                    populateRecyclerView();
                } else albumsAdapter.updateData(albums);

            } else {
                fragmentAlbumListBinding.noAlbumFoundLayout.setVisibility(View.VISIBLE);
            }
        });

        albumsListViewModel.isRefreshRequired.observe(getViewLifecycleOwner(), isAlbumCreated -> {
            if (isAlbumCreated) {
                albumsListViewModel.fetchMediaAlbums(projectId);
            }
        });
    }

    private void swipeToRefreshAlbums() {
        fragmentAlbumListBinding.refreshAlbums.setOnRefreshListener(() -> {
            if (snackbar != null) snackbar.dismiss();
            albumsListViewModel.fetchMediaAlbums(projectId);
            fragmentAlbumListBinding.refreshAlbums.setRefreshing(false);
        });
    }

    private void populateRecyclerView() {

        // Set Animation
        int resId = R.anim.grid_layout_animation_from_bottom;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(requireContext(), resId);
        fragmentAlbumListBinding.recyclerAlbumsView.setLayoutAnimation(animation);

        // Populate recycler view
        fragmentAlbumListBinding.recyclerAlbumsView.setHasFixedSize(true);
        fragmentAlbumListBinding.recyclerAlbumsView.setAdapter(albumsAdapter);

        // Save state and populate adapter
        layoutManager = new GridLayoutManager(requireContext(), 2);
        if (state != null) layoutManager.onRestoreInstanceState(state);
        fragmentAlbumListBinding.recyclerAlbumsView.setLayoutManager(layoutManager);

    }

    @Override
    public void onPause() {
        super.onPause();
        if (layoutManager != null) {
            state = layoutManager.onSaveInstanceState();
        }

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (fragmentAlbumListBinding != null) {
            fragmentAlbumListBinding = null;
        }
        if (albumsAdapter != null) {
            albumsAdapter = null;
        }
    }

}