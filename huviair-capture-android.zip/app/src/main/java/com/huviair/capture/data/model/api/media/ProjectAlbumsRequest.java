package com.huviair.capture.data.model.api.media;

public class ProjectAlbumsRequest {

    private Album album;

    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }
}
