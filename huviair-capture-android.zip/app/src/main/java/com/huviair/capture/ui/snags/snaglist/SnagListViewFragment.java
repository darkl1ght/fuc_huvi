package com.huviair.capture.ui.snags.snaglist;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.paging.LoadState;
import androidx.paging.PagingData;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.adapters.HeaderFooterAdapter;
import com.huviair.capture.adapters.SnagsListsAdapter;
import com.huviair.capture.adapters.diffUtil.SnagListDiffUtil;
import com.huviair.capture.data.model.api.snags.Config;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.databinding.SnagListViewFragmentBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.viewmodels.SnagListItemModel;
import com.huviair.capture.viewmodels.SnagViewModel;

import io.reactivex.disposables.CompositeDisposable;

public class SnagListViewFragment extends Fragment implements SnagsListsAdapter.SnagItemButtonClickListener {

    public static final String PROJECT_ID = "PROJECT_ID";
    public static final String QUERY_TYPE = "QUERY_TYPE";
    private static final String QUERY_STRING = "SEARCH_QUERY_STRING";
    private final CompositeDisposable bag = new CompositeDisposable();
    private SnagViewModel snagViewModel;
    private String projectId;
    private String snagQueryType;
    private SearchView searchView;
    private String searchQueryString = "";
    private SnagListViewFragmentBinding snagListViewFragmentBinding;

    private SnagsListsAdapter snagsListsAdapter = new SnagsListsAdapter(new SnagListDiffUtil(), this);

    private SnagListItemModel snagListItemViewModel;

    // Initialisation of the fragment
    public static SnagListViewFragment newInstance(String projectId, String queryType) {
        SnagListViewFragment snagListViewFragment = new SnagListViewFragment();
        Bundle args = new Bundle();
        args.putString(PROJECT_ID, projectId);
        args.putString(QUERY_TYPE, queryType);
        snagListViewFragment.setArguments(args);
        return snagListViewFragment;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
            snagQueryType = getArguments().getString(QUERY_TYPE);
        }
        if (savedInstanceState != null) {
            searchQueryString = savedInstanceState.getString(QUERY_STRING);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        snagListViewFragmentBinding = SnagListViewFragmentBinding.inflate(inflater, container, false);
        return snagListViewFragmentBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.VISIBLE);

        snagViewModel = new ViewModelProvider(requireActivity()).get(SnagViewModel.class);

        snagListItemViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication()))
                .get(SnagListItemModel.class);

        // Populate user email
        snagsListsAdapter.setLoggedInUserEmail(new SharedPreferencesManager(requireActivity()).getLoggedInUserEmail());

        // tool bar
        snagListViewFragmentBinding.snagListViewToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        snagListViewFragmentBinding.snagListViewToolBar.toolBar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());
        snagListViewFragmentBinding.snagListViewToolBar.toolBar.inflateMenu(R.menu.snag_list_view_menu);

        snagListViewFragmentBinding.snagListViewToolBar.toolBar.setTitle(snagQueryType);
       
        fetchSnags(projectId, snagQueryType, searchQueryString, getLatestAppliedFilterValues());
        

        bindViews();
        observeForSnagSaveChanges();
        observeForFloorPlanSaveChanges();
        observeForSnagDelete();
        searchSnagsMenu();
        progressOfAdapterData();
        observeForSnagFilters();
        listenToolBarIconsClick();
         if(snagQueryType.equalsIgnoreCase(CommonConstants.SNAG_DRAFT_ITEMS) ){
             snagsListsAdapter.setSnagType(CommonConstants.SNAG_DRAFT_ITEMS);
        } 
    }

    Config getLatestAppliedFilterValues() {
        if (snagListItemViewModel.getSnagFilters().getValue() == null) {
            return new Config();
        } else return snagListItemViewModel.getSnagFilters().getValue();
    }

    private void bindViews() {

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        snagListViewFragmentBinding.snagListRecyclerView.setLayoutManager(linearLayoutManager);
        snagListViewFragmentBinding.snagListRecyclerView.setHasFixedSize(true);
        snagListViewFragmentBinding.snagListRecyclerView.setAdapter(
                snagsListsAdapter.withLoadStateFooter(
                        new HeaderFooterAdapter(v -> snagsListsAdapter.retry())));

    }

    private void progressOfAdapterData() {
        snagsListsAdapter.addLoadStateListener(combinedLoadStates -> {
            // show empty list
            boolean isListEmpty = combinedLoadStates.getRefresh() instanceof LoadState.NotLoading && snagsListsAdapter.getItemCount() == 0;
            showEmptyList(isListEmpty);

            snagListViewFragmentBinding.snagListRecyclerView.setVisibility(combinedLoadStates.getRefresh() instanceof LoadState.NotLoading
                    ? View.VISIBLE : View.GONE);

            snagListViewFragmentBinding.loadingSnags.setVisibility(combinedLoadStates.getRefresh() instanceof LoadState.Loading
                    ? View.VISIBLE : View.GONE);

            if (combinedLoadStates.getRefresh() instanceof LoadState.Error) {
                Snackbar.make(snagListViewFragmentBinding.getRoot(), "Oops ! Unable to fetch snag details", Snackbar.LENGTH_INDEFINITE)
                        .setAction("RETRY", v -> fetchSnags(projectId, snagQueryType, null, null))
                        .setAnchorView(requireActivity().findViewById(R.id.bottom_navigation_snag))
                        .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                        .show();
            }
            return null;
        });

    }

    private void showEmptyList(boolean isListEmpty) {
        if (isListEmpty) {
            snagListViewFragmentBinding.emptyList.setVisibility(View.VISIBLE);
            snagListViewFragmentBinding.snagListRecyclerView.setVisibility(View.GONE);
        } else {
            snagListViewFragmentBinding.emptyList.setVisibility(View.GONE);
            snagListViewFragmentBinding.snagListRecyclerView.setVisibility(View.VISIBLE);
        }

    }

    private void observeForSnagSaveChanges() {
        snagListItemViewModel.getSavedSnagResponseMutableLiveData().observe(getViewLifecycleOwner(), savedSnagResponse -> {
            if (snagsListsAdapter != null) {
                showSnackBarMessage("Updated Snag Successfully", R.color.snackbar_success);
                fetchSnags(projectId, snagQueryType, searchQueryString, getLatestAppliedFilterValues());
            }
        });

        snagListItemViewModel.getIsSnagDataUpdated().observe(getViewLifecycleOwner(), isSnagSaved -> {
            if (snagsListsAdapter != null) {
                showSnackBarMessage("Updated Snag Successfully", R.color.snackbar_success);
                fetchSnags(projectId, snagQueryType, searchQueryString, getLatestAppliedFilterValues());
            }
        });
    }

    private void fetchSnags(String projectId, String queryType, @Nullable String taskDescQuery, @Nullable Config config) {
        bag.add(snagViewModel.fetchSnagsByQueryType(projectId, queryType, taskDescQuery, config)
                .subscribe(this::populateRecyclerView));
    }


    private void populateRecyclerView(PagingData<Snag> snagsDetailsList) {
        snagsListsAdapter.submitData(getViewLifecycleOwner().getLifecycle(), snagsDetailsList);
    }

    private void observeForFloorPlanSaveChanges() {
        snagViewModel.getIsFloorPlanSaved().observe(getViewLifecycleOwner(), savedSnagResponse -> {
            if (snagsListsAdapter != null) {
                fetchSnags(projectId, snagQueryType, searchQueryString, getLatestAppliedFilterValues());
            }
        });
    }


    @Override
    public void isButtonClicked(int viewId, Snag selectedSnag) {
        
        if (R.id.view_users_icon == viewId) {
            SnagAssigneeDialogFragment snagAssigneeDialogFragment = SnagAssigneeDialogFragment.newInstance(selectedSnag);
            snagAssigneeDialogFragment.show(getChildFragmentManager(), "Assignee");
        } else if (R.id.resolve_snag_level_1 == viewId) {
            SnagApproveBottomSheetFragment snagApproveBottomSheetFragment = SnagApproveBottomSheetFragment.newInstance(selectedSnag, "level1");
            snagApproveBottomSheetFragment.show(getChildFragmentManager(), "Level 1");
        } else if (R.id.resolve_snag_level_2 == viewId) {
            SnagApproveBottomSheetFragment snagApproveBottomSheetFragment = SnagApproveBottomSheetFragment.newInstance(selectedSnag, "level2");
            snagApproveBottomSheetFragment.show(getChildFragmentManager(), "Level2");
        } else if (R.id.floor_plan_button == viewId) {
            if (selectedSnag.getFloorPlan() == null) {
                Toast.makeText(requireContext(), "No Floor plan available", Toast.LENGTH_LONG).show();
            } else snagViewModel.setDisplayFloorPlanForSnag(selectedSnag, false);
        } else if (R.id.media_snag_button == viewId) {
            snagViewModel.setOpenMediaFragment(selectedSnag);
        } else if (R.id.view_media_icon == viewId) {
            selectedSnag.setIsOnsiteSnag(true);
            snagViewModel.setOpenMediaFragment(selectedSnag);
        } else if (R.id.action_update_snag == viewId) {
            SnagUpdateDialogFragment snagUpdateDialogFragment = SnagUpdateDialogFragment.newInstance(selectedSnag);
            snagUpdateDialogFragment.show(getChildFragmentManager(), "Update Snag");
        } else if (R.id.action_delete_snag == viewId) {
            snagListItemViewModel.deleteSnag(projectId, selectedSnag.getTaskId());
        }

    }

    // delete snag observe
    private void observeForSnagDelete() {
        snagListItemViewModel.getIsSnagDeleted().observe(getViewLifecycleOwner(), isSnagDeleted -> {
            if (isSnagDeleted) {
                showSnackBarMessage("Snag deleted successfully", R.color.snackbar_success);
                fetchSnags(projectId, snagQueryType, searchQueryString, getLatestAppliedFilterValues());
            }
        });

        snagListItemViewModel.getIsErrorInDeletingSnag().observe(getViewLifecycleOwner(), isError -> {
            if (isError) showSnackBarMessage("Error in deleting snag", R.color.snackbar_error);

        });
    }


    private void searchSnagsMenu() {
        MenuItem searchItem = snagListViewFragmentBinding.snagListViewToolBar.toolBar.getMenu().findItem(R.id.search_snags);
        searchView = (SearchView) searchItem.getActionView();

        // Overriding the default text colors in search view
        EditText searchEditText = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        searchEditText.setTextColor(ContextCompat.getColor(requireContext(), R.color.design_default_color_on_primary));
        searchEditText.setHintTextColor(ContextCompat.getColor(requireContext(), R.color.design_default_color_on_primary));

        searchView.setOnSearchClickListener(v -> snagListViewFragmentBinding.snagListViewToolBar.toolBar.setNavigationIcon(null));

        searchView.setQueryHint("Search Snags...");
        searchView.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchView.setOnCloseListener(() -> {
            // Re populate navigation icon
            snagListViewFragmentBinding.snagListViewToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
            // On close of search texts refresh
            if (!searchQueryString.equals(CommonConstants.EMPTY_STRING)) {
                fetchSnags(projectId, snagQueryType, null, getLatestAppliedFilterValues());
                searchQueryString = CommonConstants.EMPTY_STRING;
            }
            return false;
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if (snagsListsAdapter != null) {
                    searchQueryString = query.trim();

                    // Clear focus on submit
                    searchView.clearFocus();

                    // Reload snags - latest
                    fetchSnags(projectId, snagQueryType, searchQueryString, getLatestAppliedFilterValues());
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
    }


    private void listenToolBarIconsClick() {
        snagListViewFragmentBinding.snagListViewToolBar.toolBar.setOnMenuItemClickListener(item -> {
            if (R.id.filter_snags == item.getItemId() && snagsListsAdapter != null) {
                SnagFiltersBottomSheetFragment.newInstance(projectId).show(getChildFragmentManager(), "Filter Fragment");
                return true;
            }
            return false;
        });
    }


    private void observeForSnagFilters() {
        snagListItemViewModel.getSnagFilters().observe(getViewLifecycleOwner(), config -> fetchSnags(projectId, snagQueryType, searchQueryString, config));
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(QUERY_STRING, searchQueryString);
    }

    private void showSnackBarMessage(String text, int color) {
        Snackbar.make(snagListViewFragmentBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_SHORT)
                .setBackgroundTint(ContextCompat.getColor(requireContext(), color))
                .setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                .setAnchorView(requireActivity().findViewById(R.id.bottom_navigation_snag))
                .show();
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (searchView != null) {
            searchView.clearFocus();
        }

        if (snagListViewFragmentBinding != null) {
            snagListViewFragmentBinding = null;
        }
        if (snagsListsAdapter != null) {
            snagsListsAdapter = null;
        }
        if (!bag.isDisposed()) bag.dispose();
    }
}