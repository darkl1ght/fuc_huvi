package com.huviair.capture.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModelKt;
import androidx.paging.Pager;
import androidx.paging.PagingConfig;
import androidx.paging.PagingData;
import androidx.paging.PagingSource;
import androidx.paging.rxjava2.PagingRx;

import com.huviair.capture.R;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.SnagsAPIService;
import com.huviair.capture.data.model.api.snags.Config;
import com.huviair.capture.data.model.api.snags.SelectedSnagMediaDetails;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagConfig;
import com.huviair.capture.data.model.api.snags.SnagDashboardDetails;
import com.huviair.capture.data.model.api.snags.SnagMedia;
import com.huviair.capture.data.model.others.MediaDetails;
import com.huviair.capture.data.model.others.SnagFloorPlan;
import com.huviair.capture.data.repositories.SnagsDataSource;
import com.huviair.capture.data.repositories.SnagsRepository;
import com.huviair.capture.ui.snags.snagcreate.CreateSnagMediaDetails;
import com.huviair.capture.ui.snags.snagcreatedraft.CreateDraftSnagMediaDetails;
import com.huviair.capture.ui.snags.snaglist.SnagDataView;
import com.huviair.capture.ui.snags.snagcreate.SnagResult;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.utils.SingleLiveEvent;

import java.util.List;

import io.reactivex.Flowable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;
import kotlinx.coroutines.CoroutineScope;

public class SnagViewModel extends AndroidViewModel {

    private final SnagsRepository snagsRepository;
    private final SnagsAPIService snagsAPIService;

    private final SingleLiveEvent<SnagResult> snagStatisticsMutableLiveData = new SingleLiveEvent<>();
    private final SingleLiveEvent<String> selectedSnagCard = new SingleLiveEvent<>();
    private final SingleLiveEvent<SnagResult> snagsList = new SingleLiveEvent<>();

    // Create Snag fragment
    private final SingleLiveEvent<Boolean> openCreateSnagFragment = new SingleLiveEvent<>();
    private final SingleLiveEvent<Snag> isCreateSnagFloorPlanSaved = new SingleLiveEvent<>();

    private final SingleLiveEvent<SnagFloorPlan> displayFloorPlan = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isFloorPlanSaved = new SingleLiveEvent<>();

    // Create Draft Snag fragment
    private final SingleLiveEvent<Boolean> openCreateDraftSnagFragment = new SingleLiveEvent<>();

    private final SingleLiveEvent<CreateDraftSnagMediaDetails> openDraftSnagMediaViewerFragment = new SingleLiveEvent<>();

    // Used in Snag Media Fragments (update and create)
    private final SingleLiveEvent<Snag> openMediaFragment = new SingleLiveEvent<>();
    private final SingleLiveEvent<CreateSnagMediaDetails> openSnagMediaViewerFragment = new SingleLiveEvent<>();

    private final SingleLiveEvent<SelectedSnagMediaDetails> selectedSnagMedia = new SingleLiveEvent<>();

    // used to navigate from create snag fragment to list view fragment
    private final SingleLiveEvent<Boolean> isNewSnagCreated = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isNewOnsiteSnagCreated = new SingleLiveEvent<>();

    private final SingleLiveEvent<Boolean> isFetchingSnagDashboardStats = new SingleLiveEvent<>();

    public final SingleLiveEvent<MediaDetails> playVideo = new SingleLiveEvent<>();

    private Flowable<PagingData<Snag>> pagingDataObservable;


    public SnagViewModel(Application application) {
        super(application);
        snagsRepository = new SnagsRepository(application);
        snagsAPIService = APIClient.createService(SnagsAPIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());

    }

    public void fetchSnagDashboardDetails(String projectId) {
        isFetchingSnagDashboardStats.setValue(true);
        snagsRepository.getSnagDashboardDetails(projectId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<SnagDashboardDetails>() {
                    @Override
                    public void onSuccess(@NonNull SnagDashboardDetails snagDashboardDetails) {
                        isFetchingSnagDashboardStats.setValue(false);
                        snagStatisticsMutableLiveData.setValue(new SnagResult(new SnagDataView(snagDashboardDetails.getSnagStatistics(), null, null)));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        isFetchingSnagDashboardStats.setValue(false);
                        snagStatisticsMutableLiveData.setValue(new SnagResult(R.string.technical_error));
                    }
                });

    }

    public Flowable<PagingData<Snag>> fetchSnagsByQueryType(String projectId, String type, String searchQueryTerm, Config config) {

        String queryType = determineQueryType(type);
        if (!queryType.equals("")) {
            SnagConfig snagConfig = new SnagConfig(searchQueryTerm, config);

            PagingSource<Integer, Snag> pagingSource = new SnagsDataSource(snagsAPIService, projectId, queryType, snagConfig);

            // intialise pager
            // Flowable data paging
            Pager<Integer, Snag> pager = new Pager<>(new PagingConfig(10), () -> pagingSource);

            pagingDataObservable = PagingRx.getFlowable(pager);

            CoroutineScope viewModelScope = ViewModelKt.getViewModelScope(this);
            PagingRx.cachedIn(pagingDataObservable, viewModelScope);

            return pagingDataObservable;

        }
        return pagingDataObservable;
    }


    private String determineQueryType(String type) {
        String queryType = "";
        switch (type) {
            case CommonConstants.SNAG_ALL_ITEMS:
                queryType = "all";
                break;
            case CommonConstants.SNAG_OPEN_ITEMS:
                queryType = "open";
                break;
            case CommonConstants.SNAG_MY_ASSIGNED_ITEMS:
                queryType = "assigned";
                break;
            case CommonConstants.SNAG_OVERDUE_ITEMS:
                queryType = "overdue";
                break;
            case CommonConstants.SNAG_DRAFT_ITEMS:
                queryType = "onsite";
                break;

            default:
                queryType = "all";

        }
        return queryType;
    }


    public SingleLiveEvent<SnagResult> getSnagStatisticsMutableLiveData() {
        return snagStatisticsMutableLiveData;
    }

    public SingleLiveEvent<String> getSelectedSnagCard() {
        return selectedSnagCard;
    }

    public void setSelectedSnagCard(String type) {
        this.selectedSnagCard.setValue(type);
    }

    public SingleLiveEvent<SnagResult> getSnagsList() {
        return snagsList;
    }

    public SingleLiveEvent<SnagFloorPlan> getDisplayFloorPlan() {
        return displayFloorPlan;
    }

    public void setDisplayFloorPlanForSnag(Snag snag, boolean isCreateSnagFragment) {
        displayFloorPlan.setValue(new SnagFloorPlan(snag, isCreateSnagFragment));
    }

    public SingleLiveEvent<Boolean> getIsFloorPlanSaved() {
        return isFloorPlanSaved;
    }

    public void setIsFloorPlanSaved() {
        this.isFloorPlanSaved.setValue(true);
    }

    public SingleLiveEvent<Snag> getOpenMediaFragment() {
        return openMediaFragment;
    }

    public void setOpenMediaFragment(Snag selectedSnag) {
        this.openMediaFragment.setValue(selectedSnag);
    }

    public SingleLiveEvent<Boolean> isOpenCreateSnagFragment() {
        return openCreateSnagFragment;
    }

    public void openCreateSnagFragment(Boolean open) {
        openCreateSnagFragment.setValue(open);
    }

    public void openCreateDraftSnagFragment(Boolean open) {
        openCreateDraftSnagFragment.setValue(open);
    }

    public SingleLiveEvent<Boolean> isOpenCreateDraftSnagFragment() {
        return openCreateDraftSnagFragment;
    }
    public void setOpenDraftSnagMediaViewerFragment(CreateDraftSnagMediaDetails selectedSnagMediaDetails) {
        openDraftSnagMediaViewerFragment.setValue(selectedSnagMediaDetails);
    }
    public SingleLiveEvent<CreateDraftSnagMediaDetails> getOpenDraftSnagMediaViewerFragment() {
        return openDraftSnagMediaViewerFragment;
    }

    public SingleLiveEvent<CreateSnagMediaDetails> getOpenSnagMediaViewerFragment() {
        return openSnagMediaViewerFragment;
    }

    public void setOpenSnagMediaViewerFragment(CreateSnagMediaDetails selectedSnagMediaDetails) {
        openSnagMediaViewerFragment.setValue(selectedSnagMediaDetails);
    }

    public SingleLiveEvent<Boolean> isNewSnagCreated() {
        return isNewSnagCreated;
    }

    public SingleLiveEvent<Boolean> isNewOnsiteSnagCreated() {
        return isNewOnsiteSnagCreated;
    }
    public void setIsNewSnagCreated(boolean isNewSnagCreated) {
        this.isNewSnagCreated.setValue(isNewSnagCreated);
    }
    public void setIsNewOnsiteSnagCreated(boolean isNewOnsiteSnagCreated) {
        this.isNewOnsiteSnagCreated.setValue(isNewOnsiteSnagCreated);
    }

    public SingleLiveEvent<SelectedSnagMediaDetails> getSelectedSnagMedia() {
        return selectedSnagMedia;
    }

    public void setSelectedSnagMedia(int position, List<SnagMedia> media) {
        SelectedSnagMediaDetails selectedSnagMediaDetails = new SelectedSnagMediaDetails(position, media);
        selectedSnagMedia.setValue(selectedSnagMediaDetails);
    }

    public SingleLiveEvent<Boolean> getIsFetchingSnagDashboardStats() {
        return isFetchingSnagDashboardStats;
    }

    public SingleLiveEvent<Snag> isCreateSnagFloorPlanSaved() {
        return isCreateSnagFloorPlanSaved;
    }

    public void setCreateSnagFloorPlanSaved(Snag snag) {
        this.isCreateSnagFloorPlanSaved.setValue(snag);
    }
}