package com.huviair.capture.ui.snags.snaglist;

import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagMasterData;
import com.huviair.capture.data.model.api.snags.SnagStatistics;

import java.util.List;

public class SnagDataView {

    private final SnagStatistics snagStatistics;
    private final List<Snag> snagsDetailsList;
    private final SnagMasterData snagMasterData;

    public SnagDataView(SnagStatistics snagStatistics, List<Snag> snagsDetailsList, SnagMasterData snagMasterData) {
        this.snagStatistics = snagStatistics;
        this.snagsDetailsList = snagsDetailsList;
        this.snagMasterData = snagMasterData;
    }

    public SnagStatistics getSnagStatistics() {
        return snagStatistics;
    }

    public boolean checkIfAllStatsAreZero() {
        return snagStatistics.getMyAssignedCount() == 0
                && snagStatistics.getOpenCount() == 0
                && snagStatistics.getOverallCount() == 0
                && snagStatistics.getOverdueCount() == 0
                && snagStatistics.getOnsiteCount() == 0;
    }

    public List<Snag> getSnagsDetailsList() {
        return snagsDetailsList;
    }

    public SnagMasterData getSnagMasterData() {
        return snagMasterData;
    }

    @Override
    public String toString() {
        return "SnagDataView{" +
                "snagStatistics=" + snagStatistics +
                ", snagsDetailsList=" + snagsDetailsList +
                '}';
    }
}
