package com.huviair.capture.ui.interiors.interiorsDataExport.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.arashivision.sdkmedia.stitch.StitchUtils;
import com.arashivision.sdkmedia.work.WorkWrapper;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.databinding.FragmentGenerateHdrImagesBinding;
import com.huviair.capture.ui.interiors.interiorsDataExport.TourDataTransferFragmentActivity;
import com.huviair.capture.utils.CommonConstants;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GenerateHDRImagesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GenerateHDRImagesFragment extends Fragment {

    public static final String TOUR_ID = "TOUR_ID";
    private static String HDR_GENERATED_FOLDER_PATH, HDR_FOLDER_PATH = null;
    private final CompositeDisposable disposableBag = new CompositeDisposable();
    AtomicInteger successfulCount = new AtomicInteger(0);
    private FragmentGenerateHdrImagesBinding generateHdrImagesBinding;
    private String tourId;

    public GenerateHDRImagesFragment() {
        // Required empty public constructor
    }

    public static GenerateHDRImagesFragment newInstance(String tourId) {
        GenerateHDRImagesFragment fragment = new GenerateHDRImagesFragment();
        Bundle args = new Bundle();
        args.putString(TOUR_ID, tourId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        generateHdrImagesBinding = FragmentGenerateHdrImagesBinding.inflate(inflater, container, false);
        return generateHdrImagesBinding.getRoot();
    }

    @Override
    public void onViewCreated(@androidx.annotation.NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //Initialize folder paths
        HDR_GENERATED_FOLDER_PATH = requireContext().getFilesDir() + "/" + CommonConstants.HDR_STITCHED_IMAGES_FOLDER;
        HDR_FOLDER_PATH = requireContext().getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            tourId = getArguments().getString(TOUR_ID);
        }
    }


    @Override
    public void onStart() {
        super.onStart();

        View view = getView();
        if (view != null) {
            generateHdrImagesBinding.processHdrImages.setOnClickListener(v -> prepareForHDRStitching(tourId));
            generateHdrImagesBinding.nextPageStitchImages.setOnClickListener(v -> ((TourDataTransferFragmentActivity) requireActivity()).jumpToNextPage(view));
            generateHdrImagesBinding.previousPageExport.setOnClickListener(v -> ((TourDataTransferFragmentActivity) requireActivity()).jumpToPreviousPage(view));
        }
    }

    private void prepareForHDRStitching(String tourId) {
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(getContext());
        Single<List<TourDetails>> fetchTours = database.tourDetailsDAO().getSavedTourDetails(tourId);

        fetchTours.observeOn(AndroidSchedulers.mainThread())
                .map(this::transformTours)
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<List<TourDetails>>() {
                    @Override
                    public void onSuccess(@NonNull List<TourDetails> tourDetails) {
                        if (!tourDetails.isEmpty()) {
                            generateHDRImages(tourDetails);
                        } else {
                            Snackbar.make(generateHdrImagesBinding.getRoot(), "No images associated with the selected walk-through..", Snackbar.LENGTH_LONG)
                                    .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                    .show();
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        Snackbar.make(generateHdrImagesBinding.getRoot(), "Unable to fetch saved tour details..", Snackbar.LENGTH_INDEFINITE)
                                .setAction("RETRY", v -> prepareForHDRStitching(tourId))
                                .setActionTextColor(ContextCompat.getColor(requireContext(), R.color.sunflower_yellow))
                                .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                .show();
                    }
                });


    }

    private void generateHDRImages(List<TourDetails> tourDetails) {

        // disable buttons
        toggleButtonsVisibility(false);

        showProgressOnHDRStart();

        //Observable approach
        // Filter out all images whose length is less than 2 ( ie...Not an HDR image)
        Observable.fromIterable(tourDetails).filter(tour -> tour.getImageUrl().split(",").length > 1)
                .flatMap(tourDetail -> generateHDRImages(tourDetail).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(4))), 2)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<Boolean>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {
                        disposableBag.add(d);
                    }

                    @Override
                    public void onNext(@NonNull Boolean isHDRGenerated) {
                        if (isHDRGenerated) {
                            successfulCount.incrementAndGet();
                            generateHdrImagesBinding.generateTextProgress.setText(getString(R.string.stitch_status_processing, successfulCount.intValue(), tourDetails.size()));
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        generateHdrImagesBinding.generateHdrImagesProgress.setVisibility(View.GONE);
                        toggleButtonsVisibility(true);
                    }

                    @Override
                    public void onComplete() {
                        generateHdrImagesBinding.generateHdrImagesProgress.setVisibility(View.GONE);
                        toggleButtonsVisibility(true);

                        generateHdrImagesBinding.generateTextProgress.setText(getString(R.string.export_status_completed, successfulCount.intValue(), tourDetails.size()));
                        successfulCount.set(0);
                    }
                });

    }

    private void showProgressOnHDRStart() {
        generateHdrImagesBinding.generateHdrImagesProgress.setVisibility(View.VISIBLE);
        generateHdrImagesBinding.generateTextProgress.setVisibility(View.VISIBLE);
        generateHdrImagesBinding.generateTextProgress.setText("");
    }

    private void toggleButtonsVisibility(boolean enableButton) {
        generateHdrImagesBinding.nextPageStitchImages.setEnabled(enableButton);
        generateHdrImagesBinding.previousPageExport.setEnabled(enableButton);
        generateHdrImagesBinding.processHdrImages.setEnabled(enableButton);

    }

    // Invoke generate HDR images API - Insta 360 library and update details to DB
    private Observable<Boolean> generateHDRImages(TourDetails tourToStitch) {
        return Observable.fromCallable(() -> {
            String hdrStitchPath = HDR_GENERATED_FOLDER_PATH + "/" + UUID.randomUUID() + "_IMAGE_" + tourToStitch.getImageNumber() + ".jpg";

            WorkWrapper workWrapper = new WorkWrapper(tourToStitch.getImageUrlsSplit());

            // generate HDR image if doesn't exist
            if (tourToStitch.getHdrImageFileName() == null || !new File(tourToStitch.getHdrImageFileName()).exists()) {
                if (StitchUtils.generateHDR(workWrapper, hdrStitchPath)) {
                    DataCaptureRoomDatabase db = DataCaptureRoomDatabase.getDatabase(requireContext());
                    db.tourDetailsDAO().updateTourDetails(tourToStitch.getTourId(), hdrStitchPath, tourToStitch.getId());
                    return true;
                } else {
                    return false;
                }
            }

            return true;
        });
    }

    private List<TourDetails> transformTours(List<TourDetails> tourDetails) {
        for (TourDetails tour : tourDetails) {
            String[] tourImageUrls = tour.getImageUrl().split(",");
            for (int i = 0; i < tourImageUrls.length; i++) {
                tourImageUrls[i] = tourImageUrls[i].replace(
                        tourImageUrls[i].substring(0, tourImageUrls[i].lastIndexOf("/")), HDR_FOLDER_PATH);
            }
            tour.setImageUrlsSplit(tourImageUrls);
        }
        return tourDetails;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (generateHdrImagesBinding != null) {
            generateHdrImagesBinding = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (!disposableBag.isDisposed()) {
            disposableBag.dispose();
        }
    }
}