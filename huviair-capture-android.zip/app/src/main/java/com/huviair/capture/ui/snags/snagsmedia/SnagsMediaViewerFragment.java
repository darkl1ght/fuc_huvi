package com.huviair.capture.ui.snags.snagsmedia;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.huviair.capture.data.model.api.snags.SelectedSnagMediaDetails;
import com.huviair.capture.data.model.api.snags.SnagMedia;
import com.huviair.capture.databinding.FragmentMediaViewerBinding;
import com.huviair.capture.ui.media.fragments.MediaViewFragment;

import org.jetbrains.annotations.NotNull;

import java.util.List;


public class SnagsMediaViewerFragment extends Fragment {

    private SnagMediaViewsAdapter snagMediaViewsAdapter;
    private FragmentMediaViewerBinding mediaViewerBinding;

    private static final String SELECTED_SNAG_MEDIA = "SELECTED_SNAG_MEDIA";
    private SelectedSnagMediaDetails snagSelectedMediaDetails;

    public static SnagsMediaViewerFragment newInstance(SelectedSnagMediaDetails snagMediaDetails) {
        SnagsMediaViewerFragment fragment = new SnagsMediaViewerFragment();
        Bundle args = new Bundle();
        args.putSerializable(SELECTED_SNAG_MEDIA, snagMediaDetails);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            snagSelectedMediaDetails = (SelectedSnagMediaDetails) getArguments().getSerializable(SELECTED_SNAG_MEDIA);
        }
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        mediaViewerBinding = FragmentMediaViewerBinding.inflate(inflater, container, false);
        return mediaViewerBinding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        // Initialize ViewModel

        if (this.snagSelectedMediaDetails != null) {
            snagMediaViewsAdapter = new SnagMediaViewsAdapter(this, snagSelectedMediaDetails.getMedia());
            mediaViewerBinding.mediaViewPager.setAdapter(snagMediaViewsAdapter);
            mediaViewerBinding.mediaViewPager.setCurrentItem(snagSelectedMediaDetails.getPosition(), false);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mediaViewerBinding != null) {
            mediaViewerBinding = null;
        }
    }
}

class SnagMediaViewsAdapter extends FragmentStateAdapter {
    private final List<SnagMedia> mediaSelected;

    public SnagMediaViewsAdapter(Fragment fragment, List<SnagMedia> selectedMedia) {
        super(fragment);
        this.mediaSelected = selectedMedia;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Fragment fragment = new SnagsMediaViewFragment();
        Bundle args = new Bundle();
        args.putString(MediaViewFragment.MEDIA_NAME, mediaSelected.get(position).getFileName());
        args.putString(MediaViewFragment.MEDIA_BLOB_ID, mediaSelected.get(position).getBlobReferenceId());
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getItemCount() {
        return mediaSelected.size();
    }
}

