package com.huviair.capture.data.model.api.snags;

import com.google.gson.annotations.Expose;
import com.huviair.capture.utils.CommonConstants;

import java.io.Serializable;

public class WorkLocation implements Serializable {
    private String locationId;
    private String level1;
    private String level2;
    private String level3;
    private String level4;
    private String parentLocationId;
    private FloorPlanDrawing drawing;


    @Expose(deserialize = false, serialize = false)
    private String location;

    public String getLocation() {
        populateLocation();
        return location;
    }

    private void populateLocation() {
        String location = level1.concat(" ").concat(level2);
        StringBuilder locationBuilder = new StringBuilder(location);
        if (level3 != null && !CommonConstants.EMPTY_STRING.equals(level3)) {
            locationBuilder.append(" ");
            locationBuilder.append(level3);
        }
        if (level4 != null && !CommonConstants.EMPTY_STRING.equals(level4)) {
            locationBuilder.append(" ");
            locationBuilder.append(level4);
        }
        this.location = locationBuilder.toString();
    }

    public String getLocationId() {
        return locationId;
    }

    public String getLevel1() {
        return level1;
    }

    public String getLevel2() {
        return level2;
    }

    public String getLevel3() {
        return level3;
    }

    public String getLevel4() {
        return level4;
    }

    public FloorPlanDrawing getDrawing() {
        return drawing;
    }

    public String getParentLocationId() {
        return parentLocationId;
    }

    public boolean isLevel2Location(String level1Id) {
        return this.parentLocationId.equals(level1Id) && this.level3.equals("") && this.level4.equals("");
    }

    public boolean isLevel3Location(String level2Id) {
        return this.parentLocationId.equals(level2Id) && this.level4.equals("");
    }

    public boolean isLevel4Location(String level3Id) {
        return this.parentLocationId.equals(level3Id);
    }

    @Override
    public String toString() {
        getLocation();
        return location;
    }
}
