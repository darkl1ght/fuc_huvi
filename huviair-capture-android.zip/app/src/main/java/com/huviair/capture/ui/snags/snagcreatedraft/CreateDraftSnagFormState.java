package com.huviair.capture.ui.snags.snagcreatedraft;

import androidx.annotation.Nullable;

public class CreateDraftSnagFormState {

    @Nullable
    private Integer snagDescriptionError;
    @Nullable
    private Integer workTradeError;
    @Nullable
    private Integer selectLevelError;


    private boolean isDataValid = false;

    public CreateDraftSnagFormState(@Nullable Integer snagDescriptionError,
                               @Nullable Integer workTradeError, @Nullable Integer selectLevelError,
                               boolean isDataValid) {
        this.snagDescriptionError = snagDescriptionError;

        this.workTradeError = workTradeError;
        this.selectLevelError = selectLevelError;
        this.isDataValid = isDataValid;
    }

    public CreateDraftSnagFormState() {

    }

    public CreateDraftSnagFormState(boolean isDataValid) {
        this.snagDescriptionError = null;
        this.workTradeError = null;
        this.selectLevelError = null;
        this.isDataValid = isDataValid;
    }


    @Nullable
    public Integer getWorkTradeError() {
        return workTradeError;
    }

    @Nullable
    public Integer getSelectLevelError() {
        return selectLevelError;
    }

    @Nullable
    public Integer getSnagDescriptionError() {
        return snagDescriptionError;
    }



    public void setSnagDescriptionError(@Nullable Integer snagDescriptionError) {
        this.snagDescriptionError = snagDescriptionError;
    }

    public void setWorkTradeError(@Nullable Integer workTradeError) {
        this.workTradeError = workTradeError;
    }

    public void setSelectLevelError(@Nullable Integer selectLevelError) {
        this.selectLevelError = selectLevelError;
    }


    public void setDataValid(boolean dataValid) {
        isDataValid = dataValid;
    }

    public boolean isDataValid() {
        return isDataValid;
    }
}
