package com.huviair.capture.data.model.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "INTERIOR_WALKTHROUGH")
public class InteriorWalkthrough {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "INTERIOR_ID")
    private String interiorId;
    @ColumnInfo(name = "TOWER_ID")
    private String towerId;
    @ColumnInfo(name = "FLOOR_PLAN_BLOB_ID")
    private String floorPlanBlobId;
    @ColumnInfo(name = "WALKTHROUGH_ID")
    private String tourId;
    @ColumnInfo(name = "WALKTHROUGH_NAME")
    private String tourName;
    @ColumnInfo(name = "PROJECT_ID")
    private String projectId;
    @ColumnInfo(name = "FLOORPLAN_SAVED_PATH")
    private String floorPlanPath;

    public InteriorWalkthrough(int id, String interiorId, String towerId, String floorPlanBlobId, String tourId, String tourName, String projectId, String floorPlanPath) {
        this.id = id;
        this.interiorId = interiorId;
        this.towerId = towerId;
        this.floorPlanBlobId = floorPlanBlobId;
        this.tourId = tourId;
        this.tourName = tourName;
        this.projectId = projectId;
        this.floorPlanPath = floorPlanPath;
    }

    @Ignore
    public InteriorWalkthrough(String interiorId, String towerId, String floorPlanBlobId, String tourId, String tourName, String projectId) {
        this.interiorId = interiorId;
        this.towerId = towerId;
        this.floorPlanBlobId = floorPlanBlobId;
        this.tourId = tourId;
        this.tourName = tourName;
        this.projectId = projectId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public void setInteriorId(String interiorId) {
        this.interiorId = interiorId;
    }

    public String getTowerId() {
        return towerId;
    }

    public void setTowerId(String towerId) {
        this.towerId = towerId;
    }

    public String getFloorPlanBlobId() {
        return floorPlanBlobId;
    }

    public void setFloorPlanBlobId(String floorPlanBlobId) {
        this.floorPlanBlobId = floorPlanBlobId;
    }

    public String getTourId() {
        return tourId;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getFloorPlanPath() {
        return floorPlanPath;
    }

    public void setFloorPlanPath(String floorPlanPath) {
        this.floorPlanPath = floorPlanPath;
    }
}
