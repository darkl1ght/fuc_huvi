package com.huviair.capture.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class NetworkListener {
    public static Single<Boolean> hasInternetConnection(Context context) {
        return Single.fromCallable(() -> {
            try {
                ConnectivityManager cm =
                        (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();
                if (netInfo != null && netInfo.isConnectedOrConnecting()) {
                    // Connect to Google DNS to check for connection
                    int timeoutMs = 5000;
                    Socket socket = new Socket();
                    InetSocketAddress socketAddress = new InetSocketAddress("8.8.8.8", 53);

                    socket.connect(socketAddress, timeoutMs);
                    socket.close();

                    return true;
                }
                return false;
            } catch (IOException e) {
                return false;
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }

    public static Single<Boolean> hasInternetConnection(Context context, int timeout) {
        return Single.fromCallable(() -> {
            try {
                ConnectivityManager cm =
                        (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();
                if (netInfo != null && netInfo.isConnectedOrConnecting()) {
                    // Connect to Google DNS to check for connection

                    Socket socket = new Socket();
                    InetSocketAddress socketAddress = new InetSocketAddress("8.8.8.8", 53);

                    socket.connect(socketAddress, timeout);
                    socket.close();

                    return true;
                }
                return false;
            } catch (IOException e) {
                return false;
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }

}
