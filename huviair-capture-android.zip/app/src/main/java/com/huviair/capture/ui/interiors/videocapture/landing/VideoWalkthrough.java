package com.huviair.capture.ui.interiors.videocapture.landing;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.arashivision.sdkcamera.camera.callback.ICaptureStatusListener;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.bumptech.glide.signature.ObjectKey;
import com.davemorrissey.labs.subscaleview.ImageSource;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.adapters.BottomSheetOptionsAdapter;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.model.others.SavedFloorPlanPin;
import com.huviair.capture.databinding.ActivityVideoWalkthroughBinding;
import com.huviair.capture.ui.insta360.BaseObserveCameraActivity;
import com.huviair.capture.ui.interiors.videocapture.help.VideoCaptureHelpFragment;
import com.huviair.capture.ui.interiors.videocapture.help.VideoCaptureHelpScreen1;
import com.huviair.capture.ui.interiors.videocapture.help.VideoCaptureHelpScreen2;
import com.huviair.capture.ui.interiors.videocapture.publish.VideoCapturePublish;
import com.huviair.capture.utils.GlideApp;
import com.huviair.capture.utils.SharedPreferencesManager;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.disposables.CompositeDisposable;

public class VideoWalkthrough extends BaseObserveCameraActivity implements VideoCapturePublish.OnEventListener, VideoCaptureHelpScreen2.OnBottomSheetDismissListener, VideoCaptureHelpScreen1.OnNextPressedListener {

    private ActivityVideoWalkthroughBinding videoWalkthroughBinding;
    private VideoWalkthroughViewModel videoWalkthroughViewModel;
    public static final String WALK_THROUGH_DETAILS = "WALK_THROUGH_DETAILS";
    public static final String PROJECT_ID = "PROJECT_ID";
    public static double percentIncreaseDecreaseWidth;
    public static double percentIncreaseDecreaseHeight;

    private BottomSheetDialog confirmEndPointBottomSheet;
    private VideoCaptureHelpFragment videoCaptureHelpBottomDialog;
    private MaterialAlertDialogBuilder confirmStartPointDialog,
            publishPreviousCaptureDialog, walkthroughUploadedAlreadyDialog, recaptureConfirmationDialog;

    private boolean isAllFabsVisible = false;
    private double floorPlanOrigHeight, floorPlanOrigWidth;

    private SharedPreferencesManager sharedPreferencesManager;
    private final CompositeDisposable compositeDisposable = new CompositeDisposable();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       if (new SharedPreferencesManager(this).isInteriorsOpenedFirstTime()){
           showHelpDialog();
       }

       new SharedPreferencesManager(this).setAppOpenFirstTime(false);

        videoWalkthroughBinding = ActivityVideoWalkthroughBinding.inflate(getLayoutInflater());
        setContentView(videoWalkthroughBinding.getRoot());

        //Setup view model
        videoWalkthroughViewModel = new ViewModelProvider(this).get(VideoWalkthroughViewModel.class);

        // Get the project details from parent intent
        if (getIntent().getExtras() != null) {
            String projectId = getIntent().getStringExtra(PROJECT_ID);

            Tour selectedWalkthrough = (Tour) getIntent().getSerializableExtra(WALK_THROUGH_DETAILS);

            //Safety Check
            if (projectId == null) {
                finish();
            }
            videoWalkthroughViewModel.setProjectId(projectId);
            videoWalkthroughViewModel.setSelectedWalkThrough(selectedWalkthrough);


            // Fetch the allowedVideoCapture time property from database
            videoWalkthroughViewModel.fetchAllowedVideoCaptureTime(projectId);

            // Check for pending publish
            videoWalkthroughViewModel.isPublishPending(selectedWalkthrough.getTourId());

        }

        videoWalkthroughViewModel.startCameraConnectionInBackground();

        buildConfirmationDialogAndAddClickListeners();


        // Show loaders
        videoWalkthroughBinding.loadingFloorPlan.setVisibility(View.VISIBLE);
        videoWalkthroughBinding.loadingFloorPlanText.setVisibility(View.VISIBLE);

        compositeDisposable.add(videoWalkthroughViewModel.fetchTourDetailsFromDatabase()
                .doAfterSuccess(interiorWalkthrough -> {
                    //Populate existing floor plan path
                    videoWalkthroughViewModel.getSelectedWalkThrough().builder(interiorWalkthrough);
                    loadImages(videoWalkthroughViewModel.getSelectedWalkThrough().getFloorPlanPath());

                    addGestureDetectorToFloorPlan();

                    addViewModelDataObservers();
                })
                .subscribe());


        determineCurrentPhaseOfCapture();

        videoWalkthroughBinding.downloadOneTimeFloorPlan.setOnClickListener(view -> videoWalkthroughViewModel.downloadFloorPlan());

    }

    private void buildConfirmationDialogAndAddClickListeners() {
        confirmStartPointDialog = new MaterialAlertDialogBuilder(this)
                .setTitle("Confirm start point ?")
                .setMessage("Confirm selected start point and start the capture")
                .setPositiveButton(getResources().getString(R.string.start_capture), (dialog, which) -> videoWalkthroughViewModel.startTimeLapseVideoCapture())
                .setNegativeButton("Retake", ((dialogInterface, i) -> {
                    videoWalkthroughBinding.floorPlanImage.removePin(videoWalkthroughViewModel.captureStartPoint.getValue());
                    videoWalkthroughViewModel.captureStartPoint.setValue(null);
                    videoWalkthroughBinding.confirmStartPoint.setEnabled(false);
                }))
                .setIcon(R.drawable.exclamation_icon);

        publishPreviousCaptureDialog = new MaterialAlertDialogBuilder(this)
                .setTitle("Publish ?")
                .setMessage("Publish pending previous capture")
                .setPositiveButton(getResources().getString(R.string.button_ok), (dialog, which) -> showPublishFragment())
                .setNeutralButton("Re-capture", (dialogInterface, i) -> recaptureConfirmationDialog.show())
                .setNegativeButton(getResources().getString(R.string.cancel), null)
                .setIcon(R.drawable.exclamation_icon);

        walkthroughUploadedAlreadyDialog =  new MaterialAlertDialogBuilder(this)
                .setTitle("Walk-through published")
                .setMessage("This walk-through has been uploaded already !")
                .setPositiveButton(getResources().getString(R.string.button_ok), null)
                .setNegativeButton(getResources().getString(R.string.cancel), null)
                .setIcon(R.drawable.exclamation_icon);

        recaptureConfirmationDialog = new MaterialAlertDialogBuilder(this)
                .setTitle("Are you sure ?")
                .setMessage("This will reset the current capture, you'll have to start over again")
                .setPositiveButton(getResources().getString(R.string.button_ok), (dialogInterface, i) -> resetCurrentCapture())
                .setNegativeButton(getResources().getString(R.string.cancel), null)
                .setIcon(R.drawable.exclamation_icon);

        videoWalkthroughBinding.confirmStartPoint.setOnClickListener(view -> confirmStartPointDialog.show());
        videoWalkthroughBinding.confirmEndPoint.setOnClickListener(view -> confirmEndPointBottomSheet.show());

        setupBottomSheetView();

    }

    private void resetCurrentCapture() {
        // Remove end point
        videoWalkthroughBinding.floorPlanImage.removePin(videoWalkthroughViewModel.captureStartPoint.getValue());
        videoWalkthroughBinding.floorPlanImage.removePin(videoWalkthroughViewModel.captureEndPoint.getValue());


        videoWalkthroughViewModel.captureStartPoint.setValue(null);
        videoWalkthroughViewModel.captureEndPoint.setValue(null);

        videoWalkthroughViewModel.removeThePreviousCapture();

        // reset all points
        videoWalkthroughBinding.confirmEndPoint.setVisibility(View.GONE);
        videoWalkthroughBinding.publishPending.setVisibility(View.GONE);
        videoWalkthroughBinding.confirmStartPoint.setVisibility(View.VISIBLE);
        videoWalkthroughBinding.confirmEndPoint.setEnabled(false);
        videoWalkthroughBinding.confirmStartPoint.setEnabled(false);
        videoWalkthroughViewModel.isCaptureComplete.setValue(false);

        showSnackBarMessage("Capture reset successfully");
    }

    private void setupBottomSheetView(){
        confirmEndPointBottomSheet = new BottomSheetDialog(this);
        View bottomSheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_layout, null);
        TextView textView = bottomSheetView.findViewById(R.id.text_bottom_sheet);
        textView.setText("Next steps");
        confirmEndPointBottomSheet.setContentView(bottomSheetView);

        RecyclerView recyclerView = bottomSheetView.findViewById(R.id.recyclerView);

        List<BottomSheetOption> options = new ArrayList<>();

        options.add(new BottomSheetOption("Publish now", R.drawable.ic_baseline_publish_24));
        options.add(new BottomSheetOption("Publish later", R.drawable.ic_baseline_watch_later_24));
        options.add(new BottomSheetOption("Mark end-point again", R.drawable.edit_icon));
        options.add(new BottomSheetOption("Re-capture", R.drawable.ic_baseline_repeat_24));

        BottomSheetOptionsAdapter adapter = new BottomSheetOptionsAdapter(options);

        adapter.setOnOptionClickListener(position -> {
            if(position == 0)
                videoWalkthroughViewModel.saveCaptureDataToDatabase(floorPlanOrigHeight, percentIncreaseDecreaseWidth, percentIncreaseDecreaseHeight, true);
           else if(position == 1)
               videoWalkthroughViewModel.saveCaptureDataToDatabase(floorPlanOrigHeight, percentIncreaseDecreaseWidth,percentIncreaseDecreaseHeight,false);

            else if(position == 2) {
                confirmEndPointBottomSheet.setDismissWithAnimation(true);
                confirmEndPointBottomSheet.dismiss();

                // Remove end point
                videoWalkthroughBinding.floorPlanImage.removePin(videoWalkthroughViewModel.captureEndPoint.getValue());
                videoWalkthroughViewModel.captureEndPoint.setValue(null);
                videoWalkthroughBinding.confirmEndPoint.setEnabled(false);
            }
            else if(position == 3) {
                confirmEndPointBottomSheet.setDismissWithAnimation(true);
                confirmEndPointBottomSheet.dismiss();

                recaptureConfirmationDialog.show();

            }

        });
        recyclerView.setAdapter(adapter);
//        showPublishFragment();
    }

    private void showHelpDialog(){
        videoCaptureHelpBottomDialog = new VideoCaptureHelpFragment();
        videoCaptureHelpBottomDialog.show(getSupportFragmentManager(), "Help");
    }

    private void showPublishFragment(){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        VideoCapturePublish myFragment = new VideoCapturePublish(videoWalkthroughViewModel.getSelectedWalkThrough());
        fragmentTransaction.add(R.id.video_capture_publish, myFragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {
        FragmentManager fm = getSupportFragmentManager();
        if (fm.getBackStackEntryCount() > 0) {
            fm.popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    private void addGestureDetectorToFloorPlan() {
        final GestureDetector gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            // On Single tap, if image exists get image number
            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (videoWalkthroughBinding.floorPlanImage.isReady()) {
                    PointF selectedCoordinates = videoWalkthroughBinding.floorPlanImage.viewToSourceCoord(e.getX(), e.getY());

                    if(!videoWalkthroughViewModel.is360CameraConnected()){
                        showSnackBarMessage("Please connect 360 camera");
                    }
                    else {
                        if(videoWalkthroughViewModel.captureStartPoint.getValue() == null){
                            videoWalkthroughViewModel.captureStartPoint.setValue(selectedCoordinates);
                            videoWalkthroughBinding.floorPlanImage.setPin(selectedCoordinates);
                            videoWalkthroughBinding.confirmStartPoint.setEnabled(true);
                        }
                        if(videoWalkthroughViewModel.isCaptureComplete() && videoWalkthroughViewModel.captureEndPoint.getValue() == null){
                            videoWalkthroughViewModel.captureEndPoint.setValue(selectedCoordinates);
                            videoWalkthroughBinding.floorPlanImage.setPin(selectedCoordinates);
                            videoWalkthroughBinding.confirmEndPoint.setEnabled(true);
                        }
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Image not ready...", Toast.LENGTH_SHORT).show();
                }
                return super.onSingleTapConfirmed(e);
            }

        });

        videoWalkthroughBinding.floorPlanImage.setOnTouchListener((view, motionEvent) -> gestureDetector.onTouchEvent(motionEvent));

    }




    private void addViewModelDataObservers() {

        videoWalkthroughViewModel.showLoadingState.observe(this, isLoading -> {
            videoWalkthroughBinding.floorPlanImage.setVisibility(isLoading ? View.GONE : View.VISIBLE);
            videoWalkthroughBinding.loadingFloorPlan.setVisibility(isLoading ? View.VISIBLE : View.GONE);

            if (isLoading) videoWalkthroughBinding.downloadOneTimeFloorPlan.setVisibility(View.GONE);

        });


        videoWalkthroughViewModel.isFloorPlanDownloaded.observe(this, floorPlanDownloaded -> {
            if (floorPlanDownloaded) {
                videoWalkthroughBinding.downloadOneTimeFloorPlan.setVisibility(View.GONE);
                loadImages(videoWalkthroughViewModel.getSelectedWalkThrough().getFloorPlanPath());
            }
        });


        videoWalkthroughBinding.connectToCameraButton.setOnClickListener(view ->  {
            // Add a listener to the camera wifi
            startActivity(new Intent(WifiManager.ACTION_PICK_WIFI_NETWORK));
        });

        videoWalkthroughViewModel.isCaptureInProgress.observe(this, isCaptureInProgress -> {
            // Keep the screen on while capture is in progress
            if(isCaptureInProgress) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            videoWalkthroughBinding.confirmStartPoint.setVisibility(View.GONE);
            videoWalkthroughBinding.stopVideo.setVisibility(isCaptureInProgress ? View.VISIBLE : View.GONE);
            videoWalkthroughBinding.imageCaptureOverlay.setVisibility(isCaptureInProgress ? View.VISIBLE : View.GONE);
        });

        videoWalkthroughViewModel.isCaptureComplete.observe(this, isCaptureComplete -> {
            if(isCaptureComplete){
                showSnackBarMessage("Select the capture end point");
                videoWalkthroughBinding.confirmEndPoint.setVisibility(View.VISIBLE);
            }

        });

        videoWalkthroughBinding.stopVideo.setOnClickListener(view -> videoWalkthroughViewModel.stopTimeLapseVideoCapture());

        videoWalkthroughViewModel.isPendingPublish.observe(this, isPendingPublish -> {
            videoWalkthroughBinding.publishPending.setVisibility(isPendingPublish? View.VISIBLE: View.GONE);
            if(isPendingPublish) publishPreviousCaptureDialog.show();
        }
        );
        videoWalkthroughBinding.publishPending.setOnClickListener(view -> showPublishFragment());

        videoWalkthroughViewModel.isWalkthroughUploadedAlready.observe(this, walkthroughUploadedAlready -> {
            if(walkthroughUploadedAlready) {
                walkthroughUploadedAlreadyDialog.show();
                disableCapture();
            }
        });

        videoWalkthroughViewModel.isCaptureSavedShowPublish.observe(this, showPublishFragment -> {
            if(showPublishFragment){
                confirmEndPointBottomSheet.setDismissWithAnimation(true);
                confirmEndPointBottomSheet.dismiss();
                showPublishFragment();
            }
        });
        videoWalkthroughViewModel.isCaptureSaved.observe(this, captureSaved -> {
            if(captureSaved){
                confirmEndPointBottomSheet.setDismissWithAnimation(true);
                confirmEndPointBottomSheet.dismiss();
                onBackPressed();
            }
        });

        videoWalkthroughViewModel.previousMarkerCoordinates.observe(this, previousFeatures -> {
            if (previousFeatures != null) {

                for (int imageNumber = 0; imageNumber < previousFeatures.size(); imageNumber++) {
                    // Project back the y coordinate to the coordinate system of android
                    double projectedYCoordinate = floorPlanOrigHeight - previousFeatures.get(imageNumber).getGeometry().getYCoordinate();
                    double xCoordinate = previousFeatures.get(imageNumber).getGeometry().getXCoordinate();
                    // Create a new point and add to the plan
                    PointF point = new PointF((float) xCoordinate, (float) projectedYCoordinate);

                    // Populate coordinates and draw marker
                    videoWalkthroughBinding.floorPlanImage.populatePreviousPinCoordinates(new SavedFloorPlanPin(point, imageNumber, imageNumber + 1));
                }
                if (videoWalkthroughBinding.floorPlanImage.isReady()) {
                    videoWalkthroughBinding.floorPlanImage.initialiseAndInvalidate();
                }
            }

        });

    }

    private void disableCapture(){
        videoWalkthroughBinding.connectToCameraButton.setEnabled(false);
        videoWalkthroughBinding.floorPlanImage.setOnTouchListener(null);
    }

    private void loadImages(String urlToLoad) {
        // Load image using glide
        if (urlToLoad != null) {
            GlideApp.with(this).asBitmap()
                    .load(urlToLoad)
                    .apply(new RequestOptions().signature(new ObjectKey(String.valueOf(System.currentTimeMillis()))))
                    .listener(new RequestListener<Bitmap>() {
                        @Override
                        public boolean onLoadFailed(@androidx.annotation.Nullable GlideException e, Object model, Target<Bitmap> target, boolean isFirstResource) {
                            // On Image load fail
                            videoWalkthroughBinding.loadingFloorPlan.setVisibility(View.GONE);
                            videoWalkthroughBinding.loadingFloorPlanText.setText(getResources().getString(R.string.loading_floor_plan_failed));

                            Snackbar.make(findViewById(R.id.tour_map_layout), "Couldn't load floor plan, if it's uploaded already please sync the latest data", BaseTransientBottomBar.LENGTH_INDEFINITE)
                                    .show();
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Bitmap resource, Object model, Target<Bitmap> target, DataSource dataSource, boolean isFirstResource) {
                            return false;
                        }
                    })
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            floorPlanOrigHeight = resource.getHeight();
                            floorPlanOrigWidth = resource.getWidth();
                            videoWalkthroughBinding.floorPlanImage.setImage(ImageSource.bitmap(resource));

                            videoWalkthroughBinding.loadingFloorPlan.setVisibility(View.GONE);
                            videoWalkthroughBinding.loadingFloorPlanText.setVisibility(View.GONE);

                            percentIncreaseDecreaseHeight = videoWalkthroughBinding.floorPlanImage.getSHeight() / floorPlanOrigHeight;
                            percentIncreaseDecreaseWidth = videoWalkthroughBinding.floorPlanImage.getSWidth() / floorPlanOrigWidth;

//                            populateSavedPointsOnMap();

                            // Fetch previous markers by default
                            videoWalkthroughViewModel.getPreviousMarkersForInterior();

                            if(!isCameraConnected()) videoWalkthroughBinding.connectToCameraButton.setVisibility(View.VISIBLE);

                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }

                    });

        }
        else {
            videoWalkthroughBinding.loadingFloorPlan.setVisibility(View.GONE);
            videoWalkthroughBinding.downloadOneTimeFloorPlan.setVisibility(View.VISIBLE);
            videoWalkthroughBinding.loadingFloorPlanText.setText("");

            Snackbar.make(findViewById(R.id.tour_map_layout), "Please download floor plan to get started", BaseTransientBottomBar.LENGTH_LONG)
                    .show();
        }

    }

    private void determineCurrentPhaseOfCapture() {
        videoWalkthroughViewModel.is360CameraConnected.observe(this, isConnected -> {
            if(isConnected){
                InstaCameraManager.getInstance().setCaptureStatusListener(new ICaptureStatusListener() {
                    @Override
                    public void onCaptureStarting() {
                        videoWalkthroughViewModel.isCaptureInProgress.setValue(true);

                    }

                    @Override
                    public void onCaptureWorking() {
                    }

                    @Override
                    public void onCaptureStopping() {
                        videoWalkthroughViewModel.isCaptureInProgress.setValue(false);

                    }

                    @Override
                    public void onCaptureFinish(String[] filePaths) {
                        videoWalkthroughViewModel.isCaptureInProgress.setValue(false);
                        videoWalkthroughViewModel.isCaptureComplete.setValue(true);
                        videoWalkthroughViewModel.capturedVideoUrls = filePaths;
                    }

                    @Override
                    public void onCaptureTimeChanged(long captureTime) {
                        // Record Duration, in ms
                        // Only Record type will callback this

                        long minutes = (captureTime / 1000) / 60;
                        long seconds = (captureTime / 1000) % 60;
                        videoWalkthroughBinding.captureStatus.setText(String.format("%02d:%02d", minutes, seconds));

                        if( minutes == videoWalkthroughViewModel.allowedVideoCaptureTime) videoWalkthroughViewModel.stopTimeLapseVideoCapture();
                    }
                });
            }

            if(isConnected && videoWalkthroughViewModel.captureStartPoint.getValue() == null){
                videoWalkthroughBinding.confirmStartPoint.setVisibility(View.VISIBLE);
            }
        });
    }

    // Provides camera status change notifications
    @Override
    public void onCameraStatusChanged(boolean enabled) {
        super.onCameraStatusChanged(enabled);
        showSnackBarMessage(enabled ? "Camera connected" : "Camera disconnected");
        videoWalkthroughViewModel.is360CameraConnected.setValue(enabled);
        videoWalkthroughBinding.connectToCameraButton.setVisibility(enabled ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onCameraBatteryLow() {
        super.onCameraBatteryLow();
    }

    public void showSnackBarMessage(String message){
        Snackbar.make(videoWalkthroughBinding.getRoot(), message, Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void onWalkthroughUploadComplete(String interiorId, String towerId) {
        videoWalkthroughBinding.confirmEndPoint.setVisibility(View.GONE);
        showSnackBarMessage("Walk-through submitted successfully");
    }


    @Override
    public void onBottomSheetDismiss() {
        videoCaptureHelpBottomDialog.dismiss();
        videoCaptureHelpBottomDialog.jumpToNextPage();
    }

    @Override
    public void onNextPress() {
        videoCaptureHelpBottomDialog.jumpToNextPage();
    }
}