package com.huviair.capture.ui.insta360;

import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.github.pwittchen.reactivenetwork.library.rx2.ReactiveNetwork;
import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.InternetObservingSettings;
import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.strategy.SocketInternetObservingStrategy;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.huviair.capture.databinding.FragmentInstaConnectionBottomSheetBinding;

import org.jetbrains.annotations.NotNull;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CameraConnectionBottomSheetFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CameraConnectionBottomSheetFragment extends BottomSheetDialogFragment {


    private FragmentInstaConnectionBottomSheetBinding instaConnectionBottomSheetBinding;
    private final CompositeDisposable disposable = new CompositeDisposable();


    public CameraConnectionBottomSheetFragment() {
        // Required empty public constructor
    }

    public static CameraConnectionBottomSheetFragment newInstance() {
        CameraConnectionBottomSheetFragment fragment = new CameraConnectionBottomSheetFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onStart() {
        super.onStart();
        BottomSheetBehavior.from((View) requireView().getParent()).setState(BottomSheetBehavior.STATE_EXPANDED);
        BottomSheetBehavior.from((View) requireView().getParent()).setSkipCollapsed(true);
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        instaConnectionBottomSheetBinding = FragmentInstaConnectionBottomSheetBinding.inflate(inflater, container, false);
        return instaConnectionBottomSheetBinding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        instaConnectionBottomSheetBinding.connectCameraBottomSheet.setOnClickListener(v -> {
            showProgressBarAndDisableButtons(false);
            InstaCameraManager.getInstance().openCamera(InstaCameraManager.CONNECT_TYPE_WIFI);
        });

        instaConnectionBottomSheetBinding.wifiSettingsBottomSheet
                .setOnClickListener(v -> startActivity(new Intent(WifiManager.ACTION_PICK_WIFI_NETWORK)));

        InternetObservingSettings settings = InternetObservingSettings.builder()
                .host("http://192.168.42.1")
                .strategy(new SocketInternetObservingStrategy())
                .build();

        disposable.add(ReactiveNetwork
                .observeInternetConnectivity(settings)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(isConnectedToInternet -> {
                    if(isConnectedToInternet){
                        showProgressBarAndDisableButtons(false);
                        InstaCameraManager.getInstance().openCamera(InstaCameraManager.CONNECT_TYPE_WIFI);
                    }
                }));

    }

    public void showProgressBarAndDisableButtons( boolean isButtonEnabled) {
        instaConnectionBottomSheetBinding.wifiSettingsBottomSheet.setEnabled(isButtonEnabled);
        instaConnectionBottomSheetBinding.connectCameraBottomSheet.setEnabled(isButtonEnabled);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if(!disposable.isDisposed()){
            disposable.dispose();
        }
    }
}