package com.huviair.capture.data.repositories;

import android.app.Application;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.tours.ImageFeature;
import com.huviair.capture.data.model.api.tours.InteriorsResponse;
import com.huviair.capture.data.model.api.tours.Walkthrough;
import com.huviair.capture.data.model.database.InteriorTourCoordinates;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.SharedPreferencesManager;

import java.util.List;
import java.util.stream.Collectors;

import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class InteriorsRepository {

    private final APIService projectsService;
    private final DataCaptureRoomDatabase database;


    public InteriorsRepository(Application application) {
        projectsService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());
        database = DataCaptureRoomDatabase.getDatabase(application);
    }

    public Single<InteriorsResponse> fetchInteriorsAndWalkthroughs(String projectId) {
        return projectsService.getInteriorsAndWalkthroughs(projectId);
    }

    public Single<Walkthrough> getPreviousWalkthrough(String projectId, String interiorId, String tourId) {
        return projectsService.getPreviousWalkthrough(projectId, interiorId, tourId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Completable insertTourCoordinates(String tourId, List<ImageFeature> imageFeatures) {
        List<InteriorTourCoordinates> tourDataToSave = imageFeatures.stream().map(imageFeature -> new InteriorTourCoordinates().populateData(imageFeature, tourId)).collect(Collectors.toList());
        return database.tourDetailsDAO().deleteCoordinatesByTourId(tourId).doOnComplete(() -> database.tourDetailsDAO().insertAll(tourDataToSave).subscribe())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Single<List<InteriorTourCoordinates>> getPreviousTourCoordinates(String tourId) {
        return database.tourDetailsDAO().getTourCoordinatesForTheTour(tourId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

}
