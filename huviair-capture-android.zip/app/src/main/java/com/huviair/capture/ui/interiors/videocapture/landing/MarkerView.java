package com.huviair.capture.ui.interiors.videocapture.landing;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;

import androidx.core.content.ContextCompat;

import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import com.huviair.capture.R;
import com.huviair.capture.data.model.others.SavedFloorPlanPin;
import com.huviair.capture.ui.interiors.tours.Coordinates;

import java.util.ArrayList;
import java.util.List;


public class MarkerView extends SubsamplingScaleImageView {

    private static final float CAPTURE_MARKER_RADIUS = 35 ;
    private final Paint paint = new Paint();
    private final Paint linePaint = new Paint();
    private final Paint alphaPaint = new Paint();
    private final Paint circlePaint = new Paint();
    private final PointF vPin = new PointF();
    private final List<PointF> sPin = new ArrayList<>();
    private Bitmap pin;
    private final ArrayList<Coordinates> oldTourCoordinates = new ArrayList<>();
    private final Path path = new Path();

    public MarkerView(Context context) {
        this(context, null);
    }

    public MarkerView(Context context, AttributeSet attr) {
        super(context, attr);
        initialise();
    }

    public void setPin(PointF sPin) {
        this.sPin.add(sPin);
        initialise();
        invalidate();
    }


    public void initialiseAndInvalidate() {
        invalidate();
    }

    public void populatePreviousPinCoordinates(SavedFloorPlanPin savedFloorPlanPin) {
        this.oldTourCoordinates.add(new Coordinates(savedFloorPlanPin.getSavedPointOnFloorPlan().x,
                savedFloorPlanPin.getSavedPointOnFloorPlan().y));
    }

    public void removePin(PointF sPin){
        this.sPin.remove(sPin);
        initialise();
        invalidate();
    }

    private void initialise() {
        float density = getResources().getDisplayMetrics().densityDpi;
        pin = BitmapFactory.decodeResource(this.getResources(), R.drawable.pushpin_blue);
        float w = (density/800f) * pin.getWidth();
        float h = (density/800f) * pin.getHeight();
        pin = Bitmap.createScaledBitmap(pin, (int)w, (int)h, true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Don't draw pin before image is ready so it doesn't move around during setup.
        if (!isReady()) {
            return;
        }



        // Draw lines if minimum of two coordinate points are available
        if(oldTourCoordinates != null && oldTourCoordinates.size() >= 2){
            path.reset();

            for(int i=0 ; i < oldTourCoordinates.size() - 1; i++){
                float startingPointX = (float) oldTourCoordinates.get(i).getX();
                float startingPointY = (float) oldTourCoordinates.get(i).getY();
                float immediatePointX = (float) oldTourCoordinates.get(i+1).getX();
                float immediatePointY = (float) oldTourCoordinates.get(i+1).getY();

                PointF startingPointCoordinates = sourceToViewCoord(startingPointX, startingPointY);
                PointF immediatePointCoordinates = sourceToViewCoord(immediatePointX, immediatePointY);


                path.moveTo(startingPointCoordinates.x, startingPointCoordinates.y);
                path.lineTo(immediatePointCoordinates.x,immediatePointCoordinates.y);
            }

            path.close();
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeCap(Paint.Cap.ROUND);
            int strokeWidth = 10;
            linePaint.setStrokeWidth(strokeWidth);
            linePaint.setColor(Color.LTGRAY);
            canvas.drawPath(path, linePaint);

            circlePaint.setColor(Color.parseColor("#66000000"));

            alphaPaint.setColor(ContextCompat.getColor(getContext(), R.color.black));
            alphaPaint.setTextSize(40f);
            alphaPaint.setTextAlign(Paint.Align.CENTER);
            Rect result = new Rect();
            alphaPaint.getTextBounds("Start", 0,"Start".length(), result);
            int yOffset = result.height()/2;

            PointF startingPointCoordinates = sourceToViewCoord( (float) oldTourCoordinates.get(0).getX(), (float) oldTourCoordinates.get(0).getY());
            canvas.drawCircle(startingPointCoordinates.x, startingPointCoordinates.y, CAPTURE_MARKER_RADIUS, circlePaint);
            canvas.drawText("Start", startingPointCoordinates.x, startingPointCoordinates.y+yOffset, alphaPaint);

            PointF endPointCoordinates = sourceToViewCoord( (float) oldTourCoordinates.get(oldTourCoordinates.size()-1).getX(), (float) oldTourCoordinates.get(oldTourCoordinates.size()-1).getY());
            canvas.drawCircle(endPointCoordinates.x, endPointCoordinates.y, CAPTURE_MARKER_RADIUS, circlePaint);
            canvas.drawText("End", endPointCoordinates.x, endPointCoordinates.y+yOffset, alphaPaint);


        }

        paint.setAntiAlias(true);

        sPin.stream().forEach(pointF ->  {
            if (sPin != null && pin != null) {
                PointF vPin = sourceToViewCoord(pointF);
                float vX = vPin.x - (pin.getWidth()/2);
                float vY = vPin.y - pin.getHeight();
                canvas.drawBitmap(pin, vX, vY, paint);
            }
        });


    }

}