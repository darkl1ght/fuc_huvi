package com.huviair.capture.ui.media.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.huviair.capture.data.model.api.media.Album;
import com.huviair.capture.data.model.api.media.ProjectAlbumsRequest;
import com.huviair.capture.databinding.FragmentCreateAlbumBinding;
import com.huviair.capture.viewmodels.AlbumsListViewModel;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;

import org.jetbrains.annotations.NotNull;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CreateAlbumDialogFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CreateAlbumDialogFragment extends DialogFragment {

    private static final String PROJECT_ID = "PROJECT_ID";

    private FragmentCreateAlbumBinding createAlbumBinding;

    private String projectId;
    private String selectedDateValue;


    public CreateAlbumDialogFragment() {
        // Required empty public constructor
    }

    private AlbumsListViewModel albumsListViewModel;

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param projectId Parameter 1.
     * @return A new instance of fragment CreateAlbumFragment.
     */
    public static CreateAlbumDialogFragment newInstance(String projectId) {
        CreateAlbumDialogFragment fragment = new CreateAlbumDialogFragment();
        Bundle args = new Bundle();
        args.putString(PROJECT_ID, projectId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
        }
    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        createAlbumBinding = FragmentCreateAlbumBinding.inflate(inflater, container, false);
        return createAlbumBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        albumsListViewModel = new ViewModelProvider(requireActivity()).get(AlbumsListViewModel.class);

        // Workaround to open the date picker on single click rather than double click
        createAlbumBinding.albumDateEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (v.isInTouchMode() && hasFocus) {
                v.performClick();
            }
        });

        createAlbumBinding.albumDateEditText.setOnClickListener(v -> {
            MaterialDatePicker.Builder<Long> builder = MaterialDatePicker.Builder.datePicker();
            MaterialDatePicker<Long> picker = builder.setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                    .setTitleText("Select Album create date")
                    .build();

            picker.addOnPositiveButtonClickListener(selection -> {
                selectedDateValue = DateFormatUtils.convertDate(selection, CommonConstants.MONGO_DATE_FORMAT);
                createAlbumBinding.albumDateEditText.setText(DateFormatUtils.convertDate(selection, "dd-MM-yyyy"));

            });
            picker.show(getChildFragmentManager(), "Date picker");
        });


        // Populate current date as default
        selectedDateValue = DateFormatUtils.convertDate(MaterialDatePicker.todayInUtcMilliseconds(), CommonConstants.MONGO_DATE_FORMAT);
        createAlbumBinding.albumDateEditText.setText(DateFormatUtils.convertDate(MaterialDatePicker.todayInUtcMilliseconds(), "dd-MM-yyyy"));

        // Dismiss dialog, do nothing
        createAlbumBinding.cancelAlbumButton.setOnClickListener(v -> dismiss());

        // Helper error message for name
        createAlbumBinding.albumNameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                validateAlbumName(s.toString());
            }
        });

        // Helper error message for name
        createAlbumBinding.albumDateEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s == null || "".equals(s.toString())) {
                    createAlbumBinding.albumDate.setError("Please choose Album date");
                } else createAlbumBinding.albumDate.setError(null);
            }
        });

        // Create Album call on CLick
        createAlbumBinding.createAlbumButton.setOnClickListener(v -> validateAlbumFieldsAndCreate());

        createAlbumBinding.albumNameEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (EditorInfo.IME_ACTION_DONE == actionId) {
                validateAlbumFieldsAndCreate();
            }
            return false;
        });

        observeForStates();
    }

    private void observeForStates() {
        albumsListViewModel.isCreatingAlbum.observe(getViewLifecycleOwner(), isCreatingAlbum -> {
            createAlbumBinding.loadingCreateAlbum.setVisibility(isCreatingAlbum ? View.VISIBLE : View.GONE);
            toggleButtonsBasedOnState(!isCreatingAlbum);
        });

        albumsListViewModel.isAlbumCreatedSuccessfully.observe(getViewLifecycleOwner(), isAlbumCreated -> {
            Toast.makeText(requireContext(), "Album created successfully", Toast.LENGTH_SHORT).show();
            dismiss();
        });
        albumsListViewModel.isErrorInCreatingAlbum.observe(getViewLifecycleOwner(), isError -> Toast.makeText(requireContext(), "Error in creating album", Toast.LENGTH_SHORT).show());
    }

    private void validateAlbumName(String currentAlbumName) {
        if (currentAlbumName == null || "".equals(currentAlbumName)) {
            createAlbumBinding.albumName.setError("Album name is mandatory");
        } else createAlbumBinding.albumName.setError(null);

    }

    private void validateAlbumFieldsAndCreate() {
        String albumName = createAlbumBinding.albumNameEditText.getText().toString();
        if (selectedDateValue == null || "".equals(selectedDateValue)) {
            createAlbumBinding.albumDate.setError("Please choose Album date");
        }
        validateAlbumName(albumName);
        if (createAlbumBinding.albumDate.getError() == null && createAlbumBinding.albumName.getError() == null) {
            ProjectAlbumsRequest request = new ProjectAlbumsRequest();
            request.setAlbum(new Album(albumName, selectedDateValue, "", true));
            albumsListViewModel.createAlbumInBackend(projectId, request);
        }
    }


    private void toggleButtonsBasedOnState(boolean makeButtonsVisible) {
        createAlbumBinding.createAlbumButton.setEnabled(makeButtonsVisible);
        createAlbumBinding.cancelAlbumButton.setEnabled(makeButtonsVisible);
        this.setCancelable(makeButtonsVisible);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (createAlbumBinding != null) {
            createAlbumBinding = null;
        }
    }
}