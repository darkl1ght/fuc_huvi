package com.huviair.capture.utils;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.Objects;

public class UriUtils {

    public static Uri downloadImageToStorage(Context context, Bitmap resource, String mediaId) {
        OutputStream fileOutputStream;
        Uri imageUri;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                imageUri = checkIfFileIsAlreadyDownloaded(context, mediaId);

                if (imageUri != null) return imageUri;

                ContentResolver resolver = context.getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, mediaId);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpg");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);
                //Insert to the media store
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);

                fileOutputStream = resolver.openOutputStream(Objects.requireNonNull(imageUri));
            } else {
                String imagesDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES).toString();
                File image = new File(imagesDir, mediaId);
                imageUri = Uri.fromFile(image);
                if (image.exists()) {
                    return imageUri;
                }
                fileOutputStream = new FileOutputStream(image);

            }
            resource.compress(Bitmap.CompressFormat.JPEG, CommonConstants.IMAGE_COMPRESSION_PERCENTAGE, fileOutputStream);
            Objects.requireNonNull(fileOutputStream).close();
            return imageUri;

        } catch (Exception e) {
            return null;
        }


    }

    private static Uri checkIfFileIsAlreadyDownloaded(Context context, String mediaBlobId) {
        Uri collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = new String[]{MediaStore.MediaColumns._ID};

        String selection = MediaStore.MediaColumns.DISPLAY_NAME + " = ?";

        String[] selectionArgs = new String[]{mediaBlobId};
        String sortOrder = MediaStore.Video.Media.DISPLAY_NAME + " ASC";

        try (Cursor cursor = context.getContentResolver().query(
                collection,
                projection,
                selection, selectionArgs,
                sortOrder
        )) {
            // Cache column indices.
            int idColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);

            if (cursor.getCount() == 0) return null;

            while (cursor.moveToNext()) {
                // Get values of columns for a given video.
                long id = cursor.getLong(idColumn);

                return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
            }
        }
        return collection;
    }

    public static byte[] compressImageToBytes(String filePath, Bitmap imageBitMap) {

        // 1. Convert uri to bitmap
        Bitmap bitmap = BitmapFactory.decodeFile(filePath);

        // 2. Instantiate the downsized image content as a byte[]
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        //3. if Bitmap.decode is null
        if(bitmap==null && imageBitMap!=null) {
            bitmap = imageBitMap;
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        } else{
            bitmap.compress(Bitmap.CompressFormat.JPEG, CommonConstants.IMAGE_COMPRESSION_PERCENTAGE, byteArrayOutputStream);
        }

        return byteArrayOutputStream.toByteArray();
    }

    public static Uri downloadImageToLocalStorage(String url, Context context, String imageId) throws IOException {
        Uri imageUri;
        Bitmap imageBitmap = downloadImageBitmap(url);
        String imagesDir = context.getFilesDir().toString();
        File image = new File(imagesDir, imageId);
        imageUri = Uri.fromFile(image);
        if (image.exists()) {
            if (image.delete()) {
                try (FileOutputStream fos = new FileOutputStream(image)) {
                    if (imageBitmap != null) {
                        imageBitmap.compress(Bitmap.CompressFormat.JPEG, 70, fos);
                    }
                }
            }
        } else {
            try (FileOutputStream fos = new FileOutputStream(image)) {
                if (imageBitmap != null) {
                    imageBitmap.compress(Bitmap.CompressFormat.JPEG, 70, fos);
                }
            }
        }

        return imageUri;
    }

    private static Bitmap downloadImageBitmap(String sUrl) {
        Bitmap bitmap = null;
        try (InputStream inputStream = new URL(sUrl).openStream()) {
            // Decode Bitmap
            bitmap = BitmapFactory.decodeStream(inputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }


}