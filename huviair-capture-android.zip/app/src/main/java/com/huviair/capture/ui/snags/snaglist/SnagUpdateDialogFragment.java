package com.huviair.capture.ui.snags.snaglist;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.chip.Chip;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.lookups.Lookup;
import com.huviair.capture.data.model.api.snags.SavedSnagResponse;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.TaskPriority;
import com.huviair.capture.databinding.FragmentSnagUpdateDialogBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.viewmodels.SnagListItemModel;
import com.huviair.capture.viewmodels.UpdateSnagViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SnagUpdateDialogFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SnagUpdateDialogFragment extends DialogFragment {

    private static final String SNAG = "SNAG";
    private Snag selectedSnag;
    private FragmentSnagUpdateDialogBinding snagUpdateDialogBinding;
    private UpdateSnagViewModel updateSnagViewModel;
    private SnagListItemModel snagListItemModel;
    private String selectedDateValue;

    //Common tags for media upload
    private final List<Chip> tags = new ArrayList<>();
    private List<Lookup> lookups;


    public SnagUpdateDialogFragment() {
        // Required empty public constructor
    }

    public static SnagUpdateDialogFragment newInstance(Snag selectedSnag) {
        SnagUpdateDialogFragment fragment = new SnagUpdateDialogFragment();
        Bundle args = new Bundle();
        args.putSerializable(SNAG, selectedSnag);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onStart() {
        super.onStart();
        requireDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            selectedSnag = (Snag) getArguments().getSerializable(SNAG);

        }
    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        snagUpdateDialogBinding = FragmentSnagUpdateDialogBinding.inflate(inflater, container, false);
        return snagUpdateDialogBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        updateSnagViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication())).get(UpdateSnagViewModel.class);

        // Call the parent view model
        snagListItemModel = new ViewModelProvider(requireParentFragment()).get(SnagListItemModel.class);

        snagUpdateDialogBinding.snagDescriptionEditText.setText(selectedSnag.getTaskDescription());
        snagUpdateDialogBinding.snagDueDateEditText.setText(DateFormatUtils.parseDateInRequiredFormat(selectedSnag.getDueDate(), CommonConstants.DATE_PICKER_FORMAT));
        snagUpdateDialogBinding.snagRemarksEditText.setText(selectedSnag.getRemark());

        snagUpdateDialogBinding.priorityDropdown.setText(selectedSnag.getTaskPriority().getDesc());

        selectedDateValue = selectedSnag.getDueDate();

        // populate chips dynamically
        for (int i = 0; i < selectedSnag.getTags().length; i++) {
            addChipToGroup(selectedSnag.getTags()[i]);
        }

        fetchLookupsAndObserve();

        observeForChips();

        updateButtonListener();

        populateDatePicker();

        addTextWatchListener();

        observeForUpdatesProgress();
    }


    private void addTextWatchListener() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s == null || CommonConstants.EMPTY_STRING.equals(s.toString())) {
                    snagUpdateDialogBinding.snagDescription.setError("Please enter Snag Description");
                } else snagUpdateDialogBinding.snagDescription.setError(null);
            }
        };

        snagUpdateDialogBinding.snagDescriptionEditText.addTextChangedListener(textWatcher);
    }

    private void observeForChips() {
        snagUpdateDialogBinding.inputTags.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                String textValue = snagUpdateDialogBinding.inputTags.getText().toString();
                if (!"".equals(textValue)) {
                    addChipToGroup(textValue);
                    snagUpdateDialogBinding.inputTags.setText("");
                }
            }
            return false;
        });
    }

    private void fetchLookupsAndObserve() {
        updateSnagViewModel.fetchLookUps(CommonConstants.LOOKUP_TYPE_TASK_PRIORITY);
        updateSnagViewModel.getLookups().observe(this, snagResult -> {
            if (snagResult.getSuccess() != null && snagResult.getSuccess().getLookupList() != null) {
                lookups = snagResult.getSuccess().getLookupList();
                snagUpdateDialogBinding.priorityDropdown.setAdapter(new ArrayAdapter<>(requireContext(), R.layout.list_item, lookups));
            }
        });
    }

    // Dynamically add chips to ui
    private void addChipToGroup(String textToAdd) {

        // Create Chip object
        Chip chip = new Chip(requireContext());
        chip.setText(textToAdd);
        chip.setChipIconTintResource(R.color.brand_secondary);
        chip.setCheckable(false);
        chip.setClickable(false);
        chip.setCloseIconVisible(true);
        chip.setCloseIcon(ContextCompat.getDrawable(requireContext(), R.drawable.close_icon));

        snagUpdateDialogBinding.tagsChipGroup.setVisibility(View.VISIBLE);
        snagUpdateDialogBinding.tagsChipGroup.addView(chip);

        tags.add(chip);

        chip.setOnCloseIconClickListener(v -> {
            tags.remove(chip);
            snagUpdateDialogBinding.tagsChipGroup.removeView(chip);
        });
    }

    private void validateAndUpdateOnSubmit() {
        if (CommonConstants.EMPTY_STRING.equals(snagUpdateDialogBinding.snagDescriptionEditText.getText().toString())) {
            snagUpdateDialogBinding.snagDescription.setError("Please enter Snag Description");
        } else {
            lookups.stream().filter(lookup -> snagUpdateDialogBinding.priorityDropdown.getText().toString().equalsIgnoreCase(lookup.getValue()))
                    .findFirst()
                    .ifPresent(lookup -> {
                        Snag snag = new Snag();
                        snag.setTaskPriority(new TaskPriority(lookup.getKey(), lookup.getValue()));
                        snag.setRemark(snagUpdateDialogBinding.snagRemarksEditText.getText().toString());
                        snag.setTags(getTags(tags));
                        snag.setTaskDescription(snagUpdateDialogBinding.snagDescriptionEditText.getText().toString());
                        snag.setDueDate(selectedDateValue);
                        //Update
                        updateSnagViewModel.updateSnag(selectedSnag.getProjectId(), selectedSnag.getTaskId(),
                                new SavedSnagResponse(snag));

                    });

        }

    }

    private String[] getTags(List<Chip> tags) {
        String[] snagTags = new String[tags.size()];
        for (int i = 0; i < tags.size(); i++) {
            snagTags[i] = tags.get(i).getText().toString();
        }
        return snagTags;
    }


    private void updateButtonListener() {
        snagUpdateDialogBinding.updateSnagButton.setOnClickListener(v -> validateAndUpdateOnSubmit());
    }

    private void populateDatePicker() {
        snagUpdateDialogBinding.snagDueDate.getEditText().setOnClickListener(v -> {
            MaterialDatePicker.Builder<Long> builder = MaterialDatePicker.Builder.datePicker();
            MaterialDatePicker<Long> picker = builder.setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                    .setTitleText("Snag Due Date")
                    .build();

            picker.addOnPositiveButtonClickListener(selection -> {
                selectedDateValue = DateFormatUtils.convertDate(selection, CommonConstants.MONGO_DATE_FORMAT);
                snagUpdateDialogBinding.snagDueDate.getEditText().setText(DateFormatUtils.convertDate(selection, "dd-MM-yyyy"));

            });
            picker.show(getChildFragmentManager(), "Date picker");
        });
    }

    private void observeForUpdatesProgress() {
        updateSnagViewModel.getIsUploading().observe(this, isUploading -> snagUpdateDialogBinding.updatingSnag.setVisibility(View.VISIBLE));
        updateSnagViewModel.getIsUpdateCompleted().observe(this, isUpdatedCompleted -> {
            snagListItemModel.setSnagDataUpdated(true);
            dismiss();
        });
        updateSnagViewModel.getIsUpdateError().observe(this, isUpdateError -> Toast.makeText(requireContext(), "Error in updating snag !", Toast.LENGTH_LONG).show());
    }


}