package com.huviair.capture.data.repositories;

import android.app.Application;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.projects.ProjectList;
import com.huviair.capture.utils.SharedPreferencesManager;

import io.reactivex.Single;

public class ProjectsRepository {

    private final APIService projectsService;


    public ProjectsRepository(Application application) {
        projectsService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());
    }

    public Single<ProjectList> fetchProjects() {
        return projectsService.getProjects();

    }

    public Single<AzureTokenResponse> fetchAzureToken(String containerType) {
        return projectsService.getAzureTokenByRequest(containerType);
    }


}
