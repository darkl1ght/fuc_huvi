package com.huviair.capture.ui.media.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.huviair.capture.data.model.api.media.Media;
import com.huviair.capture.data.model.api.media.SelectedMediaDetails;
import com.huviair.capture.databinding.FragmentMediaViewerBinding;
import com.huviair.capture.viewmodels.AlbumsListViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.List;


public class MediaViewerFragment extends Fragment {

    private MediaViewsAdapter mediaViewsAdapter;
    private FragmentMediaViewerBinding mediaViewerBinding;
    private AlbumsListViewModel albumsListViewModel;
    private SelectedMediaDetails selectedMediaDetails;

    public MediaViewerFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        mediaViewerBinding = FragmentMediaViewerBinding.inflate(inflater, container, false);
        return mediaViewerBinding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        // Initialize ViewModel
        albumsListViewModel = new ViewModelProvider(requireActivity()).get(AlbumsListViewModel.class);

        albumsListViewModel.getMediaLiveDataForViewPager().observe(requireActivity(), selectedMediaDetails -> this.selectedMediaDetails = selectedMediaDetails);

        if (this.selectedMediaDetails != null) {
            mediaViewsAdapter = new MediaViewsAdapter(this, selectedMediaDetails.getMedia());
            mediaViewerBinding.mediaViewPager.setAdapter(mediaViewsAdapter);
            mediaViewerBinding.mediaViewPager.setCurrentItem(selectedMediaDetails.getPosition(), false);
        }

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mediaViewerBinding != null) {
            mediaViewerBinding = null;
        }
        if (mediaViewsAdapter != null) {
            mediaViewsAdapter = null;
        }
        if (albumsListViewModel != null) {
            albumsListViewModel = null;
        }
    }
}

class MediaViewsAdapter extends FragmentStateAdapter {
    private final List<Media> mediaSelected;

    public MediaViewsAdapter(Fragment fragment, List<Media> selectedMedia) {
        super(fragment);
        this.mediaSelected = selectedMedia;
    }


    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Fragment fragment = new MediaViewFragment();
        Bundle args = new Bundle();
        args.putString(MediaViewFragment.MEDIA_NAME, mediaSelected.get(position).getMediaName());
        args.putString(MediaViewFragment.MEDIA_BLOB_ID, mediaSelected.get(position).getBlobContentId());
        args.putString(MediaViewFragment.MEDIA_TYPE, mediaSelected.get(position).getMediaType().getCode());

        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public int getItemCount() {
        return mediaSelected.size();
    }
}

