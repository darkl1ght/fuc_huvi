package com.huviair.capture.ui;

import android.app.Application;
import android.content.Context;

import com.arashivision.sdkcamera.InstaCameraSDK;
import com.arashivision.sdkmedia.InstaMediaSDK;
import com.huviair.capture.utils.MediaLoader;
import com.yanzhenjie.album.Album;
import com.yanzhenjie.album.AlbumConfig;

import org.acra.ACRA;
import org.acra.BuildConfig;
import org.acra.config.CoreConfigurationBuilder;
import org.acra.config.MailSenderConfigurationBuilder;
import org.acra.data.StringFormat;

import java.util.Locale;

import io.reactivex.exceptions.UndeliverableException;
import io.reactivex.plugins.RxJavaPlugins;

public class MyApp extends Application {

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

        // ACRA config
        CoreConfigurationBuilder builder = new CoreConfigurationBuilder(this)
                .setBuildConfigClass(BuildConfig.class)
                .setReportFormat(StringFormat.JSON);

        builder.getPluginConfigurationBuilder(MailSenderConfigurationBuilder.class)
                .setSubject("Huviair Capture Crash report")
                .setBody("PFA the crash report")
                .setMailTo("vikas_tallur@huviair.com")
                .setReportAsFile(true)
                .setReportFileName("Crash Report.txt")
                .setEnabled(true);

        ACRA.init(this, builder);
    }


    @Override
    public void onCreate() {
        super.onCreate();

        // Initialise the album library
        Album.initialize(AlbumConfig.newBuilder(this)
                .setAlbumLoader(new MediaLoader())
                .setLocale(Locale.getDefault())
                .build()
        );

        //Initialise the Insta360 camera sdk
        InstaCameraSDK.init(this);
        InstaMediaSDK.init(this);

        RxJavaPlugins.setErrorHandler(throwable -> {
            if (throwable instanceof UndeliverableException) {
                System.err.println(throwable);
            }
        });
    }
}
