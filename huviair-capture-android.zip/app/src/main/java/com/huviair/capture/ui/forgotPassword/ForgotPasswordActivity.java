package com.huviair.capture.ui.forgotPassword;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.databinding.ActivityForgotPasswordBinding;
import com.huviair.capture.viewmodels.ForgotPasswordViewModel;

public class ForgotPasswordActivity extends AppCompatActivity {

    private ActivityForgotPasswordBinding forgotPasswordBinding;
    private ForgotPasswordViewModel forgotPasswordViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        forgotPasswordBinding = ActivityForgotPasswordBinding.inflate(getLayoutInflater());
        setContentView(forgotPasswordBinding.getRoot());

        forgotPasswordViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(ForgotPasswordViewModel.class);

        forgotPasswordBinding.sendEmailResetPassword.setOnClickListener(view -> {
            forgotPasswordViewModel.forgotPassword(forgotPasswordBinding.resetEmail.getEditText().getText().toString());
        });

        forgotPasswordViewModel.getIsLoading().observe(this, isLoading -> {
            forgotPasswordBinding.sendEmailResetPassword.setEnabled(!isLoading);
            forgotPasswordBinding.loadingForgotPassword.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        });

        forgotPasswordViewModel.getIsEmailSentSuccess().observe(this, isSuccess -> showSnackBar("Password reset email sent successfully"));

        forgotPasswordViewModel.getIsEmailNotRegistered().observe(this, isSuccess -> showSnackBar("Please enter a valid registered email"));


        TextWatcher textChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                forgotPasswordViewModel.forgotPasswordDataChanged(forgotPasswordBinding.
                        resetEmail.getEditText().getText().toString());
            }
        };

        forgotPasswordBinding.resetEmail.getEditText().addTextChangedListener(textChangedListener);

        forgotPasswordViewModel.getForgotPasswordFormState().observe(this, forgotPasswordFormState -> {
            if (forgotPasswordFormState == null) {
                return;
            }
            forgotPasswordBinding.sendEmailResetPassword.setEnabled(forgotPasswordFormState.isDataValid());
            if (forgotPasswordFormState.getUsernameError() != null) {
                forgotPasswordBinding.resetEmail.setError(getString(forgotPasswordFormState.getUsernameError()));
            } else forgotPasswordBinding.resetEmail.setError(null);
        });

        MaterialToolbar toolbar = (MaterialToolbar) findViewById(forgotPasswordBinding.projectToolBar.toolBar.getId());
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void showSnackBar(String message) {
        Snackbar snackbar =
                Snackbar.make(
                        this.getWindow().getDecorView().findViewById(android.R.id.content),
                        message,
                        Snackbar.LENGTH_LONG);

        snackbar.show();
    }

}