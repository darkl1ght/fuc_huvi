package com.huviair.capture.data.model.others;

public class MediaDetails {
    private final String blobContentId;
    private final String blobDescription;
    private final boolean is360Video;

    public MediaDetails(String blobContentId, String blobDescription, boolean is360Video) {
        this.blobContentId = blobContentId;
        this.blobDescription = blobDescription;
        this.is360Video = is360Video;
    }

    public boolean is360Video() {
        return is360Video;
    }

    public String getBlobContentId() {
        return blobContentId;
    }

    public String getBlobDescription() {
        return blobDescription;
    }
}
