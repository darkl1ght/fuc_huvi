package com.huviair.capture.viewmodels;

import android.app.Application;
import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.exifinterface.media.ExifInterface;
import androidx.lifecycle.AndroidViewModel;

import com.google.android.material.chip.Chip;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.media.Media;
import com.huviair.capture.data.model.api.media.MediaMetaData;
import com.huviair.capture.data.model.api.media.MediaResponse;
import com.huviair.capture.data.model.api.media.MediaType;
import com.huviair.capture.data.model.api.media.ProjectMediaRequest;
import com.huviair.capture.data.model.others.MediaUploadInfo;
import com.huviair.capture.data.repositories.ProjectMediaRepository;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.utils.SingleLiveEvent;
import com.huviair.capture.utils.UriUtils;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.yanzhenjie.album.AlbumFile;

import java.io.IOException;
import java.net.URI;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class CreateMediaViewModel extends AndroidViewModel {

    private final ProjectMediaRepository mediaRepository;
    private final CompositeDisposable disposable = new CompositeDisposable();

    public SingleLiveEvent<Boolean> isUploadingMedia = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isErrorInUploadingMedia = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isUploadCompleted = new SingleLiveEvent<>();

    private final SingleLiveEvent<MediaUploadInfo> uploadStatus = new SingleLiveEvent<>();

    private String projectId;
    private String albumId;
    private String containerUri;

    private Bitmap imageBitMap;

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getAlbumId() {
        return albumId;
    }

    public void setAlbumId(String albumId) {
        this.albumId = albumId;
    }

    public SingleLiveEvent<MediaUploadInfo> getUploadStatus() {
        return uploadStatus;
    }

    public CreateMediaViewModel(@NonNull Application application) {
        super(application);
        mediaRepository = new ProjectMediaRepository(application);
    }

    public void fetchContainerUri() {
        mediaRepository.getAzureWritePermissionToken()
                .subscribe(new DisposableSingleObserver<AzureTokenResponse>() {
                    @Override
                    public void onSuccess(@io.reactivex.annotations.NonNull AzureTokenResponse azureTokenResponse) {
                        containerUri = azureTokenResponse.getSasToken() != null ? azureTokenResponse.getSasToken().getUri() : null;
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                        containerUri = null;
                    }
                });
    }

    // Backend call
    public void startMediaUpload(List<AlbumFile> albumFiles, List<Chip> tags, String mediaDescription) {

        try {
            String[] imageTags = getImageTagsDetails(tags);

            isUploadingMedia.setValue(true);
            CloudBlobContainer azureBlobContainer = new CloudBlobContainer(URI.create(containerUri));

            Observable.fromIterable(albumFiles)
                    .flatMap(albumFile -> uploadMediaToAzureBlob(albumFile, azureBlobContainer, imageTags, mediaDescription).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(5))), 3)
                    .flatMap(media -> uploadMediaDetailsToBackend(media, azureBlobContainer).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(5))), 3)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new DisposableObserver<MediaResponse>() {
                        @Override
                        public void onNext(@io.reactivex.annotations.NonNull MediaResponse mediaResponse) {
                            if (uploadStatus.getValue() == null) {
                                uploadStatus.setValue(new MediaUploadInfo(new AtomicInteger(0), albumFiles.size()));
                            }
                            MediaUploadInfo mediaUploadInfo = uploadStatus.getValue();
                            mediaUploadInfo.incrementProcessedCount();
                            uploadStatus.setValue(mediaUploadInfo);
                        }

                        @Override
                        public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                            isUploadingMedia.setValue(false);
                            isErrorInUploadingMedia.setValue(true);
                            uploadStatus.setValue(null);
                        }

                        @Override
                        public void onComplete() {
                            uploadStatus.setValue(null);
                            isUploadingMedia.setValue(false);
                            isUploadCompleted.setValue(true);
                        }
                    });


        } catch (Exception ignored) {
            isErrorInUploadingMedia.setValue(true);
        }

    }

    private String[] getImageTagsDetails(List<Chip> tags) {
        String[] imageTags = new String[tags.size()];
        for (int i = 0; i < tags.size(); i++) {
            imageTags[i] = tags.get(i).getText().toString();
        }
        return imageTags;
    }

    private Observable<MediaResponse> uploadMediaDetailsToBackend(Media media, CloudBlobContainer azureBlobContainer) {
        if (CommonConstants.TYPE_VIDEO_CODE.equals(media.getMediaType().getCode())) {
            generateThumbnail(media, azureBlobContainer);
        }

        return mediaRepository.createMedia(media.getProjectId(), new ProjectMediaRequest(media));
    }

    private void generateThumbnail(Media media, CloudBlobContainer azureBlobContainer) {
        // Upload
        CloudBlockBlob blob;
        try {
            blob = azureBlobContainer.getBlockBlobReference(media.getMediaId().concat(".png"));
            blob.uploadFromFile(media.getThumbnailPath());
        } catch (Exception e) {
            // Do nothing
//            Toast.makeText(getContext(), "Video Thumbnail generation failed", Toast.LENGTH_LONG).show();
        }

    }

    private Observable<Media> uploadMediaToAzureBlob(AlbumFile albumFileToUpload, CloudBlobContainer azureBlobContainer, String[] tags, String mediaDescription) {
        return Observable.fromCallable(() -> {
            Media media = new Media();
            media.setMediaId(UUID.randomUUID().toString());
            populateMediaMetaData(media, albumFileToUpload, tags, mediaDescription);

            // Upload
            CloudBlockBlob blob = azureBlobContainer.getBlockBlobReference(media.getBlobContentId());
            if (CommonConstants.TYPE_VIDEO_CODE.equals(media.getMediaType().getCode())) {
                blob.uploadFromFile(albumFileToUpload.getPath());
            } else {
                byte[] compressImageToBytes = UriUtils.compressImageToBytes(albumFileToUpload.getPath(),
                        getImageBitMap()!=null? getImageBitMap():null);
                blob.uploadFromByteArray(compressImageToBytes, 0, compressImageToBytes.length);
            }
            return media;
        });

    }

    private void populateMediaMetaData(Media media, AlbumFile albumFileToUpload, String[] tags, String mediaDescription) throws IOException {
        // Append media type
        media.setMediaType(new MediaType(albumFileToUpload.getMediaType()));

        // If valid (Image or video) proceed
        if (!"Invalid".equals(media.getMediaType().getCode())) {
            String fileExtension = albumFileToUpload.getPath().split("\\.")[1];
            String fileName = albumFileToUpload.getPath().substring(albumFileToUpload.getPath().lastIndexOf("/") + 1);
            media.setMediaName(fileName);
            media.setBlobContentId(media.getMediaId().concat(".").concat(fileExtension));
            media.setAlbumId(albumId);
            media.setProjectId(projectId);

            String fileCreationDate = "";

            // Extract date from media, if present or default to now
            ExifInterface exifInterface = new ExifInterface(albumFileToUpload.getPath());
            if (exifInterface.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) != null) {
                fileCreationDate = DateFormatUtils.parseExifDateInRequiredFormat(
                        exifInterface.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL), "yyyy-MM-dd'T'HH:mm:ss.SSSZ");
            } else {
                fileCreationDate = DateFormatUtils.convertDate(new Date().getTime(), CommonConstants.MONGO_DATE_FORMAT);
            }

            media.setFileDate(fileCreationDate);

            //MediaMetaData data
            media.setMeta(new MediaMetaData(fileCreationDate, fileName, albumFileToUpload.getSize(),String.valueOf(albumFileToUpload.getLatitude()), String.valueOf(albumFileToUpload.getLongitude())));

            //Thumbnail is generated by the album library, hence replacing
            media.setThumbnailPath(albumFileToUpload.getThumbPath());

            // current populated values in UI
            media.setMediaDescription(mediaDescription);
            media.setTags(tags);
        }
    }


    @Override
    protected void onCleared() {
        super.onCleared();
        if (!disposable.isDisposed()) {
            disposable.dispose();
        }
    }

    public Bitmap getImageBitMap() {
        return imageBitMap;
    }

    public void setImageBitMap(Bitmap imageBitMap) {
        this.imageBitMap = imageBitMap;
    }
}