package com.huviair.capture.data.model.api.snags;

public class CreateSnagRequest {
    private CreateSnagDetails punchList;

    public CreateSnagDetails getPunchList() {
        return punchList;
    }

    public void setPunchList(CreateSnagDetails punchList) {
        this.punchList = punchList;
    }
}
