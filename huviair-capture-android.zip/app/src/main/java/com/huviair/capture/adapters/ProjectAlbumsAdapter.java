package com.huviair.capture.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.huviair.capture.R;
import com.huviair.capture.adapters.diffUtil.ProjectAlbumsListDiffUtil;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.MediaAPIService;
import com.huviair.capture.data.model.api.media.Album;
import com.huviair.capture.data.model.others.SelectedAlbum;
import com.huviair.capture.databinding.MediaAlbumListViewBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.utils.GlideApp;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.viewmodels.AlbumsListViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.CompletableObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class ProjectAlbumsAdapter extends RecyclerView.Adapter<ProjectAlbumsAdapter.ViewHolder>
        implements ActionMode.Callback {

    private final List<Album> selectedAlbumsForDelete = new ArrayList<>();
    private final Activity activity;
    private List<Album> projectAlbums = new ArrayList<>();
    private boolean multiSelectMode = false;
    // Activity level model
    private AlbumsListViewModel model;
    private ActionMode deleteActionBar;


    /**
     * Empty and parameterized constructor
     */
    public ProjectAlbumsAdapter(Activity activity) {
        this.activity = activity;
    }

    public void updateData(List<Album> newAlbumsList) {
        ProjectAlbumsListDiffUtil projectAlbumsListDiffUtil = new ProjectAlbumsListDiffUtil(projectAlbums, newAlbumsList);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(projectAlbumsListDiffUtil);
        this.projectAlbums.clear();
        this.projectAlbums.addAll(newAlbumsList);
        diffResult.dispatchUpdatesTo(this);
    }

    @Override
    public void onAttachedToRecyclerView(@androidx.annotation.NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        if (model == null) {
            model = new ViewModelProvider((ViewModelStoreOwner) recyclerView.getContext()).get(AlbumsListViewModel.class);
        }
    }

    // Create new views (invoked by the layout manager)
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NotNull ViewGroup viewGroup, int viewType) {
        return new ViewHolder(MediaAlbumListViewBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        MaterialCardView cardView = viewHolder.albumListViewBinding.itemCardAlbum;
        Album selectedAlbum = projectAlbums.get(position);

        // logic for basically handling data change
        if (selectedAlbumsForDelete.contains(selectedAlbum)) {
            cardView.setAlpha(0.5f);
        } else {
            if (cardView.isChecked()) {
                cardView.setChecked(false);
            }
            cardView.setAlpha(1.0f);
        }

        cardView.setOnLongClickListener(v -> {
            if (!multiSelectMode) {
                multiSelectMode = true;
                // Add it to the list containing all the selected images
                selectItem(viewHolder, projectAlbums.get(position));
                deleteActionBar = ((AppCompatActivity) activity).startSupportActionMode(ProjectAlbumsAdapter.this);
                return true;
            }
            return false;

        });


        viewHolder.albumListViewBinding.mediaTitle.setText(projectAlbums.get(position).getAlbumName());

        //Format date
        String albumCreateDate = DateFormatUtils.parseDateInRequiredFormat(projectAlbums.get(position).getAlbumDate(), "MMM d, yyyy");
        viewHolder.albumListViewBinding.albumCreateDate.setText(albumCreateDate);
        viewHolder.albumListViewBinding.albumMediaCount.setText(String.valueOf(projectAlbums.get(position).getMedia().size()));

        // Populate Image view from web
        populateAlbumThumbnail(projectAlbums.get(position), viewHolder.albumListViewBinding.imageViewAlbum);

        cardView.setOnClickListener(v -> {
            if (!multiSelectMode) {
                model.setSelectedAlbum(new SelectedAlbum(projectAlbums.get(position), cardView));
            } else {
                selectItem(viewHolder, projectAlbums.get(position));
            }
        });
    }

    private void populateAlbumThumbnail(Album projectAlbum, ImageView imageView) {
        String mediaType = projectAlbum.getMedia().size() > 0 ? projectAlbum.getMedia().get(0).getMediaType().getCode() : "";
        if (projectAlbum.getMedia().size() > 0) {
            if (CommonConstants.TYPE_IMAGE_CODE.equals(mediaType)) {
                GlideApp.with(imageView.getContext())
                        .load(APIClient.getAzureBlobThumbnailContainer().concat(projectAlbum.getMedia().get(0).getBlobContentId()))
                        .placeholder(R.drawable.ic_baseline_cloud_download_24)
                        .error(R.drawable.image_preview_brand_color)
                        .into(imageView);
            } else imageView.setImageResource(R.drawable.image_preview_brand_color);
        } else imageView.setImageResource(R.drawable.image_preview_brand_color);
    }

    @Override
    public int getItemCount() {
        return projectAlbums.size();
    }

    // Custom menu for implementing delete feature
    @Override
    public boolean onCreateActionMode(ActionMode mode, Menu menu) {
        mode.setTitle("Delete Selected Albums");
        mode.getMenuInflater().inflate(R.menu.album_delete_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
        return false;
    }

    @Override
    public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
        if (R.id.delete_album == item.getItemId() && !selectedAlbumsForDelete.isEmpty()) {
            deleteSelectedAlbums();
        }
        return false;
    }

    private void deleteSelectedAlbums() {
        MediaAPIService mediaAPIService = APIClient.createService(MediaAPIService.class, activity,
                APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(activity).getJwtToken());

        List<String> albumIdsToDelete = new ArrayList<>();
        for (Album selectedAlbum : selectedAlbumsForDelete) {
            albumIdsToDelete.add(selectedAlbum.getAlbumId());
        }

        // Populate map
        Map<String, List<String>> albumsToDelete = new HashMap<>();
        albumsToDelete.put("albumIds", albumIdsToDelete);

        model.setIsLoadingData(true);

        mediaAPIService.deleteAlbums(projectAlbums.get(0).getProjectId(), albumsToDelete)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new CompletableObserver() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onComplete() {
                        Toast.makeText(activity, "Album deleted successfully", Toast.LENGTH_LONG).show();

                        model.setIsLoadingData(false);
                        projectAlbums.removeAll(selectedAlbumsForDelete);
                        model.isRefreshRequired.setValue(true);
                        deleteActionBar.finish();
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        Toast.makeText(activity, "Error in deleting Albums", Toast.LENGTH_LONG).show();
                    }
                });

    }

    @Override
    public void onDestroyActionMode(ActionMode mode) {
        selectedAlbumsForDelete.clear();
        multiSelectMode = false;
        notifyDataSetChanged();
    }

    private void selectItem(ViewHolder holder, Album selectedAlbum) {
        holder.albumListViewBinding.itemCardAlbum.setChecked(!holder.albumListViewBinding.itemCardAlbum.isChecked());
        if (selectedAlbumsForDelete.contains(selectedAlbum)) {
            selectedAlbumsForDelete.remove(selectedAlbum);
            holder.albumListViewBinding.itemCardAlbum.setAlpha(1.0f);

            //Hide delete bar
            if (selectedAlbumsForDelete.isEmpty() && deleteActionBar != null) {
                deleteActionBar.finish();
            }
        } else {
            selectedAlbumsForDelete.add(selectedAlbum);
            holder.albumListViewBinding.itemCardAlbum.setAlpha(0.5f);
        }
    }

    public void setAdapterData(List<Album> albums) {
        this.projectAlbums = albums;
    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final MediaAlbumListViewBinding albumListViewBinding;

        public ViewHolder(MediaAlbumListViewBinding viewBinding) {
            super(viewBinding.getRoot());
            this.albumListViewBinding = viewBinding;
        }

    }


}

