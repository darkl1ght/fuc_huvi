package com.huviair.capture.ui.snags.snagcreatedraft;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.huviair.capture.databinding.FragmentMediaViewerBinding;

import java.util.List;


public class CreateDraftSnagsMediaViewerFragment extends Fragment {

    private CreateSnagMediaViewsAdapter createSnagMediaViewsAdapter;
    private FragmentMediaViewerBinding mediaViewerBinding;

    private static final String SELECTED_SNAG_MEDIA = "SELECTED_SNAG_MEDIA";
    private CreateDraftSnagMediaDetails snagMediaDetails;

    public static CreateDraftSnagsMediaViewerFragment newInstance(CreateDraftSnagMediaDetails snagMediaDetails) {
        CreateDraftSnagsMediaViewerFragment fragment = new CreateDraftSnagsMediaViewerFragment();
        Bundle args = new Bundle();
        args.putSerializable(SELECTED_SNAG_MEDIA, snagMediaDetails);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            snagMediaDetails = (CreateDraftSnagMediaDetails) getArguments().getSerializable(SELECTED_SNAG_MEDIA);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        mediaViewerBinding = FragmentMediaViewerBinding.inflate(inflater, container, false);
        return mediaViewerBinding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        // Initialize ViewModel

        if (this.snagMediaDetails != null) {
            createSnagMediaViewsAdapter = new CreateSnagMediaViewsAdapter(this, snagMediaDetails.getMedia());
            mediaViewerBinding.mediaViewPager.setAdapter(createSnagMediaViewsAdapter);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mediaViewerBinding != null) {
            mediaViewerBinding = null;
        }
    }
}

class CreateSnagMediaViewsAdapter extends FragmentStateAdapter {
    private final List<String> mediaSelected;

    public CreateSnagMediaViewsAdapter(Fragment fragment, List<String> selectedMedia) {
        super(fragment);
        this.mediaSelected = selectedMedia;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Fragment fragment = new CreateDraftSnagsMediaViewFragment();
        Bundle args = new Bundle();
        args.putString(CreateDraftSnagsMediaViewFragment.MEDIA_FILE_PATH, mediaSelected.get(position));
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getItemCount() {
        return mediaSelected.size();
    }
}

