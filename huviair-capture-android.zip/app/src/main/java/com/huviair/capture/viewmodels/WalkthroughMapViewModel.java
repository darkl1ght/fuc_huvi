package com.huviair.capture.viewmodels;

import android.app.Application;
import android.graphics.PointF;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkContinuation;
import androidx.work.WorkManager;

import com.arashivision.sdkmedia.export.ExportUtils;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.azure.AzureToken;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.tours.Image;
import com.huviair.capture.data.model.api.tours.ImageFeature;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.repositories.InteriorsRepository;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.NetworkListener;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.utils.SingleLiveEvent;
import com.huviair.capture.utils.UriUtils;
import com.huviair.capture.workers.ExportHDRImagesWorker;
import com.huviair.capture.workers.GenerateHDRImagesWorker;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.HttpException;

public class WalkthroughMapViewModel extends AndroidViewModel {

    private final WorkManager workManager;
    private final InteriorsRepository interiorsRepository;
    private final APIService apiService;
    private final DataCaptureRoomDatabase database;
    private final CompositeDisposable disposableBag = new CompositeDisposable();
    public SingleLiveEvent<Boolean> isImageDeleted = new SingleLiveEvent<>();
    public SingleLiveEvent<Long> isImageReviewed = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> showLoadingState = new SingleLiveEvent<>();
    public SingleLiveEvent<List<ImageFeature>> previousMarkerCoordinates = new SingleLiveEvent<>();
    public SingleLiveEvent<List<ImageFeature>> previousMarkerCoordinatesClone = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isShowingPreviousMarkers = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isErrorInFetchingMarkers = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> noMarkersAvailable = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isAllLoadingComplete = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isFloorPlanDownloaded = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isProcessingNotComplete = new SingleLiveEvent<>();
    public boolean isPreviousMarkerFetched = false;
    private String projectId;
    private Tour selectedWalkThrough;
    private PointF currentMarkerCoordinates;
    private String[] currentImage;


    public WalkthroughMapViewModel(@NonNull Application application) {
        super(application);
        workManager = WorkManager.getInstance(application);
        interiorsRepository = new InteriorsRepository(application);
        apiService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());
        isShowingPreviousMarkers.setValue(false);
        database = DataCaptureRoomDatabase.getDatabase(application);

    }

    public WorkManager getWorkManager() {
        return workManager;
    }

    public PointF getCurrentMarkerCoordinates() {
        return currentMarkerCoordinates;
    }

    public void setCurrentMarkerCoordinates(PointF currentMarkerCoordinates) {
        this.currentMarkerCoordinates = currentMarkerCoordinates;
    }

    public Tour getSelectedWalkThrough() {
        return selectedWalkThrough;
    }

    public void setSelectedWalkThrough(Tour selectedWalkThrough) {
        this.selectedWalkThrough = selectedWalkThrough;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String[] getCurrentImage() {
        return currentImage;
    }

    public void setCurrentImage(String[] currentImage) {
        this.currentImage = currentImage;
    }

    public void startProcessingCapturedImages() {
        //work constraints
        Constraints constraints = new Constraints.Builder().build();

        // Start image processing GenerateHDR => StitchImages
        OneTimeWorkRequest generateHDRRequest = new OneTimeWorkRequest.Builder(GenerateHDRImagesWorker.class)
                .setInputData(createInputDataForUri())
                .addTag(CommonConstants.GENERATE_HDR_WORKER)
                .addTag(selectedWalkThrough.getTourId())
                .addTag(selectedWalkThrough.getTowerId())
                .addTag(selectedWalkThrough.getInteriorId())
                .setConstraints(constraints)
                .build();

        OneTimeWorkRequest exportHDRWorker = new OneTimeWorkRequest.Builder(ExportHDRImagesWorker.class)
                .setInputData(createInputDataForUri())
                .addTag(CommonConstants.EXPORT_HDR_WORKER)
                .addTag(selectedWalkThrough.getInteriorId())
                .addTag(selectedWalkThrough.getTowerId())
                .addTag(selectedWalkThrough.getTourId())
                .setConstraints(constraints)
                .build();

        WorkContinuation continuation = workManager.beginUniqueWork(selectedWalkThrough.getTourId(), ExistingWorkPolicy.REPLACE, generateHDRRequest);

        continuation = continuation.then(exportHDRWorker);

        continuation.enqueue();

    }

    private Data createInputDataForUri() {
        Data.Builder builder = new Data.Builder();
        builder.putString(CommonConstants.WALKTHROUGH_ID, selectedWalkThrough.getTourId());
        builder.putString(CommonConstants.PROJECT_ID, selectedWalkThrough.getProjectId());
        builder.putString(CommonConstants.INTERIOR_TOUR_ID, selectedWalkThrough.getInteriorId());
        builder.putString(CommonConstants.TOUR_NAME, selectedWalkThrough.getTourName());
        builder.putString(CommonConstants.TOWER_ID, selectedWalkThrough.getTowerId());
        return builder.build();
    }

    public void getPreviousMarkersForInterior() {
        // Fetch previous markers for the first time only
        if (!isPreviousMarkerFetched) {
            disposableBag.add(
                    NetworkListener.hasInternetConnection(getApplication(),1500).
                            subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe((isConnected, throwable) -> {
                                if (isConnected) {
                                    showLoadingState.setValue(true);
                                    disposableBag.add(interiorsRepository.getPreviousWalkthrough(selectedWalkThrough.getProjectId(), selectedWalkThrough.getInteriorId(), selectedWalkThrough.getTourId())
                                            .subscribe(walkthrough -> {
                                                isAllLoadingComplete.setValue(true);
                                                showLoadingState.setValue(false);
                                                isPreviousMarkerFetched = true;
                                                if (walkthrough.getFeatures() == null
                                                        || walkthrough.getFeatures().getFeatures() == null
                                                        || walkthrough.getFeatures().getFeatures().isEmpty()) {
                                                    noMarkersAvailable.setValue(true);
                                                    return;
                                                }
                                                isShowingPreviousMarkers.setValue(true);
                                                previousMarkerCoordinates.setValue(walkthrough.getPreviousCapturedFeatures());
                                                previousMarkerCoordinatesClone.setValue(walkthrough.getPreviousCapturedFeatures());

                                                // Save previous markers in DB
                                                interiorsRepository.insertTourCoordinates(selectedWalkThrough.getTourId(), walkthrough.getPreviousCapturedFeatures()).subscribe();

                                            }, error -> {
                                                isAllLoadingComplete.setValue(true);
                                                isPreviousMarkerFetched = true;
                                                showLoadingState.setValue(false);
                                                if (error instanceof HttpException) {
                                                    int code = ((HttpException) error).response().code();
                                                    if (code == 404) {
                                                        noMarkersAvailable.setValue(true);
                                                    }
                                                } else isErrorInFetchingMarkers.setValue(true);
                                            }));
                                } else {
                                    disposableBag.add(
                                            interiorsRepository.getPreviousTourCoordinates(selectedWalkThrough.getTourId())
                                                    .subscribe((interiorTourCoordinates, throwable1) -> {
                                                        if (interiorTourCoordinates != null) {
                                                            isAllLoadingComplete.setValue(true);
                                                            showLoadingState.setValue(false);
                                                            isPreviousMarkerFetched = true;

                                                            isShowingPreviousMarkers.setValue(true);

                                                            List<ImageFeature> previousCoordinates = interiorTourCoordinates.stream().map(interiorTourCoordinatesDb -> new ImageFeature(new Image(interiorTourCoordinatesDb.getImageId(), interiorTourCoordinatesDb.getImageId(), interiorTourCoordinatesDb.getImageId()),
                                                                    interiorTourCoordinatesDb.getXCoordinate(), interiorTourCoordinatesDb.getYCoordinate())).collect(Collectors.toList());

                                                            previousMarkerCoordinates.setValue(previousCoordinates);
                                                            previousMarkerCoordinatesClone.setValue(previousCoordinates);

                                                        }
                                                    })
                                    );
                                }
                            })
            );

        }
    }

    public void downloadFloorPlan() {
        disposableBag.add(NetworkListener.hasInternetConnection(getApplication())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((isConnected, throwable) -> {
                    if (isConnected) {
                        showLoadingState.setValue(true);
                        disposableBag.add(getFloorPlanObservable().flatMap(azureTokenResponse ->
                                downloadFileToLocalStorage(azureTokenResponse, selectedWalkThrough).subscribeOn(Schedulers.newThread()))
                                .subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(floorPlanDownloaded -> {
                                    if (floorPlanDownloaded) {
                                        isFloorPlanDownloaded.setValue(true);
                                        showLoadingState.setValue(false);
                                    }
                                }));
                    }
                }));
    }

    private Observable<Boolean> downloadFileToLocalStorage(AzureTokenResponse azureTokenResponse, Tour walkthrough) {
        return Observable.fromCallable(() -> {
            AzureToken token = azureTokenResponse.getSasToken();
            String blobUrl = token.blobUrl(walkthrough.getFloorPlanBlobId(), CommonConstants.FLOOR_PLAN);
            try {
                Uri uri = UriUtils.downloadImageToLocalStorage(blobUrl, getApplication(), walkthrough.getFloorPlanBlobId());
                if (uri != null) {
                    // Update database with the path to the image
                    DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(getApplication());
                    database.projectCacheDAO().updateFloorPlanId(uri.getPath(), walkthrough.getTourId());
                    this.selectedWalkThrough.setFloorPlanPath(uri.getPath());
                    return true;
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            return false;
        });
    }

    private Observable<AzureTokenResponse> getFloorPlanObservable() {
        return apiService.getAzureTokenByRequest(CommonConstants.FLOOR_PLAN).toObservable();
    }

    public void cancelProcessing() {
        workManager.cancelUniqueWork(selectedWalkThrough.getTourId());
    }

    public void clearAllProcessedData() {
        disposableBag.add(
                database.tourDetailsDAO().getAllTourDetails(selectedWalkThrough.getTourId())
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe((tourDetails, throwable) -> {
                            tourDetails.stream().forEach(tourDetails1 -> ExportUtils.stopExport(tourDetails1.getStitchEventId()));
                            disposableBag.add(database.tourDetailsDAO().clearAllProcessedDetails(selectedWalkThrough.getTourId())
                                    .subscribeOn(Schedulers.io())
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(() -> Log.d("Stopped  all events", "clearAllProcessedData: ")));
                        }));


    }

    public void checkProcessingStatus() {
        disposableBag.add(
                database.tourDetailsDAO().getAllTourDetails(selectedWalkThrough.getTourId())
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe((tourDetails, throwable) -> {
                            boolean existingTour = tourDetails.stream().anyMatch(tour -> (tour.getHdrImageFileName() == null || tour.getHdrExportFileName() == null) &&
                                    !tour.isWalkThroughUploaded());

                            isProcessingNotComplete.setValue(existingTour);
                        }));
    }
}
