package com.huviair.capture.api;

import com.huviair.capture.data.model.api.media.MediaResponse;
import com.huviair.capture.data.model.api.media.ProjectAlbumsMediaResponse;
import com.huviair.capture.data.model.api.media.ProjectAlbumsRequest;
import com.huviair.capture.data.model.api.media.ProjectAlbumsResponse;
import com.huviair.capture.data.model.api.media.ProjectMediaRequest;
import com.huviair.capture.data.model.api.media.SingleAlbumResponse;

import java.util.List;
import java.util.Map;

import io.reactivex.Completable;
import io.reactivex.Observable;
import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/**
 * Interface provides different API functionality for interacting with the Node.js backend
 */

public interface MediaAPIService {

    @PUT("api/projectmedia/{project_id}/album/remove")
    Completable deleteAlbums(@Path("project_id") String projectId, @Body Map<String, List<String>> albumIds);

    @GET("api/projectmedia/{project_id}/album")
    Single<ProjectAlbumsResponse> getProjectMediaDetails(@Path("project_id") String projectId);

    @POST("api/projectmedia/{project_id}/album")
    Single<SingleAlbumResponse> createAlbum(@Path("project_id") String projectId, @Body ProjectAlbumsRequest album);

    @POST("api/projectmedia/{project_id}/album/media")
    Observable<MediaResponse> createMedia(@Path("project_id") String projectId, @Body ProjectMediaRequest mediaRequest);

    @GET("api/projectmedia/{project_id}/album/{album_id}")
    Single<ProjectAlbumsMediaResponse> getMediaOfAlbum(@Path("project_id") String projectId, @Path("album_id") String albumId);

    @PUT("api/projectmedia/{project_id}/album/{album_id}/media/bulkdelete")
    Completable deleteMedia(@Path("project_id") String projectId, @Path("album_id") String albumId, @Body Map<String, List<String>> mediaIds);

}
