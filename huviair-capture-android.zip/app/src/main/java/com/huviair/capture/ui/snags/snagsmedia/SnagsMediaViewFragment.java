package com.huviair.capture.ui.snags.snagsmedia;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.bitmap.BitmapTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.bumptech.glide.util.Util;
import com.davemorrissey.labs.subscaleview.ImageSource;
import com.huviair.capture.R;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.azure.AzureToken;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.databinding.MediaViewBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.GlideApp;
import com.huviair.capture.utils.GlideUrlUtil;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.utils.UriUtils;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

// Instances of this class are fragments representing a single
// object in our collection.
public class SnagsMediaViewFragment extends Fragment {
    public static final String MEDIA_NAME = "MEDIA_NAME";
    public static final String MEDIA_BLOB_ID = "MEDIA_BLOB_ID";

    private MediaViewBinding mediaViewerBinding;
    private String mediaBlobId;
    private String mediaName;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        mediaViewerBinding = MediaViewBinding.inflate(inflater, container, false);
        return mediaViewerBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();
        if (getArguments() != null) {
            mediaBlobId = args.getString(MEDIA_BLOB_ID);
            mediaName = args.getString(MEDIA_NAME);
        }

        requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.GONE);

        mediaViewerBinding.projectBar.toolbar.setTitle(mediaName);
        mediaViewerBinding.projectBar.toolbar.setNavigationIcon(R.drawable.navigation_back_icon);

        mediaViewerBinding.projectBar.toolbar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        if (mediaBlobId.endsWith(".mp4")) {
            mediaViewerBinding.noPreviewAvailable.setVisibility(View.VISIBLE);
            mediaViewerBinding.shareImage.setVisibility(View.GONE);
        } else {
            getUrlFromAPIAndLoadImage(false);

            mediaViewerBinding.shareImage.setOnClickListener(v -> getUrlFromAPIAndLoadImage(true));

        }
    }

    private void loadImage(String urlToLoad) {

        // Load image using glide
        GlideApp.with(this)
                .asBitmap()
                .load(new GlideUrlUtil(urlToLoad))
                .addListener(new RequestListener<Bitmap>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Bitmap> target, boolean isFirstResource) {
                        Util.postOnUiThread(() -> {
                            mediaViewerBinding.imagePreview.setImage(ImageSource.resource(R.drawable.broken_image));
                        });
                        mediaViewerBinding.loadingImagePager.setVisibility(View.GONE);
                        Toast.makeText(getContext(), "Loading image failed", Toast.LENGTH_LONG).show();
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Bitmap resource, Object model, Target<Bitmap> target, DataSource dataSource, boolean isFirstResource) {
                        mediaViewerBinding.shareImage.setVisibility(View.VISIBLE);
                        return false;
                    }
                })
                .transition(BitmapTransitionOptions.withCrossFade())
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onLoadStarted(@Nullable Drawable placeholder) {
                        super.onLoadStarted(placeholder);
                        mediaViewerBinding.loadingImagePager.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @org.jetbrains.annotations.Nullable Transition<? super Bitmap> transition) {
                        mediaViewerBinding.loadingImagePager.setVisibility(View.GONE);
                        mediaViewerBinding.imagePreview.setImage(ImageSource.bitmap(resource));
                    }

                    @Override
                    public void onLoadCleared(@org.jetbrains.annotations.Nullable Drawable placeholder) {
                    }

                });

    }

    private void loadBitmapAndDownloadToStorage(String floorPlanUrl) {
        mediaViewerBinding.loadingImagePager.setVisibility(View.VISIBLE);

        // Load image using glide
        GlideApp.with(this)
                .asBitmap()
                .load(new GlideUrlUtil(floorPlanUrl))
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @org.jetbrains.annotations.Nullable Transition<? super Bitmap> transition) {
                        Uri savedUri = UriUtils.downloadImageToStorage(requireContext(), resource, mediaBlobId);
                        mediaViewerBinding.loadingImagePager.setVisibility(View.GONE);

                        if (savedUri != null) {
                            Intent shareIntent = new Intent();
                            shareIntent.setAction(Intent.ACTION_SEND);
                            shareIntent.putExtra(Intent.EXTRA_STREAM, savedUri);
                            shareIntent.setType("image/*");
                            startActivity(Intent.createChooser(shareIntent, getResources().getText(R.string.send_to)));
                        } else
                            Toast.makeText(requireContext(), "Error in loading", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onLoadCleared(@org.jetbrains.annotations.Nullable Drawable placeholder) {
                    }

                });

    }


    private void getUrlFromAPIAndLoadImage(boolean isSharable) {
        APIService azureTokenService = APIClient.createService(APIService.class, requireContext(), APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(requireContext()).getJwtToken());
        Call<AzureTokenResponse> azureToken = azureTokenService.getAzureToken(CommonConstants.MEDIA);

        // Asynchronously call the interiors api to get the floor plan URL and display it on the imageView
        azureToken.enqueue(new Callback<AzureTokenResponse>() {
            @Override
            public void onResponse(@NotNull Call<AzureTokenResponse> call, @NotNull Response<AzureTokenResponse> response) {
                AzureToken azureTokenRes = response.body().getSasToken();
                String floorPlanUrl = azureTokenRes.blobUrl(mediaBlobId, CommonConstants.MEDIA);
                if (!isSharable) {
                    loadImage(floorPlanUrl.trim());
                    return;
                }
                loadBitmapAndDownloadToStorage(floorPlanUrl.trim());

            }

            @Override
            public void onFailure(@NotNull Call<AzureTokenResponse> call, @NotNull Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mediaViewerBinding != null) {
            mediaViewerBinding = null;
        }
    }
}

