package com.huviair.capture.ui.aerial;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.aerial.AerialTour;
import com.huviair.capture.databinding.AerialUploadFragmentBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.viewmodels.AerialUploadViewModel;

import java.util.ArrayList;
import java.util.List;

public class AerialDataUploadFragment extends Fragment {

    // Parameters to the fragment
    public static final String PROJECT_ID = "PROJECT_ID";
    public static final String FILE_PICKER_RESULT_CODE = "1001";
    private AerialUploadViewModel aerialUploadViewModel;
    private AerialUploadFragmentBinding aerialUploadFragmentBinding;
    private String projectId;
    private List<AerialTour> aerialTours;
    private int selectedPosition;

    public static AerialDataUploadFragment newInstance(String projectId) {
        AerialDataUploadFragment aerialDataUploadFragment = new AerialDataUploadFragment();
        Bundle bundle = new Bundle();
        bundle.putString(PROJECT_ID, projectId);
        aerialDataUploadFragment.setArguments(bundle);
        return aerialDataUploadFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        aerialUploadFragmentBinding = AerialUploadFragmentBinding.inflate(inflater, container, false);
        return aerialUploadFragmentBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize view model
        aerialUploadViewModel = new ViewModelProvider(requireParentFragment()).get(AerialUploadViewModel.class);

        // clear out any previous file selections
        aerialUploadViewModel.clearSelectedFiles();

        fetchAerialTourDataAndPopulate();

        toggleUploadImagesViews(false);

        bindListenersAndListenForClicks();

        observeForFilePickerChanges();

        uploadImagesOnSubmit();

        observeForWorkBeingProcessed();

        observeForInternetConnection();
    }

    private void observeForWorkBeingProcessed() {
        aerialUploadViewModel.isWorkBeingProcessed.observe(getViewLifecycleOwner(), isBeingProcessed -> {
            if (isBeingProcessed) {
                showSnackBarMessage("Upload work added to the queue", R.color.snackbar_success);
                aerialUploadViewModel.clearSelectedFiles();
                toggleUploadImagesViews(false);

                aerialUploadViewModel.isWorkBeingProcessed.setValue(false);
            }
        });
    }

    private void observeForInternetConnection() {
        aerialUploadViewModel.isDataConnectionAvailable.observe(getViewLifecycleOwner(), isDataConnectionAvailable -> {
            if (!isDataConnectionAvailable) {
                aerialUploadFragmentBinding.loadingData.setVisibility(View.GONE);

                Snackbar.make(aerialUploadFragmentBinding.getRoot(), "No internet connection available", BaseTransientBottomBar.LENGTH_SHORT)
                        .setAnchorView(requireActivity().findViewById(R.id.bottom_navigation_aerial))
                        .show();
            }
        });
    }

    private void fetchAerialTourDataAndPopulate() {
        //Invoke the call
        aerialUploadViewModel.fetchAerialToursForProject(projectId);

        aerialUploadViewModel.getAerialResponseEvent().observe(this, aerialResponse -> {
            aerialTours = aerialResponse.getTours();
            if (aerialTours.isEmpty()) {
                toggleUploadImagesViews(false);
                aerialUploadFragmentBinding.noAerialToursFound.setVisibility(View.VISIBLE);
            } else {
                toggleTourSpecificViews(true);
                aerialUploadFragmentBinding.aerialToursDropdown.setAdapter(new ArrayAdapter<>(requireContext(), R.layout.list_item, aerialResponse.getTours()));
            }

        });
    }

    private void bindListenersAndListenForClicks() {
        // Populate tourId
        aerialUploadFragmentBinding.aerialToursDropdown.setOnItemClickListener((parent, view, position, id) -> {
            refreshViews();
            String tourId = aerialTours.get(position).getTourId();
            aerialUploadViewModel.setSelectedAerialTourId(tourId);
            aerialUploadViewModel.setSelectedAerialTourName(aerialTours.get(position).getTourName());

        });

        aerialUploadFragmentBinding.selectImages.setOnClickListener(v -> {
            // Choose a directory using the system's file picker.
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(intent, Integer.parseInt(FILE_PICKER_RESULT_CODE));
        });

        aerialUploadFragmentBinding.clearImages.setOnClickListener(v -> aerialUploadViewModel.clearSelectedFiles());

        aerialUploadFragmentBinding.processData.setOnClickListener(v -> {
            new MaterialAlertDialogBuilder(requireContext())
                    .setIcon(R.drawable.start_processing_data)
                    .setTitle("Start processing tour ?")
                    .setPositiveButton("YES", (dialog, which) -> aerialUploadViewModel.startProcessingData(projectId))
                    .setNegativeButton("NO", (dialog, which) -> {
                    })
                    .setCancelable(true)
                    .show();

        });

        aerialUploadViewModel.getCurrentTourStatus().observe(getViewLifecycleOwner(), tourStatus -> {
            if (CommonConstants.SUCCESS.equals(tourStatus.getStatus())) {
                showSnackBarMessage("Started processing tour successfully", R.color.snackbar_success);
            } else if (CommonConstants.FAILURE_STATUS_CODE_NO_PARAMS.equals(tourStatus.getCode())) {
                showSnackBarMessage("Processing parameters not set for the tour", R.color.snackbar_error);
            } else if (CommonConstants.FAILURE_STATUS_CODE_IMAGES_COUNT.equals(tourStatus.getCode())) {
                showSnackBarMessage("A minimum of 10 Images are required for processing tour", R.color.snackbar_error);
            } else
                showSnackBarMessage("Something went wrong...", R.color.snackbar_error);

        });

        aerialUploadViewModel.isLoadingDataFromAPI.observe(getViewLifecycleOwner(), isLoading -> {
            int visibility = isLoading ? View.VISIBLE : View.GONE;
            aerialUploadFragmentBinding.loadingData.setVisibility(visibility);
            aerialUploadFragmentBinding.processData.setEnabled(isLoading);
        });

        aerialUploadViewModel.isErrorInLoading.observe(getViewLifecycleOwner(), isError -> {
            if (isError)
                showSnackBarMessage("Oops something went wrong ...", R.color.snackbar_error);
        });

    }

    private void uploadImagesOnSubmit() {
        aerialUploadFragmentBinding.uploadImages.setOnClickListener(v -> aerialUploadViewModel.startUploadImagesWork(projectId));
    }


    private void refreshViews() {
        aerialUploadFragmentBinding.selectImages.setEnabled(true);
        aerialUploadFragmentBinding.processData.setEnabled(true);
        aerialUploadViewModel.clearSelectedFiles();
    }


    private void observeForFilePickerChanges() {
        aerialUploadViewModel.getSelectedFiles().observe(getViewLifecycleOwner(), uris -> {
            if (uris != null && uris.size() > 0) {
                toggleUploadImagesViews(true);
                aerialUploadFragmentBinding.imagesSelectedValue.setText(String.valueOf(uris.size()));
            } else {
                toggleUploadImagesViews(false);
                aerialUploadFragmentBinding.imagesSelectedValue.setText(String.valueOf(0));
            }
        });
    }

    private void showSnackBarMessage(String text, int color) {
        Snackbar.make(aerialUploadFragmentBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_LONG)
                .setBackgroundTint(ContextCompat.getColor(requireContext(), color))
                .setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                .setAnchorView(requireActivity().findViewById(R.id.bottom_navigation_aerial))
                .show();
    }

    private void toggleUploadImagesViews(boolean b) {
        int visibility = b ? View.VISIBLE : View.GONE;
        aerialUploadFragmentBinding.uploadViewHeader.setVisibility(visibility);
        aerialUploadFragmentBinding.imagesSelectedHeader.setVisibility(visibility);
        aerialUploadFragmentBinding.uploadImages.setVisibility(visibility);
        aerialUploadFragmentBinding.clearImages.setVisibility(visibility);
        aerialUploadFragmentBinding.imagesSelectedValue.setVisibility(visibility);
    }

    private void toggleTourSpecificViews(boolean isActive) {
        int visibility = isActive ? View.VISIBLE : View.GONE;
        aerialUploadFragmentBinding.imageUploadDivider.setVisibility(visibility);
        aerialUploadFragmentBinding.aerialToursTextInput.setVisibility(visibility);
        aerialUploadFragmentBinding.selectImages.setVisibility(visibility);
        aerialUploadFragmentBinding.processData.setVisibility(visibility);
        aerialUploadFragmentBinding.fragmentHeader.setVisibility(visibility);

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {

        if (requestCode == Integer.parseInt(FILE_PICKER_RESULT_CODE) && resultCode == Activity.RESULT_OK) {
            if (resultData != null) { // checking empty selection
                Uri folderUri = resultData.getData();
                getPermissionOverRestarts(folderUri);
                readAndAddAllFilesOfUri(folderUri);
            }
        }
    }

    private void readAndAddAllFilesOfUri(Uri folderUri) {
        DocumentFile file = DocumentFile.fromTreeUri(requireContext(), folderUri);
        if (file != null) {
            List<Uri> fileUris = getAllFilesInTheDirectory(file);
            fileUris.stream().forEach(uri -> aerialUploadViewModel.addSelectedFiles(uri));
        }
    }

    private List<Uri> getAllFilesInTheDirectory(DocumentFile folder) {
        List<Uri> fileUris = new ArrayList<>();

        if (folder.isDirectory()) {
            DocumentFile[] documentFiles = folder.listFiles();
            for (DocumentFile documentFile : documentFiles) {
                fileUris.add(documentFile.getUri());
            }
            return fileUris;
        }
        return fileUris;
    }

    private void getPermissionOverRestarts(Uri documentUri) {
        requireContext().getContentResolver().takePersistableUriPermission(documentUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (aerialUploadFragmentBinding != null) {
            aerialUploadFragmentBinding = null;
        }
    }

}