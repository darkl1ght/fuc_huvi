package com.huviair.capture.data.model.api.media;

import java.util.List;

public class ProjectAlbumsResponse {

    private List<Album> album;

    public List<Album> getAlbum() {
        return album;
    }

    public void setAlbum(List<Album> album) {
        this.album = album;
    }
}
