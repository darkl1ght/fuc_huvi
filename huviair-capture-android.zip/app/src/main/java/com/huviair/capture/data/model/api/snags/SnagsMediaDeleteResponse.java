package com.huviair.capture.data.model.api.snags;

public class SnagsMediaDeleteResponse {
    private Snag task;

    public Snag getTask() {
        return task;
    }
}
