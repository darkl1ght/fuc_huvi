package com.huviair.capture.data.model.api.snags;

import java.util.List;

public class Filters {

    private List<String> workPackage;
    private String startDate;
    private String endDate;
    private String priority;
    private String[] punchListId;
    private boolean isNonConformity;

    public Filters() {

    }

    public Filters(List<String> workPackage, String startDate, String endDate, String priority, String[] punchListId, boolean isNonConformity) {
        this.workPackage = workPackage;
        this.startDate = startDate;
        this.endDate = endDate;
        this.priority = priority;
        this.isNonConformity = isNonConformity;
        this.punchListId = punchListId;
    }

    public List<String> getWorkPackage() {
        return workPackage;
    }

    public String getPriority() {
        return priority;
    }

    public String getEndDate() {
        return endDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public boolean isNonConformity() {
        return isNonConformity;
    }

    public String[] getPunchListId() {
        return punchListId;
    }
}
