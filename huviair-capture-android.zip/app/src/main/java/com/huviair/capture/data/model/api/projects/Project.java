package com.huviair.capture.data.model.api.projects;

import java.io.Serializable;

public class Project implements Serializable {
    private String projectName;
    private String projectId;
    private String location;
    private String type;

    private long virtualVideoCaptureDurationLimit = 14;  // Duration in minutes

    public Project(String projectName, String projectId, String location, String projectType, long virtualVideoCaptureDurationLimit) {
        this.projectName = projectName;
        this.projectId = projectId;
        this.location = location;
        this.type = projectType;
        this.virtualVideoCaptureDurationLimit = virtualVideoCaptureDurationLimit;
    }

    public Project(String projectName, String projectId) {
        this.projectId = projectId;
        this.projectName = projectName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getVirtualVideoCaptureDurationLimit() {
        return virtualVideoCaptureDurationLimit;
    }

    public void setVirtualVideoCaptureDurationLimit(long virtualVideoCaptureDurationLimit) {
        if(virtualVideoCaptureDurationLimit == 0 ){
            this.virtualVideoCaptureDurationLimit = 14;
        }
        else this.virtualVideoCaptureDurationLimit = virtualVideoCaptureDurationLimit;

    }
}
