package com.huviair.capture.data.model.api.aerial;

public class AerialTour {
    private String tourId, tourName, tourDate;
    private String projectId;
    private TourStatus status;

    public TourStatus getTourStatus() {
        return status;
    }

    public String getTourId() {
        return tourId;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    public String getTourDate() {
        return tourDate;
    }

    public void setTourDate(String tourDate) {
        this.tourDate = tourDate;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }


    // used to set value in the dropdown
    @Override
    public String toString() {
        return tourName;
    }

}
