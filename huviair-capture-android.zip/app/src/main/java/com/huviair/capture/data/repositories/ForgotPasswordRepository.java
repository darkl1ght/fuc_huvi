package com.huviair.capture.data.repositories;

import android.app.Application;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.ForgotPasswordRequest;
import com.huviair.capture.data.model.api.ForgotPasswordResponse;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.projects.ProjectList;
import com.huviair.capture.utils.SharedPreferencesManager;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class ForgotPasswordRepository {

    private final APIService service;


    public ForgotPasswordRepository() {
        service = APIClient.createServiceForLogin(APIService.class, APIClient.getSecurityApi());
    }

    public Single<ForgotPasswordResponse> forgotPassword(String emailId) {
        return service.resetPassword(new ForgotPasswordRequest(emailId))
                         .observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.io());

    }

}
