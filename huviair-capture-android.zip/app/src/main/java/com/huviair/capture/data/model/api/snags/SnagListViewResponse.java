package com.huviair.capture.data.model.api.snags;

public class SnagListViewResponse {
    private SnagListResponse snagsResponse;

    public SnagListResponse getSnagsResponse() {
        return snagsResponse;
    }
}
