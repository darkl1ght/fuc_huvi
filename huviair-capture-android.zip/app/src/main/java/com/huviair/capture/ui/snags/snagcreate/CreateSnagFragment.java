package com.huviair.capture.ui.snags.snagcreate;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.color.MaterialColors;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.snags.CreateSnagDetails;
import com.huviair.capture.data.model.api.snags.CreateSnagRequest;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagMasterData;
import com.huviair.capture.data.model.api.snags.WorkLocation;
import com.huviair.capture.data.model.api.snags.WorkPackage;
import com.huviair.capture.data.model.api.tours.Feature;
import com.huviair.capture.databinding.CreateSnagFragmentBinding;
import com.huviair.capture.ui.common.MultiSelectFragment;
import com.huviair.capture.ui.common.MultiSelectViewItem;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.utils.GlideApp;
import com.huviair.capture.viewmodels.CreateSnagViewModel;
import com.huviair.capture.viewmodels.SnagViewModel;
import com.yanzhenjie.album.Album;
import com.yanzhenjie.album.AlbumFile;
import com.yanzhenjie.album.api.widget.Widget;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

public class CreateSnagFragment extends Fragment implements MultiSelectFragment.OnSaveClickListener {

    private static final String PROJECT_ID = "PROJECT_ID";

    // View model - Fragment level
    private CreateSnagViewModel createSnagViewModel;
    // View model - Activity level
    private SnagViewModel snagViewModel;

    private CreateSnagFragmentBinding createSnagFragmentBinding;

    // Project Details
    private String projectId;

    private String selectedDateValue;

    // Dropdown data
    private List<WorkLocation> workLocationValues;
    private List<WorkPackage> workPackageValues;

    private SnagMasterData snagMasterData;

    private ActivityResultLauncher<Intent> pickMultipleMediaLauncher;
    private ActivityResultLauncher<Intent> pickCameraMediaLauncher;

    public static CreateSnagFragment newInstance(String projectId) {
        CreateSnagFragment fragment = new CreateSnagFragment();
        Bundle args = new Bundle();
        args.putSerializable(PROJECT_ID, projectId);
        fragment.setArguments(args);
        return fragment;
    }
    public String getPathFromUri(Uri contentUri) {
        String resPath = null;
        String[] types = { MediaStore.Images.Media.DATA };
        Cursor cursor = getContext().getContentResolver().query(contentUri, types, null, null, null);
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            resPath = cursor.getString(columnIndex);
        }
        cursor.close();
        return resPath;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
        }
        // read images
        pickMultipleMediaLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != Activity.RESULT_OK) {
                        Toast.makeText(requireContext(), "Error while selecting media!", Toast.LENGTH_LONG).show();
                    } else {
                        Intent data = result.getData();
                        if (data != null) {
                            ClipData uris = data.getClipData();
                            List<AlbumFile> fileList = new ArrayList<>();
                            if(uris==null){
                                Uri singleFileUri = data.getData();
                                String path = getRealPathFromURI_API19AndAbove(getContext(), singleFileUri);
                                AlbumFile albumFile = new AlbumFile();
                                albumFile.setPath(path);
                                fileList.add(albumFile);
                            } else {
                                for (int index = 0; index < uris.getItemCount(); index++) {
                                    Uri uri = uris.getItemAt(index).getUri();
                                    String path = getRealPathFromURI_API19AndAbove(getContext(), uri);
                                    AlbumFile albumFile = new AlbumFile();
                                    albumFile.setPath(path);
                                    fileList.add(albumFile);
                                }
                            }
                            createSnagViewModel.setImagePaths(fileList);
                            previewImages();

                        }
                    }
                });
        //camera
        pickCameraMediaLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != Activity.RESULT_OK) {
                        Toast.makeText(requireContext(), "Error while camera capture!", Toast.LENGTH_LONG).show();
                    } else {
                        Intent data = result.getData();
                        Bundle extras = data.getExtras();
                        Bitmap imageBitmap = (Bitmap) extras.get("data");
                        createSnagViewModel.setImageBitMap(imageBitmap);
                        Uri imageUri = saveToGallery(imageBitmap);

                        if (imageUri!=null){
                            AlbumFile albumFile = new AlbumFile();
                            albumFile.setPath(imageUri.toString());
                            //Add to list
                            List<AlbumFile> albumFileList = new ArrayList<>();
                            albumFileList.add(albumFile);
                            createSnagViewModel.setImagePaths(albumFileList);
                            previewImages();
                        }
                    }
                });
    }

    private Uri saveToGallery(Bitmap bitmapImage) {
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName= "IMG_"+timeStamp+".jpeg";
        File imageFile = new File(storageDir,fileName);
        Uri imageUri =null;
        try{
            FileOutputStream outputStream = new FileOutputStream(imageFile);
            bitmapImage.compress(Bitmap.CompressFormat.JPEG,100,outputStream);
            outputStream.flush();
            outputStream.close();
            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            imageUri = Uri.fromFile(imageFile);
            mediaScanIntent.setData(imageUri);

        } catch (Exception ex){
            Toast.makeText(requireContext(), "Error while camera capture!", Toast.LENGTH_LONG).show();
        }
        return imageUri;
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        // Remove the bottom nav
        requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.GONE);

        createSnagFragmentBinding = CreateSnagFragmentBinding.inflate(inflater, container, false);
        return createSnagFragmentBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // View models initialisation
        createSnagViewModel = new ViewModelProvider(this,
                new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication()))
                .get(CreateSnagViewModel.class);
        snagViewModel = new ViewModelProvider(requireActivity()).get(SnagViewModel.class);

        // Toolbar population
        createSnagFragmentBinding.snagToolBar.toolBar.setTitle("Create Snag");
        createSnagFragmentBinding.snagToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        createSnagFragmentBinding.snagToolBar.toolBar
                .setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        createSnagFragmentBinding.snagTypetoggleButton.check(R.id.non_conformity);

        fetchAndPopulateDropDownValues();
        populateDatePicker();
        listenForButtonClicks();
        observeFormData();
        observeForSnagCreate();
        onClickOfImagePreview();
        previewImages();

        // Observe for the events coming from @SnagFloorPlanFragment
        observeForFloorPlanChanges();
        // observe for approver clicks
        observeForApproverClicks();

        observeForLiveWorkTradeData();

    }

    private void observeForLiveWorkTradeData() {
        createSnagFragmentBinding.workTradeDropdown.setOnItemClickListener((parent, view, position, id) -> {
            if (createSnagViewModel.stage1MultiSelectItems.getValue() != null) {
                createSnagViewModel.stage1MultiSelectItems.setValue(null);
            }
            if (createSnagViewModel.stage2MultiSelectItems.getValue() != null) {
                createSnagViewModel.stage2MultiSelectItems.setValue(null);
            }
        });
    }

    private void observeForFloorPlanChanges() {
        snagViewModel.isCreateSnagFloorPlanSaved().observe(getViewLifecycleOwner(),
                snag -> createSnagViewModel.setSnagWithFloorPlanDetails(snag));
    }

    private void observeFormData() {
        createSnagViewModel.getFormState().observe(getViewLifecycleOwner(), createSnagFormState -> {
            if (createSnagFormState == null)
                return;

            if (createSnagFormState.getSnagDescriptionError() != null) {
                createSnagFragmentBinding.snagDescription
                        .setError(getString(createSnagFormState.getSnagDescriptionError()));
            } else
                createSnagFragmentBinding.snagDescription.setError(null);

            if (createSnagFormState.getDueDateError() != null) {
                createSnagFragmentBinding.snagDueDate.setError(getString(createSnagFormState.getDueDateError()));
            } else
                createSnagFragmentBinding.snagDueDate.setError(null);

            if (createSnagFormState.getSelectLevelError() != null) {
                createSnagFragmentBinding.selectLevel.setError(getString(createSnagFormState.getSelectLevelError()));
            } else
                createSnagFragmentBinding.selectLevel.setError(null);

            if (createSnagFormState.getWorkTradeError() != null) {
                createSnagFragmentBinding.workTrade.setError(getString(createSnagFormState.getWorkTradeError()));
            } else
                createSnagFragmentBinding.workTrade.setError(null);

            if (createSnagFormState.getSelectStage1Error() != null) {
                createSnagFragmentBinding.stage1Approvers
                        .setError(getString(createSnagFormState.getSelectStage1Error()));
            } else
                createSnagFragmentBinding.stage1Approvers.setError(null);

            if (createSnagFormState.getSelectStage2Error() != null) {
                createSnagFragmentBinding.stage2Approvers
                        .setError(getString(createSnagFormState.getSelectStage2Error()));
            } else
                createSnagFragmentBinding.stage2Approvers.setError(null);

            createSnagFragmentBinding.createSnagFab.setEnabled(createSnagFormState.isDataValid());

        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                createSnagViewModel.formDataChanged(
                        createSnagFragmentBinding.snagDescriptionEditText.getText().toString(),
                        createSnagFragmentBinding.snagDueDate.getEditText().getText().toString(),
                        createSnagFragmentBinding.workTradeDropdown.getText().toString(),
                        createSnagFragmentBinding.selectLevelDropdown.getText().toString());
            }
        };

        createSnagFragmentBinding.snagDescription.getEditText().addTextChangedListener(afterTextChangedListener);
        createSnagFragmentBinding.snagDueDate.getEditText().addTextChangedListener(afterTextChangedListener);
        createSnagFragmentBinding.workTradeDropdown.addTextChangedListener(afterTextChangedListener);
        createSnagFragmentBinding.selectLevelDropdown.addTextChangedListener(afterTextChangedListener);
        createSnagFragmentBinding.stage1ApproversEditText.addTextChangedListener(afterTextChangedListener);
        createSnagFragmentBinding.stage2ApproversEditText.addTextChangedListener(afterTextChangedListener);
    }

    private void populateDatePicker() {
        createSnagFragmentBinding.snagDueDate.getEditText().setOnClickListener(v -> {
            MaterialDatePicker.Builder<Long> builder = MaterialDatePicker.Builder.datePicker();
            MaterialDatePicker<Long> picker = builder.setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                    .setTitleText("Snag Due Date")
                    .build();

            picker.addOnPositiveButtonClickListener(selection -> {
                selectedDateValue = DateFormatUtils.convertDate(selection, CommonConstants.MONGO_DATE_FORMAT);
                createSnagFragmentBinding.snagDueDate.getEditText()
                        .setText(DateFormatUtils.convertDate(selection, "dd-MM-yyyy"));

            });
            picker.show(getChildFragmentManager(), "Date picker");
        });
    }

    private void fetchAndPopulateDropDownValues() {
        createSnagViewModel.getSnagsMasterData(projectId);
        createSnagViewModel.getSnagMasterDataMutableLiveData().observe(getViewLifecycleOwner(), snagResult -> {
            if (snagResult.getSuccess() != null && snagResult.getSuccess().getSnagMasterData() != null) {
                snagMasterData = snagResult.getSuccess().getSnagMasterData();

                workLocationValues = snagMasterData.getWorkLocations();
                workPackageValues = snagMasterData.getWorkPackage();

                // filter out work packages without any approvers
                workPackageValues = workPackageValues.stream()
                        .filter(workPackage -> (workPackage.getLevel1() != null && workPackage.getLevel2() != null) &&
                                (workPackage.getLevel1().length > 0 && workPackage.getLevel2().length > 0))
                        .collect(Collectors.toList());

                // Populate work location values to viewmodel
                createSnagViewModel.workLocations.setValue(workLocationValues);

                createSnagFragmentBinding.selectLevelDropdown.setAdapter(
                        new ArrayAdapter<>(requireContext(), R.layout.list_item, workLocationValues));

                createSnagFragmentBinding.workTradeDropdown.setAdapter(
                        new ArrayAdapter<>(requireContext(), R.layout.list_item, workPackageValues));

                // Disable key board on item select
                createSnagFragmentBinding.selectLevelDropdown.setOnItemClickListener((parent, view, position, id) -> {
                    InputMethodManager imm = (InputMethodManager) requireContext()
                            .getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(createSnagFragmentBinding.selectLevelDropdown.getWindowToken(), 0);
                });

            }
        });
    }

    private void listenForButtonClicks() {
        // Camera FAB listener
        createSnagFragmentBinding.camera.setOnClickListener(v -> {
            if(ContextCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.CAMERA},1);
                return;
            }
            pickCameraMediaLauncher.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
//            if (Build.VERSION.SDK_INT >= 33) {
//                if(ContextCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
//                    ActivityCompat.requestPermissions(getActivity(),
//                            new String[]{Manifest.permission.CAMERA},1);
//                    return;
//                }
//                pickCameraMediaLauncher.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
//            } else {
//
//                Album.camera(this) // Camera function.
//                        .image() // Take Picture.
//                        .onResult(result -> {
//                            AlbumFile albumFile = new AlbumFile();
//                            albumFile.setPath(result);
//                            List<AlbumFile> fileList = new ArrayList<>();
//                            fileList.add(albumFile);
//                            createSnagViewModel.setImagePaths(fileList);
//                            previewImages();
//                        })
//                        .onCancel(result -> {
//                        })
//                        .start();
//            }

        });

        int brandColor = ContextCompat.getColor(requireContext(), R.color.brand_color);

        // Change color only in night mode
        int nightModeFlags = requireContext().getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            brandColor = MaterialColors.getColor(requireContext(), R.attr.colorOnPrimary,
                    ContextCompat.getColor(requireContext(), R.color.brand_color));
        }

        int secondaryColor = ContextCompat.getColor(requireContext(), R.color.brand_secondary);
        // Gallery FAB listener
        int finalBrandColor = brandColor;

        createSnagFragmentBinding.gallery.setOnClickListener(v -> {
            // For API compatibility above 33
            if (Build.VERSION.SDK_INT >= 33) {

                pickMultipleMediaLauncher.launch(new Intent(MediaStore.ACTION_PICK_IMAGES)

                        .putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, 10));

            }
            else {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    pickMultipleMediaLauncher.launch(intent);
                } catch (Exception ex){
                    Log.e("ErrorPicker", ex.getMessage());
                }
//                Album.image(this) // Image and video mix options.
//                        .multipleChoice() // Multi-Mode, Single-Mode: singleChoice().
//                        .selectCount(10)
//                        .columnCount(2) // The number of columns in the page list.
//                        .widget(
//                                Widget.newDarkBuilder(getContext())
//                                        .statusBarColor(finalBrandColor)
//                                        .toolBarColor(finalBrandColor)
//                                        .title("Select Media")
//                                        .buttonStyle( // Used to configure the style of button when the image/video is
//                                                      // not found.
//                                                Widget.ButtonStyle.newDarkBuilder(getContext()) // With Widget's Builder
//                                                                                                // model.
//                                                        .setButtonSelector(finalBrandColor, secondaryColor) // Button
//                                                                                                            // selector.
//                                                        .build())
//                                        .build())
//                        .camera(true) // Whether the camera appears in the Item.
//                        .onResult(result -> {
//                            createSnagViewModel.setImagePaths(result);
//                            previewImages();
//                        })
//                        .onCancel(result -> {
//                            Toast.makeText(getContext(), "No media selected", Toast.LENGTH_LONG).show();
//                            // The user canceled the operation.
//                        })
//                        .start();
            }
        }

        );

        // Clear images button listener
        createSnagFragmentBinding.clearImagesButton.setOnClickListener(v -> {
            if (!createSnagViewModel.getSelectedImagesPaths().getValue().isEmpty()) {
                createSnagViewModel.setImagePaths(new ArrayList<>());
                clearImages();
            }
        });

        // Create Snag ( Will be created only if the form is in valid state)
        createSnagFragmentBinding.createSnagFab.setOnClickListener(v -> {
            String snagDescription = createSnagFragmentBinding.snagDescriptionEditText.getText().toString();
            String remarks = createSnagFragmentBinding.snagRemarksEditText.getText().toString();

            // Populate floor plan details to the new feature object
            Feature feature = null;
            if (createSnagViewModel.getSnagWithFloorPlanDetails() != null) {
                feature = createSnagViewModel.getSnagWithFloorPlanDetails().getFloorPlan().getFeature();
            }

            // Prepare request
            CreateSnagRequest createSnagRequest = new CreateSnagRequest();

            String snagType = createSnagFragmentBinding.snagTypetoggleButton.getCheckedButtonId() == R.id.non_conformity
                    ? "NC"
                    : "OB";

            createSnagRequest.setPunchList(new CreateSnagDetails().builder(snagDescription, remarks, getWorkTradeId(),
                    selectedDateValue, new String[] { getWorkLocationId() }, createSnagViewModel.getSnagMediaList(),
                    feature, snagType));

            // Submit for creation
            createSnagViewModel.createSnag(projectId, createSnagRequest);
        });

        // Snag Media
        createSnagViewModel.getSelectedImagesPaths().observe(getViewLifecycleOwner(), albumFiles -> {
            if (albumFiles.size() > 0) {
                createSnagFragmentBinding.clearImagesButton.setVisibility(View.VISIBLE);
            } else
                createSnagFragmentBinding.clearImagesButton.setVisibility(View.GONE);
        });

        // Floor plan button
        createSnagFragmentBinding.floorPlanMarkerBtn.setOnClickListener(v -> {
            if (!createSnagFragmentBinding.selectLevelDropdown.getText().toString().equals("")) {
                Optional<WorkLocation> workLocation = snagMasterData.getWorkLocations().stream()
                        .filter(x -> x.getLocationId().equals(getWorkLocationId())).findFirst();

                if (workLocation.isPresent()) {
                    if (workLocation.get().getDrawing() != null) {
                        if (createSnagViewModel.getSnagWithFloorPlanDetails() == null) {
                            createSnagViewModel.setSnagWithFloorPlanDetails(
                                    new Snag().floorPlanBuilder(workLocation.get().getDrawing()));
                        }
                        // Display floor plan by passing an event to Snag Activity
                        snagViewModel.setDisplayFloorPlanForSnag(createSnagViewModel.getSnagWithFloorPlanDetails(),
                                true);
                    } else {
                        showSnackBarMessage("No Floor Plan present", R.color.snackbar_error);
                    }

                }
            } else
                showSnackBarMessage("Please select work location", R.color.snackbar_error);
        });

        createSnagViewModel.stage1MultiSelectItems.observe(getViewLifecycleOwner(), multiSelectViewItems -> {
            if (multiSelectViewItems == null) {
                createSnagFragmentBinding.stage1ApproversEditText.setText(null);
            } else {
                long count = multiSelectViewItems.stream().filter(MultiSelectViewItem::isSelected).count();
                String message = (count != 0)
                        ? String.format(getResources().getString(R.string.approvers_selected), count)
                        : null;
                createSnagFragmentBinding.stage1ApproversEditText.setText(message);
            }
        });

        createSnagViewModel.stage2MultiSelectItems.observe(getViewLifecycleOwner(), multiSelectViewItems -> {
            if (multiSelectViewItems == null) {
                createSnagFragmentBinding.stage2ApproversEditText.setText(null);
            } else {
                long count = multiSelectViewItems.stream().filter(MultiSelectViewItem::isSelected).count();
                String message = (count != 0)
                        ? String.format(getResources().getString(R.string.approvers_selected), count)
                        : null;
                createSnagFragmentBinding.stage2ApproversEditText.setText(message);
            }
        });

    }

    private String getWorkTradeId() {
        String workId = "";
        for (WorkPackage workPackageValue : workPackageValues) {
            if (workPackageValue.getTradeName()
                    .equalsIgnoreCase(createSnagFragmentBinding.workTradeDropdown.getText().toString())) {
                workId = workPackageValue.getTradeId();
                break;
            }
        }
        return workId;
    }

    private String getWorkLocationId() {
        String locationId = "";
        for (WorkLocation workLocation : workLocationValues) {
            if (workLocation.getLocation()
                    .equalsIgnoreCase(createSnagFragmentBinding.selectLevelDropdown.getText().toString())) {
                locationId = workLocation.getLocationId();
                break;
            }
        }
        return locationId;
    }

    private void observeForSnagCreate() {
        createSnagViewModel.getIsSnagCreated().observe(getViewLifecycleOwner(), snagCreated -> {
            if (getViewLifecycleOwner().getLifecycle().getCurrentState() == Lifecycle.State.RESUMED) {
                if (snagCreated) {
                    snagViewModel.setIsNewSnagCreated(true);
                    Toast.makeText(requireContext(), "Snag created successfully", Toast.LENGTH_LONG).show();
                }
            }

        });

        createSnagViewModel.getIsSnagCreationError().observe(getViewLifecycleOwner(), snagError -> {
            if (snagError) {
                Toast.makeText(requireContext(), "Snag creation failed", Toast.LENGTH_LONG).show();
            }
        });

        createSnagViewModel.getIsSnagCreationStarted().observe(getViewLifecycleOwner(), snagCreationStarted -> {
            toggleButtons(!snagCreationStarted);
            createSnagFragmentBinding.loadingCreateSnag.setVisibility(snagCreationStarted ? View.VISIBLE : View.GONE);
        });

    }

    private void toggleButtons(boolean isActive) {
        if (!isActive)
            createSnagFragmentBinding.createSnagFab.hide();
        else
            createSnagFragmentBinding.createSnagFab.show();
        createSnagFragmentBinding.floorPlanMarkerBtn.setEnabled(isActive);
        createSnagFragmentBinding.gallery.setEnabled(isActive);
        createSnagFragmentBinding.camera.setEnabled(isActive);
    }

    private void previewImages() {
        if (createSnagViewModel.getSelectedImagesPaths() != null
                && createSnagViewModel.getSelectedImagesPaths().getValue().size() > 0) {
            GlideApp.with(requireContext())
                    .load(createSnagViewModel.getSelectedImagesPaths().getValue().get(0).getPath())
                    .circleCrop()
                    .placeholder(R.drawable.ic_baseline_cloud_download_24)
                    .error(R.drawable.image_preview_brand_color)
                    .into(createSnagFragmentBinding.imagesToUploadPreview);

            createSnagFragmentBinding.imagesToUploadPreview.setVisibility(View.VISIBLE);
        }

    }

    private void clearImages() {
        createSnagFragmentBinding.imagesToUploadPreview.invalidate();
        createSnagFragmentBinding.imagesToUploadPreview.setImageBitmap(null);
        createSnagFragmentBinding.imagesToUploadPreview.setVisibility(View.GONE);

    }

    public void onClickOfImagePreview() {
        createSnagFragmentBinding.imagesToUploadPreview.setOnClickListener(v -> {
            List<String> selectedImages = createSnagViewModel.getSelectedImagesPaths().getValue().stream()
                    .map(AlbumFile::getPath).collect(Collectors.toList());
            snagViewModel.setOpenSnagMediaViewerFragment(new CreateSnagMediaDetails(0, selectedImages));
        });

    }

    private void showSnackBarMessage(String text, int color) {
        Snackbar.make(createSnagFragmentBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_SHORT)
                .setBackgroundTint(ContextCompat.getColor(requireContext(), color))
                .setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                .show();
    }

    // Approvers on edit text click - check and open the multiselect fragment
    private void observeForApproverClicks() {
        // If worklocation is chosen, open the multi-select dialog
        createSnagFragmentBinding.stage1ApproversEditText.setOnClickListener(v -> {
            String workTradeId = getWorkTradeId();
            if (!CommonConstants.EMPTY_STRING.equals(workTradeId) && workPackageValues != null
                    && workPackageValues.size() > 0) {
                List<MultiSelectViewItem> level1Approvers;
                // populate data for the first time of selection
                if (createSnagViewModel.stage1MultiSelectItems.getValue() == null) {
                    level1Approvers = populateMultiSelectList(workTradeId, true);
                } else
                    level1Approvers = createSnagViewModel.stage1MultiSelectItems.getValue();

                invokeMultiSelectFragment(level1Approvers);
            } else {
                showSnackBarMessage("Please select work trade", R.color.snackbar_error);
            }
        });

        createSnagFragmentBinding.stage2ApproversEditText.setOnClickListener(v -> {
            String workTradeId = getWorkTradeId();
            if (!CommonConstants.EMPTY_STRING.equals(workTradeId) && workPackageValues != null
                    && workPackageValues.size() > 0) {
                List<MultiSelectViewItem> level2Approvers;
                // populate data for the first time of selection
                if (createSnagViewModel.stage2MultiSelectItems.getValue() == null) {
                    level2Approvers = populateMultiSelectList(workTradeId, false);
                } else
                    level2Approvers = createSnagViewModel.stage2MultiSelectItems.getValue();

                invokeMultiSelectFragment(level2Approvers);
            } else {
                showSnackBarMessage("Please select work trade", R.color.snackbar_error);
            }
        });
    }

    private void invokeMultiSelectFragment(List<MultiSelectViewItem> multiSelectViewItems) {
        MultiSelectFragment multiSelectFragment = MultiSelectFragment.newInstance(multiSelectViewItems,
                getString(R.string.select_approver), getString(R.string.search_approver));
        multiSelectFragment.setOnSaveClickListener(this);
        multiSelectFragment.show(getChildFragmentManager(), "approvers");
    }

    private List<MultiSelectViewItem> populateMultiSelectList(String workTradeId, boolean isLevel1) {
        return workPackageValues.stream()
                .filter(selectedWorkPackage -> selectedWorkPackage.getTradeId().equals(workTradeId))
                .map(workPackage -> isLevel1 ? workPackage.getLevel1() : workPackage.getLevel2())
                .flatMap(Arrays::stream)
                .map(email -> new MultiSelectViewItem(email, email, 0, isLevel1 ? 1 : 0))
                .collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public void onSave(List<MultiSelectViewItem> multiSelectViewItems) {
        if (!multiSelectViewItems.isEmpty() && multiSelectViewItems.get(0).isLevel1Approver()) {
            createSnagViewModel.stage1MultiSelectItems.setValue(multiSelectViewItems);
        } else if (!multiSelectViewItems.isEmpty() && !multiSelectViewItems.get(0).isLevel1Approver()) {
            createSnagViewModel.stage2MultiSelectItems.setValue(multiSelectViewItems);
        }
    }

    public static String getRealPathFromURI_API19AndAbove(final Context context, final Uri uri) {
// DocumentProvider
        if ( DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
            else if ("content".equalsIgnoreCase(uri.getScheme())) {
                return getDataColumn(context, uri, null, null);
            }
        }
        else if ("content".equalsIgnoreCase(uri.getScheme())) { // MediaStore (and general)
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    /**
     * Get the value of the data column for this Uri. This is useful for
     * MediaStore Uris, and other file-based ContentProviders.
     *
     * @param context       The context.
     * @param uri           The Uri to query.
     * @param selection     (Optional) Filter used in the query.
     * @param selectionArgs (Optional) Selection arguments used in the query.
     * @return The value of the _data column, which is typically a file path.
     */
    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }


    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

}
