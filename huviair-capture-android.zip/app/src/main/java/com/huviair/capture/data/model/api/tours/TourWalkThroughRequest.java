package com.huviair.capture.data.model.api.tours;

public class TourWalkThroughRequest {

    private Image image;
    private ImageFeature feature;

    public void addImagesAndFeatures(Image image, int imageNumber, Double xCoordinate, Double yCoordinate) {
        this.image = image;
        this.feature = new ImageFeature(image, imageNumber, xCoordinate, yCoordinate);
    }

    @Override
    public String toString() {
        return "TourWalkThroughRequest{" +
                "images=" + image +
                ", feature=" + feature +
                '}';
    }
}
