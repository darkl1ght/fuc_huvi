package com.huviair.capture.data.model.api.projectCache;

import com.huviair.capture.data.model.api.projects.ProjectDetails;

import java.io.Serializable;
import java.util.List;

public class ProjectsAndInteriorsResponse implements Serializable {
    private List<ProjectDetails> projects;

    public List<ProjectDetails> getProjects() {
        return projects;
    }

    public void setProjects(List<ProjectDetails> projects) {
        this.projects = projects;
    }

    @Override
    public String toString() {
        return "ProjectsAndInteriorsResponse{" +
                "projects=" + projects +
                '}';
    }
}
