package com.huviair.capture.ui.snags.snagutils;

import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagMediaFloorPlan;
import com.huviair.capture.data.model.api.tours.Feature;
import com.huviair.capture.data.model.api.tours.Image;
import com.huviair.capture.data.model.api.tours.ImageFeature;
import com.huviair.capture.ui.interiors.tours.Coordinates;

import java.util.ArrayList;
import java.util.List;

public class SnagUtils {

    public static SnagMediaFloorPlan populateFloorPlanFeatures(Snag snag, List<Coordinates> selectedCoordinates) {
        String blobReference = snag.getFloorPlan().getBlobReference();
        List<ImageFeature> features = new ArrayList<>();
        selectedCoordinates.stream().forEach(coordinates -> features.add(new ImageFeature(new Image(blobReference, blobReference, blobReference), coordinates.getX(), coordinates.getY())));

        return new SnagMediaFloorPlan(blobReference, new Feature(features));
    }
}
