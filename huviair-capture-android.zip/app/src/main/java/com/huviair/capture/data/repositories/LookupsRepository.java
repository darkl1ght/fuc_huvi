package com.huviair.capture.data.repositories;

import android.app.Application;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.LookupsAPIService;
import com.huviair.capture.data.model.api.lookups.LookupsResponse;
import com.huviair.capture.utils.SharedPreferencesManager;

import io.reactivex.Single;

public class LookupsRepository {

    private final LookupsAPIService lookupsAPIService;


    public LookupsRepository(Application application) {
        lookupsAPIService = APIClient.createService(LookupsAPIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());
    }

    public Single<LookupsResponse> getLookupsByType(String type) {
        return lookupsAPIService.getLookups(type);

    }


}
