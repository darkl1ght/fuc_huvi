package com.huviair.capture.ui.snags;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelProvider;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.projects.Project;
import com.huviair.capture.databinding.ActivitySnagBinding;
import com.huviair.capture.ui.aerial.AerialActivity;
import com.huviair.capture.ui.media.ProjectMediaActivity;
import com.huviair.capture.ui.media.fragments.ExoMediaPlayerFragment;
import com.huviair.capture.ui.interiors.InteriorsActivity;
import com.huviair.capture.ui.snags.snagcreate.CreateSnagFragment;
import com.huviair.capture.ui.snags.snagcreate.CreateSnagsMediaViewerFragment;
import com.huviair.capture.ui.snags.snagcreatedraft.CreateDraftSnagFragment;
import com.huviair.capture.ui.snags.snaglist.SnagDashboardFragment;
import com.huviair.capture.ui.snags.snaglist.SnagFloorPlanFragment;
import com.huviair.capture.ui.snags.snaglist.SnagListNotificationFragment;
import com.huviair.capture.ui.snags.snaglist.SnagListViewFragment;
import com.huviair.capture.ui.snags.snagsmedia.SnagMediaFragment;
import com.huviair.capture.ui.snags.snagsmedia.SnagsMediaViewerFragment;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.viewmodels.SnagViewModel;

public class SnagActivity extends AppCompatActivity {

    public static final String SELECTED_PROJECT = "SELECTED_PROJECT";
    public static final String ACTION_TYPE = "actionType";
    public static final String PROJECT_ID = "projectId";
    public static final String PROJECT_NAME = "projectName";

    private ActivitySnagBinding snagBinding;
    private Project selectedProject;

    // Push notification specific
    private boolean isSnagUpdateNotificationEvent, isSnagCreatedNotificationEvent, isSnagOverDueEvent = false;
    private String notificationFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        snagBinding = ActivitySnagBinding.inflate(getLayoutInflater());
        setContentView(snagBinding.getRoot());

        if (getIntent().getExtras() != null) {
            if (getIntent().hasExtra(ACTION_TYPE) && getIntent().hasExtra(PROJECT_ID)
                    && getIntent().hasExtra(PROJECT_NAME)) {
                String actionType = getIntent().getStringExtra(ACTION_TYPE);

                // Populate respective action types to determine the flow of notifications
                switch (actionType) {
                    case "SnagCreate":
                        isSnagCreatedNotificationEvent = true;
                        break;
                    case "SnagUpdate":
                        isSnagUpdateNotificationEvent = true;
                        notificationFilter = getIntent().getStringExtra("punchId");
                        break;
                    case "SnagOverdue":
                        isSnagOverDueEvent = true;
                    default:
                }

                selectedProject = new Project(getIntent().getStringExtra("projectName"), getIntent().getStringExtra("projectId"));
            } else selectedProject = (Project) getIntent().getSerializableExtra(SELECTED_PROJECT);
        }
        SnagViewModel snagViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(SnagViewModel.class);

        setupBottomNavigationView();

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.snag_list_fragment, SnagDashboardFragment.newInstance(selectedProject.getProjectId()), null)
                    .commit();
        }

        // region push-notification-events
        if (isSnagUpdateNotificationEvent) {
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .addToBackStack(null)
                    .replace(R.id.snag_list_fragment, SnagListNotificationFragment.newInstance(selectedProject.getProjectId(), CommonConstants.SNAG_ALL_ITEMS, notificationFilter), null)
                    .commit();
        }

        if (isSnagCreatedNotificationEvent || isSnagOverDueEvent) {
            String viewType = isSnagCreatedNotificationEvent ? CommonConstants.SNAG_MY_ASSIGNED_ITEMS : CommonConstants.SNAG_OVERDUE_ITEMS;
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .addToBackStack(null)
                    .replace(R.id.snag_list_fragment, SnagListViewFragment.newInstance(selectedProject.getProjectId(), viewType), null)
                    .commit();
        }

        // endregion

        snagViewModel.getSelectedSnagCard().observe(this, selectedSnagCard ->
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .addToBackStack(null)
                        .replace(R.id.snag_list_fragment, SnagListViewFragment.newInstance(selectedProject.getProjectId(), selectedSnagCard), null)
                        .commit());

        snagViewModel.getDisplayFloorPlan().observe(this, snagFloorPlan -> {
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .addToBackStack(null)
                    .add(R.id.snag_floor_plan_fragment, SnagFloorPlanFragment.newInstance(snagFloorPlan.getSelectedSnag(), snagFloorPlan.isCreateSnagFragment()), null)
                    .commit();
        });

        snagViewModel.getOpenMediaFragment().observe(this, openMediaFragment ->
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .addToBackStack(null)
                        .add(R.id.snag_media_fragment, SnagMediaFragment.newInstance(openMediaFragment), null)
                        .commit());

        snagViewModel.isOpenCreateSnagFragment().observe(this, isOpenCreateSnagFragment ->
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .addToBackStack(null)
                        .replace(R.id.snag_list_fragment, CreateSnagFragment.newInstance(selectedProject.getProjectId()), null)
                        .commit());

        snagViewModel.isOpenCreateDraftSnagFragment().observe(this, isOpenCreateDraftSnagFragment ->
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .addToBackStack(null)
                        .replace(R.id.snag_list_fragment, CreateDraftSnagFragment.newInstance(selectedProject.getProjectId()), null)
                        .commit());


        snagViewModel.getSelectedSnagMedia().observe(this, selectedSnagMediaDetails -> {
            if (getLifecycle().getCurrentState() == Lifecycle.State.RESUMED) {
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .addToBackStack(null)
                        .replace(R.id.snag_media_fragment, SnagsMediaViewerFragment.newInstance(selectedSnagMediaDetails), null)
                        .commit();
            }
        });

        snagViewModel.isNewSnagCreated().observe(this, isNewSnagCreated -> {
            getSupportFragmentManager().popBackStack();
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .addToBackStack(null)
                    .replace(R.id.snag_list_fragment, SnagListViewFragment.newInstance(selectedProject.getProjectId(), CommonConstants.SNAG_ALL_ITEMS), null)
                    .commit();
        });

        snagViewModel.isNewOnsiteSnagCreated().observe(this, isNewOnsiteSnagCreated -> {
            getSupportFragmentManager().popBackStack();
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .addToBackStack(null)
                    .replace(R.id.snag_list_fragment, SnagDashboardFragment.newInstance(selectedProject.getProjectId()), null)
                    .commit();
        });

        snagViewModel.getOpenSnagMediaViewerFragment().observe(this, selectedSnagMediaDetails ->
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .addToBackStack(null)
                        .replace(R.id.snag_list_fragment, CreateSnagsMediaViewerFragment.newInstance(selectedSnagMediaDetails), null)
                        .commit());


        snagViewModel.playVideo.observe(this, mediaDetails -> getSupportFragmentManager().beginTransaction()
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .replace(R.id.snag_media_fragment, ExoMediaPlayerFragment.newInstance(mediaDetails.getBlobContentId(), mediaDetails.getBlobDescription(), false), null)
                .commit());

    }


    private void setupBottomNavigationView() {

        snagBinding.bottomNavigationSnag.getRoot().setVisibility(View.VISIBLE);
        snagBinding.bottomNavigationSnag.getRoot().setSelectedItemId(R.id.snag);

        snagBinding.bottomNavigationSnag.getRoot().setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.interiors) {
                Intent interiorIntent = new Intent(this, InteriorsActivity.class);
                interiorIntent.putExtra(InteriorsActivity.PROJECT, selectedProject);
                startActivity(interiorIntent);
                overridePendingTransition(0, 0);
                finish();

            // } else if (itemId == R.id.media) {
            //     Intent projectMediaIntent = new Intent(this, ProjectMediaActivity.class);
            //     projectMediaIntent.putExtra(ProjectMediaActivity.SELECTED_PROJECT, selectedProject);
            //     startActivity(projectMediaIntent);
            //     overridePendingTransition(0, 0);
            //     finish();
            } else if (itemId == R.id.aerial) {
                Intent interiorIntent = new Intent(this, AerialActivity.class);
                interiorIntent.putExtra(SnagActivity.SELECTED_PROJECT, selectedProject);
                startActivity(interiorIntent);
                overridePendingTransition(0, 0);
                finish();
            }
            return true;
        });
    }


}