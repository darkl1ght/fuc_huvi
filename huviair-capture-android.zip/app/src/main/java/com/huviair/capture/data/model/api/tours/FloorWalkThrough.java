package com.huviair.capture.data.model.api.tours;

import java.io.Serializable;
import java.util.List;

public class FloorWalkThrough implements Serializable {
    private String towerId;
    private String towerName;
    private String interiorId;
    private List<String> tours;

    public String getInteriorId() {
        return interiorId;
    }

    public String getTowerId() {
        return towerId;
    }

    public void setTowerId(String towerId) {
        this.towerId = towerId;
    }

    public String getTowerName() {
        return towerName;
    }

    public void setTowerName(String towerName) {
        this.towerName = towerName;
    }

    public List<String> getTours() {
        return tours;
    }

    public void setTours(List<String> tours) {
        this.tours = tours;
    }

    @Override
    public String toString() {
        return "FloorWalkThroughCacheData{" +
                "towerId='" + towerId + '\'' +
                ", towerName='" + towerName + '\'' +
                ", tours=" + tours +
                '}';
    }
}
