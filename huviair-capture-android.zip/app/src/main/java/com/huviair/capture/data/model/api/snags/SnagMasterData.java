package com.huviair.capture.data.model.api.snags;

import java.io.Serializable;
import java.util.List;

public class SnagMasterData implements Serializable {
    private List<WorkPackage> workPackage;
    private List<WorkLocation> workLocation;
    private String[] level1;
    private String[] level2;
    private String projectId;

    public String[] getLevel2() {
        return level2;
    }

    public String[] getLevel1() {
        return level1;
    }

    public List<WorkLocation> getWorkLocations() {
        return workLocation;
    }

    public List<WorkPackage> getWorkPackage() {
        return workPackage;
    }

    public String getProjectId() {
        return projectId;
    }
}
