package com.huviair.capture.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;
import androidx.work.Data;
import androidx.work.WorkInfo;

import com.huviair.capture.R;
import com.huviair.capture.databinding.AerialUploadProgressViewBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class AerialJobStatusAdapter extends RecyclerView.Adapter<AerialJobStatusAdapter.ViewHolder> {

    private final List<WorkInfo> workInfoList;

    private final OnRetryClickListener onRetryClickListener;


    public interface OnRetryClickListener {
        void onRetryClick(Data workId);
    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        public AerialUploadProgressViewBinding aerialUploadProgressViewBinding;

        public ViewHolder(AerialUploadProgressViewBinding aerialUploadProgressViewBinding) {
            super(aerialUploadProgressViewBinding.getRoot());
            this.aerialUploadProgressViewBinding = aerialUploadProgressViewBinding;
        }

    }


    public AerialJobStatusAdapter(List<WorkInfo> workInfoList, OnRetryClickListener listener) {
        this.workInfoList = workInfoList;
        this.onRetryClickListener = listener;
    }

    // Create new views (invoked by the layout manager)
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NotNull ViewGroup viewGroup, int viewType) {
        ViewHolder viewHolder = new AerialJobStatusAdapter.ViewHolder(AerialUploadProgressViewBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
        viewHolder.aerialUploadProgressViewBinding.retryJob.setOnClickListener(v -> onRetryClickListener.onRetryClick(workInfoList.get(viewHolder.getAbsoluteAdapterPosition()).getOutputData()));
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NotNull ViewHolder viewHolder, final int position) {
        WorkInfo workInfo = workInfoList.get(position);
        if (workInfo != null) {
            viewHolder.aerialUploadProgressViewBinding.jobName.setText(workInfo.getOutputData().getString(CommonConstants.TOUR_NAME));
            viewHolder.aerialUploadProgressViewBinding.jobStatus.setText(workInfo.getState().toString());

            switch (workInfo.getState()) {
                case SUCCEEDED:
                    viewHolder.aerialUploadProgressViewBinding.statusIcon.setImageResource(R.drawable.check_circle_icon);
                    viewHolder.aerialUploadProgressViewBinding.jobCompletedOn.setText(DateFormatUtils.convertDate(workInfo.getOutputData().getLong(CommonConstants.WORK_COMPLETED_ON, 0), "MMM d, yyyy HH:mm"));
                    break;
                case FAILED:
                    viewHolder.aerialUploadProgressViewBinding.statusIcon.setImageResource(R.drawable.cancel_round_icon);
                    viewHolder.aerialUploadProgressViewBinding.jobCompletedOn.setText(DateFormatUtils.convertDate(workInfo.getOutputData().getLong(CommonConstants.WORK_COMPLETED_ON, 0), "MMM d, yyyy HH:mm"));
                    viewHolder.aerialUploadProgressViewBinding.retryJob.setVisibility(View.VISIBLE);
                    break;
                default:
                    viewHolder.aerialUploadProgressViewBinding.statusIcon.setImageResource(R.drawable.pending_icon);


            }
        }

    }


    @Override
    public int getItemCount() {
        return workInfoList.size();
    }
}

