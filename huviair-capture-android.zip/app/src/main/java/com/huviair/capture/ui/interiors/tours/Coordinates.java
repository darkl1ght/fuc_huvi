package com.huviair.capture.ui.interiors.tours;

import androidx.annotation.Keep;

import java.io.Serializable;

@Keep
public class Coordinates implements Serializable {

    private double x;
    private double y;

    public Coordinates(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public boolean comparePoints(Coordinates other) {
        double xCoordinatePositive = this.x + 30;
        double xCoordinateNegative = this.x - 30;
        double yCoordinatePositive = this.y + 30;
        double yCoordinateNegative = this.y - 30;
        if ((other.getX() < xCoordinatePositive) && (other.getX() > xCoordinateNegative)) {
            return (other.getY() < yCoordinatePositive) && (other.getY() > yCoordinateNegative);
        }
        return false;
    }

    public double getY() {
        return y;
    }

}
