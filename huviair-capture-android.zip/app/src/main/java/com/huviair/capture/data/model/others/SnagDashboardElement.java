package com.huviair.capture.data.model.others;

public class SnagDashboardElement {

    private final String title;
    private final String count;
    private final int drawableResId;

    public SnagDashboardElement(String title, String count, int drawableResId) {
        this.title = title;
        this.count = count;
        this.drawableResId = drawableResId;
    }

    public String getTitle() {
        return title;
    }


    public String getCount() {
        return count;
    }

    public int getDrawableResId() {
        return drawableResId;
    }


}
