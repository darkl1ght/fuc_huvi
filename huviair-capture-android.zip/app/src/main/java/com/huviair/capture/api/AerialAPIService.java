package com.huviair.capture.api;

import com.huviair.capture.data.model.api.aerial.AerialImageRequest;
import com.huviair.capture.data.model.api.aerial.AerialImageResponse;
import com.huviair.capture.data.model.api.aerial.AerialResponse;
import com.huviair.capture.data.model.api.aerial.TourStatus;

import java.util.Map;

import io.reactivex.Completable;
import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/**
 * Interface provides different API functionality for interacting with the Node.js backend
 */
public interface AerialAPIService {

    @GET("api/aerialtour/{project_id}/tour")
    Single<AerialResponse> getAerialTours(@Path("project_id") String projectId);

    @POST("api/aerialtour/{project_id}/aerialtour/{tour_id}/image")
    Single<AerialImageResponse> updateImageDetailsToBackEnd(@Path("project_id") String projectId, @Path("tour_id") String tourId, @Body AerialImageRequest image);

    @PUT("api/aerialtour/{project_id}/aerialtour/status/{tour_id}")
    Single<TourStatus> getAerialTourStatus(@Path("project_id") String projectId, @Path("tour_id") String tourId);

    @POST("api/aerialtour/{project_id}/aerialtour/{tour_id}/center")
    Completable saveTourCenter(@Path("project_id") String projectId, @Path("tour_id") String tourId, @Body Map<String, Double> request);

}
