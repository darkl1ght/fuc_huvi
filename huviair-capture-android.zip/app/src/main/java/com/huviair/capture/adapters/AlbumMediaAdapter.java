package com.huviair.capture.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.huviair.capture.R;
import com.huviair.capture.adapters.diffUtil.ProjectMediaListDiffUtil;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.MediaAPIService;
import com.huviair.capture.data.model.api.media.Media;
import com.huviair.capture.databinding.MediaAlbumDetailsBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.utils.GlideApp;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.viewmodels.AlbumsListViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.CompletableObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class AlbumMediaAdapter extends RecyclerView.Adapter<AlbumMediaAdapter.MediaViewHolder> implements ActionMode.Callback {

    private final List<Media> mediaDetails;
    private AlbumsListViewModel model;

    private final List<Media> selectedMediaForDelete = new ArrayList<>();
    private boolean multiSelectMode = false;
    private ActionMode deleteActionBar;

    private final Activity activity;


    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class MediaViewHolder extends RecyclerView.ViewHolder {
        public MediaAlbumDetailsBinding mediaAlbumDetailsBinding;

        public MediaViewHolder(@androidx.annotation.NonNull MediaAlbumDetailsBinding view) {
            super(view.getRoot());
            this.mediaAlbumDetailsBinding = view;
        }

    }

    public AlbumMediaAdapter(List<Media> media, Activity activity) {
        this.mediaDetails = media;
        this.activity = activity;
    }

    public void updateAdapterData(List<Media> updatedMedia) {
        ProjectMediaListDiffUtil mediaListDiffUtil = new ProjectMediaListDiffUtil(this.mediaDetails, updatedMedia);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(mediaListDiffUtil);
        this.mediaDetails.clear();
        this.mediaDetails.addAll(updatedMedia);

        diffResult.dispatchUpdatesTo(this);

    }

    @Override
    public void onAttachedToRecyclerView(@androidx.annotation.NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        if (model == null) {
            model = new ViewModelProvider((ViewModelStoreOwner) recyclerView.getContext()).get(AlbumsListViewModel.class);
        }
    }


    // Create new views (invoked by the layout manager)
    @NotNull
    @Override
    public MediaViewHolder onCreateViewHolder(@NotNull ViewGroup viewGroup, int viewType) {

        MediaAlbumDetailsBinding viewBinding;
        if (Media.VIDEO_TYPE == viewType) {
            viewBinding = MediaAlbumDetailsBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
            viewBinding.imageViewMedia.setAlpha(0.2f);
            viewBinding.videoPlayButton.setVisibility(View.VISIBLE);
        } else if (Media.VIDEO_TYPE_360 == viewType) {
            viewBinding = MediaAlbumDetailsBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
            viewBinding.imageViewMedia.setAlpha(0.2f);
            viewBinding.v360PlayButton.setVisibility(View.VISIBLE);
        } else {
            viewBinding = MediaAlbumDetailsBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
        }

        MediaViewHolder mediaViewHolder = new MediaViewHolder(viewBinding);


        // On single click
        mediaViewHolder.mediaAlbumDetailsBinding.itemCardAlbum.setOnClickListener(v -> {
            int absoluteAdapterPosition = mediaViewHolder.getAbsoluteAdapterPosition();

            if (!multiSelectMode && isOfVideoType(mediaDetails.get(absoluteAdapterPosition))) {
                model.setPlayVideo(mediaDetails.get(absoluteAdapterPosition), false);
            } else if (!multiSelectMode && isOf360VideoType(mediaDetails.get(absoluteAdapterPosition))) {
                model.setPlayVideo(mediaDetails.get(absoluteAdapterPosition), true);
            } else if (!multiSelectMode) {
                model.setMediaSelected(absoluteAdapterPosition, mediaDetails);
            } else {
                selectItem(mediaViewHolder.mediaAlbumDetailsBinding.itemCardAlbum, mediaDetails.get(absoluteAdapterPosition));
            }
        });

        mediaViewHolder.mediaAlbumDetailsBinding.itemCardAlbum.setOnLongClickListener(v -> {
            if (!multiSelectMode) {
                multiSelectMode = true;
                // Add it to the list containing all the selected images
                selectItem(mediaViewHolder.mediaAlbumDetailsBinding.itemCardAlbum, mediaDetails.get(mediaViewHolder.getAbsoluteAdapterPosition()));
                deleteActionBar = ((AppCompatActivity) activity).startSupportActionMode(AlbumMediaAdapter.this);
                return true;
            }
            return false;

        });

        return mediaViewHolder;
    }


    @Override
    public void onBindViewHolder(MediaViewHolder viewHolder, final int position) {

        MaterialCardView cardView = viewHolder.mediaAlbumDetailsBinding.itemCardAlbum;

        Media currentMedia = mediaDetails.get(viewHolder.getAbsoluteAdapterPosition());

        // Populate Image view from web
        populateMediaThumbnail(currentMedia, viewHolder);

        // logic for basically handling data change
        if (selectedMediaForDelete.contains(currentMedia)) {
            cardView.setAlpha(0.5f);
        } else {
            if (cardView.isChecked()) {
                cardView.setChecked(false);
            }
            cardView.setAlpha(1.0f);
        }

        //Format date
        String albumCreateDate = DateFormatUtils.parseDate(currentMedia.getFileDate());
        viewHolder.mediaAlbumDetailsBinding.imageCreateDate.setText(albumCreateDate);


        if (currentMedia.getTags() != null && currentMedia.getTags().length > 0) {
            viewHolder.mediaAlbumDetailsBinding.imageTag.setText("#".concat(currentMedia.getTags()[0]));
            viewHolder.mediaAlbumDetailsBinding.imageTag.setVisibility(View.VISIBLE);

        }

    }

    private boolean isOfVideoType(Media media) {
        return CommonConstants.TYPE_VIDEO_CODE.equals(media.getMediaType().getCode());
    }

    private boolean isOf360VideoType(Media media) {
        return CommonConstants.TYPE_360_VIDEO_CODE.equals(media.getMediaType().getCode());
    }

    private void populateMediaThumbnail(Media albumMedia, MediaViewHolder viewHolder) {
        String mediaType = albumMedia.getMediaType().getCode();

        // Thumbnail for images and video
        switch (mediaType) {
            case CommonConstants.TYPE_IMAGE_CODE:
                loadImage(albumMedia.getBlobContentId(), viewHolder.mediaAlbumDetailsBinding.imageViewMedia);
                break;
            case CommonConstants.TYPE_VIDEO_CODE:
                String thumbnailName = albumMedia.getMediaId().concat(".png");
                loadImage(thumbnailName, viewHolder.mediaAlbumDetailsBinding.imageViewMedia);
                break;
            default:
                loadPlaceholderImage(viewHolder.mediaAlbumDetailsBinding.imageViewMedia);
        }


    }

    private void loadImage(String thumbnailName, ImageView imageView) {
        GlideApp.with(imageView.getContext())
                .load(APIClient.getAzureBlobThumbnailContainer().concat(thumbnailName))
                .placeholder(R.drawable.ic_baseline_cloud_download_24)
                .error(R.drawable.image_preview_brand_color)
                .into(imageView);
    }


    @Override
    public int getItemCount() {
        return mediaDetails.size();
    }

    private void loadPlaceholderImage(ImageView imageView) {
        GlideApp.with(imageView.getContext())
                .load(R.drawable.image_preview_brand_color)
                .error(R.drawable.image_preview_brand_color)
                .into(imageView);

    }

    private void selectItem(MaterialCardView cardView, Media selectedMedia) {
        cardView.setChecked(!cardView.isChecked());
        if (selectedMediaForDelete.contains(selectedMedia)) {
            selectedMediaForDelete.remove(selectedMedia);
            cardView.setAlpha(1.0f);

            //Hide delete bar
            if (selectedMediaForDelete.isEmpty() && deleteActionBar != null) {
                deleteActionBar.finish();
            }
        } else {
            selectedMediaForDelete.add(selectedMedia);
            cardView.setAlpha(0.5f);
        }
    }

    // Custom menu for implementing delete feature
    @Override
    public boolean onCreateActionMode(ActionMode mode, Menu menu) {
        mode.setTitle("Delete Selected Media");
        mode.getMenuInflater().inflate(R.menu.album_delete_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
        return false;
    }

    @Override
    public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
        if (R.id.delete_album == item.getItemId() && !selectedMediaForDelete.isEmpty()) {
            deleteSelectedAlbums();
        }
        return false;
    }

    private void deleteSelectedAlbums() {
        MediaAPIService mediaAPIService = APIClient.createService(MediaAPIService.class, activity,
                APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(activity).getJwtToken());

        List<String> mediaIdsToDelete = new ArrayList<>();
        for (Media selectedMedia : selectedMediaForDelete) {
            mediaIdsToDelete.add(selectedMedia.getMediaId());
        }

        // Populate map
        Map<String, List<String>> mediaToDelete = new HashMap<>();
        mediaToDelete.put("mediaIds", mediaIdsToDelete);

        model.isDeletingMedia.setValue(true);

        mediaAPIService.deleteMedia(mediaDetails.get(0).getProjectId(), mediaDetails.get(0).getAlbumId(), mediaToDelete)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new CompletableObserver() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onComplete() {
                        mediaDetails.removeAll(selectedMediaForDelete);
                        //state indicators
                        model.isDeletingMedia.setValue(false);
                        model.isMediaDeleted.setValue(true);

                        notifyDataSetChanged();
                        deleteActionBar.finish();
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        model.isDeletingMedia.setValue(false);
                        Toast.makeText(activity, "Error in deleting Albums", Toast.LENGTH_LONG).show();
                    }
                });

    }

    @Override
    public void onDestroyActionMode(ActionMode mode) {
        selectedMediaForDelete.clear();
        multiSelectMode = false;
        notifyDataSetChanged();

    }


    @Override
    public int getItemViewType(int position) {

        switch (mediaDetails.get(position).getMediaType().getCode()) {
            case CommonConstants.TYPE_IMAGE_CODE:
                return Media.IMAGE_TYPE;
            case CommonConstants.TYPE_VIDEO_CODE:
                return Media.VIDEO_TYPE;
            case CommonConstants.TYPE_360_VIDEO_CODE:
                return Media.VIDEO_TYPE_360;
            default:
                return -1;
        }
    }


}

