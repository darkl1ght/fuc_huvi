package com.huviair.capture.data.model.api.media;

import java.io.Serializable;

public class MediaMetaData implements Serializable {

    private String dateTaken;
    private String fileName;
    private long fileSize;
    private String lat;
    private String lng;

    public MediaMetaData() {

    }

    public MediaMetaData(String dateTaken, String fileName, long fileSize, String lat, String lng) {
        this.dateTaken = dateTaken;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.lat = lat;
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getDateTaken() {
        return dateTaken;
    }

    public void setDateTaken(String dateTaken) {
        this.dateTaken = dateTaken;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }
}
