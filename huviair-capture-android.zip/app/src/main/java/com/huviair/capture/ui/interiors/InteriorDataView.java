package com.huviair.capture.ui.interiors;

import com.huviair.capture.data.model.api.tours.Interior;
import com.huviair.capture.data.model.api.tours.interiorsResponse.FloorWalkThrough;

import java.util.List;

public class InteriorDataView {

    private List<Interior> interiors;
    private List<FloorWalkThrough> tours;

    public InteriorDataView(List<Interior> interiors, List<FloorWalkThrough> tours) {
        this.interiors = interiors;
        this.tours = tours;
    }

    public List<Interior> getInteriors() {
        return interiors;
    }

    public void setInteriors(List<Interior> interiors) {
        this.interiors = interiors;
    }

    public List<FloorWalkThrough> getTours() {
        return tours;
    }

    public void setTours(List<FloorWalkThrough> tours) {
        this.tours = tours;
    }
}
