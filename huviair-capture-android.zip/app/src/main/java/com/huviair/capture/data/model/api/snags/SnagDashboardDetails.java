package com.huviair.capture.data.model.api.snags;

public class SnagDashboardDetails {
    private SnagStatistics snagStatistics;

    public SnagStatistics getSnagStatistics() {
        return snagStatistics;
    }

    public void setSnagStatistics(SnagStatistics snagStatistics) {
        this.snagStatistics = snagStatistics;
    }
}
