package com.huviair.capture.data.model.api.tours.interiorsResponse;

import java.util.List;

public class WalkThroughResponse {

    private List<FloorWalkThrough> tours;

    public List<FloorWalkThrough> getTours() {
        return tours;
    }
}
