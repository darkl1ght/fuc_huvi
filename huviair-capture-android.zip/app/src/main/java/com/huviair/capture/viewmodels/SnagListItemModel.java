package com.huviair.capture.viewmodels;

import android.app.Application;
import android.graphics.Bitmap;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.lookups.LookupsResponse;
import com.huviair.capture.data.model.api.snags.ApproverDetails;
import com.huviair.capture.data.model.api.snags.Config;
import com.huviair.capture.data.model.api.snags.PunchListIdResponse;
import com.huviair.capture.data.model.api.snags.SavedSnagResponse;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagMasterDataResponse;
import com.huviair.capture.data.repositories.LookupsRepository;
import com.huviair.capture.data.repositories.ProjectsRepository;
import com.huviair.capture.data.repositories.SnagsRepository;
import com.huviair.capture.ui.snags.LookUpsResult;
import com.huviair.capture.ui.snags.LookupDataView;
import com.huviair.capture.ui.snags.snagcreate.SnagResult;
import com.huviair.capture.ui.snags.snaglist.SnagDataView;
import com.huviair.capture.ui.snags.snagsmedia.SnagMediaDataView;
import com.huviair.capture.ui.snags.snaglist.SnagMediaResult;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SingleLiveEvent;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.util.UUID;

import io.reactivex.CompletableObserver;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableCompletableObserver;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class SnagListItemModel extends AndroidViewModel {

    //repos used
    private final SnagsRepository snagsRepository;
    private final LookupsRepository lookupsRepository;
    private final ProjectsRepository projectsRepository;

    //Save media and other helpers
    private final SingleLiveEvent<LookUpsResult> lookups = new SingleLiveEvent<>();

    private final MutableLiveData<SavedSnagResponse> savedSnagResponseMutableLiveData = new MutableLiveData<>();
    private final SingleLiveEvent<SnagMediaResult> snagMediaResultMutableLiveData = new SingleLiveEvent<>();
    private final SingleLiveEvent<SnagMediaResult> snagFloorPlanSaveLiveData = new SingleLiveEvent<>();

    //Snag delete
    private final SingleLiveEvent<Boolean> isSnagDeleted = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isErrorInDeletingSnag = new SingleLiveEvent<>();

    //Snag update
    private final SingleLiveEvent<Boolean> isSnagDataUpdated = new SingleLiveEvent<>();

    private final SingleLiveEvent<Boolean> isErrorInSavingApproverDetails = new SingleLiveEvent<>();

    // Snag master data
    private final SingleLiveEvent<SnagResult> snagMasterDataEvent = new SingleLiveEvent<>();

    //Items used in maintaining filter state
    private final SingleLiveEvent<Config> snagFilters = new SingleLiveEvent<>();
    private boolean[] selectedTradeItems;

    private final SingleLiveEvent<String[]> punchlistIds = new SingleLiveEvent<>();


    public SnagListItemModel(Application application) {
        super(application);
        snagsRepository = new SnagsRepository(application);
        lookupsRepository = new LookupsRepository(application);
        projectsRepository = new ProjectsRepository(application);
    }


    public SingleLiveEvent<LookUpsResult> getLookups() {
        return lookups;
    }

    public void fetchLookUps(String type) {
        lookupsRepository.getLookupsByType(type)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<LookupsResponse>() {
                    @Override
                    public void onSuccess(@NonNull LookupsResponse lookupsResponse) {
                        lookups.setValue(new LookUpsResult(new LookupDataView(lookupsResponse.getLookups())));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        lookups.setValue(new LookUpsResult(R.id.technical_error));
                    }
                });
    }

    public void fetchPunchListIds(String projectId) {
        snagsRepository.getPunchListIdsForProject(projectId).observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<PunchListIdResponse>() {
                    @Override
                    public void onSuccess(@NonNull PunchListIdResponse punchListIdResponse) {
                        punchlistIds.setValue(punchListIdResponse.getPunchListId());
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {

                    }
                });
    }

    public void getSnagsMasterData(String projectId) {
        snagsRepository.getSnagsMasterData(projectId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<SnagMasterDataResponse>() {
                    @Override
                    public void onSuccess(@NonNull SnagMasterDataResponse snagMasterDataResponse) {
                        snagMasterDataEvent.setValue(new SnagResult(new SnagDataView(null, null, snagMasterDataResponse.getMaster())));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        snagMasterDataEvent.setValue(new SnagResult(R.string.technical_error));
                    }
                });
    }

    public LiveData<SavedSnagResponse> getSavedSnagResponseMutableLiveData() {
        return savedSnagResponseMutableLiveData;
    }

    public void saveSnagLevelStatus(Integer updatedPosition, String projectId, String levelType, String taskId, ApproverDetails approverDetails) {
        snagsRepository.saveSnagApproverDetails(projectId, levelType, taskId, approverDetails)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<SavedSnagResponse>() {
                    @Override
                    public void onSuccess(@NonNull SavedSnagResponse savedSnagResponse) {
                        savedSnagResponse.setPosition(updatedPosition);
                        savedSnagResponseMutableLiveData.setValue(savedSnagResponse);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        isErrorInSavingApproverDetails.setValue(true);
                    }
                });
    }

    public SingleLiveEvent<SnagMediaResult> getSnagMediaResultMutableLiveData() {
        return snagMediaResultMutableLiveData;
    }

    public void fetchSnagMediaFloorPlanUrl() {
        projectsRepository.fetchAzureToken(CommonConstants.FLOOR_PLAN)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<AzureTokenResponse>() {
                    @Override
                    public void onSuccess(@NonNull AzureTokenResponse azureTokenResponse) {
                        snagMediaResultMutableLiveData.setValue(new SnagMediaResult(new SnagMediaDataView(azureTokenResponse.getSasToken())));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        snagMediaResultMutableLiveData.setValue(new SnagMediaResult(R.string.technical_error));
                    }
                });

    }

    public SingleLiveEvent<SnagMediaResult> getSnagFloorPlanSaveLiveData() {
        return snagFloorPlanSaveLiveData;
    }

    public void saveSnagFloorPlanFeatures(Snag snag) {
        // Save the latest screenshot of the floor plan
        snagsRepository.getAzureWritePermissionToken()
                .flatMap(azureTokenResponse -> {
                    String containerURI = azureTokenResponse.getSasToken() != null ? azureTokenResponse.getSasToken().getUri() : null;
                    CloudBlobContainer cloudBlobContainer = new CloudBlobContainer(URI.create(containerURI));
                    return uploadFloorPlanScreenshot(snag, cloudBlobContainer).subscribeOn(Schedulers.newThread());
                })
                .flatMapCompletable(container ->  snagsRepository.saveSnagFloorPlanFeatures(snag.getProjectId(), snag.getTaskId(), snag.getFloorPlan()))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new CompletableObserver() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) { }

                    @Override
                    public void onComplete() {
                        snagFloorPlanSaveLiveData.setValue(new SnagMediaResult(new SnagMediaDataView(snag.getFloorPlan().getFeature())));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        snagFloorPlanSaveLiveData.setValue(new SnagMediaResult(R.string.technical_error));
                    }
                });
    }

    public SingleLiveEvent<Boolean> getIsSnagDeleted() {
        return isSnagDeleted;
    }

    public SingleLiveEvent<Boolean> getIsErrorInDeletingSnag() {
        return isErrorInDeletingSnag;
    }

    public void deleteSnag(String projectId, String taskId) {
        snagsRepository.deleteSnag(projectId, taskId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableCompletableObserver() {
                    @Override
                    public void onComplete() {
                        isSnagDeleted.setValue(true);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        isErrorInDeletingSnag.setValue(true);
                    }
                });
    }

    private Single<CloudBlobContainer> uploadFloorPlanScreenshot(Snag snag, CloudBlobContainer azureBlobContainer) {
        return Single.fromCallable(() -> {
            Bitmap latestSnapshotBitMap = snag.getFloorPlan().getLatestSnapshotBitMap();
            ByteArrayOutputStream outputStreamByteArray = new ByteArrayOutputStream();
            latestSnapshotBitMap.compress(Bitmap.CompressFormat.JPEG, CommonConstants.IMAGE_COMPRESSION_PERCENTAGE, outputStreamByteArray);

            String latestSnapshotBlobId = UUID.randomUUID().toString().concat(".png");
            CloudBlockBlob blob = azureBlobContainer.getBlockBlobReference(latestSnapshotBlobId);
            blob.uploadFromByteArray(outputStreamByteArray.toByteArray(),0, outputStreamByteArray.size());

            // Append the snapshot blob Id to the request after successful upload to blob
            snag.getFloorPlan().setLatestSnapshotBlobId(latestSnapshotBlobId);
            return azureBlobContainer;
        });

    }


    public SingleLiveEvent<Boolean> getIsSnagDataUpdated() {
        return isSnagDataUpdated;
    }

    public void setSnagDataUpdated(Boolean isUpdated) {
        this.isSnagDataUpdated.setValue(isUpdated);
    }

    public SingleLiveEvent<Boolean> getIsErrorInSavingApproverDetails() {
        return isErrorInSavingApproverDetails;
    }

    public SingleLiveEvent<SnagResult> getSnagMasterData() {
        return snagMasterDataEvent;
    }

    public SingleLiveEvent<Config> getSnagFilters() {
        return snagFilters;
    }

    public void setSnagFilters(Config config) {
        this.snagFilters.setValue(config);
    }

    public void setSelectedTradeItems(boolean[] selectedTradeItems) {
        this.selectedTradeItems = selectedTradeItems;
    }

    public boolean[] getSelectedTradeItems() {
        return selectedTradeItems;
    }

    public SingleLiveEvent<String[]> getPunchlistIds() {
        return punchlistIds;
    }
}