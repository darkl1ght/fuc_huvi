package com.huviair.capture.viewmodels;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.huviair.capture.data.model.api.media.Album;
import com.huviair.capture.data.model.api.media.Media;
import com.huviair.capture.data.model.api.media.ProjectAlbumsRequest;
import com.huviair.capture.data.model.api.media.SelectedMediaDetails;
import com.huviair.capture.data.model.api.media.SingleAlbumResponse;
import com.huviair.capture.data.model.others.MediaDetails;
import com.huviair.capture.data.model.others.SelectedAlbum;
import com.huviair.capture.data.repositories.ProjectMediaRepository;
import com.huviair.capture.utils.NetworkListener;
import com.huviair.capture.utils.SingleLiveEvent;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class AlbumsListViewModel extends AndroidViewModel {

    private final ProjectMediaRepository mediaRepository;
    private final CompositeDisposable disposable = new CompositeDisposable();
    public final SingleLiveEvent<Boolean> isDataConnectionAvailable = new SingleLiveEvent<>();

    public AlbumsListViewModel(@NonNull Application application) {
        super(application);
        mediaRepository = new ProjectMediaRepository(application);
    }

    private final SingleLiveEvent<List<Album>> projectAlbums = new SingleLiveEvent<>();

    // Events used for interaction between fragments
    private final SingleLiveEvent<Boolean> isErrorInRetrieving = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isLoadingData = new SingleLiveEvent<>();

    // Create album error/loading state indicators
    public final SingleLiveEvent<Boolean> isErrorInCreatingAlbum = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isCreatingAlbum = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isAlbumCreatedSuccessfully = new SingleLiveEvent<>();

    // Create album error/loading state indicators
    public final SingleLiveEvent<Boolean> isDeletingMedia = new SingleLiveEvent<>();


    // new album created
    public final SingleLiveEvent<Boolean> isRefreshRequired = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isMediaDeleted = new SingleLiveEvent<>();

    private final SingleLiveEvent<MediaDetails> playVideo = new SingleLiveEvent<>();

    public SingleLiveEvent<MediaDetails> getPlayVideo() {
        return playVideo;
    }

    public void setPlayVideo(Media media, boolean is360Video) {
        this.playVideo.setValue(new MediaDetails(media.getBlobContentId(), media.getMediaDescription(), is360Video));
    }

    private final SingleLiveEvent<SelectedAlbum> selectedAlbumLiveData = new SingleLiveEvent<>();

    public SingleLiveEvent<SelectedAlbum> getSelectedAlbum() {
        return selectedAlbumLiveData;
    }

    public void setSelectedAlbum(SelectedAlbum selectedAlbum) {
        selectedAlbumLiveData.setValue(selectedAlbum);
    }

    private final MutableLiveData<SelectedMediaDetails> mediaLiveDataForViewPager = new MutableLiveData<>();

    public LiveData<SelectedMediaDetails> getMediaLiveDataForViewPager() {
        return mediaLiveDataForViewPager;
    }

    public void setMediaSelected(Integer position, List<Media> selectedMedia) {
        mediaLiveDataForViewPager.setValue(new SelectedMediaDetails(position, selectedMedia));
    }

    public void fetchMediaAlbums(String projectId) {
        isLoadingData.setValue(true);

        disposable.add(
                NetworkListener.hasInternetConnection(getApplication())
                        .subscribe(hasInternetConnection -> {
                            if(hasInternetConnection) {
                                disposable.add(mediaRepository.getProjectMediaDetails(projectId)
                                        .observeOn(AndroidSchedulers.mainThread())
                                        .subscribeOn(Schedulers.io())
                                        .subscribe((projectMediaResponse, throwable) -> {
                                            // Is loading done
                                            isLoadingData.setValue(false);

                                            if (projectMediaResponse != null && projectMediaResponse.getAlbum() != null) {
                                                // Populate albums for further use and adapters for recycler view
                                                projectAlbums.setValue(projectMediaResponse.getAlbum());
                                            }
                                            if (throwable != null) {
                                                Log.d("Error", throwable.getMessage());
                                                isErrorInRetrieving.setValue(true);
                                            }
                                        }));
                            }
                            else{
                                isDataConnectionAvailable.setValue(false);
                            }
                        }));


    }

    // Backend call
    public void createAlbumInBackend(String projectId, ProjectAlbumsRequest albumAddRequest) {
        //Loading indicator
        isCreatingAlbum.setValue(true);

        mediaRepository.createAlbum(projectId, albumAddRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<SingleAlbumResponse>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) {
                    }

                    @Override
                    public void onSuccess(@io.reactivex.annotations.NonNull SingleAlbumResponse albumResponse) {
                        isCreatingAlbum.setValue(false);
                        isAlbumCreatedSuccessfully.setValue(true);
                        isRefreshRequired.setValue(true);
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                        isErrorInCreatingAlbum.setValue(true);
                        isCreatingAlbum.setValue(false);
                    }
                });


    }

    public SingleLiveEvent<List<Album>> getProjectAlbums() {
        return projectAlbums;
    }

    public SingleLiveEvent<Boolean> getIsLoadingData() {
        return isLoadingData;
    }

    public SingleLiveEvent<Boolean> getIsErrorInRetrieving() {
        return isErrorInRetrieving;
    }

    public void setIsLoadingData(boolean loadingData) {
        isLoadingData.setValue(loadingData);
    }


    @Override
    protected void onCleared() {
        super.onCleared();
        if (!disposable.isDisposed()) {
            disposable.dispose();
        }
    }
}