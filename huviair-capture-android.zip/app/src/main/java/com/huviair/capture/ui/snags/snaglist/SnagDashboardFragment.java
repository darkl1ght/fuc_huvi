package com.huviair.capture.ui.snags.snaglist;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;

import com.google.android.material.color.MaterialColors;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.adapters.SnagsDashboardAdapter;
import com.huviair.capture.data.model.api.snags.SnagStatistics;
import com.huviair.capture.data.model.others.SnagDashboardElement;
import com.huviair.capture.databinding.SnagDashboardFragmentBinding;
import com.huviair.capture.ui.snags.snagcreate.SnagResult;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.viewmodels.SnagViewModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SnagDashboardFragment extends Fragment {

    private SnagViewModel snagViewModel;
    private SnagDashboardFragmentBinding snagDashboardFragmentBinding;
    private static final String PROJECT_ID = "PROJECT_ID";
    private String projectId;
    private List<SnagDashboardElement> snagDashboardElements;

    public static SnagDashboardFragment newInstance(String projectId) {
        SnagDashboardFragment fragment = new SnagDashboardFragment();
        Bundle args = new Bundle();
        args.putSerializable(PROJECT_ID, projectId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
        }
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        snagDashboardFragmentBinding = SnagDashboardFragmentBinding.inflate(inflater, container, false);

        if (isNightModeEnabled()) {
            int brandColor = MaterialColors.getColor(requireContext(), R.attr.colorSurface, ContextCompat.getColor(requireContext(), R.color.brand_color));
            snagDashboardFragmentBinding.view.setBackgroundColor(brandColor);
        }

        return snagDashboardFragmentBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        snagViewModel = new ViewModelProvider(requireActivity()).get(SnagViewModel.class);

        // Enable bottom nav
        requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.VISIBLE);

        snagDashboardFragmentBinding.snagToolBar.toolBar.setTitle("Snags");
        snagDashboardFragmentBinding.snagToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        snagDashboardFragmentBinding.snagToolBar.toolBar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        observeForDataLoaders();
        populateDashboardCards();
        observeForCreateSnag();
        observeForChanges();

    }

    private void observeForDataLoaders() {
        snagViewModel.getIsFetchingSnagDashboardStats().observe(getViewLifecycleOwner(), isFetching ->
                snagDashboardFragmentBinding.loadingSnagsDashboardDetails.setVisibility(isFetching ? View.VISIBLE : View.GONE));
    }

    private void observeForCreateSnag() {
        snagDashboardFragmentBinding.fab.setOnClickListener(v -> snagViewModel.openCreateSnagFragment(true));
        snagDashboardFragmentBinding.draft.setOnClickListener(v -> snagViewModel.openCreateDraftSnagFragment(true));
    }

    private void populateDashboardCards() {
        // invoke fetch details
        snagViewModel.fetchSnagDashboardDetails(projectId);

    }


    private void observeForChanges() {

        snagViewModel.getSnagStatisticsMutableLiveData().observe(getViewLifecycleOwner(), snagResult -> {
            if (snagResult.getSuccess() != null) {
                snagDashboardFragmentBinding.fab.show();
                snagDashboardFragmentBinding.draft.show();
                // Validate data
                if (validateDashboardDetails(snagResult))
                    populateDynamicDataOnCards(snagResult.getSuccess().getSnagStatistics());
            }
            if (snagResult.getError() != null) {
                Snackbar.make(snagDashboardFragmentBinding.getRoot(), "No internet connection available", BaseTransientBottomBar.LENGTH_INDEFINITE)
                        .setAction("RETRY", v -> snagViewModel.fetchSnagDashboardDetails(projectId))
                        .setAnchorView(requireActivity().findViewById(R.id.bottom_navigation_snag))
                        .show();
            }
        });
    }

    private boolean validateDashboardDetails(SnagResult snagResult) {
        if (snagResult.getSuccess().getSnagStatistics() != null) {
            if (snagResult.getSuccess().checkIfAllStatsAreZero()) {
                snagDashboardFragmentBinding.noSnagsFoundText.setVisibility(View.VISIBLE);
                snagDashboardFragmentBinding.punchItemImage.setVisibility(View.VISIBLE);
                return false;
            }
            return true;
        }
        return true;
    }

    private void populateDynamicDataOnCards(SnagStatistics snagStatistics) {

        snagDashboardElements = new ArrayList<>();

        SnagDashboardElement myAssignedItems = new SnagDashboardElement(CommonConstants.SNAG_MY_ASSIGNED_ITEMS, String.valueOf(snagStatistics.getMyAssignedCount()),
                R.drawable.my_assigned_icon);
        SnagDashboardElement overDueItems = new SnagDashboardElement(CommonConstants.SNAG_OVERDUE_ITEMS, String.valueOf(snagStatistics.getOverdueCount()),
                R.drawable.overdue_icon);
        SnagDashboardElement openItems = new SnagDashboardElement(CommonConstants.SNAG_OPEN_ITEMS, String.valueOf(snagStatistics.getOpenCount()),
                R.drawable.alert_icon);
        SnagDashboardElement allItems = new SnagDashboardElement(CommonConstants.SNAG_ALL_ITEMS, String.valueOf(snagStatistics.getOverallCount()),
                R.drawable.select_all_icon);
        SnagDashboardElement draftItems = new SnagDashboardElement(CommonConstants.SNAG_DRAFT_ITEMS, String.valueOf(snagStatistics.getOnsiteCount()),
                R.drawable.punch_list_icon);

        Collections.addAll(snagDashboardElements, myAssignedItems, overDueItems, openItems, allItems, draftItems);

        populateRecyclerView();


    }

    private void populateRecyclerView() {

        // set animation for recycler view
        int resId = R.anim.grid_layout_animation_from_bottom;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(requireContext(), resId);
        snagDashboardFragmentBinding.recyclerSnagDashboard.setLayoutAnimation(animation);

        // populate adapter
        SnagsDashboardAdapter snagsDashboardAdapter = new SnagsDashboardAdapter(snagDashboardElements);

        snagDashboardFragmentBinding.recyclerSnagDashboard.setHasFixedSize(true);
        snagDashboardFragmentBinding.recyclerSnagDashboard.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        snagDashboardFragmentBinding.recyclerSnagDashboard.setAdapter(snagsDashboardAdapter);
    }


    private boolean isNightModeEnabled() {
        //Change color only in night mode
        int nightModeFlags = requireContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return nightModeFlags == Configuration.UI_MODE_NIGHT_YES;

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (snagDashboardFragmentBinding != null) {
            snagDashboardFragmentBinding = null;
        }
    }

}