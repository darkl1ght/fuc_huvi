package com.huviair.capture.data.model.api.snags;

import com.huviair.capture.data.model.api.common.PaginationMetaData;

import java.util.List;

public class SnagListResponse {
    private List<Snag> snagsList;
    private PaginationMetaData paginationMetaData;

    public List<Snag> getSnagsList() {
        return snagsList;
    }

    public PaginationMetaData getPaginationMetaData() {
        return paginationMetaData;
    }
}
