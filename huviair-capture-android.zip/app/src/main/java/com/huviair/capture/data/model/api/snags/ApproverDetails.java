package com.huviair.capture.data.model.api.snags;

import java.io.Serializable;
import java.util.Objects;

public class ApproverDetails implements Serializable {
    private TaskStatus status;
    private String comment;
    private String verifiedBy;

    public TaskStatus getStatus() {
        return status;
    }

    public String getComment() {
        return comment;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public ApproverDetails(TaskStatus status, String comment) {
        this.status = status;
        this.comment = comment;
    }

    public void setStatus(TaskStatus status) {
        this.status = status;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    @Override
    public boolean equals(Object o) {
        ApproverDetails that = (ApproverDetails) o;
        return Objects.equals(status, that.status) &&
                Objects.equals(comment, that.comment) &&
                Objects.equals(verifiedBy, that.verifiedBy);
    }

    @Override
    public int hashCode() {
        return Objects.hash(status, comment, verifiedBy);
    }
}
