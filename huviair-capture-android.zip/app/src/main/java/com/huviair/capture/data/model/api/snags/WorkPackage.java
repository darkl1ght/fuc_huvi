package com.huviair.capture.data.model.api.snags;

import java.io.Serializable;

public class WorkPackage implements Serializable {
    private String tradeId;
    private String tradeName;
    private String[] level1;
    private String[] level2;

    public String getTradeId() {
        return tradeId;
    }

    public String getTradeName() {
        return tradeName;
    }

    public String[] getLevel1() {
        return level1;
    }

    public String[] getLevel2() {
        return level2;
    }

    @Override
    public String toString() {
        return tradeName;
    }
}
