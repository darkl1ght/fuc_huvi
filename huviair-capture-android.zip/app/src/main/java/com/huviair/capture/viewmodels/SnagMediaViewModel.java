package com.huviair.capture.viewmodels;

import android.app.Application;
import android.graphics.Bitmap;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.snags.SnagMedia;
import com.huviair.capture.data.model.api.snags.SnagsMediaDeleteResponse;
import com.huviair.capture.data.model.api.snags.SnagsMediaResponse;
import com.huviair.capture.data.repositories.SnagsRepository;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.utils.SingleLiveEvent;
import com.huviair.capture.utils.UriUtils;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.yanzhenjie.album.AlbumFile;

import java.net.URI;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class SnagMediaViewModel extends AndroidViewModel {

    public final SingleLiveEvent<Boolean> isDeletingMedia = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isDeleteCompletedSuccessfully = new SingleLiveEvent<>();
    private final SnagsRepository snagsRepository;
    private final SingleLiveEvent<Boolean> isUploading = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isUploadCompletedSuccessfully = new SingleLiveEvent<>();
    private final SingleLiveEvent<List<SnagMedia>> updatedMediaList = new SingleLiveEvent<>();

    private String containerUri;

    private Bitmap imageBitMap;

    public SnagMediaViewModel(@NonNull Application application) {
        super(application);
        snagsRepository = new SnagsRepository(application);
    }

    public SingleLiveEvent<Boolean> getIsUploading() {
        return isUploading;
    }

    public SingleLiveEvent<Boolean> getIsUploadCompletedSuccessfully() {
        return isUploadCompletedSuccessfully;
    }

    public void fetchContainerUri() {
        snagsRepository.getAzureWritePermissionToken()
                .subscribe(new DisposableSingleObserver<AzureTokenResponse>() {
                    @Override
                    public void onSuccess(@io.reactivex.annotations.NonNull AzureTokenResponse azureTokenResponse) {
                        containerUri = azureTokenResponse.getSasToken() != null ? azureTokenResponse.getSasToken().getUri() : null;
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                        containerUri = null;
                    }
                });
    }

    public void uploadSnagMedia(List<AlbumFile> filesToUpload, String projectId, String taskId) {
        // upload progress started
        try {
            isUploading.setValue(true);

            CloudBlobContainer azureBlobContainer = new CloudBlobContainer(URI.create(containerUri));

            Observable.fromIterable(filesToUpload)
                    .flatMap(albumFile -> uploadMediaToAzureBlob(albumFile, azureBlobContainer).
                            subscribeOn(Schedulers.from(Executors.newFixedThreadPool(5))), 3)
                    .flatMap(snagMedia -> uploadMediaDetailsToBackend(snagMedia, projectId, taskId).
                            subscribeOn(Schedulers.from(Executors.newFixedThreadPool(5))), 3).subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new DisposableObserver<SnagsMediaResponse>() {
                        @Override
                        public void onNext(@io.reactivex.annotations.NonNull SnagsMediaResponse snagsMediaResponse) {
                            updatedMediaList.setValue(snagsMediaResponse.getMediaList());
                        }

                        @Override
                        public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                            isUploading.setValue(false);
                        }

                        @Override
                        public void onComplete() {
                            isUploadCompletedSuccessfully.setValue(true);
                            isUploading.setValue(false);
                        }
                    });


        } catch (Exception e) {
            isUploading.setValue(false);
        }

    }

    private Observable<SnagsMediaResponse> uploadMediaDetailsToBackend(SnagMedia media, String projectId, String taskId) {
        return snagsRepository.uploadSnagMedia(projectId, taskId, media).toObservable();
    }

    private Observable<SnagMedia> uploadMediaToAzureBlob(AlbumFile albumFileToUpload, CloudBlobContainer azureBlobContainer) {
        return Observable.fromCallable(() -> {
            SnagMedia snagMedia = new SnagMedia();
            snagMedia.setMediaId(UUID.randomUUID().toString());
            snagMedia.setMediaCreateDate(DateFormatUtils.getCurrentDateInMongoFormat());

            String fileName = albumFileToUpload.getPath().substring(albumFileToUpload.getPath().lastIndexOf("/") + 1);
            String fileExtension = albumFileToUpload.getPath().split("\\.")[1];
            if (Build.VERSION.SDK_INT >= 33) {
                int index = fileName.lastIndexOf('.');
                if (index > 0) {
                    String extension = fileName.substring(index + 1);
                    fileExtension = extension.length() > 0 ? extension : fileExtension;
                }
            }
            snagMedia.setFileName(fileName);
            snagMedia.setBlobReferenceId(AlbumFile.TYPE_VIDEO == albumFileToUpload.getMediaType() ?
                    snagMedia.getMediaId().concat(".").concat(fileExtension) : snagMedia.getMediaId().concat(".jpeg"));
            // Upload
            CloudBlockBlob blob = azureBlobContainer.getBlockBlobReference(snagMedia.getBlobReferenceId());

            if (AlbumFile.TYPE_VIDEO == albumFileToUpload.getMediaType()) {
                blob.uploadFromFile(albumFileToUpload.getPath());
            } else {

                byte[] compressImageToBytes = UriUtils.compressImageToBytes(albumFileToUpload.getPath(),
                        getImageBitMap()!=null? getImageBitMap():null);
                blob.uploadFromByteArray(compressImageToBytes, 0, compressImageToBytes.length);
            }
            return snagMedia;
        });

    }

    public SingleLiveEvent<List<SnagMedia>> getUpdatedMediaList() {
        return updatedMediaList;
    }

    public void deleteMedia(String projectId, String taskId, String mediaId) {
        List<String> mediaIdsToDelete = Collections.singletonList(mediaId);
        Map<String, List<String>> mediaToDelete = new HashMap<>();
        mediaToDelete.put("mediaIds", mediaIdsToDelete);

        isDeletingMedia.setValue(true);
        snagsRepository.deleteSnagMedia(projectId, taskId, mediaToDelete)
                .subscribe(new DisposableSingleObserver<SnagsMediaDeleteResponse>() {
                    @Override
                    public void onSuccess(@NonNull SnagsMediaDeleteResponse snag) {
                        isDeletingMedia.setValue(false);
                        isDeleteCompletedSuccessfully.setValue(true);
                        updatedMediaList.setValue(snag.getTask().getMediaList());
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        isDeletingMedia.setValue(false);
                    }
                });


    }


    public Bitmap getImageBitMap() {
        return imageBitMap;
    }

    public void setImageBitMap(Bitmap imageBitMap) {
        this.imageBitMap = imageBitMap;
    }
}