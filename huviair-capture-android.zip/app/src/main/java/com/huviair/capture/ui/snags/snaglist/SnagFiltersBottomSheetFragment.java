package com.huviair.capture.ui.snags.snaglist;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.lookups.Lookup;
import com.huviair.capture.data.model.api.snags.Config;
import com.huviair.capture.data.model.api.snags.Filters;
import com.huviair.capture.data.model.api.snags.SnagMasterData;
import com.huviair.capture.data.model.api.snags.WorkPackage;
import com.huviair.capture.databinding.FragmentSnagFilterBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.viewmodels.SnagListItemModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SnagFiltersBottomSheetFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SnagFiltersBottomSheetFragment extends BottomSheetDialogFragment {

    private static final String PROJECT_ID = "PROJECT_ID";
    private FragmentSnagFilterBinding snagFilterBinding;
    private SnagListItemModel snagListItemModel;

    private List<Lookup> priorityValues;
    private List<String> selectedWorkTradeValues = new ArrayList<>();
    private String projectId;
    private String filterStartDate, filterEndDate;


    public SnagFiltersBottomSheetFragment() {
        // Required empty public constructor
    }

    public static SnagFiltersBottomSheetFragment newInstance(String projectId) {
        SnagFiltersBottomSheetFragment fragment = new SnagFiltersBottomSheetFragment();
        Bundle args = new Bundle();
        args.putString(PROJECT_ID, projectId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
        }

    }

    @Override
    public void onStart() {
        super.onStart();
        // Resize the fragment on keyboard visibility
        requireDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        snagFilterBinding = FragmentSnagFilterBinding.inflate(inflater, container, false);
        return snagFilterBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        snagListItemModel = new ViewModelProvider(requireParentFragment()).get(SnagListItemModel.class);

        // Fetch lookups
        snagListItemModel.fetchLookUps(CommonConstants.LOOKUP_TYPE_TASK_PRIORITY);

        // Fetch master data for the project
        snagListItemModel.getSnagsMasterData(projectId);

        //Fetch punchlistids
        snagListItemModel.fetchPunchListIds(projectId);

        snagListItemModel.getLookups().observe(getViewLifecycleOwner(), lookUpsResult -> {
            if (lookUpsResult.getSuccess() != null && lookUpsResult.getSuccess().getLookupList() != null) {
                // Map values if success
                this.priorityValues = lookUpsResult.getSuccess().getLookupList();
                snagFilterBinding.snagFilterPriorityDropdown.setAdapter(new ArrayAdapter<>(requireContext(), R.layout.list_item, priorityValues));

                // Prepopulate previously selected values
                prePopulateExistingFilters();
            }
            if (lookUpsResult.getError() != null) {
                Toast.makeText(requireContext(), "Technical Error", Toast.LENGTH_LONG).show();
            }
        });

        snagListItemModel.getSnagMasterData().observe(getViewLifecycleOwner(), snagResult -> {
            if (snagResult.getSuccess() != null && snagResult.getSuccess().getSnagMasterData() != null) {
                // Populate workpackages
                populateWorkPackages(snagResult.getSuccess().getSnagMasterData());
            }
            if (snagResult.getError() != null) {
                Toast.makeText(requireContext(), "Technical Error", Toast.LENGTH_LONG).show();
            }
        });

        snagListItemModel.getPunchlistIds().observe(getViewLifecycleOwner(), ids -> {
            snagFilterBinding.snagFilterPunchlistIdDropdown.setAdapter(new ArrayAdapter<>(requireContext(), R.layout.list_item, ids));
        });

        bindListenersAndSave();
        observeForDatePickerClicks();

    }

    private void observeForDatePickerClicks() {
        snagFilterBinding.snagStartDueDateEditText.setOnClickListener(v -> {
            MaterialDatePicker<Long> startDatePicker = showMaterialDatePicker("Select start date");
            startDatePicker.addOnPositiveButtonClickListener(selection -> {
                filterStartDate = DateFormatUtils.convertDate(selection, CommonConstants.MONGO_DATE_FORMAT);
                snagFilterBinding.snagStartDueDateEditText.setText(DateFormatUtils.convertDate(selection, "dd-MM-yyyy"));
            });
        });

        snagFilterBinding.snagEndDueDateEditText.setOnClickListener(v -> {
            MaterialDatePicker<Long> startDatePicker = showMaterialDatePicker("Select end date");
            startDatePicker.addOnPositiveButtonClickListener(selection -> {
                filterEndDate = DateFormatUtils.convertDate(selection, CommonConstants.MONGO_DATE_FORMAT);
                snagFilterBinding.snagEndDueDateEditText.setText(DateFormatUtils.convertDate(selection, "dd-MM-yyyy"));
            });
        });
    }


    private void populateWorkPackages(SnagMasterData masterData) {
        List<WorkPackage> workPackages = masterData.getWorkPackage();
        if (snagListItemModel.getSelectedTradeItems() == null) {
            snagListItemModel.setSelectedTradeItems(new boolean[workPackages.size()]);
        }
        snagFilterBinding.snagWorkTradeEditText.setOnClickListener(v -> showMultiSelectWorkTradeDialog("Select Work Trade", workPackages));
    }

    private void prePopulateExistingFilters() {
        if (snagListItemModel.getSnagFilters().getValue() != null) {
            Config appliedFilters = snagListItemModel.getSnagFilters().getValue();
            if (appliedFilters != null) {
                // Existing Priority values
                populatePriorityValues(appliedFilters);

                if (appliedFilters.getFilters().getPunchListId() != null &&
                        appliedFilters.getFilters().getPunchListId().length > 0) {
                    snagFilterBinding.snagFilterPunchlistIdDropdown.setText(appliedFilters.getFilters().getPunchListId()[0]);
                }

                // non conformity
                snagFilterBinding.snagFilterNonConformity.setChecked(appliedFilters.getFilters().isNonConformity());

                // Existing work package (trade)
                if (appliedFilters.getFilters().getWorkPackage() != null) {
                    selectedWorkTradeValues = appliedFilters.getFilters().getWorkPackage();
                    populatePlaceHolderForWorkTrade(selectedWorkTradeValues);
                }

                // Existing start and end date values
                populateDateValues(appliedFilters);
            }
        }
    }

    private void populateDateValues(Config appliedFilters) {
        if (appliedFilters.getFilters().getStartDate() != null) {
            filterStartDate = appliedFilters.getFilters().getStartDate();
            snagFilterBinding.snagStartDueDateEditText.setText(DateFormatUtils.parseDateInRequiredFormat(filterStartDate, CommonConstants.DATE_PICKER_FORMAT));
        }

        if (appliedFilters.getFilters().getEndDate() != null) {
            filterEndDate = appliedFilters.getFilters().getEndDate();
            snagFilterBinding.snagEndDueDateEditText.setText(DateFormatUtils.parseDateInRequiredFormat(filterEndDate, CommonConstants.DATE_PICKER_FORMAT));

        }

    }

    private void populatePriorityValues(Config appliedFilters) {
        String priorityLookupCode = "";
        Optional<Lookup> priority = priorityValues.stream().filter(lookup -> lookup.getKey().equals(appliedFilters.getFilters().getPriority())).findFirst();
        if (priority.isPresent()) priorityLookupCode = priority.get().getValue();

        snagFilterBinding.snagFilterPriorityDropdown.setText(priorityLookupCode, false);

    }

    private void bindListenersAndSave() {
        snagFilterBinding.saveSnagDetails.setOnClickListener(v -> submit());
        snagFilterBinding.cancel.setOnClickListener(v -> dismiss());

        // Toggle clear filter button
        if (snagListItemModel.getSnagFilters().getValue() == null || !snagListItemModel.getSnagFilters().getValue().isFiltersApplied()) {
            snagFilterBinding.clearFilters.setVisibility(View.GONE);
        } else {
            snagFilterBinding.clearFilters.setVisibility(View.VISIBLE);
        }

        snagFilterBinding.clearFilters.setOnClickListener(v -> {
            //clear existing edit text values
            snagFilterBinding.snagFilterPriorityDropdown.setText(CommonConstants.EMPTY_STRING);
            snagFilterBinding.snagFilterPunchlistIdDropdown.setText(CommonConstants.EMPTY_STRING);
            snagFilterBinding.snagStartDueDateEditText.setText(CommonConstants.EMPTY_STRING);
            snagFilterBinding.snagEndDueDateEditText.setText(CommonConstants.EMPTY_STRING);
            snagFilterBinding.snagWorkTradeEditText.setText(CommonConstants.EMPTY_STRING);

            // clear worktade details
            selectedWorkTradeValues.clear();
            snagListItemModel.setSelectedTradeItems(new boolean[snagListItemModel.getSelectedTradeItems().length]);

            // Clear date values
            filterStartDate = null;
            filterEndDate = null;

            snagFilterBinding.snagFilterNonConformity.setChecked(false);

            snagFilterBinding.clearFilters.setVisibility(View.GONE);

        });
    }


    private void submit() {
        Config config = new Config();
        List<String> workPackage = selectedWorkTradeValues.size() > 0 ? selectedWorkTradeValues : null;
        String[] selectedPunchListItems = Arrays.stream(snagListItemModel.getPunchlistIds().getValue())
                .filter(s -> s.equals(snagFilterBinding.snagFilterPunchlistIdDropdown.getText().toString()))
                .toArray(String[]::new);

        // Don't send any punchid items if size 0
        selectedPunchListItems = selectedPunchListItems.length != 0 ? selectedPunchListItems : null;

        config.setFilters(new Filters(workPackage, filterStartDate, filterEndDate, getSelectedPriorityId(), selectedPunchListItems, snagFilterBinding.snagFilterNonConformity.isChecked()));
        snagListItemModel.setSnagFilters(config);
        dismiss();
    }

    private String getSelectedPriorityId() {
        String selectedPriority = snagFilterBinding.snagFilterPriorityDropdown.getText().toString();
        String priorityLookupCode = "";
        // Get lookup code
        Optional<Lookup> priority = priorityValues.stream().filter(lookup -> lookup.getValue().equals(selectedPriority)).findFirst();
        if (priority.isPresent()) priorityLookupCode = priority.get().getKey();

        return priorityLookupCode;

    }

    private void showMultiSelectWorkTradeDialog(String title, List<WorkPackage> listToPopulate) {

        boolean[] selectedSnagWorkPackages = snagListItemModel.getSelectedTradeItems();

        new MaterialAlertDialogBuilder(requireContext(), R.style.ThemeOverlay_App_MaterialAlertDialog)
                .setTitle(title)
                .setIcon(R.drawable.edit_icon)
                .setPositiveButton("Save",
                        (DialogInterface dialog, int which) -> {
                            SparseBooleanArray checkedItemPositions = ((AlertDialog) dialog).getListView().getCheckedItemPositions();
                            List<WorkPackage> result = new ArrayList<>();
                            for (int i = 0; i < listToPopulate.size(); i++) {
                                if (checkedItemPositions.get(i)) {
                                    result.add(listToPopulate.get(i));
                                    selectedSnagWorkPackages[i] = true;
                                } else selectedSnagWorkPackages[i] = false;
                            }
                            saveSelectedWorkTradeDetails(result, selectedSnagWorkPackages);
                        })
                .setNegativeButton("Cancel", null)
                .setMultiChoiceItems(listToPopulate.stream().map(WorkPackage::getTradeName).toArray(CharSequence[]::new), selectedSnagWorkPackages, null)
                .show();
    }

    private void saveSelectedWorkTradeDetails(List<WorkPackage> result, boolean[] selectedSnagWorkPackages) {
        populatePlaceHolderForWorkTrade(result);
        selectedWorkTradeValues = result.stream().map(WorkPackage::getTradeId).collect(Collectors.toList());
        snagListItemModel.setSelectedTradeItems(selectedSnagWorkPackages);
    }

    private <T> void populatePlaceHolderForWorkTrade(List<T> result) {
        // Populate placeholder
        if (result.size() > 0)
            snagFilterBinding.snagWorkTradeEditText.setText(getString(R.string.selected_snag_levels, result.size()));
        else snagFilterBinding.snagWorkTradeEditText.setText(null);

    }

    private MaterialDatePicker<Long> showMaterialDatePicker(String title) {
        MaterialDatePicker.Builder<Long> builder = MaterialDatePicker.Builder.datePicker();
        MaterialDatePicker<Long> picker = builder.setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .setTitleText(title)
                .build();
        picker.show(getChildFragmentManager(), "Date picker");
        return picker;
    }

}