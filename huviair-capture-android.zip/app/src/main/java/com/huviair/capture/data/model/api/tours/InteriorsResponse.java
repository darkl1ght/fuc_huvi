package com.huviair.capture.data.model.api.tours;

import java.util.List;

public class InteriorsResponse {
    private List<Interior> interiors;

    public List<Interior> getInteriors() {
        return interiors;
    }

    public void setInteriors(List<Interior> interiors) {
        this.interiors = interiors;
    }
}
