package com.huviair.capture.adapters.diffUtil;

import androidx.recyclerview.widget.DiffUtil;

import com.huviair.capture.data.model.api.media.Album;

import java.util.List;

public class ProjectAlbumsListDiffUtil extends DiffUtil.Callback {
    private final List<Album> previousList;
    private final List<Album> newList;

    public ProjectAlbumsListDiffUtil(List<Album> previousList, List<Album> newList) {
        this.previousList = previousList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return previousList != null ? previousList.size() : 0;
    }

    @Override
    public int getNewListSize() {
        return newList != null ? newList.size() : 0;
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        return newList.get(newItemPosition).getAlbumId().equals(previousList.get(oldItemPosition).getAlbumId());

    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        int result = newList.get(newItemPosition).compareTo(previousList.get(oldItemPosition));
        return result == 0;
    }

}
