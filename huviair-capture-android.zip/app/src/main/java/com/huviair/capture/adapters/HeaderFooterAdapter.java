package com.huviair.capture.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.paging.LoadState;
import androidx.recyclerview.widget.RecyclerView;

import com.huviair.capture.R;
import com.huviair.capture.databinding.ReposLoadStateFooterViewItemBinding;

import org.jetbrains.annotations.NotNull;

public class HeaderFooterAdapter extends androidx.paging.LoadStateAdapter<HeaderFooterAdapter.LoadStateViewHolder> {
    // Define Retry Callback
    private final View.OnClickListener mRetryCallback;

    public HeaderFooterAdapter(View.OnClickListener retryCallback) {
        // Init Retry Callback
        mRetryCallback = retryCallback;
    }

    @NotNull
    @Override
    public LoadStateViewHolder onCreateViewHolder(@NotNull ViewGroup parent,
                                                  @NotNull LoadState loadState) {
        // Return new LoadStateViewHolder object
        return new LoadStateViewHolder(parent, mRetryCallback);
    }

    @Override
    public void onBindViewHolder(@NotNull LoadStateViewHolder holder,
                                 @NotNull LoadState loadState) {
        // Call Bind Method to bind visibility  of views
        holder.bind(loadState);
    }

    public static class LoadStateViewHolder extends RecyclerView.ViewHolder {
        // Define Progress bar
        private final ProgressBar mProgressBar;
        // Define error TextView
        private final TextView mErrorMsg;
        // Define Retry button
        private final Button mRetry;

        LoadStateViewHolder(
                @NonNull ViewGroup parent,
                @NonNull View.OnClickListener retryCallback) {
            super(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.repos_load_state_footer_view_item, parent, false));
            ReposLoadStateFooterViewItemBinding binding = ReposLoadStateFooterViewItemBinding.bind(itemView);
            mProgressBar = binding.loadingSnagItems;
            mErrorMsg = binding.errorMsg;
            mRetry = binding.retryButton;
            mRetry.setOnClickListener(retryCallback);
        }

        public void bind(LoadState loadState) {
            // Check load state
            if (loadState instanceof LoadState.Error) {
                // Set text of Error message
                mErrorMsg.setText("Oops ! something went wrong, Try again !!");
            }
            // set visibility of widgets based on LoadState
            mProgressBar.setVisibility(loadState instanceof LoadState.Loading
                    ? View.VISIBLE : View.GONE);
            mRetry.setVisibility(loadState instanceof LoadState.Error
                    ? View.VISIBLE : View.GONE);
            mErrorMsg.setVisibility(loadState instanceof LoadState.Error
                    ? View.VISIBLE : View.GONE);
        }
    }
}