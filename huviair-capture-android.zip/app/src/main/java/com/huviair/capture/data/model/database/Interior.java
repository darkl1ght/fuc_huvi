package com.huviair.capture.data.model.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "INTERIORS")
public class Interior {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "INTERIOR_ID")
    private String interiorId;
    @ColumnInfo(name = "INTERIOR_NAME")
    private String interiorName;
    @ColumnInfo(name = "PROJECT_ID")
    private String projectId;

    public Interior(int id, String interiorId, String interiorName, String projectId) {
        this.id = id;
        this.interiorId = interiorId;
        this.interiorName = interiorName;
        this.projectId = projectId;
    }

    @Ignore
    public Interior(String interiorId, String interiorName, String projectId) {
        this.interiorId = interiorId;
        this.interiorName = interiorName;
        this.projectId = projectId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public void setInteriorId(String interiorId) {
        this.interiorId = interiorId;
    }

    public String getInteriorName() {
        return interiorName;
    }

    public void setInteriorName(String interiorName) {
        this.interiorName = interiorName;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }


}
