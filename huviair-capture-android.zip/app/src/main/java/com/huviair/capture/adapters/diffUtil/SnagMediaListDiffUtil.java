package com.huviair.capture.adapters.diffUtil;

import androidx.recyclerview.widget.DiffUtil;

import com.huviair.capture.data.model.api.snags.SnagMedia;

import java.util.List;

public class SnagMediaListDiffUtil extends DiffUtil.Callback {
    private final List<SnagMedia> previousList;
    private final List<SnagMedia> newList;

    public SnagMediaListDiffUtil(List<SnagMedia> previousList, List<SnagMedia> newList) {
        this.previousList = previousList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return previousList != null ? previousList.size() : 0;
    }

    @Override
    public int getNewListSize() {
        return newList != null ? newList.size() : 0;
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        return newList.get(newItemPosition).getMediaId().equals(previousList.get(oldItemPosition).getMediaId());

    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        int result = newList.get(newItemPosition).compareTo(previousList.get(oldItemPosition));
        return result == 0;
    }

}
