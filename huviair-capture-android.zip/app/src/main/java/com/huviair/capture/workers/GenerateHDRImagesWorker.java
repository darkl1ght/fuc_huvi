package com.huviair.capture.workers;

import android.app.Notification;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ForegroundInfo;
import androidx.work.RxWorker;
import androidx.work.WorkerParameters;

import com.arashivision.sdkmedia.stitch.StitchUtils;
import com.arashivision.sdkmedia.work.WorkWrapper;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.CommonConstants;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.Completable;
import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class GenerateHDRImagesWorker extends RxWorker {

    private final DataCaptureRoomDatabase database;
    private final AtomicInteger atomicInteger = new AtomicInteger(0);

    private final String IMPORTED_IMAGES_PATH;
    private final String HDR_GENERATED_IMAGES_PATH;
    private List<TourDetails> toursFromDatabase;

    /**
     * @param appContext   The application {@link Context}
     * @param workerParams Parameters to setup the internal state of this worker
     */
    public GenerateHDRImagesWorker(@NonNull Context appContext, @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);

        //Initialize folder paths
        HDR_GENERATED_IMAGES_PATH = appContext.getFilesDir() + "/" + CommonConstants.HDR_STITCHED_IMAGES_FOLDER;
        IMPORTED_IMAGES_PATH = appContext.getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER;

        // Initialize database
        database = DataCaptureRoomDatabase.getDatabase(appContext);
    }

    @NonNull
    @Override
    public Single<Result> createWork() {
        try {
            String interiorWalkthroughId = getInputData().getString(CommonConstants.WALKTHROUGH_ID);
            String walkthroughName = getInputData().getString(CommonConstants.TOUR_NAME);
            String interiorTourId = getInputData().getString(CommonConstants.INTERIOR_TOUR_ID);
            String projectId = getInputData().getString(CommonConstants.PROJECT_ID);
            String towerId = getInputData().getString(CommonConstants.TOWER_ID);


            Data.Builder builder = new Data.Builder()
                    .putString(CommonConstants.INTERIOR_TOUR_ID, interiorTourId)
                    .putString(CommonConstants.TOUR_NAME, walkthroughName)
                    .putString(CommonConstants.WALKTHROUGH_ID, interiorWalkthroughId)
                    .putString(CommonConstants.PROJECT_ID, projectId)
                    .putString(CommonConstants.TOWER_ID, towerId);

            Single<List<TourDetails>> fetchTours = database.tourDetailsDAO().getSavedTourDetails(interiorWalkthroughId);

            setForegroundAsync(createForegroundInfo(true, "Generating HDR Images started for the walk-through ".concat(walkthroughName), interiorWalkthroughId));

            return fetchTours.toObservable().observeOn(AndroidSchedulers.mainThread())
                    .map(this::transformTours)
                    .flatMap(tourDetails -> {
                        this.toursFromDatabase = tourDetails;
                        return Observable.fromIterable(tourDetails).filter(tour -> tour.getImageUrl().split(",").length > 1)
                                .flatMap(tourDetail -> generateHDRImages(tourDetail).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(4))), 2);
                    })
                    .subscribeOn(Schedulers.io())
                    .doOnSubscribe(disposable -> setForegroundAsync(createForegroundInfo(true, "Generating images for the walk-through ".concat(walkthroughName), interiorWalkthroughId)))
                    .doOnNext(aBoolean -> setForegroundAsync(createForegroundInfo(true, String.format(Locale.getDefault(), "Generating HDR images %d of %d for the walk-through ".concat(walkthroughName), atomicInteger.incrementAndGet(), toursFromDatabase.size()), interiorWalkthroughId)))
                    .doOnComplete(() -> setForegroundAsync(createForegroundInfo(false, "Generating HDR Images for ".concat(walkthroughName).concat(" ").concat("completed"), interiorWalkthroughId)))
                    .doOnError(throwable -> setForegroundAsync(createForegroundInfo(false, "Generating HDR images failed", interiorWalkthroughId)))
                    .toList()
                    .map(generateHDRResponse -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.success(builder.build());
                    })
                    .onErrorReturn(throwable -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.failure(builder.build());
                    });
        } catch (Exception e) {
            return Single.just(Result.failure());
        }
    }

    // Modify tour image URL's paths to that of the local storage of the mobile
    private List<TourDetails> transformTours(List<TourDetails> tourDetails) {
        for (TourDetails tour : tourDetails) {
            String[] tourImageUrls = tour.getImageUrl().split(",");
            for (int i = 0; i < tourImageUrls.length; i++) {
                tourImageUrls[i] = tourImageUrls[i].replace(
                        tourImageUrls[i].substring(0, tourImageUrls[i].lastIndexOf("/")), IMPORTED_IMAGES_PATH);
            }
            tour.setImageUrlsSplit(tourImageUrls);
        }
        return tourDetails;
    }


    // Invoke generate HDR images API - Insta 360 library and update details to DB
    private Observable<Boolean> generateHDRImages(TourDetails tourToStitch) {
        return Observable.fromCallable(() -> {
            String generatedImagesPath = HDR_GENERATED_IMAGES_PATH + "/" + UUID.randomUUID() + "_IMAGE_" + tourToStitch.getImageNumber() + ".jpg";

            WorkWrapper workWrapper = new WorkWrapper(tourToStitch.getImageUrlsSplit());

            // generate HDR image if doesn't exist
            if (tourToStitch.getHdrImageFileName() == null || !new File(tourToStitch.getHdrImageFileName()).exists()) {
                if (StitchUtils.generateHDR(workWrapper, generatedImagesPath)) {
                    database.tourDetailsDAO().updateTourDetails(tourToStitch.getTourId(), generatedImagesPath, tourToStitch.getId());
                    return true;
                } else {
                    return false;
                }
            }

            return true;
        });
    }

    @NonNull
    private ForegroundInfo createForegroundInfo(boolean onGoing, @NonNull String message, @NonNull String walkthroughId) {
        Notification foregroundNotification = WorkerUtils.getNotification(onGoing, CommonConstants.INTERIOR_WORK_NOTIFICATION_TITLE, message, walkthroughId, getApplicationContext());
        int notificationId = onGoing ? 1 : 2;
        return new ForegroundInfo(notificationId, foregroundNotification);
    }

    @NonNull
    @Override
    protected Scheduler getBackgroundScheduler() {
        return Schedulers.from(Executors.newFixedThreadPool(10));
    }
}


