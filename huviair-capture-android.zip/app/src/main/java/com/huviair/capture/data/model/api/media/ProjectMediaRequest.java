package com.huviair.capture.data.model.api.media;

public class ProjectMediaRequest {

    private Media media;

    public ProjectMediaRequest(Media media) {
        this.media = media;
    }

    public Media getMedia() {
        return media;
    }

    public void setMedia(Media media) {
        this.media = media;
    }
}
