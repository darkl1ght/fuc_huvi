package com.huviair.capture.ui.interiors.videocapture.landing;

import android.app.Application;
import android.graphics.PointF;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.work.WorkManager;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.arashivision.sdkcamera.camera.callback.ICameraOperateCallback;
import com.github.pwittchen.reactivenetwork.library.rx2.ReactiveNetwork;
import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.InternetObservingSettings;
import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.strategy.SocketInternetObservingStrategy;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.azure.AzureToken;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.tours.Image;
import com.huviair.capture.data.model.api.tours.ImageFeature;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.model.database.InteriorVideoCapture;
import com.huviair.capture.data.model.database.InteriorWalkthrough;
import com.huviair.capture.data.repositories.InteriorsRepository;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.NetworkListener;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.utils.SingleLiveEvent;
import com.huviair.capture.utils.UriUtils;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.HttpException;

public class VideoWalkthroughViewModel extends AndroidViewModel {

    private final WorkManager workManager;
    private final InteriorsRepository interiorsRepository;
    private final APIService apiService;
    private final DataCaptureRoomDatabase database;

    private final CompositeDisposable disposableBag = new CompositeDisposable();
    public SingleLiveEvent<Boolean> is360CameraConnected = new SingleLiveEvent<>();
    public SingleLiveEvent<PointF> captureStartPoint = new SingleLiveEvent<>();
    public SingleLiveEvent<PointF> captureEndPoint = new SingleLiveEvent<>();

    public SingleLiveEvent<Boolean> isCaptureInProgress = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isCaptureComplete = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isPendingPublish = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isWalkthroughUploadedAlready = new SingleLiveEvent<>();

    public SingleLiveEvent<Boolean> isCaptureSavedShowPublish = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isCaptureSaved = new SingleLiveEvent<>();

    public String[] capturedVideoUrls = new String[2];
    public SingleLiveEvent<Boolean> showLoadingState = new SingleLiveEvent<>();

    public SingleLiveEvent<List<ImageFeature>> previousMarkerCoordinates = new SingleLiveEvent<>();
    public SingleLiveEvent<List<ImageFeature>> previousMarkerCoordinatesClone = new SingleLiveEvent<>();

    public SingleLiveEvent<Boolean> isShowingPreviousMarkers = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isErrorInFetchingMarkers = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> noMarkersAvailable = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isAllLoadingComplete = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isFloorPlanDownloaded = new SingleLiveEvent<>();

    public boolean isPreviousMarkerFetched = false;
    private String projectId;
    private Tour selectedWalkThrough;
    public long allowedVideoCaptureTime = 14;

    public VideoWalkthroughViewModel(@NonNull Application application) {
        super(application);
        workManager = WorkManager.getInstance(application);
        interiorsRepository = new InteriorsRepository(application);
        apiService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());
        isShowingPreviousMarkers.setValue(false);
        database = DataCaptureRoomDatabase.getDatabase(application);

    }

    public void fetchAllowedVideoCaptureTime(String projectId) {
        disposableBag.add(
                Single.fromCallable(() -> database.projectCacheDAO().getAllowedVideoCaptureTimeByProjectId(projectId))
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(allowedTime -> {
                            allowedVideoCaptureTime = allowedTime;
                        }, throwable -> {
                            // Handle any errors here, such as setting a default value or logging an error
                            allowedVideoCaptureTime = 14; // Use the default value of 12 minutes
                        })
        );
    }
    public boolean isCaptureComplete() {
        return captureStartPoint.getValue() != null && isCaptureComplete.getValue() != null && isCaptureComplete.getValue()
                && captureEndPoint.getValue() == null;
    }

    public Boolean is360CameraConnected() {
        return is360CameraConnected.getValue() != null && is360CameraConnected.getValue();
    }


    public Tour getSelectedWalkThrough() {
        return selectedWalkThrough;
    }

    public void setSelectedWalkThrough(Tour selectedWalkThrough) {
        this.selectedWalkThrough = selectedWalkThrough;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public void startCameraConnectionInBackground() {

        InternetObservingSettings settings = InternetObservingSettings.builder()
                .host("http://192.168.42.1")
                .strategy(new SocketInternetObservingStrategy())
                .build();

        disposableBag.add(ReactiveNetwork
                .observeInternetConnectivity(settings)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(isConnectedToCameraWifi -> {
                    if (isConnectedToCameraWifi) {
                        InstaCameraManager.getInstance().openCamera(InstaCameraManager.CONNECT_TYPE_WIFI);
                    }
                }));
    }

    public void removeThePreviousCapture() {
        disposableBag.add(database.tourDetailsDAO().deleteVideoCapture(selectedWalkThrough.getTourId())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe());
    }

    public void startTimeLapseVideoCapture() {
        if(InstaCameraManager.CAMERA_MODE_PANORAMA != InstaCameraManager.getInstance().getCurrentCameraMode() ||
        InstaCameraManager.FOCUS_SENSOR_ALL != InstaCameraManager.getInstance().getCurrentFocusSensor()){
            // Timelapse interval of half a second
            InstaCameraManager.getInstance().switchCameraMode(InstaCameraManager.CAMERA_MODE_PANORAMA, InstaCameraManager.FOCUS_SENSOR_ALL, new ICameraOperateCallback() {
                @Override
                public void onSuccessful() {
                    InstaCameraManager.getInstance().setTimeLapseInterval(500);
                    InstaCameraManager.getInstance().startTimeLapse();
                }

                @Override
                public void onFailed() {

                }

                @Override
                public void onCameraConnectError() {

                }
            });

        }
        else {
            InstaCameraManager.getInstance().setTimeLapseInterval(500);
            InstaCameraManager.getInstance().startTimeLapse();
        }

    }

    public void stopTimeLapseVideoCapture() {
        InstaCameraManager.getInstance().stopTimeLapse();
    }

    public void downloadFloorPlan() {
        disposableBag.add(NetworkListener.hasInternetConnection(getApplication())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((isConnected, throwable) -> {
                    if (isConnected) {
                        showLoadingState.setValue(true);
                        disposableBag.add(getFloorPlanObservable().flatMap(azureTokenResponse ->
                                downloadFileToLocalStorage(azureTokenResponse, selectedWalkThrough).subscribeOn(Schedulers.newThread()))
                                .subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(floorPlanDownloaded -> {
                                    if (floorPlanDownloaded) {
                                        isFloorPlanDownloaded.setValue(true);
                                        showLoadingState.setValue(false);
                                    }
                                }));
                    }
                }));
    }

    private Observable<Boolean> downloadFileToLocalStorage(AzureTokenResponse azureTokenResponse, Tour walkthrough) {
        return Observable.fromCallable(() -> {
            AzureToken token = azureTokenResponse.getSasToken();
            String blobUrl = token.blobUrl(walkthrough.getFloorPlanBlobId(), CommonConstants.FLOOR_PLAN);
            try {
                Uri uri = UriUtils.downloadImageToLocalStorage(blobUrl, getApplication(), walkthrough.getFloorPlanBlobId());
                if (uri != null) {
                    // Update database with the path to the image
                    DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(getApplication());
                    database.projectCacheDAO().updateFloorPlanId(uri.getPath(), walkthrough.getTourId());
                    this.selectedWalkThrough.setFloorPlanPath(uri.getPath());
                    return true;
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            return false;
        });
    }

    private Observable<AzureTokenResponse> getFloorPlanObservable() {
        return apiService.getAzureTokenByRequest(CommonConstants.FLOOR_PLAN).toObservable();
    }


    public Single<InteriorWalkthrough> fetchTourDetailsFromDatabase() {
        return database.projectCacheDAO()
                .getSavedTourDetails(selectedWalkThrough.getTourId())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public void saveCaptureDataToDatabase(double floorPlanHeight, double percentIncreaseDecreaseWidth, double percentIncreaseDecreaseHeight, boolean openPublishScreen) {
        // Form the model
        double captureStartPointX = captureStartPoint.getValue().x / percentIncreaseDecreaseWidth;
        double captureStartPointY = floorPlanHeight - (captureStartPoint.getValue().y / percentIncreaseDecreaseHeight);

        PointF captureStartPoint = new PointF((float) captureStartPointX, (float) captureStartPointY);

        double captureEndPointX = captureEndPoint.getValue().x / percentIncreaseDecreaseWidth;
        double captureEndPointY = floorPlanHeight - (captureEndPoint.getValue().y / percentIncreaseDecreaseHeight);

        PointF captureEndPoint = new PointF((float) captureEndPointX, (float) captureEndPointY);

        InteriorVideoCapture videoCapture = new InteriorVideoCapture(selectedWalkThrough.getInteriorId(), selectedWalkThrough.getProjectId(), selectedWalkThrough.getTourId(),
                captureStartPoint, captureEndPoint,
                Arrays.stream(capturedVideoUrls).collect(Collectors.toList()), selectedWalkThrough.getTowerId(), selectedWalkThrough.getTourName(), false);

        disposableBag.add(database.tourDetailsDAO().insertVideoCapture(videoCapture)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((rowId, throwable) -> {
                    if (rowId != null) {
                        if (openPublishScreen) isCaptureSavedShowPublish.setValue(true);
                        else isCaptureSaved.setValue(true);
                    }
                    if (throwable != null) {
                        throwable.printStackTrace();
                    }

                }));

    }

    public void getPreviousMarkersForInterior() {
        // Fetch previous markers for the first time only
        disposableBag.add(
                NetworkListener.hasInternetConnection(getApplication()).
                        subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe((isConnected, throwable) -> {
                            if (isConnected) {
                                showLoadingState.setValue(true);
                                disposableBag.add(interiorsRepository.getPreviousWalkthrough(selectedWalkThrough.getProjectId(), selectedWalkThrough.getInteriorId(), selectedWalkThrough.getTourId())
                                        .subscribe(walkthrough -> {
                                            isAllLoadingComplete.setValue(true);
                                            showLoadingState.setValue(false);
                                            isPreviousMarkerFetched = true;
                                            if (walkthrough.getFeatures() == null
                                                    || walkthrough.getFeatures().getFeatures() == null
                                                    || walkthrough.getFeatures().getFeatures().isEmpty()) {
                                                noMarkersAvailable.setValue(true);
                                                return;
                                            }
                                            isShowingPreviousMarkers.setValue(true);
                                            previousMarkerCoordinates.setValue(walkthrough.getPreviousCapturedFeatures());
                                            previousMarkerCoordinatesClone.setValue(walkthrough.getPreviousCapturedFeatures());


                                            // Save previous markers in DB
                                            interiorsRepository.insertTourCoordinates(selectedWalkThrough.getTourId(), walkthrough.getPreviousCapturedFeatures()).subscribe();

                                        }, error -> {
                                            isAllLoadingComplete.setValue(true);
                                            isPreviousMarkerFetched = true;
                                            showLoadingState.setValue(false);
                                            if (error instanceof HttpException) {
                                                int code = ((HttpException) error).response().code();
                                                if (code == 404) {
                                                    noMarkersAvailable.setValue(true);
                                                }
                                            } else isErrorInFetchingMarkers.setValue(true);
                                        }));
                            } else {
                                disposableBag.add(
                                        interiorsRepository.getPreviousTourCoordinates(selectedWalkThrough.getTourId())
                                                .subscribe((interiorTourCoordinates, throwable1) -> {
                                                    if (interiorTourCoordinates != null) {
                                                        isAllLoadingComplete.setValue(true);
                                                        showLoadingState.setValue(false);
                                                        isPreviousMarkerFetched = true;

                                                        isShowingPreviousMarkers.setValue(true);

                                                        List<ImageFeature> previousCoordinates = interiorTourCoordinates.stream().map(interiorTourCoordinatesDb -> new ImageFeature(new Image(interiorTourCoordinatesDb.getImageId(), interiorTourCoordinatesDb.getImageId(), interiorTourCoordinatesDb.getImageId()),
                                                                interiorTourCoordinatesDb.getXCoordinate(), interiorTourCoordinatesDb.getYCoordinate())).collect(Collectors.toList());

                                                        previousMarkerCoordinates.setValue(previousCoordinates);
                                                        previousMarkerCoordinatesClone.setValue(previousCoordinates);

                                                    }
                                                })
                                );
                            }
                        })
        );
    }

    public void isPublishPending(String tourId) {
        disposableBag.add(database.tourDetailsDAO().getInteriorVideoWalkthrough(tourId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((interiorVideoCaptures, throwable) -> {
                    if (interiorVideoCaptures != null && interiorVideoCaptures.size() > 0) {
                        if (!interiorVideoCaptures.get(0).isVideoUploaded())
                            isPendingPublish.setValue(true);
                        if (interiorVideoCaptures.get(0).isVideoUploaded())
                            isWalkthroughUploadedAlready.setValue(true);
                    }
                }));
    }

}
