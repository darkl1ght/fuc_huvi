package com.huviair.capture.data.model.api.aerial;

import android.net.Uri;

import com.google.gson.annotations.Expose;

public class AerialTourRequest {
    private String imageId;
    private String blobImageId;
    private String imageName;
    private AerialImageMetaData meta;

    @Expose(serialize = false, deserialize = false)
    private int imageRowId;

    @Expose(serialize = false, deserialize = false)
    private Uri imageUri;

    public AerialTourRequest() {

    }


    public AerialTourRequest(String imageId, String blobImageId, String imageName, AerialImageMetaData meta) {
        this.imageId = imageId;
        this.blobImageId = blobImageId;
        this.imageName = imageName;
        this.meta = meta;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public void setBlobImageId(String blobImageId) {
        this.blobImageId = blobImageId;
    }

    public String getImageId() {
        return imageId;
    }

    public String getBlobImageId() {
        return blobImageId;
    }

    public void setMeta(AerialImageMetaData meta) {
        this.meta = meta;
    }

    public AerialImageMetaData getMeta() {
        return meta;
    }

    public int getImageRowId() {
        return imageRowId;
    }

    public void setImageRowId(int imageRowId) {
        this.imageRowId = imageRowId;
    }

    public void populateUri(String path){
        this.imageUri = Uri.parse(path);
    }

    public Uri getImageUri() {
        return imageUri;
    }
    @Override
    public String toString() {
        return "AerialTourRequest{" +
                "imageId='" + imageId + '\'' +
                ", blobImageId='" + blobImageId + '\'' +
                ", imageName='" + imageName + '\'' +
                ", meta=" + meta +
                '}';
    }
}
