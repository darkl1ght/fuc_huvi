package com.huviair.capture.data.model.api.snags;

public class FloorPlanDrawing {
    private final String blobContentId;
    private final String drawingName;
    private final String drawingId;

    public FloorPlanDrawing(String blobContentId, String drawingName, String drawingId) {
        this.blobContentId = blobContentId;
        this.drawingName = drawingName;
        this.drawingId = drawingId;
    }

    public String getBlobContentId() {
        return blobContentId;
    }

    public String getDrawingId() {
        return drawingId;
    }

    public String getDrawingName() {
        return drawingName;
    }
}
