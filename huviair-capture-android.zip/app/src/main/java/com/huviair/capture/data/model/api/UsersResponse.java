package com.huviair.capture.data.model.api;

import java.util.List;

public class UsersResponse {
    private List<LoggedInUser.User> users;

    public List<LoggedInUser.User> getUsers() {
        return users;
    }
}
