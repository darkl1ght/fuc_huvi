package com.huviair.capture.data.model.api.common;

public class PaginationMetaData {
    private int itemCount, itemsPerPage, currentPage, pageCount;
    private boolean hasPrevPage, hasNextPage;
    private Integer prevPage, nextPage;

    public int getItemCount() {
        return itemCount;
    }

    public int getItemsPerPage() {
        return itemsPerPage;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public int getPageCount() {
        return pageCount;
    }

    public boolean isHasPrevPage() {
        return hasPrevPage;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public Integer getPrevPage() {
        return prevPage;
    }

    public Integer getNextPage() {
        return nextPage;
    }
}
