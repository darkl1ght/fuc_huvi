package com.huviair.capture.viewmodels;

import android.annotation.SuppressLint;
import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkContinuation;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;
import androidx.work.WorkQuery;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.tours.Interior;
import com.huviair.capture.data.model.api.tours.InteriorsResponse;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.model.api.tours.interiorsResponse.FloorWalkThrough;
import com.huviair.capture.data.model.database.InteriorTower;
import com.huviair.capture.data.model.database.InteriorVideoCapture;
import com.huviair.capture.data.model.database.InteriorWalkthrough;
import com.huviair.capture.data.model.others.InteriorPublishEvent;
import com.huviair.capture.data.repositories.InteriorsRepository;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.ui.interiors.InteriorDataView;
import com.huviair.capture.ui.interiors.InteriorsResult;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.NetworkListener;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.utils.SingleLiveEvent;
import com.huviair.capture.workers.CompressAndPublishImagesWorker;
import com.huviair.capture.workers.DownloadImageWorker;
import com.huviair.capture.workers.ExportHDRImagesWorker;
import com.huviair.capture.workers.GenerateHDRImagesWorker;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class InteriorsViewModel extends AndroidViewModel {

    public final SingleLiveEvent<Boolean> isFetchingData = new SingleLiveEvent<>();
    private final InteriorsRepository interiorsRepository;
    private final MutableLiveData<InteriorsResult> interiorsResultMutableLiveData = new MutableLiveData<>();
    private final LiveData<List<WorkInfo>> floorPlanDownloadWorkInfo, publishImagesWorkInfo, stitcingImagesWorkInfo;
    private final SingleLiveEvent<List<InteriorVideoCapture>> videoCaptures = new SingleLiveEvent<>();

    // WorkManager - Information
    private final WorkManager workManager;
    private final DataCaptureRoomDatabase database;
    private final CompositeDisposable bag = new CompositeDisposable();

    public SingleLiveEvent<String> selectedTowerId = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> isWalkthroughInProgress = new SingleLiveEvent<>();

    public String selectedInteriorId = "";

    // Specific to publish interior tours
    public SingleLiveEvent<InteriorPublishEvent> publishSingleLiveEvent = new SingleLiveEvent<>();
    public Boolean isInternetConnectivityAvailable = false;

    public String selectedWorkTowerId = "";
    public String selectedWorkInteriorId = "";
    public String projectId;

    public UUID workUUID = UUID.randomUUID();

    private LiveData<List<WorkInfo>> publishWalkthroughWorkInfo;

    private List<String> tourNames = new ArrayList<>();
    private List<String> towerNames = new ArrayList<>();
    private List<FloorWalkThrough> walkThroughResponseList = new ArrayList<>();
    private List<FloorWalkThrough> walkthroughWorkResponseList = new ArrayList<>();
    private List<Interior> interiorsList = new ArrayList<>();

    private List<String> stitchingImageData = Arrays.asList(CommonConstants.EXPORT_HDR_WORKER, CommonConstants.GENERATE_HDR_WORKER);

    public InteriorsViewModel(@NonNull Application application) {
        super(application);
        workManager = WorkManager.getInstance(application);
        interiorsRepository = new InteriorsRepository(application);
        database = DataCaptureRoomDatabase.getDatabase(application);
        floorPlanDownloadWorkInfo = workManager.getWorkInfosByTagLiveData(CommonConstants.FLOOR_PLAN_DOWNLOAD_WORK);
        publishImagesWorkInfo = workManager.getWorkInfosByTagLiveData(CommonConstants.COMPRESS_PUBLISH_IMAGE_WORKER);
        stitcingImagesWorkInfo = workManager.getWorkInfosLiveData(WorkQuery.Builder.fromTags(stitchingImageData).build());
    }

    public SingleLiveEvent<List<InteriorVideoCapture>> getVideoCaptures() {
        return videoCaptures;
    }

    public LiveData<List<WorkInfo>> getPublishImagesWorkInfo() {
        return publishImagesWorkInfo;
    }

    public LiveData<List<WorkInfo>> getStitcingImagesWorkInfo() {
        return stitcingImagesWorkInfo;
    }

    public void getWorkInfoByTowerId(String selectedWorkTowerId) {
        publishWalkthroughWorkInfo = workManager.getWorkInfosByTagLiveData(selectedWorkTowerId);
    }

    public List<FloorWalkThrough> getWalkthroughWorkResponseList() {
        return walkthroughWorkResponseList;
    }
    public void getVideoCaptureDetailsByTowerId(String selectedInteriorId, String selectedWorkTowerId) {
        bag.add(database.tourDetailsDAO().getVideoWalkthroughsByTower(selectedInteriorId, selectedWorkTowerId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe((interiorVideoCaptures, throwable) -> {
                    if (interiorVideoCaptures != null) {
                        videoCaptures.setValue(interiorVideoCaptures);
                    }

                })
        );
    }

    public MutableLiveData<InteriorsResult> getInteriorsResultMutableLiveData() {
        return interiorsResultMutableLiveData;
    }

    public LiveData<List<WorkInfo>> getFloorPlanDownloadWorkInfo() {
        return floorPlanDownloadWorkInfo;
    }

    public LiveData<List<WorkInfo>> getPublishWalkthroughWorkInfo() {
        return publishWalkthroughWorkInfo;
    }

    @SuppressLint("CheckResult")
    public void fetchInteriorsForTheProject(String projectId) {

        isFetchingData.setValue(true);

        // Populate data for the first time from network call
        bag.add(NetworkListener.hasInternetConnection(getApplication())
                .subscribe((hasInternet) -> {
                    if (hasInternet && !new SharedPreferencesManager(getApplication()).isInteriorsDownloaded()) {
                        interiorsRepository.fetchInteriorsAndWalkthroughs(projectId)
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribeOn(Schedulers.io())
                                .subscribe(new DisposableSingleObserver<InteriorsResponse>() {
                                    @Override
                                    public void onSuccess(@io.reactivex.annotations.NonNull InteriorsResponse interiorsResponse) {
                                        isFetchingData.setValue(false);
                                        interiorsList = interiorsResponse.getInteriors();

                                        // populate database with the interiors
                                        populateInteriorDataToDatabase(interiorsList);

                                        interiorsResultMutableLiveData.setValue(new InteriorsResult(new InteriorDataView(interiorsResponse.getInteriors(), null)));
                                    }

                                    @Override
                                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                                        isFetchingData.setValue(false);
                                        Log.e("Error in database 172", "onError: ",e );
                                        interiorsResultMutableLiveData.setValue(new InteriorsResult(R.string.technical_error));
                                    }
                                });

                    } else fetchDetailsFromDatabase(projectId);
                }));
    }

    private void populateInteriorDataToDatabase(List<Interior> interiorData) {
        // Interiors
        com.huviair.capture.data.model.database.Interior[] interiors = interiorData.stream()
                .map(interior -> new com.huviair.capture.data.model.database.Interior(interior.getInteriorId(), interior.getInteriorName(), interior.getProjectId()))
                .toArray(com.huviair.capture.data.model.database.Interior[]::new);

        // Interior Towers
        InteriorTower[] interiorTowers = interiorData.stream()
                .map(Interior::getFloorWalkthough)
                .flatMap(Collection::stream)
                .map(floorWalkThrough -> new InteriorTower(floorWalkThrough.getInteriorId(), floorWalkThrough.getTowerId(), floorWalkThrough.getTowerName(), projectId))
                .toArray(InteriorTower[]::new);

        InteriorWalkthrough[] interiorWalkthroughs = interiorData.stream().map(Interior::getFloorWalkthough).flatMap(Collection::stream)
                .flatMap(floorWalkThroughCacheData -> floorWalkThroughCacheData.getTours().stream())
                .map(tour -> new InteriorWalkthrough(tour.getInteriorId(), tour.getTowerId(), tour.getFloorPlanBlobId(), tour.getTourId(), tour.getTourName(), tour.getProjectId()))
                .toArray(InteriorWalkthrough[]::new);

        // Clean up existing details and insert latest details
        bag.add(database.projectCacheDAO().deleteInteriors(projectId)
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().deleteInteriorTowers(projectId)))
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().deleteWalkthroughs(projectId)))
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().insertInteriors(interiors)))
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().insertInteriorTowers(interiorTowers)))
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().insertWalkthroughs(interiorWalkthroughs)))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(() -> new SharedPreferencesManager(getApplication()).setIsInteriorsDownloaded(true)));
    }

    @SuppressLint("CheckResult")
    public void fetchWalkThroughsForTheTour(String interiorId) {
        isFetchingData.setValue(true);

        database.projectCacheDAO().getTowersForInterior(interiorId)
                .flatMap(interiorTowers -> {
                    walkThroughResponseList = interiorTowers.stream().map(interiorTower -> new FloorWalkThrough(interiorTower.getTowerId(), interiorTower.getTowerName(), interiorTower.getInteriorId())).collect(Collectors.toList());
                    return Single.just(walkThroughResponseList);
                })
                .flatMap(floorWalkThroughs -> {
                    if (!floorWalkThroughs.isEmpty()) {
                        for (FloorWalkThrough walkThrough : floorWalkThroughs) {
                            List<InteriorWalkthrough> walkthroughsForTower = database.projectCacheDAO().getWalkthroughsForTower(interiorId, walkThrough.getTowerId());
                            walkThrough.setTours(walkthroughsForTower.stream().map(interiorWalkthrough -> new Tour(interiorWalkthrough.getFloorPlanBlobId(), interiorWalkthrough.getInteriorId(), interiorWalkthrough.getTourId(), interiorWalkthrough.getTourName(),
                                    interiorWalkthrough.getTowerId(), interiorWalkthrough.getProjectId(), interiorWalkthrough.getFloorPlanPath())).collect(Collectors.toList()));
                        }
                    }
                    return Single.just(floorWalkThroughs);
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((floorWalkThroughs, throwable) -> {
                    walkThroughResponseList = floorWalkThroughs;
                    isFetchingData.setValue(false);
                    interiorsResultMutableLiveData.setValue(new InteriorsResult(new InteriorDataView(null, walkThroughResponseList)));
                });

    }

    @SuppressLint("CheckResult")
    public void fetchWorkWalkThroughsForTheTour(String interiorId) {
        isFetchingData.setValue(true);

        database.projectCacheDAO().getTowersForInterior(interiorId)
                .flatMap(interiorTowers -> {
                    walkthroughWorkResponseList = interiorTowers.stream().map(interiorTower -> new FloorWalkThrough(interiorTower.getTowerId(), interiorTower.getTowerName(), interiorTower.getInteriorId())).collect(Collectors.toList());
                    return Single.just(walkthroughWorkResponseList);
                })
                .flatMap(floorWalkThroughs -> {
                    if (!floorWalkThroughs.isEmpty()) {
                        for (FloorWalkThrough walkThrough : floorWalkThroughs) {
                            List<InteriorWalkthrough> walkthroughsForTower = database.projectCacheDAO().getWalkthroughsForTower(interiorId, walkThrough.getTowerId());
                            walkThrough.setTours(walkthroughsForTower.stream().map(interiorWalkthrough -> new Tour(interiorWalkthrough.getFloorPlanBlobId(), interiorWalkthrough.getInteriorId(), interiorWalkthrough.getTourId(), interiorWalkthrough.getTourName(),
                                    interiorWalkthrough.getTowerId(), interiorWalkthrough.getProjectId(), interiorWalkthrough.getFloorPlanPath())).collect(Collectors.toList()));
                        }
                    }
                    return Single.just(floorWalkThroughs);
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((floorWalkThroughs, throwable) -> {
                    walkthroughWorkResponseList = floorWalkThroughs;
                    isFetchingData.setValue(false);
                    interiorsResultMutableLiveData.setValue(new InteriorsResult(new InteriorDataView(null, walkthroughWorkResponseList)));
                });

    }

    public List<FloorWalkThrough> getWalkThroughResponseList() {
        return walkThroughResponseList;
    }

    public List<Interior> getInteriorsList() {
        return interiorsList;
    }

    public List<String> getTourNames() {
        return tourNames;
    }

    public void setTourNames(List<String> tourNames) {
        this.tourNames = tourNames;
    }

    public List<String> getTowerNames() {
        return towerNames;
    }

    public void setTowerNames(List<String> towerNames) {
        this.towerNames = towerNames;
    }

    public void scheduleForTourPublish(String walkthroughName, String projectId, String interiorTourId, String interiorWalkthroughId, String towerId) {
        //work constraints
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();

        // Start image processing GenerateHDR => StitchImages
        OneTimeWorkRequest publishImagesWorkRequest = new OneTimeWorkRequest.Builder(CompressAndPublishImagesWorker.class)
                .setInputData(createInputDataForUri(walkthroughName, projectId, interiorTourId, interiorWalkthroughId, towerId))
                .addTag(interiorWalkthroughId)
                .addTag(towerId)
                .addTag(interiorTourId)
                .addTag(CommonConstants.COMPRESS_PUBLISH_IMAGE_WORKER)
                .setConstraints(constraints)
                .build();

        if (isInternetConnectivityAvailable) {
            isWalkthroughInProgress.setValue(true);
            workManager.enqueueUniqueWork(interiorWalkthroughId, ExistingWorkPolicy.REPLACE, publishImagesWorkRequest);
        }

    }

    public void publishWalkthroughBulk(List<WorkInfo> workInfo) {
        if (isInternetConnectivityAvailable) {
            List<WorkInfo> workListToProcess = workInfo.stream().filter(workToProcess -> workToProcess.getState().isFinished() && workToProcess.getTags().contains(CommonConstants.EXPORT_HDR_WORKER))
                    .collect(Collectors.toList());

            workListToProcess.stream().forEach(work -> {
                Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();

                String interiorWalkthroughId = work.getOutputData().getString(CommonConstants.WALKTHROUGH_ID);
                String walkthroughName = work.getOutputData().getString(CommonConstants.TOUR_NAME);
                String interiorTourId = work.getOutputData().getString(CommonConstants.INTERIOR_TOUR_ID);
                String projectId = work.getOutputData().getString(CommonConstants.PROJECT_ID);
                String towerId = work.getOutputData().getString(CommonConstants.TOWER_ID);

                OneTimeWorkRequest publishWorkRequest = new OneTimeWorkRequest.Builder(CompressAndPublishImagesWorker.class)
                        .setInputData(createInputDataForUri(walkthroughName, projectId, interiorTourId, interiorWalkthroughId, towerId))
                        .addTag(interiorWalkthroughId)
                        .addTag(towerId)
                        .addTag(interiorTourId)
                        .addTag(CommonConstants.COMPRESS_PUBLISH_IMAGE_WORKER)
                        .setConstraints(constraints)
                        .build();

                workManager.enqueueUniqueWork(interiorWalkthroughId, ExistingWorkPolicy.KEEP, publishWorkRequest);

            });
        }


    }

    public void retryStitchAndExportImages(String walkthroughName, String interiorTourId, String interiorWalkthroughId, String towerId) {

        // Start image processing GenerateHDR => StitchImages
        OneTimeWorkRequest generateHDRRequest = new OneTimeWorkRequest.Builder(GenerateHDRImagesWorker.class)
                .setInputData(createInputDataForUri(walkthroughName, projectId, interiorTourId, interiorWalkthroughId, towerId))
                .addTag(CommonConstants.GENERATE_HDR_WORKER)
                .addTag(interiorWalkthroughId)
                .addTag(towerId)
                .addTag(interiorTourId)
                .build();

        OneTimeWorkRequest exportHDRWorker = new OneTimeWorkRequest.Builder(ExportHDRImagesWorker.class)
                .setInputData(createInputDataForUri(walkthroughName, projectId, interiorTourId, interiorWalkthroughId, towerId))
                .addTag(CommonConstants.EXPORT_HDR_WORKER)
                .addTag(interiorWalkthroughId)
                .addTag(towerId)
                .addTag(interiorTourId)
                .build();

        WorkContinuation continuation = workManager.beginUniqueWork(interiorWalkthroughId, ExistingWorkPolicy.REPLACE, generateHDRRequest);

        continuation = continuation.then(exportHDRWorker);

        continuation.enqueue();
    }


    private Data createInputDataForUri(String walkthroughName, String projectId, String interiorTourId, String interiorWalkThroughId, String towerId) {
        Data.Builder builder = new Data.Builder();
        builder.putString(CommonConstants.WALKTHROUGH_ID, interiorWalkThroughId);
        builder.putString(CommonConstants.PROJECT_ID, projectId);
        builder.putString(CommonConstants.INTERIOR_TOUR_ID, interiorTourId);
        builder.putString(CommonConstants.TOUR_NAME, walkthroughName);
        builder.putString(CommonConstants.TOWER_ID, towerId);

        return builder.build();
    }

    private Data createInputDataForDownload(String interiorId, String selectedTowerId) {
        Data.Builder builder = new Data.Builder();
        builder.putString(CommonConstants.INTERIOR_TOUR_ID, interiorId);
        builder.putString(CommonConstants.TOWER_ID, selectedTowerId);

        // find tower name
        String towerName = walkThroughResponseList.stream().filter(floorWalkThrough -> floorWalkThrough.getTowerId().equals(selectedTowerId)).findFirst().get().getTowerName();

        builder.putString(CommonConstants.TOWER_NAME, towerName);
        return builder.build();
    }

    public void downloadFloorPlans() {
        //work constraints
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();

        OneTimeWorkRequest downloadFloorPlansRequest = new OneTimeWorkRequest.Builder(DownloadImageWorker.class)
                .setInputData(createInputDataForDownload(selectedInteriorId, selectedTowerId.getValue()))
                .addTag(CommonConstants.FLOOR_PLAN_DOWNLOAD_WORK)
                .setConstraints(constraints)
                .build();

        workUUID = downloadFloorPlansRequest.getId();
        workManager.enqueueUniqueWork(selectedTowerId.getValue(), ExistingWorkPolicy.REPLACE, downloadFloorPlansRequest);

    }

    private void fetchDetailsFromDatabase(String projectId) {
        // Fetch details only from the DB
        database.projectCacheDAO().getInteriorsByProjectId(projectId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new DisposableSingleObserver<List<com.huviair.capture.data.model.database.Interior>>() {
                    @Override
                    public void onSuccess(@io.reactivex.annotations.NonNull List<com.huviair.capture.data.model.database.Interior> interiors) {
                        isFetchingData.setValue(false);
                        interiorsList = interiors.stream().map(interior -> new Interior(interior.getInteriorId(), interior.getProjectId(), interior.getInteriorName())).collect(Collectors.toList());
                        interiorsResultMutableLiveData.setValue(new InteriorsResult(new InteriorDataView(interiorsList, null)));
                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                        isFetchingData.setValue(false);
                        Log.e("Error in database 396", "onError: ",e );
                        interiorsResultMutableLiveData.setValue(new InteriorsResult(R.string.technical_error));
                    }
                });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (!bag.isDisposed()) bag.dispose();
    }
}
