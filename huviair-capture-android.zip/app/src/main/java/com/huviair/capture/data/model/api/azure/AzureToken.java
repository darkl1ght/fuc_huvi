package com.huviair.capture.data.model.api.azure;

import com.huviair.capture.api.APIClient;

public class AzureToken {
    private String token;
    private String uri;

    public String blobUrl(String imageName, String requestType) {
        return APIClient.getAzureBlobBaseUrl().concat(requestType).concat("/").concat(imageName).concat("?").concat(token);
    }

    public String getUri() {
        return uri;
    }
}
