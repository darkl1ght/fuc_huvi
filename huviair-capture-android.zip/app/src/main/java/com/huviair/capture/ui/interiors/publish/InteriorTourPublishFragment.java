package com.huviair.capture.ui.interiors.publish;

import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.work.WorkInfo;

import com.github.pwittchen.reactivenetwork.library.rx2.ReactiveNetwork;
import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.InternetObservingSettings;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.adapters.InteriorPublishStatusAdapter;
import com.huviair.capture.data.model.database.InteriorVideoCapture;
import com.huviair.capture.databinding.FragmentInteriorTourPublishBinding;
import com.huviair.capture.ui.interiors.videocapture.publish.VideoCapturePublish;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.viewmodels.InteriorsViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link InteriorTourPublishFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class InteriorTourPublishFragment extends Fragment {

    private static final String TOWER_ID = "TOWER_ID";
    private static final String INTERIOR_ID = "INTERIOR_ID";

    private final List<Object> adapterData = new ArrayList<>();
    private String towerId;
    private String interiorId;

    private FragmentInteriorTourPublishBinding interiorTourPublishBinding;

    private List<WorkInfo> publishWorkInfo;
    private Snackbar internetConnectivitySnackbar;
    private InteriorsViewModel interiorsViewModel;

    private boolean isInternetConnectivityListenerAdded = false;

    private final CompositeDisposable disposable = new CompositeDisposable();

    public InteriorTourPublishFragment() {
        // Required empty public constructor
    }

    public static InteriorTourPublishFragment newInstance(String interiorId, String towerId) {
        InteriorTourPublishFragment fragment = new InteriorTourPublishFragment();
        Bundle args = new Bundle();
        args.putString(TOWER_ID, towerId);
        args.putString(INTERIOR_ID, interiorId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            towerId = getArguments().getString(TOWER_ID);
            interiorId = getArguments().getString(INTERIOR_ID);
        }
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        interiorTourPublishBinding = FragmentInteriorTourPublishBinding.inflate(inflater, container, false);
        return interiorTourPublishBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        interiorsViewModel = new ViewModelProvider(requireActivity(), new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication())).get(InteriorsViewModel.class);

        initializeConnectivitySnackbar();

        interiorTourPublishBinding.interiorPublishToolBar.toolBar.setTitle("Publish Walk-through");
        interiorTourPublishBinding.interiorPublishToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        interiorTourPublishBinding.interiorPublishToolBar.toolBar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        interiorsViewModel.getWorkInfoByTowerId(towerId);
        interiorsViewModel.getVideoCaptureDetailsByTowerId(interiorId, towerId);

        interiorsViewModel.getVideoCaptures().observe(getViewLifecycleOwner(),videoCaptures-> {

            Iterator<Object> iter = adapterData.iterator();
            while (iter.hasNext()) {
                Object obj = iter.next();
                if (obj instanceof InteriorVideoCapture) {
                    iter.remove();
                }
            }

            adapterData.removeAll(videoCaptures);
            adapterData.addAll(videoCaptures);
            populateRecyclerView();
        });

        interiorsViewModel.getPublishWalkthroughWorkInfo().observe(getViewLifecycleOwner(), workInfos -> {

            publishWorkInfo = workInfos.stream().filter(workInfo -> (workInfo.getTags().contains(CommonConstants.EXPORT_HDR_WORKER)
                    || workInfo.getTags().contains(CommonConstants.COMPRESS_PUBLISH_IMAGE_WORKER))
                    && workInfo.getState().isFinished()
                    && workInfo.getTags().contains(towerId)
                    && workInfo.getTags().contains(interiorId)).collect(Collectors.toList());


            if(publishWorkInfo.isEmpty()){
                Iterator<Object> iter = adapterData.iterator();
                while (iter.hasNext()) {
                    Object obj = iter.next();
                    if (obj instanceof WorkInfo) {
                        iter.remove();
                    }
                }
                adapterData.removeAll(publishWorkInfo);
                populateRecyclerView();
            }

            if ((publishWorkInfo.size() > 0)) {
                interiorTourPublishBinding.publishAllWalkThroughs.show();
                interiorTourPublishBinding.noInteriorJobData.setVisibility(View.GONE);

                Iterator<Object> iter = adapterData.iterator();
                while (iter.hasNext()) {
                    Object obj = iter.next();
                    if (obj instanceof WorkInfo) {
                        iter.remove();
                    }
                }
                adapterData.removeAll(publishWorkInfo);
                adapterData.addAll(publishWorkInfo);
                populateRecyclerView();
                addInternetConnectivityListener();
            } else {
                if(!workInfos.stream().anyMatch(workInfo -> (workInfo.getTags().contains(CommonConstants.COMPRESS_PUBLISH_IMAGE_WORKER)
                        && workInfo.getTags().contains(towerId)
                        && workInfo.getTags().contains(interiorId)
                        && WorkInfo.State.RUNNING == workInfo.getState()
                ) ) && (interiorsViewModel.getVideoCaptures().getValue() == null || interiorsViewModel.getVideoCaptures().getValue().isEmpty())){
                    interiorTourPublishBinding.noInteriorJobData.setVisibility(View.VISIBLE);
                    interiorTourPublishBinding.publishAllWalkThroughs.hide();
                }

            }
        });

        interiorsViewModel.isWalkthroughInProgress.observe(getViewLifecycleOwner(), isWalkthroughInProgress -> showSnackBarMessage("Walk-through added to the queue successfully", R.color.snackbar_success));

        interiorTourPublishBinding.publishAllWalkThroughs.setOnClickListener(v -> {
            new MaterialAlertDialogBuilder(requireContext()).setTitle("Are you sure ?")
                    .setMessage("Publish walk-through and all the data associated with the walk-through")
                    .setPositiveButton("YES", (dialog, which) -> {
                        interiorsViewModel.publishWalkthroughBulk(publishWorkInfo);
                        showSnackBarMessage("Walk-through added to the queue successfully", R.color.snackbar_success);
                    })
                    .setNegativeButton("NO", (dialog, which) -> {
                    })
                    .setCancelable(true)
                    .show();
        });



        addWorkInfoListener();

    }


    private void addWorkInfoListener() {
        interiorsViewModel.getPublishImagesWorkInfo().observe(getViewLifecycleOwner(), workInfos -> {
            boolean isInProgress = workInfos.stream().anyMatch(workInfo -> WorkInfo.State.RUNNING == workInfo.getState());
            interiorTourPublishBinding.processingIndicator.setVisibility(isInProgress ? View.VISIBLE : View.GONE);
            if (isInProgress) {
                interiorTourPublishBinding.publishAllWalkThroughs.hide();
                interiorTourPublishBinding.noInteriorJobData.setVisibility(View.GONE);
                interiorTourPublishBinding.processingText.setText("Publishing data");
            } else {
                interiorTourPublishBinding.processingText.setText("");
            }
        });

        interiorsViewModel.getStitcingImagesWorkInfo().observe(getViewLifecycleOwner(), workInfos -> {
            boolean isInProgress = workInfos.stream().anyMatch(workInfo -> WorkInfo.State.RUNNING == workInfo.getState());
            interiorTourPublishBinding.processingIndicator.setVisibility(isInProgress ? View.VISIBLE : View.GONE);
            if (isInProgress) {
                interiorTourPublishBinding.noInteriorJobData.setVisibility(View.GONE);
                interiorTourPublishBinding.processingText.setText("Processing data");
            } else {
                interiorTourPublishBinding.processingText.setText("");
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    private void addInternetConnectivityListener() {
        InternetObservingSettings settings = InternetObservingSettings.builder()
                .initialInterval(1000)
                .interval(3000)
                .build();

        Observable<Boolean> internetObservable = ReactiveNetwork
                .observeInternetConnectivity(settings)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());


        if(!isInternetConnectivityListenerAdded){
            disposable.add(internetObservable
                    .subscribe(isConnectedToInternet -> {
                        if (!isConnectedToInternet) {
                            interiorsViewModel.isInternetConnectivityAvailable = false;
                            internetConnectivitySnackbar.show();
                        } else {
                            interiorsViewModel.isInternetConnectivityAvailable = true;
                            if (internetConnectivitySnackbar.isShown()) {
                                internetConnectivitySnackbar.dismiss();
                            }
                        }
                    }));

        }

        isInternetConnectivityListenerAdded = true;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        internetConnectivitySnackbar.dismiss();
        if(!disposable.isDisposed()){
            disposable.dispose();
        }
    }

    private void populateRecyclerView() {
        InteriorPublishStatusAdapter interiorPublishStatusAdapter = new InteriorPublishStatusAdapter(adapterData);

        interiorTourPublishBinding.recyclerInteriorPublishView.setHasFixedSize(true);
        interiorTourPublishBinding.recyclerInteriorPublishView.setAdapter(interiorPublishStatusAdapter);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        interiorTourPublishBinding.recyclerInteriorPublishView.addItemDecoration(new DividerItemDecoration(requireContext(),
                DividerItemDecoration.VERTICAL));
        interiorTourPublishBinding.recyclerInteriorPublishView.setLayoutManager(linearLayoutManager);

    }

    private void showSnackBarMessage(String text, int color) {
        Snackbar.make(interiorTourPublishBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_LONG)
                .setBackgroundTint(ContextCompat.getColor(requireContext(), color))
                .setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                .show();
    }

    private void initializeConnectivitySnackbar() {
        internetConnectivitySnackbar = Snackbar.make(interiorTourPublishBinding.getRoot(), "Publishing requires internet", Snackbar.LENGTH_INDEFINITE)
                .setBackgroundTint(ContextCompat.getColor(requireContext(),R.color.snackbar_default))
                .setTextColor(ContextCompat.getColor(requireContext(),R.color.snackbar_text))
                .setAction("Connect", view -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        startActivity(new Intent(android.provider.Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
                    }
                    else startActivity(new Intent(WifiManager.ACTION_PICK_WIFI_NETWORK));
                });

    }
}