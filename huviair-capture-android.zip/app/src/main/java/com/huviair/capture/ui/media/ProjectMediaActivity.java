package com.huviair.capture.ui.media;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.projects.Project;
import com.huviair.capture.databinding.ActivityProjectMediaBinding;
import com.huviair.capture.ui.aerial.AerialActivity;
import com.huviair.capture.ui.media.fragments.ExoMediaPlayerFragment;
import com.huviair.capture.ui.media.fragments.ProjectAlbumListFragment;
import com.huviair.capture.ui.media.fragments.ProjectMediaListFragment;
import com.huviair.capture.ui.media.fragments.MediaViewerFragment;
import com.huviair.capture.ui.interiors.InteriorsActivity;
import com.huviair.capture.ui.snags.SnagActivity;
import com.huviair.capture.viewmodels.AlbumsListViewModel;

public class ProjectMediaActivity extends AppCompatActivity {

    public static final String SELECTED_PROJECT = "SELECTED_PROJECT";
    private Project selectedProject;
    private ActivityProjectMediaBinding projectMediaBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectMediaBinding = ActivityProjectMediaBinding.inflate(getLayoutInflater());
        setContentView(projectMediaBinding.getRoot());

        AlbumsListViewModel viewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(AlbumsListViewModel.class);

        if (getIntent().getExtras() != null) {
            selectedProject = (Project) getIntent().getSerializableExtra(SELECTED_PROJECT);
        }

        populateBottomNavigationView();

        if (savedInstanceState == null) {
            ProjectAlbumListFragment projectAlbumListFragment = ProjectAlbumListFragment.newInstance(selectedProject.getProjectId());
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.album_list_fragment, projectAlbumListFragment, null)
                    .commit();
        }


        viewModel.getSelectedAlbum().observe(this, selectedAlbum -> getSupportFragmentManager().beginTransaction()
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .replace(R.id.album_list_fragment, ProjectMediaListFragment.newInstance(selectedAlbum.getAlbum()), null)
                .commit());

        viewModel.getMediaLiveDataForViewPager().observe(this, media ->
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .addToBackStack(null)
                        .replace(R.id.album_list_fragment, new MediaViewerFragment(), null)
                        .commit());

        viewModel.getPlayVideo().observe(this, mediaDetails ->
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .addToBackStack(null)
                        .replace(R.id.album_list_fragment, ExoMediaPlayerFragment.newInstance(mediaDetails.getBlobContentId(), mediaDetails.getBlobDescription(), mediaDetails.is360Video()), null)
                        .commit());


    }

    private void populateBottomNavigationView() {

        projectMediaBinding.bottomNavigationMedia.getRoot().setVisibility(View.VISIBLE);
        //projectMediaBinding.bottomNavigationMedia.getRoot().setSelectedItemId(R.id.media);

        projectMediaBinding.bottomNavigationMedia.getRoot().setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.interiors) {
                Intent interiorIntent = new Intent(this, InteriorsActivity.class);
                interiorIntent.putExtra(InteriorsActivity.PROJECT, selectedProject);
                startActivity(interiorIntent);
                overridePendingTransition(0, 0);
                finish();

            } else if (itemId == R.id.snag) {
                Intent interiorIntent = new Intent(this, SnagActivity.class);
                interiorIntent.putExtra(SnagActivity.SELECTED_PROJECT, selectedProject);
                startActivity(interiorIntent);
                overridePendingTransition(0, 0);
                finish();

            } else if (itemId == R.id.aerial) {
                Intent interiorIntent = new Intent(this, AerialActivity.class);
                interiorIntent.putExtra(SnagActivity.SELECTED_PROJECT, selectedProject);
                startActivity(interiorIntent);
                overridePendingTransition(0, 0);
                finish();
            }
            return true;
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (projectMediaBinding != null) {
            projectMediaBinding = null;
        }
    }
}