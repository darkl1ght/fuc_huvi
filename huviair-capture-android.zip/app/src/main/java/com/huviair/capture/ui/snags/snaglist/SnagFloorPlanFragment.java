package com.huviair.capture.ui.snags.snaglist;

import android.annotation.SuppressLint;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.davemorrissey.labs.subscaleview.ImageSource;
import com.davemorrissey.labs.subscaleview.ImageViewState;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.azure.AzureToken;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagMediaFloorPlan;
import com.huviair.capture.data.model.others.SavedFloorPlanPin;
import com.huviair.capture.databinding.FragmentSnagFloorPlanBinding;
import com.huviair.capture.ui.snags.snagutils.SnagUtils;
import com.huviair.capture.ui.interiors.tours.Coordinates;
import com.huviair.capture.ui.interiors.tours.PinView;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.GlideApp;
import com.huviair.capture.utils.GlideUrlUtil;
import com.huviair.capture.viewmodels.SnagListItemModel;
import com.huviair.capture.viewmodels.SnagViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * This Fragment is used in multiple functionalities
 * 1) Snag update (via SnagListViewFragment)
 * 2) Snag Create Fragment
 */
public class SnagFloorPlanFragment extends Fragment {

    private static final String PIN_COORDINATES_ARRAY = "PIN_COORDINATES_ARRAY";
    private static final String SAVED_PIN_ARRAY = "SAVED_PIN_ARRAY";

    private static final String SELECTED_SNAG = "SELECTED_SNAG";
    private static final String IS_CREATE_SNAG_FRAGMENT = "IS_CREATE_SNAG_FRAGMENT";

    private FragmentSnagFloorPlanBinding snagFloorPlanBinding;

    private Snag selectedSnag;
    private boolean isCreateSnagFragment;

    // View models - Fragment level
    private SnagListItemModel snagListItemModel;

    // View Model - Activity level
    private SnagViewModel snagViewModel;

    private double floorPlanOrigHeight;
    private double floorPlanOrigWidth;

    public SnagFloorPlanFragment() {
        // Required empty public constructor
    }

    public static SnagFloorPlanFragment newInstance(Snag selectedSnag, boolean isSnagCreateFragment) {
        SnagFloorPlanFragment fragment = new SnagFloorPlanFragment();
        Bundle args = new Bundle();
        args.putSerializable(SELECTED_SNAG, selectedSnag);
        args.putBoolean(IS_CREATE_SNAG_FRAGMENT, isSnagCreateFragment);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            selectedSnag = (Snag) getArguments().getSerializable(SELECTED_SNAG);
            isCreateSnagFragment = getArguments().getBoolean(IS_CREATE_SNAG_FRAGMENT);
        }
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Change orientation and hide bottom navigation
        requireActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.GONE);

        // Inflate the layout for this fragment
        snagFloorPlanBinding = FragmentSnagFloorPlanBinding.inflate(inflater, container, false);

        // Fetch any previous points marked in the transaction
        if (savedInstanceState != null && savedInstanceState.containsKey(SAVED_PIN_ARRAY) && savedInstanceState.containsKey(PIN_COORDINATES_ARRAY)) {
            snagFloorPlanBinding.floorPlanPinView.setPinCoordinates((ArrayList<Coordinates>) savedInstanceState.getSerializable(PIN_COORDINATES_ARRAY));
            snagFloorPlanBinding.floorPlanPinView.setsPin((ArrayList<SavedFloorPlanPin>) savedInstanceState.getSerializable(SAVED_PIN_ARRAY));
        }

        return snagFloorPlanBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);

        // Initialise fragment level and activity level models
        snagListItemModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication())).get(SnagListItemModel.class);

        snagViewModel = new ViewModelProvider(requireActivity()).get(SnagViewModel.class);

        // Fetch the Floor-plan-token
        snagListItemModel.fetchSnagMediaFloorPlanUrl();

        snagFloorPlanBinding.loadingImage.setVisibility(View.VISIBLE);

        // Fetch azure blob token
        observeFloorPlanToken();

        // Gesture changes on image if ready
        watchForGestureChanges();

        //Save latest snapshot
        saveLatestSnapshot();

        // Observe for save of floorplan
        observeSaveFloorPlanFeatures();
    }

    private void observeSaveFloorPlanFeatures() {
        snagListItemModel.getSnagFloorPlanSaveLiveData().observe(getViewLifecycleOwner(), snagMediaResult -> {
            if (snagMediaResult.getSuccess() != null) {
                // Enable views
                toggleViewsVisibility(true);

                showSnackBarMessage("Floor Plan saved successfully", R.color.snackbar_success, requireActivity().findViewById(R.id.bottom_navigation_snag));
                snagViewModel.setIsFloorPlanSaved();
            }
            if (snagMediaResult.getError() != null) {
                //Enable views
                toggleViewsVisibility(true);

                showSnackBarMessage("Problem in saving the floor plan, please check your internet connection", R.color.snackbar_error, null);
            }

        });
    }

    private void showSnackBarMessage(String text, int color, View anchorView) {
        Snackbar.make(snagFloorPlanBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_SHORT)
                .setBackgroundTint(ContextCompat.getColor(requireContext(), color))
                .setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                .setAnchorView(anchorView)
                .show();
    }


    private void saveLatestSnapshot() {

        snagFloorPlanBinding.saveFeature.setOnClickListener(v -> {
            if (snagFloorPlanBinding.floorPlanPinView.isReady()) {
                // Disable views
                toggleViewsVisibility(false);

                // Zoom out
                snagFloorPlanBinding.floorPlanPinView.resetScaleAndCenter();

                List<Coordinates> transformedCoordinatesList = new ArrayList<>();
                snagFloorPlanBinding.floorPlanPinView.getPinCoordinates().stream().forEach(coordinates ->
                        transformedCoordinatesList.add(new Coordinates(coordinates.getX(), (floorPlanOrigHeight - coordinates.getY()))));

                SnagMediaFloorPlan floorPlan = SnagUtils.populateFloorPlanFeatures(selectedSnag, transformedCoordinatesList);
                floorPlan.setLatestSnapshotBitMap(captureScreenShotOfTheView());
                selectedSnag.setFloorPlan(floorPlan);

                if (!isCreateSnagFragment) {
                    snagListItemModel.saveSnagFloorPlanFeatures(selectedSnag);
                } else {
                    snagViewModel.setCreateSnagFloorPlanSaved(selectedSnag);
                    showSnackBarMessage("Floor Plan saved successfully", R.color.snackbar_success, null);
                    // Enable views
                    toggleViewsVisibility(true);
                }
            }

        });
    }

    private void toggleViewsVisibility(boolean visible) {
        int visibility = visible ? View.VISIBLE : View.GONE;
        snagFloorPlanBinding.floorPlanPinView.setVisibility(visibility);
        snagFloorPlanBinding.saveFeature.setVisibility(visibility);
        snagFloorPlanBinding.loadingImage.setVisibility(!visible ? View.VISIBLE : View.GONE);
    }

    private Bitmap captureScreenShotOfTheView() {
        Bitmap bitmap = Bitmap.createBitmap(snagFloorPlanBinding.floorPlanPinView.getWidth(),
                snagFloorPlanBinding.floorPlanPinView.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        snagFloorPlanBinding.floorPlanPinView.draw(canvas);
        return bitmap;
    }

    private void observeFloorPlanToken() {

        snagListItemModel.getSnagMediaResultMutableLiveData().observe(getViewLifecycleOwner(), snagMediaResult -> {
            if (getViewLifecycleOwner().getLifecycle().getCurrentState() == Lifecycle.State.RESUMED) {
                if (snagMediaResult.getSuccess() != null) {
                    snagFloorPlanBinding.loadingImage.setVisibility(View.GONE);
                    AzureToken azureToken = snagMediaResult.getSuccess().getAzureToken();
                    String imageUrl = azureToken.blobUrl(selectedSnag.getFloorPlan().getBlobReference(), CommonConstants.FLOOR_PLAN);
                    loadImage(imageUrl);
                }
                if (snagMediaResult.getError() != null) {
                    snagFloorPlanBinding.loadingImage.setVisibility(View.GONE);
                    Snackbar.make(snagFloorPlanBinding.getRoot(), R.string.loading_failed, BaseTransientBottomBar.LENGTH_LONG)
                            .setAction("RETRY", v -> snagListItemModel.fetchSnagMediaFloorPlanUrl())
                            .show();
                }
            }
        });
    }

    private void loadImage(String imageUrl) {
        // Load image using glide
        GlideApp.with(requireContext()).asBitmap()
                .load(new GlideUrlUtil(imageUrl))
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @org.jetbrains.annotations.Nullable Transition<? super Bitmap> transition) {
                        floorPlanOrigHeight = resource.getHeight();
                        floorPlanOrigWidth = resource.getWidth();
                        snagFloorPlanBinding.floorPlanPinView.setImage(ImageSource.bitmap(resource));
                        populatePointsOnFloorPlan();
                    }

                    @Override
                    public void onLoadCleared(@org.jetbrains.annotations.Nullable Drawable placeholder) {
                    }

                });


    }

    @SuppressLint("ClickableViewAccessibility")
    private void watchForGestureChanges() {

        GestureDetector gestureDetector = new GestureDetector(requireContext(),
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onSingleTapConfirmed(MotionEvent e) {
                        PinView imageView = snagFloorPlanBinding.floorPlanPinView;
                        if (imageView.isReady()) {
                            PointF screenCoordinates = imageView.viewToSourceCoord(e.getX(), e.getY());
                            if ((0 < screenCoordinates.x) && (screenCoordinates.x <= imageView.getSWidth()) &&
                                    (screenCoordinates.y <= imageView.getSHeight()) && (screenCoordinates.y > 0)) {
                                // setting image number to -1, so as to not show number on the marker
                                imageView.setPin(new SavedFloorPlanPin(screenCoordinates, -1, -1));
                            }

                        }
                        return true;
                    }

                    @Override
                    public boolean onDoubleTap(MotionEvent e) {
                        if (snagFloorPlanBinding.floorPlanPinView.isReady()) {
                            PointF screenCoordinates = snagFloorPlanBinding.floorPlanPinView.viewToSourceCoord(e.getX(), e.getY());
                            snagFloorPlanBinding.floorPlanPinView.removePin(screenCoordinates);
                        }
                        return true;
                    }

                });


        snagFloorPlanBinding.floorPlanPinView.setOnTouchListener((view, motionEvent) -> gestureDetector.onTouchEvent(motionEvent));

    }

    // Pre- populate points
    private void populatePointsOnFloorPlan() {
        if (selectedSnag.getFloorPlan().getFeature() != null) {
            selectedSnag.getFloorPlan().getFeature().getFeatures().stream().forEach(imageFeature -> {
                double xCoordinate = imageFeature.getGeometry().getCoordinates().get(0);
                double yCoordinate = floorPlanOrigHeight - imageFeature.getGeometry().getCoordinates().get(1);
                snagFloorPlanBinding.floorPlanPinView.populatePinCoordinates(new SavedFloorPlanPin(new PointF((float) xCoordinate, (float) yCoordinate), -1, -1));
            });
        }
    }

    @Override
    public void onSaveInstanceState(@NotNull Bundle outState) {
        View rootView = getView();
        if (rootView != null) {
            PinView imageView = rootView.findViewById(R.id.floor_plan_pin_view);
            ImageViewState state = imageView.getState();
            if (state != null) {
                outState.putSerializable(PIN_COORDINATES_ARRAY, imageView.getPinCoordinates());
                outState.putSerializable(SAVED_PIN_ARRAY, imageView.getsPin());
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        // Revert orientation and bottom nav changes
        requireActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        if(! isCreateSnagFragment) requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.VISIBLE);

        if (snagFloorPlanBinding != null) {
             snagFloorPlanBinding = null;
      }
    }
}