package com.huviair.capture.data.model.api.snags;

import java.io.Serializable;

public class SnagMasterDataResponse implements Serializable {
    private SnagMasterData master;

    public SnagMasterData getMaster() {
        return master;
    }
}
