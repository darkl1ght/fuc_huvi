package com.huviair.capture.data.repositories;

import android.app.Application;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.AerialAPIService;
import com.huviair.capture.data.model.api.aerial.AerialResponse;
import com.huviair.capture.data.model.api.aerial.TourStatus;
import com.huviair.capture.utils.SharedPreferencesManager;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class AerialRepository {

    private final AerialAPIService aerialAPIService;
//    private final APIService commonApiService;

    public AerialRepository(Application application) {
        aerialAPIService = APIClient.createService(AerialAPIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());
//
//        commonApiService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(),
//                new SharedPreferencesManager(application).getJwtToken());
    }

    public Single<AerialResponse> getAerialTourData(String projectId) {
        return aerialAPIService.getAerialTours(projectId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io());
    }

    public Single<TourStatus> getAerialTourCurrentStatus(String projectId, String tourId) {
        return aerialAPIService.getAerialTourStatus(projectId, tourId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io());
    }

}
