package com.huviair.capture.data.model.api.snags;

public class SnagStatistics {

    private Integer overallCount;

    private Integer myAssignedCount;

    private Integer overdueCount;

    private Integer openCount;

    private Integer onsiteCount;

    public Integer getOverallCount() {
        return overallCount;
    }

    public void setOverallCount(Integer overallCount) {
        this.overallCount = overallCount;
    }

    public Integer getMyAssignedCount() {
        return myAssignedCount;
    }

    public void setMyAssignedCount(Integer myAssignedCount) {
        this.myAssignedCount = myAssignedCount;
    }

    public Integer getOverdueCount() {
        return overdueCount;
    }

    public void setOverdueCount(Integer overdueCount) {
        this.overdueCount = overdueCount;
    }

    public Integer getOpenCount() {
        return openCount;
    }

    public void setOpenCount(Integer openCount) {
        this.openCount = openCount;
    }

    public Integer getOnsiteCount() {
        return onsiteCount;
    }

    public void setOnsiteCount(Integer onsiteCount) {
        this.onsiteCount = onsiteCount;
    }
}