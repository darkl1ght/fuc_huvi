package com.huviair.capture.ui.snags.snagcreatedraft;

import java.io.Serializable;
import java.util.List;

public class CreateDraftSnagMediaDetails implements Serializable {

    private Integer position;
    private List<String> media;

    public CreateDraftSnagMediaDetails(Integer position, List<String> media) {
        this.position = position;
        this.media = media;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public List<String> getMedia() {
        return media;
    }

    public void setMedia(List<String> media) {
        this.media = media;
    }
}
