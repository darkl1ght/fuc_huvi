package com.huviair.capture.data.model.api.tours.interiorsResponse;

import com.huviair.capture.data.model.api.tours.Tour;

import java.io.Serializable;
import java.util.List;

public class FloorWalkThrough implements Serializable {
    private String towerId;
    private String towerName;
    private final String interiorId;
    private List<Tour> tours;

    public FloorWalkThrough(String towerId, String towerName, String interiorId) {
        this.towerId = towerId;
        this.towerName = towerName;
        this.interiorId = interiorId;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public String getTowerId() {
        return towerId;
    }

    public void setTowerId(String towerId) {
        this.towerId = towerId;
    }

    public String getTowerName() {
        return towerName;
    }

    public void setTowerName(String towerName) {
        this.towerName = towerName;
    }

    public List<Tour> getTours() {
        return tours;
    }

    public void setTours(List<Tour> tours) {
        this.tours = tours;
    }

    @Override
    public String toString() {
        return "FloorWalkThroughCacheData{" +
                "towerId='" + towerId + '\'' +
                ", towerName='" + towerName + '\'' +
                ", tours=" + tours +
                '}';
    }
}
