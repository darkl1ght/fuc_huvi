package com.huviair.capture.api;

import com.huviair.capture.data.model.api.snags.ApproverDetails;
import com.huviair.capture.data.model.api.snags.CreateSnagRequest;
import com.huviair.capture.data.model.api.snags.CreateOnsiteSnagRequest;
import com.huviair.capture.data.model.api.snags.PunchListIdResponse;
import com.huviair.capture.data.model.api.snags.SavedSnagResponse;
import com.huviair.capture.data.model.api.snags.SnagConfig;
import com.huviair.capture.data.model.api.snags.SnagDashboardDetails;
import com.huviair.capture.data.model.api.snags.SnagListViewResponse;
import com.huviair.capture.data.model.api.snags.SnagMasterDataResponse;
import com.huviair.capture.data.model.api.snags.SnagMedia;
import com.huviair.capture.data.model.api.snags.SnagMediaFloorPlan;
import com.huviair.capture.data.model.api.snags.SnagsMediaDeleteResponse;
import com.huviair.capture.data.model.api.snags.SnagsMediaResponse;

import java.util.List;
import java.util.Map;

import io.reactivex.Completable;
import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Interface provides different API functionality for interacting with the Node.js backend
 */

public interface SnagsAPIService {

    @GET("api/punchlist/{project_id}/dashboard/snagstatistics")
    Single<SnagDashboardDetails> getSnagDashboardDetails(@Path("project_id") String projectId);

    @POST("api/punchlist/{project_id}/paginate/{query_type}")
    Single<SnagListViewResponse> getSnagDetailsByQueryType(@Path("project_id") String projectId,
                                                           @Path("query_type") String queryType, @Body SnagConfig config,
                                                           @Query("page") int pageNumber);

    @PUT("api/punchlist/{project_id}/punchitem/resolve/{level_type}/{task_id}")
    Single<SavedSnagResponse> saveSnagLevelStatus(@Path("project_id") String projectId, @Path("level_type") String levelType,
                                                  @Path("task_id") String taskId,
                                                  @Body Map<String, ApproverDetails> approverDetails);

    @PUT("api/punchlist/{project_id}/punchitem/floorplan/{task_id}")
    Completable saveSnagFloorPlanFeatures(@Path("project_id") String projectId, @Path("task_id") String taskId,
                                          @Body Map<String, SnagMediaFloorPlan> floorPlan);

    @PUT("api/punchlist/{project_id}/punchitem/{task_id}/bulkdeletemedia")
    Single<SnagsMediaDeleteResponse> deleteSnagMedia(@Path("project_id") String projectId, @Path("task_id") String taskId,
                                                     @Body Map<String, List<String>> mediaIdsToDelete);

    @PUT("api/punchlist/{project_id}/punchitem/media/{task_id}")
    Single<SnagsMediaResponse> uploadSnagMediaToBackend(@Path("project_id") String projectId, @Path("task_id") String taskId,
                                                        @Body Map<String, SnagMedia> mediaToUpload);


    @DELETE("api/punchlist/{project_id}/punchitem/{task_id}")
    Completable deleteSnag(@Path("project_id") String projectId, @Path("task_id") String taskId);

    @POST("api/punchlist/{project_id}/bulk")
    Completable createSnag(@Path("project_id") String projectId, @Body CreateSnagRequest createSnagRequest);

    @GET("api/masterdata/{project_id}")
    Single<SnagMasterDataResponse> getSnagMasterDataForProject(@Path("project_id") String projectId);


    @PUT("api/punchlist/{project_id}/punchitem/{task_id}")
    Completable updateSnagDetails(@Path("project_id") String projectId, @Path("task_id") String taskId,
                                  @Body SavedSnagResponse snag);

    @GET("api/punchlist/{project_id}/lookup/punchlist")
    Single<PunchListIdResponse> getPunchIdsForTheProject(@Path("project_id") String projectId);

    @POST("api/punchlist/{project_id}/onsiteTask")
    Completable createOnsiteSnag(@Path("project_id") String projectId, @Body CreateOnsiteSnagRequest createOnsiteSnagRequest);
}
