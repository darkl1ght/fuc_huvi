package com.huviair.capture.data.model.api.tours;

import com.huviair.capture.data.model.api.tours.Tour;

import java.util.List;

public class ToursResponse {

    private List<Tour> tours;

    public List<Tour> getTours() {
        return tours;
    }

    public void setTours(List<Tour> tours) {
        this.tours = tours;
    }
}
