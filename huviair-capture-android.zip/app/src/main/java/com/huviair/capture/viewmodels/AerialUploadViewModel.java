package com.huviair.capture.viewmodels;

import android.app.Application;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import com.huviair.capture.data.model.api.aerial.AerialResponse;
import com.huviair.capture.data.model.api.aerial.AerialTour;
import com.huviair.capture.data.model.api.aerial.TourStatus;
import com.huviair.capture.data.model.database.AerialUploadTourDetails;
import com.huviair.capture.data.repositories.AerialRepository;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.NetworkListener;
import com.huviair.capture.utils.SingleLiveEvent;
import com.huviair.capture.workers.UploadAerialImagesWorker;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;

public class AerialUploadViewModel extends AndroidViewModel {
    public final SingleLiveEvent<Boolean> isWorkBeingProcessed = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isLoadingDataFromAPI = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isErrorInLoading = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isDataConnectionAvailable = new SingleLiveEvent<>();
    private final AerialRepository aerialRepository;

    // WorkManager - Information
    private final WorkManager aerialImageUploadWorkManager;
    private final LiveData<List<WorkInfo>> workInfo;
    private final CompositeDisposable bag = new CompositeDisposable();

    // File picker related fields
    private final MutableLiveData<List<String>> selectedFiles = new MutableLiveData<>();
    private final SingleLiveEvent<AerialResponse> aerialResponseEvent = new SingleLiveEvent<>();
    private final MutableLiveData<String> selectedAerialTourId = new MutableLiveData<>();
    private final MutableLiveData<String> selectedAerialTourName = new MutableLiveData<>();
    private final SingleLiveEvent<TourStatus> currentTourStatus = new SingleLiveEvent<>();
    private final DataCaptureRoomDatabase database;


    public AerialUploadViewModel(@NonNull Application application) {
        super(application);
        aerialRepository = new AerialRepository(application);
        aerialImageUploadWorkManager = WorkManager.getInstance(application);
        database = DataCaptureRoomDatabase.getDatabase(application);
        workInfo = aerialImageUploadWorkManager.getWorkInfosByTagLiveData(CommonConstants.AERIAL_UPLOAD_WORK_TAG);
    }

    public void fetchAerialToursForProject(String projectId) {
        isLoadingDataFromAPI.setValue(true);

        bag.add(
                NetworkListener.hasInternetConnection(getApplication())
                        .subscribe(hasInternetConnection -> {
                            if (hasInternetConnection) {
                                bag.add(aerialRepository.getAerialTourData(projectId)
                                        .subscribe(aerialResponse -> {
                                                    isLoadingDataFromAPI.setValue(false);
                                                    if (aerialResponse.getTours().size() > 0) {
                                                        List<AerialTour> filteredList = aerialResponse.getTours().stream().filter(aerialTour -> CommonConstants.WAITING_FOR_IMAGE_UPLOAD.equals(aerialTour.getTourStatus().getCode()))
                                                                .collect(Collectors.toList());
                                                        aerialResponse.setTours(filteredList);
                                                    }
                                                    aerialResponseEvent.setValue(aerialResponse);
                                                },
                                                throwable -> {
                                                    isLoadingDataFromAPI.setValue(false);
                                                    isErrorInLoading.setValue(true);
                                                }

                                        ));
                            } else {
                                isDataConnectionAvailable.setValue(false);
                            }

                        }));

    }

    public SingleLiveEvent<AerialResponse> getAerialResponseEvent() {
        return aerialResponseEvent;
    }

    public MutableLiveData<List<String>> getSelectedFiles() {
        return selectedFiles;
    }

    public void addSelectedFiles(Uri uriToAdd) {
        if (selectedFiles.getValue() == null) {
            List<String> uriList = new ArrayList<>();
            uriList.add(uriToAdd.toString());
            selectedFiles.setValue(uriList);
        } else {
            List<String> existingList = selectedFiles.getValue();
            existingList.add(uriToAdd.toString());
            selectedFiles.setValue(existingList);
        }
    }

    public void clearSelectedFiles() {
        if (selectedFiles.getValue() != null && !selectedFiles.getValue().isEmpty()) {
            selectedFiles.setValue(null);
        }
    }

    public void startUploadImagesWork(String projectId) {
        // Should be connected to the network
        if (this.selectedAerialTourId.getValue() != null && this.selectedAerialTourName.getValue() != null) {

            Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();

            String[] selectedFileStrings = selectedFiles.getValue().toArray(new String[selectedFiles.getValue().size()]);

            Observable.fromArray(selectedFileStrings)
                    .flatMap(path -> database.aerialTourDetailsDAO().insertTour(new AerialUploadTourDetails(path, projectId
                            , this.selectedAerialTourId.getValue(), this.selectedAerialTourName.getValue(), false)).toObservable()).subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new DisposableObserver<Long>() {
                                   @Override
                                   public void onNext(@io.reactivex.annotations.NonNull Long aLong) {

                                   }

                                   @Override
                                   public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                                       Log.d("Error", e.getMessage());
                                   }

                                   @Override
                                   public void onComplete() {
                                       OneTimeWorkRequest oneTimeWorkRequest = new OneTimeWorkRequest.Builder(UploadAerialImagesWorker.class)
                                               .setInputData(createInputDataForUri(projectId, selectedAerialTourId.getValue(), selectedAerialTourName.getValue()))
                                               .addTag(CommonConstants.AERIAL_UPLOAD_WORK_TAG)
                                               .setConstraints(constraints)
                                               .build();

                                       isWorkBeingProcessed.setValue(true);

                                       // Enqueue unique work
                                       aerialImageUploadWorkManager.enqueueUniqueWork(selectedAerialTourId.getValue(), ExistingWorkPolicy.KEEP, oneTimeWorkRequest);

                                   }
                               }
                    );

        }
    }

    public void retryUploadWork(Data jobDetails) {
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();

        OneTimeWorkRequest oneTimeWorkRequest = new OneTimeWorkRequest.Builder(UploadAerialImagesWorker.class)
                .setInputData(jobDetails)
                .addTag(CommonConstants.AERIAL_UPLOAD_WORK_TAG)
                .setConstraints(constraints)
                .build();
        aerialImageUploadWorkManager.enqueueUniqueWork(jobDetails.getString(CommonConstants.INTERIOR_TOUR_ID), ExistingWorkPolicy.KEEP, oneTimeWorkRequest);
    }

    /**
     * Creates the input data bundle which includes the Uri to operate on
     *
     * @return Data which contains the Image Uri as a String
     */
    private Data createInputDataForUri(String projectId, String tourId, String tourName) {
        Data.Builder builder = new Data.Builder();
        builder.putString(CommonConstants.PROJECT_ID, projectId);
        builder.putString(CommonConstants.INTERIOR_TOUR_ID, tourId);
        builder.putString(CommonConstants.TOUR_NAME, tourName);

        return builder.build();
    }

    public LiveData<List<WorkInfo>> getWorkInfo() {
        return workInfo;
    }

    public void setSelectedAerialTourId(String tourId) {
        this.selectedAerialTourId.setValue(tourId);
    }

    public void setSelectedAerialTourName(String tourName) {
        this.selectedAerialTourName.setValue(tourName);
    }

    public SingleLiveEvent<TourStatus> getCurrentTourStatus() {
        return currentTourStatus;
    }


    public void startProcessingData(String projectId) {
        isLoadingDataFromAPI.setValue(true);
        bag.add(aerialRepository.getAerialTourCurrentStatus(projectId, selectedAerialTourId.getValue())
                .doAfterSuccess(tourStatus -> {
                    currentTourStatus.setValue(tourStatus);
                    isLoadingDataFromAPI.setValue(false);
                    isErrorInLoading.setValue(false);
                })
                .doOnError(throwable -> {
                    isErrorInLoading.setValue(true);
                    isLoadingDataFromAPI.setValue(false);
                })
                .subscribe((tourStatus, throwable) -> {
                }));
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (!bag.isDisposed()) bag.dispose();
    }


}