package com.huviair.capture.data.model.api.tours;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ImageFeature implements Serializable {
    private String type;
    private final Double id;
    private Properties properties;
    private final Geometry geometry;

    public ImageFeature(Image image, Double xCoordinate, Double yCoordinate) {
        this.type = "Feature";
        this.properties = new Properties(image.getImageId(), image.getImageName());
        this.geometry = new Geometry("Point", populateCoordinates(xCoordinate, yCoordinate));
        this.id = Math.random();
    }

    public ImageFeature(Image image, int imageNumber, Double xCoordinate, Double yCoordinate) {
        this.type = "Feature";
        this.properties = new Properties(image.getImageId(), image.getImageName(), imageNumber);
        this.geometry = new Geometry("Point", populateCoordinates(xCoordinate, yCoordinate));
        this.id = Math.random();
    }

    private List<Double> populateCoordinates(Double xCoordinate, Double yCoordinate) {
        List<Double> coordinatesList = new ArrayList<>();
        coordinatesList.add(xCoordinate);
        coordinatesList.add(yCoordinate);
        return coordinatesList;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Properties getProperties() {
        return properties;
    }

    public Geometry getGeometry() {
        return geometry;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImageFeature that = (ImageFeature) o;
        return Objects.equals(type, that.type) &&
                Objects.equals(id, that.id) &&
                Objects.equals(properties, that.properties) &&
                Objects.equals(geometry, that.geometry);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, id, properties, geometry);
    }

    @Override
    public String toString() {
        return "ImageFeature{" +
                "type='" + type + '\'' +
                ", id=" + id +
                ", properties=" + properties +
                ", geometry=" + geometry +
                '}';
    }
}

