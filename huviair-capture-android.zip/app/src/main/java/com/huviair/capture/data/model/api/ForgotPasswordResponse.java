package com.huviair.capture.data.model.api;

import com.google.gson.annotations.Expose;

public class ForgotPasswordResponse {
    @Expose
    String status;

    public ForgotPasswordResponse(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
