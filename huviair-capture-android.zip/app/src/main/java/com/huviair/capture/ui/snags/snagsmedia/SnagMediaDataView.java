package com.huviair.capture.ui.snags.snagsmedia;

import com.huviair.capture.data.model.api.azure.AzureToken;
import com.huviair.capture.data.model.api.tours.Feature;

public class SnagMediaDataView {
    private AzureToken azureToken;
    private Feature feature;

    public SnagMediaDataView(AzureToken azureToken) {
        this.azureToken = azureToken;
    }

    public SnagMediaDataView(Feature feature) {
        this.feature = feature;
    }

    public AzureToken getAzureToken() {
        return azureToken;
    }

    public Feature getFeature() {
        return feature;
    }
}
