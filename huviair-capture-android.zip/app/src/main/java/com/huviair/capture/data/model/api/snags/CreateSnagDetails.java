package com.huviair.capture.data.model.api.snags;

import com.huviair.capture.data.model.api.tours.Feature;
import com.huviair.capture.utils.CommonConstants;

import java.util.List;

public class CreateSnagDetails {
    private String workPackageId;
    private String dueDate;
    private String[] locations;
    private SnagItem[] punchItems;
    private String punchListId;

    private String[] stage1Approver;
    private String[] stage2Approver;

    public void setStage1Approver(String[] stage1Approvers) {
        this.stage1Approver = stage1Approvers;
    }

    public void setStage2Approver(String[] stage2Approvers) {
        this.stage2Approver = stage2Approvers;
    }

    public SnagItem[] getPunchItems() {
        return punchItems;
    }

    public CreateSnagDetails builder(String description, String remarks, String workPackageId, String dueDate, String[] locations, List<SnagMedia> mediaList
            , Feature features, String punchListId) {
        this.workPackageId = workPackageId;
        this.dueDate = dueDate;
        this.locations = locations;
        this.punchListId = punchListId;

        // Create Snag item
        SnagItem snagItem = new SnagItem(description, remarks,
                new TaskPriority(CommonConstants.TASK_PRIORITY_MEDIUM, "Medium"), mediaList, features, punchListId);

        this.punchItems = new SnagItem[]{snagItem};

        return this;
    }


    public class SnagItem {
        private final String taskDescription;
        private final String remark;
        private final boolean isNonConformity = true;
        private final TaskPriority taskPriority;
        private final List<SnagMedia> mediaList;
        private final Feature features;
        private String latestSnapshotBlobId;
        private final String punchListId;

        public SnagItem(String taskDescription, String remark, TaskPriority taskPriority, List<SnagMedia> mediaList, Feature features, String punchListId) {
            this.taskDescription = taskDescription;
            this.remark = remark;
            this.taskPriority = taskPriority;
            this.mediaList = mediaList;
            this.features = features;
            this.punchListId = punchListId;
        }

        public void setSnapshotBlobId(String snapshotBlobId) {
            this.latestSnapshotBlobId = snapshotBlobId;
        }

        public String getSnapshotBlobId() {
            return latestSnapshotBlobId;
        }

        public Feature getFeatures() {
            return features;
        }
    }

}


