package com.huviair.capture.data.model.api;

import java.io.Serializable;

public class Notification implements Serializable {
    private String token;
    private String deviceId;

    public Notification(String token, String deviceId){
        this.deviceId = deviceId;
        this.token = token;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
