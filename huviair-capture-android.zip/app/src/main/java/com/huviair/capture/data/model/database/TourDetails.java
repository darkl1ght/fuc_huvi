package com.huviair.capture.data.model.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.Arrays;

@Entity(tableName = "TOUR_WALK_THROUGH_DETAILS")
public class TourDetails {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "IMAGE_URL")
    private String imageUrl;
    @ColumnInfo(name = "TOUR_ID")
    private String tourId;
    @ColumnInfo(name = "INTERIOR_ID")
    private String interiorId;
    @ColumnInfo(name = "IS_WALK_THROUGH_UPLOADED")
    private boolean isWalkThroughUploaded = false;
    @ColumnInfo(name = "IS_UPLOADED_TO_API")
    private boolean isUploadedToAPI = false;
    @ColumnInfo(name = "X_COORDINATE")
    private double xCoordinate;
    @ColumnInfo(name = "Y_COORDINATE")
    private double yCoordinate;
    @ColumnInfo(name = "HDR_STITCH_FILE_NAME")
    private String hdrImageFileName;
    @ColumnInfo(name = "HDR_EXPORT_FILE_NAME")
    private String hdrExportFileName;
    @ColumnInfo(name = "TOUR_LAST_PUBLISHED_DATE")
    private String lastPublishedDate;
    @ColumnInfo(name = "IMAGE_NUMBER")
    private Integer imageNumber;
    @ColumnInfo(name = "OFFSET_FROM_NORTH")
    private double offsetFromNorth;
    @ColumnInfo(name = "STITCH_IMAGE_EVENT_ID")
    private int stitchEventId;
    @Ignore
    private String[] imageUrlsSplit;

    @Ignore
    public TourDetails() {

    }

    public TourDetails(int id, String imageUrl, String tourId, String interiorId,
                       boolean isWalkThroughUploaded, double xCoordinate, double yCoordinate,
                       String hdrImageFileName, boolean isUploadedToAPI, String hdrExportFileName, int imageNumber,
                       double offsetFromNorth) {
        this.id = id;
        this.hdrImageFileName = hdrImageFileName;
        this.imageUrl = imageUrl;
        this.tourId = tourId;
        this.interiorId = interiorId;
        this.isWalkThroughUploaded = isWalkThroughUploaded;
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        this.isUploadedToAPI = isUploadedToAPI;
        this.hdrExportFileName = hdrExportFileName;
        this.imageNumber = imageNumber;
        this.offsetFromNorth = offsetFromNorth;
    }


    @Ignore
    public TourDetails(String imageUrl, String tourId, String interiorId, boolean isWalkThroughUploaded, double xCoordinate, double yCoordinate, String hdrImageFileName,
                       double offsetFromNorth) {
        this.imageUrl = imageUrl;
        this.tourId = tourId;
        this.interiorId = interiorId;
        this.isWalkThroughUploaded = isWalkThroughUploaded;
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        this.hdrImageFileName = hdrImageFileName;
        this.offsetFromNorth = offsetFromNorth;
    }

    public Integer getImageNumber() {
        return imageNumber;
    }

    public void setImageNumber(Integer imageNumber) {
        this.imageNumber = imageNumber;
    }

    public int getId() {
        return id;
    }

    public int getStitchEventId() {
        return stitchEventId;
    }

    public String getLastPublishedDate() {
        return lastPublishedDate;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getTourId() {
        return tourId;
    }

    public double getOffsetFromNorth() {
        return offsetFromNorth;
    }

    public double getXCoordinate() {
        return xCoordinate;
    }

    public double getYCoordinate() {
        return yCoordinate;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public boolean isUploadedToAPI() {
        return isUploadedToAPI;
    }

    public boolean isWalkThroughUploaded() {
        return isWalkThroughUploaded;
    }

    public void setWalkThroughUploaded(boolean walkThroughUploaded) {
        isWalkThroughUploaded = walkThroughUploaded;
    }

    public void setStitchEventId(int stitchEventId) {
        this.stitchEventId = stitchEventId;
    }

    public String getHdrExportFileName() {
        return hdrExportFileName;
    }

    public void setHdrExportFileName(String hdrExportFileName) {
        this.hdrExportFileName = hdrExportFileName;
    }

    public String[] getImageUrlsSplit() {
        return imageUrlsSplit;
    }

    public void setImageUrlsSplit(String[] imageUrlsSplit) {
        this.imageUrlsSplit = imageUrlsSplit;
    }

    public String getHdrImageFileName() {
        return hdrImageFileName;
    }

    public void setLastPublishedDate(String lastPublishedDate) {
        this.lastPublishedDate = lastPublishedDate;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    @Override
    public String toString() {
        return "TourDetails{" +
                "id=" + id +
                ", imageUrl='" + imageUrl + '\'' +
                ", tourId='" + tourId + '\'' +
                ", interiorId='" + interiorId + '\'' +
                ", isWalkThroughUploaded=" + isWalkThroughUploaded +
                ", isUploadedToAPI=" + isUploadedToAPI +
                ", xCoordinate=" + xCoordinate +
                ", yCoordinate=" + yCoordinate +
                ", hdrImageFileName='" + hdrImageFileName + '\'' +
                ", imageUrlsSplit=" + Arrays.toString(imageUrlsSplit) +
                '}';
    }
}
