package com.huviair.capture.utils;

import androidx.annotation.Keep;

import java.util.Arrays;
import java.util.List;

@Keep
public class CommonConstants {

    public static final String FLOOR_PLAN = "floor-plan";
    public static final String DATABASE_NAME = "data_capture_database";
    public static final String HDR_IMPORTED_IMAGES_FOLDER = "HUVIAIR_360/HDR_IMPORTED_IMAGES";
    public static final String HDR_STITCHED_IMAGES_FOLDER = "HUVIAIR_360/HDR_GENERATED_IMAGES";
    public static final String COMPLETED_IMAGES_FOLDER = "HUVIAIR_360/COMPLETED_IMAGES";
    public static final String VIDEO_CAPTURE_VIDEOS_FOLDER = "HUVIAIR_360/VIDEO_CAPTURES";


    public static final String VIRTUAL_TOUR = "virtualtour";
    public static final String MEDIA = "media";
    public static final String AERIAL_TOUR = "aerialtour";
    public static final String TYPE_IMAGE_CODE = "MT10001";
    public static final String IMAGE_DESCRIPTION = "Image";

    public static final String TYPE_VIDEO_CODE = "MT10002";
    public static final String TYPE_360_VIDEO_CODE = "MT10004";
    public static final String VIDEO_DESCRIPTION = "Video";
    public static final String MONGO_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String DATE_PICKER_FORMAT = "dd-MM-yyyy";

    // Dashboard - Snag
    public static final String SNAG_ALL_ITEMS = "All Items";
    public static final String SNAG_OPEN_ITEMS = "Open Items";
    public static final String SNAG_MY_ASSIGNED_ITEMS = "My Assigned";
    public static final String SNAG_OVERDUE_ITEMS = "Overdue";

    public static final String SNAG_DRAFT_ITEMS = "Onsite Snags";

    // Task statuses
    public static final String TASK_STATUS_PENDING_VERIFICATION = "TS10001";
    public static final String TASK_STATUS_ACCEPTED = "TS10002";
    public static final String TASK_STATUS_NOT_ACCEPTED = "TS10003";
    public static final String TASK_STATUS_CONDITIONALLY_ACCEPTED = "TS10004";

    // Verification Status
    public static final String VERIFICATION_STATUS_PENDING = "VS10001";
    public static final String VERIFICATION_STATUS_ACCEPTED = "VS10002";
    public static final String VERIFICATION_STATUS_NOT_ACCEPTED = "VS10003";
    public static final String VERIFICATION_STATUS_CONDITIONALLY_ACCEPTED = "VS10004";
    public static final String LOOKUP_TYPE_VERIFICATION_STATUS = "verificationStatus";

    public static final List<String> VERIFICATION_STATUS_ACCEPTED_REJECTED = Arrays.asList(VERIFICATION_STATUS_ACCEPTED, VERIFICATION_STATUS_NOT_ACCEPTED);
    public static final List<String> VERIFICATION_STATUS_PENDING_ACCEPTED= Arrays.asList(VERIFICATION_STATUS_ACCEPTED, VERIFICATION_STATUS_PENDING);

    public static final String LOOKUP_TYPE_TASK_PRIORITY = "taskPriority";

    public static final String EMPTY_STRING = "";

    public static final String TASK_PRIORITY_LOW = "TP10001";
    public static final String TASK_PRIORITY_MEDIUM = "TP10002";
    public static final String TASK_PRIORITY_HIGH = "TP10003";


    public static final String PROJECT_ID = "PROJECT_ID";
    public static final String INTERIOR_TOUR_ID = "TOUR_ID";
    public static final String TOUR_NAME = "TOUR_NAME";
    public static final String TOWER_ID = "TOWER_ID";

    //    public static final String INSTA_SAVED_DIRECTORY_URL = "http://192.168.42.1:80/DCIM/Camera01";

    public static final CharSequence VERBOSE_NOTIFICATION_CHANNEL_NAME = "Verbose capture notifications";
    public static final String WAITING_FOR_IMAGE_UPLOAD = "AT10001";
    public static final String PROGRESS = "WORK_PROGRESS";
    public static final String WORK_COMPLETED_ON = "WORK_COMPLETED_ON";
    public static final String SUCCESS = "success";
    public static final int IMAGE_COMPRESSION_PERCENTAGE = 70;
    public static final String WALKTHROUGH_ID = "WALKTHROUGH_ID";
    public static final String TOWER_NAME = "TOWER_NAME";
    public static final String FLOOR_PLAN_DOWNLOAD_WORK = "FLOOR_PLAN_DOWNLOAD_WORK";
    public static final String COMPRESS_PUBLISH_IMAGE_WORKER = "COMPRESS_PUBLISH_IMAGE_WORKER";
    public static final String GENERATE_HDR_WORKER = "GENERATE_HDR_WORKER";
    public static final String EXPORT_HDR_WORKER = "EXPORT_HDR_WORKER" ;


    public static String VERBOSE_NOTIFICATION_CHANNEL_DESCRIPTION = "Shows notifications whenever work starts";
    public static final String AERIAL_WORK_NOTIFICATION_TITLE = "Capture - Aerial Data Upload";
    public static final String INTERIOR_DOWNLOAD_NOTIFICATION_TITLE = "Capture - Interiors Floor plans download";
    public static final String INTERIOR_WORK_NOTIFICATION_TITLE = "Capture - Interior data processing";
    public static final int NOTIFICATION_ID = 1;

    //Aerial constants
    public static final String AERIAL_UPLOAD_WORK_TAG = "AERIAL_UPLOAD_TAG";
    public static final String FAILURE_STATUS_CODE_NO_PARAMS = "10002";
    public static final String FAILURE_STATUS_CODE_IMAGES_COUNT = "10003";

    // Snag sections
    public static final String SNAG_STATUS_CREATED = "created";
    public static final String SNAG_STATUS_LEVEL1_UPDATED= "level1Updated";
    public static final String SNAG_STATUS_LEVEL2_UPDATED = "level2Updated";
}
