package com.huviair.capture.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;

import com.huviair.capture.data.model.api.lookups.LookupsResponse;
import com.huviair.capture.data.model.api.snags.SavedSnagResponse;
import com.huviair.capture.data.repositories.LookupsRepository;
import com.huviair.capture.data.repositories.SnagsRepository;
import com.huviair.capture.ui.snags.LookUpsResult;
import com.huviair.capture.ui.snags.LookupDataView;
import com.huviair.capture.utils.SingleLiveEvent;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableCompletableObserver;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class UpdateSnagViewModel extends AndroidViewModel {
    private final SnagsRepository snagsRepository;
    private final LookupsRepository lookupsRepository;

    private final SingleLiveEvent<Boolean> isUploading = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isUpdateCompleted = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isUpdateError = new SingleLiveEvent<>();

    private final SingleLiveEvent<LookUpsResult> lookups = new SingleLiveEvent<>();


    public UpdateSnagViewModel(Application application) {
        super(application);
        snagsRepository = new SnagsRepository(application);
        lookupsRepository = new LookupsRepository(application);
    }

    public SingleLiveEvent<LookUpsResult> getLookups() {
        return lookups;
    }


    public void fetchLookUps(String type) {
        lookupsRepository.getLookupsByType(type)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<LookupsResponse>() {
                    @Override
                    public void onSuccess(@NonNull LookupsResponse lookupsResponse) {
                        lookups.setValue(new LookUpsResult(new LookupDataView(lookupsResponse.getLookups())));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {

                    }
                });
    }

    public void updateSnag(String projectId, String taskId, SavedSnagResponse snagResponse) {
        isUploading.setValue(true);
        snagsRepository.updateSnag(projectId, taskId, snagResponse)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableCompletableObserver() {
                    @Override
                    public void onComplete() {
                        isUploading.setValue(false);
                        isUpdateCompleted.setValue(true);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        isUploading.setValue(false);
                        isUpdateError.setValue(true);
                    }
                });
    }

    public SingleLiveEvent<Boolean> getIsUpdateCompleted() {
        return isUpdateCompleted;
    }

    public SingleLiveEvent<Boolean> getIsUpdateError() {
        return isUpdateError;
    }

    public SingleLiveEvent<Boolean> getIsUploading() {
        return isUploading;
    }
}