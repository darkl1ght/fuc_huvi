package com.huviair.capture.data.model.api.snags;

public class PunchListIdResponse {
    private String[] punchListId;

    public String[] getPunchListId() {
        return punchListId;
    }

}
