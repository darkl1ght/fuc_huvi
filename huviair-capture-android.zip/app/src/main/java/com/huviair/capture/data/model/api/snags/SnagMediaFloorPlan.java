package com.huviair.capture.data.model.api.snags;

import android.graphics.Bitmap;

import com.google.gson.annotations.Expose;
import com.huviair.capture.data.model.api.tours.Feature;

import java.io.Serializable;
import java.util.Objects;

public class SnagMediaFloorPlan implements Serializable {
    private String blobReference;
    private final Feature features;
    private String latestSnapshotBlobId;

    @Expose(deserialize = false, serialize = false)
    private Bitmap latestSnapshotBitMap;

    public SnagMediaFloorPlan(String blobReference, Feature features) {
        this.blobReference = blobReference;
        this.features = features;
    }

    public String getBlobReference() {
        return blobReference;
    }

    public void setBlobReference(String blobReference) {
        this.blobReference = blobReference;
    }

    public Feature getFeature() {
        return features;
    }

    public Bitmap getLatestSnapshotBitMap() {
        return latestSnapshotBitMap;
    }

    public void setLatestSnapshotBitMap(Bitmap latestSnapshotBitMap) {
        this.latestSnapshotBitMap = latestSnapshotBitMap;
    }

    public String getLatestSnapshotBlobId() {
        return latestSnapshotBlobId;
    }

    public void setLatestSnapshotBlobId(String latestSnapshotBlobId) {
        this.latestSnapshotBlobId = latestSnapshotBlobId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SnagMediaFloorPlan that = (SnagMediaFloorPlan) o;
        return Objects.equals(blobReference, that.blobReference) &&
                Objects.equals(features, that.features);
    }

    @Override
    public int hashCode() {
        return Objects.hash(blobReference, features);
    }
}

