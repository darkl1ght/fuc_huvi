package com.huviair.capture.data.model.api;

import com.huviair.capture.data.model.api.AuditLog;
import java.io.Serializable;
import java.util.List;

public class SendLogRequest  implements  Serializable{
    private List<AuditLog> logs;
    private String createdBy;

    public SendLogRequest(String userEmail, List<AuditLog> logs) {
        this.logs = logs;
        this.createdBy = createdBy;
    }


    public void setAuditLogRequest() {
        setAuditLogRequest(null, null);
    }

    public void setAuditLogRequest(List<AuditLog> logs, String createdBy) {
        this.logs = logs;
        this.createdBy = createdBy;
    }
}
