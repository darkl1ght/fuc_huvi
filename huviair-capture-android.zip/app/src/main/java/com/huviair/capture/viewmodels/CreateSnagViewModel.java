package com.huviair.capture.viewmodels;

import android.app.Application;
import android.graphics.Bitmap;
import android.os.Build;
import android.util.Log;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.snags.CreateOnsiteSnagRequest;
import com.huviair.capture.data.model.api.snags.CreateSnagRequest;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagMasterDataResponse;
import com.huviair.capture.data.model.api.snags.SnagMedia;
import com.huviair.capture.data.model.api.snags.WorkLocation;
import com.huviair.capture.data.repositories.ProjectsRepository;
import com.huviair.capture.data.repositories.SnagsRepository;
import com.huviair.capture.ui.common.MultiSelectViewItem;
import com.huviair.capture.ui.snags.snagcreate.CreateSnagFormState;
import com.huviair.capture.ui.snags.snagcreate.SnagResult;
import com.huviair.capture.ui.snags.snagcreatedraft.CreateDraftSnagFormState;
import com.huviair.capture.ui.snags.snagcreatedraft.DraftSnagResult;
import com.huviair.capture.ui.snags.snaglist.SnagDataView;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.utils.SingleLiveEvent;
import com.huviair.capture.utils.UriUtils;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.yanzhenjie.album.AlbumFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;

import id.zelory.compressor.Compressor;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableCompletableObserver;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class CreateSnagViewModel extends AndroidViewModel {
    private final SnagsRepository snagsRepository;
    private final ProjectsRepository projectsRepository;

    private final SingleLiveEvent<SnagResult> snagMasterDataMutableLiveData = new SingleLiveEvent<>();
    private final MutableLiveData<CreateSnagFormState> formState = new MutableLiveData<>();
    private final MutableLiveData<CreateDraftSnagFormState> draftFormState = new MutableLiveData<>();


    // Selected media details
    private final MutableLiveData<List<AlbumFile>> selectedMedia = new MutableLiveData<>(new ArrayList<>());
    private final List<SnagMedia> snagMediaList = new ArrayList<>();

    // State of snag creation
    private final SingleLiveEvent<Boolean> isSnagCreated = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isSnagCreationError = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isSnagCreationStarted = new SingleLiveEvent<>();

    public SingleLiveEvent<List<MultiSelectViewItem>> stage1MultiSelectItems = new SingleLiveEvent<>();
    public SingleLiveEvent<List<MultiSelectViewItem>> stage2MultiSelectItems = new SingleLiveEvent<>();
    public SingleLiveEvent<List<WorkLocation>> workLocations = new SingleLiveEvent<>();


    private Snag snagWithFloorPlanDetails;

    private Bitmap imageBitMap;


    public CreateSnagViewModel(Application application) {
        super(application);
        snagsRepository = new SnagsRepository(application);
        projectsRepository = new ProjectsRepository(application);
    }

    public SingleLiveEvent<Boolean> getIsSnagCreationStarted() {
        return isSnagCreationStarted;
    }

    public SingleLiveEvent<Boolean> getIsSnagCreated() {
        return isSnagCreated;
    }

    public SingleLiveEvent<Boolean> getIsSnagCreationError() {
        return isSnagCreationError;
    }

    public void getSnagsMasterData(String projectId) {
        snagsRepository.getSnagsMasterData(projectId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableSingleObserver<SnagMasterDataResponse>() {
                    @Override
                    public void onSuccess(@NonNull SnagMasterDataResponse snagMasterDataResponse) {
                        snagMasterDataMutableLiveData.setValue(new SnagResult(new SnagDataView(null, null, snagMasterDataResponse.getMaster())));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        snagMasterDataMutableLiveData.setValue(new SnagResult(R.string.technical_error));
                    }
                });
    }

    public SingleLiveEvent<SnagResult> getSnagMasterDataMutableLiveData() {
        return snagMasterDataMutableLiveData;
    }

    public MutableLiveData<CreateSnagFormState> getFormState() {
        return formState;
    }

    public MutableLiveData<CreateDraftSnagFormState> getDraftFormState() {
        return draftFormState;
    }

    // validate current form state
    public void formDataChanged(String description, String dueDate, String workTrade, String level) {
        CreateSnagFormState currentFormState = new CreateSnagFormState();
        if (description == null || CommonConstants.EMPTY_STRING.equals(description)) {
            currentFormState.setSnagDescriptionError(R.string.snag_description_vali);
            formState.setValue(currentFormState);
        } else if (dueDate == null || CommonConstants.EMPTY_STRING.equals(dueDate)) {
            currentFormState.setDueDateError(R.string.due_date_error);
            formState.setValue(currentFormState);
        } else if (workTrade == null || CommonConstants.EMPTY_STRING.equals(workTrade)) {
            currentFormState.setWorkTradeError(R.string.work_trade_val);
            formState.setValue(currentFormState);
        } else if (!isApproversSelected(true)) {
            currentFormState.setSelectStage1Error(R.string.stage_approver_error);
            formState.setValue(currentFormState);
        } else if (!isApproversSelected(false)) {
            currentFormState.setSelectStage2Error(R.string.stage_approver_error);
            formState.setValue(currentFormState);
        } else if (level == null || CommonConstants.EMPTY_STRING.equals(level) || isInvalidWorkLocation(level)) {
            currentFormState.setSelectLevelError(R.string.level_err);
            formState.setValue(currentFormState);
        } else {
            currentFormState.setDataValid(true);
            formState.setValue(currentFormState);
        }

    }

    public void draftFormDataChanged(String description, String workTrade, String level) {
        CreateDraftSnagFormState currentFormState = new CreateDraftSnagFormState();
        if (description == null || CommonConstants.EMPTY_STRING.equals(description)) {
            currentFormState.setSnagDescriptionError(R.string.snag_description_vali);
            draftFormState.setValue(currentFormState);
        }  else if (workTrade == null || CommonConstants.EMPTY_STRING.equals(workTrade)) {
            currentFormState.setWorkTradeError(R.string.work_trade_val);
            draftFormState.setValue(currentFormState);
        }  else if (level == null || CommonConstants.EMPTY_STRING.equals(level) || isInvalidWorkLocation(level)) {
            currentFormState.setSelectLevelError(R.string.level_err);
            draftFormState.setValue(currentFormState);
        } else {
            currentFormState.setDataValid(true);
            draftFormState.setValue(currentFormState);
        }

    }

    private boolean isInvalidWorkLocation(String level) {
        return workLocations.getValue().stream().noneMatch(workLocation -> level.equals(workLocation.getLocation()));
    }

    public LiveData<List<AlbumFile>> getSelectedImagesPaths() {
        return selectedMedia;
    }


    public void setImagePaths(List<AlbumFile> imagePaths) {
        this.selectedMedia.setValue(imagePaths);
    }

    public List<SnagMedia> getSnagMediaList() {
        return snagMediaList;
    }

    public void createSnag(String projectId, CreateSnagRequest createSnagRequest) {
        //post to UI
        isSnagCreationStarted.setValue(true);

        createSnagRequest.getPunchList().setStage1Approver(getSelectedApprovers(true));
        createSnagRequest.getPunchList().setStage2Approver(getSelectedApprovers(false));

        snagsRepository.getAzureWritePermissionToken().toObservable()
                .flatMap(azureTokenResponse -> {
                    String containerURI = azureTokenResponse.getSasToken() != null ? azureTokenResponse.getSasToken().getUri() : null;
                    CloudBlobContainer cloudBlobContainer = new CloudBlobContainer(URI.create(containerURI));
                    return (!isFloorPlanEdited() ? Observable.just(cloudBlobContainer) : uploadFloorPlanScreenshot(createSnagRequest, cloudBlobContainer).subscribeOn(Schedulers.newThread()));
                })
                .switchMap(mediaContainer -> Observable.fromIterable(selectedMedia.getValue())
                        .flatMap(albumFile -> uploadMediaToAzureBlob(albumFile, mediaContainer).
                                subscribeOn(Schedulers.from(Executors.newFixedThreadPool(10))), 5))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new DisposableObserver<SnagMedia>() {
                    @Override
                    public void onNext(@NonNull SnagMedia snagMedia) {
                        snagMediaList.add(snagMedia);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        e.printStackTrace();
                        isSnagCreationStarted.setValue(false);
                        isSnagCreationError.postValue(true);
                    }

                    @Override
                    public void onComplete() {
                        createSnagInTheBackend(projectId, createSnagRequest);
                    }
                });


    }

    public void createOnsiteSnag(String projectId, CreateOnsiteSnagRequest createSnagRequest) {
        //post to UI
        isSnagCreationStarted.setValue(true);


        snagsRepository.getAzureWritePermissionToken().toObservable()
                .flatMap(azureTokenResponse -> {
                    String containerURI = azureTokenResponse.getSasToken() != null ? azureTokenResponse.getSasToken().getUri() : null;
                    CloudBlobContainer cloudBlobContainer = new CloudBlobContainer(URI.create(containerURI));
                    return ( Observable.just(cloudBlobContainer));
                })
                .switchMap(mediaContainer -> Observable.fromIterable(selectedMedia.getValue())
                        .flatMap(albumFile -> uploadMediaToAzureBlob(albumFile, mediaContainer).
                                subscribeOn(Schedulers.from(Executors.newFixedThreadPool(10))), 5))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new DisposableObserver<SnagMedia>() {
                    @Override
                    public void onNext(@NonNull SnagMedia snagMedia) {
                        snagMediaList.add(snagMedia);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        e.printStackTrace();
                        isSnagCreationStarted.setValue(false);
                        isSnagCreationError.postValue(true);
                    }

                    @Override
                    public void onComplete() {
                        createOnsiteSnagInTheBackend(projectId, createSnagRequest);
                    }
                });


    }

    private void createSnagInTheBackend(String projectId, CreateSnagRequest createSnagRequest) {
        snagsRepository.createSnag(projectId, createSnagRequest).observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableCompletableObserver() {
                    @Override
                    public void onComplete() {
                        isSnagCreationStarted.setValue(false);
                        isSnagCreated.postValue(true);
                        snagMediaList.clear();
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        isSnagCreationStarted.setValue(false);
                        isSnagCreationError.postValue(true);
                    }
                });

    }

    private void createOnsiteSnagInTheBackend(String projectId, CreateOnsiteSnagRequest createSnagRequest) {
        snagsRepository.createOnsiteSnag(projectId, createSnagRequest).observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DisposableCompletableObserver() {
                    @Override
                    public void onComplete() {
                        isSnagCreationStarted.setValue(false);
                        isSnagCreated.postValue(true);
                        snagMediaList.clear();
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        isSnagCreationStarted.setValue(false);
                        isSnagCreationError.postValue(true);
                    }
                });

    }


    private Observable<SnagMedia> uploadMediaToAzureBlob(AlbumFile file, CloudBlobContainer azureBlobContainer) {
        return Observable.fromCallable(() -> {
            SnagMedia snagMedia = new SnagMedia();
            snagMedia.setMediaId(UUID.randomUUID().toString());
            snagMedia.setMediaCreateDate(DateFormatUtils.getCurrentDateInMongoFormat());
            String fileName = file.getPath().substring(file.getPath().lastIndexOf("/") + 1);
            String fileExtension="jpg";
            int index = fileName.lastIndexOf('.');
            if (index > 0) {
                String extension = fileName.substring(index + 1);
                fileExtension = extension.length() > 0 ? extension : fileExtension;
            } else{
                fileExtension = file.getPath().split("\\.")[1];
            }
            snagMedia.setFileName(fileName);
            snagMedia.setBlobReferenceId(snagMedia.getMediaId().concat(".").concat(fileExtension));

            // Upload to Blob
            CloudBlockBlob blob = azureBlobContainer.getBlockBlobReference(snagMedia.getBlobReferenceId());

            if (AlbumFile.TYPE_VIDEO != file.getMediaType()) {
                byte[] compressImageToBytes = UriUtils.compressImageToBytes(file.getPath(),
                        getImageBitMap() != null ? getImageBitMap() : null);
                blob.uploadFromByteArray(compressImageToBytes, 0, compressImageToBytes.length);
            } else{
                // Compress Image and get the path
                String compressedImagePath = new Compressor(getApplication()).compressToFile(new File(file.getPath())).getPath();
                blob.uploadFromFile(compressedImagePath);
            }
            return snagMedia;
        });

    }

    private Observable<CloudBlobContainer> uploadFloorPlanScreenshot(CreateSnagRequest createSnagRequest, CloudBlobContainer azureBlobContainer) {
        return Observable.fromCallable(() -> {
            Bitmap latestSnapshotBitMap = getSnagWithFloorPlanDetails().getFloorPlan().getLatestSnapshotBitMap();
            ByteArrayOutputStream outputStreamByteArray = new ByteArrayOutputStream();
            latestSnapshotBitMap.compress(Bitmap.CompressFormat.JPEG, CommonConstants.IMAGE_COMPRESSION_PERCENTAGE, outputStreamByteArray);

            String latestSnapshotBlobId = UUID.randomUUID().toString().concat(".png");
            CloudBlockBlob blob = azureBlobContainer.getBlockBlobReference(latestSnapshotBlobId);
            blob.uploadFromByteArray(outputStreamByteArray.toByteArray(),0, outputStreamByteArray.size());

            // Append the snapshot blob Id to the request after successful upload to blob
            createSnagRequest.getPunchList().getPunchItems()[0].setSnapshotBlobId(latestSnapshotBlobId);
            return azureBlobContainer;
        });

    }

    private boolean isFloorPlanEdited() {
        return getSnagWithFloorPlanDetails() != null && getSnagWithFloorPlanDetails().getFloorPlan() != null && getSnagWithFloorPlanDetails().getFloorPlan().getFeature() != null;
    }

    public Snag getSnagWithFloorPlanDetails() {
        return snagWithFloorPlanDetails;
    }

    public void setSnagWithFloorPlanDetails(Snag snagWithFloorPlanDetails) {
        this.snagWithFloorPlanDetails = snagWithFloorPlanDetails;
    }

    private boolean isApproversSelected(boolean isLevel1) {
        List<MultiSelectViewItem> multiSelectViewItems = isLevel1 ? stage1MultiSelectItems.getValue() : stage2MultiSelectItems.getValue();
        if (multiSelectViewItems != null && !multiSelectViewItems.isEmpty()) {
            return multiSelectViewItems.stream().anyMatch(MultiSelectViewItem::isSelected);
        }
        return false;
    }

    private String[] getSelectedApprovers(boolean isLevel1) {
        List<MultiSelectViewItem> multiSelectViewItems = isLevel1 ? stage1MultiSelectItems.getValue() : stage2MultiSelectItems.getValue();
        return multiSelectViewItems.stream().filter(MultiSelectViewItem::isSelected).map(MultiSelectViewItem::getContent).toArray(String[]::new);
    }

    public Bitmap getImageBitMap() {
        return imageBitMap;
    }


        public void setImageBitMap(Bitmap imageBitMap) {
        this.imageBitMap = imageBitMap;
    }

}