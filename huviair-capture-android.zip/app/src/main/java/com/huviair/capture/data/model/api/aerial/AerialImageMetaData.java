package com.huviair.capture.data.model.api.aerial;

public class AerialImageMetaData {
    private String dateTaken;
    private String fileName;
    private long fileSize;
    private double lat;
    private double lng;
    private double alt;
    private  String blobRef;
    private  String fileId;

    public AerialImageMetaData(String dateTaken, String fileName, long fileSize, double lat, double lng, String blobRef, String fileId, double alt) {
        this.dateTaken = dateTaken;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.lat = lat;
        this.lng = lng;
        this.blobRef = blobRef;
        this.fileId = fileId;
        this.alt = alt;
    }

    public AerialImageMetaData(){}

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getAlt() {
        return alt;
    }

    public void setAlt(double alt) {
        this.alt = alt;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public String getDateTaken() {
        return dateTaken;
    }

    public void setDateTaken(String dateTaken) {
        this.dateTaken = dateTaken;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public String getBlobRef() {
        return blobRef;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }
}
