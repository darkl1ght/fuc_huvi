package com.huviair.capture.ui.aerial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.projects.Project;
import com.huviair.capture.databinding.ActivityAerialBinding;
import com.huviair.capture.ui.media.ProjectMediaActivity;
import com.huviair.capture.ui.interiors.InteriorsActivity;
import com.huviair.capture.ui.snags.SnagActivity;

public class AerialActivity extends AppCompatActivity {

    private ActivityAerialBinding aerialViewBinding;
    public static final String SELECTED_PROJECT = "SELECTED_PROJECT";
    private Project selectedProject;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        aerialViewBinding = ActivityAerialBinding.inflate(getLayoutInflater());
        setContentView(aerialViewBinding.getRoot());

        if (getIntent().getExtras() != null) {
            selectedProject = (Project) getIntent().getSerializableExtra(SELECTED_PROJECT);
        }

        populateBottomNavigationView();

        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.aerial_upload_data_fragment, AerialLandingFragment.newInstance(selectedProject.getProjectId()), "Aerial Upload Fragment")
                    .commit();
        }


    }

    private void populateBottomNavigationView() {

        aerialViewBinding.bottomNavigationAerial.getRoot().setVisibility(View.VISIBLE);
        aerialViewBinding.bottomNavigationAerial.getRoot().setSelectedItemId(R.id.aerial);

        aerialViewBinding.bottomNavigationAerial.getRoot().setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.interiors) {
                Intent interiorIntent = new Intent(this, InteriorsActivity.class);
                interiorIntent.putExtra(InteriorsActivity.PROJECT, selectedProject);
                startActivity(interiorIntent);
                overridePendingTransition(0, 0);
                finish();

            // } else if (itemId == R.id.media) {
            //     Intent projectMediaIntent = new Intent(this, ProjectMediaActivity.class);
            //     projectMediaIntent.putExtra(ProjectMediaActivity.SELECTED_PROJECT, selectedProject);
            //     startActivity(projectMediaIntent);
            //     overridePendingTransition(0, 0);
            //     finish();
            } else if (itemId == R.id.snag) {
                Intent snagActivityIntent = new Intent(this, SnagActivity.class);
                snagActivityIntent.putExtra(ProjectMediaActivity.SELECTED_PROJECT, selectedProject);
                startActivity(snagActivityIntent);
                overridePendingTransition(0, 0);
                finish();
            }
            return true;
        });
    }
}