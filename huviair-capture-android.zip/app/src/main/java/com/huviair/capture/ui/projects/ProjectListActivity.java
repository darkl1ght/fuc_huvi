package com.huviair.capture.ui.projects;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.Task;
import com.huviair.capture.R;
import com.huviair.capture.adapters.ProjectsAdapter;
import com.huviair.capture.data.model.api.projects.Project;
import com.huviair.capture.databinding.ActivityProjectListBinding;
import com.huviair.capture.ui.interiors.InteriorsActivity;
import com.huviair.capture.ui.login.LoginActivity;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.viewmodels.ProjectsViewModel;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import io.reactivex.disposables.CompositeDisposable;

public class ProjectListActivity extends AppCompatActivity implements ProjectsAdapter.ProjectSelectedListener {
    private static final String TAG = "PROJECT_LIST_ACTIVITY";
    private static final int RESULT_CODE = 781;

    //region project list variables
    private final CompositeDisposable disposable = new CompositeDisposable();
    private final int STALENESS_DAYS = 10;
    private final int FLEXIBLE_UPDATE_HIDE_HOURS = 3;
    // Initialize view model, view binding, adapter
    private ProjectsAdapter projectsAdapter;
    private ActivityProjectListBinding projectListBinding;
    //endregion project list variables
    private ProjectsViewModel projectsViewModel;
    private Snackbar snackbar;

    //region In app update variables
    private AppUpdateManager appUpdateManager;
    private final InstallStateUpdatedListener listener = installState -> {
        if (installState.installStatus() == InstallStatus.DOWNLOADED)
            popupSnackbarForCompleteUpdate();
    };
    private Task<AppUpdateInfo> appUpdateInfoTask;
    private int currentAppUpdateType;
    //endregion in app update variables

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //region in-app update code
        this.appUpdateManager = AppUpdateManagerFactory.create(this);
        startAppUpdate();
        //endregion in-app update

        //region project list code
        projectListBinding = ActivityProjectListBinding.inflate(getLayoutInflater());
        setContentView(projectListBinding.getRoot());

        projectsViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(ProjectsViewModel.class);

        // Save firebase token in the background
        projectsViewModel.saveMessagingToken();

        MaterialToolbar toolbar = findViewById(R.id.tool_bar);
        toolbar.setTitle("Projects");
        setSupportActionBar(toolbar);


        // Asynchronously call the projects api to get the list of projects
        fetchProjects();

        observeProjectResult();

        swipeToRefresh();

        observeForInternetConnection();

        observeForSyncEvents();

        //endregion projectlist

        requestReview();
    }

    //region project list helpers
    private void observeForInternetConnection() {
        projectsViewModel.isNoDataConnection.observe(this, hasNoDataConnection -> Snackbar.make(findViewById(R.id.project_list_layout), "No Data Connection Available", Snackbar.LENGTH_LONG).show());
    }

    private void observeProjectResult() {
        projectsViewModel.getProjectLiveData().observe(this, projectResult -> {
            if (projectResult.getSuccess() != null) {
                if (projectResult.getSuccess().getProjects().isEmpty()) {
                    toggleProjectNotFound(true);
                    projectListBinding.loadingProjects.setVisibility(View.GONE);

                } else populateRecyclerView(projectResult.getSuccess().getProjects());
            }

            if (projectResult.getError() != null) {
                handleError();
            }
        });

        projectsViewModel.isMessagingTokenDeleted.observe(this, isDeleted -> {
            if (isDeleted) {
                boolean logout = new SharedPreferencesManager(this).logout();
                // Clear all database details on logout
                disposable.add(projectsViewModel.clearAllDatabaseDetails().subscribe(() -> {
                    if (logout) {
                        Intent loginIntent = new Intent(this, LoginActivity.class);
                        startActivity(loginIntent);
                        finishAffinity();
                    }

                }, Throwable::printStackTrace));

            }
        });
    }

    private void swipeToRefresh() {
        projectListBinding.refreshProjects.setOnRefreshListener(
                this::refreshProjects
        );
    }

    private void refreshProjects() {
        if (snackbar != null) snackbar.dismiss();

        // Disable views
        projectListBinding.recyclerProjectView.setVisibility(View.GONE);

        fetchProjects();

        projectListBinding.refreshProjects.setRefreshing(false); // Disables the refresh icon
    }

    private void observeForSyncEvents() {
        projectsViewModel.syncStatusLiveEvent.observe(this, dataSyncStatus -> {

            int visibility = dataSyncStatus.isDataSyncInProgress() ? View.VISIBLE : View.GONE;
            projectListBinding.loadingProjects.setVisibility(visibility);

            if (!dataSyncStatus.isDataSyncComplete()) {
                projectListBinding.dataSyncStatus.setText(dataSyncStatus.getCurrentStep());
            } else {
                projectListBinding.recyclerProjectView.setVisibility(View.VISIBLE);
                projectListBinding.dataSyncStatus.setText("");
            }

        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.project_list_icons, menu);
        MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        SearchView searchView = (SearchView) searchItem.getActionView();

        // Overriding the default text colors in search view
        EditText searchEditText = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        searchEditText.setTextAppearance(R.style.TextAppearance_Capture_Headline6);
        searchView.setVerticalGravity(Gravity.CENTER_VERTICAL);
        searchEditText.setTextColor(ContextCompat.getColor(this, R.color.design_default_color_on_primary));
        searchEditText.setHintTextColor(ContextCompat.getColor(this, R.color.design_default_color_on_primary));

        searchView.setQueryHint("Search Projects");
        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (projectsAdapter != null) {
                    projectsAdapter.getFilter().filter(newText);
                }
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@androidx.annotation.NonNull MenuItem item) {
        if (item.getItemId() == R.id.app_bar_logout) {
            // invoke delete token call
            projectsViewModel.deleteFCMTokenFromBackend();
            return true;
        }

        if (item.getItemId() == R.id.sync_now) {
            // Hide recycler view
            projectListBinding.recyclerProjectView.setVisibility(View.GONE);
            fetchProjects();
            return true;

        }
        if (item.getItemId() == R.id.send_logs) {
            projectListBinding.dataSyncStatus.setText("Sending Log data...");
            sendLogs();
            return true;

        }
        return super.onOptionsItemSelected(item);
    }

    private void sendLogs(){

        // show loading
        projectListBinding.loadingProjects.setVisibility(View.VISIBLE);

        //get logged in user email
        String userEmail = new SharedPreferencesManager(this).getLoggedInUserEmail();
        // Invoke API again
        projectsViewModel.sendLogToDatabase(userEmail);

        projectListBinding.dataSyncStatus.setText("");
        Snackbar.make(findViewById(R.id.project_list_layout),
                "Logs sent to support team successfully!", Snackbar.LENGTH_LONG).show();
        // Remove the loader
        projectListBinding.loadingProjects.setVisibility(View.GONE);

    }
    private void fetchProjects() {
        // Remove technical error and projectNot found images
        projectListBinding.technicalErrorView.getRoot().setVisibility(View.GONE);
        toggleProjectNotFound(false);

        // show loading
        projectListBinding.loadingProjects.setVisibility(View.VISIBLE);

        // Invoke API again
        projectsViewModel.fetchProjectsFromBackend();

    }

    private void populateRecyclerView(List<Project> projects) {
        projectListBinding.technicalErrorView.getRoot().setVisibility(View.GONE);
        // Remove the loader
        projectListBinding.loadingProjects.setVisibility(View.GONE);
        projectListBinding.recyclerProjectView.setVisibility(View.VISIBLE);

        projectsAdapter = new ProjectsAdapter(projects, this);
        projectListBinding.recyclerProjectView.setHasFixedSize(true);
        projectListBinding.recyclerProjectView.setAdapter(projectsAdapter);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        startLayoutAnimation();
        projectListBinding.recyclerProjectView.setLayoutManager(linearLayoutManager);

    }

    private void handleError() {
        projectListBinding.loadingProjects.setVisibility(View.GONE);
        projectListBinding.dataSyncStatus.setText("");
        projectListBinding.technicalErrorView.getRoot().setVisibility(View.VISIBLE);

        snackbar = Snackbar.make(findViewById(R.id.project_list_layout), "Unable to fetch projects due to bad connectivity", Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("RETRY", v -> fetchProjects()).
                setBackgroundTint(ContextCompat.getColor(this, R.color.snackbar_default)).show();
    }

    private void startLayoutAnimation() {
        LayoutAnimationController animationController =
                AnimationUtils.loadLayoutAnimation(projectListBinding.recyclerProjectView.
                        getContext(), R.anim.layout_animation_up_to_down);

        projectListBinding.recyclerProjectView.setLayoutAnimation(animationController);
        projectListBinding.recyclerProjectView.scheduleLayoutAnimation();

    }

    // On select, open the Interiors Activity
    @Override
    public void onClick(int position, MaterialCardView cardView) {
        ActivityOptionsCompat options = ActivityOptionsCompat
                .makeSceneTransitionAnimation(this, cardView, projectsAdapter.getCurrentData().get(position).getProjectId());

        Intent intent = new Intent(this, InteriorsActivity.class);
        intent.putExtra(InteriorsActivity.PROJECT, projectsAdapter.getCurrentData().get(position));
        startActivity(intent, options.toBundle());
    }

    private void toggleProjectNotFound(boolean enabled) {
        int visibility = enabled ? View.VISIBLE : View.GONE;
        projectListBinding.noProjectsFound.setVisibility(visibility);
        projectListBinding.noProjectsFoundText.setVisibility(visibility);

    }

    // endregion project list helpers

    // region appUpdate helpers
    private void startAppUpdate() {
        this.appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();

        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                // Request the update.
                Log.d(TAG, "Update available");

                int stalenessDays = appUpdateInfo.clientVersionStalenessDays() != null ? appUpdateInfo
                        .clientVersionStalenessDays() : -1;

                currentAppUpdateType = stalenessDays < STALENESS_DAYS ? AppUpdateType.FLEXIBLE : AppUpdateType.IMMEDIATE;

                if (AppUpdateType.FLEXIBLE == currentAppUpdateType) {
                    LocalDateTime lastCancelledDate = new SharedPreferencesManager(this).getAppUpdateStatusTime();
                    if (lastCancelledDate == null) start();
                    else if (Duration.between(lastCancelledDate, LocalDateTime.now()).toHours() > FLEXIBLE_UPDATE_HIDE_HOURS) {
                        start();
                    }

                } else start();

            } else {
                Log.d(TAG, "No Update available");
            }
        });

    }

    public void start() {
        if (currentAppUpdateType == AppUpdateType.FLEXIBLE) {
            setUpListener();
        }
        checkUpdate();
    }

    private void checkUpdate() {
        // Checks that the platform will allow the specified type of update.
        Log.d(TAG, "Checking for updates");
        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {

            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                    && appUpdateInfo.isUpdateTypeAllowed(currentAppUpdateType)) {
                // Request the update.
                Log.d(TAG, "Update available");
                startUpdate(appUpdateInfo);
            } else {
                Log.d(TAG, "No Update available");
            }
        });
    }

    private void startUpdate(AppUpdateInfo appUpdateInfo) {
        try {
            Log.d(TAG, "Starting update");
            appUpdateManager.startUpdateFlowForResult(
                    appUpdateInfo,
                    currentAppUpdateType,
                    this,
                    RESULT_CODE);
        } catch (IntentSender.SendIntentException e) {
            Log.d(TAG, "" + e.getMessage());
        }
    }

    private void setUpListener() {
        appUpdateManager.registerListener(listener);
    }

    private void continueUpdate() {
        if (currentAppUpdateType == AppUpdateType.FLEXIBLE) continueUpdateForFlexible();
        else continueUpdateForImmediate();
    }

    private void continueUpdateForFlexible() {
        appUpdateManager
                .getAppUpdateInfo()
                .addOnSuccessListener(appUpdateInfo -> {
                    // If the update is downloaded but not installed,
                    // notify the user to complete the update.
                    if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED) {
                        Log.d(TAG, "An update has been downloaded");
                        popupSnackbarForCompleteUpdate();
                    }
                });
    }

    private void continueUpdateForImmediate() {
        appUpdateManager
                .getAppUpdateInfo()
                .addOnSuccessListener(appUpdateInfo -> {
                    if (appUpdateInfo.updateAvailability()
                            == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                        // If an in-app update is already running, resume the update.
                        try {
                            appUpdateManager.startUpdateFlowForResult(
                                    appUpdateInfo,
                                    AppUpdateType.IMMEDIATE,
                                    this,
                                    RESULT_CODE);
                        } catch (IntentSender.SendIntentException e) {
                            Log.d(TAG, "" + e.getMessage());
                        }
                    }
                });
    }

    private void popupSnackbarForCompleteUpdate() {
        Snackbar snackbar =
                Snackbar.make(
                        this.getWindow().getDecorView().findViewById(android.R.id.content),
                        "An app update has been downloaded.",
                        Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("RESTART", v -> appUpdateManager.completeUpdate());
        snackbar.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_CODE) {
            if (resultCode != RESULT_OK && AppUpdateType.FLEXIBLE == currentAppUpdateType) {
                new SharedPreferencesManager(this).setAppUpdateStatusTime();
            }
            if (resultCode != RESULT_OK && AppUpdateType.IMMEDIATE == currentAppUpdateType) {
                startAppUpdate();
            }
            if (resultCode == RESULT_OK) showDownloadingSnackMessage();
        }
    }

    private void unregisterListener() {
        if (appUpdateManager != null && listener != null) {
            appUpdateManager.unregisterListener(listener);
            Log.d(TAG, "Unregistered the install state listener");
        }
    }

    private void showDownloadingSnackMessage() {
        Snackbar.make(this.getWindow().getDecorView().findViewById(android.R.id.content), "App update is downloading in the background", Snackbar.LENGTH_LONG)
                .show();
    }

    // endregion

    private void requestReview() {
        if (new SharedPreferencesManager(this).getAppOpenCount() % 30 == 0) {
            ReviewManager manager = ReviewManagerFactory.create(this);
            Task<ReviewInfo> request = manager.requestReviewFlow();
            request.addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    // We can get the ReviewInfo object
                    ReviewInfo reviewInfo = task.getResult();
                    Task<Void> flow = manager.launchReviewFlow(this, reviewInfo);
                    flow.addOnCompleteListener(task1 -> {
                    });
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        continueUpdate();
    }

    @Override
    protected void onDestroy() {
        if (!disposable.isDisposed()) {
            disposable.dispose();
        }
        unregisterListener();
        super.onDestroy();
    }
}