package com.huviair.capture.data.model.api.aerial;

public class AerialImageResponse {
    private String status;
    private int imageRowId;

    public AerialImageResponse(int imageRowId) {
        this.imageRowId = imageRowId;
    }

    public int getImageRowId() {
        return imageRowId;
    }

    public void setImageRowId(int imageRowId) {
        this.imageRowId = imageRowId;
    }
}
