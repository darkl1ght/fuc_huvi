package com.huviair.capture.data.model.api.projects;


import com.huviair.capture.data.model.api.tours.InteriorCacheData;

import java.io.Serializable;
import java.util.List;

public class ProjectDetails implements Serializable {
    private String projectName;
    private String projectId;
    private String location;
    private String type;
    private List<InteriorCacheData> interiors;

    public ProjectDetails(String projectName, String projectId, String location, String type, List<InteriorCacheData> interiors) {
        this.projectName = projectName;
        this.projectId = projectId;
        this.location = location;
        this.type = type;
        this.interiors = interiors;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<InteriorCacheData> getInteriors() {
        return interiors;
    }

    public void setInteriors(List<InteriorCacheData> interiors) {
        this.interiors = interiors;
    }

    @Override
    public String toString() {
        return "ProjectDetails{" +
                "projectName='" + projectName + '\'' +
                ", projectId='" + projectId + '\'' +
                ", location='" + location + '\'' +
                ", type='" + type + '\'' +
                ", interiorCacheData=" + interiors +
                '}';
    }
}
