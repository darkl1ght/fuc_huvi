package com.huviair.capture.adapters;

import android.content.res.ColorStateList;
import android.graphics.drawable.InsetDrawable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.huviair.capture.R;
import com.huviair.capture.animations.Animations;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.TaskStatus;
import com.huviair.capture.databinding.SnagsViewListItemBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.DateFormatUtils;

import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

public class SnagsListsAdapter extends PagingDataAdapter<Snag, SnagsListsAdapter.ViewHolder> {

    private final SnagItemButtonClickListener snagItemButtonClickListener;
    private String loggedInUserEmail;

    private String snagType;
    public void setLoggedInUserEmail(String loggedInUserEmail) {
        this.loggedInUserEmail = loggedInUserEmail;
    }

    public void setSnagType(String snagType) {
        this.snagType = snagType;
    }

    public interface SnagItemButtonClickListener {
        void isButtonClicked(int viewId, Snag selectedSnag);
    }


    public SnagsListsAdapter(@NotNull DiffUtil.ItemCallback<Snag> diffCallback, SnagItemButtonClickListener snagItemButtonClickListener) {
        super(diffCallback);
        this.snagItemButtonClickListener = snagItemButtonClickListener;
    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        public SnagsViewListItemBinding snagsViewListItemBinding;

        public ViewHolder(SnagsViewListItemBinding snagsViewListItemBinding) {
            super(snagsViewListItemBinding.getRoot());
            this.snagsViewListItemBinding = snagsViewListItemBinding;
        }

    }


    // Create new views (invoked by the layout manager)
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NotNull ViewGroup viewGroup, int viewType) {
        return new ViewHolder(SnagsViewListItemBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }


    @Override
    public void onBindViewHolder(@NotNull ViewHolder viewHolder, final int position) {
        // Get chosen snag
        Snag snag = getItem(position);
        if (snag != null) {
            viewHolder.snagsViewListItemBinding.snagName.setText(snag.getTaskDescription());
            viewHolder.snagsViewListItemBinding.snagListId.setText(snag.getPunchListId());

            bindViews(snag, viewHolder);

            // Animate the arrow accordingly
            Animations.toggleArrow(viewHolder.snagsViewListItemBinding.expandableIcon, snag.isViewExpanded());

            viewHolder.snagsViewListItemBinding.cardLayout.setOnClickListener(v -> {
                boolean expanded = snag.isViewExpanded();

                // modify expanded status
                getItem(viewHolder.getLayoutPosition()).setViewExpanded(!expanded);

                // Notify the adapter that item has changed
                notifyItemChanged(viewHolder.getLayoutPosition());
            });

            viewHolder.snagsViewListItemBinding.viewUsersIcon.setOnClickListener(v -> snagItemButtonClickListener.isButtonClicked(v.getId(), getItem(position)));
            viewHolder.snagsViewListItemBinding.resolveSnagLevel1.setOnClickListener(v -> snagItemButtonClickListener.isButtonClicked(v.getId(), getItem(position)));
            viewHolder.snagsViewListItemBinding.resolveSnagLevel2.setOnClickListener(v -> snagItemButtonClickListener.isButtonClicked(v.getId(), getItem(position)));
            viewHolder.snagsViewListItemBinding.floorPlanButton.setOnClickListener(v -> snagItemButtonClickListener.isButtonClicked(v.getId(), getItem(position)));
            viewHolder.snagsViewListItemBinding.viewMediaIcon.setOnClickListener(v -> snagItemButtonClickListener.isButtonClicked(v.getId(), getItem(position)));
            viewHolder.snagsViewListItemBinding.mediaSnagButton.setOnClickListener(v -> snagItemButtonClickListener.isButtonClicked(v.getId(), getItem(position)));
            viewHolder.snagsViewListItemBinding.moreActions.setOnClickListener(v -> openPopUpMenu(v, snag));

        }

    }

    private void openPopUpMenu(View view, Snag snag) {
        PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
        popupMenu.inflate(R.menu.snag_pop_up_menu);
        populateIcons(popupMenu, view);

        // Do not allow level 1 user to delete the snag
        popupMenu.getMenu().findItem(R.id.action_delete_snag).setVisible(isApproverAllowedToDelete(snag));

        popupMenu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_update_snag) {
                snagItemButtonClickListener.isButtonClicked(item.getItemId(), snag);
            } else if (item.getItemId() == R.id.action_delete_snag) {
                new MaterialAlertDialogBuilder(view.getContext())
                        .setTitle("Delete Snag")
                        .setIcon(R.drawable.delete_brand_color)
                        .setPositiveButton("YES", (dialog, which) -> snagItemButtonClickListener.isButtonClicked(item.getItemId(), snag))
                        .setNegativeButton("NO", (dialog, which) -> {
                        })
                        .create()
                        .show();

            }
            return false;
        });
        popupMenu.show();
    }

    private boolean isApproverAllowedToDelete(Snag snag){
       return Arrays.stream(snag.getLevel2Users()).anyMatch(level2Email -> level2Email.toLowerCase().equals(loggedInUserEmail));
    }
    private void populateIcons(PopupMenu popup, View view) {
        if (popup.getMenu() instanceof MenuBuilder) {
            MenuBuilder menuBuilder = (MenuBuilder) popup.getMenu();
            //noinspection RestrictedApi
            menuBuilder.setOptionalIconsVisible(true);
            //noinspection RestrictedApi
            for (MenuItem item : menuBuilder.getVisibleItems()) {
                int iconMarginPx =
                        (int)
                                TypedValue.applyDimension(
                                        TypedValue.COMPLEX_UNIT_DIP, 8, view.getContext().getResources().getDisplayMetrics());

                if (item.getIcon() != null) {
                    item.setIcon(
                            new InsetDrawable(item.getIcon(), iconMarginPx, 0, iconMarginPx, 0) {
                                @Override
                                public int getIntrinsicWidth() {
                                    return getIntrinsicHeight() + iconMarginPx + iconMarginPx;
                                }
                            });
                }
            }
        }
    }

    private void bindViews(Snag snag, ViewHolder viewHolder) {
        // Get the state
        boolean expanded = snag.isViewExpanded();
        boolean onsiteSnag = snagType!=null && snagType.equalsIgnoreCase(CommonConstants.SNAG_DRAFT_ITEMS);
        // Set the visibility based on state
        viewHolder.snagsViewListItemBinding.expandableCardView.setVisibility(expanded ? View.VISIBLE : View.GONE);
        viewHolder.snagsViewListItemBinding.snagLocationValue.setText(snag.getWorkLocation().getLocation());
        viewHolder.snagsViewListItemBinding.snagWorkpackageValue.setText(snag.getWorkPackage().getTradeName());
        viewHolder.snagsViewListItemBinding.snagLastUpdatedValue.setText(DateFormatUtils.parseDate(snag.getUpdatedAt()));
        if(onsiteSnag){
            viewHolder.snagsViewListItemBinding.viewMediaIcon.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.snagStatusKey.setVisibility(View.GONE);
            viewHolder.snagsViewListItemBinding.snagStatusValue.setVisibility(View.GONE);
            viewHolder.snagsViewListItemBinding.snagDuedateKey.setVisibility(View.GONE);
            viewHolder.snagsViewListItemBinding.snagDuedateValue.setVisibility(View.GONE);
            viewHolder.snagsViewListItemBinding.viewUsersIcon.setVisibility(View.GONE);

            viewHolder.snagsViewListItemBinding.resolveSnagLevel1.setVisibility(View.GONE);
            viewHolder.snagsViewListItemBinding.resolveSnagLevel2.setVisibility(View.GONE);
            viewHolder.snagsViewListItemBinding.floorPlanButton.setVisibility(View.GONE);
            viewHolder.snagsViewListItemBinding.mediaSnagButton.setVisibility(View.GONE);

            } else {
            viewHolder.snagsViewListItemBinding.viewMediaIcon.setVisibility(View.GONE);
            viewHolder.snagsViewListItemBinding.snagStatusKey.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.snagStatusValue.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.snagDuedateKey.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.snagDuedateValue.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.viewUsersIcon.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.resolveSnagLevel1.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.resolveSnagLevel2.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.floorPlanButton.setVisibility(View.VISIBLE);
            viewHolder.snagsViewListItemBinding.mediaSnagButton.setVisibility(View.VISIBLE);

            viewHolder.snagsViewListItemBinding.snagStatusValue.setText(snag.getTaskStatus().getDesc());
            viewHolder.snagsViewListItemBinding.snagDuedateValue.setText(DateFormatUtils.parseDate(snag.getDueDate()));
            populateCardLeftMarginColorAndTaskStatus(viewHolder.snagsViewListItemBinding.snagStatusValue, viewHolder.snagsViewListItemBinding.emptyCard, snag.getTaskStatus());
            // Level1
            populateApproverIcons(snag.getLevel1Status().getStatus(), (MaterialButton) viewHolder.snagsViewListItemBinding.resolveSnagLevel1);
            // Level2
            populateApproverIcons(snag.getLevel2Status().getStatus(), (MaterialButton) viewHolder.snagsViewListItemBinding.resolveSnagLevel2);

        }



    }

    private void populateApproverIcons(@NotNull TaskStatus snagStatus, MaterialButton button) {
        switch (snagStatus.getCode()) {
            case CommonConstants.VERIFICATION_STATUS_ACCEPTED:
                button.setIconTint(ColorStateList.valueOf(ContextCompat.getColor(button.getContext(), R.color.success)));
                button.setIconResource(R.drawable.check_circle_icon);
                break;
            case CommonConstants.VERIFICATION_STATUS_NOT_ACCEPTED:
                button.setIconTint(ColorStateList.valueOf(ContextCompat.getColor(button.getContext(), R.color.danger)));
                button.setIconResource(R.drawable.cancel_round_icon);
                break;
            case CommonConstants.VERIFICATION_STATUS_CONDITIONALLY_ACCEPTED:
                button.setIconTint(ColorStateList.valueOf(ContextCompat.getColor(button.getContext(), R.color.success)));
                button.setIconResource(R.drawable.fact_check_icon);
                break;
            case CommonConstants.VERIFICATION_STATUS_PENDING:
                button.setIconTint(ColorStateList.valueOf(ContextCompat.getColor(button.getContext(), R.color.warning)));
                button.setIconResource(R.drawable.pending_icon);
                break;
            default:
                // Do nothing
        }
    }

    private void populateCardLeftMarginColorAndTaskStatus(TextView statusText, TextView emptyView, TaskStatus taskStatus) {
        switch (taskStatus.getCode()) {
            case CommonConstants.TASK_STATUS_ACCEPTED:
            case CommonConstants.TASK_STATUS_CONDITIONALLY_ACCEPTED:
                int successColor = ContextCompat.getColor(statusText.getContext(), R.color.success);
                statusText.setTextColor(successColor);
                emptyView.setBackgroundColor(successColor);
                break;
            case CommonConstants.TASK_STATUS_NOT_ACCEPTED:
                int dangerColor = ContextCompat.getColor(statusText.getContext(), R.color.danger);
                statusText.setTextColor(dangerColor);
                emptyView.setBackgroundColor(dangerColor);
                break;
            case CommonConstants.TASK_STATUS_PENDING_VERIFICATION:
                int warningColor = ContextCompat.getColor(statusText.getContext(), R.color.warning);
                statusText.setTextColor(warningColor);
                emptyView.setBackgroundColor(warningColor);
                break;
            default:
                // Do nothing

        }

    }

}

