package com.huviair.capture.ui.interiors;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.tours.interiorsResponse.FloorWalkThrough;
import com.huviair.capture.data.model.others.InteriorPublishEvent;
import com.huviair.capture.databinding.FragmentInteriorTourWorkStatsBinding;
import com.huviair.capture.viewmodels.InteriorsViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.stream.Collectors;

public class InteriorTourWorkStatsFragment extends Fragment {

    private FragmentInteriorTourWorkStatsBinding fragmentInteriorTourWorkStatsBinding;
    private InteriorsViewModel interiorsViewModel;

    public InteriorTourWorkStatsFragment() {
        // Required empty public constructor
    }


    public static InteriorTourWorkStatsFragment newInstance() {
        InteriorTourWorkStatsFragment fragment = new InteriorTourWorkStatsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentInteriorTourWorkStatsBinding = FragmentInteriorTourWorkStatsBinding.inflate(inflater, container, false);
        return fragmentInteriorTourWorkStatsBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        fragmentInteriorTourWorkStatsBinding.interiorStatsToolBar.toolBar.setTitle("Walk-through upload");
        fragmentInteriorTourWorkStatsBinding.interiorStatsToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        fragmentInteriorTourWorkStatsBinding.interiorStatsToolBar.toolBar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        interiorsViewModel = new ViewModelProvider(requireActivity(), new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication())).get(InteriorsViewModel.class);

        fragmentInteriorTourWorkStatsBinding.tourTextViewForStats.setAdapter(new ArrayAdapter<>(requireContext(), R.layout.list_item, interiorsViewModel.getTourNames()));

        populateTowersOnTourChange();
        observeForInteriorsResponse();

        fragmentInteriorTourWorkStatsBinding.viewWorkStatus.setOnClickListener(v -> interiorsViewModel.publishSingleLiveEvent.setValue(
                new InteriorPublishEvent(interiorsViewModel.selectedWorkTowerId, interiorsViewModel.selectedWorkInteriorId)));
    }

    private void populateTowersOnTourChange() {
        fragmentInteriorTourWorkStatsBinding.tourTextViewForStats.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence changedText, int start, int before, int count) {
                String tourToSearch = changedText.toString();
                if (interiorsViewModel.getTourNames().stream().anyMatch(s -> s.equalsIgnoreCase(tourToSearch))) {
                    // remove all existing towers
                    interiorsViewModel.selectedWorkTowerId= "";
                    populateTowers(interiorsViewModel.getTourNames().indexOf(tourToSearch));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        fragmentInteriorTourWorkStatsBinding.towerTextViewForStats.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence changedText, int start, int before, int count) {
                String tourToSearch = changedText.toString();
                if (interiorsViewModel.getWalkthroughWorkResponseList().stream().anyMatch(s -> s.getTowerName().equalsIgnoreCase(tourToSearch))) {
                    interiorsViewModel.selectedWorkTowerId = interiorsViewModel.getWalkthroughWorkResponseList().stream().filter(floorWalkThrough -> floorWalkThrough.getTowerName().equals(changedText.toString()))
                            .findFirst().get().getTowerId();
                    fragmentInteriorTourWorkStatsBinding.viewWorkStatus.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void populateTowers(int index) {
        fragmentInteriorTourWorkStatsBinding.towerTextViewForStats.setText("");
        fragmentInteriorTourWorkStatsBinding.viewWorkStatus.setEnabled(false);

        interiorsViewModel.selectedWorkInteriorId = interiorsViewModel.getInteriorsList().get(index).getInteriorId();
        interiorsViewModel.fetchWorkWalkThroughsForTheTour(interiorsViewModel.selectedWorkInteriorId);
    }

    private void observeForInteriorsResponse() {
        interiorsViewModel.getInteriorsResultMutableLiveData().observe(getViewLifecycleOwner(), interiorsResult -> {
            if (interiorsResult.getSuccess() != null && interiorsResult.getSuccess().getTours() != null) {
                populateTowersDropDown(interiorsResult.getSuccess().getTours());
            }
        });
    }

    private void populateTowersDropDown(List<FloorWalkThrough> floorWalkThroughs) {
        List<String> towerNames = floorWalkThroughs.stream().map(FloorWalkThrough::getTowerName).collect(Collectors.toList());
        interiorsViewModel.setTowerNames(towerNames);
        fragmentInteriorTourWorkStatsBinding.towerTextViewForStats.setAdapter(new ArrayAdapter<>(requireContext(), R.layout.list_item, towerNames));
        fragmentInteriorTourWorkStatsBinding.towerTextViewForStats.setEnabled(true);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (fragmentInteriorTourWorkStatsBinding != null) {
            fragmentInteriorTourWorkStatsBinding = null;
        }
    }
}