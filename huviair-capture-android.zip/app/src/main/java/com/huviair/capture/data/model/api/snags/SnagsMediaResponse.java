package com.huviair.capture.data.model.api.snags;

import java.util.List;

public class SnagsMediaResponse {
    private List<SnagMedia> mediaList;

    public List<SnagMedia> getMediaList() {
        return mediaList;
    }
}
