package com.huviair.capture.ui.snags.snaglist;

import androidx.annotation.Nullable;

import com.huviair.capture.ui.snags.snagsmedia.SnagMediaDataView;

public class SnagMediaResult {
    @Nullable
    private SnagMediaDataView success;
    @Nullable
    private Integer error;

    public SnagMediaResult(@Nullable Integer error) {
        this.error = error;
    }

    public SnagMediaResult(@Nullable SnagMediaDataView success) {
        this.success = success;
    }

    @Nullable
    SnagMediaDataView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }
}
