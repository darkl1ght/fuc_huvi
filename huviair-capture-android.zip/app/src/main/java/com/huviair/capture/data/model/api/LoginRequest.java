package com.huviair.capture.data.model.api;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;

public class LoginRequest {
    @Expose
    User user;

    public LoginRequest(String userEmailId, String password) {
        user = new User(userEmailId, password);
    }

    @Keep
    class User {
        private String email;
        private String password;

        public User(String emailId, String password) {
            this.email = emailId;
            this.password = password;
        }

        public String getUserEmailId() {
            return email;
        }

        public void setUserEmailId(String userEmailId) {
            this.email = userEmailId;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }


    }
}
