package com.huviair.capture.data.model.api.tours;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class Geometry implements Serializable {
    private String type;
    private final List<Double> coordinates;

    public Geometry(String type, List<Double> coordinates) {
        this.type = type;
        this.coordinates = coordinates;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Double> getCoordinates() {
        return coordinates;
    }

    public Double getYCoordinate(){
        return coordinates.get(1);
    }
    public Double getXCoordinate(){
        return coordinates.get(0);
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Geometry geometry = (Geometry) o;
        return Objects.equals(type, geometry.type) &&
                Objects.equals(coordinates, geometry.coordinates);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, coordinates);
    }
}
