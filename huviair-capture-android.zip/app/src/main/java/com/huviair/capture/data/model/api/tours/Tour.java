package com.huviair.capture.data.model.api.tours;

import com.google.gson.annotations.Expose;
import com.huviair.capture.data.model.database.InteriorWalkthrough;

import java.io.Serializable;

public class Tour implements Serializable {

    private final String towerId;
    private String floorPlanBlobId;
    private String interiorId;
    private String tourId;
    private String tourName;
    private String projectId;
    private boolean isPublished;

    @Expose(serialize = false, deserialize = false)
    private String floorPlanPath;

    public Tour(String floorPlanBlobId, String interiorId, String tourId, String tourName, String towerId, String projectId, String floorPlanPath) {
        this.floorPlanBlobId = floorPlanBlobId;
        this.interiorId = interiorId;
        this.tourId = tourId;
        this.tourName = tourName;
        this.towerId = towerId;
        this.projectId = projectId;
        this.floorPlanPath = floorPlanPath;
    }

    public String getFloorPlanPath() {
        return floorPlanPath;
    }

    public void setFloorPlanPath(String path) {
        this.floorPlanPath = path;
    }

    public String getTowerId() {
        return towerId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getFloorPlanBlobId() {
        return floorPlanBlobId;
    }

    public void setFloorPlanBlobId(String floorPlanBlobId) {
        this.floorPlanBlobId = floorPlanBlobId;
    }


    public boolean isPublished() {
        return isPublished;
    }

    public void setPublished(boolean published) {
        isPublished = published;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public void setInteriorId(String interiorId) {
        this.interiorId = interiorId;
    }

    public String getTourId() {
        return tourId;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    public void builder(InteriorWalkthrough tour) {
        if (tour.getFloorPlanPath() != null)
            this.floorPlanPath = tour.getFloorPlanPath();
    }

    @Override
    public String toString() {
        return "Tour{" +
                "floorPlanBlobId='" + floorPlanBlobId + '\'' +
                ", interiorId='" + interiorId + '\'' +
                ", tourId='" + tourId + '\'' +
                ", tourName='" + tourName + '\'' +
                '}';
    }
}
