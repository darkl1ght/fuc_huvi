package com.huviair.capture.data.model.api.azure;

public class AzureTokenResponse {

    private AzureToken sasToken;

    public AzureToken getSasToken() {
        return sasToken;
    }

    public void setSasToken(AzureToken sasToken) {
        this.sasToken = sasToken;
    }
}
