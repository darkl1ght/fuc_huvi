package com.huviair.capture.data.model.api;

import com.google.gson.annotations.Expose;

public class ForgotPasswordRequest {
    @Expose
    String email;

    public ForgotPasswordRequest(String userEmailId) {
        this.email = userEmailId;
    }

}
