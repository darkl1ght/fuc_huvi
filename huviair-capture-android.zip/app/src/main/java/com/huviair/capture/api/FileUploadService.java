package com.huviair.capture.api;

import com.huviair.capture.data.model.api.ForgotPasswordRequest;
import com.huviair.capture.data.model.api.ForgotPasswordResponse;
import com.huviair.capture.data.model.api.LoggedInUser;
import com.huviair.capture.data.model.api.LoginRequest;
import com.huviair.capture.data.model.api.Notification;
import com.huviair.capture.data.model.api.UsersResponse;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.common.CommonResponse;
import com.huviair.capture.data.model.api.projects.ProjectList;
import com.huviair.capture.data.model.api.tours.InteriorsResponse;
import com.huviair.capture.data.model.api.tours.TourWalkThroughRequest;
import com.huviair.capture.data.model.api.tours.Walkthrough;
import com.huviair.capture.data.model.api.tours.interiorsResponse.WalkThroughResponse;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Single;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Url;

/**
 * Interface provides different API functionality for interacting with the Node.js backend
 */
public interface FileUploadService {

    @Headers({"x-ms-blob-type: BlockBlob",  "Content-Type: application/octet-stream"} )
    @PUT
    Call<ResponseBody> uploadFile(@Url String url, @Body RequestBody file);

}
