package com.huviair.capture.workers;

import static androidx.core.content.ContextCompat.getSystemService;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ForegroundInfo;
import androidx.work.RxWorker;
import androidx.work.WorkerParameters;

import com.arashivision.sdkmedia.export.ExportImageParamsBuilder;
import com.arashivision.sdkmedia.export.ExportUtils;
import com.arashivision.sdkmedia.export.IExportCallback;
import com.arashivision.sdkmedia.work.WorkWrapper;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.CommonConstants;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class ExportHDRImagesWorker extends RxWorker {

    private final DataCaptureRoomDatabase database;

    private final String IMPORTED_IMAGES_PATH;
    private final String HDR_STITCHED_IMAGE_PATH;

    AtomicInteger imageExportCount = new AtomicInteger(0);

    private List<TourDetails> tourDetailsFromDatabase;

    private String walkthroughName, interiorWalkthroughId;


    /**
     * @param appContext   The application {@link Context}
     * @param workerParams Parameters to setup the internal state of this worker
     */
    public ExportHDRImagesWorker(@NonNull Context appContext, @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);

        //Initialize folder paths
        HDR_STITCHED_IMAGE_PATH = appContext.getFilesDir() + "/" + CommonConstants.COMPLETED_IMAGES_FOLDER;
        IMPORTED_IMAGES_PATH = appContext.getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER;

        // Initialize database
        database = DataCaptureRoomDatabase.getDatabase(appContext);
    }

    @NonNull
    @Override
    public Single<Result> createWork() {
        try {
            interiorWalkthroughId = getInputData().getString(CommonConstants.WALKTHROUGH_ID);
            walkthroughName = getInputData().getString(CommonConstants.TOUR_NAME);
            String interiorTourId = getInputData().getString(CommonConstants.INTERIOR_TOUR_ID);
            String projectId = getInputData().getString(CommonConstants.PROJECT_ID);
            String towerId = getInputData().getString(CommonConstants.TOWER_ID);

            Data.Builder builder = new Data.Builder()
                    .putString(CommonConstants.INTERIOR_TOUR_ID, interiorTourId)
                    .putString(CommonConstants.TOUR_NAME, walkthroughName)
                    .putString(CommonConstants.WALKTHROUGH_ID, interiorWalkthroughId)
                    .putString(CommonConstants.PROJECT_ID, projectId)
                    .putString(CommonConstants.TOWER_ID, towerId);

            // Get all images available for export
            Single<List<TourDetails>> fetchTours = database.tourDetailsDAO().getWalkThroughForHdrGenerate(interiorWalkthroughId);

            setForegroundAsync(createForegroundInfo(true, "Stitching HDR Images started for the walk-through ".concat(walkthroughName), interiorWalkthroughId));

            return fetchTours.toObservable().observeOn(AndroidSchedulers.mainThread())
                    .map(this::transformTours)
                    .flatMap(tourDetails -> {
                        this.tourDetailsFromDatabase = tourDetails;
                        return Observable.fromIterable(tourDetails).filter(tour -> tour.getImageUrl().split(",").length > 1)
                                .flatMap(this::exportHDRImagesAsynchronously);
                    })
                    .doOnSubscribe(disposable -> setForegroundAsync(createForegroundInfo(true, "Stitching images for the walk-through ".concat(walkthroughName), interiorWalkthroughId)))
                    .toList()
                    .map(aerialImageResponses -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.success(builder.build());
                    })
                    .onErrorReturn(throwable -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.failure(builder.build());
                    })
                    .subscribeOn(Schedulers.io())
                    .doOnSuccess(result -> {
                        String message = "Stitching HDR Images for ".concat(walkthroughName).concat(" ").concat("completed");
                        setForegroundAsync(createForegroundInfo(false, message, interiorWalkthroughId));

                        // Send a processing complete notification
                        String processingComplete = "Processing has been completed for ".concat(walkthroughName);
                        showNotification(processingComplete);
                    })
                    .doOnError(throwable -> setForegroundAsync(createForegroundInfo(false, "Stitching HDR images for ".concat(walkthroughName).concat(" ").concat("failed"), interiorWalkthroughId)));


        } catch (Exception e) {
            return Single.just(Result.failure());
        }
    }

    // Modify tour image URL's paths to that of the local storage of the mobile
    private List<TourDetails> transformTours(List<TourDetails> tourDetails) {
        for (TourDetails tour : tourDetails) {
            String[] tourImageUrls = tour.getImageUrl().split(",");
            for (int i = 0; i < tourImageUrls.length; i++) {
                tourImageUrls[i] = tourImageUrls[i].replace(
                        tourImageUrls[i].substring(0, tourImageUrls[i].lastIndexOf("/")), IMPORTED_IMAGES_PATH);
            }
            tour.setImageUrlsSplit(tourImageUrls);
        }
        return tourDetails;
    }


    @NonNull
    private ForegroundInfo createForegroundInfo(boolean onGoing, @NonNull String message, @NonNull String walkthroughId) {
        Notification foregroundNotification = WorkerUtils.getNotification(onGoing, CommonConstants.INTERIOR_WORK_NOTIFICATION_TITLE, message, walkthroughId, getApplicationContext());
        int notificationId = onGoing ? 1 : 2;
        return new ForegroundInfo(notificationId, foregroundNotification);
    }

    private void showNotification(String message) {
        Random random = new Random();
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        Notification foregroundNotification = WorkerUtils.getNotification(false, CommonConstants.INTERIOR_WORK_NOTIFICATION_TITLE, message, "completed notification", getApplicationContext());
        notificationManager.notify(random.nextInt(), foregroundNotification);
    }


    /**
     * Export HDR images asynchronously
     *
     * @param tourDetails
     * @return
     */
    private Observable<Boolean> exportHDRImagesAsynchronously(TourDetails tourDetails) {

        WorkWrapper wrapper = new WorkWrapper(tourDetails.getImageUrlsSplit());
        String finalImagePath = HDR_STITCHED_IMAGE_PATH + "/" + "IMAGE_" + tourDetails.getImageNumber() + "_" + UUID.randomUUID() + ".jpg";

        // Stitch images only if HDR file exists and export file doesn't exist
        if (new File(tourDetails.getHdrImageFileName()).exists() && (tourDetails.getHdrExportFileName() == null || !new File(tourDetails.getHdrExportFileName()).exists())) {
            ExportImageParamsBuilder builder = new ExportImageParamsBuilder()
                    .setExportMode(ExportUtils.ExportMode.PANORAMA)
                    .setTargetPath(finalImagePath)
                    .setUrlForExport(tourDetails.getHdrImageFileName());
            return Observable.create((emitter) -> {
                int eventId = ExportUtils.exportImage(wrapper, builder, new IExportCallback() {
                    @Override
                    public void onSuccess() {
                        imageExportCount.incrementAndGet();
                        setForegroundAsync(createForegroundInfo(true, String.format(Locale.getDefault(), "Stitching images %d of %d for walk-through ".concat(walkthroughName), imageExportCount.intValue(), tourDetailsFromDatabase.size()), interiorWalkthroughId));
                        database.tourDetailsDAO().updateWalkThroughHdrExport(tourDetails.getTourId(), finalImagePath, tourDetails.getId()).subscribeOn(Schedulers.io()).subscribe();
                        emitter.onComplete();
                    }

                    @Override
                    public void onFail(int i, String s) {
                        emitter.onError(new Throwable(s));
                    }

                    @Override
                    public void onCancel() {

                    }
                });
                Log.d("event id", "exportHDRImagesAsynchronously: " + eventId);
                database.tourDetailsDAO().updateWalkthroughStitchEventId(tourDetails.getTourId(), eventId, tourDetails.getId()).subscribeOn(Schedulers.io()).subscribe();

            });
        }
        return Observable.just(false);
    }
}


