package com.huviair.capture.data.model.api.snags;

import com.huviair.capture.utils.CommonConstants;

public class Config {

    private String projectId;
    private String type;
    private Filters filters;

    // Default constructor
    public Config() {
        this.filters = new Filters();
    }

    public Config(String projectId, String type, Filters filters) {
        this.projectId = projectId;
        this.type = type;
        this.filters = filters;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Filters getFilters() {
        return filters;
    }

    public void setFilters(Filters filters) {
        this.filters = filters;
    }

    public boolean isFiltersApplied() {
        if (filters != null) {
            return filters.getPunchListId() != null || filters.getStartDate() != null || filters.getEndDate() != null
                    || filters.getWorkPackage() != null || !CommonConstants.EMPTY_STRING.equals(filters.getPriority());
        }
        return false;
    }

}
