package com.huviair.capture.data.model.api.media;

public class MediaResponse {
    public String status;
}
