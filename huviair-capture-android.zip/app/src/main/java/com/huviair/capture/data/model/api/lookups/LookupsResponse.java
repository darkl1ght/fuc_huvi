package com.huviair.capture.data.model.api.lookups;

import java.util.List;

public class LookupsResponse {
    private List<Lookup> lookups;

    public List<Lookup> getLookups() {
        return lookups;
    }
}
