package com.huviair.capture.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.huviair.capture.R;
import com.huviair.capture.adapters.diffUtil.SnagMediaListDiffUtil;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.data.model.api.media.Media;
import com.huviair.capture.data.model.api.snags.SnagMedia;
import com.huviair.capture.data.model.others.MediaDetails;
import com.huviair.capture.databinding.MediaAlbumDetailsBinding;
import com.huviair.capture.utils.DateFormatUtils;
import com.huviair.capture.utils.GlideApp;
import com.huviair.capture.viewmodels.SnagViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class SnagMediaAdapter extends RecyclerView.Adapter<SnagMediaAdapter.MediaViewHolder> {

    private final List<SnagMedia> mediaDetails;

    private final SnagMediaAdapterClicksListener snagMediaAdapterClicksListener;
    private SnagViewModel snagViewModel;

    public SnagMediaAdapter(List<SnagMedia> media, SnagMediaAdapterClicksListener listener) {
        this.mediaDetails = media;
        this.snagMediaAdapterClicksListener = listener;
    }

    public void updateData(List<SnagMedia> newMediaList) {
        SnagMediaListDiffUtil snagMediaListDiffUtil = new SnagMediaListDiffUtil(mediaDetails, newMediaList);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(snagMediaListDiffUtil);
        this.mediaDetails.clear();
        this.mediaDetails.addAll(newMediaList);
        diffResult.dispatchUpdatesTo(this);
    }

    @Override
    public void onAttachedToRecyclerView(@androidx.annotation.NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        if (snagViewModel == null) {
            snagViewModel = new ViewModelProvider((ViewModelStoreOwner) recyclerView.getContext()).get(SnagViewModel.class);
        }
    }

    // Create new views (invoked by the layout manager)
    @NotNull
    @Override
    public MediaViewHolder onCreateViewHolder(@NotNull ViewGroup viewGroup, int viewType) {
        MediaAlbumDetailsBinding albumDetailsBinding;

        albumDetailsBinding = MediaAlbumDetailsBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);


        MediaViewHolder mediaViewHolder = new MediaViewHolder(albumDetailsBinding);

        if (Media.VIDEO_TYPE == viewType) {
            albumDetailsBinding.imageViewMedia.setAlpha(0.2f);
            albumDetailsBinding.videoPlayButton.setVisibility(View.VISIBLE);
        }

        // On single click
        mediaViewHolder.mediaAlbumDetailsBinding.itemCardAlbum.setOnClickListener(v -> {
            int absoluteAdapterPosition = mediaViewHolder.getAbsoluteAdapterPosition();
            SnagMedia snagMedia = mediaDetails.get(absoluteAdapterPosition);

            // Handles three scenarios - Video playback, Image playback, Multiselect mode "ON"
            if (isOfVideoType(snagMedia)) {
                snagViewModel.playVideo.setValue(new MediaDetails(snagMedia.getBlobReferenceId(), snagMedia.getFileName(), false));
            } else {
                snagViewModel.setSelectedSnagMedia(absoluteAdapterPosition, mediaDetails);
            }
        });

        mediaViewHolder.mediaAlbumDetailsBinding.itemCardAlbum
                .setOnLongClickListener(v -> {
                    int absoluteAdapterPosition = mediaViewHolder.getAbsoluteAdapterPosition();
                    SnagMedia snagMedia = mediaDetails.get(absoluteAdapterPosition);

                    snagMediaAdapterClicksListener.deleteMedia(snagMedia.getMediaId());
                    return false;
                });

        return mediaViewHolder;
    }

    private boolean isOfVideoType(SnagMedia media) {
        return media.getBlobReferenceId().endsWith(".mp4");
    }

    @Override
    public void onBindViewHolder(MediaViewHolder viewHolder, final int position) {
        SnagMedia currentMedia = mediaDetails.get(position);

        // Populate Image view from web
        populateMediaThumbnail(currentMedia, viewHolder.mediaAlbumDetailsBinding.imageViewMedia);


        //Format date
        String albumCreateDate = DateFormatUtils.parseDateWithTimeZone(currentMedia.getMediaCreateDate(), "MMM d, yyyy HH:mm");
        viewHolder.mediaAlbumDetailsBinding.imageCreateDate.setText(albumCreateDate);

    }

    private void populateMediaThumbnail(SnagMedia snagMedia, ImageView imageView) {
        GlideApp.with(imageView.getContext())
                .load(APIClient.getAzureBlobThumbnailContainer().concat(snagMedia.getBlobReferenceId()))
                .placeholder(R.drawable.ic_baseline_cloud_download_24)
                .error(R.drawable.image_preview_brand_color)
                .into(imageView);
    }

    @Override
    public int getItemCount() {
        return mediaDetails.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (mediaDetails.get(position).getBlobReferenceId().endsWith(".mp4")) {
            return Media.VIDEO_TYPE;
        }
        return Media.IMAGE_TYPE;

    }


    public interface SnagMediaAdapterClicksListener {
        void deleteMedia(String mediaIdToDelete);
    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class MediaViewHolder extends RecyclerView.ViewHolder {
        public MediaAlbumDetailsBinding mediaAlbumDetailsBinding;

        public MediaViewHolder(@androidx.annotation.NonNull MediaAlbumDetailsBinding view) {
            super(view.getRoot());
            this.mediaAlbumDetailsBinding = view;
        }

    }

}

