package com.huviair.capture.ui.interiors.interiorsDataExport;

import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.huviair.capture.R;
import com.huviair.capture.ui.interiors.interiorsDataExport.fragments.GenerateHDRImagesFragment;
import com.huviair.capture.ui.interiors.interiorsDataExport.fragments.ImportImagesFromCamFragment;
import com.huviair.capture.ui.interiors.interiorsDataExport.fragments.PublishImagesFragment;
import com.huviair.capture.ui.interiors.interiorsDataExport.fragments.StitchHDRImagesFragment;

import org.jetbrains.annotations.NotNull;

public class TourDataTransferFragmentActivity extends FragmentActivity {

    //    Intent constants
    public static final String PROJECT_ID = "PROJECT_ID";
    public static final String INTERIOR_ID = "INTERIOR_ID";
    public static final String TOUR_ID = "TOUR_ID";

    // Tour Details Variables
    private String tourId;
    private String projectId;
    private String interiorId;

    /**
     * The number of pages (wizard steps) to show in this demo.
     */
    private static final int NUM_PAGES = 4;

    /**
     * The pager widget, which handles animation and allows swiping horizontally to access previous
     * and next wizard steps.
     */
    private ViewPager2 viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_data_transfer_fragment);

        if (getIntent().getExtras() != null) {
            tourId = getIntent().getStringExtra(TOUR_ID);
            projectId = getIntent().getStringExtra(PROJECT_ID);
            interiorId = getIntent().getStringExtra(INTERIOR_ID);
            if (tourId == null || projectId == null || interiorId == null) finish();
        }

        // Instantiate a ViewPager2 and a PagerAdapter.
        viewPager = findViewById(R.id.pager);
        FragmentStateAdapter pagerAdapter = new ScreenSlidePagerAdapter(this);

        //Disable the swipe
        viewPager.setUserInputEnabled(false);

        viewPager.setAdapter(pagerAdapter);
    }

    @Override
    public void onBackPressed() {
        if (viewPager.getCurrentItem() == 0) {
            // If the user is currently looking at the first step, allow the system to handle the
            // Back button. This calls finish() on this activity and pops the back stack.
            super.onBackPressed();
        }
    }

    /**
     * A simple pager adapter that represents 3 ScreenSlidePageFragment objects, in
     * sequence.
     */
    private class ScreenSlidePagerAdapter extends FragmentStateAdapter {
        public ScreenSlidePagerAdapter(FragmentActivity fa) {
            super(fa);
        }

        @NotNull
        @Override
        public Fragment createFragment(int position) {
            switch (position) {
                case 0:
                    return ImportImagesFromCamFragment.newInstance(tourId);
                case 1:
                    return GenerateHDRImagesFragment.newInstance(tourId);
                case 2:
                    return StitchHDRImagesFragment.newInstance(tourId);
                case 3:
                    return PublishImagesFragment.newInstance(tourId, projectId, interiorId);

                default:
                    throw new IllegalStateException("Unexpected value: " + position);
            }
        }

        @Override
        public int getItemCount() {
            return NUM_PAGES;
        }

    }


    public void jumpToNextPage(View view) {
        if (viewPager.getCurrentItem() != 3) {
            viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true);
        }
    }

    public void jumpToPreviousPage(View view) {
        if (viewPager.getCurrentItem() != 0) {
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1, true);
        }

    }
}

