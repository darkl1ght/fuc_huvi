package com.huviair.capture.utils;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.Keep;

import java.time.LocalDateTime;

@Keep
public class SharedPreferencesManager {

    private static final String SHARED_PREF_NAME_USER = "User Preferences";
    private static final String JWT_TOKEN = "TOKEN";
    private static final String LOGGED_IN_USER_EMAIL = "EMAIL";
    private static final String INSTA_CAMERA_PREVIEW = "INSTA_CAMERA_PREVIEW";
    private static final String IS_CAPTURE_HD_MODE_ENABLED = "IS_CAPTURE_HD_MODE_ENABLED";
    private static final String IS_INTERIORS_DOWNLOADED = "IS_INTERIORS_DOWNLOADED";
    private static final String APP_OPEN_COUNT = "APP_OPEN_COUNT";
    private static final String APP_UPDATE_STATUS_CANCELLED_TIME = "APP_UPDATE_STATUS_CANCELLED_TIME";
    private static final String GCM_REGISTRATION_TOKEN = "GCM_REGISTRATION_TOKEN";
    private static final String IS_VIEWING_INTERIORS_FIRST_TIME ="IS_VIEWING_INTERIORS_FIRST_TIME";
    private final Context context;

    public SharedPreferencesManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean userLogin(String jwtToken, String email) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(JWT_TOKEN, jwtToken);
        editor.putString(LOGGED_IN_USER_EMAIL, email);
        editor.apply();
        return true;
    }

    public boolean isLoggedIn() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        return sharedPreferences.getString(JWT_TOKEN, null) != null;
    }

    public String getJwtToken() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        return sharedPreferences.getString(JWT_TOKEN, " ");
    }

    public String getLoggedInUserEmail() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        return sharedPreferences.getString(LOGGED_IN_USER_EMAIL, " ");
    }

    public boolean logout() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(JWT_TOKEN);
        editor.remove(LOGGED_IN_USER_EMAIL);
        editor.apply();
        return true;
    }

    public void setInstaCameraPreviewEnabled(boolean status) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(INSTA_CAMERA_PREVIEW, String.valueOf(status));
        editor.apply();
    }

    public boolean isInstaCameraPreviewEnabled() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        return Boolean.parseBoolean(sharedPreferences.getString(INSTA_CAMERA_PREVIEW, "false"));
    }

    public boolean isHDQualityEnabled() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        return Boolean.parseBoolean(sharedPreferences.getString(IS_CAPTURE_HD_MODE_ENABLED, "false"));
    }

    public void setCaptureHDQualityEnabled(boolean status) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(IS_CAPTURE_HD_MODE_ENABLED, String.valueOf(status));
        editor.apply();
    }

    public void setIsInteriorsDownloaded(boolean isInteriorsDownloaded) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(IS_INTERIORS_DOWNLOADED, String.valueOf(isInteriorsDownloaded));
        editor.apply();
    }

    public boolean isInteriorsDownloaded() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        return Boolean.parseBoolean(sharedPreferences.getString(IS_INTERIORS_DOWNLOADED, "false"));
    }

    public void setAppUpdateStatusTime() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(APP_UPDATE_STATUS_CANCELLED_TIME, LocalDateTime.now().toString());
        editor.apply();
    }

    public void setAppOpenCount() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        long currentAppCount = sharedPreferences.getLong(APP_OPEN_COUNT, 0L);
        editor.putLong(APP_OPEN_COUNT, currentAppCount + 1);
        editor.apply();
    }

    public long getAppOpenCount() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        return sharedPreferences.getLong(APP_OPEN_COUNT, 0L);
    }

    public boolean isInteriorsOpenedFirstTime() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        return Boolean.parseBoolean(sharedPreferences.getString(IS_VIEWING_INTERIORS_FIRST_TIME, "true"));
    }


    public LocalDateTime getAppUpdateStatusTime() {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        String localDateTime = sharedPreferences.getString(APP_UPDATE_STATUS_CANCELLED_TIME, null);
        return localDateTime != null ? LocalDateTime.parse(localDateTime) : null;

    }


    public void setGcmRegistrationToken(String registrationToken) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(GCM_REGISTRATION_TOKEN, registrationToken);
        editor.apply();
    }

    public void setAppOpenFirstTime(boolean firstTime) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME_USER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(IS_VIEWING_INTERIORS_FIRST_TIME, String.valueOf(firstTime));
        editor.apply();
    }
}
