package com.huviair.capture.ui.interiors.videocapture.publish;

import static com.lzy.okgo.utils.HttpUtils.runOnUiThread;

import android.app.Application;
import android.content.Context;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.github.pwittchen.reactivenetwork.library.rx2.ReactiveNetwork;
import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.InternetObservingSettings;
import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.strategy.SocketInternetObservingStrategy;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.api.FileUploadService;
import com.huviair.capture.api.ProgressRequestBody;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.model.api.tours.VideocaptureRequest;
import com.huviair.capture.data.model.database.InteriorVideoCapture;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.ui.interiors.tours.Coordinates;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.utils.SingleLiveEvent;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VideoCapturePublishViewModel extends AndroidViewModel {
    private final DataCaptureRoomDatabase database;
    private final SingleLiveEvent<Boolean> areVideosDownloaded = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isInternetConnectivityAvailable = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isUploadingDataToConstra = new SingleLiveEvent<>();
    private final SingleLiveEvent<Boolean> isUploadComplete = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isWalkthroughUploadedAlready = new SingleLiveEvent<>();

    private final SingleLiveEvent<Integer> file1UploadPercentage = new SingleLiveEvent<>();
    private final SingleLiveEvent<Integer> file2UploadPercentage = new SingleLiveEvent<>();
    public SingleLiveEvent<Boolean> is360CameraConnected = new SingleLiveEvent<>();

    private final String VIDEO_FOLDER_PATH;
    private final FileUploadService fileUploadService;
    private final APIService apiService;
    private final CompositeDisposable disposableBag = new CompositeDisposable();
    private Tour selectedWalkThrough;
    private InteriorVideoCapture videoCapture;

    public VideoCapturePublishViewModel(@NonNull Application application) {
        super(application);
        this.database = DataCaptureRoomDatabase.getDatabase(application);
        VIDEO_FOLDER_PATH = getApplication().getFilesDir() + "/" + CommonConstants.VIDEO_CAPTURE_VIDEOS_FOLDER;

        apiService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(application.getApplicationContext()).getJwtToken());

        fileUploadService = APIClient.createUploadService(FileUploadService.class, application, "");
    }


    public InteriorVideoCapture getVideoCapture() {
        return videoCapture;
    }

    public String getFileNameFromUrl(String url) {
        return url.substring(url.lastIndexOf("/") + 1);
    }


    public void fetchVideoCapture(Tour selectedWalkThrough) {
        this.selectedWalkThrough = selectedWalkThrough;

        disposableBag.add(database.tourDetailsDAO().getInteriorVideoWalkthrough(selectedWalkThrough.getTourId())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe((interiorVideoCapture, throwable) -> {
                    if (interiorVideoCapture != null) {
                        Log.i("Video capture", interiorVideoCapture.get(0).toString());
                        this.videoCapture = interiorVideoCapture.get(0);
                        File documentsURL = new File(VIDEO_FOLDER_PATH);
                        if (!documentsURL.exists()) {
                            documentsURL.mkdirs();
                        }

                        boolean videoDownloadStatus = interiorVideoCapture.get(0).getTimelapseVideoUrl().stream()
                                .map(this::getFileNameFromUrl)
                                .map(fileName -> new File(documentsURL, fileName))
                                .allMatch(File::exists);

                        areVideosDownloaded.setValue(videoDownloadStatus);

                        isWalkthroughUploadedAlready.setValue(interiorVideoCapture.get(0).isVideoUploaded());

                    }
                })
        );


    }

    public void addInternetConnectivityListener() {
        InternetObservingSettings settings = InternetObservingSettings.builder()
                .initialInterval(1000)
                .interval(3000)
                .build();

        disposableBag.add(ReactiveNetwork
                .observeInternetConnectivity(settings)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(isConnectedToInternet -> {
                    if (!isConnectedToInternet) {
                        isInternetConnectivityAvailable.setValue(false);
                    } else {
                        isInternetConnectivityAvailable.setValue(true);
                    }
                }));
    }


    public void uploadVideosToConstra() {

        file1UploadPercentage.setValue(0);
        file2UploadPercentage.setValue(0);

        isUploadingDataToConstra.setValue(true);


        AtomicInteger counter = new AtomicInteger(0);
        disposableBag.add(
                apiService.getAzureTokenWritePermission(CommonConstants.VIRTUAL_TOUR)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe((azureTokenResponse) -> {
                            File documentsURL = new File(VIDEO_FOLDER_PATH);
                            if (!documentsURL.exists()) {
                                documentsURL.mkdirs();
                            }

                            Callback<ResponseBody> callback = new Callback<ResponseBody>() {
                                @Override
                                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                                    // Handle successful response
                                    Log.d("Success", "onResponse: ");
                                    if(counter.incrementAndGet() == 2 ) {


                                        database.tourDetailsDAO().markVideoUploadStatus(true, videoCapture.getId())
                                                .subscribeOn(Schedulers.io())
                                                .observeOn(AndroidSchedulers.mainThread())
                                                .subscribe();

                                        String[] timelapseVideoUrls =videoCapture.getTimelapseVideoUrl().stream()
                                                                                    .map(url -> getFileNameFromUrl(url))
                                                                                    .collect(Collectors.toList())
                                                                                    .toArray(new String[2]);
                                        Log.d("Timelapse video url", "onResponse: "+ Arrays.toString(timelapseVideoUrls));

                                        VideocaptureRequest request = new VideocaptureRequest(timelapseVideoUrls, new Coordinates(videoCapture.getCaptureStartPoint().x, videoCapture.getCaptureStartPoint().y)
                                        ,new Coordinates(videoCapture.getCaptureEndPoint().x, videoCapture.getCaptureEndPoint().y));

                                        disposableBag.add(apiService.updateVideoCaptureDetails(selectedWalkThrough.getProjectId(), selectedWalkThrough.getTourId(), request)
                                                .subscribeOn(Schedulers.io())
                                                .observeOn(AndroidSchedulers.mainThread())
                                                .subscribe((commonResponse, throwable) -> {

                                                    // Delete the files
                                                    File file1 = new File(VIDEO_FOLDER_PATH + "/" + timelapseVideoUrls[0]);
                                                    File file2 = new File(VIDEO_FOLDER_PATH + "/" + timelapseVideoUrls[1]);
                                                    boolean file1Deleted = file1.delete();
                                                    boolean file2Deleted =file2.delete();
                                                    if (!file1Deleted || !file2Deleted) {
                                                        // Error deleting file
                                                        Log.d("Video delete", "failed");
                                                    }

                                                    isUploadComplete.setValue(true);
                                                    isUploadingDataToConstra.setValue(false);

                                                }));
                                    };
                                }

                                @Override
                                public void onFailure(Call<ResponseBody> call, Throwable t) {
                                    isUploadingDataToConstra.setValue(false);
                                }
                            };

                            List<File> fileList = videoCapture.getTimelapseVideoUrl().stream().map(this::getFileNameFromUrl)
                                    .map(fileName -> new File(documentsURL, fileName))
                                    .collect(Collectors.toList());

                            String file1URI = azureTokenResponse.getSasToken().blobUrl(videoCapture.getTourId() + "/" + fileList.get(0).getName(), CommonConstants.VIRTUAL_TOUR);
                            String file2URI = azureTokenResponse.getSasToken().blobUrl(videoCapture.getTourId() + "/" + fileList.get(1).getName(), CommonConstants.VIRTUAL_TOUR);

                            RequestBody requestFile1 = RequestBody.create(MediaType.parse("application/octet-stream"), fileList.get(0));
                            RequestBody requestFile2 = RequestBody.create(MediaType.parse("application/octet-stream"), fileList.get(1));

                            final ProgressRequestBody requestBody1 = new ProgressRequestBody(requestFile1, new ProgressRequestBody.UploadCallbacks() {
                                @Override
                                public void onProgressUpdate(int percentage) {
                                    // Update your progress bar or text view with the percentage
                                    Log.d("Progress", "onProgressUpdate: " + percentage);

                                    runOnUiThread(new Runnable() {
                                        public void run() {
                                            file1UploadPercentage.setValue(percentage);
                                        }});
                                }

                                @Override
                                public void onError() {
                                    // Handle any errors that occurred during the upload
                                }

                                @Override
                                public void onFinish() {
                                    // Hide the progress bar or text view
                                }
                            });

                            final ProgressRequestBody requestBody2 = new ProgressRequestBody(requestFile2, new ProgressRequestBody.UploadCallbacks() {
                                @Override
                                public void onProgressUpdate(int percentage) {
                                    // Update your progress bar or text view with the percentage
                                    Log.d("Progress", "onProgressUpdate: " + percentage);

                                    runOnUiThread(new Runnable() {
                                        public void run() {
                                            file2UploadPercentage.setValue(percentage);
                                        }
                                    });

                                }

                                @Override
                                public void onError() {
                                    // Handle any errors that occurred during the upload
                                }

                                @Override
                                public void onFinish() {
                                    // Hide the progress bar or text view
                                }
                            });


                            //Upload both the files
                            fileUploadService.uploadFile(file1URI, requestBody1).enqueue(callback);
                            fileUploadService.uploadFile(file2URI, requestBody2).enqueue(callback);
                        }));


    }


    public void startCameraConnectionInBackground() {

        InternetObservingSettings settings = InternetObservingSettings.builder()
                .host("http://192.168.42.1")
                .strategy(new SocketInternetObservingStrategy())
                .build();

        disposableBag.add(ReactiveNetwork
                .observeInternetConnectivity(settings)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(isConnectedToCameraWifi -> {
                    if (isConnectedToCameraWifi) {
                        InstaCameraManager.getInstance().openCamera(InstaCameraManager.CONNECT_TYPE_WIFI);
                    }
                }));
    }

    public void isVideoUploadedToConstra() {

    }

    public SingleLiveEvent<Boolean> getAreVideosDownloaded() {
        return areVideosDownloaded;
    }
    public void setAreVideosDownloaded(Boolean value){
        this.areVideosDownloaded.setValue(value);
    }

    public SingleLiveEvent<Boolean> isInternetConnectivityAvailable() {
        return isInternetConnectivityAvailable;
    }

    public SingleLiveEvent<Integer> getFile1UploadPercentage() {
        return file1UploadPercentage;
    }

    public SingleLiveEvent<Integer> getFile2UploadPercentage() {
        return file2UploadPercentage;
    }

    public SingleLiveEvent<Boolean> isUploadingDataToConstra() {
        return isUploadingDataToConstra;
    }

    public SingleLiveEvent<Boolean> getIsUploadComplete() {
        return isUploadComplete;
    }
}