package com.huviair.capture.ui.login;

/**
 * Class exposing authenticated user details to the UI.
 */
class LoggedInUserView {
    private final String displayName;
    private final String jwtToken;
    private final String email;

    LoggedInUserView(String displayName, String jwtToken, String email) {
        this.displayName = displayName;
        this.jwtToken = jwtToken;
        this.email = email;
    }

    String getDisplayName() {
        return displayName;
    }

    String getJwtToken() {
        return jwtToken;
    }

    public String getEmail() {
        return email;
    }
}