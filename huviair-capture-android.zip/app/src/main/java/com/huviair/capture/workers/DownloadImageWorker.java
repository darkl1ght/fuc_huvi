package com.huviair.capture.workers;

import android.app.Notification;
import android.content.Context;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ForegroundInfo;
import androidx.work.RxWorker;
import androidx.work.WorkerParameters;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.azure.AzureToken;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.database.InteriorWalkthrough;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.utils.UriUtils;

import java.io.FileNotFoundException;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.Single;
import io.reactivex.schedulers.Schedulers;

public class DownloadImageWorker extends RxWorker {

    private final DataCaptureRoomDatabase database;
    private final AtomicInteger atomicInteger = new AtomicInteger(0);
    private final APIService apiService;
    private int numberOfFloorPlans;

    /**
     * @param appContext   The application {@link Context}
     * @param workerParams Parameters to setup the internal state of this worker
     */
    public DownloadImageWorker(@NonNull Context appContext, @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);

        apiService = APIClient.createService(APIService.class, appContext, APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(appContext).getJwtToken());

        // Initialize database
        database = DataCaptureRoomDatabase.getDatabase(appContext);
    }

    @NonNull
    @Override
    public Single<Result> createWork() {
        try {
            String towerId = getInputData().getString(CommonConstants.TOWER_ID);
            String interiorId = getInputData().getString(CommonConstants.INTERIOR_TOUR_ID);
            String towerName = getInputData().getString(CommonConstants.TOWER_NAME);
            Data.Builder builder = new Data.Builder().putString(CommonConstants.TOWER_ID, towerId);

            Single<List<InteriorWalkthrough>> walkthroughsForTowerObservable = database.projectCacheDAO().getWalkthroughsForTowerObservable(interiorId, towerId);

            setForegroundAsync(createForegroundInfo(true, "Downloading floor plans for ".concat(towerName), towerId));


            return getFloorPlanObservable().flatMap(azureTokenResponse -> walkthroughsForTowerObservable.toObservable()
                    .flatMap(interiorWalkthroughs -> {
                        List<InteriorWalkthrough> filteredList = interiorWalkthroughs.stream().filter(walkthrough -> !CommonConstants.EMPTY_STRING.equals(walkthrough.getFloorPlanBlobId())).collect(Collectors.toList());
                        numberOfFloorPlans = filteredList.size();
                        return Observable.fromIterable(filteredList).flatMap(interiorWalkthrough -> downloadFileToLocalStorage(azureTokenResponse, interiorWalkthrough).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(4))),3);
                    }))
                    .doOnSubscribe(disposable -> setForegroundAsync(createForegroundInfo(true, "Downloading floor-plans for ".concat(towerName), towerId)))
                    .doOnNext(aerialImageResponse -> setForegroundAsync(createForegroundInfo(true, String.format(Locale.getDefault(), "Downloading floor-plans %d of %d", atomicInteger.incrementAndGet(), numberOfFloorPlans), towerId)))
                    .doOnComplete(() -> setForegroundAsync(createForegroundInfo(false, "Downloading floor-plans completed for ".concat(towerName), towerId)))
                    .doOnError(throwable -> setForegroundAsync(createForegroundInfo(false, "Downloading floor-plans failed ".concat(towerName), towerId + throwable.getMessage())))
                    .toList()
                    .map(aerialImageResponses -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.success(builder.build());
                    })
                    .onErrorReturn(throwable -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.failure(builder.build());
                    });
        } catch (Exception e) {
            e.printStackTrace();
            return Single.just(Result.failure());
        }
    }

    private Observable<AzureTokenResponse> getFloorPlanObservable() {
        return apiService.getAzureTokenByRequest(CommonConstants.FLOOR_PLAN).toObservable();
    }

    private Observable<Boolean> downloadFileToLocalStorage(AzureTokenResponse azureTokenResponse, InteriorWalkthrough walkthrough) {
        return Observable.fromCallable(() -> {
            AzureToken token = azureTokenResponse.getSasToken();
            String blobUrl = token.blobUrl(walkthrough.getFloorPlanBlobId(), CommonConstants.FLOOR_PLAN);
            try {
                Uri uri = UriUtils.downloadImageToLocalStorage(blobUrl, getApplicationContext(), walkthrough.getFloorPlanBlobId());
                if (uri != null) walkthrough.setFloorPlanPath(uri.getPath());
                // Update database with the path to the image
                database.projectCacheDAO().updateFloorPlanId(walkthrough.getFloorPlanPath(), walkthrough.getTourId());
                return true;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            return false;
        });
    }

    @NonNull
    private ForegroundInfo createForegroundInfo(boolean onGoing, @NonNull String message, @NonNull String towerId) {
        Notification foregroundNotification = WorkerUtils.getNotification(onGoing, CommonConstants.INTERIOR_DOWNLOAD_NOTIFICATION_TITLE, message, towerId, getApplicationContext());
        int notificationId = onGoing ? 1 : 2;
        return new ForegroundInfo(notificationId, foregroundNotification);
    }

    @NonNull
    @Override
    protected Scheduler getBackgroundScheduler() {
        return Schedulers.from(Executors.newFixedThreadPool(10));
    }

}


