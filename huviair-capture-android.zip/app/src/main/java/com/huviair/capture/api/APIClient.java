package com.huviair.capture.api;

import android.content.Context;

import com.huviair.capture.utils.RequestInterceptor;
import com.huviair.capture.utils.ResponseInterceptor;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class APIClient {

    // API Urls Constants
    private static final String SECURITY_API = "https://constra-api.huviair.com:3000/v1/security/api/";
    private static final String SECURITY_API_BASE_URL = "https://constra-api.huviair.com:3000/v1/security/api/users/login/";
//    private static final String SECURITY_API = "https://dev.huviair.com:5003/api/";
//    private static final String SECURITY_API_BASE_URL = "https://dev.huviair.com:5003/api/users/login/";
    private static final String PROJECT_API_BASE_URL = "https://constra-api.huviair.com:3000/v1/project/";
//    private static final String PROJECT_API_BASE_URL = "https://dev.huviair.com:4001/";
//    private static final String AZURE_BLOB_BASE_URL = "https://prodinspection.blob.core.windows.net/";
    private static final String AZURE_BLOB_BASE_URL = "https://huviairinspection.blob.core.windows.net/";
    private static final String THUMBNAIL_CONTAINER = "https://huviairinspection.blob.core.windows.net/rawdata-sm/";
    //    private static final String THUMBNAIL_CONTAINER = "https://prodinspection.blob.core.windows.net/rawdata-sm/";
    private static final String MEDIA_STREAMING_URL = "https://60a247b1bccb7.streamlock.net/huvi_prod_vod/_definst_/mp4:https/{player}/playlist.m3u8";

    private static final String INTERIOR_HELP_DOC_URL = "https://docs.google.com/viewer?url=https://huviair.com/wp-content/uploads/2022/05/Huviair-Capture-User-Guide.pdf";

    public static String getSecurityApiBaseUrl() {
        return SECURITY_API_BASE_URL;
    }

    public static String getSecurityApi() {
        return SECURITY_API;
    }

    public static String getAzureBlobBaseUrl() {
        return AZURE_BLOB_BASE_URL;
    }

    public static String getProjectApiBaseUrl() {
        return PROJECT_API_BASE_URL;
    }

    public static String getAzureBlobThumbnailContainer() {
        return THUMBNAIL_CONTAINER;
    }

    public static String getMediaVodStreamingUrl() {
        return MEDIA_STREAMING_URL;
    }

    public static String getInteriorHelpDocUrl() {
        return INTERIOR_HELP_DOC_URL;
    }

    // Retrofit configuration

    private static Retrofit retrofit = null;

    private static final Retrofit.Builder builder =
            new Retrofit.Builder()
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create());


    // Used for login without any interceptors
    public static <S> S createServiceForLogin(Class<S> serviceClass, String baseUrl) {
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        builder.client(httpClient.build());
        builder.baseUrl(baseUrl);
        retrofit = builder.build();
        return retrofit.create(serviceClass);
    }


    public static <S> S createService(Class<S> serviceClass, Context context, String baseUrl, String jwtToken) {
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder()
                .addInterceptor(new ResponseInterceptor(context))
                .addInterceptor(new RequestInterceptor(jwtToken));
        builder.client(httpClient.build());
        builder.baseUrl(baseUrl);
        retrofit = builder.build();
        return retrofit.create(serviceClass);
    }



    public static <S> S createUploadService(Class<S> serviceClass, Context context, String baseUrl) {
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder()
                .addInterceptor(new ResponseInterceptor(context));
        builder.client(httpClient.build());
        retrofit = builder.build();
        return retrofit.create(serviceClass);
    }
}


