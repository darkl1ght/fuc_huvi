package com.huviair.capture.ui.interiors.tours;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;

import androidx.core.content.ContextCompat;

import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import com.huviair.capture.R;
import com.huviair.capture.data.model.others.SavedFloorPlanPin;

import java.io.Serializable;
import java.util.ArrayList;


public class CircleMarkerView extends SubsamplingScaleImageView implements Serializable {

    // Paint objects
    private final Paint paint = new Paint();
    private final Paint alphaPaint = new Paint();
    private final Paint linePaint = new Paint();
    private final Path path = new Path();
    private int strokeWidth;

    // Items to render
    private ArrayList<SavedFloorPlanPin> sPin = new ArrayList<>();
    private ArrayList<SavedFloorPlanPin> oldTourPins = new ArrayList<>();
    private ArrayList<Coordinates> pinCoordinates = new ArrayList<>();
    private ArrayList<Coordinates> oldTourCoordinates = new ArrayList<>();

    public static final long CAPTURE_MARKER_RADIUS = 35;



    public ArrayList<SavedFloorPlanPin> getsPin() {
        return sPin;
    }

    public ArrayList<Coordinates> getPinCoordinates() {
        return pinCoordinates;
    }

    public void setsPin(ArrayList<SavedFloorPlanPin> sPin) {
        this.sPin = sPin;
    }

    public void setPinCoordinates(ArrayList<Coordinates> pinCoordinates) {
        this.pinCoordinates = pinCoordinates;
    }


    public CircleMarkerView(Context context) {
        this(context, null);
    }

    public CircleMarkerView(Context context, AttributeSet attr) {
        super(context, attr);
    }


    public void initialiseAndInvalidate() {
        invalidate();
    }

    public void populatePinCoordinates(SavedFloorPlanPin savedFloorPlanPin) {
        this.sPin.add(savedFloorPlanPin);
        this.pinCoordinates.add(new Coordinates(savedFloorPlanPin.getSavedPointOnFloorPlan().x,
                savedFloorPlanPin.getSavedPointOnFloorPlan().y));
    }

    public void populatePreviousPinCoordinates(SavedFloorPlanPin savedFloorPlanPin) {
        this.oldTourPins.add(savedFloorPlanPin);
        this.oldTourCoordinates.add(new Coordinates(savedFloorPlanPin.getSavedPointOnFloorPlan().x,
                savedFloorPlanPin.getSavedPointOnFloorPlan().y));
    }

    // Add a new pin object to the Image
    public void setPin(SavedFloorPlanPin savedFloorPlanPin) {
        this.sPin.add(savedFloorPlanPin);
        this.pinCoordinates.add(new Coordinates(savedFloorPlanPin.getSavedPointOnFloorPlan().x,
                savedFloorPlanPin.getSavedPointOnFloorPlan().y));
        invalidate();
    }

    //Clear existing image coordinates
    public void clearExistingImageCoordinates() {
        this.sPin.clear();
        this.pinCoordinates.clear();
    }

    //Clear existing image coordinates
    public void clearPreviousMarkers() {
       this.oldTourPins.clear();
       this.oldTourCoordinates.clear();
       invalidate();
    }

    // Remove any existing coordinates matching the incoming coordinates
    public boolean removePin(PointF point) {
        Coordinates removeCoordinate = new Coordinates(point.x, point.y);
        for (Coordinates coordinate : pinCoordinates) {
            if (coordinate.comparePoints(removeCoordinate)) {
                this.sPin.remove(pinCoordinates.indexOf(coordinate));
                pinCoordinates.remove(coordinate);
                invalidate();
                return true;
            }
        }
        return false;
    }

    public long getImageNumber(PointF point) {
        Coordinates removeCoordinate = new Coordinates(point.x, point.y);
        for (Coordinates coordinate : pinCoordinates) {
            if (coordinate.comparePoints(removeCoordinate)) {
                return sPin.get(pinCoordinates.indexOf(coordinate)).getSavedImageNumber();
            }
        }
        return -1;
    }

    public long getDisplayImageNumber(PointF point) {
        Coordinates removeCoordinate = new Coordinates(point.x, point.y);
        for (Coordinates coordinate : pinCoordinates) {
            if (coordinate.comparePoints(removeCoordinate)) {
                return sPin.get(pinCoordinates.indexOf(coordinate)).getImageNumberToDisplay();
            }
        }
        return -1;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Don't draw pin before image is ready so it doesn't move around during setup.
        if (!isReady()) {
            return;
        }

        paint.setAntiAlias(true);

        // Actual Markers
        sPin.stream().forEach(savedFloorPlanPin -> {
            if (savedFloorPlanPin.getSavedPointOnFloorPlan() != null) {
                paint.setColor(Color.parseColor("#0008C1"));
                PointF vPin = sourceToViewCoord(savedFloorPlanPin.getSavedPointOnFloorPlan());
                float vX = vPin.x ;
                float vY = vPin.y ;
                canvas.drawCircle(vX, vY, CAPTURE_MARKER_RADIUS, paint);

                // Use case to add a number with the marker (used in interiors tours)
                if (savedFloorPlanPin.getImageNumberToDisplay() != -1) {
                    paint.setColor(ContextCompat.getColor(getContext(), R.color.white));
                    paint.setTextSize(40f);

                    //this ensures X alignment
                    paint.setTextAlign(Paint.Align.CENTER);

                    // Measure the text rectangle to get the height
                    Rect result = new Rect();
                    paint.getTextBounds(String.valueOf(savedFloorPlanPin.getImageNumberToDisplay()), 0, String.valueOf(savedFloorPlanPin.getImageNumberToDisplay()).length(), result);
                    //take half the height as the offset
                    int yOffset = result.height()/2;

                    //add offset to ensure Y is aligned center
                    canvas.drawText(String.valueOf(savedFloorPlanPin.getImageNumberToDisplay()), vX, vY+yOffset, paint);
                }

            }
        });

        alphaPaint.setAntiAlias(true);
        linePaint.setAntiAlias(true);

        // Previous tour markers
        oldTourPins.stream().forEach(savedFloorPlanPin -> {
            if (savedFloorPlanPin.getSavedPointOnFloorPlan() != null) {
                alphaPaint.setColor(Color.parseColor("#66000000"));
                PointF vPin = sourceToViewCoord(savedFloorPlanPin.getSavedPointOnFloorPlan());
                float vX = vPin.x - (CAPTURE_MARKER_RADIUS / 2.5f);
                float vY = vPin.y - CAPTURE_MARKER_RADIUS;

                canvas.drawCircle(vX, vY, CAPTURE_MARKER_RADIUS, alphaPaint);

                // Use case to add a number with the marker (used in interiors tours)
                if (savedFloorPlanPin.getImageNumberToDisplay() != -1) {
                    alphaPaint.setColor(ContextCompat.getColor(getContext(), R.color.white));
                    alphaPaint.setTextSize(40f);

                    //this ensures X alignment
                    alphaPaint.setTextAlign(Paint.Align.CENTER);

                    // Measure the text rectangle to get the height
                    Rect result = new Rect();
                    alphaPaint.getTextBounds(String.valueOf(savedFloorPlanPin.getImageNumberToDisplay()), 0, String.valueOf(savedFloorPlanPin.getImageNumberToDisplay()).length(), result);
                    //take half the height as the offset
                    int yOffset = result.height()/2;

                    //add offset to ensure Y is aligned center
                    canvas.drawText(String.valueOf(savedFloorPlanPin.getImageNumberToDisplay()), vX, vY+yOffset, alphaPaint);
                }

            }
        });


        // Draw lines if minimum of two coordinate points are available
        if(oldTourCoordinates != null && oldTourCoordinates.size() >= 2){
            path.reset();
            for(int i=0 ; i < oldTourCoordinates.size() - 1; i++){
                float startingPointX = (float) oldTourCoordinates.get(i).getX();
                float startingPointY = (float) oldTourCoordinates.get(i).getY();
                float immediatePointX = (float) oldTourCoordinates.get(i+1).getX();
                float immediatePointY = (float) oldTourCoordinates.get(i+1).getY();

                PointF startingPointCoordinates = sourceToViewCoord(startingPointX, startingPointY);
                PointF immediatePointCoordinates = sourceToViewCoord(immediatePointX, immediatePointY);

                path.moveTo(startingPointCoordinates.x, startingPointCoordinates.y);
                path.lineTo(immediatePointCoordinates.x,immediatePointCoordinates.y);
            }
            path.close();
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeCap(Paint.Cap.ROUND);
            linePaint.setStrokeWidth(strokeWidth);
            linePaint.setColor(Color.LTGRAY);
            canvas.drawPath(path, linePaint);
        }

    }

}
