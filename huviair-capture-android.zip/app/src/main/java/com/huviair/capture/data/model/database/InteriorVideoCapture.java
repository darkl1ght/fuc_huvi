package com.huviair.capture.data.model.database;

import android.graphics.PointF;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.List;


@Entity(tableName = "INTERIOR_VIDEO_WALKTHROUGH")
public class InteriorVideoCapture {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "INTERIOR_ID")
    private String interiorId;
    @ColumnInfo(name = "TOWER_ID")
    private String towerId;
    @ColumnInfo(name = "WALKTHROUGH_ID")
    private String tourId;
    @ColumnInfo(name = "WALKTHROUGH_NAME")
    private String tourName;
    @ColumnInfo(name = "PROJECT_ID")
    private String projectId;
    @ColumnInfo(name = "IS_VIDEO_UPLOADED")
    private boolean isVideoUploaded;
    @ColumnInfo(name = "CAPTURE_START_POINT")
    @TypeConverters(PointFConverter.class)
    private PointF captureStartPoint;
    @ColumnInfo(name = "CAPTURE_END_POINT")
    @TypeConverters(PointFConverter.class)
    private PointF captureEndPoint;
    @ColumnInfo(name = "TIMELAPSE_VIDEO_URL")
    @TypeConverters(ListConverter.class)
    private List<String> timelapseVideoUrl;

    public InteriorVideoCapture(int id, String interiorId, String projectId, String tourId,
                                PointF captureStartPoint, PointF captureEndPoint,
                               List<String> timelapseVideoUrl, String towerId, String tourName, boolean isVideoUploaded) {
        this.id = id;
        this.interiorId = interiorId;
        this.projectId = projectId;
        this.tourId = tourId;
        this.captureStartPoint = captureStartPoint;
        this.captureEndPoint = captureEndPoint;
        this.timelapseVideoUrl = timelapseVideoUrl;
        this.towerId = towerId;
        this.tourName = tourName;
        this.isVideoUploaded = isVideoUploaded;
    }

    public void setCaptureStartPoint(PointF captureStartPoint) {
        this.captureStartPoint = captureStartPoint;
    }

    public void setCaptureEndPoint(PointF captureEndPoint) {
        this.captureEndPoint = captureEndPoint;
    }

    @Ignore
    public InteriorVideoCapture(String interiorId, String projectId, String tourId,
                                PointF captureStartPoint, PointF captureEndPoint,
                                List<String> timelapseVideoUrl, String towerId, String tourName, boolean isVideoUploaded) {
        this.interiorId = interiorId;
        this.projectId = projectId;
        this.tourId = tourId;
        this.captureStartPoint =captureStartPoint;
        this.captureEndPoint = captureEndPoint;
        this.timelapseVideoUrl = timelapseVideoUrl;
        this.towerId = towerId;
        this.tourName = tourName;
        this.isVideoUploaded = isVideoUploaded;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getTourId() {
        return tourId;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public void setInteriorId(String interiorId) {
        this.interiorId = interiorId;
    }

    public String getTowerId() {
        return towerId;
    }

    public void setTowerId(String towerId) {
        this.towerId = towerId;
    }

    public boolean isVideoUploaded() {
        return isVideoUploaded;
    }

    public void setVideoUploaded(boolean videoUploaded) {
        isVideoUploaded = videoUploaded;
    }

    public PointF getCaptureStartPoint() {
        return captureStartPoint;
    }


    public PointF getCaptureEndPoint() {
        return captureEndPoint;
    }

    public List<String> getTimelapseVideoUrl() {
        return timelapseVideoUrl;
    }

    public void setTimelapseVideoUrl(List<String> timelapseVideoUrl) {
        this.timelapseVideoUrl = timelapseVideoUrl;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    @Override
    public String toString() {
        return "InteriorVideoCapture{" +
                "id=" + id +
                ", interiorId='" + interiorId + '\'' +
                ", towerId='" + towerId + '\'' +
                ", tourId='" + tourId + '\'' +
                ", tourName='" + tourName + '\'' +
                ", projectId='" + projectId + '\'' +
                ", isVideoUploaded=" + isVideoUploaded +
                ", captureStartPoint=" + captureStartPoint +
                ", captureEndPoint=" + captureEndPoint +
                ", timelapseVideoUrl=" + timelapseVideoUrl +
                '}';
    }
}

