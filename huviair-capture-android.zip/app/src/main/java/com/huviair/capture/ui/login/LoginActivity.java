package com.huviair.capture.ui.login;

import android.app.Activity;

import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.huviair.capture.R;
import com.huviair.capture.databinding.ActivityLoginBinding;
import com.huviair.capture.ui.forgotPassword.ForgotPasswordActivity;
import com.huviair.capture.ui.projects.ProjectListActivity;
import com.huviair.capture.utils.SharedPreferencesManager;

public class LoginActivity extends AppCompatActivity {

    private LoginViewModel loginViewModel;
    private ActivityLoginBinding loginBinding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginBinding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(loginBinding.getRoot());

        loginViewModel = new ViewModelProvider(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        final TextInputLayout userNameInput = loginBinding.username;
        final EditText usernameEditText = userNameInput.getEditText();

        final TextInputLayout passwordInput = loginBinding.password;
        final EditText passwordEditText = passwordInput.getEditText();

        loginViewModel.getLoginFormState().observe(this, loginFormState -> {
            if (loginFormState == null) {
                return;
            }
            loginBinding.login.setEnabled(loginFormState.isDataValid());
            if (loginFormState.getUsernameError() != null) {
                userNameInput.setError(getString(loginFormState.getUsernameError()));
            } else userNameInput.setError(null);

            if (loginFormState.getPasswordError() != null) {
                passwordInput.setError(getString(loginFormState.getPasswordError()));
            } else passwordInput.setError(null);

        });

        loginViewModel.getLoginResult().observe(this, loginResult -> {
            if (loginResult == null) {
                return;
            }
            loginBinding.loading.setVisibility(View.GONE);
            loginBinding.login.setEnabled(true);

            if (loginResult.getError() != null) {
                showLoginFailed(loginResult.getError());
            }
            if (loginResult.getSuccess() != null) {
                // Save Jwt token and other details
                SharedPreferencesManager sharedPreferencesManager = new SharedPreferencesManager(LoginActivity.this);
                sharedPreferencesManager.userLogin(loginResult.getSuccess().getJwtToken(), loginResult.getSuccess().getEmail());
                sharedPreferencesManager.setAppOpenCount();

                updateUiWithUser(loginResult.getSuccess());
                setResult(Activity.RESULT_OK);
                //Complete and destroy login activity once successful
                finish();

            }

        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);

        passwordEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE && loginBinding.login.isEnabled()) {
                performLogin();
            }
            return false;
        });

        loginBinding.login.setOnClickListener(v -> performLogin());
        loginBinding.forgotPassword.setOnClickListener(v -> openForgotPasswordScreen());
    }

    private void  openForgotPasswordScreen() {
        // Open forgot password activity
        Intent intent = new Intent(this, ForgotPasswordActivity.class);
        startActivity(intent);
    }

    private void updateUiWithUser(LoggedInUserView model) {
        String loginSuccess = getString(R.string.hello) + model.getDisplayName();
        Toast.makeText(this, loginSuccess, Toast.LENGTH_SHORT).show();

        // Transfer to the ProjectsActivity
        Intent intent = new Intent(this, ProjectListActivity.class);
        startActivity(intent);
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        Snackbar.make(loginBinding.getRoot(), errorString, Snackbar.LENGTH_LONG)
                .setTextColor(ContextCompat.getColor(this, R.color.white))
                .setBackgroundTint(ContextCompat.getColor(this, R.color.login_text_error))
                .show();
    }

    // Perform login
    private void performLogin() {
        loginBinding.loading.setVisibility(View.VISIBLE);
        loginBinding.login.setEnabled(false);
        loginViewModel.login(loginBinding.username.getEditText().getText().toString(),
                loginBinding.password.getEditText().getText().toString());
    }

}