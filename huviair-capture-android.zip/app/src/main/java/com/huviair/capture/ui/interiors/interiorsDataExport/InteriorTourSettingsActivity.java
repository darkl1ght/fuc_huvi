package com.huviair.capture.ui.interiors.interiorsDataExport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.huviair.capture.R;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.databinding.ActivityInteriorTourStatisticsBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

public class InteriorTourSettingsActivity extends AppCompatActivity {

    private ActivityInteriorTourStatisticsBinding tourSettingsBinding;

    public static final String TOUR_ID = "TOUR_ID";
    public static final String INTERIOR_ID = "INTERIOR_ID";
    public static final String PROJECT_ID = "PROJECT_ID";

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();

    private List<TourDetails> tourDetails;

    // Tour Details Variables
    private String tourId;
    private String interiorId;
    private String projectId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tourSettingsBinding = ActivityInteriorTourStatisticsBinding.inflate(getLayoutInflater());
        setContentView(tourSettingsBinding.getRoot());

        if (getIntent().getExtras() != null) {
            tourId = getIntent().getStringExtra(TOUR_ID);
            interiorId = getIntent().getStringExtra(INTERIOR_ID);
            projectId = getIntent().getStringExtra(PROJECT_ID);
            if (tourId == null || interiorId == null || projectId == null) finish();
        }

        // Populate the tool bar
        MaterialToolbar toolbar = tourSettingsBinding.tourStatsToolBar.toolBar;
        toolbar.setTitle("Walk-through settings");
        setSupportActionBar(toolbar);

        populateDataFromLocalDB();

        clearDataOnCLick();

        tourSettingsBinding.tourStatsToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        tourSettingsBinding.tourStatsToolBar.toolBar.setNavigationOnClickListener(v -> onBackPressed());


        // Camera preview settings
        SharedPreferencesManager sharedPreferencesManager = new SharedPreferencesManager(this);
        tourSettingsBinding.virtualTourCameraPreview.setChecked(sharedPreferencesManager.isInstaCameraPreviewEnabled());
        tourSettingsBinding.virtualTourImageQuality.setChecked(sharedPreferencesManager.isHDQualityEnabled());

        tourSettingsBinding.virtualTourCameraPreview.setOnCheckedChangeListener((compoundButton, isChecked) -> {
            tourSettingsBinding.virtualTourCameraPreview.setChecked(isChecked);
            sharedPreferencesManager.setInstaCameraPreviewEnabled(isChecked);
            if( InstaCameraManager.CONNECT_TYPE_NONE != InstaCameraManager.getInstance().getCameraConnectedType()){
                InstaCameraManager.getInstance().closeCamera();
            }
        });

        tourSettingsBinding.virtualTourImageQuality.setOnCheckedChangeListener((compoundButton, isChecked) -> {
            tourSettingsBinding.virtualTourImageQuality.setChecked(isChecked);
            sharedPreferencesManager.setCaptureHDQualityEnabled(isChecked);
        });
    }

    private void clearDataOnCLick() {
        tourSettingsBinding.clearImportedImages.setOnClickListener(v ->
                new MaterialAlertDialogBuilder(this).setTitle("Clear images")
                        .setMessage(R.string.clear_walkthrough_images)
                        .setCancelable(true)
                        .setIcon(R.drawable.delete_brand_color)
                        .setPositiveButton("OK", (dialog, which) -> removeAllImages())
                        .setNegativeButton("CANCEL", (dialog, which) -> {
                        })
                        .show());

        tourSettingsBinding.clearWalkthroughData.setOnClickListener(v ->
                new MaterialAlertDialogBuilder(this).setTitle("Clear walk through data")
                        .setMessage(R.string.clear_walkthrough_images_data)
                        .setCancelable(true)
                        .setIcon(R.drawable.delete_brand_color)
                        .setPositiveButton("OK", (dialog, which) -> deleteWalkthroughDetails())
                        .setNegativeButton("CANCEL", (dialog, which) -> {
                        })
                        .show());
    }

    private void deleteWalkthroughDetails() {
        removeAllImages();
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(this);
        compositeDisposable.add(
                database.tourDetailsDAO().deleteWalkThrough(tourId)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .doOnError(throwable -> Toast.makeText(this, "Error in clearing details...", Toast.LENGTH_SHORT).show())
                        .subscribe(() -> Toast.makeText(this, "Walk through details removed successfully...", Toast.LENGTH_SHORT).show()));

    }

    private void removeAllImages() {
        String[] importedImageUrls = getAllImportedImages().toArray(String[]::new);
        String[] hdrImageUrls = getAllHDRImages().toArray(String[]::new);
        String[] stitchedImageUrls = getStitchedImages().toArray(String[]::new);

        if (importedImageUrls.length == 0 && hdrImageUrls.length == 0 && stitchedImageUrls.length == 0) {
            Toast.makeText(this, "No data available..", Toast.LENGTH_SHORT).show();
            return;
        }

        Observable<Boolean> deleteImportedImages = Observable.fromArray(importedImageUrls).flatMap(url -> Observable.just(new File(url).delete()))
                .flatMap(aBoolean -> Observable.fromArray(hdrImageUrls).flatMap(url -> Observable.just(new File(url).delete())))
                .flatMap(aBoolean -> Observable.fromArray(stitchedImageUrls).flatMap(url -> Observable.just(new File(url).delete())));


        compositeDisposable.add(deleteImportedImages.observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .doOnError(throwable -> Toast.makeText(this, "Error in clearing images", Toast.LENGTH_SHORT).show())
                .doOnComplete(() -> Toast.makeText(this, "Cleared Images Successfully", Toast.LENGTH_SHORT).show())
                .subscribe(isCompleted -> {
                }));
    }

    private void populateDataFromLocalDB() {

        getImagesCapturedCount();
        getDetailsFromTheDeviceFolder();

    }

    private void getImagesCapturedCount() {
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(this);
        compositeDisposable.add(
                database.tourDetailsDAO().getLastInsertedWalkThroughCount(tourId)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe((count, throwable) -> tourSettingsBinding.imagesCountValue.setText(String.valueOf(count)))
        );

    }

    private void getDetailsFromTheDeviceFolder() {
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(this);
        compositeDisposable.add(
                database.tourDetailsDAO().getAllTourDetails(tourId)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe((tourDetails, throwable) -> {
                            if (tourDetails != null && !tourDetails.isEmpty()) {
                                enableTourDetails();
                                this.tourDetails = tourDetails;
                                calculateFilesStatistics(tourDetails);
                            } else tourSettingsBinding.noTourStats.setVisibility(View.VISIBLE);
                        })

        );
    }

    private void enableTourDetails() {
        tourSettingsBinding.tourStatsCardView.setVisibility(View.VISIBLE);
        tourSettingsBinding.walkthroughSettings.setVisibility(View.VISIBLE);
        tourSettingsBinding.clearImportedImages.setVisibility(View.VISIBLE);
        tourSettingsBinding.clearWalkthroughData.setVisibility(View.VISIBLE);
        tourSettingsBinding.divider2.setVisibility(View.VISIBLE);


    }

    private void calculateFilesStatistics(List<TourDetails> walkthroughs) {
        // Remove any image url = null and further split the image urls by "," and get the array of image URLS
        long importedImagesCount = getAllImportedImages().count();

        long totalImagesCount = walkthroughs.stream().filter(individualRow -> individualRow.getImageUrl() != null)
                .map(TourDetails::getImageUrl)
                .map(urls -> urls.split(","))
                .flatMap(Arrays::stream)
                .count();

        tourSettingsBinding.imagesImportedCount.setText(String.valueOf(importedImagesCount).concat("/").concat(String.valueOf(totalImagesCount)));


        long hdrGeneratedImages = getAllHDRImages().count();

        tourSettingsBinding.imagesGeneratedCount.setText(String.valueOf(hdrGeneratedImages));

        long stitchedImages = getStitchedImages().count();

        tourSettingsBinding.imagesStitchedCount.setText(String.valueOf(stitchedImages));

        tourSettingsBinding.imagesPublishedCount.setText(walkthroughs.get(0).isWalkThroughUploaded() ? "Yes" : "No");


    }

    private Stream<String> getAllImportedImages() {
        return tourDetails.stream().filter(individualRow -> individualRow.getImageUrl() != null)
                .map(TourDetails::getImageUrl)
                .map(urls -> urls.split(","))
                .flatMap(Arrays::stream)
                .map(s -> s.replace(s.substring(0, s.lastIndexOf("/")), getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER))
                .filter(url -> new File(url).exists());

    }

    private Stream<String> getAllHDRImages() {
        return tourDetails.stream().filter(individualRow -> individualRow.getImageUrl() != null)
                .filter(walkThrough -> walkThrough.getHdrImageFileName() != null)
                .map(TourDetails::getHdrImageFileName)
                .filter(url -> new File(url).exists());
    }

    private Stream<String> getStitchedImages() {
        return tourDetails.stream().filter(individualRow -> individualRow.getImageUrl() != null)
                .filter(walkThrough -> walkThrough.getHdrExportFileName() != null)
                .map(TourDetails::getHdrExportFileName)
                .filter(url -> new File(url).exists());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.tour_settings_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@androidx.annotation.NonNull MenuItem item) {
        if (item.getItemId() == R.id.publish_walkthrough_manually) {
            Intent intent = new Intent(this, TourDataTransferFragmentActivity.class);
            intent.putExtra(TourDataTransferFragmentActivity.TOUR_ID, tourId);
            intent.putExtra(TourDataTransferFragmentActivity.INTERIOR_ID, interiorId);
            intent.putExtra(TourDataTransferFragmentActivity.PROJECT_ID,projectId);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
        }
    }
}