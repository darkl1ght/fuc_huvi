package com.huviair.capture.ui.interiors.interiorsDataExport.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.arashivision.sdkmedia.export.ExportImageParamsBuilder;
import com.arashivision.sdkmedia.export.ExportUtils;
import com.arashivision.sdkmedia.export.IExportCallback;
import com.arashivision.sdkmedia.work.WorkWrapper;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.databinding.FragmentStitchHdrImagesBinding;
import com.huviair.capture.ui.interiors.interiorsDataExport.TourDataTransferFragmentActivity;
import com.huviair.capture.utils.CommonConstants;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link StitchHDRImagesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class StitchHDRImagesFragment extends Fragment implements IExportCallback {

    public static final String TOUR_ID = "TOUR_ID";
    private static String COMPLETED_IMAGE_PATH, HDR_FOLDER_PATH = null;
    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    AtomicInteger successfulCount = new AtomicInteger(0);
    AtomicInteger imageExportCount = new AtomicInteger(0);
    private FragmentStitchHdrImagesBinding stitchHdrImagesBinding;
    private List<TourDetails> tourDetailsFromDB;
    private String tourId;

    public StitchHDRImagesFragment() {
        // Required empty public constructor
    }

    public static StitchHDRImagesFragment newInstance(String tourId) {
        StitchHDRImagesFragment fragment = new StitchHDRImagesFragment();
        Bundle args = new Bundle();
        args.putString(TOUR_ID, tourId);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        stitchHdrImagesBinding = FragmentStitchHdrImagesBinding.inflate(inflater, container, false);
        return stitchHdrImagesBinding.getRoot();
    }

    @Override
    public void onViewCreated(@androidx.annotation.NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //Initialize folder paths
        COMPLETED_IMAGE_PATH = requireContext().getFilesDir() + "/" + CommonConstants.COMPLETED_IMAGES_FOLDER;
        HDR_FOLDER_PATH = requireContext().getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            tourId = getArguments().getString(TOUR_ID);
        }
    }


    @Override
    public void onStart() {
        super.onStart();

        View view = getView();
        if (view != null) {
            stitchHdrImagesBinding.stitchImagesButton.setOnClickListener(v -> prepareImagesForHDRExport(tourId));
            stitchHdrImagesBinding.nextPagePublish.setOnClickListener(v -> ((TourDataTransferFragmentActivity) requireActivity()).jumpToNextPage(view));
            stitchHdrImagesBinding.previousPageGenerate.setOnClickListener(v -> ((TourDataTransferFragmentActivity) requireActivity()).jumpToPreviousPage(view));
        }
    }

    private void prepareImagesForHDRExport(String tourId) {
        enableProgressItems();

        // Start db operations and HDR export
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(getContext());
        Single<List<TourDetails>> fetchTours = database.tourDetailsDAO().getWalkThroughForHdrGenerate(tourId);

        compositeDisposable.add(
                fetchTours.observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.io())
                        .subscribe(tourDetails -> {
                            if (!tourDetails.isEmpty()) {
                                tourDetailsFromDB = tourDetails;

                                stitchHdrImagesBinding.stitchImagesButton.setEnabled(false);
                                // Emit tour details as observable
                                Observable.fromIterable(tourDetails)
                                        .map(this::transformTours)
                                        .flatMap(tourDetailsFromDB -> stitchHDRImages(tourDetailsFromDB).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(4))), 2)
                                        .observeOn(AndroidSchedulers.mainThread())
                                        .subscribe(new Observer<Boolean>() {
                                            @Override
                                            public void onSubscribe(@NonNull Disposable d) {
                                                compositeDisposable.add(d);
                                            }

                                            @Override
                                            public void onNext(@NonNull Boolean aBoolean) {
                                                successfulCount.incrementAndGet();
                                                stitchHdrImagesBinding.stitchImagesTextView.setText(getString(R.string.stitch_status_queued, successfulCount.intValue(), tourDetails.size()));
                                            }

                                            @Override
                                            public void onError(@NonNull Throwable e) {
                                                stitchHdrImagesBinding.stitchImagesButton.setEnabled(true);
                                                Snackbar.make(stitchHdrImagesBinding.getRoot(), R.string.technical_error, Snackbar.LENGTH_INDEFINITE)
                                                        .setAction("RETRY", v -> prepareImagesForHDRExport(tourId))
                                                        .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                                        .show();
                                            }

                                            @Override
                                            public void onComplete() {
                                                successfulCount.set(0);
                                            }
                                        });
                            } else {
                                Snackbar.make(stitchHdrImagesBinding.getRoot(), "No images associated with the selected walk-through..", Snackbar.LENGTH_LONG)
                                        .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                        .show();
                            }

                        }));
    }

    private void enableProgressItems() {
        stitchHdrImagesBinding.stitchImagesTextView.setVisibility(View.VISIBLE);
        stitchHdrImagesBinding.stitchImagesTextView.setText("");
    }

    private Observable<Boolean> stitchHDRImages(TourDetails tourDetails) {
        return Observable.fromCallable(() -> {
            WorkWrapper wrapper = new WorkWrapper(tourDetails.getImageUrlsSplit());
            String finalImagePath = COMPLETED_IMAGE_PATH + "/" + "IMAGE_" + tourDetails.getImageNumber() + "_" + UUID.randomUUID() + ".jpg";

            // Stitch images only if HDR file exists and export file doesn't exist
            if (new File(tourDetails.getHdrImageFileName()).exists() && (tourDetails.getHdrExportFileName() == null || !new File(tourDetails.getHdrExportFileName()).exists())) {
                ExportImageParamsBuilder builder = new ExportImageParamsBuilder()
                        .setExportMode(ExportUtils.ExportMode.PANORAMA)
                        .setTargetPath(finalImagePath)
                        .setUrlForExport(tourDetails.getHdrImageFileName());

                ExportUtils.exportImage(wrapper, builder, this);
                DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(requireContext());
                database.tourDetailsDAO().updateWalkThroughHdrExport(tourDetails.getTourId(), finalImagePath, tourDetails.getId()).subscribe();
                return true;
            }
            return true;
        });

    }


    private TourDetails transformTours(TourDetails tourDetails) {
        String[] tourImageUrls = tourDetails.getImageUrl().split(",");
        for (int i = 0; i < tourImageUrls.length; i++) {
            tourImageUrls[i] = tourImageUrls[i].replace(tourImageUrls[i].substring(0, tourImageUrls[i].lastIndexOf("/")), HDR_FOLDER_PATH);
        }
        tourDetails.setImageUrlsSplit(tourImageUrls);
        return tourDetails;
    }

    // Callback for export/Generating images
    @Override
    public void onSuccess() {
        imageExportCount.incrementAndGet();
        stitchHdrImagesBinding.stitchImagesTextView.setText(getString(R.string.stitch_status_completed, imageExportCount.intValue(), tourDetailsFromDB.size()));

        // Enable the button once all images are stitched
        if (imageExportCount.intValue() == tourDetailsFromDB.size()) {
            stitchHdrImagesBinding.stitchImagesButton.setEnabled(true);
        }
    }

    @Override
    public void onFail(int i, String s) {
        Toast.makeText(requireContext(), "Oops something went wrong...", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCancel() {

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (stitchHdrImagesBinding != null) {
            stitchHdrImagesBinding = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (!compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
        }
    }
}