package com.huviair.capture.data.repositories;

import android.app.Application;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.api.SnagsAPIService;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.snags.ApproverDetails;
import com.huviair.capture.data.model.api.snags.CreateSnagRequest;
import com.huviair.capture.data.model.api.snags.CreateOnsiteSnagRequest;
import com.huviair.capture.data.model.api.snags.PunchListIdResponse;
import com.huviair.capture.data.model.api.snags.SavedSnagResponse;
import com.huviair.capture.data.model.api.snags.SnagDashboardDetails;
import com.huviair.capture.data.model.api.snags.SnagMasterDataResponse;
import com.huviair.capture.data.model.api.snags.SnagMedia;
import com.huviair.capture.data.model.api.snags.SnagMediaFloorPlan;
import com.huviair.capture.data.model.api.snags.SnagsMediaDeleteResponse;
import com.huviair.capture.data.model.api.snags.SnagsMediaResponse;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class SnagsRepository {

    private final SnagsAPIService snagsAPIService;
    private final APIService commonApiService;

    public SnagsRepository(Application application) {
        snagsAPIService = APIClient.createService(SnagsAPIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());

        commonApiService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());
    }

    public Single<SnagDashboardDetails> getSnagDashboardDetails(String projectId) {
        return snagsAPIService.getSnagDashboardDetails(projectId);

    }

    public Single<SavedSnagResponse> saveSnagApproverDetails(String projectId, String level, String taskId, ApproverDetails approverDetails) {
        Map<String, ApproverDetails> requestBody = new HashMap<>();
        requestBody.put("taskStatus", approverDetails);
        return snagsAPIService.saveSnagLevelStatus(projectId, level, taskId, requestBody);
    }

    public Completable saveSnagFloorPlanFeatures(String projectId, String taskId, SnagMediaFloorPlan floorPlan) {
        Map<String, SnagMediaFloorPlan> requestBody = new HashMap<>();
        requestBody.put("floorPlan", floorPlan);
        return snagsAPIService.saveSnagFloorPlanFeatures(projectId, taskId, requestBody);
    }

    public Single<AzureTokenResponse> getAzureWritePermissionToken() {
        return commonApiService.getAzureTokenWritePermission(CommonConstants.MEDIA)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Single<SnagsMediaResponse> uploadSnagMedia(String projectId, String taskId, SnagMedia media) {
        Map<String, SnagMedia> requestBody = new HashMap<>();
        requestBody.put("media", media);
        return snagsAPIService.uploadSnagMediaToBackend(projectId, taskId, requestBody);
    }

    public Completable deleteSnag(String projectId, String taskId) {
        return snagsAPIService.deleteSnag(projectId, taskId);
    }
    public Single<SnagsMediaDeleteResponse> deleteSnagMedia(String projectId, String taskId, Map<String, List<String>> mediaToDelete) {
        return snagsAPIService.deleteSnagMedia(projectId, taskId,mediaToDelete).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io());
    }

    public Single<SnagMasterDataResponse> getSnagsMasterData(String projectId) {
        return snagsAPIService.getSnagMasterDataForProject(projectId);
    }

    public Completable createSnag(String projectId, CreateSnagRequest request) {
        return snagsAPIService.createSnag(projectId, request);
    }

    public Completable createOnsiteSnag(String projectId, CreateOnsiteSnagRequest request) {
        return snagsAPIService.createOnsiteSnag(projectId, request);
    }

    public Completable updateSnag(String projectId, String taskId, SavedSnagResponse snag) {
        return snagsAPIService.updateSnagDetails(projectId, taskId, snag);
    }

    public Single<PunchListIdResponse> getPunchListIdsForProject(String projectId) {
        return snagsAPIService.getPunchIdsForTheProject(projectId);
    }

}
