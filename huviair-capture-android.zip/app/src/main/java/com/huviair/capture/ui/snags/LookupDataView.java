package com.huviair.capture.ui.snags;

import com.huviair.capture.data.model.api.lookups.Lookup;

import java.util.List;

public class LookupDataView {
    private final List<Lookup> lookupList;

    public LookupDataView(List<Lookup> lookups) {
        this.lookupList = lookups;
    }

    public List<Lookup> getLookupList() {
        return lookupList;
    }
}
