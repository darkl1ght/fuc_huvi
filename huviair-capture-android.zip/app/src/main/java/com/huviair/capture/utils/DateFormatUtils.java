package com.huviair.capture.utils;

import android.text.format.DateFormat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateFormatUtils {

    public static String convertDate(Long dateInMilliseconds, String format) {
        return new SimpleDateFormat(format, Locale.getDefault()).format(new Date(dateInMilliseconds));
    }

    public static String getCurrentDateInMongoFormat() {
        return new SimpleDateFormat(CommonConstants.MONGO_DATE_FORMAT, Locale.getDefault()).format(new Date());
    }

    public static String parseDateInRequiredFormat(String val, String outputFormatType) {
        try {
            Date inputDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault()).parse(val);
            return DateFormat.format(outputFormatType, inputDate).toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String parseDateWithTimeZone(String val, String outputFormatType) {
        try {
            SimpleDateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault());
            simpleDateFormat.setTimeZone( TimeZone.getTimeZone("UTC"));
            Date inputDate = simpleDateFormat.parse(val);
            return DateFormat.format(outputFormatType, inputDate).toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
    public static String parseExifDateInRequiredFormat(String val, String outputFormatType) {
        try {
            Date inputDate = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.getDefault()).parse(val);
            return DateFormat.format(outputFormatType, inputDate).toString().replace(".SSS", ".000");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String parseDate(String createDate) {
        String parsedDate = "";
        if (createDate != null) {
            if (createDate.contains("Z")) {
                parsedDate = parseDateInRequiredFormat(createDate, "MMM d, yyyy");
            } else {
                parsedDate = parseExifDateInRequiredFormat(createDate, "MMM d, yyyy");
            }
        }
        return parsedDate;
    }

}
