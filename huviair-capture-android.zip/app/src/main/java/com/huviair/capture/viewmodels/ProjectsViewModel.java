package com.huviair.capture.viewmodels;

import android.app.Application;
import android.provider.Settings;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.messaging.FirebaseMessaging;
import com.huviair.capture.R;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.Notification;
import com.huviair.capture.data.model.api.SendLogRequest;
import com.huviair.capture.data.model.database.AuditLog;
import com.huviair.capture.data.model.database.Project;
import com.huviair.capture.data.model.others.DataSyncStatus;
import com.huviair.capture.data.repositories.AuditLogsRepository;
import com.huviair.capture.data.repositories.ProjectsRepository;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.ui.projects.ProjectDataView;
import com.huviair.capture.ui.projects.ProjectResult;
import com.huviair.capture.utils.NetworkListener;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.utils.SingleLiveEvent;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableCompletableObserver;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class ProjectsViewModel extends AndroidViewModel {
    private static final String APP_TYPE_CAPTURE = "APP001";

    public final SingleLiveEvent<Boolean> isNoDataConnection = new SingleLiveEvent<>();
    public final SingleLiveEvent<DataSyncStatus> syncStatusLiveEvent = new SingleLiveEvent<>();
    public final SingleLiveEvent<Boolean> isMessagingTokenDeleted = new SingleLiveEvent<>();
    private final ProjectsRepository projectsRepository;
    private final AuditLogsRepository auditLogsRepository;
    private final DataCaptureRoomDatabase database;
    private final CompositeDisposable disposableBag = new CompositeDisposable();
    private final MutableLiveData<ProjectResult> projectLiveData = new MutableLiveData<>();
    private final APIService apiService;
    private final String androidUniqueDeviceId;


    public ProjectsViewModel(@NonNull Application application) {
        super(application);
        projectsRepository = new ProjectsRepository(application);
        auditLogsRepository = new AuditLogsRepository(application);
        database = DataCaptureRoomDatabase.getDatabase(application);

        apiService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());

        androidUniqueDeviceId = Settings.Secure.getString(application.getContentResolver(), Settings.Secure.ANDROID_ID);
    }


    public LiveData<ProjectResult> getProjectLiveData() {
        return projectLiveData;
    }

    public void fetchProjectsFromBackend() {

        disposableBag.add(NetworkListener.hasInternetConnection(getApplication()).subscribe(hasInternet -> {
            if (!hasInternet) {
                isNoDataConnection.setValue(true);
                database.projectCacheDAO().getAllProjects()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new DisposableSingleObserver<List<Project>>() {
                            @Override
                            public void onSuccess(@io.reactivex.annotations.NonNull List<Project> projects) {
                                if (projects.size() > 0) {
                                    List<com.huviair.capture.data.model.api.projects.Project> projectDetails = projects.stream().map(projectFromDB -> new com.huviair.capture.data.model.api.projects.Project(projectFromDB.getProjectName(),
                                            projectFromDB.getProjectId(), projectFromDB.getLocation(),
                                            projectFromDB.getType(),projectFromDB.getAllowedVideoCaptureTime())).collect(Collectors.toList());

                                    projectLiveData.setValue(new ProjectResult(new ProjectDataView(projectDetails)));
                                }
                            }

                            @Override
                            public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                            }
                        });


            } else {
                checkForInternetAndPopulate();
            }
        }));

    }

    private void checkForInternetAndPopulate() {

        disposableBag.add(NetworkListener.hasInternetConnection(getApplication()).subscribe((hasInternet) -> {
            if (hasInternet) {
                DataSyncStatus dataSyncStatus = new DataSyncStatus();
                dataSyncStatus.setDataSyncInProgress(true);
                dataSyncStatus.setCurrentStep("Syncing Projects...");

                syncStatusLiveEvent.setValue(dataSyncStatus);

                disposableBag.add(projectsRepository.fetchProjects()
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.io())
                        .subscribe(projects -> {
                                    // edit db
                                    populateProjectsToDataBase(projects.getProjects());

                                    dataSyncStatus.setCurrentStep("Projects Sync Complete");
                                    dataSyncStatus.setDataSyncComplete(true);
                                    dataSyncStatus.setDataSyncInProgress(false);

                                    syncStatusLiveEvent.setValue(dataSyncStatus);
                                    projectLiveData.setValue(new ProjectResult(new ProjectDataView(projects.getProjects())));
                                },
                                throwable -> {
                                    dataSyncStatus.setDataSyncInProgress(false);
                                    projectLiveData.setValue(new ProjectResult(R.string.technical_error));
                                }));

            } else {
                isNoDataConnection.setValue(true);
            }
        }));

    }

    private void populateProjectsToDataBase(List<com.huviair.capture.data.model.api.projects.Project> projects) {
        List<com.huviair.capture.data.model.api.projects.Project> transformedProjects = projects.stream().map((project -> {
            if (project.getVirtualVideoCaptureDurationLimit() == 0) {
                project.setVirtualVideoCaptureDurationLimit(14);
            }
            return project;
        })).collect(Collectors.toList());

        Project[] projectsToPersist = transformedProjects.stream().map(project -> new Project(project.getProjectName(), project.getProjectId(), project.getLocation(), project.getType(), project.getVirtualVideoCaptureDurationLimit())).toArray(Project[]::new);

        // Delete existing projects and add new projects
        database.projectCacheDAO().deleteProjects()
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().insertProjects(projectsToPersist)))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.single()).subscribe();
    }

    public void saveMessagingToken() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }

                    // Get new FCM registration token
                    String token = task.getResult();

                    apiService.saveMessagingToken(APP_TYPE_CAPTURE, new Notification(token, androidUniqueDeviceId)).subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(new DisposableCompletableObserver() {
                                @Override
                                public void onComplete() {
                                    // do nothing
                                }

                                @Override
                                public void onError(@NonNull Throwable e) {
                                    // do nothing
                                }
                            });
                });


    }

    @Override
    protected void onCleared() {
        super.onCleared();
    }
    public void sendLogToDatabase(String userEmail) {

        disposableBag.add(NetworkListener.hasInternetConnection(getApplication()).subscribe(hasInternet -> {
            if (hasInternet) {

                database.auditLogsDAO().getAllLogs()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new DisposableSingleObserver<List<AuditLog>>() {
                            @Override
                            public void onSuccess(@io.reactivex.annotations.NonNull List<AuditLog> auditLogs) {
                               try {
                                   if (auditLogs.size() > 0) {
                                       List<com.huviair.capture.data.model.api.AuditLog> logDetails = auditLogs.stream().map(logFromDB -> new com.huviair.capture.data.model.api.AuditLog(logFromDB.getTourId(),
                                               logFromDB.getType(), logFromDB.getMethod(),
                                               logFromDB.getLogDate(), logFromDB.getLogInfo())).collect(Collectors.toList());
                                       Log.d("counter", String.valueOf(logDetails.size()));

                                       apiService.sendLogs(new SendLogRequest(userEmail,
                                                       logDetails)).subscribeOn(Schedulers.io())
                                               .observeOn(AndroidSchedulers.mainThread())
                                               .subscribe();

                                   }
                               } catch(Exception ex){
                                   Log.e("error while sending logs",ex.getMessage());
                               }
                            }

                            @Override
                            public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                                Log.e("error while sending logs",e.getMessage());
                            }
                        });


            }

        }));

    }
    public Completable clearAllDatabaseDetails() {
        return database.projectCacheDAO().deleteProjects()
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().deleteAllInteriors()))
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().deleteAllInteriorTowers()))
                .andThen(Completable.fromAction(() -> database.projectCacheDAO().deleteAllWalkthroughs()))
                .andThen(Completable.fromAction(() -> database.auditLogsDAO().deleteLogs()))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io());
    }

    public void deleteFCMTokenFromBackend() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }
                    // Get new FCM registration token
                    String token = task.getResult();

                    apiService.deleteMessagingToken(APP_TYPE_CAPTURE, token, androidUniqueDeviceId).subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(new DisposableCompletableObserver() {
                                @Override
                                public void onComplete() {
                                    isMessagingTokenDeleted.setValue(true);
                                }

                                @Override
                                public void onError(@NonNull Throwable e) {
                                    isMessagingTokenDeleted.setValue(false);
                                }
                            });
                });
    }
}
