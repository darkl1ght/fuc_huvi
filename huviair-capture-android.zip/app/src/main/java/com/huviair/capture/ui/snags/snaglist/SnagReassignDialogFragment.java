//package com.huviair.capture.ui.snags.snaglist;
//
//import android.content.DialogInterface;
//import android.os.Bundle;
//import android.text.Editable;
//import android.text.TextWatcher;
//import android.util.SparseBooleanArray;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.view.WindowManager;
//import android.view.inputmethod.EditorInfo;
//import android.widget.ArrayAdapter;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AlertDialog;
//import androidx.core.content.ContextCompat;
//import androidx.fragment.app.DialogFragment;
//import androidx.fragment.app.Fragment;
//import androidx.lifecycle.ViewModelProvider;
//
//import com.google.android.material.chip.Chip;
//import com.google.android.material.datepicker.MaterialDatePicker;
//import com.google.android.material.dialog.MaterialAlertDialogBuilder;
//import com.huviair.capture.R;
//import com.huviair.capture.data.model.api.LoggedInUser;
//import com.huviair.capture.data.model.api.UsersResponse;
//import com.huviair.capture.data.model.api.lookups.Lookup;
//import com.huviair.capture.data.model.api.snags.SavedSnagResponse;
//import com.huviair.capture.data.model.api.snags.Snag;
//import com.huviair.capture.data.model.api.snags.TaskPriority;
//import com.huviair.capture.data.model.api.snags.WorkPackage;
//import com.huviair.capture.databinding.FragmentSnagReassignDialogBinding;
//import com.huviair.capture.databinding.FragmentSnagUpdateDialogBinding;
//import com.huviair.capture.utils.CommonConstants;
//import com.huviair.capture.utils.DateFormatUtils;
//import com.huviair.capture.viewmodels.SnagListItemModel;
//import com.huviair.capture.viewmodels.UpdateSnagViewModel;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//import java.util.stream.Collectors;
//
///**
// * A simple {@link Fragment} subclass.
// * Use the {@link SnagReassignDialogFragment#newInstance} factory method to
// * create an instance of this fragment.
// */
//public class SnagReassignDialogFragment extends DialogFragment {
//
//    private static final String SNAG = "SNAG";
//    private Snag selectedSnag;
//    private FragmentSnagReassignDialogBinding snagReassignDialogBinding;
//    private SnagListItemModel snagListItemModel;
//    private String selectedDateValue;
//
//    //Common tags for media upload
//    private List<Chip> tags = new ArrayList<>();
//    private List<Lookup> lookups;
//
//
//    public SnagReassignDialogFragment() {
//        // Required empty public constructor
//    }
//
//    public static SnagReassignDialogFragment newInstance(Snag selectedSnag) {
//        SnagReassignDialogFragment fragment = new SnagReassignDialogFragment();
//        Bundle args = new Bundle();
//        args.putSerializable(SNAG, selectedSnag);
//        fragment.setArguments(args);
//        return fragment;
//    }
//
//    @Override
//    public void onStart() {
//        super.onStart();
//        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            selectedSnag = (Snag) getArguments().getSerializable(SNAG);
//
//        }
//    }
//
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        snagReassignDialogBinding = FragmentSnagReassignDialogBinding.inflate(inflater, container,false);
//        return snagReassignDialogBinding.getRoot();
//    }
//
//    @Override
//    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//
//        // Call the parent view model
//        snagListItemModel = new ViewModelProvider(requireParentFragment()).get(SnagListItemModel.class);
//
//        populateExistingValues();
//        snagListItemModel.getUsersAssociatedToTheProject(selectedSnag.getProjectId());
//
//
//        observeForUsersResult();
//
//        snagReassignDialogBinding.snagLevel1ApproversEditText.setOnClickListener(v -> {
////            showMultiSelectUsersDialog();
//        });
//    }
//
//    private void populateExistingValues() {
//         if(selectedSnag.getLevel1Users() != null &&  snagListItemModel.getUsersResponse() != null){
//             Arrays.stream(selectedSnag.getLevel1Users()).flatMap( userEmail -> snagListItemModel.getUsersResponse().getUsers()
//             .stream().filter(user -> user.getEmail().equals(userEmail))).toArray(String::new);
//            snagReassignDialogBinding.snagLevel1ApproversEditText.setText();
//         }
//    }
//
//    private void showMultiSelectUsersDialog(UsersResponse usersResponse) {
//        boolean[] selectedUsers = snagListItemModel.getSelectedUsers();
//        List<String> users = usersResponse.getUsers().stream().map(user -> user.getFirstName() + " " + user.getLastName()).collect(Collectors.toList());
//
//        new MaterialAlertDialogBuilder(requireContext())
//                    .setTitle("Select Users")
//                    .setIcon(R.drawable.edit_icon)
//                    .setPositiveButton("Save",
//                            (DialogInterface dialog, int which) -> {
//                                SparseBooleanArray checkedItemPositions = ((AlertDialog) dialog).getListView().getCheckedItemPositions();
//                                List<LoggedInUser.User> result = new ArrayList<>();
//                                for (int i = 0; i < usersResponse.getUsers().size() ; i++) {
//                                    if (checkedItemPositions.get(i)) {
//                                        result.add(usersResponse.getUsers().get(i));
//                                       selectedUsers[i] = true;
//                                    }else selectedUsers[i] = false;
//                                }
//                                saveSelectedUserDetails(result, selectedUsers);
//                            })
//                    .setNegativeButton("Cancel", null)
//                    .setMultiChoiceItems(users.stream().toArray(CharSequence[]::new), selectedUsers, null)
//                    .show();
//
//    }
//
//    private void saveSelectedUserDetails(List<LoggedInUser.User> result, boolean[] selectedUsers) {
//    }
//
//    private void observeForUsersResult() {
//        snagListItemModel.getUsersResponseSingleLiveEvent().observe(getViewLifecycleOwner(), usersResponse -> {
//                snagListItemModel.setUsersResponse(usersResponse);
//
//        });
//    }
//
//
//
//}