package com.huviair.capture.data.model.api.common;

public class CommonResponse {
    private String status;
}
