package com.huviair.capture.ui.common;

import android.os.Parcel;
import android.os.Parcelable;

public class MultiSelectViewItem implements Parcelable {

    private final String id;
    private final String content;
    private boolean isSelected;

    private boolean isLevel1Approver;

    public MultiSelectViewItem(String id, String content, int isSelected) {
        this.id = id;
        this.content = content;
        this.isSelected = isSelected == 1;
    }

    public MultiSelectViewItem(String id, String content, int isSelected, int isLevel1Approver) {
        this.id = id;
        this.content = content;
        this.isSelected = isSelected == 1;
        this.isLevel1Approver = isLevel1Approver == 1;
    }

    public MultiSelectViewItem(Parcel in) {
        this.id = in.readString();
        this.content = in.readString();
        this.isSelected = in.readInt() == 1;
        this.isLevel1Approver = in.readInt() == 1;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public boolean isLevel1Approver() {
        return isLevel1Approver;
    }

    @Override
    public String toString() {
        return content;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public String getContent() {
        return content;
    }

    public static final Parcelable.Creator<MultiSelectViewItem> CREATOR = new Parcelable.Creator<MultiSelectViewItem>() {
        public MultiSelectViewItem createFromParcel(Parcel in) {
            return new MultiSelectViewItem(in);
        }

        public MultiSelectViewItem[] newArray(int size) {
            return new MultiSelectViewItem[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(content);
        dest.writeInt(isSelected ? 1 : 0);
        dest.writeInt(isLevel1Approver ? 1 : 0);
    }
}