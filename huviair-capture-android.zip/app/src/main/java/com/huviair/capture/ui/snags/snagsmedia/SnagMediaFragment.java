package com.huviair.capture.ui.snags.snagsmedia;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.color.MaterialColors;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.huviair.capture.R;
import com.huviair.capture.adapters.SnagMediaAdapter;
import com.huviair.capture.adapters.SnagMediaParentAdapter;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagMedia;
import com.huviair.capture.data.model.api.snags.SnagMediaWithHeader;
import com.huviair.capture.databinding.SnagMediaFragmentBinding;
import com.huviair.capture.viewmodels.SnagMediaViewModel;
import com.yanzhenjie.album.Album;
import com.yanzhenjie.album.AlbumFile;
import com.yanzhenjie.album.api.widget.Widget;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class SnagMediaFragment extends Fragment implements SnagMediaAdapter.SnagMediaAdapterClicksListener {

    private static final String SELECTED_SNAG = "SELECTED_SNAG";
    private SnagMediaViewModel snagMediaViewModel;
    private SnagMediaFragmentBinding snagMediaFragmentBinding;

    private SnagMediaParentAdapter snagMediaParentAdapter;
    private Snag selectedSnag;
    private ActivityResultLauncher<Intent> pickMultipleMediaLauncher;

    private ActivityResultLauncher<Intent> pickCameraMediaLauncher;

    public static SnagMediaFragment newInstance(Snag selectedSnag) {

        SnagMediaFragment fragment = new SnagMediaFragment();
        Bundle args = new Bundle();
        args.putSerializable(SELECTED_SNAG, selectedSnag);
        fragment.setArguments(args);
        return fragment;
    }

    public String getPathFromUri(Uri contentUri) {
        String resPath = null;
        String[] types = { MediaStore.Images.Media.DATA };
        Cursor cursor = getContext().getContentResolver().query(contentUri, types, null, null, null);
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            resPath = cursor.getString(columnIndex);
        }
        cursor.close();
        return resPath;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            selectedSnag = (Snag) getArguments().getSerializable(SELECTED_SNAG);
        }
        // read images
        pickMultipleMediaLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != Activity.RESULT_OK) {
                        Toast.makeText(requireContext(), "Error while selecting media!", Toast.LENGTH_LONG).show();
                    } else {
                        Intent data = result.getData();
                        if (data != null) {
                            ClipData uris = data.getClipData();
                            List<AlbumFile> fileList = new ArrayList<>();
                            if(uris==null){
                                Uri singleFileUri = data.getData();
                                String path = getRealPathFromURI_API19AndAbove(getContext(), singleFileUri);
                                AlbumFile albumFile = new AlbumFile();
                                albumFile.setPath(path);
                                fileList.add(albumFile);
                            } else {
                                for (int index = 0; index < uris.getItemCount(); index++) {
                                    Uri uri = uris.getItemAt(index).getUri();
                                    String path = getRealPathFromURI_API19AndAbove(getContext(), uri);
                                    AlbumFile albumFile = new AlbumFile();
                                    albumFile.setPath(path);
                                    fileList.add(albumFile);
                                }
                            }
                            snagMediaViewModel.uploadSnagMedia(fileList, selectedSnag.getProjectId(),
                                    selectedSnag.getTaskId());
                        }
                    }
                });

        //camera
        pickCameraMediaLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != Activity.RESULT_OK) {
                        Toast.makeText(requireContext(), "Error while camera capture!", Toast.LENGTH_LONG).show();
                    } else {
                        Intent data = result.getData();
                        Bundle extras = data.getExtras();
                        Bitmap imageBitmap = (Bitmap) extras.get("data");
                        snagMediaViewModel.setImageBitMap(imageBitmap);
                        Uri imageUri = saveToGallery(imageBitmap);

                        if (imageUri!=null){
                            AlbumFile albumFile = new AlbumFile();
                            albumFile.setPath(imageUri.toString());
                             //Add to list
                            List<AlbumFile> albumFileList = new ArrayList<>();
                            albumFileList.add(albumFile);
                            snagMediaViewModel.uploadSnagMedia(albumFileList, selectedSnag.getProjectId(),
                                    selectedSnag.getTaskId());
                        }
                    }
                });

    }

    private Uri saveToGallery(Bitmap bitmapImage) {
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String fileName= "IMG_"+timeStamp+".jpeg";
        File imageFile = new File(storageDir,fileName);
        Uri imageUri =null;
        try{
            FileOutputStream outputStream = new FileOutputStream(imageFile);
            bitmapImage.compress(Bitmap.CompressFormat.JPEG,100,outputStream);
            outputStream.flush();
            outputStream.close();
            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            imageUri = Uri.fromFile(imageFile);
            mediaScanIntent.setData(imageUri);

        } catch (Exception ex){
            Toast.makeText(requireContext(), "Error while camera capture!", Toast.LENGTH_LONG).show();
        }
        return imageUri;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        snagMediaFragmentBinding = SnagMediaFragmentBinding.inflate(inflater, container, false);
        return snagMediaFragmentBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.VISIBLE);

        snagMediaViewModel = new ViewModelProvider(this,
                new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication()))
                .get(SnagMediaViewModel.class);

        snagMediaFragmentBinding.snagMediaToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        snagMediaFragmentBinding.snagMediaToolBar.toolBar.setTitle("Snag Media");
        snagMediaFragmentBinding.snagMediaToolBar.toolBar
                .setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        populateSnagMedia();
        listenForClicksOnFabButtons();
        observeForUploadAndDeleteEvents();
        boolean isOnsiteSnag = selectedSnag.isOnsiteSnag();
        if(isOnsiteSnag) {
            snagMediaFragmentBinding.fabCaptureImage.hide();
            snagMediaFragmentBinding.fabAddMedia.hide();
        }
    }

    private void populateSnagMedia() {

        List<SnagMedia> snagMediaList = selectedSnag.getMediaList();
        toggleNoDataFound(snagMediaList);

        List<SnagMediaWithHeader> snagMediaWithHeaders = prepareData(snagMediaList);
        snagMediaParentAdapter = new SnagMediaParentAdapter(snagMediaWithHeaders, requireActivity(), this);

        snagMediaFragmentBinding.snagMediaRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        snagMediaFragmentBinding.snagMediaRecyclerView.setHasFixedSize(true);
        snagMediaFragmentBinding.snagMediaRecyclerView.setAdapter(snagMediaParentAdapter);
    }

    private List<SnagMediaWithHeader> prepareData(List<SnagMedia> snagMediaList) {
        List<SnagMediaWithHeader> snagsWithHeader = new ArrayList<>();
        Map<String, List<SnagMedia>> snagsGroupedByHeader = snagMediaList.stream()
                .collect(Collectors.groupingBy(SnagMedia::getState));
        snagsGroupedByHeader
                .forEach((state, snagMedia) -> snagsWithHeader.add(new SnagMediaWithHeader(state, snagMedia)));
        return snagsWithHeader;
    }

    private void toggleNoDataFound(List<SnagMedia> mediaList) {
        if (mediaList == null || mediaList.size() == 0) {
            snagMediaFragmentBinding.noMediaToShow.setVisibility(View.VISIBLE);
        } else
            snagMediaFragmentBinding.noMediaToShow.setVisibility(View.GONE);
    }

    private void listenForClicksOnFabButtons() {

        snagMediaFragmentBinding.fabAddMedia.setOnClickListener(v -> {
            // Pre-populate the container URI
            snagMediaViewModel.fetchContainerUri();

            int brandColor = ContextCompat.getColor(requireContext(), R.color.brand_color);

            // Change color only in night mode
            int nightModeFlags = requireContext().getResources().getConfiguration().uiMode
                    & Configuration.UI_MODE_NIGHT_MASK;
            if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
                brandColor = MaterialColors.getColor(requireContext(), R.attr.colorOnPrimary,
                        ContextCompat.getColor(requireContext(), R.color.brand_color));
            }

            int secondaryColor = ContextCompat.getColor(requireContext(), R.color.brand_secondary);
            // For API compatibility above 33
            if (Build.VERSION.SDK_INT >= 33) {

                pickMultipleMediaLauncher.launch(new Intent(MediaStore.ACTION_PICK_IMAGES)

                        .putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, 10));

            } else {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    pickMultipleMediaLauncher.launch(intent);
                } catch (Exception ex){
                    Log.e("ErrorPicker", ex.getMessage());
                }
            }
        });

        snagMediaFragmentBinding.fabCaptureImage.setOnClickListener(v -> {
            // Pre-populate the container URI
            snagMediaViewModel.fetchContainerUri();
            if(ContextCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.CAMERA},1);
                return;
            }
            pickCameraMediaLauncher.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
        });

    }

    private void observeForUploadAndDeleteEvents() {
        snagMediaViewModel.getUpdatedMediaList().observe(getViewLifecycleOwner(), snagMedia -> {
            selectedSnag.setMediaList(snagMedia);
            if (snagMediaParentAdapter != null) {
                toggleNoDataFound(snagMedia);
                List<SnagMediaWithHeader> snagMediaWithHeaders = prepareData(snagMedia);
                snagMediaParentAdapter.updateData(snagMediaWithHeaders);
            }
        });

        snagMediaViewModel.getIsUploading().observe(getViewLifecycleOwner(), this::toggleViewsDuringUploadAndDelete);

        snagMediaViewModel.getIsUploadCompletedSuccessfully().observe(getViewLifecycleOwner(), isUploaded -> {
            if (isUploaded)
                Toast.makeText(requireContext(), "Media upload successful", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(requireContext(), "Media upload failed", Toast.LENGTH_SHORT).show();
        });
        snagMediaViewModel.isDeletingMedia.observe(getViewLifecycleOwner(), this::toggleViewsDuringUploadAndDelete);

        snagMediaViewModel.isDeleteCompletedSuccessfully.observe(getViewLifecycleOwner(), isDeleted -> {
            if (isDeleted) {
                Toast.makeText(requireContext(), "Media deleted successfully", Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(requireContext(), "Failed to delete media", Toast.LENGTH_SHORT).show();
        });
    }

    private void toggleViewsDuringUploadAndDelete(boolean isInProgress) {
        snagMediaFragmentBinding.uploadingMedia.setVisibility(isInProgress ? View.VISIBLE : View.GONE);
        snagMediaFragmentBinding.snagMediaRecyclerView.setVisibility(isInProgress ? View.GONE : View.VISIBLE);
        if (isInProgress) {
            snagMediaFragmentBinding.fabCaptureImage.hide();
            snagMediaFragmentBinding.fabAddMedia.hide();
        } else {
            snagMediaFragmentBinding.fabCaptureImage.show();
            snagMediaFragmentBinding.fabAddMedia.show();
        }
    }

    @Override
    public void deleteMedia(String mediaIdToDelete) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete selected media ?")
                .setMessage("This will delete the selected media item for the snag")
                .setIcon(R.drawable.delete_brand_color)
                .setPositiveButton("Delete",
                        (dialog, which) -> snagMediaViewModel.deleteMedia(selectedSnag.getProjectId(),
                                selectedSnag.getTaskId(), mediaIdToDelete))
                .setNegativeButton("Cancel", (dialog, which) -> {
                })
                .show();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("SELECTED_SNAG", selectedSnag);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (snagMediaFragmentBinding != null) {
            snagMediaFragmentBinding = null;
        }
    }

    public static String getRealPathFromURI_API19AndAbove(final Context context, final Uri uri) {
// DocumentProvider
        if ( DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
            else if ("content".equalsIgnoreCase(uri.getScheme())) {
                return getDataColumn(context, uri, null, null);
            }
        }
        else if ("content".equalsIgnoreCase(uri.getScheme())) { // MediaStore (and general)
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    /**
     * Get the value of the data column for this Uri. This is useful for
     * MediaStore Uris, and other file-based ContentProviders.
     *
     * @param context       The context.
     * @param uri           The Uri to query.
     * @param selection     (Optional) Filter used in the query.
     * @param selectionArgs (Optional) Selection arguments used in the query.
     * @return The value of the _data column, which is typically a file path.
     */
    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }


    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }
}