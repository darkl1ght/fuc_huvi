package com.huviair.capture.database;

import android.database.sqlite.SQLiteDatabase;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.huviair.capture.data.model.database.Interior;
import com.huviair.capture.data.model.database.InteriorTower;
import com.huviair.capture.data.model.database.InteriorWalkthrough;
import com.huviair.capture.data.model.database.Project;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Single;

@Dao
public interface ProjectCacheDAO {


    @Insert(onConflict = SQLiteDatabase.CONFLICT_REPLACE)
    void insertProjects(Project... projects);

    @Insert
    void insertInteriors(Interior... interiors);

    @Insert
    void insertInteriorTowers(InteriorTower... towers);

    @Insert
    void insertWalkthroughs(InteriorWalkthrough... walkthroughs);

    @Query("SELECT * FROM PROJECTS")
    Single<List<Project>> getAllProjects();

    @Query("SELECT * FROM INTERIORS WHERE PROJECT_ID=:projectId")
    Single<List<Interior>> getInteriorsByProjectId(String projectId);

    @Query("SELECT * FROM INTERIOR_TOWER WHERE INTERIOR_ID=:interiorId")
    Single<List<InteriorTower>> getTowersForInterior(String interiorId);

    @Query("SELECT * FROM INTERIOR_WALKTHROUGH WHERE INTERIOR_ID=:interiorId and TOWER_ID=:towerId")
    List<InteriorWalkthrough> getWalkthroughsForTower(String interiorId, String towerId);

    @Query("SELECT * FROM INTERIOR_WALKTHROUGH WHERE INTERIOR_ID=:interiorId and TOWER_ID=:towerId")
    Single<List<InteriorWalkthrough>> getWalkthroughsForTowerObservable(String interiorId, String towerId);

    @Query("UPDATE INTERIOR_WALKTHROUGH SET FLOORPLAN_SAVED_PATH= :floorPlanPath WHERE WALKTHROUGH_ID=:tourId")
    void updateFloorPlanId(String floorPlanPath, String tourId);

    @Query("DELETE FROM PROJECTS")
    Completable deleteProjects();

    @Query("DELETE FROM INTERIORS WHERE PROJECT_ID= :projectId")
    Completable deleteInteriors(String projectId);

    @Query("DELETE FROM INTERIORS")
    void deleteAllInteriors();

    @Query("DELETE FROM INTERIOR_WALKTHROUGH WHERE PROJECT_ID= :projectId")
    void deleteWalkthroughs(String projectId);

    @Query("DELETE FROM INTERIOR_WALKTHROUGH")
    void deleteAllWalkthroughs();

    @Query("DELETE FROM INTERIOR_TOWER WHERE PROJECT_ID= :projectId")
    void deleteInteriorTowers(String projectId);

    @Query("DELETE FROM INTERIOR_TOWER")
    void deleteAllInteriorTowers();

    @Query("SELECT * FROM INTERIOR_WALKTHROUGH WHERE WALKTHROUGH_ID=:tourId")
    Single<InteriorWalkthrough> getSavedTourDetails(String tourId);

    @Query("SELECT ALLOWED_VIDEO_CAPTURE_TIME FROM PROJECTS WHERE PROJECT_ID= :projectId")
    long getAllowedVideoCaptureTimeByProjectId(String projectId);

}
