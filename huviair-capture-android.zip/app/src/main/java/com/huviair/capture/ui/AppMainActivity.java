package com.huviair.capture.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.huviair.capture.ui.login.LoginActivity;
import com.huviair.capture.ui.projects.ProjectListActivity;
import com.huviair.capture.utils.SharedPreferencesManager;

public class AppMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferencesManager sharedPreferencesManager = new SharedPreferencesManager(this);
        // If user is already logged-in open the project list activity
        if (sharedPreferencesManager.isLoggedIn()) {

            sharedPreferencesManager.setAppOpenCount();

            // Project list intent
            Intent projectListIntent = new Intent(this, ProjectListActivity.class);
            projectListIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(projectListIntent);
        }

        // Redirect to login activity for authentication
        else {
            startActivity(new Intent(this, LoginActivity.class));
        }

        finish();


    }
}