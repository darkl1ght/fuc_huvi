package com.huviair.capture.adapters.diffUtil;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

import com.huviair.capture.data.model.api.snags.Snag;

public class SnagListDiffUtil extends DiffUtil.ItemCallback<Snag> {
    private static final String TAG = "test";

    @Override
    public boolean areItemsTheSame(@NonNull Snag oldItem, @NonNull Snag newItem) {
        // Id is unique.
        return oldItem.getTaskId().equals(newItem.getTaskId());
    }

    @Override
    public boolean areContentsTheSame(@NonNull Snag oldItem, @NonNull Snag newItem) {
        if (newItem.getTaskDescription().equals("Wrap up")) {
            Log.d("test", "test");
        }
        int result = oldItem.compareTo(newItem);
        if (result > 0) {
            newItem.setViewExpanded(true);
        }
        return result == 0;
    }
}