package com.huviair.capture.workers;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.huviair.capture.R;
import com.huviair.capture.utils.CommonConstants;

public class WorkerUtils {

    static Notification getNotification(boolean onGoing, String notificationTitle, String message, String channelId, Context context) {

        // Make a channel if necessary
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            // Create the NotificationChannel, but only on API 26+ because
            // the NotificationChannel class is new and not in the support library
            CharSequence name = CommonConstants.VERBOSE_NOTIFICATION_CHANNEL_NAME;
            String description = CommonConstants.VERBOSE_NOTIFICATION_CHANNEL_DESCRIPTION;
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(channelId, name, importance);
            channel.setDescription(description);

            // Add the channel
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        // Create the notification
        return new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_stat_image_1)
                .setLargeIcon(Bitmap.createScaledBitmap(BitmapFactory.decodeResource(context.getResources(), R.drawable.huviair_logo), 128, 128, false))
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setColor(context.getColor(R.color.brand_color))
                .setContentTitle(notificationTitle)
                .setOngoing(onGoing)
                .setTicker(message)
                .setSilent(true)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();
    }


}
