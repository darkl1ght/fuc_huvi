package com.huviair.capture.data.model.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "INTERIOR_TOWER")
public class InteriorTower {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "INTERIOR_ID")
    private String interiorId;
    @ColumnInfo(name = "TOWER_ID")
    private String towerId;
    @ColumnInfo(name = "TOWER_NAME")
    private String towerName;
    @ColumnInfo(name = "PROJECT_ID")
    private String projectId;


    public InteriorTower(int id, String interiorId, String towerId, String towerName, String projectId) {
        this.id = id;
        this.interiorId = interiorId;
        this.towerId = towerId;
        this.towerName = towerName;
        this.projectId = projectId;
    }

    @Ignore
    public InteriorTower(String interiorId, String towerId, String towerName, String projectId) {
        this.interiorId = interiorId;
        this.towerId = towerId;
        this.towerName = towerName;
        this.projectId = projectId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public void setInteriorId(String interiorId) {
        this.interiorId = interiorId;
    }

    public String getTowerId() {
        return towerId;
    }

    public void setTowerId(String towerId) {
        this.towerId = towerId;
    }

    public String getTowerName() {
        return towerName;
    }

    public void setTowerName(String towerName) {
        this.towerName = towerName;
    }
}
