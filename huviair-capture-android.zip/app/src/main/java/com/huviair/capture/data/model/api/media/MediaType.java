package com.huviair.capture.data.model.api.media;

import com.huviair.capture.utils.CommonConstants;
import com.yanzhenjie.album.AlbumFile;

import java.io.Serializable;

public class MediaType implements Serializable {

    private String code;
    private String desc;

    public MediaType(int mediaType) {
        populateMediaType(mediaType);
    }

    private void populateMediaType(int mediaType) {

//        if(CommonConstants.imageTypes.contains(mediaType.toLowerCase())){
//            this.code = CommonConstants.TYPE_IMAGE_CODE;
//            this.desc = CommonConstants.IMAGE_DESCRIPTION;
//        }
//        else if(CommonConstants.videoTypes.contains(mediaType.toLowerCase())){
//            this.code = CommonConstants.TYPE_VIDEO_CODE;
//            this.desc = CommonConstants.VIDEO_DESCRIPTION;
//        }

        if (AlbumFile.TYPE_IMAGE == mediaType) {
            this.code = CommonConstants.TYPE_IMAGE_CODE;
            this.desc = CommonConstants.IMAGE_DESCRIPTION;
        } else if (AlbumFile.TYPE_VIDEO == mediaType) {
            this.code = CommonConstants.TYPE_VIDEO_CODE;
            this.desc = CommonConstants.VIDEO_DESCRIPTION;
        } else {
            code = "Invalid";
        }
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }


    @Override
    public String toString() {
        return "MediaType{" +
                "code='" + code + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }
}

