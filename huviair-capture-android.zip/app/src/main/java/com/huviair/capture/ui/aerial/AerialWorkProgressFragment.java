package com.huviair.capture.ui.aerial;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.work.Data;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.huviair.capture.adapters.AerialJobStatusAdapter;
import com.huviair.capture.databinding.FragmentAerialWorkProgressBinding;
import com.huviair.capture.viewmodels.AerialUploadViewModel;

import org.jetbrains.annotations.NotNull;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AerialWorkProgressFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AerialWorkProgressFragment extends Fragment implements AerialJobStatusAdapter.OnRetryClickListener {

    private FragmentAerialWorkProgressBinding fragmentAerialWorkProgressBinding;
    private AerialUploadViewModel aerialUploadViewModel;
    private static final String PROJECT_ID = "PROJECT_ID";
    private String projectId;

    public AerialWorkProgressFragment() {
        // Required empty public constructor
    }

    public static AerialWorkProgressFragment newInstance(String projectId) {
        AerialWorkProgressFragment aerialWorkProgressFragment = new AerialWorkProgressFragment();
        Bundle bundle = new Bundle();
        bundle.putString(PROJECT_ID, projectId);
        aerialWorkProgressFragment.setArguments(bundle);
        return aerialWorkProgressFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
        }
    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentAerialWorkProgressBinding = FragmentAerialWorkProgressBinding.inflate(inflater, container, false);
        return fragmentAerialWorkProgressBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize view model
        aerialUploadViewModel = new ViewModelProvider(requireParentFragment()).get(AerialUploadViewModel.class);

        observeUploadWorkStatus();

    }


    private void observeUploadWorkStatus() {

        aerialUploadViewModel.getWorkInfo().observe(getViewLifecycleOwner(), workInfos -> {
            // If there are no matching work info, do nothing
            if (workInfos == null || workInfos.isEmpty()) {
                fragmentAerialWorkProgressBinding.noDataToShow.setVisibility(View.VISIBLE);
                return;
            }

            AerialJobStatusAdapter jobStatusAdapter = new AerialJobStatusAdapter(workInfos, this);
            fragmentAerialWorkProgressBinding.recyclerAerialProgressView.setAdapter(jobStatusAdapter);
            fragmentAerialWorkProgressBinding.recyclerAerialProgressView.setHasFixedSize(true);

            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext());
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            fragmentAerialWorkProgressBinding.recyclerAerialProgressView.setLayoutManager(linearLayoutManager);
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (fragmentAerialWorkProgressBinding != null) {
            fragmentAerialWorkProgressBinding = null;
        }
    }

    @Override
    public void onRetryClick(Data jobDetails) {
        aerialUploadViewModel.retryUploadWork(jobDetails);
    }
}
