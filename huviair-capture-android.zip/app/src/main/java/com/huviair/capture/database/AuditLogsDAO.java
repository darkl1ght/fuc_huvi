package com.huviair.capture.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.huviair.capture.data.model.database.AuditLog;

import java.util.Date;
import java.util.List;
import android.database.sqlite.SQLiteDatabase;
import io.reactivex.Completable;
import io.reactivex.Single;

@Dao
public interface AuditLogsDAO {

    @Insert
    void insertLog(AuditLog... log);

    @Query("DELETE FROM AUDIT_LOGS")
    void deleteLogs();

    @Query("SELECT * FROM AUDIT_LOGS")
    Single<List<AuditLog>> getAllLogs();


}
