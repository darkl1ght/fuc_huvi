package com.huviair.capture.ui.projects;

import androidx.annotation.Nullable;

/**
 * Authentication result : success (user details) or error message.
 */
public class ProjectResult {
    @Nullable
    private ProjectDataView success;
    @Nullable
    private Integer error;

    public ProjectResult(@Nullable Integer error) {
        this.error = error;
    }

    public ProjectResult(@Nullable ProjectDataView success) {
        this.success = success;
    }

    @Nullable
    ProjectDataView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }
}