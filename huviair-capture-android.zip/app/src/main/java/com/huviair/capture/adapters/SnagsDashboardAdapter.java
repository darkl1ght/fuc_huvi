package com.huviair.capture.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.huviair.capture.R;
import com.huviair.capture.data.model.others.SnagDashboardElement;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.viewmodels.SnagViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class SnagsDashboardAdapter extends RecyclerView.Adapter<SnagsDashboardAdapter.ViewHolder> {

    private final List<SnagDashboardElement> snagDashboardElements;
    private SnagViewModel model;

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final MaterialCardView cardView;
        private final TextView snagCardTitle;
        private final TextView snagCount;
        private final ImageView cardIcon;

        public ViewHolder(MaterialCardView view) {
            super(view);
            cardView = view;
            // Define click listener for the ViewHolder's View
            snagCardTitle = view.findViewById(R.id.snag_card_title);
            snagCount = view.findViewById(R.id.snag_card_count);
            cardIcon = view.findViewById(R.id.snag_card_icon);
        }

        public TextView getSnagCardTitle() {
            return snagCardTitle;
        }

        public TextView getSnagCount() {
            return snagCount;
        }

        public ImageView getCardIcon() {
            return cardIcon;
        }
    }


    public SnagsDashboardAdapter(List<SnagDashboardElement> dataSet) {
        this.snagDashboardElements = dataSet;

    }

    // Create new views (invoked by the layout manager)
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view, which defines the UI of the list item
        MaterialCardView view = (MaterialCardView) LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.snag_card_view, viewGroup, false);

        return new ViewHolder(view);
    }


    @Override
    public void onAttachedToRecyclerView(@androidx.annotation.NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        if (model == null) {
            model = new ViewModelProvider((ViewModelStoreOwner) recyclerView.getContext()).get(SnagViewModel.class);
        }
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        MaterialCardView cardView = viewHolder.cardView;
        viewHolder.getSnagCardTitle().setText(snagDashboardElements.get(position).getTitle());
        viewHolder.getSnagCount().setText(snagDashboardElements.get(position).getCount());
        viewHolder.getCardIcon().setImageResource(snagDashboardElements.get(position).getDrawableResId());

        populateColors(position, cardView);

        cardView.setOnClickListener(v -> model.setSelectedSnagCard(snagDashboardElements.get(position).getTitle()));
    }

    private void populateColors(int position, MaterialCardView cardView) {

        switch (snagDashboardElements.get(position).getTitle()) {
            case CommonConstants.SNAG_ALL_ITEMS:
                cardView.setCardBackgroundColor(ContextCompat.getColor(cardView.getContext(), R.color.snag_dashboard_all_items));
                break;
            case CommonConstants.SNAG_OPEN_ITEMS:
                cardView.setCardBackgroundColor(ContextCompat.getColor(cardView.getContext(), R.color.snag_dashboard_amber));
                break;
            case CommonConstants.SNAG_MY_ASSIGNED_ITEMS:
                cardView.setCardBackgroundColor(ContextCompat.getColor(cardView.getContext(), R.color.snag_dashboard_green));
                break;
            case CommonConstants.SNAG_OVERDUE_ITEMS:
                cardView.setCardBackgroundColor(ContextCompat.getColor(cardView.getContext(), R.color.snag_dashboard_red));
                break;

            default:
                // Do nothing

        }

    }

    @Override
    public int getItemCount() {
        return snagDashboardElements.size();
    }
}

