package com.huviair.capture.api;

import com.huviair.capture.data.model.api.lookups.LookupsResponse;

import io.reactivex.Single;
import retrofit2.http.GET;
import retrofit2.http.Path;

/**
 * Interface provides different API functionality for interacting with the Node.js backend
 */

public interface LookupsAPIService {

    @GET("api/lookups/lookup/{lookup_type}")
    Single<LookupsResponse> getLookups(@Path("lookup_type") String lookupType);

}
