package com.huviair.capture.data.model.database;

public class InteriorTowerWalkThrough {
    private String floorPlanBlobId;
    private String tourId;
    private String towerId;
    private String towerName;
    private String tourName;
    private String interiorId;

    public String getTowerName() {
        return towerName;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTowerName(String towerName) {
        this.towerName = towerName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    public String getFloorPlanBlobId() {
        return floorPlanBlobId;
    }

    public void setFloorPlanBlobId(String floorPlanBlobId) {
        this.floorPlanBlobId = floorPlanBlobId;
    }

    public String getTourId() {
        return tourId;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    public String getTowerId() {
        return towerId;
    }

    public void setTowerId(String towerId) {
        this.towerId = towerId;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public void setInteriorId(String interiorId) {
        this.interiorId = interiorId;
    }
}
