package com.huviair.capture.ui.interiors.videocapture.publish;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.arashivision.sdkcamera.camera.callback.ICameraChangedCallback;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.model.database.InteriorVideoCapture;
import com.huviair.capture.databinding.VideoCapturePublishFragmentBinding;
import com.huviair.capture.utils.CommonConstants;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.FileCallback;
import com.lzy.okgo.model.Response;

import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;

public class VideoCapturePublish extends Fragment implements ICameraChangedCallback {

    private VideoCapturePublishViewModel videoCapturePublishViewModel;
    private Tour selectedWalkthrough;
    private String VIDEO_FOLDER_PATH;
    private Snackbar internetConnectivitySnackbar;
    private VideoCapturePublishFragmentBinding videoCapturePublishFragmentBinding;

    public VideoCapturePublish() {

    }

    public interface OnEventListener {
        void onWalkthroughUploadComplete(String interiorId, String towerId);
    }
    private OnEventListener mCallback;


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            mCallback = (OnEventListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnEventListener");
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        mCallback = null;
    }

    public VideoCapturePublish(Tour selectedWalkthrough) {
        this.selectedWalkthrough = selectedWalkthrough;
    }

    public static VideoCapturePublish newInstance(Tour selectedWalkthrough) {
        return new VideoCapturePublish(selectedWalkthrough);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        videoCapturePublishViewModel = new ViewModelProvider(requireActivity(), new ViewModelProvider.AndroidViewModelFactory(requireActivity().getApplication())).get(VideoCapturePublishViewModel.class);
        videoCapturePublishViewModel.fetchVideoCapture(selectedWalkthrough);

        VIDEO_FOLDER_PATH = requireContext().getFilesDir() + "/" + CommonConstants.VIDEO_CAPTURE_VIDEOS_FOLDER;

        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        InstaCameraManager.getInstance().registerCameraChangedCallback(this);

        videoCapturePublishFragmentBinding = VideoCapturePublishFragmentBinding.inflate(inflater, container, false);
        return videoCapturePublishFragmentBinding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initializeConnectivitySnackbar();

        videoCapturePublishFragmentBinding.videoCapturePublishToolBar.toolBar.setTitle("");
        videoCapturePublishFragmentBinding.videoCapturePublishToolBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        videoCapturePublishFragmentBinding.videoCapturePublishToolBar.toolBar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        listenForVideoDownload();
        downloadVideoButtonListener();
        uploadVideoButtonListener();
        addUploadProgressListeners();
        addCameraConnectionListener();
    }

    private void addCameraConnectionListener() {
        videoCapturePublishFragmentBinding.connectCamera.setOnClickListener(view -> {
            videoCapturePublishViewModel.startCameraConnectionInBackground();
            startActivity(new Intent(WifiManager.ACTION_PICK_WIFI_NETWORK));
        });
    }

    private void addUploadProgressListeners() {
        videoCapturePublishViewModel.isUploadingDataToConstra().observe(this, isUploading -> {
            // Keep screen on during upload
            if (isUploading){
                videoCapturePublishFragmentBinding.uploadVideoConstra.setEnabled(false);
                requireActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
            else{
                videoCapturePublishFragmentBinding.uploadVideoConstra.setEnabled(true);
                requireActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }


            videoCapturePublishFragmentBinding.videoUploadProgress.setVisibility(isUploading ? View.VISIBLE : View.GONE);
        });
        videoCapturePublishViewModel.getFile1UploadPercentage().observe(this, integer -> videoCapturePublishFragmentBinding.captureIndicatorFile1.setProgress(integer));
        videoCapturePublishViewModel.getFile2UploadPercentage().observe(this, integer -> videoCapturePublishFragmentBinding.captureIndicatorFile2.setProgress(integer));

        videoCapturePublishViewModel.getIsUploadComplete().observe(this, isUploadComplete -> {
            if (isUploadComplete) {
                videoCapturePublishFragmentBinding.uploadVideoConstra.setVisibility(View.GONE);
                videoCapturePublishFragmentBinding.step3Status.setText("Complete");
                videoCapturePublishFragmentBinding.step3Status.setVisibility(View.VISIBLE);

                Snackbar.make(videoCapturePublishFragmentBinding.getRoot(), "Walk-through submitted successfully", Snackbar.LENGTH_LONG).show();

                mCallback.onWalkthroughUploadComplete(selectedWalkthrough.getInteriorId(), selectedWalkthrough.getTowerId());
            }
        });
    }

    private void uploadVideoButtonListener() {
        videoCapturePublishFragmentBinding.uploadVideoConstra.setOnClickListener(view -> videoCapturePublishViewModel.uploadVideosToConstra());
    }

    private void listenForVideoDownload() {
        videoCapturePublishViewModel.getAreVideosDownloaded().observe(this, isVideosDownloaded -> {
            videoCapturePublishFragmentBinding.downloadVideos.setVisibility(isVideosDownloaded ? View.GONE : View.VISIBLE);
            if (isVideosDownloaded) {
                videoCapturePublishFragmentBinding.step2Status.setText("Complete");
                videoCapturePublishFragmentBinding.step2Status.setVisibility(View.VISIBLE);

                boolean isVideoUploaded = videoCapturePublishViewModel.getVideoCapture().isVideoUploaded();
                videoCapturePublishFragmentBinding.uploadVideoConstra.setVisibility(!isVideoUploaded ? View.VISIBLE : View.GONE);

                if (!isVideoUploaded)
                    videoCapturePublishViewModel.addInternetConnectivityListener();
                else {
                    videoCapturePublishFragmentBinding.step3Status.setText("Complete");
                    videoCapturePublishFragmentBinding.step3Status.setVisibility(View.VISIBLE);

                }
            } else {
                if (InstaCameraManager.getInstance().getCameraConnectedType() == InstaCameraManager.CONNECT_TYPE_NONE) {
                    videoCapturePublishFragmentBinding.downloadVideos.setVisibility(View.GONE);
                    videoCapturePublishFragmentBinding.connectCamera.setVisibility(View.VISIBLE);

                    videoCapturePublishViewModel.startCameraConnectionInBackground();
                }

            }
        });

        videoCapturePublishViewModel.is360CameraConnected.observe(this, isConnected -> {
            if (videoCapturePublishViewModel.getAreVideosDownloaded().getValue() != null && !videoCapturePublishViewModel.getAreVideosDownloaded().getValue()) {
                videoCapturePublishFragmentBinding.downloadVideos.setVisibility(!isConnected ? View.GONE : View.VISIBLE);
                videoCapturePublishFragmentBinding.connectCamera.setVisibility(!isConnected ? View.VISIBLE : View.GONE);
            }
        });

        videoCapturePublishViewModel.isWalkthroughUploadedAlready.observe(this, isUploadedAlready -> {
            if (isUploadedAlready) {
                videoCapturePublishFragmentBinding.step3Status.setText("Complete");
                videoCapturePublishFragmentBinding.step3Status.setVisibility(View.VISIBLE);
            }
        });

        videoCapturePublishViewModel.isInternetConnectivityAvailable().observe(this, isInternetAvailable -> {
            if (isInternetAvailable) {
                if (internetConnectivitySnackbar.isShown()) {
                    internetConnectivitySnackbar.dismiss();
                }
            } else internetConnectivitySnackbar.show();

        });
    }

    public void downloadVideoButtonListener() {
        videoCapturePublishFragmentBinding.downloadVideos.setOnClickListener(view -> downloadVideosFromCamera());
    }


    public void downloadVideosFromCamera() {

        // Keep scree on
        requireActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        InteriorVideoCapture videoCapture = videoCapturePublishViewModel.getVideoCapture();

        String[] fileNames = new String[videoCapture.getTimelapseVideoUrl().size()];
        String[] localPaths = new String[videoCapture.getTimelapseVideoUrl().size()];

        for (int i = 0; i < localPaths.length; i++) {
            fileNames[i] = videoCapturePublishViewModel.getFileNameFromUrl(videoCapture.getTimelapseVideoUrl().get(i));
            localPaths[i] = VIDEO_FOLDER_PATH + "/" + fileNames[i];
        }

        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Downloading videos.. ")
                .setMessage(getString(R.string.download_status, videoCapture.getTimelapseVideoUrl().size(), 0, 0))
                .setIcon(R.drawable.ic_baseline_arrow_downward_24)
                .setCancelable(false)
                .show();

        AtomicInteger successfulCount = new AtomicInteger(0);
        AtomicInteger errorCount = new AtomicInteger(0);

        // Import images
        for (int i = 0; i < localPaths.length; i++) {
            String url = videoCapture.getTimelapseVideoUrl().get(i);

            OkGo.<File>get(url)
                    .execute(new FileCallback(VIDEO_FOLDER_PATH, fileNames[i]) {

                        @Override
                        public void onError(Response<File> response) {
                            super.onError(response);

                            Snackbar.make(videoCapturePublishFragmentBinding.getRoot(), "Error in downloading files", Snackbar.LENGTH_LONG).show();

                            errorCount.incrementAndGet();
                            checkDownloadCount();
                        }

                        @Override
                        public void onSuccess(Response<File> response) {
                            successfulCount.incrementAndGet();
                            checkDownloadCount();
                        }

                        private void checkDownloadCount() {
                            dialog.setMessage(getString(R.string.download_status, videoCapture.getTimelapseVideoUrl().size(), successfulCount.intValue(), errorCount.intValue()));
                            if (successfulCount.intValue() >= videoCapture.getTimelapseVideoUrl().size()) {
                                // remove flags
                                requireActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

                                videoCapturePublishViewModel.setAreVideosDownloaded(true);
                                Snackbar.make(videoCapturePublishFragmentBinding.getRoot(), "Videos downloaded successfully", Snackbar.LENGTH_LONG).show();
                                dialog.dismiss();
                            }
                        }
                    });
        }

    }

    private void initializeConnectivitySnackbar() {
        internetConnectivitySnackbar = Snackbar.make(videoCapturePublishFragmentBinding.getRoot(), "Publishing requires internet", Snackbar.LENGTH_INDEFINITE)
                .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                .setTextColor(ContextCompat.getColor(requireContext(), R.color.snackbar_text))
                .setAction("Connect", view -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        startActivity(new Intent(android.provider.Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
                    } else startActivity(new Intent(WifiManager.ACTION_PICK_WIFI_NETWORK));
                });

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        InstaCameraManager.getInstance().unregisterCameraChangedCallback(this);
        internetConnectivitySnackbar.dismiss();

    }

    /**
     * Camera status changed
     *
     * @param enabled: Whether the camera is available
     */
    @Override
    public void onCameraStatusChanged(boolean enabled) {
        videoCapturePublishViewModel.is360CameraConnected.setValue(enabled);

    }

}