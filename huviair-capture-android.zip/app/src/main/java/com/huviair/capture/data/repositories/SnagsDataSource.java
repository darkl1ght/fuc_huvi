package com.huviair.capture.data.repositories;

import androidx.annotation.NonNull;
import androidx.paging.PagingState;
import androidx.paging.rxjava2.RxPagingSource;

import com.huviair.capture.api.SnagsAPIService;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.SnagConfig;
import com.huviair.capture.data.model.api.snags.SnagListViewResponse;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class SnagsDataSource extends RxPagingSource<Integer, Snag> {
    @NotNull
    private final SnagsAPIService snagsAPIService;

    private final String projectId;
    private final String queryType;
    private final SnagConfig snagConfig;


    public SnagsDataSource(@NotNull SnagsAPIService snagsAPIService, @NotNull String projectId,
                           @NotNull String queryType, @NotNull SnagConfig snagConfig) {

        this.snagsAPIService = snagsAPIService;
        this.projectId = projectId;
        this.queryType = queryType;
        this.snagConfig = snagConfig;
    }

    @NotNull
    @Override
    public Single<LoadResult<Integer, Snag>> loadSingle(@NotNull LoadParams<Integer> loadParams) {
        // Start refresh at page 1 if undefined.
        Integer nextPageNumber = loadParams.getKey();
        if (nextPageNumber == null) {
            nextPageNumber = 1;
        }

        return snagsAPIService.getSnagDetailsByQueryType(projectId, queryType, snagConfig, nextPageNumber)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map(this::toLoadResult)
                .onErrorReturn(LoadResult.Error::new);
    }

    private LoadResult<Integer, Snag> toLoadResult(
            @NonNull SnagListViewResponse response) {
        return new LoadResult.Page<>(
                response.getSnagsResponse().getSnagsList(),
                response.getSnagsResponse().getPaginationMetaData().getPrevPage(), // Only paging forward.
                response.getSnagsResponse().getPaginationMetaData().getNextPage(),
                LoadResult.Page.COUNT_UNDEFINED,
                LoadResult.Page.COUNT_UNDEFINED);
    }

    @Nullable
    @Override
    public Integer getRefreshKey(@NotNull PagingState<Integer, Snag> pagingState) {
        // Try to find the page key of the closest page to anchorPosition, from
        // either the prevKey or the nextKey, but you need to handle nullability
        // here:
        //  * prevKey == null -> anchorPage is the first page.
        //  * nextKey == null -> anchorPage is the last page.
        //  * both prevKey and nextKey null -> anchorPage is the initial page, so
        //    just return null.
        Integer anchorPosition = pagingState.getAnchorPosition();
        if (anchorPosition == null) {
            return null;
        }

        LoadResult.Page<Integer, Snag> anchorPage = pagingState.closestPageToPosition(anchorPosition);
        if (anchorPage == null) {
            return null;
        }

        Integer prevKey = anchorPage.getPrevKey();
        if (prevKey != null) {
            return prevKey + 1;
        }

        Integer nextKey = anchorPage.getNextKey();
        if (nextKey != null) {
            return nextKey - 1;
        }

        return null;
    }
}


