package com.huviair.capture.ui.aerial;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;
import com.huviair.capture.R;
import com.huviair.capture.databinding.AerialLandingFragmentBinding;

public class AerialLandingFragment extends Fragment {

    private AerialLandingFragmentBinding aerialLandingFragmentBinding;

    // Parameters to the fragment
    public static final String PROJECT_ID = "PROJECT_ID";
    private String projectId;


    public static AerialLandingFragment newInstance(String projectId) {
        AerialLandingFragment aerialLandingFragment = new AerialLandingFragment();
        Bundle bundle = new Bundle();
        bundle.putString(PROJECT_ID, projectId);
        aerialLandingFragment.setArguments(bundle);
        return aerialLandingFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        aerialLandingFragmentBinding = AerialLandingFragmentBinding.inflate(inflater, container, false);
        return aerialLandingFragmentBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        aerialLandingFragmentBinding.projectBar.toolBar.setTitle("Aerial");
        aerialLandingFragmentBinding.projectBar.toolBar.setNavigationIcon(ContextCompat.getDrawable(requireContext(), R.drawable.navigation_back_icon));
        aerialLandingFragmentBinding.projectBar.toolBar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        observeForTabClicks();

        getChildFragmentManager().beginTransaction()
                .add(R.id.replacable_frame_layout, AerialDataUploadFragment.newInstance(projectId), "data upload")
                .commit();
    }

    private void observeForTabClicks() {
        aerialLandingFragmentBinding.aerialTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    getChildFragmentManager().beginTransaction()
                            .replace(R.id.replacable_frame_layout, AerialDataUploadFragment.newInstance(projectId), "data upload")
                            .commit();
                } else if (tab.getPosition() == 1) {
                    getChildFragmentManager().beginTransaction()
                            .replace(R.id.replacable_frame_layout, AerialWorkProgressFragment.newInstance(projectId), "data upload")
                            .commit();
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (aerialLandingFragmentBinding != null) {
            aerialLandingFragmentBinding = null;
        }
    }

}