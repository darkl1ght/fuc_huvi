package com.huviair.capture.ui.snags.snaglist;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.lookups.Lookup;
import com.huviair.capture.data.model.api.snags.ApproverDetails;
import com.huviair.capture.data.model.api.snags.Snag;
import com.huviair.capture.data.model.api.snags.TaskStatus;
import com.huviair.capture.databinding.FragmentSnagBottomModalBinding;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.viewmodels.SnagListItemModel;

import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SnagApproveBottomSheetFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SnagApproveBottomSheetFragment extends BottomSheetDialogFragment {

    private static final String SNAG = "SNAG";
    private static final String LEVEL = "LEVEL";
    private FragmentSnagBottomModalBinding snagBottomModalBinding;
    private SnagListItemModel snagListItemModel;

    private List<Lookup> lookups;

    private Snag selectedSnag;
    private boolean isLevel1user = false;

    public SnagApproveBottomSheetFragment() {
        // Required empty public constructor
    }

    public static SnagApproveBottomSheetFragment newInstance(Snag snag, String level) {
        SnagApproveBottomSheetFragment fragment = new SnagApproveBottomSheetFragment();
        Bundle args = new Bundle();
        args.putSerializable(SNAG, snag);
        args.putString(LEVEL, level);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            selectedSnag = (Snag) getArguments().getSerializable(SNAG);
            isLevel1user = getArguments().getString(LEVEL).equalsIgnoreCase("level1");
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        // Resize the fragment on keyboard visibility
        requireDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        snagBottomModalBinding = FragmentSnagBottomModalBinding.inflate(inflater, container, false);
        return snagBottomModalBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        snagListItemModel = new ViewModelProvider(requireParentFragment()).get(SnagListItemModel.class);

        // Fetch lookups
        snagListItemModel.fetchLookUps(CommonConstants.LOOKUP_TYPE_VERIFICATION_STATUS);

        snagListItemModel.getLookups().observe(getViewLifecycleOwner(), lookUpsResult -> {
            if (lookUpsResult.getSuccess() != null && lookUpsResult.getSuccess().getLookupList() != null) {
                // Map values if success
                this.lookups = lookUpsResult.getSuccess().getLookupList();
                snagBottomModalBinding.snagTextView.setAdapter(new ArrayAdapter<>(requireContext(), R.layout.list_item, lookups));

                // populate existing values
                snagBottomModalBinding.snagTextView.setText(isLevel1user ? selectedSnag.getLevel1Status().getStatus().getDesc() : selectedSnag.getLevel2Status().getStatus().getDesc(), false);
                snagBottomModalBinding.commentsEditText.setText(isLevel1user ? selectedSnag.getLevel1Status().getComment() : selectedSnag.getLevel2Status().getComment());
            }
            if (lookUpsResult.getError() != null) {
                Toast.makeText(requireContext(), "Unable to get details, please check your connection", Toast.LENGTH_LONG).show();
            }
        });

        disableSaveForNonAuthorizedUsers();
        addTextWatcherAndValidate();
        bindListenersAndSave();
        observeForSnagSaveChanges();

    }

    private void disableSaveForNonAuthorizedUsers() {
        String loggedInUserEmail = new SharedPreferencesManager(requireContext()).getLoggedInUserEmail();

        String level1TaskStatus = selectedSnag.getLevel1Status().getStatus().getCode();
        String level2TaskStatus = selectedSnag.getLevel2Status().getStatus().getCode();

        if (!CommonConstants.EMPTY_STRING.equals(loggedInUserEmail)) {
            String[] levelUsers = isLevel1user ? selectedSnag.getLevel1Users() : selectedSnag.getLevel2Users();
            if (!Arrays.asList(levelUsers).contains(loggedInUserEmail)) {
                Snackbar.make(requireDialog().getWindow().getDecorView(), "You are not an assignee", Snackbar.LENGTH_SHORT)
                        .setAnchorView(snagBottomModalBinding.saveSnagDetails)
                        .show();
                disableFields();
            }
            if (isLevel1user && Arrays.asList(levelUsers).contains(loggedInUserEmail)) {
                if (CommonConstants.VERIFICATION_STATUS_ACCEPTED_REJECTED.contains(level1TaskStatus)
                        && CommonConstants.VERIFICATION_STATUS_PENDING_ACCEPTED.contains(level2TaskStatus)) {
                    disableFields();

                    String message = "";

                    if(CommonConstants.VERIFICATION_STATUS_ACCEPTED.equals(level2TaskStatus))
                        message = "Update of snag not allowed as level-2 has already accepted the snag";
                    else if(CommonConstants.VERIFICATION_STATUS_PENDING.equals(level2TaskStatus))
                        message = "Update of snag not allowed as level-2 has not updated the snag";

                    Snackbar.make(requireDialog().getWindow().getDecorView(), message, Snackbar.LENGTH_LONG)
                            .setAnchorView(snagBottomModalBinding.saveSnagDetails)
                            .show();

                }
            }
        }

    }

    private void disableFields() {
        // Disable any updates
        snagBottomModalBinding.comments.setEnabled(false);
        snagBottomModalBinding.verificationStatusSnag.setEnabled(false);
        snagBottomModalBinding.saveSnagDetails.setEnabled(false);
    }

    private void addTextWatcherAndValidate() {
        snagBottomModalBinding.commentsEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s != null && (!"".equals(s.toString().trim()))) {
                    snagBottomModalBinding.comments.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void bindListenersAndSave() {
        snagBottomModalBinding.saveSnagDetails.setOnClickListener(v -> validateAndSubmit());
        snagBottomModalBinding.snagTextView.setOnItemClickListener((parent, view, position, id) -> snagBottomModalBinding.comments.setError(null));
        snagBottomModalBinding.cancel.setOnClickListener(v -> dismiss());
    }

    private void validateAndSubmit() {
        // get the corresponding lookup chosen
        lookups.stream().filter(lookup -> snagBottomModalBinding.snagTextView.getText().toString().equalsIgnoreCase(lookup.getValue()))
                .findFirst()
                .ifPresent(lookup -> {
                    if (CommonConstants.VERIFICATION_STATUS_CONDITIONALLY_ACCEPTED.equalsIgnoreCase(lookup.getKey())) {
                        if ("".equals(snagBottomModalBinding.commentsEditText.getText().toString().trim())) {
                            snagBottomModalBinding.comments.setError("Please Provide comments");
                        } else submit(lookup);
                    } else submit(lookup);

                });

    }

    private void submit(Lookup lookup) {
        snagListItemModel.saveSnagLevelStatus(selectedSnag.getListPositionOfTheSnag(),
                selectedSnag.getProjectId(),
                isLevel1user ? "level1" : "level2", selectedSnag.getTaskId(),
                new ApproverDetails(new TaskStatus(lookup.getKey(), lookup.getValue()),
                        snagBottomModalBinding.commentsEditText.getText().toString()));
    }

    private void observeForSnagSaveChanges() {
        snagListItemModel.getSavedSnagResponseMutableLiveData().observe(getViewLifecycleOwner(), savedSnagResponse -> {
            if (getViewLifecycleOwner().getLifecycle().getCurrentState() == Lifecycle.State.RESUMED) {
                dismiss();
            }
        });
        snagListItemModel.getIsErrorInSavingApproverDetails().observe(getViewLifecycleOwner(), isError -> {
            if (isError)
                Toast.makeText(requireContext(), "Error in saving snag", Toast.LENGTH_SHORT).show();
        });
    }

}