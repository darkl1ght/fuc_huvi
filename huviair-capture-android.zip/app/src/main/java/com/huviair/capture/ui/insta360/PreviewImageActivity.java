package com.huviair.capture.ui.insta360;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.arashivision.sdkmedia.player.image.ImageParamsBuilder;
import com.arashivision.sdkmedia.player.listener.PlayerViewListener;
import com.arashivision.sdkmedia.work.WorkWrapper;
import com.huviair.capture.R;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.databinding.ActivityPreviewImageBinding;
import com.huviair.capture.utils.CommonConstants;

import java.util.List;

public class PreviewImageActivity extends BaseObserveCameraActivity {

    public static final String WORK_URLS = "IMAGE_URLS";

    private ActivityPreviewImageBinding previewImageBinding;
    private static String HDR_FOLDER_PATH = null;


    private WorkWrapper mWorkWrapper;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        previewImageBinding = ActivityPreviewImageBinding.inflate(getLayoutInflater());
        setContentView(previewImageBinding.getRoot());

        //Initialize folder paths
        HDR_FOLDER_PATH = getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER;


        String[] urls = getIntent().getStringArrayExtra(WORK_URLS);
        if (urls == null) {
            finish();
            Toast.makeText(this, R.string.play_toast_empty_path, Toast.LENGTH_SHORT).show();
            return;
        }

        String[] transformedUrls = transformTours(urls);


        previewImageBinding.returnToPlan.setOnClickListener(v -> onBackPressed());

        mWorkWrapper = new WorkWrapper(transformedUrls);

        previewImageBinding.imageLoadingProgress.setVisibility(View.VISIBLE);

        // Invoke play image
        playImage(false);

    }

    private String[] transformTours(String[] urlsToTransform) {
            for (int i = 0; i < urlsToTransform.length; i++) {
                urlsToTransform[i] = urlsToTransform[i].replace(
                        urlsToTransform[i].substring(0, urlsToTransform[i].lastIndexOf("/")), HDR_FOLDER_PATH);
            }

        return urlsToTransform;
    }


    private void playImage(boolean isPlaneMode) {
        previewImageBinding.previewImagePlayer.setVisibility(View.VISIBLE);
        previewImageBinding.previewImagePlayer.setLifecycle(getLifecycle());
        previewImageBinding.previewImagePlayer.setPlayerViewListener(new PlayerViewListener() {
            @Override
            public void onLoadingStatusChanged(boolean isLoading) {
            }

            @Override
            public void onLoadingFinish() {
                previewImageBinding.imageLoadingProgress.setVisibility(View.GONE);
            }

            @Override
            public void onFail(int errorCode, String errorMsg) {
                // if GPU not support, errorCode is -10003 or -10005 or -13020
//                String toast = getString(R.string.play_toast_fail_desc, errorCode, errorMsg);
//                Toast.makeText(PlayAndExportActivity.this, toast, Toast.LENGTH_LONG).show();
            }
        });
        previewImageBinding.previewImagePlayer.prepare(mWorkWrapper, new ImageParamsBuilder());
        previewImageBinding.previewImagePlayer.play();
    }

}
