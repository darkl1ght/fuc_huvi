package com.huviair.capture.viewmodels;

import android.app.Application;
import android.util.Log;
import android.util.Patterns;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.ForgotPasswordResponse;
import com.huviair.capture.data.repositories.ForgotPasswordRepository;
import com.huviair.capture.ui.forgotPassword.ForgotPasswordFormState;

import io.reactivex.observers.DisposableSingleObserver;

public class ForgotPasswordViewModel extends AndroidViewModel {

    private final ForgotPasswordRepository forgotPasswordRepository;
    private final MutableLiveData<Boolean> isEmailSentSuccess = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isErrorInSendingEmail = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isEmailNotRegistered = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>();

    private final MutableLiveData<ForgotPasswordFormState> forgotPasswordFormState = new MutableLiveData<>();

    private final String SUCCESS_STATUS = "0000";
    private final String EMAIL_NOT_EXISTS_STATUS = "10001";

    public ForgotPasswordViewModel(@NonNull Application application) {
        super(application);
        forgotPasswordRepository = new ForgotPasswordRepository();

    }

    public MutableLiveData<ForgotPasswordFormState> getForgotPasswordFormState() {
        return forgotPasswordFormState;
    }

    public MutableLiveData<Boolean> getIsEmailSentSuccess() {
        return isEmailSentSuccess;
    }

    public MutableLiveData<Boolean> getIsEmailNotRegistered() {
        return isEmailNotRegistered;
    }

    public MutableLiveData<Boolean> getIsErrorInSendingEmail() {
        return isErrorInSendingEmail;
    }

    public MutableLiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public void forgotPassword(String email) {
        isLoading.setValue(true);
        forgotPasswordRepository.forgotPassword(email).subscribe(new DisposableSingleObserver<ForgotPasswordResponse>() {
            @Override
            public void onSuccess(ForgotPasswordResponse forgotPasswordResponse) {
                Log.d("Response", forgotPasswordResponse.getStatus());

                isLoading.setValue(false);

                if (SUCCESS_STATUS.equals(forgotPasswordResponse.getStatus()))
                    isEmailSentSuccess.setValue(true);

                else if (EMAIL_NOT_EXISTS_STATUS.equals(forgotPasswordResponse.getStatus()))
                    isEmailNotRegistered.setValue(true);
            }

            @Override
            public void onError(Throwable e) {
                isLoading.setValue(false);
                isErrorInSendingEmail.setValue(true);
                e.printStackTrace();
            }
        });
    }

    public void forgotPasswordDataChanged(String email) {
        if (!isEmailValid(email)) {
            forgotPasswordFormState.setValue(new ForgotPasswordFormState(R.string.invalid_username));
        } else {
            forgotPasswordFormState.setValue(new ForgotPasswordFormState(true));
        }
    }

    // A placeholder username validation check
    private boolean isEmailValid(String email) {
        if (email == null) {
            return false;
        } else
            return Patterns.EMAIL_ADDRESS.matcher(email).matches();

    }



}
