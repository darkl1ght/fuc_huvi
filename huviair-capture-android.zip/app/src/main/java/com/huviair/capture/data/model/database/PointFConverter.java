package com.huviair.capture.data.model.database;

import android.graphics.PointF;

import androidx.room.TypeConverter;

public class PointFConverter {
    @TypeConverter
    public static PointF fromString(String value) {
        String[] pointValues = value.split(",");
        return new PointF(Float.valueOf(pointValues[0]), Float.valueOf(pointValues[1]));
    }

    @TypeConverter
    public static String fromPointF(PointF pointF) {
        return pointF.x + "," + pointF.y;
    }
}
