package com.huviair.capture.data.repositories;

import android.app.Application;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.api.MediaAPIService;
import com.huviair.capture.data.model.api.azure.AzureTokenResponse;
import com.huviair.capture.data.model.api.media.MediaResponse;
import com.huviair.capture.data.model.api.media.ProjectAlbumsRequest;
import com.huviair.capture.data.model.api.media.ProjectAlbumsResponse;
import com.huviair.capture.data.model.api.media.ProjectMediaRequest;
import com.huviair.capture.data.model.api.media.SingleAlbumResponse;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;

import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class ProjectMediaRepository {

    private final MediaAPIService mediaAPIService;
    private final APIService commonApiService;


    public ProjectMediaRepository(Application application) {
        // init services
        mediaAPIService = APIClient.createService(MediaAPIService.class, application, APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(application).getJwtToken());
        commonApiService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(application).getJwtToken());
    }

    public Single<ProjectAlbumsResponse> getProjectMediaDetails(String projectId) {
        return mediaAPIService.getProjectMediaDetails(projectId);
    }

    public Single<SingleAlbumResponse> createAlbum(String projectId, ProjectAlbumsRequest request) {
        return mediaAPIService.createAlbum(projectId, request);
    }

    public Single<AzureTokenResponse> getAzureWritePermissionToken() {
        return commonApiService.getAzureTokenWritePermission(CommonConstants.MEDIA)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<MediaResponse> createMedia(String projectId, ProjectMediaRequest request) {
        return mediaAPIService.createMedia(projectId, request);
    }

}
