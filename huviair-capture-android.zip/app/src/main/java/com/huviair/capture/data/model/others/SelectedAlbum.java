package com.huviair.capture.data.model.others;

import com.google.android.material.card.MaterialCardView;
import com.huviair.capture.data.model.api.media.Album;

public class SelectedAlbum {
    private Album album;
    private MaterialCardView selectedAlbumView;

    public SelectedAlbum(Album album, MaterialCardView selectedAlbumView) {
        this.album = album;
        this.selectedAlbumView = selectedAlbumView;
    }

    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }

    public MaterialCardView getSelectedAlbumView() {
        return selectedAlbumView;
    }

    public void setSelectedAlbumView(MaterialCardView selectedAlbumView) {
        this.selectedAlbumView = selectedAlbumView;
    }
}
