package com.huviair.capture.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.huviair.capture.data.model.database.AerialUploadTourDetails;

import java.util.List;

import io.reactivex.Single;

@Dao
public interface AerialTourDetailsDAO {

    @Insert
    Single<Long> insertTour(AerialUploadTourDetails tour);

    @Query("SELECT * FROM AERIAL_UPLOAD_TOUR_DETAILS WHERE AERIAL_TOUR_ID = :aerialTourId ORDER BY id ASC")
    Single<List<AerialUploadTourDetails>> getAerialToursToUpload(String aerialTourId);

    @Query("UPDATE AERIAL_UPLOAD_TOUR_DETAILS SET IS_IMAGE_UPLOADED = :isUploaded WHERE id = :rowId")
    void markAerialImageUploadStatus(boolean isUploaded, int rowId);


}
