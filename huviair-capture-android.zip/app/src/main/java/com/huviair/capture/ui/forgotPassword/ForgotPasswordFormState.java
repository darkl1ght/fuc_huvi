package com.huviair.capture.ui.forgotPassword;

import androidx.annotation.Nullable;

public class ForgotPasswordFormState {
    @Nullable
    private final Integer usernameError;
    private final boolean isDataValid;

    public ForgotPasswordFormState(@Nullable Integer usernameError) {
        this.usernameError = usernameError;
        this.isDataValid = false;
    }

    public ForgotPasswordFormState(boolean isDataValid) {
        this.usernameError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    Integer getUsernameError() {
        return usernameError;
    }

    boolean isDataValid() {
        return isDataValid;
    }
}
