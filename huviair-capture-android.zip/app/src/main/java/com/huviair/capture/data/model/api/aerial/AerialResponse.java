package com.huviair.capture.data.model.api.aerial;

import java.util.List;

public class AerialResponse {
    private List<AerialTour> tours;

    public List<AerialTour> getTours() {
        return tours;
    }

    public void setTours(List<AerialTour> tours) {
        this.tours = tours;
    }
}
