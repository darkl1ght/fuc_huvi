package com.huviair.capture.data.model.api.snags;

import com.huviair.capture.utils.CommonConstants;

import java.util.List;

public class SnagMediaWithHeader{
    private String header;
    private List<SnagMedia> snagMedia;

    public SnagMediaWithHeader(String header, List<SnagMedia> snagMedia) {
        switch(header){
            case CommonConstants.SNAG_STATUS_CREATED:
                this.header = "Snag Created";
                break;
            case CommonConstants.SNAG_STATUS_LEVEL1_UPDATED:
                this.header = "Level 1 updated";
                break;
            case CommonConstants.SNAG_STATUS_LEVEL2_UPDATED:
                this.header = "Level 2 updated";
                break;
            default:
                this.header = "Snag Created";
        }

        this.snagMedia = snagMedia;
    }

    public List<SnagMedia> getSnagMedia() {
        return snagMedia;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public void setSnagMedia(List<SnagMedia> snagMedia) {
        this.snagMedia = snagMedia;
    }

    public String getHeader() {
        return header;
    }
}
