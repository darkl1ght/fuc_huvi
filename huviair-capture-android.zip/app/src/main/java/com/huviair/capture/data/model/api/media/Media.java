package com.huviair.capture.data.model.api.media;

import com.google.gson.annotations.Expose;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

public class Media implements Serializable, Comparable {

    private String[] tags;
    private String mediaId;
    private String blobContentId;
    private String mediaName;
    private MediaType mediaType;
    private String mediaDescription;
    private String albumId;
    private String fileDate;
    private String projectId;
    private MediaMetaData meta;

    // Ignore in the RESt call
    @Expose(deserialize = false, serialize = false)
    private String thumbnailPath;

    public static final int IMAGE_TYPE = 0;
    public static final int VIDEO_TYPE = 1;
    public static final int VIDEO_TYPE_360 = 2;

    public Media() {

    }

    public Media(String mediaDescription, String albumId, String fileDate, String projectId, MediaMetaData mediaMetaData) {
        this.mediaDescription = mediaDescription;
        this.albumId = albumId;
        this.fileDate = fileDate;
        this.projectId = projectId;
        this.meta = mediaMetaData;
    }

    public String[] getTags() {
        return tags;
    }

    public void setTags(String[] tags) {
        this.tags = tags;
    }

    public String getMediaId() {
        return mediaId;
    }

    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }

    public String getBlobContentId() {
        return blobContentId;
    }

    public void setBlobContentId(String blobContentId) {
        this.blobContentId = blobContentId;
    }

    public String getMediaName() {
        return mediaName;
    }

    public void setMediaName(String mediaName) {
        this.mediaName = mediaName;
    }

    public MediaType getMediaType() {
        return mediaType;
    }

    public void setMediaType(MediaType mediaType) {
        this.mediaType = mediaType;
    }

    public void setMediaDescription(String mediaDescription) {
        this.mediaDescription = mediaDescription;
    }

    public String getAlbumId() {
        return albumId;
    }

    public void setAlbumId(String albumId) {
        this.albumId = albumId;
    }

    public String getFileDate() {
        return fileDate;
    }

    public void setFileDate(String fileDate) {
        this.fileDate = fileDate;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public MediaMetaData getMeta() {
        return meta;
    }

    public void setMeta(MediaMetaData mediaMetaData) {
        this.meta = mediaMetaData;
    }

    public String getMediaDescription() {
        return mediaDescription;
    }

    public String getThumbnailPath() {
        return thumbnailPath;
    }

    public void setThumbnailPath(String thumbnailPath) {
        this.thumbnailPath = thumbnailPath;
    }

    @Override
    public String toString() {
        return "Media{" +
                "tags=" + Arrays.toString(tags) +
                ", mediaId='" + mediaId + '\'' +
                ", blobContentId='" + blobContentId + '\'' +
                ", mediaName='" + mediaName + '\'' +
                ", mediaType=" + mediaType +
                ", mediaDescription='" + mediaDescription + '\'' +
                ", albumId='" + albumId + '\'' +
                ", fileDate='" + fileDate + '\'' +
                ", projectId='" + projectId + '\'' +
                ", meta=" + meta +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Media media = (Media) o;
        return Arrays.equals(tags, media.tags) &&
                Objects.equals(mediaId, media.mediaId) &&
                Objects.equals(blobContentId, media.blobContentId) &&
                Objects.equals(mediaName, media.mediaName);
    }

    @Override
    public int compareTo(Object o) {
        Media media = (Media) o;
        if (this.mediaId.equals(media.getAlbumId())
                && this.blobContentId.equals(media.getBlobContentId())) return 0;

        return 1;
    }
}
