package com.huviair.capture.data.model.api.tours;

public class Image {
    private String imageId;
    private String blobImageId;
    private String imageName;
    private double offsetFromNorth;

    public Image(String imageId, String blobImageId, String imageName) {
        this.imageId = imageId;
        this.blobImageId = blobImageId;
        this.imageName = imageName;
    }

    public Image(String imageId, String blobImageId, String imageName, double offsetFromNorth) {
        this.imageId = imageId;
        this.blobImageId = blobImageId;
        this.imageName = imageName;
        this.offsetFromNorth = offsetFromNorth;
    }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public String getBlobImageId() {
        return blobImageId;
    }

    public void setBlobImageId(String blobImageId) {
        this.blobImageId = blobImageId;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    @Override
    public String toString() {
        return "Image{" +
                "imageId='" + imageId + '\'' +
                ", blobImageId='" + blobImageId + '\'' +
                ", imageName='" + imageName + '\'' +

                '}';
    }
}
