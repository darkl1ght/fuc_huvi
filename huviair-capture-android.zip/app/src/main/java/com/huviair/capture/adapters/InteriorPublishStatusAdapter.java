package com.huviair.capture.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.WorkInfo;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.model.database.InteriorVideoCapture;
import com.huviair.capture.databinding.InteriorDataUploadViewBinding;
import com.huviair.capture.databinding.VideoCaptureViewBinding;
import com.huviair.capture.ui.interiors.videocapture.publish.VideoCapturePublish;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.viewmodels.InteriorsViewModel;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class InteriorPublishStatusAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_WORKINFO = 0;
    private static final int VIEW_TYPE_VIDEOCAPTURE = 1;

    private final List<Object> dataList;


    private InteriorsViewModel interiorsViewModel;

    public InteriorPublishStatusAdapter(List<Object> dataList) {
        this.dataList = dataList;
    }

    @Override
    public int getItemViewType(int position) {
        if (dataList.get(position) instanceof WorkInfo) {
            return VIEW_TYPE_WORKINFO;
        } else if (dataList.get(position) instanceof InteriorVideoCapture) {
            return VIEW_TYPE_VIDEOCAPTURE;
        }
        return super.getItemViewType(position);
    }

    @Override
    public void onAttachedToRecyclerView(@androidx.annotation.NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        if (interiorsViewModel == null) {
            interiorsViewModel = new ViewModelProvider((ViewModelStoreOwner) recyclerView.getContext()).get(InteriorsViewModel.class);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == VIEW_TYPE_WORKINFO) {
            return new WorkInfoViewHolder(InteriorDataUploadViewBinding.inflate(inflater, parent, false));
        } else if (viewType == VIEW_TYPE_VIDEOCAPTURE) {
           return new VideoCaptureViewHolder(VideoCaptureViewBinding.inflate(inflater, parent, false));
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NotNull RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        if (viewType == VIEW_TYPE_WORKINFO) {
            WorkInfo workInfo = (WorkInfo) dataList.get(position);
            WorkInfoViewHolder workInfoViewHolder = (WorkInfoViewHolder) holder;

            String interiorWalkthroughId = workInfo.getOutputData().getString(CommonConstants.WALKTHROUGH_ID);
            String walkthroughName = workInfo.getOutputData().getString(CommonConstants.TOUR_NAME);
            String interiorTourId = workInfo.getOutputData().getString(CommonConstants.INTERIOR_TOUR_ID);
            String projectId = workInfo.getOutputData().getString(CommonConstants.PROJECT_ID);
            String towerId = workInfo.getOutputData().getString(CommonConstants.TOWER_ID);

            workInfoViewHolder.interiorDataUploadViewBinding.floorName.setText(walkthroughName);

            // Publish tour job triggeri
            workInfoViewHolder.interiorDataUploadViewBinding.publishTour.setOnClickListener(v -> interiorsViewModel.scheduleForTourPublish(walkthroughName, projectId, interiorTourId, interiorWalkthroughId, towerId));

            // Retry the failed job
            workInfoViewHolder.interiorDataUploadViewBinding.retryPublish.setOnClickListener(v -> {
                if (workInfo.getTags().contains(CommonConstants.EXPORT_HDR_WORKER))
                    interiorsViewModel.retryStitchAndExportImages(walkthroughName, interiorTourId, interiorWalkthroughId, towerId);
                else if (workInfo.getTags().contains(CommonConstants.COMPRESS_PUBLISH_IMAGE_WORKER))
                    interiorsViewModel.scheduleForTourPublish(walkthroughName, projectId, interiorTourId, interiorWalkthroughId, towerId);

            });
            switch (workInfo.getState()) {
                case SUCCEEDED:
                    if (workInfo.getTags().contains(CommonConstants.EXPORT_HDR_WORKER))
                        workInfoViewHolder.interiorDataUploadViewBinding.publishTour.setVisibility(View.VISIBLE);
                    else if (workInfo.getTags().contains(CommonConstants.COMPRESS_PUBLISH_IMAGE_WORKER))
                        workInfoViewHolder.interiorDataUploadViewBinding.publishedSuccess.setVisibility(View.VISIBLE);
                    break;
                case FAILED:
                    workInfoViewHolder.interiorDataUploadViewBinding.retryPublish.setVisibility(View.VISIBLE);
                    break;
                default:

            }
        }
        else if (viewType == VIEW_TYPE_VIDEOCAPTURE) {
            InteriorVideoCapture videoCapture = (InteriorVideoCapture) dataList.get(position);
            VideoCaptureViewHolder videoCaptureViewHolder = (VideoCaptureViewHolder) holder;
            videoCaptureViewHolder.videoCaptureViewBinding.floorName.setText(videoCapture.getTourName());

            if(videoCapture.isVideoUploaded()) {
                videoCaptureViewHolder.videoCaptureViewBinding.publishedSuccess.setVisibility(View.VISIBLE);
            }
            else {
                videoCaptureViewHolder.videoCaptureViewBinding.publishTour.setVisibility(View.VISIBLE);
            }

            videoCaptureViewHolder.videoCaptureViewBinding.publishTour.setOnClickListener(view -> {
                FragmentManager fragmentManager = ((AppCompatActivity) videoCaptureViewHolder.videoCaptureViewBinding.getRoot().getContext()).getSupportFragmentManager();
                Fragment fragment = new VideoCapturePublish(new Tour(null, videoCapture.getInteriorId(),videoCapture.getTourId(),videoCapture.getTourName(),
                        videoCapture.getTowerId(), videoCapture.getProjectId(),null));
                fragmentManager.beginTransaction()
                        .replace(R.id.video_capture_publish_container, fragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .addToBackStack(null)
                        .commit();
            });

        }
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }


    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class WorkInfoViewHolder extends RecyclerView.ViewHolder {
        public InteriorDataUploadViewBinding interiorDataUploadViewBinding;

        public WorkInfoViewHolder(InteriorDataUploadViewBinding interiorDataUploadViewBinding) {
            super(interiorDataUploadViewBinding.getRoot());
            this.interiorDataUploadViewBinding = interiorDataUploadViewBinding;
        }

    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class VideoCaptureViewHolder extends RecyclerView.ViewHolder {
        public VideoCaptureViewBinding videoCaptureViewBinding;

        public VideoCaptureViewHolder(VideoCaptureViewBinding videoCaptureViewBinding) {
            super(videoCaptureViewBinding.getRoot());
            this.videoCaptureViewBinding = videoCaptureViewBinding;
        }

    }
}

