package com.huviair.capture.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.recyclerview.widget.RecyclerView;

import com.huviair.capture.R;
import com.huviair.capture.ui.common.MultiSelectViewItem;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.stream.Collectors;

public class MultiSelectRecyclerViewAdapter extends RecyclerView.Adapter<MultiSelectRecyclerViewAdapter.ViewHolder> implements Filterable {

    private final List<MultiSelectViewItem> mValues;
    private List<MultiSelectViewItem> filteredValues;

    public MultiSelectRecyclerViewAdapter(List<MultiSelectViewItem> items) {
        mValues = items;
        filteredValues = items;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = filteredValues.get(position);
        holder.itemContent.setText(holder.mItem.getContent());
        holder.itemContent.setChecked(holder.mItem.isSelected());

        holder.itemContent.setOnClickListener(v -> {
            filteredValues.get(position).setSelected(!mValues.get(position).isSelected());
            holder.itemContent.setChecked(mValues.get(position).isSelected());
        });
    }

    @Override
    public int getItemCount() {
        return filteredValues.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String stringToSearch = constraint.toString().trim();

                if (!constraint.equals("")) {
                    filteredValues = mValues.stream().filter(value -> value.getContent().toLowerCase().contains(stringToSearch.toLowerCase()))
                            .collect(Collectors.toList());
                } else filteredValues = mValues;

                FilterResults results = new FilterResults();
                results.values = filteredValues;
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredValues = (List<MultiSelectViewItem>) results.values;
                notifyDataSetChanged();
            }
        };
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final CheckedTextView itemContent;
        public MultiSelectViewItem mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            itemContent = view.findViewById(R.id.list);
        }

    }

    public List<MultiSelectViewItem> getFilteredValues() {
        return filteredValues;
    }
}