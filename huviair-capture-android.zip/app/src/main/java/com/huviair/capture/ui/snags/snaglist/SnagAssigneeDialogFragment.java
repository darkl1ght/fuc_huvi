package com.huviair.capture.ui.snags.snaglist;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import com.huviair.capture.R;
import com.huviair.capture.data.model.api.snags.Snag;

import java.util.Arrays;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SnagAssigneeDialogFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SnagAssigneeDialogFragment extends DialogFragment {

    private static final String SNAG = "SNAG";
    private Snag snag;

    public SnagAssigneeDialogFragment() {
        // Required empty public constructor
    }

    public static SnagAssigneeDialogFragment newInstance(Snag selectedSnag) {
        SnagAssigneeDialogFragment fragment = new SnagAssigneeDialogFragment();
        Bundle args = new Bundle();
        args.putSerializable(SNAG, selectedSnag);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            snag = (Snag) getArguments().getSerializable(SNAG);

        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_snag_assignee_dialog, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        TextView level1Assignee = view.findViewById(R.id.level1_assignee_value);
        TextView level2Assignee = view.findViewById(R.id.level2_assignee_value);

        String level1Users = "";
        String level2Users = "";
        if (snag.getLevel1Users() != null && snag.getLevel1Users().length > 0) {
            level1Users = populateAssignees(snag.getLevel1Users());
        }
        if (snag.getLevel2Users() != null && snag.getLevel2Users().length > 0) {
            level2Users = populateAssignees(snag.getLevel2Users());
        }

        level1Assignee.setText(level1Users);
        level2Assignee.setText(level2Users);

        super.onViewCreated(view, savedInstanceState);

    }

    private String populateAssignees(String[] assignees) {
        String assigneesToString = Arrays.toString(assignees);
        return assigneesToString.substring(1, assigneesToString.length() - 1);
    }
}