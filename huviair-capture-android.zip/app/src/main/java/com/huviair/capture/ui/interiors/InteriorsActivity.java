package com.huviair.capture.ui.interiors;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.interpolator.view.animation.FastOutSlowInInterpolator;
import androidx.lifecycle.ViewModelProvider;
import androidx.work.WorkInfo;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.transition.platform.MaterialContainerTransform;
import com.google.android.material.transition.platform.MaterialContainerTransformSharedElementCallback;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.projects.Project;
import com.huviair.capture.data.model.api.tours.Interior;
import com.huviair.capture.data.model.api.tours.Tour;
import com.huviair.capture.data.model.api.tours.interiorsResponse.FloorWalkThrough;
import com.huviair.capture.databinding.ActivityProjectInteriorsBinding;
import com.huviair.capture.ui.aerial.AerialActivity;
import com.huviair.capture.ui.interiors.publish.InteriorTourPublishFragment;
import com.huviair.capture.ui.interiors.videocapture.landing.VideoWalkthrough;
import com.huviair.capture.ui.interiors.videocapture.publish.VideoCapturePublish;
import com.huviair.capture.ui.media.ProjectMediaActivity;
import com.huviair.capture.ui.snags.SnagActivity;
import com.huviair.capture.ui.interiors.tours.WalkThroughPlanActivity;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.huviair.capture.viewmodels.InteriorsViewModel;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class InteriorsActivity extends AppCompatActivity implements VideoCapturePublish.OnEventListener {

    public static final String PROJECT = "PROJECT";
    private InteriorsViewModel interiorsViewModel;
    private Project selectedProject;
    private TextWatcher toursTextViewTextWatcher,walkthroughViewTextWatcher,towersTextViewWatcher;


    private ActivityProjectInteriorsBinding interiorsBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS);
        super.onCreate(savedInstanceState);

        interiorsBinding = ActivityProjectInteriorsBinding.inflate(getLayoutInflater());
        setContentView(interiorsBinding.getRoot());


        interiorsViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(InteriorsViewModel.class);

        // Get the project details from parent intent
        if (getIntent().getExtras() != null) {
            selectedProject = (Project) getIntent().getSerializableExtra(PROJECT);
            interiorsViewModel.projectId = selectedProject.getProjectId();
        }

        // Container Transform activity transition
        setEnterSharedElementCallback(new MaterialContainerTransformSharedElementCallback());
        getWindow().setSharedElementEnterTransition(buildContainerTransform());
        getWindow().setSharedElementReturnTransition(buildContainerTransform());


        interiorsBinding.getRoot().setTransitionName(selectedProject.getProjectId());

        interiorsBinding.downloadFloorPlanButton.hide();

        // Populate the tool bar
        MaterialToolbar toolbar = findViewById(R.id.tool_bar);
        toolbar.setTitle("Virtual tour");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        interiorsBinding.projectDetailsName.setText(selectedProject.getProjectName());

        //Disable walkthrough button
        interiorsBinding.walkthroughTextView.setEnabled(false);

        fetchInteriors();

        observeForInteriorsResponse();

        // Add Text watchers
        toursTextViewTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence changedText, int start, int before, int count) {
                String tourToSearch = changedText.toString();
                if (interiorsViewModel.getTourNames().stream().anyMatch(s -> s.equalsIgnoreCase(tourToSearch))) {
                    // remove all existing towers
                    interiorsViewModel.selectedTowerId.setValue("");
                    populateTowers(interiorsViewModel.getTourNames().indexOf(tourToSearch));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
        interiorsBinding.toursTextView.addTextChangedListener(toursTextViewTextWatcher);

        walkthroughViewTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!interiorsBinding.walkthroughTextView.getText().toString().equals("")) {
                    interiorsBinding.viewWalkthroughButton.setEnabled(true);
                    interiorsBinding.videoCaptureMode.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
        interiorsBinding.walkthroughTextView.addTextChangedListener(walkthroughViewTextWatcher);

        towersTextViewWatcher =  new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence changedText, int start, int before, int count) {
                String tourToSearch = changedText.toString();
                if (interiorsViewModel.getWalkThroughResponseList().stream().anyMatch(s -> s.getTowerName().equalsIgnoreCase(tourToSearch))) {
                    interiorsViewModel.selectedTowerId.setValue(interiorsViewModel.getWalkThroughResponseList().stream().filter(floorWalkThrough -> floorWalkThrough.getTowerName().equals(changedText.toString()))
                            .findFirst().get().getTowerId());

                    interiorsBinding.viewWalkthroughButton.setEnabled(false);
                    interiorsBinding.videoCaptureMode.setEnabled(false);

                    // Remove existing walk-through details
                    interiorsBinding.walkthroughTextView.setText("");
                    interiorsBinding.walkthroughTextView.setAdapter(null);
                    interiorsBinding.walkthroughTextInput.setError(null);

                    populateWalkThroughDropDown(interiorsViewModel.getTowerNames().indexOf(tourToSearch));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
        interiorsBinding.towerTextView.addTextChangedListener(towersTextViewWatcher);




        interiorsBinding.viewWalkthroughButton.setOnClickListener(v -> startWalkThroughMapActivity());

        interiorsBinding.videoCaptureMode.setOnClickListener(v -> startVideoWalkThroughActivity());

        populateBottomNavigation();

        swipeToRefresh();

        // Take user input and process download
        interiorsBinding.downloadFloorPlanButton.setOnClickListener(v -> new MaterialAlertDialogBuilder(this)
                .setTitle("Download floor plans ?")
                .setMessage("This will download all the floor plans for the selected tower")
                .setIcon(R.drawable.ic_baseline_arrow_downward_24)
                .setCancelable(true)
                .setPositiveButton("OK", (dialog, which) -> interiorsViewModel.downloadFloorPlans())
                .setNegativeButton("CANCEL", (dialog, which) -> {
                })
                .show());

        // Observe for work info details
        interiorsViewModel.getFloorPlanDownloadWorkInfo().observe(this, workInfos -> {
            if (workInfos == null || workInfos.isEmpty()) return;

            if (workInfos.stream().anyMatch(workInfo -> WorkInfo.State.RUNNING == workInfo.getState() && interiorsViewModel.workUUID.equals(workInfo.getId()))) {
                toggleViews(false);
                interiorsBinding.downloadFloorPlanButton.setVisibility(View.GONE);
                // Show loader and text
                interiorsBinding.loadingTours.setVisibility(View.VISIBLE);
                interiorsBinding.downloadFloorPlanText.setVisibility(View.VISIBLE);

            } else if (workInfos.stream().anyMatch(workInfo -> (WorkInfo.State.SUCCEEDED == workInfo.getState() || WorkInfo.State.FAILED == workInfo.getState())
                    && interiorsViewModel.workUUID.equals(workInfo.getId()))) {
                // Fetch interiors from db, toggle views and update tower and walkthroughs to reflect floor-plans
                fetchInteriors();
                interiorsViewModel.fetchWalkThroughsForTheTour(interiorsViewModel.selectedInteriorId);
                toggleViews(true);

                // disable loader and text
                interiorsBinding.loadingTours.setVisibility(View.GONE);
                interiorsBinding.downloadFloorPlanText.setVisibility(View.GONE);
            }
        });

        interiorsViewModel.publishSingleLiveEvent.observe(this, interiorPublishEvent -> getSupportFragmentManager().beginTransaction()
                .setReorderingAllowed(true)
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                .addToBackStack(null)
                .add(R.id.publish_interiors, InteriorTourPublishFragment.newInstance(interiorPublishEvent.getSelectedInteriorId(), interiorPublishEvent.getSelectedTowerId()), null)
                .commit());
    }

    private void populateTowers(int index) {
        interiorsBinding.walkthroughTextView.setText("");
        interiorsBinding.towerTextView.setText("");
        interiorsBinding.viewWalkthroughButton.setEnabled(false);
        interiorsBinding.videoCaptureMode.setEnabled(false);

        interiorsBinding.walkthroughTextView.setText("");
        interiorsBinding.walkthroughTextView.setAdapter(null);
        interiorsBinding.walkthroughTextInput.setError(null);

        interiorsViewModel.selectedInteriorId = interiorsViewModel.getInteriorsList().get(index).getInteriorId();
        interiorsViewModel.fetchWalkThroughsForTheTour(interiorsViewModel.selectedInteriorId);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.project_details_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@androidx.annotation.NonNull MenuItem item) {
        if (item.getItemId() == R.id.sync_floor_plans) {
            // Set interiors downloaded to false
            new SharedPreferencesManager(this).setIsInteriorsDownloaded(false);
            fetchInteriors();
            return true;

        } else if (item.getItemId() == R.id.tour_work) {
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                    .addToBackStack(null)
                    .add(R.id.interiors_work_status, InteriorTourWorkStatsFragment.newInstance(), null)
                    .commit();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void startWalkThroughMapActivity() {
        Intent intent = new Intent(this, WalkThroughPlanActivity.class);
        String tourName = interiorsBinding.walkthroughTextView.getText().toString();

        interiorsViewModel.getWalkThroughResponseList().stream().filter(floorWalkThrough -> interiorsViewModel.selectedTowerId.getValue().equals(floorWalkThrough.getTowerId()))
                .flatMap(floorWalkThrough -> floorWalkThrough.getTours().stream())
                .forEach(tour -> {
                    if (tour.getTourName().equals(tourName)) {
                        intent.putExtra(WalkThroughPlanActivity.PROJECT_ID, selectedProject.getProjectId());
                        intent.putExtra(WalkThroughPlanActivity.WALK_THROUGH_DETAILS, tour);
                        startActivity(intent);
                    }
                });

    }

    private void startVideoWalkThroughActivity() {
        Intent intent = new Intent(this, VideoWalkthrough.class);
        String tourName = interiorsBinding.walkthroughTextView.getText().toString();

        interiorsViewModel.getWalkThroughResponseList().stream().filter(floorWalkThrough -> interiorsViewModel.selectedTowerId.getValue().equals(floorWalkThrough.getTowerId()))
                .flatMap(floorWalkThrough -> floorWalkThrough.getTours().stream())
                .forEach(tour -> {
                    if (tour.getTourName().equals(tourName)) {
                        intent.putExtra(VideoWalkthrough.PROJECT_ID, selectedProject.getProjectId());
                        intent.putExtra(VideoWalkthrough.WALK_THROUGH_DETAILS, tour);
                        startActivity(intent);
                    }
                });

    }

    private void fetchInteriors() {
        // API call to the view model
        interiorsViewModel.fetchInteriorsForTheProject(selectedProject.getProjectId());

    }

    private void observeForInteriorsResponse() {
        interiorsViewModel.getInteriorsResultMutableLiveData().observe(this, interiorsResult -> {

            interiorsBinding.toursNoData.setVisibility(View.GONE);
            interiorsBinding.noToursFound.setVisibility(View.GONE);
            interiorsBinding.technicalErrorView.getRoot().setVisibility(View.GONE);

            interiorsBinding.walkthroughTextInput.setError("");

            if (interiorsResult.getSuccess() != null && interiorsResult.getSuccess().getInteriors() != null) {
                if (interiorsResult.getSuccess().getInteriors().isEmpty()) {
                    interiorsBinding.toursNoData.setVisibility(View.VISIBLE);
                    interiorsBinding.noToursFound.setVisibility(View.VISIBLE);
                } else populateInteriorDropdown(interiorsResult.getSuccess().getInteriors());
            }

            if (interiorsResult.getSuccess() != null && interiorsResult.getSuccess().getTours() != null) {
                if (interiorsResult.getSuccess().getTours().isEmpty()) {
                    // Remove previous adapter
                    interiorsBinding.walkthroughTextView.setAdapter(null);
                    interiorsBinding.walkthroughTextInput.setError(getResources().getString(R.string.no_tour_data_available));

                    Snackbar.make(interiorsBinding.getRoot(), R.string.no_tour_data_available, 5000)
                            .setBackgroundTint(ContextCompat.getColor(InteriorsActivity.this,
                                    R.color.snackbar_default))
                            .setAnchorView(R.id.bottom_navigation_interiors)
                            .show();
                } else {
                    populateTowersDropDown(interiorsResult.getSuccess().getTours());
                }
            }

            if (interiorsResult.getError() != null) {
                disableViewsOnError();
                Snackbar.make(interiorsBinding.getRoot(), R.string.technical_error, Snackbar.LENGTH_INDEFINITE)
                        .setBackgroundTint(ContextCompat.getColor(InteriorsActivity.this,
                                R.color.snackbar_default))
                        .setAnchorView(R.id.bottom_navigation_interiors)
                        .setAction("RETRY", v -> interiorsViewModel.fetchInteriorsForTheProject(selectedProject.getProjectId()))
                        .show();
            }

        });

        interiorsViewModel.isFetchingData.observe(this, isLoading -> interiorsBinding.loadingTours.setVisibility(isLoading ? View.VISIBLE : View.GONE));

        interiorsViewModel.selectedTowerId.observe(this, s -> {
            if (s == null || CommonConstants.EMPTY_STRING.equals(s))
                interiorsBinding.downloadFloorPlanButton.hide();
            else interiorsBinding.downloadFloorPlanButton.show();
        });

    }

    private void populateInteriorDropdown(List<Interior> interiors) {
        toggleViews(true);
        interiorsViewModel.setTourNames(interiors.stream().map(Interior::getInteriorName).collect(Collectors.toList()));
        interiorsBinding.toursTextView.setAdapter(new ArrayAdapter<>(InteriorsActivity.this, R.layout.list_item, interiorsViewModel.getTourNames()));
    }

    private void populateTowersDropDown(List<FloorWalkThrough> floorWalkThroughs) {
        List<String> towerNames = floorWalkThroughs.stream().map(FloorWalkThrough::getTowerName).collect(Collectors.toList());
        interiorsViewModel.setTowerNames(towerNames);
        interiorsBinding.towerTextView.setAdapter(new ArrayAdapter<>(InteriorsActivity.this, R.layout.list_item, towerNames));
        interiorsBinding.towerTextView.setEnabled(true);
    }

    private void populateWalkThroughDropDown(int index) {
        List<Tour> tours = interiorsViewModel.getWalkThroughResponseList().get(index).getTours();
        if (tours.isEmpty()) {
            interiorsBinding.walkthroughTextInput.setError("No walk-throughs available to process, please sync interiors to get the latest data (if any)");
            interiorsBinding.downloadFloorPlanButton.hide();
        } else {
            List<String> walkThroughNames = tours.stream().sorted(Comparator.comparing(Tour::getTourName))
                                                 .map(Tour::getTourName).collect(Collectors.toList());
            interiorsBinding.downloadFloorPlanButton.show();
            interiorsBinding.walkthroughTextView.setAdapter(new ArrayAdapter<>(InteriorsActivity.this, R.layout.list_item, walkThroughNames));
            interiorsBinding.walkthroughTextView.setEnabled(true);
        }

    }

    private void toggleViews(boolean enabled) {
        int visibility = enabled ? View.VISIBLE : View.GONE;
        interiorsBinding.projectDetailsName.setVisibility(visibility);
        interiorsBinding.walkthroughTextInput.setVisibility(visibility);
        interiorsBinding.toursTextInput.setVisibility(visibility);
        interiorsBinding.towerInput.setVisibility(visibility);
        interiorsBinding.viewWalkthroughButton.setVisibility(visibility);
        interiorsBinding.videoCaptureMode.setVisibility(visibility);
    }

    private void disableViewsOnError() {
        interiorsBinding.technicalErrorView.getRoot().setVisibility(View.VISIBLE);
        toggleViews(false);
    }

    // Container transform transition - Material Library
    private MaterialContainerTransform buildContainerTransform() {
        MaterialContainerTransform transform = new MaterialContainerTransform();
        transform.addTarget(interiorsBinding.getRoot());
        transform.setInterpolator(new FastOutSlowInInterpolator());
        transform.setFadeMode(MaterialContainerTransform.FADE_MODE_IN);
        transform.setAllContainerColors(MaterialColors.getColor(interiorsBinding.getRoot(), R.attr.colorSurface));
        transform.setDuration(400);
        return transform;
    }

    private void populateBottomNavigation() {
        interiorsBinding.bottomNavigationInteriors.getRoot().setSelectedItemId(R.id.interiors);

        interiorsBinding.bottomNavigationInteriors.getRoot().setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            // if (itemId == R.id.media) {
            //     Intent projectMediaIntent = new Intent(this, ProjectMediaActivity.class);
            //     projectMediaIntent.putExtra(ProjectMediaActivity.SELECTED_PROJECT, selectedProject);
            //     startActivity(projectMediaIntent);
            //     overridePendingTransition(0, 0);
            //     finish();

            // } else 
            if (itemId == R.id.snag) {
                Intent interiorIntent = new Intent(this, SnagActivity.class);
                interiorIntent.putExtra(SnagActivity.SELECTED_PROJECT, selectedProject);
                startActivity(interiorIntent);
                overridePendingTransition(0, 0);
                finish();
            } else if (itemId == R.id.aerial) {
                Intent interiorIntent = new Intent(this, AerialActivity.class);
                interiorIntent.putExtra(SnagActivity.SELECTED_PROJECT, selectedProject);
                startActivity(interiorIntent);
                overridePendingTransition(0, 0);
                finish();
            }
            return true;
        });
    }

    private void swipeToRefresh() {
        interiorsBinding.interiorsSwipeToRefresh.setOnRefreshListener(() -> {
            observeForInteriorsResponse();
            interiorsBinding.interiorsSwipeToRefresh.setRefreshing(false);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        interiorsBinding.toursTextView.removeTextChangedListener(toursTextViewTextWatcher);
        interiorsBinding.walkthroughTextView.removeTextChangedListener(walkthroughViewTextWatcher);
        interiorsBinding.towerTextView.removeTextChangedListener(towersTextViewWatcher);

    }

    @Override
    public void onWalkthroughUploadComplete(String interiorId, String towerId) {
        interiorsViewModel.getVideoCaptureDetailsByTowerId(interiorId, towerId);
    }
}