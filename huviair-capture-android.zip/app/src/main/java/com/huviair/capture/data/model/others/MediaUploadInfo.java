package com.huviair.capture.data.model.others;

import java.util.concurrent.atomic.AtomicInteger;

public class MediaUploadInfo {
    private AtomicInteger processingCount;
    private int fileSize;

    public MediaUploadInfo(AtomicInteger processingCount, int fileLength) {
        this.fileSize = fileLength;
        this.processingCount = processingCount;
    }

    public AtomicInteger getProcessingCount() {
        return processingCount;
    }

    public void setFileSize(int fileSize) {
        this.fileSize = fileSize;
    }

    public void setProcessingCount(AtomicInteger processingCount) {
        this.processingCount = processingCount;
    }

    public int getFileSize() {
        return fileSize;
    }

    public void incrementProcessedCount() {
        this.processingCount.getAndIncrement();
    }

    public void resetValues() {
        this.processingCount.set(0);
        this.setFileSize(0);
    }
}
