package com.huviair.capture.ui.interiors;

import androidx.annotation.Nullable;

import com.huviair.capture.ui.interiors.InteriorDataView;

// A class utilized by the UI based on the result type
public class InteriorsResult {
    @Nullable
    private InteriorDataView success;
    @Nullable
    private Integer error;

    public InteriorsResult(@Nullable Integer error) {
        this.error = error;
    }

    public InteriorsResult(@Nullable InteriorDataView success) {
        this.success = success;
    }

    @Nullable
    InteriorDataView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }
}
