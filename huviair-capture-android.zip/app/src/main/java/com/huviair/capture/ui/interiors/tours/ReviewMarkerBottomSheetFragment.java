package com.huviair.capture.ui.interiors.tours;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.huviair.capture.R;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.databinding.FragmentReviewMarkerBottomSheetBinding;
import com.huviair.capture.viewmodels.WalkthroughMapViewModel;

import org.jetbrains.annotations.NotNull;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ReviewMarkerBottomSheetFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ReviewMarkerBottomSheetFragment extends BottomSheetDialogFragment {

    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String FLOOR_PLAN_IMAGE_NUMBER = "param1";
    private static final String IMAGE_NUMBER = "param2";

    private final CompositeDisposable bag = new CompositeDisposable();

    private long imageNumber;
    private long floorPlanImageNumber;
    private DataCaptureRoomDatabase dataCaptureRoomDatabase;

    private WalkthroughMapViewModel walkthroughMapViewModel;
    private FragmentReviewMarkerBottomSheetBinding reviewMarkerBottomSheetBinding;

    public ReviewMarkerBottomSheetFragment() {
        // Required empty public constructor
    }


    public static ReviewMarkerBottomSheetFragment newInstance(long floorPlanImageNumber, long imageNumber) {
        ReviewMarkerBottomSheetFragment fragment = new ReviewMarkerBottomSheetFragment();
        Bundle args = new Bundle();
        args.putLong(FLOOR_PLAN_IMAGE_NUMBER, floorPlanImageNumber);
        args.putLong(IMAGE_NUMBER, imageNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            imageNumber = getArguments().getLong(IMAGE_NUMBER);
            floorPlanImageNumber = getArguments().getLong(FLOOR_PLAN_IMAGE_NUMBER);
            dataCaptureRoomDatabase = DataCaptureRoomDatabase.getDatabase(requireContext());
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        BottomSheetBehavior.from((View) requireView().getParent()).setState(BottomSheetBehavior.STATE_EXPANDED);
        BottomSheetBehavior.from((View) requireView().getParent()).setSkipCollapsed(true);
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        reviewMarkerBottomSheetBinding = FragmentReviewMarkerBottomSheetBinding.inflate(inflater, container, false);
        return reviewMarkerBottomSheetBinding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Populate bottom sheet header
        reviewMarkerBottomSheetBinding.headerReviewBottomSheet.setText(getString(R.string.capture_details_header, floorPlanImageNumber));

        walkthroughMapViewModel = new ViewModelProvider(requireActivity()).get(WalkthroughMapViewModel.class);

        reviewMarkerBottomSheetBinding.deleteMarker.setOnClickListener(v -> new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete marker ?")
                .setMessage("This will delete the marker and the captured image")
                .setPositiveButton(getResources().getString(R.string.positive), (dialog, which) -> {
                   bag.add(dataCaptureRoomDatabase.tourDetailsDAO().deleteMarker( walkthroughMapViewModel.getSelectedWalkThrough().getTourId(), imageNumber)
                                           .observeOn(AndroidSchedulers.mainThread())
                                           .subscribeOn(Schedulers.io())
                                           .subscribe(() -> {
                                               walkthroughMapViewModel.isImageDeleted.setValue(true);
                                               requireDialog().dismiss();
                                           }));

                })
                .setNeutralButton(getResources().getString(R.string.neutral), null)
                .setIcon(R.drawable.delete_brand_color)
                .show());

        reviewMarkerBottomSheetBinding.reviewImage.setOnClickListener(v -> {
            walkthroughMapViewModel.isImageReviewed.setValue(imageNumber);
            requireDialog().dismiss();
        });
    }
}