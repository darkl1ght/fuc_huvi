package com.huviair.capture.ui.login;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import android.util.Patterns;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.LoggedInUser;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.LoginRequest;

import java.net.ConnectException;
import java.net.UnknownHostException;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class LoginViewModel extends ViewModel {

    // Mutable Live data observed in the main activity
    private final MutableLiveData<LoginFormState> loginFormState = new MutableLiveData<>();
    private final MutableLiveData<LoginResult> loginResult = new MutableLiveData<>();


    LiveData<LoginFormState> getLoginFormState() {
        return loginFormState;
    }

    LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }

    public void login(String username, String password) {
        //Initalize request
        LoginRequest loginRequest = new LoginRequest(username, password);
        requestLogin(loginRequest);
    }

    public void loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
        } else if (!isPasswordValid(password)) {
            loginFormState.setValue(new LoginFormState(null, R.string.invalid_password));
        } else {
            loginFormState.setValue(new LoginFormState(true));
        }
    }

    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        } else
            return Patterns.EMAIL_ADDRESS.matcher(username).matches();

    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 5;
    }

    private void requestLogin(LoginRequest loginRequest) {

        APIService service = APIClient.createServiceForLogin(APIService.class, APIClient.getSecurityApiBaseUrl());
        // Create observable
        Single<LoggedInUser> loggedInUserObservable = service.login(APIClient.getSecurityApiBaseUrl(), loginRequest);

        //Subscribe
        loggedInUserObservable.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new DisposableSingleObserver<LoggedInUser>() {
                    @Override
                    public void onSuccess(@NonNull LoggedInUser loggedInUser) {
                        LoggedInUser.User user = loggedInUser.getUser();
                        loginResult.setValue(new LoginResult(new LoggedInUserView(user.getFirstName(), user.getToken(), user.getEmail())));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        if (e instanceof UnknownHostException || e instanceof ConnectException) {
                            loginResult.setValue(new LoginResult(R.string.technical_error));
                        } else {
                            loginResult.setValue(new LoginResult(R.string.invalid_credentials));
                        }

                    }
                });

    }

    
}
