package com.huviair.capture.ui.media.fragments;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.chip.Chip;
import com.google.android.material.color.MaterialColors;
import com.huviair.capture.R;
import com.huviair.capture.R.drawable;
import com.huviair.capture.databinding.FragmentCreateMediaBinding;
import com.huviair.capture.viewmodels.AlbumsListViewModel;
import com.huviair.capture.viewmodels.CreateMediaViewModel;
import com.yanzhenjie.album.Album;
import com.yanzhenjie.album.api.widget.Widget;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CreateMediaDialogFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CreateMediaDialogFragment extends DialogFragment {

    // Fragment parameters
    private static final String PROJECT_ID = "PROJECT_ID";
    private static final String ALBUM_ID = "ALBUM_ID";


    private FragmentCreateMediaBinding createMediaBinding;
    private AlbumsListViewModel viewModel;
    private CreateMediaViewModel createMediaViewModel;

    private String projectId;
    private String albumId;

    //Common tags for media upload
    private final List<Chip> tags = new ArrayList<>();


    public CreateMediaDialogFragment() {
        // Required empty public constructor
    }

    public interface MediaUploadStatusListener {
        void onUploadComplete(boolean isUploaded);
    }

    // Use this instance of the interface to deliver action events
    MediaUploadStatusListener listener;


    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment CreateMediaDialogFragment.
     */
    public static CreateMediaDialogFragment newInstance(String projectId, String albumId) {
        CreateMediaDialogFragment fragment = new CreateMediaDialogFragment();
        Bundle args = new Bundle();
        args.putString(PROJECT_ID, projectId);
        args.putString(ALBUM_ID, albumId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(PROJECT_ID);
            albumId = getArguments().getString(ALBUM_ID);
        }
    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        listener = (MediaUploadStatusListener) getParentFragment();
        createMediaBinding = FragmentCreateMediaBinding.inflate(inflater, container, false);
        return createMediaBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(AlbumsListViewModel.class);
        createMediaViewModel = new ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(requireActivity().getApplication())).get(CreateMediaViewModel.class);

        // populate projectId and albumId to model
        createMediaViewModel.setAlbumId(albumId);
        createMediaViewModel.setProjectId(projectId);

        listenForImageTagChips();
        listenForButtonClicks();
        observeForUploadResults();

    }


    private void listenForImageTagChips() {
        // populate tags on ime done
        createMediaBinding.inputTags.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                String textValue = createMediaBinding.inputTags.getText().toString();
                if (!"".equals(textValue)) {
                    addChipToGroup(textValue);
                    createMediaBinding.inputTags.setText("");
                }
            }
            return false;
        });
    }

    private void listenForButtonClicks() {
        createMediaBinding.galleryButton.setOnClickListener(v -> {

            // Fetch container URI before hand
            createMediaViewModel.fetchContainerUri();

            int brandColor = ContextCompat.getColor(requireContext(), R.color.brand_color);

            //Change color only in night mode
            int nightModeFlags = requireContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
                brandColor = MaterialColors.getColor(requireContext(), R.attr.colorOnPrimary, ContextCompat.getColor(requireContext(), R.color.brand_color));
            }

            int secondaryColor = ContextCompat.getColor(requireContext(), R.color.brand_secondary);

            // Album library to invoke gallery
            Album.album(this) // Image and video mix options.
                    .multipleChoice() // Multi-Mode, Single-Mode: singleChoice().
                    .columnCount(2) // The number of columns in the page list.
                    .selectCount(10)
                    .widget(
                            Widget.newDarkBuilder((requireContext()))
                                    .statusBarColor(brandColor)
                                    .toolBarColor(brandColor)
                                    .title("Select media and upload")
                                    .buttonStyle( // Used to configure the style of button when the image/video is not found.
                                            Widget.ButtonStyle.newDarkBuilder(requireContext()) // With Widget's Builder model.
                                                    .setButtonSelector(brandColor, secondaryColor) // Button selector.
                                                    .build()
                                    )
                                    .build()
                    )
                    .camera(true) // Whether the camera appears in the Item.
                    .cameraVideoQuality(1) // Video quality, [0, 1].
                    .cameraVideoLimitDuration(Long.MAX_VALUE) // The longest duration of the video is in milliseconds.
                    .cameraVideoLimitBytes(Long.MAX_VALUE) // Maximum size of the video, in bytes..
                    .onResult(selectedFiles -> createMediaViewModel.startMediaUpload(selectedFiles, tags, createMediaBinding.mediaDescription.getText().toString()))
                    .onCancel(result -> Toast.makeText(getContext(), "No media selected", Toast.LENGTH_LONG).show())
                    .start();
        });

        createMediaBinding.cancel.setOnClickListener(v -> dismiss());


    }

    // Dynamically add chips to ui
    private void addChipToGroup(String textToAdd) {

        // Create Chip object
        Chip chip = new Chip(requireContext());
        chip.setText(textToAdd);
        chip.setChipIconTintResource(R.color.brand_secondary);
        chip.setCheckable(false);
        chip.setClickable(false);
        chip.setCloseIconVisible(true);
        chip.setCloseIcon(ContextCompat.getDrawable(requireContext(), drawable.close_icon));
        createMediaBinding.tagsChipGroup.addView(chip);

        tags.add(chip);

        chip.setOnCloseIconClickListener(v -> {
            tags.remove(chip);
            createMediaBinding.tagsChipGroup.removeView(chip);
        });
    }


    private void observeForUploadResults() {

        createMediaViewModel.isUploadingMedia.observe(getViewLifecycleOwner(), isUploading -> {
            int visibility = isUploading ? View.VISIBLE : View.GONE;
            createMediaBinding.uploadingMediaProgress.setVisibility(visibility);
            toggleButtonsBasedOnState(!isUploading);
        });

        createMediaViewModel.isErrorInUploadingMedia.observe(getViewLifecycleOwner(), isError -> Toast.makeText(requireContext(), "Error in uploading media", Toast.LENGTH_SHORT).show());

        createMediaViewModel.getUploadStatus().observe(getViewLifecycleOwner(), uploadInfo -> {
            if (uploadInfo != null) {
                createMediaBinding.uploadStatus.setVisibility(View.VISIBLE);
                createMediaBinding.uploadStatus.setText(getString(R.string.media_upload_processing, uploadInfo.getProcessingCount().intValue(), uploadInfo.getFileSize()));
            }

        });

        createMediaViewModel.isUploadCompleted.observe(getViewLifecycleOwner(), isUploadComplete -> {

            // Indicating recycler view to update data
            listener.onUploadComplete(true);

            createMediaBinding.uploadStatus.setText(getString(R.string.media_upload_completed));
            Toast.makeText(requireContext(), "Uploaded media successfully", Toast.LENGTH_SHORT).show();
            dismiss();
        });
    }

    private void toggleButtonsBasedOnState(boolean makeButtonsVisible) {
        createMediaBinding.cancel.setEnabled(makeButtonsVisible);
        createMediaBinding.galleryButton.setEnabled(makeButtonsVisible);
        this.setCancelable(makeButtonsVisible);
    }


}