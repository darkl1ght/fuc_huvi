package com.huviair.capture.data.model.others;

public class DataSyncStatus {

    private boolean isDataSyncInProgress = false;
    private boolean isDataSyncComplete = false;
    private String currentStep = "";

    public String getCurrentStep() {
        return currentStep;
    }

    public boolean isDataSyncInProgress() {
        return isDataSyncInProgress;
    }

    public boolean isDataSyncComplete() {
        return isDataSyncComplete;
    }

    public void setDataSyncInProgress(boolean isDataSyncStarted) {
        this.isDataSyncInProgress = isDataSyncStarted;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }

    public void setDataSyncComplete(boolean dataSyncComplete) {
        this.isDataSyncComplete = dataSyncComplete;
    }
}
