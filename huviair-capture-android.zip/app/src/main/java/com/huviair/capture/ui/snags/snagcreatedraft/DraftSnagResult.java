package com.huviair.capture.ui.snags.snagcreatedraft;

import androidx.annotation.Nullable;

import com.huviair.capture.ui.snags.snaglist.SnagDataView;

public class DraftSnagResult {

    @Nullable
    private SnagDataView success;
    @Nullable
    private Integer error;

    public DraftSnagResult(@Nullable Integer error) {
        this.error = error;
    }

    public DraftSnagResult(@Nullable SnagDataView success) {
        this.success = success;
    }

    @Nullable
    public SnagDataView getSuccess() {
        return success;
    }

    @Nullable
    public Integer getError() {
        return error;
    }
}
