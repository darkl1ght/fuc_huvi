package com.huviair.capture.data.model.api.snags;

import java.io.Serializable;

public class SnagMedia implements Serializable, Comparable {
    private String blobReference;
    private String fileName;
    private String mediaId;
    private String mediaCreateDate;
    private String state;

    public String getBlobReferenceId() {
        return blobReference;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setBlobReferenceId(String blobReferenceId) {
        this.blobReference = blobReferenceId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getMediaId() {
        return mediaId;
    }

    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }

    public String getMediaCreateDate() {
        return mediaCreateDate;
    }

    public void setMediaCreateDate(String mediaCreateDate) {
        this.mediaCreateDate = mediaCreateDate;
    }

    @Override
    public int compareTo(Object o) {
        SnagMedia newSnag = (SnagMedia) o;
        if (newSnag.getMediaId().equals(mediaId)
                && newSnag.getBlobReferenceId().equals(blobReference)
                && newSnag.getFileName().equals(fileName)
                && newSnag.getState().equals(state)
        ) {
            return 0;
        }
        return 1;
    }
}
