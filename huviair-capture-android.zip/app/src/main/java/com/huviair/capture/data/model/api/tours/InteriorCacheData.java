package com.huviair.capture.data.model.api.tours;

import java.io.Serializable;
import java.util.List;

public class InteriorCacheData implements Serializable {

    private String interiorId;
    private String projectId;
    private String interiorName;
    private String interiorDate;
    private List<FloorWalkThroughCacheData> floorWalkthough;

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getInteriorId() {
        return interiorId;
    }

    public void setInteriorId(String interiorId) {
        this.interiorId = interiorId;
    }

    public String getInteriorName() {
        return interiorName;
    }

    public void setInteriorName(String interiorName) {
        this.interiorName = interiorName;
    }

    public String getInteriorDate() {
        return interiorDate;
    }

    public void setInteriorDate(String interiorDate) {
        this.interiorDate = interiorDate;
    }

    public List<FloorWalkThroughCacheData> getFloorWalkThough() {
        return floorWalkthough;
    }

    public void setFloorWalkThough(List<FloorWalkThroughCacheData> floorWalkThough) {
        this.floorWalkthough = floorWalkThough;
    }

    @Override
    public String toString() {
        return "InteriorCacheData{" +
                "interiorId='" + interiorId + '\'' +
                ", interiorName='" + interiorName + '\'' +
                ", interiorDate='" + interiorDate + '\'' +
                ", floorWalkThrough=" + floorWalkthough +
                '}';
    }
}