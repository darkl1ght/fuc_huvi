package com.huviair.capture.data.model.api.snags;

import java.io.Serializable;
import java.util.Objects;

public class TaskStatus implements Serializable {
    private final String code;
    private final String desc;

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public TaskStatus(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @Override
    public boolean equals(Object o) {
        TaskStatus that = (TaskStatus) o;
        return Objects.equals(code, that.code) &&
                Objects.equals(desc, that.desc);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, desc);
    }
}
