package com.huviair.capture.ui.interiors.videocapture.help;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.huviair.capture.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link VideoCaptureHelpScreen2#newInstance} factory method to
 * create an instance of this fragment.
 */

public class VideoCaptureHelpScreen2 extends Fragment {

    private OnBottomSheetDismissListener listener;

    public VideoCaptureHelpScreen2() {
        // Required empty public constructor
    }

  public static VideoCaptureHelpScreen2 newInstance() {
      return new VideoCaptureHelpScreen2();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnBottomSheetDismissListener) {
            listener = (OnBottomSheetDismissListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnBottomSheetDismissListener");
        }
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_video_capture_help_screen2, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Button dismissButton = view.findViewById(R.id.btn_got_it);
        dismissButton.setOnClickListener(view1 -> listener.onBottomSheetDismiss());
    }

    public interface OnBottomSheetDismissListener {
        void onBottomSheetDismiss();
    }
}