package com.huviair.capture.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.huviair.capture.data.model.database.InteriorTourCoordinates;
import com.huviair.capture.data.model.database.InteriorVideoCapture;
import com.huviair.capture.data.model.database.TourDetails;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Single;

@Dao
public interface InteriorTourDetailsDAO {

    @Insert
    Single<Long> insertTour(TourDetails tour);

    @Query("SELECT COUNT(*) FROM TOUR_WALK_THROUGH_DETAILS WHERE TOUR_ID = :tourId")
    Single<Long> getLastInsertedWalkThroughCount(String tourId);

    @Query("DELETE FROM TOUR_WALK_THROUGH_DETAILS WHERE TOUR_ID= :tourId")
    Completable deleteWalkThrough(String tourId);

    @Query("SELECT * FROM TOUR_WALK_THROUGH_DETAILS WHERE TOUR_ID = :tourId ORDER BY id ASC")
    Single<List<TourDetails>> getAllTourDetails(String tourId);

    @Query("SELECT * FROM TOUR_WALK_THROUGH_DETAILS WHERE IS_WALK_THROUGH_UPLOADED = 0 AND TOUR_ID = :tourId ORDER BY id ASC")
    Single<List<TourDetails>> getSavedTourDetails(String tourId);

    @Query("UPDATE TOUR_WALK_THROUGH_DETAILS SET HDR_STITCH_FILE_NAME = null, HDR_EXPORT_FILE_NAME = null  WHERE TOUR_ID = :tourId")
    Completable clearAllProcessedDetails(String tourId);

    @Query("SELECT * FROM TOUR_WALK_THROUGH_DETAILS WHERE IS_WALK_THROUGH_UPLOADED = 0 AND HDR_STITCH_FILE_NAME is not null AND TOUR_ID = :tourId ORDER BY id ASC")
    Single<List<TourDetails>> getWalkThroughForHdrGenerate(String tourId);

    @Query("UPDATE TOUR_WALK_THROUGH_DETAILS SET HDR_EXPORT_FILE_NAME = :hdrExportFileName WHERE TOUR_ID = :tourId AND id= :rowId")
    Completable updateWalkThroughHdrExport(String tourId, String hdrExportFileName, int rowId);

    @Query("UPDATE TOUR_WALK_THROUGH_DETAILS SET STITCH_IMAGE_EVENT_ID = :stitchEventId WHERE TOUR_ID = :tourId AND id= :rowId")
    Completable updateWalkthroughStitchEventId(String tourId, int stitchEventId, int rowId);


    @Query("UPDATE TOUR_WALK_THROUGH_DETAILS SET HDR_STITCH_FILE_NAME = :hdrFileName WHERE TOUR_ID = :tourId AND id= :rowId")
    void updateTourDetails(String tourId, String hdrFileName, int rowId);

    @Query("SELECT * FROM TOUR_WALK_THROUGH_DETAILS WHERE HDR_EXPORT_FILE_NAME is not null and IS_WALK_THROUGH_UPLOADED = 0 and TOUR_ID = :tourId")
    Single<List<TourDetails>> getToursToPublishToBackend(String tourId);

    @Query("UPDATE TOUR_WALK_THROUGH_DETAILS SET IS_WALK_THROUGH_UPLOADED = :isUploaded WHERE id = :rowId")
    int markWalkThroughUploadStatus(boolean isUploaded, int rowId);

    @Query("DELETE  FROM TOUR_WALK_THROUGH_DETAILS  WHERE TOUR_ID=:tourId and IMAGE_NUMBER=:imageNumber")
    Completable deleteMarker(String tourId, long imageNumber);

    @Query("SELECT IMAGE_URL FROM TOUR_WALK_THROUGH_DETAILS WHERE TOUR_ID = :tourId and IMAGE_NUMBER=:imageNumber")
    Single<String> getImageUrls(String tourId, long imageNumber);

    @Insert
    Single<Long> insertVideoCapture(InteriorVideoCapture tour);

    @Query("SELECT * FROM INTERIOR_VIDEO_WALKTHROUGH WHERE WALKTHROUGH_ID = :tourId ORDER BY id DESC")
    Single<List<InteriorVideoCapture>> getInteriorVideoWalkthrough(String tourId);

    @Query("UPDATE INTERIOR_VIDEO_WALKTHROUGH SET IS_VIDEO_UPLOADED = :isUploaded WHERE id = :rowId")
    Completable markVideoUploadStatus(boolean isUploaded, int rowId);

    @Query("DELETE FROM INTERIOR_VIDEO_WALKTHROUGH WHERE WALKTHROUGH_ID= :tourId")
    Completable deleteVideoCapture(String tourId);

    @Query("SELECT * FROM INTERIOR_VIDEO_WALKTHROUGH WHERE TOWER_ID= :towerId AND INTERIOR_ID= :interiorId ORDER BY id DESC")
    Single<List<InteriorVideoCapture>> getVideoWalkthroughsByTower(String interiorId, String towerId);

    @Insert
    Completable insertAll(List<InteriorTourCoordinates> imageFeatures);

    @Insert
    void insert(InteriorTourCoordinates imageFeatureEntity);

    @Query("SELECT * FROM INTERIOR_TOUR_COORDINATES")
    List<InteriorTourCoordinates> getAllImageFeatures();

    @Query("SELECT * FROM INTERIOR_TOUR_COORDINATES WHERE tourId= :tourId")
    Single<List<InteriorTourCoordinates>> getTourCoordinatesForTheTour(String tourId);

    @Query("DELETE FROM INTERIOR_TOUR_COORDINATES")
    void deleteAll();

    @Query("DELETE FROM INTERIOR_TOUR_COORDINATES WHERE tourId = :tourId")
    Completable deleteCoordinatesByTourId(String tourId);
}
