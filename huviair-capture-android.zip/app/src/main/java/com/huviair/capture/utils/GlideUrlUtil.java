package com.huviair.capture.utils;

import com.bumptech.glide.load.model.GlideUrl;

public class GlideUrlUtil extends GlideUrl {
    private final String mUrl;

    public GlideUrlUtil(String url) {
        super(url);
        this.mUrl = url;
    }

    @Override
    public String getCacheKey() {
        return mUrl.replace(getTokenParam(), "");
    }

    // Cache based on the key as url without the dynamic changing token
    private String getTokenParam() {
        String tokenParam = "";
        int tokenKeyIndex = mUrl.contains("?st=") ? mUrl.indexOf("?st=") : mUrl.indexOf("&token=");
        if (tokenKeyIndex != -1) {
            tokenParam = mUrl.substring(tokenKeyIndex);
        }
        return tokenParam;
    }
}
