package com.huviair.capture.ui.insta360;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.arashivision.sdkcamera.camera.InstaCameraManager;
import com.arashivision.sdkcamera.camera.callback.ICaptureStatusListener;
import com.arashivision.sdkcamera.camera.callback.IPreviewStatusListener;
import com.arashivision.sdkcamera.camera.resolution.PreviewStreamResolution;
import com.arashivision.sdkmedia.player.capture.CaptureParamsBuilder;
import com.arashivision.sdkmedia.player.capture.InstaCapturePlayerView;
import com.arashivision.sdkmedia.player.config.InstaStabType;
import com.arashivision.sdkmedia.player.listener.PlayerViewListener;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.databinding.ActivityCaptureBinding;

public class CaptureActivity extends BaseObserveCameraActivity implements IPreviewStatusListener, SensorEventListener {

    public static final String SAVE_IMAGE = "SAVE_IMAGE";
    public static final String CAPTURED_IMAGE_PATH = "CAPTURED_IMAGE_PATH";
    public static final String OFFSET_FROM_NORTH = "OFFSET_FROM_NORTH";

    // Sensor related variables
    private final float[] accelerometerReading = new float[3];
    private final float[] magnetometerReading = new float[3];
    private final float[] rotationMatrix = new float[9];
    private final float[] orientationAngles = new float[3];

    private InstaCapturePlayerView mCapturePlayerView;
    private ActivityCaptureBinding captureViewBinding;

    private String capturedImagePaths = null;
    private double capturedOrientationAngle = 0.0d;

    private boolean isCapturingImage = false;

    private SensorManager sensorManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Populate view binding
        captureViewBinding = ActivityCaptureBinding.inflate(getLayoutInflater());

        setContentView(captureViewBinding.getRoot());

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        if (!super.isCameraConnected()) {
            finish();
            return;
        }


        bindActivityLifecycleToCamera();


        InstaCameraManager.getInstance().setCameraBeepSwitch(true);

        // Capture Status Callback
        InstaCameraManager.getInstance().setCaptureStatusListener(new ICaptureStatusListener() {
            @Override
            public void onCaptureStarting() {
                isCapturingImage = true;
                captureViewBinding.tvCaptureStatus.setText(R.string.capture_capture_starting);
                captureViewBinding.captureImage.hide();
            }

            @Override
            public void onCaptureWorking() {
                captureViewBinding.tvCaptureStatus.setText(R.string.capture_capture_working);
            }

            @Override
            public void onCaptureStopping() {
                captureViewBinding.tvCaptureStatus.setText(R.string.capture_capture_stopping);
            }

            @Override
            public void onCaptureFinish(String[] filePaths) {

                if (filePaths == null || filePaths.length == 0) {
                    showSnackBarMessage("Image details could not be obtained from the camera, please check your connection", R.color.snackbar_error, captureViewBinding.captureImage);
                    return;
                }
                capturedImagePaths = convertFilePathsToString(filePaths);

                captureViewBinding.tvCaptureStatus.setText(R.string.capture_capture_finished);

                isCapturingImage = false;

                // Save image and close activity
                saveCapturedImage();
            }

            @Override
            public void onCaptureTimeChanged(long captureTime) {
            }

            @Override
            public void onCaptureCountChanged(int captureCount) {
            }

        });

        // Capture image on click
        captureViewBinding.captureImage.setOnClickListener(v -> {
            if (checkSdCardEnabled()) {
                capturedOrientationAngle = fetchCurrentOrientationAngle();
                InstaCameraManager.getInstance().startHDRCapture(false);
            }

        });
    }

    private void enableStream() {
        // Switch camera mode to panorama
        InstaCameraManager.getInstance().switchCameraMode(InstaCameraManager.CAMERA_MODE_PANORAMA, InstaCameraManager.FOCUS_SENSOR_ALL, null);

        // Add capture listeners
        InstaCameraManager.getInstance().setPreviewStatusChangedListener(this);

        // Start preview
        InstaCameraManager.getInstance().startPreviewStream(PreviewStreamResolution.STREAM_1440_720_30FPS, InstaCameraManager.PREVIEW_TYPE_NORMAL);
    }


    private void bindActivityLifecycleToCamera() {
        mCapturePlayerView = findViewById(R.id.player_capture);
        mCapturePlayerView.setLifecycle(getLifecycle());
    }


    private boolean checkSdCardEnabled() {
        if (!InstaCameraManager.getInstance().isSdCardEnabled()) {
            Toast.makeText(this, R.string.capture_toast_sd_card_error, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @Override
    public void onCameraStorageChanged(long freeSpace, long totalSpace) {
        super.onCameraStorageChanged(freeSpace, totalSpace);
    }

    @Override
    public void onCameraStatusChanged(boolean enabled) {
        super.onCameraStatusChanged(enabled);
        if (!enabled) {
            Toast.makeText(getApplicationContext(), "Camera Disconnected", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    public void onCameraSensorModeChanged(int cameraSensorMode) {
        super.onCameraSensorModeChanged(cameraSensorMode);
    }


    // Camera capture lifecycle methods


    private void disableStream() {
        InstaCameraManager.getInstance().setPreviewStatusChangedListener(null);
        InstaCameraManager.getInstance().closePreviewStream();
        mCapturePlayerView.destroy();
    }


    private void showSnackBarMessage(String text, int color, View anchorView) {
        Snackbar.make(captureViewBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_SHORT)
                .setBackgroundTint(ContextCompat.getColor(this, color))
                .setTextColor(ContextCompat.getColor(this, R.color.white))
                .setAnchorView(anchorView)
                .show();
    }


    // Lifecycle events of Preview Stream
    @Override
    protected void onStop() {
        super.onStop();
        if (isFinishing()) {
            // Auto close preview after page loses focus
            disableStream();
        }
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onOpening() {
        // Preview Opening
    }

    @Override
    public void onOpened() {
        // Preview stream is on and can be played
        InstaCameraManager.getInstance().setStreamEncode();
        mCapturePlayerView.setPlayerViewListener(new PlayerViewListener() {
            @Override
            public void onLoadingFinish() {
                if (!isCapturingImage) {
                    captureViewBinding.captureImage.show();
                }
                InstaCameraManager.getInstance().setPipeline(mCapturePlayerView.getPipeline());
            }

            @Override
            public void onReleaseCameraPipeline() {
                InstaCameraManager.getInstance().setPipeline(null);
            }
        });
        mCapturePlayerView.prepare(createParams());
        mCapturePlayerView.play();
        mCapturePlayerView.setKeepScreenOn(true);
    }

    private CaptureParamsBuilder createParams() {
        CaptureParamsBuilder builder = new CaptureParamsBuilder()
                .setCameraType(InstaCameraManager.getInstance().getCameraType())
                .setMediaOffset(InstaCameraManager.getInstance().getMediaOffset())
                .setCameraSelfie(InstaCameraManager.getInstance().isCameraSelfie())
                .setGyroTimeStamp(InstaCameraManager.getInstance().getGyroTimeStamp())
                .setBatteryType(InstaCameraManager.getInstance().getBatteryType())
                .setStabType(InstaStabType.STAB_TYPE_AUTO)
                .setStabEnabled(true);


        builder.setRenderModelType(CaptureParamsBuilder.RENDER_MODE_AUTO);
        return builder;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            System.arraycopy(event.values, 0, accelerometerReading,
                    0, accelerometerReading.length);
        } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            System.arraycopy(event.values, 0, magnetometerReading,
                    0, magnetometerReading.length);
        }
    }


    // Compute the three orientation angles based on the most recent readings from
    // the device's accelerometer and magnetometer.
    public double fetchCurrentOrientationAngle() {
        // Update rotation matrix, which is needed to update orientation angles.
        SensorManager.getRotationMatrix(rotationMatrix, null,
                accelerometerReading, magnetometerReading);

        // "rotationMatrix" now has up-to-date information.
        float[] orientation = SensorManager.getOrientation(rotationMatrix, orientationAngles);

        // Convert output of -pi to pi --> 0 - 360
        return (Math.toDegrees(orientation[0]) + 360) % 360;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }


    @Override
    public void onIdle() {
        // Preview Stopped
        mCapturePlayerView.destroy();
        mCapturePlayerView.setKeepScreenOn(false);
    }

    @Override
    public void onError() {
        showSnackBarMessage("Unable to preview content, check your camera", R.color.snackbar_error, captureViewBinding.captureImage);
    }

    @Override
    protected void onPause() {
        super.onPause();
        InstaCameraManager.getInstance().closePreviewStream();
        captureViewBinding.captureImage.hide();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Start preview stream
        enableStream();


        // Get updates from the accelerometer and magnetometer at a constant rate.
        // To make batch operations more efficient and reduce power consumption,
        // provide support for delaying updates to the application.
        //
        // In this example, the sensor reporting delay is small enough such that
        // the application receives an update before the system checks the sensor
        // readings again.
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
        }
        Sensor magneticField = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (magneticField != null) {
            sensorManager.registerListener(this, magneticField,
                    SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isFinishing()) {
            // Auto close preview after page loses focus
            InstaCameraManager.getInstance().setPreviewStatusChangedListener(null);
            InstaCameraManager.getInstance().closePreviewStream();
            mCapturePlayerView.destroy();
        }
    }


    private String convertFilePathsToString(String[] filePaths) {
        StringBuilder filePathsToString = new StringBuilder();
        if (filePaths.length > 1) {
            for (int i = 0; i < filePaths.length; i++) {
                if (i == filePaths.length - 1) filePathsToString.append(filePaths[i]);
                else filePathsToString.append(filePaths[i]).append(",");
            }
            return filePathsToString.toString();
        }
        filePathsToString.append(filePaths[0]);
        return filePathsToString.toString();
    }

    private void saveCapturedImage() {
        Intent intent = new Intent();
        intent.putExtra(SAVE_IMAGE, true);
        intent.putExtra(CAPTURED_IMAGE_PATH, capturedImagePaths);
        intent.putExtra(OFFSET_FROM_NORTH, capturedOrientationAngle);
        setResult(RESULT_OK, intent);
        finish();
    }

}
