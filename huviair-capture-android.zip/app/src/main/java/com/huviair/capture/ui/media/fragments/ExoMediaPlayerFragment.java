package com.huviair.capture.ui.media.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.google.android.exoplayer2.util.Util;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.huviair.capture.R;
import com.huviair.capture.api.APIClient;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ExoMediaPlayerFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ExoMediaPlayerFragment extends Fragment {

    private static final String MEDIA_BLOB_CONTENT_ID = "MEDIA_BLOB_CONTENT_ID";
    private static final String MEDIA_NAME = "MEDIA_NAME";
    private static final String IS_360_VIDEO = "IS_360_VIDEO";

    private SimpleExoPlayer mediaPlayer;

    private String mediaBlobContentId;
    private String mediaName;
    private boolean is360Video = false;
    private String streamUrl;

    private MediaPlayerListener mediaPlayerListener;
    private CircularProgressIndicator progressIndicator;
    private PlayerView exoMediaPlayerView;

    private int currentWindow = 0;
    private long playbackPosition = 0;

    private static final String CURRENT_WINDOW = "CURRENT_WINDOW";
    private static final String PLAYBACK_POSITION = "PLAYBACK_POSITION";

    public ExoMediaPlayerFragment() {
        // Required empty public constructor
    }

    public static ExoMediaPlayerFragment newInstance(String mediaBlobContentId, String mediaName, boolean is360Video) {
        ExoMediaPlayerFragment fragment = new ExoMediaPlayerFragment();
        Bundle args = new Bundle();
        args.putString(MEDIA_BLOB_CONTENT_ID, mediaBlobContentId);
        args.putString(MEDIA_NAME, mediaName);
        args.putBoolean(IS_360_VIDEO, is360Video);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mediaBlobContentId = getArguments().getString(MEDIA_BLOB_CONTENT_ID);
            is360Video = getArguments().getBoolean(IS_360_VIDEO);
        }
        if (savedInstanceState != null) {
            playbackPosition = savedInstanceState.getLong(PLAYBACK_POSITION);
            currentWindow = savedInstanceState.getInt(CURRENT_WINDOW);
        }
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (is360Video) {
            return inflater.inflate(R.layout.fragment_exo_media_player_spherical, container, false);
        } else
            return inflater.inflate(R.layout.fragment_exo_media_player, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        progressIndicator = view.findViewById(R.id.loading_stream);
        exoMediaPlayerView = view.findViewById(R.id.media_player_view);


        if (requireActivity().findViewById(R.id.bottom_navigation_snag) != null) {
            requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.GONE);
        } else if (requireActivity().findViewById(R.id.bottom_navigation_media) != null) {
            requireActivity().findViewById(R.id.bottom_navigation_media).setVisibility(View.GONE);
        }

        streamUrl = APIClient.getMediaVodStreamingUrl().replace("{player}", mediaBlobContentId);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (Util.SDK_INT >= 24) {
            initializePlayer();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if ((Util.SDK_INT < 24 || mediaPlayer == null)) {
            initializePlayer();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (Util.SDK_INT < 24) {
            releasePlayer();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (Util.SDK_INT >= 24) {
            releasePlayer();
        }
    }

    private void initializePlayer() {
        if (mediaPlayer == null) {
            DefaultTrackSelector trackSelector = new DefaultTrackSelector(requireContext());
            trackSelector.setParameters(trackSelector.buildUponParameters().setMaxVideoSizeSd());

            mediaPlayer = new SimpleExoPlayer.Builder(requireContext()).setTrackSelector(trackSelector).build();

            // Set media player to player view
            exoMediaPlayerView.setPlayer(mediaPlayer);
            mediaPlayer.setMediaItem(MediaItem.fromUri(streamUrl));
            mediaPlayer.setPlayWhenReady(false);

            mediaPlayerListener = new MediaPlayerListener();
            mediaPlayer.addListener(mediaPlayerListener);
            mediaPlayer.seekTo(currentWindow, playbackPosition);
            mediaPlayer.prepare();
        }
    }

    public void releasePlayer() {
        if (mediaPlayer != null) {
            playbackPosition = mediaPlayer.getCurrentPosition();
            currentWindow = mediaPlayer.getCurrentWindowIndex();
            mediaPlayer.removeListener(mediaPlayerListener);
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }


    class MediaPlayerListener implements Player.Listener {

        @Override
        public void onPlaybackStateChanged(int state) {
            if (Player.STATE_BUFFERING == state || Player.STATE_IDLE == state) {
                progressIndicator.setVisibility(View.VISIBLE);
            }
            if (Player.STATE_READY == state || Player.STATE_ENDED == state) {
                progressIndicator.setVisibility(View.GONE);
            }
        }

        @Override
        public void onPlayerError(ExoPlaybackException error) {
            if (error.type == ExoPlaybackException.TYPE_SOURCE) {
                IOException cause = error.getSourceException();
                if (cause instanceof HttpDataSource.HttpDataSourceException) {
                    // An HTTP error occurred.
                    HttpDataSource.HttpDataSourceException httpError = (HttpDataSource.HttpDataSourceException) cause;

                    // This is the request for which the error occurred.
                    DataSpec requestDataSpec = httpError.dataSpec;
                    // It's possible to find out more about the error both by casting and by
                    // querying the cause.
                    if (httpError instanceof HttpDataSource.InvalidResponseCodeException) {
                        Toast.makeText(requireContext(), "Error in loading stream", Toast.LENGTH_SHORT).show();
                    } else {
                        // Try calling httpError.getCause() to retrieve the underlying cause,
                        // although note that it may be null.
                        Toast.makeText(requireContext(), "Error in loading stream", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(PLAYBACK_POSITION, playbackPosition);
        outState.putInt(CURRENT_WINDOW, currentWindow);
    }
}