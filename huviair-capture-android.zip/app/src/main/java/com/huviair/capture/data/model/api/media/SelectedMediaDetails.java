package com.huviair.capture.data.model.api.media;

import java.util.List;

public class SelectedMediaDetails {

    private Integer position;
    private List<Media> media;

    public SelectedMediaDetails(Integer position, List<Media> media) {
        this.position = position;
        this.media = media;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public List<Media> getMedia() {
        return media;
    }

    public void setMedia(List<Media> media) {
        this.media = media;
    }
}
