package com.huviair.capture.workers;

import android.app.Notification;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ForegroundInfo;
import androidx.work.RxWorker;
import androidx.work.WorkerParameters;

import com.google.common.util.concurrent.ListenableFuture;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.database.AuditLog;
import com.huviair.capture.data.model.api.tours.Image;
import com.huviair.capture.data.model.api.tours.TourWalkThroughRequest;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

import java.io.File;
import java.net.URI;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import id.zelory.compressor.Compressor;
import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.Single;
import io.reactivex.schedulers.Schedulers;

public class CompressAndPublishImagesWorker extends RxWorker {

    private final APIService apiService;
    private final DataCaptureRoomDatabase database;

    private final AtomicInteger publishedImagesCount = new AtomicInteger(0);
    private int imagesToPublishCount;
    private SharedPreferencesManager sharedPreferencesManager;


    /**
     * @param appContext   The application {@link Context}
     * @param workerParams Parameters to setup the internal state of this worker
     */
    public CompressAndPublishImagesWorker(@NonNull Context appContext, @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);

        // Initialize API services
        apiService = APIClient.createService(APIService.class, appContext, APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(appContext).getJwtToken());

        // Initialize database
        database = DataCaptureRoomDatabase.getDatabase(appContext);

        sharedPreferencesManager = new SharedPreferencesManager(appContext);
    }

    @NonNull
    @Override
    public Single<Result> createWork() {
        try {
            String interiorWalkthroughId = getInputData().getString(CommonConstants.WALKTHROUGH_ID);
            String walkthroughName = getInputData().getString(CommonConstants.TOUR_NAME);
            String interiorTourId = getInputData().getString(CommonConstants.INTERIOR_TOUR_ID);
            String projectId = getInputData().getString(CommonConstants.PROJECT_ID);
            String towerId = getInputData().getString(CommonConstants.TOWER_ID);

            Data.Builder builder = new Data.Builder()
                    .putString(CommonConstants.INTERIOR_TOUR_ID, interiorTourId)
                    .putString(CommonConstants.TOUR_NAME, walkthroughName)
                    .putString(CommonConstants.WALKTHROUGH_ID, interiorWalkthroughId)
                    .putString(CommonConstants.PROJECT_ID, projectId)
                    .putString(CommonConstants.TOWER_ID, towerId);

            Observable<CloudBlobContainer> cloudBlobContainerObservable = apiService.getAzureTokenWritePermission(CommonConstants.VIRTUAL_TOUR)
                    .flatMap(azureTokenResponse -> {
                        String containerURI = azureTokenResponse.getSasToken() != null ? azureTokenResponse.getSasToken().getUri() : null;
                        CloudBlobContainer container = new CloudBlobContainer(URI.create(containerURI));
                        return Single.just(container);
                    }).toObservable();


            setForegroundAsync(createForegroundInfo(true, "Publishing data for the walk-through ".concat(walkthroughName).concat(" ").concat("started"), interiorWalkthroughId));

            return cloudBlobContainerObservable.flatMap(container -> {
                Single<List<TourDetails>> toursToPublishToBackend = database.tourDetailsDAO().getToursToPublishToBackend(interiorWalkthroughId);
                return toursToPublishToBackend.toObservable().flatMap(tourDetails -> {
                    imagesToPublishCount = tourDetails.size();
                    return Observable.fromIterable(tourDetails)
                            .flatMap(tour -> {
                                TourWalkThroughRequest request = new TourWalkThroughRequest();
                                return uploadCompressedImageToBlob(container, tour, request)
                                        .flatMap(walkThroughRequest -> apiService.updateTourDetails(projectId, interiorTourId, interiorWalkthroughId, walkThroughRequest).toObservable().flatMap(o -> {
                                            database.tourDetailsDAO().markWalkThroughUploadStatus(true, tour.getId());
                                            return Observable.just(tour);
                                        }).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(10))));
                            }, 5);
                })
                        .flatMap(this::deleteImageData, 5).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(10)));
            }).subscribeOn(Schedulers.io())
                    .doOnSubscribe(disposable -> setForegroundAsync(createForegroundInfo(true, "Publishing images for the walk-through -".concat(walkthroughName), interiorWalkthroughId)))
                    .doOnNext(aBoolean -> setForegroundAsync(createForegroundInfo(true, String.format(Locale.getDefault(), "Publishing images %d of %d for walk-through ".concat(walkthroughName), publishedImagesCount.incrementAndGet(), imagesToPublishCount), interiorWalkthroughId)))
                    .doOnComplete(() -> {
                        apiService.updateInteriorPublishDetails(projectId, interiorTourId, interiorWalkthroughId).execute();
                        setForegroundAsync(createForegroundInfo(false, "Publishing Images completed for walk-through  -".concat(walkthroughName), interiorWalkthroughId));
                    })
                    .doOnError(throwable ->
                    { setForegroundAsync(createForegroundInfo(false, "Publishing of images failed".concat(throwable.getMessage()), interiorWalkthroughId));
                        AuditLog errorLog = new AuditLog(interiorTourId,
                                "exception",
                                "createWork",
                                new Date().toString(),
                                throwable.getMessage());
                        database.auditLogsDAO().insertLog(errorLog);
                    })
                    .toList()
                    .map(aerialImageResponses -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.success(builder.build());
                    })
                    .onErrorReturn(throwable -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.failure(builder.build());
                    });
        } catch (Exception e) {
            AuditLog errorLog = new AuditLog("tourId","exception","createWork",new Date().toString(),e.getMessage());
            database.auditLogsDAO().insertLog(errorLog);
            return Single.just(Result.failure());
        }
    }

    private Observable<Boolean> deleteImageData(TourDetails tourDetails) {
        return Observable.fromCallable(() -> {
            File hdrExportFile = new File(tourDetails.getHdrExportFileName());
            File hdrGeneratedImage = new File(tourDetails.getHdrImageFileName());
            hdrExportFile.delete();
            hdrGeneratedImage.delete();

            String[] importedImageURLs = tourDetails.getImageUrl().split(",");
            for (String importedImageURL : importedImageURLs) {
                String hdrFolderPath = getApplicationContext().getFilesDir() + "/" + CommonConstants.HDR_IMPORTED_IMAGES_FOLDER;
                String urlToDelete = importedImageURL.replace(importedImageURL.substring(0, importedImageURL.lastIndexOf("/")), hdrFolderPath);
                File inspFile = new File(urlToDelete);
                inspFile.delete();
            }
            return true;

        });
    }


    private Observable<TourWalkThroughRequest> uploadCompressedImageToBlob(CloudBlobContainer container, TourDetails tourDetails, TourWalkThroughRequest request) throws Exception {
        return Observable.fromCallable(() -> {
            String imageName = tourDetails.getHdrExportFileName().substring(tourDetails.getHdrExportFileName().lastIndexOf("/") + 1);
            CloudBlockBlob blob = container.getBlockBlobReference(tourDetails.getTourId() + "/" + imageName);

            String filePath = "";
            // Compress Image and get the path
            if (!sharedPreferencesManager.isHDQualityEnabled())
                filePath = new Compressor(getApplicationContext()).compressToFile(new File(tourDetails.getHdrExportFileName())).getPath();

            else filePath = tourDetails.getHdrExportFileName();

            blob.uploadFromFile(filePath);

            String imageId = imageName.substring(0, imageName.length() - 4);
            request.addImagesAndFeatures(new Image(imageId, imageName, imageId, tourDetails.getOffsetFromNorth()), tourDetails.getImageNumber(), tourDetails.getXCoordinate(), tourDetails.getYCoordinate());
            return request;
        });
    }


    @NonNull
    private ForegroundInfo createForegroundInfo(boolean onGoing, @NonNull String message, @NonNull String interiorWalkthroughId) {
        Notification foregroundNotification = WorkerUtils.getNotification(onGoing, CommonConstants.INTERIOR_WORK_NOTIFICATION_TITLE, message, interiorWalkthroughId, getApplicationContext());
        int notificationId = onGoing ? 1 : 2;
        return new ForegroundInfo(notificationId, foregroundNotification);
    }

    @NonNull
    @Override
    protected Scheduler getBackgroundScheduler() {
        return Schedulers.from(Executors.newFixedThreadPool(10));
    }
}


