package com.huviair.capture.data.model.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.huviair.capture.data.model.api.tours.ImageFeature;

import java.io.Serializable;

@Entity(tableName = "INTERIOR_TOUR_COORDINATES")
public class InteriorTourCoordinates implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String type;
    private String imageId;
    private int imageNumber;
    private double xCoordinate;
    private double yCoordinate;
    private String tourId;


    public InteriorTourCoordinates(String type, String tourId, String imageId, int imageNumber, double xCoordinate, double yCoordinate) {
        this.type = type;
        this.imageId = imageId;
        this.imageNumber = imageNumber;
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        this.tourId = tourId;
    }

    public InteriorTourCoordinates() {

    }

    public InteriorTourCoordinates populateData(ImageFeature feature, String tourId) {
        this.type = feature.getType();
        this.imageId = feature.getProperties().getImageId();
        this.imageNumber = feature.getProperties().getImageNumber();
        this.xCoordinate = feature.getGeometry().getXCoordinate();
        this.yCoordinate = feature.getGeometry().getYCoordinate();
        this.tourId = tourId;
        return this;
    }

    public String getImageId() {
        return imageId;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public void setImageNumber(int imageNumber) {
        this.imageNumber = imageNumber;
    }

    public void setXCoordinate(double xCoordinate) {
        this.xCoordinate = xCoordinate;
    }

    public void setYCoordinate(double yCoordinate) {
        this.yCoordinate = yCoordinate;
    }

    public int getId() {
        return id;
    }

    public String getTourId() {
        return tourId;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }


    public int getImageNumber() {
        return imageNumber;
    }

    public double getXCoordinate() {
        return xCoordinate;
    }

    public double getYCoordinate() {
        return yCoordinate;
    }
}
