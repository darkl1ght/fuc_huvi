package com.huviair.capture.data.model.api.media;

import com.huviair.capture.data.model.api.media.Media;

import java.util.List;

public class ProjectAlbumsMediaResponse {

    private List<Media> media;

    public List<Media> getMedia() {
        return media;
    }

    public void setMedia(List<Media> media) {
        this.media = media;
    }
}
