package com.huviair.capture.utils;

import android.content.Context;
import android.content.Intent;

import androidx.annotation.Keep;

import com.huviair.capture.ui.login.LoginActivity;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.logging.Logger;

import okhttp3.Interceptor;
import okhttp3.Response;

@Keep
public class ResponseInterceptor implements Interceptor {
    private final Context context;

    public ResponseInterceptor(Context context) {
        this.context = context.getApplicationContext();
    }

    @NotNull
    @Override
    public Response intercept(Chain chain) throws IOException {
        Response response = chain.proceed(chain.request());
        if (!response.isSuccessful() && response.code() == 401) {
            Logger.getAnonymousLogger().info(String.format("Received response %s", response.code()));
            if (context != null) {
                boolean logout = new SharedPreferencesManager(context.getApplicationContext()).logout();
                if (logout) {
                    Intent loginIntent = new Intent(context, LoginActivity.class);
                    loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(loginIntent);

                }

            }

        }

        return response;
    }
}