package com.huviair.capture.data.model.api.projects;

import java.util.List;

public class ProjectList {
    private List<Project> projects;

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }

}
