package com.huviair.capture.data.model.api.snags;

import com.huviair.capture.data.model.api.tours.Feature;
import com.huviair.capture.utils.CommonConstants;

import java.util.List;

public class CreateOnsiteSnagDetails {
    private String workPackageId;
   
    private String[] locations;
    private SnagItem[] punchItems;
    private String punchListId;


    

    public SnagItem[] getPunchItems() {
        return punchItems;
    }

    public CreateOnsiteSnagDetails builder(String description, String remarks, String workPackageId, String[] locations, List<SnagMedia> mediaList
            , String punchListId) {
        this.workPackageId = workPackageId;
      
        this.locations = locations;
        this.punchListId = punchListId;

        // Create Snag item
        SnagItem snagItem = new SnagItem(description, remarks, mediaList, punchListId);

        this.punchItems = new SnagItem[]{snagItem};

        return this;
    }


    public class SnagItem {
        private final String taskDescription;
        private final String remark;
        private final boolean isNonConformity = true;
        
        private final List<SnagMedia> mediaList;
      
        private final String punchListId;

        public SnagItem(String taskDescription, String remark,  List<SnagMedia> mediaList, String punchListId) {
            this.taskDescription = taskDescription;
            this.remark = remark;
            this.mediaList = mediaList;
            this.punchListId = punchListId;
        }

        
    }

}


