package com.huviair.capture.data.model.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;


import java.io.Serializable;

@Entity(tableName = "AUDIT_LOGS")
public class AuditLog implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String tourId;
    private String type;
    private String method;
    private String logDate;
    private String logInfo;



    public AuditLog(String tourId, String type, String method, String logDate, String logInfo) {
        this.type = type;
        this.tourId = tourId;
        this.type = type;
        this.method = method;
        this.logDate = logDate;
        this.logInfo = logInfo;
    }

    public AuditLog() {

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLogDate() {
        return logDate;
    }

    public void setLogDate(String logDate) {
        this.logDate = logDate;
    }

     public String getLogInfo() {
        return logInfo;
    }

    public void setLogInfo(String logInfo) {
        this.logInfo = logInfo;
    }

    public String getTourId() {
        return tourId;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }
}
