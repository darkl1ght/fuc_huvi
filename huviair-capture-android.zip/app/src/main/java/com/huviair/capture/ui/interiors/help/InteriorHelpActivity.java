package com.huviair.capture.ui.interiors.help;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.huviair.capture.R;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.databinding.ActivityInteriorHelpBinding;

public class InteriorHelpActivity extends AppCompatActivity {

    private ActivityInteriorHelpBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityInteriorHelpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.helpBar.toolBar.setTitle("Help");
        binding.helpBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        binding.helpBar.toolBar.setNavigationOnClickListener(v -> onBackPressed());

        loadHelpDocument();
    }

    private void loadHelpDocument() {
        binding.documentWebview.invalidate();
        binding.documentWebview.getSettings().setSupportZoom(true);
        binding.documentWebview.getSettings().setJavaScriptEnabled(true);
        binding.documentWebview.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        binding.documentWebview.loadUrl(APIClient.getInteriorHelpDocUrl());

        binding.documentWebview.setWebViewClient(new WebViewClient() {
            boolean checkOnPageStartedCalled = false;

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                binding.loadingWebview.setVisibility(View.VISIBLE);
                checkOnPageStartedCalled = true;
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (checkOnPageStartedCalled) {
                    binding.loadingWebview.setVisibility(View.GONE);
                } else {
                    loadHelpDocument();
                }

                super.onPageFinished(view, url);
            }
        });

    }
}