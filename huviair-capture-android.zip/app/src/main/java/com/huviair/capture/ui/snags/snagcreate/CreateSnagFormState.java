package com.huviair.capture.ui.snags.snagcreate;

import androidx.annotation.Nullable;

public class CreateSnagFormState {

    @Nullable
    private Integer snagDescriptionError;
    @Nullable
    private Integer dueDateError;
    @Nullable
    private Integer workTradeError;
    @Nullable
    private Integer selectLevelError;
    @Nullable
    private Integer selectStage1Error;
    @Nullable
    private Integer selectStage2Error;

    private boolean isDataValid = false;

    public CreateSnagFormState(@Nullable Integer snagDescriptionError, @Nullable Integer dueDateError,
                               @Nullable Integer workTradeError, @Nullable Integer selectLevelError,
                               @Nullable Integer selectStage1Error, @Nullable Integer selectStage2Error,
                               boolean isDataValid) {
        this.snagDescriptionError = snagDescriptionError;
        this.dueDateError = dueDateError;
        this.workTradeError = workTradeError;
        this.selectLevelError = selectLevelError;
        this.isDataValid = isDataValid;
        this.selectStage1Error = selectStage1Error;
        this.selectStage2Error = selectStage2Error;
    }

    public CreateSnagFormState() {

    }

    public CreateSnagFormState(boolean isDataValid) {
        this.snagDescriptionError = null;
        this.dueDateError = null;
        this.workTradeError = null;
        this.selectLevelError = null;
        this.selectStage2Error = null;
        this.selectStage1Error = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    public Integer getDueDateError() {
        return dueDateError;
    }

    @Nullable
    public Integer getWorkTradeError() {
        return workTradeError;
    }

    @Nullable
    public Integer getSelectLevelError() {
        return selectLevelError;
    }

    @Nullable
    public Integer getSnagDescriptionError() {
        return snagDescriptionError;
    }

    @Nullable
    public Integer getSelectStage1Error() {
        return selectStage1Error;
    }

    @Nullable
    public Integer getSelectStage2Error() {
        return selectStage2Error;
    }

    public void setSnagDescriptionError(@Nullable Integer snagDescriptionError) {
        this.snagDescriptionError = snagDescriptionError;
    }

    public void setDueDateError(@Nullable Integer dueDateError) {
        this.dueDateError = dueDateError;
    }

    public void setWorkTradeError(@Nullable Integer workTradeError) {
        this.workTradeError = workTradeError;
    }

    public void setSelectLevelError(@Nullable Integer selectLevelError) {
        this.selectLevelError = selectLevelError;
    }

    public void setSelectStage1Error(@Nullable Integer selectStage1Error) {
        this.selectStage1Error = selectStage1Error;
    }

    public void setSelectStage2Error(@Nullable Integer selectStage2Error) {
        this.selectStage2Error = selectStage2Error;
    }

    public void setDataValid(boolean dataValid) {
        isDataValid = dataValid;
    }

    public boolean isDataValid() {
        return isDataValid;
    }
}
