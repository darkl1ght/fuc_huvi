package com.huviair.capture.data.model.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "AERIAL_UPLOAD_TOUR_DETAILS")
public class AerialUploadTourDetails {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "IMAGE_PATH")
    private String imagePath;
    @ColumnInfo(name = "PROJECT_ID")
    private String projectId;
    @ColumnInfo(name = "AERIAL_TOUR_ID")
    private String aerialTourId;
    @ColumnInfo(name = "AERIAL_TOUR_NAME")
    private String aerialTourName;
    @ColumnInfo(name = "IS_IMAGE_UPLOADED")
    private boolean isImageUploaded = false;

    public AerialUploadTourDetails(int id, String imagePath, String projectId, String aerialTourId, String aerialTourName, boolean isImageUploaded) {
        this.id = id;
        this.imagePath = imagePath;
        this.projectId = projectId;
        this.aerialTourId = aerialTourId;
        this.aerialTourName = aerialTourName;
        this.isImageUploaded = isImageUploaded;
    }

    @Ignore
    public AerialUploadTourDetails(String imagePath, String projectId, String aerialTourId, String aerialTourName, boolean isImageUploaded) {
        this.imagePath = imagePath;
        this.projectId = projectId;
        this.aerialTourId = aerialTourId;
        this.aerialTourName = aerialTourName;
        this.isImageUploaded = isImageUploaded;
    }

    public int getId() {
        return id;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getAerialTourId() {
        return aerialTourId;
    }

    public void setAerialTourId(String aerialTourId) {
        this.aerialTourId = aerialTourId;
    }

    public String getAerialTourName() {
        return aerialTourName;
    }

    public void setAerialTourName(String aerialTourName) {
        this.aerialTourName = aerialTourName;
    }

    public boolean isImageUploaded() {
        return isImageUploaded;
    }

    public void setImageUploaded(boolean imageUploaded) {
        isImageUploaded = imageUploaded;
    }
}
