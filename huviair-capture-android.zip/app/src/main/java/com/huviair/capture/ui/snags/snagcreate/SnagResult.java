package com.huviair.capture.ui.snags.snagcreate;

import androidx.annotation.Nullable;

import com.huviair.capture.ui.snags.snaglist.SnagDataView;

public class SnagResult {

    @Nullable
    private SnagDataView success;
    @Nullable
    private Integer error;

    public SnagResult(@Nullable Integer error) {
        this.error = error;
    }

    public SnagResult(@Nullable SnagDataView success) {
        this.success = success;
    }

    @Nullable
    public SnagDataView getSuccess() {
        return success;
    }

    @Nullable
    public Integer getError() {
        return error;
    }
}
