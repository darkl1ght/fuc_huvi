package com.huviair.capture.utils;

import android.widget.ImageView;

import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.huviair.capture.R;
import com.yanzhenjie.album.AlbumFile;
import com.yanzhenjie.album.AlbumLoader;

public class MediaLoader implements AlbumLoader {


    @Override
    public void load(ImageView imageView, AlbumFile albumFile) {
        load(imageView, albumFile.getPath());
    }

    @Override
    public void load(ImageView imageView, String url) {

        GlideApp.with(imageView.getContext())
                .load(url)
                .error(R.drawable.media_icon)
                .placeholder(R.drawable.media_icon)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageView);
    }
}
