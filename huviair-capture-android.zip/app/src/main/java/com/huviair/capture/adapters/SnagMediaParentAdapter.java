package com.huviair.capture.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.huviair.capture.data.model.api.snags.SnagMediaWithHeader;
import com.huviair.capture.databinding.SnagMediaParentBinding;
import com.huviair.capture.ui.snags.snagsmedia.SnagMediaFragment;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class SnagMediaParentAdapter extends RecyclerView.Adapter<SnagMediaParentAdapter.SnagMediaParentViewHolder> {

    private final Activity activity;
    private final SnagMediaFragment fragment;
    private List<SnagMediaWithHeader> snagsWithHeader;

    public SnagMediaParentAdapter(List<SnagMediaWithHeader> snagsWithHeader, Activity activity, SnagMediaFragment fragment) {
        this.snagsWithHeader = snagsWithHeader;
        this.fragment = fragment;
        this.activity = activity;
    }

    public void updateData(List<SnagMediaWithHeader> newMediaList) {
        this.snagsWithHeader = newMediaList;
        notifyDataSetChanged();
    }

    // Create new views (invoked by the layout manager)
    @NotNull
    @Override
    public SnagMediaParentViewHolder onCreateViewHolder(@NotNull ViewGroup viewGroup, int viewType) {
        SnagMediaParentBinding mediaParentBinding;
        mediaParentBinding = SnagMediaParentBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
        return new SnagMediaParentViewHolder(mediaParentBinding);
    }

    @Override
    public void onBindViewHolder(SnagMediaParentViewHolder viewHolder, final int position) {
        viewHolder.mediaParentBinding.heading.setText(snagsWithHeader.get(position).getHeader());
        SnagMediaAdapter snagMediaAdapter = new SnagMediaAdapter(snagsWithHeader.get(position).getSnagMedia(), fragment);

        viewHolder.mediaParentBinding.snagMediaChildRecyclerview.setLayoutManager(new GridLayoutManager(activity, 2));
        viewHolder.mediaParentBinding.snagMediaChildRecyclerview.setHasFixedSize(true);
        viewHolder.mediaParentBinding.snagMediaChildRecyclerview.setAdapter(snagMediaAdapter);
    }

    @Override
    public int getItemCount() {
        return snagsWithHeader.size();
    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class SnagMediaParentViewHolder extends RecyclerView.ViewHolder {
        public SnagMediaParentBinding mediaParentBinding;

        public SnagMediaParentViewHolder(@NonNull SnagMediaParentBinding view) {
            super(view.getRoot());
            this.mediaParentBinding = view;
        }

    }

}

