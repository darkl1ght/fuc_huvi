package com.huviair.capture.data.model.others;

import com.huviair.capture.data.model.api.snags.Snag;

public class SnagFloorPlan {
    private final Snag selectedSnag;
    private final boolean isCreateSnagFragment;

    public SnagFloorPlan(Snag selectedSnag, boolean isCreateSnagFragment) {
        this.selectedSnag = selectedSnag;
        this.isCreateSnagFragment = isCreateSnagFragment;
    }

    public Snag getSelectedSnag() {
        return selectedSnag;
    }

    public boolean isCreateSnagFragment() {
        return isCreateSnagFragment;
    }
}
