package com.huviair.capture.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.huviair.capture.R;
import com.huviair.capture.ui.interiors.videocapture.landing.BottomSheetOption;

import java.util.List;

public class BottomSheetOptionsAdapter extends RecyclerView.Adapter<BottomSheetOptionsAdapter.ViewHolder> {

    private List<BottomSheetOption> options;
    private OnOptionClickListener listener;

    public BottomSheetOptionsAdapter(List<BottomSheetOption> options) {
        this.options = options;
    }

    public void setOnOptionClickListener(OnOptionClickListener listener) {
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bottom_sheet_option, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        BottomSheetOption option = options.get(position);
        holder.textView.setText(option.getTitle());
        holder.imageView.setImageResource(option.getIcon());
    }

    @Override
    public int getItemCount() {
        return options.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView textView;
        private ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView);
            imageView = itemView.findViewById(R.id.icon);
            itemView.setOnClickListener(view -> {
                if (listener != null) {
                    listener.onOptionClick(getBindingAdapterPosition());
                }
            });
        }
    }

    public interface OnOptionClickListener {
        void onOptionClick(int position);
    }
}
