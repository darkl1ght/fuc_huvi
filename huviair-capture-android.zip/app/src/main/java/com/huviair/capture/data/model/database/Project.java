package com.huviair.capture.data.model.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "PROJECTS")
public class Project {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "PROJECT_NAME")
    private String projectName;
    @ColumnInfo(name = "PROJECT_ID")
    private String projectId;
    @ColumnInfo(name = "LOCATION")
    private String location;
    @ColumnInfo(name = "PROJECT_TYPE")
    private String type;
    @ColumnInfo(name = "ALLOWED_VIDEO_CAPTURE_TIME")
    private long allowedVideoCaptureTime;


    public Project(int id, String projectName, String projectId, String location, String type, long allowedVideoCaptureTime) {
        this.id = id;
        this.projectName = projectName;
        this.projectId = projectId;
        this.location = location;
        this.type = type;
        this.allowedVideoCaptureTime = allowedVideoCaptureTime;
    }

    @Ignore
    public Project(String projectName, String projectId, String location, String type, long allowedVideoCaptureTime) {
        this.projectName = projectName;
        this.projectId = projectId;
        this.location = location;
        this.type = type;
        this.allowedVideoCaptureTime = allowedVideoCaptureTime;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getAllowedVideoCaptureTime() {
        return allowedVideoCaptureTime;
    }

    public void setAllowedVideoCaptureTime(long allowedVideoCaptureTime) {
        this.allowedVideoCaptureTime = allowedVideoCaptureTime;
    }

    @Override
    public String toString() {
        return "Project{" +
                "id=" + id +
                ", projectName='" + projectName + '\'' +
                ", projectId='" + projectId + '\'' +
                ", location='" + location + '\'' +
                ", type='" + type + '\'' +
                ", allowedVideoCaptureTime=" + allowedVideoCaptureTime +
                '}';
    }

}
