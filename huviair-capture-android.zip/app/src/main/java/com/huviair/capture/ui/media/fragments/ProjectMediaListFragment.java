package com.huviair.capture.ui.media.fragments;

import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.MediaAPIService;
import com.huviair.capture.data.model.api.media.Album;
import com.huviair.capture.data.model.api.media.Media;
import com.huviair.capture.data.model.api.media.ProjectAlbumsMediaResponse;
import com.huviair.capture.databinding.FragmentAlbumsMediaViewBinding;
import com.huviair.capture.adapters.AlbumMediaAdapter;
import com.huviair.capture.viewmodels.AlbumsListViewModel;
import com.huviair.capture.utils.SharedPreferencesManager;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProjectMediaListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProjectMediaListFragment extends Fragment implements CreateMediaDialogFragment.MediaUploadStatusListener {

    private static final String SELECTED_ALBUM = "SELECTED_ALBUM";
    private FragmentAlbumsMediaViewBinding fragmentAlbumsMediaViewBinding;

    private AlbumsListViewModel albumsListViewModel;

    private Album selectedAlbum;
    private List<Media> media;
    private AlbumMediaAdapter albumMediaAdapter;

    private RecyclerView.LayoutManager layoutManager;
    private Parcelable state;

    public ProjectMediaListFragment() {
        // Required empty public constructor
    }

    public static ProjectMediaListFragment newInstance(Album selectedAlbum) {
        ProjectMediaListFragment fragment = new ProjectMediaListFragment();
        Bundle args = new Bundle();
        args.putSerializable(SELECTED_ALBUM, selectedAlbum);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            selectedAlbum = (Album) getArguments().getSerializable(SELECTED_ALBUM);
            media = selectedAlbum.getMedia();
        }
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentAlbumsMediaViewBinding = FragmentAlbumsMediaViewBinding.inflate(inflater, container, false);
        return fragmentAlbumsMediaViewBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get ViewModel associated to the activity
        albumsListViewModel = new ViewModelProvider(requireActivity()).get(AlbumsListViewModel.class);

        ViewCompat.setTransitionName(fragmentAlbumsMediaViewBinding.getRoot(), "test");

        // Enable bottom nav
        requireActivity().findViewById(R.id.bottom_navigation_media).setVisibility(View.VISIBLE);

        fragmentAlbumsMediaViewBinding.mediaViewBar.toolBar.setTitle(selectedAlbum.getAlbumName());
        fragmentAlbumsMediaViewBinding.mediaViewBar.toolBar.setNavigationIcon(R.drawable.navigation_back_icon);
        fragmentAlbumsMediaViewBinding.mediaViewBar.toolBar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        // Show dialog fragment
        fragmentAlbumsMediaViewBinding.fabAddMedia.setOnClickListener(v -> {
            fragmentAlbumsMediaViewBinding.fabAddMedia.setRotation(0);
            ViewCompat.animate(fragmentAlbumsMediaViewBinding.fabAddMedia)
                    .rotation(360)
                    .withLayer()
                    .setDuration(1000)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .start();
            CreateMediaDialogFragment dialogFragment = CreateMediaDialogFragment.newInstance(selectedAlbum.getProjectId(), selectedAlbum.getAlbumId());
            dialogFragment.show(getChildFragmentManager(), "Media Fragment");
        });

        listenForChanges();

        if (media == null || media.size() == 0) {
            fragmentAlbumsMediaViewBinding.noMediaAvailableTextView.setVisibility(View.VISIBLE);
        } else {
            fetchMedia();
        }

        refreshOnSwipe();
    }

    private void refreshOnSwipe() {
        fragmentAlbumsMediaViewBinding.refreshMedia.setOnRefreshListener(() -> {
            fetchMedia();
            fragmentAlbumsMediaViewBinding.refreshMedia.setRefreshing(false);
        });
    }

    private void listenForChanges() {
        albumsListViewModel.isMediaDeleted.observe(getViewLifecycleOwner(), isDeleted -> {
            if (isDeleted) {
                showSnackBarMessage("Media items deleted successfully", R.color.snackbar_success);
                fetchMedia();
            }
        });

        albumsListViewModel.isDeletingMedia.observe(getViewLifecycleOwner(), isMediaDeleteInProgress -> {

            fragmentAlbumsMediaViewBinding.recyclerMediaView.setVisibility(isMediaDeleteInProgress ? View.GONE : View.VISIBLE);
            fragmentAlbumsMediaViewBinding.backgroundProcessing.setVisibility(isMediaDeleteInProgress ? View.VISIBLE : View.GONE);

            if (isMediaDeleteInProgress) fragmentAlbumsMediaViewBinding.fabAddMedia.hide();
            else fragmentAlbumsMediaViewBinding.fabAddMedia.show();

        });

        // Hide and show FAB add media based on scroll
        fragmentAlbumsMediaViewBinding.recyclerMediaView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NotNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    // Scroll Down
                    if (fragmentAlbumsMediaViewBinding.fabAddMedia.isShown()) {
                        fragmentAlbumsMediaViewBinding.fabAddMedia.hide();
                    }
                } else if (dy < 0) {
                    // Scroll Up
                    if (!fragmentAlbumsMediaViewBinding.fabAddMedia.isShown()) {
                        fragmentAlbumsMediaViewBinding.fabAddMedia.show();
                    }
                }
            }
        });
    }

    private void showSnackBarMessage(String text, int color) {
        Snackbar.make(fragmentAlbumsMediaViewBinding.getRoot(), text, BaseTransientBottomBar.LENGTH_SHORT)
                .setBackgroundTint(ContextCompat.getColor(requireContext(), color))
                .setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
                .setAnchorView(requireActivity().findViewById(R.id.bottom_navigation_media))
                .show();
    }

    private void populateMediaViews() {

        // populate animation
        int resId = R.anim.grid_layout_animation_from_bottom;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(requireContext(), resId);
        fragmentAlbumsMediaViewBinding.recyclerMediaView.setLayoutAnimation(animation);

        if (state != null) layoutManager.onRestoreInstanceState(state);
        layoutManager = new GridLayoutManager(requireContext(), 3);

        albumMediaAdapter = new AlbumMediaAdapter(media, requireActivity());

        fragmentAlbumsMediaViewBinding.recyclerMediaView.setLayoutManager(layoutManager);
        fragmentAlbumsMediaViewBinding.recyclerMediaView.setHasFixedSize(true);
        fragmentAlbumsMediaViewBinding.recyclerMediaView.setAdapter(albumMediaAdapter);
    }


    //Listener
    @Override
    public void onUploadComplete(boolean isUploaded) {
        if (isUploaded) fetchMedia();
    }


    @Override
    public void onPause() {
        super.onPause();
        if (layoutManager != null) {
            state = layoutManager.onSaveInstanceState();
        }

    }

    private void fetchMedia() {

        fragmentAlbumsMediaViewBinding.backgroundProcessing.setVisibility(View.VISIBLE);
        fragmentAlbumsMediaViewBinding.noMediaAvailableTextView.setVisibility(View.GONE);


        MediaAPIService mediaService = APIClient.createService(MediaAPIService.class, getContext(), APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(requireContext()).getJwtToken());

        mediaService.getMediaOfAlbum(selectedAlbum.getProjectId(), selectedAlbum.getAlbumId())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<ProjectAlbumsMediaResponse>() {
                    @Override
                    public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) {

                    }

                    @Override
                    public void onSuccess(@io.reactivex.annotations.NonNull ProjectAlbumsMediaResponse projectAlbumsMediaResponse) {
                        media = projectAlbumsMediaResponse.getMedia();
                        fragmentAlbumsMediaViewBinding.backgroundProcessing.setVisibility(View.GONE);
                        if (media == null || media.size() == 0) {
                            fragmentAlbumsMediaViewBinding.noMediaAvailableTextView.setVisibility(View.VISIBLE);
                        } else {
                            if (albumMediaAdapter != null) {
                                albumMediaAdapter.updateAdapterData(media);
                            } else populateMediaViews();
                        }

                    }

                    @Override
                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {
                        showSnackBarMessage("Technical Error !", R.color.snackbar_error);
                        fragmentAlbumsMediaViewBinding.backgroundProcessing.setVisibility(View.GONE);
                    }
                });

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (fragmentAlbumsMediaViewBinding != null) {
            fragmentAlbumsMediaViewBinding = null;
        }
        if (albumMediaAdapter != null) {
            albumMediaAdapter = null;
        }
    }

}