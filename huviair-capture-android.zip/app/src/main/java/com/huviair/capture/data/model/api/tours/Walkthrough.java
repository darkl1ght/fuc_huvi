package com.huviair.capture.data.model.api.tours;

import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Walkthrough implements Serializable {

    private Image[] images;
    private String tourId;
    private String tourName;
    private String towerId;
    private String projectId;
    private boolean isPublished;
    private Feature features;


    public Image[] getImages() {
        return images;
    }

    public void setImages(Image[] images) {
        this.images = images;
    }

    public String getTourId() {
        return tourId;
    }

    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    public String getTowerId() {
        return towerId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public boolean isPublished() {
        return isPublished;
    }

    public void setPublished(boolean published) {
        isPublished = published;
    }

    public Feature getFeatures() {
        return features;
    }

    public void setFeatures(Feature features) {
        this.features = features;
    }



    public List<ImageFeature> getPreviousCapturedFeatures() {
        return this.features.getFeatures().stream()
                .filter(Objects::nonNull)
                .sorted(Comparator.comparing(imageFeature -> imageFeature.getProperties().getImageNumber()))
                .collect(Collectors.toList());
    }
}
