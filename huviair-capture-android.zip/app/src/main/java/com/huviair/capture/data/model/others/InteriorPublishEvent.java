package com.huviair.capture.data.model.others;

public class InteriorPublishEvent {
    private final String selectedTowerId;
    private final String selectedInteriorId;

    public InteriorPublishEvent(String selectedTowerId, String selectedInteriorId) {
        this.selectedTowerId = selectedTowerId;
        this.selectedInteriorId = selectedInteriorId;
    }

    public String getSelectedTowerId() {
        return selectedTowerId;
    }

    public String getSelectedInteriorId() {
        return selectedInteriorId;
    }
}
