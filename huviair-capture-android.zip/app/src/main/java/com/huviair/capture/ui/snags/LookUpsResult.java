package com.huviair.capture.ui.snags;

import androidx.annotation.Nullable;

public class LookUpsResult {
    @Nullable
    private LookupDataView success;
    @Nullable
    private Integer error;

    public LookUpsResult(@Nullable Integer error) {
        this.error = error;
    }

    public LookUpsResult(@Nullable LookupDataView success) {
        this.success = success;
    }

    @Nullable
    public LookupDataView getSuccess() {
        return success;
    }

    @Nullable
    public Integer getError() {
        return error;
    }
}
