package com.huviair.capture.data.model.api;

import java.io.Serializable;

public class AuditLog implements Serializable {

    private String additionalInfo;
    private String type;
    private String method;
    private String logDate;
    private String logInfo;

    public AuditLog(String tourId, String type, String method, String logDate, String logInfo) {
        this.type = type;
        this.additionalInfo = tourId;
        this.type = type;
        this.method = method;
        this.logDate = logDate;
        this.logInfo = logInfo;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLogDate() {
        return logDate;
    }

    public void setLogDate(String logDate) {
        this.logDate = logDate;
    }

    public String getLogInfo() {
        return logInfo;
    }

    public void setLogInfo(String logInfo) {
        this.logInfo = logInfo;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
}
