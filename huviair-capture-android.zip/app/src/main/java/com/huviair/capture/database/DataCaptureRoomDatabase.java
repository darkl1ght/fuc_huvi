package com.huviair.capture.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.huviair.capture.data.model.database.AerialUploadTourDetails;
import com.huviair.capture.data.model.database.Interior;
import com.huviair.capture.data.model.database.InteriorTourCoordinates;
import com.huviair.capture.data.model.database.InteriorTower;
import com.huviair.capture.data.model.database.InteriorVideoCapture;
import com.huviair.capture.data.model.database.InteriorWalkthrough;
import com.huviair.capture.data.model.database.ListConverter;
import com.huviair.capture.data.model.database.PointFConverter;
import com.huviair.capture.data.model.database.Project;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.data.model.database.AuditLog;
import com.huviair.capture.data.repositories.AuditLogsRepository;
import com.huviair.capture.utils.CommonConstants;

import org.jetbrains.annotations.NotNull;

@Database(entities = {TourDetails.class, AerialUploadTourDetails.class, Project.class, Interior.class, InteriorTower.class, InteriorWalkthrough.class, InteriorVideoCapture.class, InteriorTourCoordinates.class,AuditLog.class}, version = 17, exportSchema = false)
@TypeConverters({PointFConverter.class, ListConverter.class})
public abstract class DataCaptureRoomDatabase extends RoomDatabase {


    public abstract InteriorTourDetailsDAO tourDetailsDAO();
    public abstract  ProjectCacheDAO projectCacheDAO();
    public abstract AerialTourDetailsDAO aerialTourDetailsDAO();
    public abstract AuditLogsDAO auditLogsDAO();

    private static volatile DataCaptureRoomDatabase INSTANCE;


    static final Migration MIGRATION_13_17 = new Migration(13, 17) {
        @Override
        public void migrate(@NotNull SupportSQLiteDatabase database) {
            database.execSQL("CREATE TABLE INTERIOR_VIDEO_WALKTHROUGH (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `INTERIOR_ID` TEXT, `PROJECT_ID` TEXT, `WALKTHROUGH_ID` TEXT, `CAPTURE_START_POINT` TEXT, `CAPTURE_END_POINT` TEXT, `TIMELAPSE_VIDEO_URL` TEXT, `TOWER_ID` TEXT, `WALKTHROUGH_NAME` TEXT, `IS_VIDEO_UPLOADED` INTEGER NOT NULL)");
            database.execSQL("CREATE TABLE `INTERIOR_TOUR_COORDINATES` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `type` TEXT, `imageId` TEXT, `imageNumber` INTEGER NOT NULL, `xCoordinate` REAL NOT NULL, `yCoordinate` REAL NOT NULL, `tourId` TEXT)");

        }
    };

    static final Migration MIGRATION_14_15 = new Migration(14, 15) {
        @Override
        public void migrate(@NotNull SupportSQLiteDatabase database) {
            database.execSQL("CREATE TABLE `INTERIOR_TOUR_COORDINATES` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `type` TEXT, `imageId` TEXT, `imageNumber` INTEGER NOT NULL, `xCoordinate` REAL NOT NULL, `yCoordinate` REAL NOT NULL, `tourId` TEXT)");
        }
    };

    public static final Migration MIGRATION_15_16 = new Migration(15, 16) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE PROJECTS ADD COLUMN ALLOWED_VIDEO_CAPTURE_TIME INTEGER DEFAULT 14 NOT NULL");
        }
    };
    public static final Migration MIGRATION_16_17 = new Migration(16, 17) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("CREATE TABLE `AUDIT_LOGS` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,`tourId` TEXT, `method` TEXT, `type` TEXT,`logDate` Text, `logInfo` TEXT)");
        }
    };

    public static DataCaptureRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (DataCaptureRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            DataCaptureRoomDatabase.class, CommonConstants.DATABASE_NAME)
                            .addMigrations(MIGRATION_13_17, MIGRATION_14_15, MIGRATION_15_16,MIGRATION_16_17)
                            .build();
                }
            }
        }
        return INSTANCE;
    }


}
