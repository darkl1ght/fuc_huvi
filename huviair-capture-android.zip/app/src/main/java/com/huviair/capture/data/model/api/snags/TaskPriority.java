package com.huviair.capture.data.model.api.snags;

import java.io.Serializable;
import java.util.Objects;

public class TaskPriority implements Serializable {
    private String code;
    private String desc;

    public TaskPriority(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TaskPriority that = (TaskPriority) o;
        return Objects.equals(code, that.code) &&
                Objects.equals(desc, that.desc);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, desc);
    }
}
