package com.huviair.capture.data.model.api.snags;

import java.io.Serializable;
import java.util.List;

public class SelectedSnagMediaDetails implements Serializable {

    private Integer position;
    private List<SnagMedia> media;

    public SelectedSnagMediaDetails(Integer position, List<SnagMedia> media) {
        this.position = position;
        this.media = media;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public List<SnagMedia> getMedia() {
        return media;
    }

    public void setMedia(List<SnagMedia> media) {
        this.media = media;
    }
}
