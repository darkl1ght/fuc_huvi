package com.huviair.capture.ui.projects;

import com.huviair.capture.data.model.api.projects.Project;

import java.util.List;

/**
 * Class exposing project details to the UI
 */
public class ProjectDataView {
    private List<Project> projects;

    public ProjectDataView(List<Project> projects) {
        this.projects = projects;
    }

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }
}