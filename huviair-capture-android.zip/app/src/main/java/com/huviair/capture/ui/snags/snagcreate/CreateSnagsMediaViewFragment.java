package com.huviair.capture.ui.snags.snagcreate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.davemorrissey.labs.subscaleview.ImageSource;
import com.huviair.capture.R;
import com.huviair.capture.databinding.MediaViewBinding;

// Instances of this class are fragments representing a single
// object in our collection.
public class CreateSnagsMediaViewFragment extends Fragment {
    public static final String MEDIA_FILE_PATH = "MEDIA_PATH";

    private MediaViewBinding mediaViewerBinding;
    private String mediaFilePath;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        mediaViewerBinding = MediaViewBinding.inflate(inflater, container, false);
        return mediaViewerBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();
        if (getArguments() != null) {
            mediaFilePath = args.getString(MEDIA_FILE_PATH);
        }

        String fileName = mediaFilePath.substring(mediaFilePath.lastIndexOf("/") + 1);

        requireActivity().findViewById(R.id.bottom_navigation_snag).setVisibility(View.GONE);
        mediaViewerBinding.projectBar.toolbar.setTitle(fileName);
        mediaViewerBinding.projectBar.toolbar.setNavigationIcon(R.drawable.navigation_back_icon);

        mediaViewerBinding.projectBar.toolbar.setNavigationOnClickListener(v -> requireActivity().onBackPressed());

        loadImage(mediaFilePath);
    }

    private void loadImage(String urlToLoad) {
        mediaViewerBinding.imagePreview.setImage(ImageSource.uri(urlToLoad));

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mediaViewerBinding != null) {
            mediaViewerBinding = null;
        }
    }
}

