package com.huviair.capture.ui.interiors.interiorsDataExport.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.snackbar.Snackbar;
import com.huviair.capture.R;
import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.tours.Image;
import com.huviair.capture.data.model.database.AuditLog;
import com.huviair.capture.data.model.database.TourDetails;
import com.huviair.capture.data.model.api.tours.TourWalkThroughRequest;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.databinding.FragmentPublishDataBinding;
import com.huviair.capture.ui.interiors.interiorsDataExport.TourDataTransferFragmentActivity;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.NetworkListener;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.net.URI;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import id.zelory.compressor.Compressor;
import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PublishImagesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PublishImagesFragment extends Fragment {

    public static final String TOUR_ID = "TOUR_ID";
    public static final String INTERIOR_ID = "INTERIOR_ID";
    public static final String PROJECT_ID = "PROJECT_ID";
    private final CompositeDisposable disposableBag = new CompositeDisposable();
    AtomicInteger successfulCount = new AtomicInteger(0);
    private FragmentPublishDataBinding publishDataBinding;
    private SharedPreferencesManager sharedPreferencesManager;

    // Tour Details Variables
    private String tourId;
    private String projectId;
    private String interiorId;
    // Total list size
    private int toursListSize;

    public PublishImagesFragment() {
        // Required empty public constructor
    }

    public static PublishImagesFragment newInstance(String tourId, String projectId, String interiorId) {
        PublishImagesFragment fragment = new PublishImagesFragment();
        Bundle args = new Bundle();
        args.putString(TOUR_ID, tourId);
        args.putString(INTERIOR_ID, interiorId);
        args.putString(PROJECT_ID, projectId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        publishDataBinding = FragmentPublishDataBinding.inflate(inflater, container, false);
        return publishDataBinding.getRoot();
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            tourId = getArguments().getString(TOUR_ID);
            projectId = getArguments().getString(PROJECT_ID);
            interiorId = getArguments().getString(INTERIOR_ID);
            sharedPreferencesManager = new SharedPreferencesManager(requireContext());
        }
    }


    @Override
    public void onStart() {
        super.onStart();
        View view = getView();
        if (view != null) {
            publishDataBinding.publishImagesButton.setOnClickListener(v -> publishData());
            publishDataBinding.previousPageGenerate.setOnClickListener(v -> ((TourDataTransferFragmentActivity) requireActivity()).jumpToPreviousPage(view));
            publishDataBinding.returnToFloorPlanButton.setOnClickListener(v -> requireActivity().finish());
        }

        fetchPreviouslyProcessedData();

    }

    private void fetchPreviouslyProcessedData() {
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(requireContext());
        disposableBag.add(database.tourDetailsDAO().getAllTourDetails(tourId).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(tourDetails -> {
                    if (!tourDetails.isEmpty()) {
                        long uploadedCount = tourDetails.stream().filter(TourDetails::isWalkThroughUploaded).count();
                        if (uploadedCount > 0) {
                            publishDataBinding.publishTextProgress.setVisibility(View.VISIBLE);
                            publishDataBinding.publishTextProgress.setText(getString(R.string.publish_images_completed, uploadedCount, tourDetails.size()));
                        }
                    }
                }));
    }

    /*
         Steps involved
         1) Fetch the azure token for uploading images to azure blob
         2) Get the latest snapshot of the tour details from the room database
         3) Submit all the data in one go to the backend
         */
    private void publishData() {
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(requireContext());
        disposableBag.add(NetworkListener.hasInternetConnection(requireContext())
                .subscribe(hasInternet -> {
                    if (!hasInternet) {
                        Snackbar.make(publishDataBinding.getRoot(), "No Internet available", Snackbar.LENGTH_LONG)
                                .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                .show();
                    } else {
                        publishDataBinding.publishImagesProgress.setVisibility(View.VISIBLE);
                        toggleButtonsVisibility(false);

                        APIService service = APIClient.createService(APIService.class, getContext(), APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(requireContext()).getJwtToken());

                        disposableBag.add(
                                service.getAzureTokenWritePermission(CommonConstants.VIRTUAL_TOUR)
                                        .flatMap(azureTokenResponse -> {
                                            String containerURI = azureTokenResponse.getSasToken() != null ? azureTokenResponse.getSasToken().getUri() : null;
                                            CloudBlobContainer container = new CloudBlobContainer(URI.create(containerURI));
                                            return Single.just(container);
                                        })
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(AndroidSchedulers.mainThread())
                                        .subscribe((container) -> {
                                                   // DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(getContext());
                                                    Single<List<TourDetails>> toursToPublishToBackend = database.tourDetailsDAO().getToursToPublishToBackend(tourId);

                                                    disposableBag.add(toursToPublishToBackend.subscribeOn(Schedulers.io())
                                                            .observeOn(AndroidSchedulers.mainThread())
                                                            .subscribe((tourDetails, throwable) -> {
                                                                if (!tourDetails.isEmpty()) {
                                                                    toursListSize = tourDetails.size();
                                                                    uploadWalkthroughData(container, tourDetails);
                                                                } else {
                                                                    Snackbar.make(publishDataBinding.getRoot(), "No Data available to Publish", Snackbar.LENGTH_LONG)
                                                                            .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                                                            .show();

                                                                    publishDataBinding.publishImagesProgress.setVisibility(View.GONE);
                                                                    toggleButtonsVisibility(true);

                                                                }

                                                            }));
                                                },
                                                throwable -> {
                                                    publishDataBinding.publishImagesProgress.setVisibility(View.GONE);
                                                    toggleButtonsVisibility(true);
                                                    AuditLog errorLog = new AuditLog(tourId,
                                                            "exception",
                                                            "publishData",
                                                            new Date().toString(),
                                                            throwable.getMessage());
                                                    database.auditLogsDAO().insertLog(errorLog);
                                                    Snackbar.make(publishDataBinding.getRoot(), "Technical error. Try again..", Snackbar.LENGTH_LONG)
                                                            .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                                            .show();
                                                }));

                    }
                }));

    }

    private void uploadWalkthroughData(CloudBlobContainer container, List<TourDetails> toursToUpload) {
        // Get Service and DB objects
        APIService service = APIClient.createService(APIService.class, getContext(), APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(requireContext()).getJwtToken());
        DataCaptureRoomDatabase database = DataCaptureRoomDatabase.getDatabase(requireContext());

        Observable.fromIterable(toursToUpload)
                .flatMap(tour -> {
                    TourWalkThroughRequest request = new TourWalkThroughRequest();
                    return uploadCompressedImageToBlob(container, tour, request)
                            .flatMap(walkThroughRequest -> service.updateTourDetails(projectId, interiorId, tourId, walkThroughRequest).toObservable()
                                    .flatMap(o -> {
                                        int rowId = database.tourDetailsDAO().markWalkThroughUploadStatus(true, tour.getId());
                                        return Observable.just(rowId);
                                    })
                                    .subscribeOn(Schedulers.from(Executors.newFixedThreadPool(10))));
                },5)
                .doOnComplete(() -> service.updateInteriorPublishDetails(projectId, interiorId, tourId).execute())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(disposable -> {
                    publishDataBinding.publishTextProgress.setVisibility(View.VISIBLE);
                    publishDataBinding.publishTextProgress.setText(getString(R.string.publish_images_processing, successfulCount.intValue(), toursListSize));
                })
                .subscribe(new DisposableObserver<Object>() {
                    @Override
                    public void onNext(@NonNull Object aLong) {
                        successfulCount.incrementAndGet();
                        publishDataBinding.publishTextProgress.setText(getString(R.string.publish_images_processing, successfulCount.intValue(), toursListSize));
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        toggleButtonsVisibility(true);
                        publishDataBinding.publishImagesProgress.setVisibility(View.GONE);
                        publishDataBinding.publishTextProgress.setVisibility(View.GONE);
                        AuditLog errorLog = new AuditLog(tourId,
                                "exception",
                                "uploadWalkthroughData",
                                new Date().toString(),
                                e.getMessage());
                        database.auditLogsDAO().insertLog(errorLog);
                        successfulCount.set(0);

                        Snackbar.make(publishDataBinding.getRoot(), "Something went wrong, please contact huviair support", Snackbar.LENGTH_LONG)
                                .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                .show();
                    }

                    @Override
                    public void onComplete() {
                        publishDataBinding.publishImagesProgress.setVisibility(View.GONE);
                        fetchPreviouslyProcessedData();
                        successfulCount.set(0);

                        toggleButtonsVisibility(true);
                        Snackbar.make(publishDataBinding.getRoot(), "Walk-Through submitted successfully", Snackbar.LENGTH_LONG)
                                .setBackgroundTint(ContextCompat.getColor(requireContext(), R.color.snackbar_default))
                                .show();
                    }
                });
    }


    private Observable<TourWalkThroughRequest> uploadCompressedImageToBlob(CloudBlobContainer container, TourDetails tourDetails, TourWalkThroughRequest request) throws Exception {
        return Observable.fromCallable(() -> {
            String imageName = tourDetails.getHdrExportFileName().substring(tourDetails.getHdrExportFileName().lastIndexOf("/") + 1);
            CloudBlockBlob blob = container.getBlockBlobReference(tourDetails.getTourId() + "/" + imageName);

            String filePath = "";
            // Compress Image and get the path
            if (!sharedPreferencesManager.isHDQualityEnabled())
                filePath = new Compressor(requireContext()).compressToFile(new File(tourDetails.getHdrExportFileName())).getPath();

            else filePath = tourDetails.getHdrExportFileName();

            blob.uploadFromFile(filePath);
            String imageId = imageName.substring(0, imageName.length() - 4);
            request.addImagesAndFeatures(new Image(imageId, imageName, imageId, tourDetails.getOffsetFromNorth()), tourDetails.getImageNumber(), tourDetails.getXCoordinate(), tourDetails.getYCoordinate());
            return request;
        });
    }


    private void toggleButtonsVisibility(boolean enableButton) {
        publishDataBinding.publishImagesButton.setEnabled(enableButton);
        publishDataBinding.previousPageGenerate.setEnabled(enableButton);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (publishDataBinding != null) {
            publishDataBinding = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (!disposableBag.isDisposed()) {
            disposableBag.dispose();
        }
    }
}