package com.huviair.capture.data.repositories;

import android.app.Application;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.data.model.api.SendLogRequest;
import com.huviair.capture.data.model.api.common.CommonResponse;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.SharedPreferencesManager;

import io.reactivex.Single;

public class AuditLogsRepository {

    private final APIService auditLogsService;
    private final DataCaptureRoomDatabase database;


    public AuditLogsRepository(Application application) {
        auditLogsService = APIClient.createService(APIService.class, application, APIClient.getProjectApiBaseUrl(),
                new SharedPreferencesManager(application).getJwtToken());
        database = DataCaptureRoomDatabase.getDatabase(application);
    }

    public Single<CommonResponse> sendLogs(SendLogRequest logRequest) {
        return auditLogsService.sendLogs(logRequest);
    }

}
