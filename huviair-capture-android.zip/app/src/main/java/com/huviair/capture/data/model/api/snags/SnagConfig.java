package com.huviair.capture.data.model.api.snags;

public class SnagConfig {

    private Config config;
    private String searchTerm;

    public SnagConfig(String searchTerm, Config config) {
        this.searchTerm = searchTerm;
        this.config = config;
    }

    public String getSearchTerm() {
        return searchTerm;
    }

    public void setSearchTerm(String searchTerm) {
        this.searchTerm = searchTerm;
    }

    public Config getConfig() {
        return config;
    }

    public void setConfig(Config config) {
        this.config = config;
    }


}


