package com.huviair.capture.data.model.api.tours;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Feature implements Serializable {
    private final String type;
    private List<ImageFeature> features;

    // Constructor used for an individual feature
    public Feature(Image image, Double xCoordinate, Double yCoordinate) {
        this.type = "FeatureCollection";
        addFeature(image, xCoordinate, yCoordinate);
    }

    // Constructor used for onetime object creation
    public Feature(List<ImageFeature> imageFeatures) {
        this.type = "FeatureCollection";
        this.features = imageFeatures;
    }

    public void addFeature(Image image, Double xCoordinate, Double yCoordinate) {
        if (this.features == null) {
            features = new ArrayList<>();
        }
        features.add(new ImageFeature(image, xCoordinate, yCoordinate));

    }

    public List<ImageFeature> getFeatures() {
        return features;
    }

    @Override
    public String toString() {
        return "Feature{" +
                "type='" + type + '\'' +
                ", features=" + features +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Feature feature = (Feature) o;
        return Objects.equals(type, feature.type) &&
                Objects.equals(features, feature.features);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, features);
    }
}
