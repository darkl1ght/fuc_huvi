package com.huviair.capture.data.model.api.tours;

import java.io.Serializable;
import java.util.Objects;

public class Properties implements Serializable {
    private final String imageName;
    private final String imageId;
    private int imageNumber;

    public String getImageName() {
        return imageName;
    }

    public String getImageId() {
        return imageId;
    }

    public int getImageNumber() {
        return imageNumber;
    }

    public void setImageNumber(int imageNumber) {
        this.imageNumber = imageNumber;
    }

    // used in interiors-tour
    public Properties(String imageId, String imageName, int imageNumber) {
        this.imageId = imageId;
        this.imageName = imageName;
        this.imageNumber = imageNumber;
    }

    // used in snag- floor plan
    public Properties(String imageId, String imageName) {
        this.imageId = imageId;
        this.imageName = imageName;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Properties that = (Properties) o;
        return Objects.equals(imageName, that.imageName) &&
                Objects.equals(imageId, that.imageId) &&
                Objects.equals(imageNumber, that.imageNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(imageName, imageId, imageNumber);
    }
}
