package com.huviair.capture.workers;

import android.app.Notification;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import androidx.annotation.NonNull;
import androidx.exifinterface.media.ExifInterface;
import androidx.work.Data;
import androidx.work.ForegroundInfo;
import androidx.work.RxWorker;
import androidx.work.WorkerParameters;

import com.huviair.capture.api.APIClient;
import com.huviair.capture.api.APIService;
import com.huviair.capture.api.AerialAPIService;
import com.huviair.capture.data.model.api.aerial.AerialImageMetaData;
import com.huviair.capture.data.model.api.aerial.AerialImageRequest;
import com.huviair.capture.data.model.api.aerial.AerialImageResponse;
import com.huviair.capture.data.model.api.aerial.AerialTourRequest;
import com.huviair.capture.data.model.database.AerialUploadTourDetails;
import com.huviair.capture.database.DataCaptureRoomDatabase;
import com.huviair.capture.utils.CommonConstants;
import com.huviair.capture.utils.SharedPreferencesManager;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

import io.reactivex.Completable;
import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.Single;
import io.reactivex.observers.DisposableCompletableObserver;
import io.reactivex.schedulers.Schedulers;

public class UploadAerialImagesWorker extends RxWorker {

    private final APIService apiService;
    private final AerialAPIService aerialAPIService;
    private final DataCaptureRoomDatabase database;
    private AtomicLong uploadCount = new AtomicLong(0);
    // used in logic
    private int toursToUploadSize;
    private double latitudeSum;
    private double longitudeSum;

    /**
     * @param appContext   The application {@link Context}
     * @param workerParams Parameters to setup the internal state of this worker
     */
    public UploadAerialImagesWorker(@NonNull Context appContext, @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);

        // Initialize API services
        apiService = APIClient.createService(APIService.class, appContext, APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(appContext).getJwtToken());
        aerialAPIService = APIClient.createService(AerialAPIService.class, appContext, APIClient.getProjectApiBaseUrl(), new SharedPreferencesManager(appContext).getJwtToken());

        // Initialize database
        database = DataCaptureRoomDatabase.getDatabase(appContext);
    }

    @NonNull
    @Override
    public Single<Result> createWork() {
        try {
            String projectId = getInputData().getString(CommonConstants.PROJECT_ID);
            String aerialTourId = getInputData().getString(CommonConstants.INTERIOR_TOUR_ID);
            String aerialTourName = getInputData().getString(CommonConstants.TOUR_NAME);

            Data.Builder builder = new Data.Builder()
                    .putString(CommonConstants.PROJECT_ID, projectId)
                    .putString(CommonConstants.TOUR_NAME, aerialTourName)
                    .putString(CommonConstants.INTERIOR_TOUR_ID, aerialTourId);

            Observable<List<AerialUploadTourDetails>> aerialsFromDB = database.aerialTourDetailsDAO().getAerialToursToUpload(aerialTourId).toObservable();

            setForegroundAsync(createForegroundInfo(true, "Uploading images job queued for tour ".concat(aerialTourName), aerialTourId));

            Observable<CloudBlobContainer> cloudBlobContainerObservable = apiService.getAzureTokenForLongRunningTask(CommonConstants.AERIAL_TOUR)
                    .flatMap(azureTokenResponse -> {
                        String containerURI = azureTokenResponse.getSasToken() != null ? azureTokenResponse.getSasToken().getUri() : null;
                        CloudBlobContainer container = new CloudBlobContainer(URI.create(containerURI));
                        return Single.just(container);
                    }).toObservable();


            return cloudBlobContainerObservable.flatMap(container -> aerialsFromDB
                    .filter(aerialUploadTourDetails -> aerialUploadTourDetails.size() > 0)
                    .map(aerialUploadTourDetails -> {
                        // Populate the total size and the previous upload size (if any)
                        toursToUploadSize = aerialUploadTourDetails.size();
                        uploadCount = new AtomicLong(aerialUploadTourDetails.stream().filter(AerialUploadTourDetails::isImageUploaded).count());
                        return aerialUploadTourDetails;
                    })
                    .flatMap(aerialUploadTourDetails -> Observable.fromIterable(aerialUploadTourDetails)
                            .filter(row -> !row.isImageUploaded())
                            .flatMap(tourDetails -> uploadMediaToAzureBlob(tourDetails, container)
                                            .flatMap(tourRequest -> uploadMediaDetailsToBackend(tourRequest, projectId, aerialTourId))
                                    , 5).subscribeOn(Schedulers.from(Executors.newFixedThreadPool(8)))))
                    .doOnSubscribe(disposable -> setForegroundAsync(createForegroundInfo(true, "Uploading images for the tour - ".concat(aerialTourName), aerialTourId)))
                    .doOnNext(aerialImageResponse -> {
                        setForegroundAsync(createForegroundInfo(true, String.format(Locale.getDefault(), "Uploading images %d of %d ", uploadCount.incrementAndGet(), toursToUploadSize), aerialTourId));
                        database.aerialTourDetailsDAO().markAerialImageUploadStatus(true, aerialImageResponse.getImageRowId());
                    })
                    .doOnComplete(() -> {
                        setForegroundAsync(createForegroundInfo(false, "Uploading images completed for tour - ".concat(aerialTourName), aerialTourId));
                        populateTourCenter(projectId, aerialTourId)
                                .subscribeOn(Schedulers.io())
                                .subscribe(new DisposableCompletableObserver() {
                                    @Override
                                    public void onComplete() {
                                    }

                                    @Override
                                    public void onError(@io.reactivex.annotations.NonNull Throwable e) {

                                    }
                                });
                    })
                    .doOnError(throwable -> setForegroundAsync(createForegroundInfo(false, "Images upload failed for tour - " + throwable.getMessage(), aerialTourId)))
                    .toList()
                    .map(aerialImageResponses -> {
                        setForegroundAsync(createForegroundInfo(false, "Uploading images completed for tour - ".concat(aerialTourName), aerialTourId));
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.success(builder.build());
                    })
                    .onErrorReturn(throwable -> {
                        builder.putLong(CommonConstants.WORK_COMPLETED_ON, new Date().getTime());
                        return Result.failure(builder.build());
                    });
        } catch (Exception e) {
            return Single.just(Result.failure());
        }
    }

    private Completable populateTourCenter(String projectId, String aerialTourId) {
        Map<String, Double> requestBody = new HashMap<>();
        requestBody.put("lat", latitudeSum / toursToUploadSize);
        requestBody.put("lng", longitudeSum / toursToUploadSize);
        return aerialAPIService.saveTourCenter(projectId, aerialTourId, requestBody);
    }

    private Observable<AerialImageResponse> uploadMediaDetailsToBackend(AerialTourRequest tourRequest, String projectId, String tourId) throws InterruptedException {
        AerialImageRequest aerialImageRequest = new AerialImageRequest();
        aerialImageRequest.setImage(tourRequest);
        return aerialAPIService.updateImageDetailsToBackEnd(projectId, tourId, aerialImageRequest).toObservable().doOnNext(aerialImageResponse -> aerialImageResponse.setImageRowId(tourRequest.getImageRowId()));
    }

    private Observable<AerialTourRequest> uploadMediaToAzureBlob(AerialUploadTourDetails aerialDbObject, CloudBlobContainer azureBlobContainer) throws IOException {
        return Observable.fromCallable(() -> {
            AerialTourRequest aerialTourRequest = new AerialTourRequest();
            aerialTourRequest.setImageId(UUID.randomUUID().toString());
            aerialTourRequest.setImageRowId(aerialDbObject.getId());

            String imagePath = aerialDbObject.getImagePath();
            String fileExtension = imagePath.substring(imagePath.lastIndexOf(".") + 1);

            aerialTourRequest.setBlobImageId(aerialTourRequest.getImageId().concat(".").concat(fileExtension));
            aerialTourRequest.populateUri(imagePath);

            // populate exif data
            populateExifData(aerialTourRequest);

            // populate file-size and name data
            populateMetaData(aerialTourRequest);

            // Upload
            CloudBlockBlob blob = azureBlobContainer.getBlockBlobReference(aerialDbObject.getAerialTourId() + "/" + aerialTourRequest.getBlobImageId());


            blob.upload(getApplicationContext().getContentResolver().openInputStream(Uri.parse(imagePath)), aerialTourRequest.getMeta().getFileSize());
            return aerialTourRequest;
        });

    }

    private void populateExifData(AerialTourRequest tourRequest) throws IOException {
        try (InputStream is = getApplicationContext().getContentResolver().openInputStream(tourRequest.getImageUri())) {
            ExifInterface exifInterface = new ExifInterface(is);

            double[] returnedLatLong = exifInterface.getLatLong();
            // If lat/long is null, fall back to the coordinates (0, 0).
            double[] latLong = returnedLatLong != null ? returnedLatLong : new double[2];
            double altitude = exifInterface.getAltitude(0);

            String dateTimeOfImage = "";
            if (exifInterface.hasAttribute(ExifInterface.TAG_DATETIME))
                dateTimeOfImage = exifInterface.getAttribute(ExifInterface.TAG_DATETIME);

            // populate meta info
            AerialImageMetaData meta = new AerialImageMetaData();
            meta.setDateTaken(dateTimeOfImage);
            meta.setLat(latLong[0]);
            meta.setLng(latLong[1]);
            meta.setAlt(altitude);

            tourRequest.setMeta(meta);

            //Add lat and long to determine center
            latitudeSum += meta.getLat();
            longitudeSum += meta.getLng();

        }
    }

    private void populateMetaData(AerialTourRequest request) {
        try (Cursor returnCursor = getApplicationContext().getContentResolver().query(request.getImageUri(), null, null, null, null)) {
            int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
            returnCursor.moveToFirst();
            String size;
            if (!returnCursor.isNull(sizeIndex)) {
                size = returnCursor.getString(sizeIndex);
            } else {
                size = "-1";
            }

            request.getMeta().setFileSize(Long.parseLong(size));
            request.getMeta().setFileName(returnCursor.getString(nameIndex));
        }
    }

    @NonNull
    private ForegroundInfo createForegroundInfo(boolean onGoing, @NonNull String message, @NonNull String aerialTourId) {
        Notification foregroundNotification = WorkerUtils.getNotification(onGoing, CommonConstants.AERIAL_WORK_NOTIFICATION_TITLE, message, aerialTourId, getApplicationContext());
        int notificationId = onGoing ? 1 : 2;
        return new ForegroundInfo(notificationId, foregroundNotification);
    }

    @NonNull
    @Override
    protected Scheduler getBackgroundScheduler() {
        return Schedulers.from(Executors.newFixedThreadPool(10));
    }


}


