package com.huviair.capture.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.Chip;
import com.huviair.capture.R;
import com.huviair.capture.data.model.api.projects.Project;
import com.huviair.capture.ui.projects.ProjectListActivity;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.stream.Collectors;

public class ProjectsAdapter extends RecyclerView.Adapter<ProjectsAdapter.ViewHolder> implements Filterable {

    private final List<Project> projects;
    private List<Project> filteredProjects;

    private final ProjectSelectedListener listener;

    // Filter recycler view
    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String stringToSearch = constraint.toString().trim();

                if (!constraint.equals("")) {
                    filteredProjects = projects.stream().filter(project -> project.getProjectName().toLowerCase().contains(stringToSearch.toLowerCase()))
                            .collect(Collectors.toList());
                } else filteredProjects = projects;

                FilterResults results = new FilterResults();
                results.values = filteredProjects;
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredProjects = (List<Project>) results.values;
                notifyDataSetChanged();
            }
        };
    }

    public interface ProjectSelectedListener {
        void onClick(int position, MaterialCardView selectedCardView);
    }

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final MaterialCardView cardView;
        private final TextView projectName;
        private final TextView location;
        private final Chip projectType;

        public ViewHolder(MaterialCardView view) {
            super(view);
            cardView = view;
            // Define click listener for the ViewHolder's View
            projectName = view.findViewById(R.id.job_name);
            location = view.findViewById(R.id.job_status);
            projectType = view.findViewById(R.id.project_type);

        }


        public TextView getProjectName() {
            return projectName;
        }

        public TextView getLocation() {
            return location;
        }

        public Chip getProjectType() {
            return projectType;
        }
    }


    public ProjectsAdapter(List<Project> dataSet, Context context) {
        this.projects = dataSet;
        this.filteredProjects = dataSet;
        this.listener = (ProjectListActivity) context;
    }

    // Create new views (invoked by the layout manager)
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view, which defines the UI of the list item
        MaterialCardView view = (MaterialCardView) LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.list_view, viewGroup, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        MaterialCardView cardView = viewHolder.cardView;
        viewHolder.getProjectName().setText(filteredProjects.get(position).getProjectName());
        viewHolder.getLocation().setText(filteredProjects.get(position).getLocation());
        viewHolder.getProjectType().setText(filteredProjects.get(position).getType());
        cardView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onClick(position, cardView);
            }
        });
    }

    public List<Project> getCurrentData() {
        return this.filteredProjects;
    }

    @Override
    public int getItemCount() {
        return filteredProjects.size();
    }
}

