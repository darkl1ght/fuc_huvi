import mongoose, { Document, Model } from "mongoose";
import { toJSON, paginate, QueryResult } from "./plugins";

interface IAuditLog {
  entity: string;
  action: string;
  cabinetRefId: string;
  folderRefId: string;
  fileRefId: string;
  additionalInfo: string;
  apiKey: string;
  auditedBy: string;
  paginate: any;
}

interface IAuditLogDocument extends IAuditLog, Document {}
interface IAuditLogModel extends Model<IAuditLogDocument> {
  paginate: (filter: any, options: any) => Promise<QueryResult>;
}
const AuditLogSchema = new mongoose.Schema<IAuditLogDocument>(
  {
    entity: {
      type: String,
      required: true,
      trim: true,
    },
    action: {
      type: String,
      required: true,
      trim: true,
    },
    cabinetRefId: {
      type: String,
      trim: true,
    },
    folderRefId: {
      type: String,
      trim: true,
    },
    fileRefId: {
      type: String,
      trim: true,
    },
    additionalInfo: {
      type: String,
      trim: true,
    },
    apiKey: {
      type: String,
      trim: true,
    },
    auditedBy: {
      type: String,
      trim: true,
      default: "System",
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
AuditLogSchema.plugin(toJSON);
AuditLogSchema.plugin(paginate);

/**
 * @typedef AuditLog
 */
const AuditLog = mongoose.model<IAuditLogDocument, IAuditLogModel>("AuditLog", AuditLogSchema);

export { AuditLog };
