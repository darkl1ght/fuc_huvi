import mongoose, { Document, Model } from "mongoose";
import validator from "validator";
import { toJSON, paginate, QueryResult } from "./plugins";

interface IApp {
  name: string;
  contactName: string;
  apiKey: string;
  contactEmail: string;
  ContactNumber: string;
  supportedFileStorage: any;
}

interface IAppDocument extends IApp, Document {}

interface IAppModel extends Model<IAppDocument> {
  paginate: (filter: any, options: any) => Promise<QueryResult>;
}

const supportedFileStorageSchema = new mongoose.Schema(
  {
    code: String,
    description: String,
    accessKeyId: String,
    accessKeySecret: String,
    serviceAccount: String,
    preferredRegion: String,
    allowedHeaders: Array,
    allowedMethods: Array,
    allowedOrigins: Array,
    exposeHeaders: Array,
    maxAgeSeconds: Number,
    bucketId: String,
  },
  { timestamps: true }
);
const appSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    apiKey: {
      type: String,
      required: true,
      unique: true,
    },
    contactName: {
      type: String,
      required: true,
      trim: true,
    },
    contactEmail: {
      type: String,
      required: true,
      unique: false,
      lowercase: true,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error("Invalid email");
        }
      },
    },
    contactNumber: {
      type: String,
      required: true,
      trim: true,
    },
    supportedFileStorage: [
      { type: supportedFileStorageSchema, default: [] },
    ],
    createdBy: String,
  },
  {
    timestamps: true,
  }
);
supportedFileStorageSchema.plugin(toJSON);
appSchema.plugin(toJSON);
appSchema.plugin(paginate);

const App = mongoose.model<IAppDocument, IAppModel>("App", appSchema);

export { App };
