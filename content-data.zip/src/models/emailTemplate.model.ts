import mongoose from "mongoose";

const emailTemplate = new mongoose.Schema({
  code: String,
  subject: String,
  body: String,
  to: [{ name: String, email: String }],
  cc: [{ name: String, email: String }],
  bcc: [{ name: String, email: String }],
});

const EmailTemplate = mongoose.model("EmailTemplate", emailTemplate);
export { EmailTemplate };
