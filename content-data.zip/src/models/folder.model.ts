import mongoose, { Document, Model } from "mongoose";
import { toJSON, paginate, QueryResult } from "./plugins";

interface IFolder {
  name: string;
  description: string;
  cabinetRefId: string;
  parentFolderRefId: string;
  additionalInfo: string;
  fileCount: number;
  folderCount: number;
  createdBy: string;
  updatedBy: string;
  status: boolean;
  migratedOn: Date;
  migratedCreatedOn: Date;
  migratedUpdatedOn: Date;
  paginate: any;
}

interface IFolderDocument extends IFolder, Document {}
interface IFolderModel extends Model<IFolderDocument> {
  paginate: (filter: any, options: any) => Promise<QueryResult>;
}
const FolderSchema = new mongoose.Schema<IFolderDocument>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      trim: true,
    },
    cabinetRefId: {
      type: String,
      required: true,
      trim: true,
    },
    parentFolderRefId: {
      type: String,
      trim: true,
    },
    additionalInfo: {
      type: String,
      trim: true,
    },
    fileCount: {
      type: Number,
      default: 0,
    },
    folderCount: {
      type: Number,
      default: 0,
    },
    createdBy: {
      type: String,
      trim: true,
    },
    updatedBy: {
      type: String,
      trim: true,
    },
    migratedOn: {
      type: Date,
    },
    migratedCreatedOn: {
      type: Date,
    },
    migratedUpdatedOn: {
      type: Date,
    },
    status: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
FolderSchema.plugin(toJSON, true);
FolderSchema.plugin(paginate);

/**
 * @typedef Folder
 */
const Folder = mongoose.model<IFolderDocument, IFolderModel>(
  "Folder",
  FolderSchema
);

export { Folder };
