import mongoose, { Document, Model } from "mongoose";
import { toJSON, paginate, QueryResult } from "./plugins";

interface ICabinet {
  name: string;
  appId: string;
  permissions: [];
  retentionPolicy: string;
  metadata: [];
  description: string;
  configuration: any;
  supportedFileStorage: any;
  status: boolean;
  additionalInfo: string;
  paginate: any;
}

interface ICabinetDocument extends ICabinet, Document {}
interface ICabinetModel extends Model<ICabinetDocument> {
  paginate: (filter: any, options: any) => Promise<QueryResult>;
}
const supportedFileStorageSchema = new mongoose.Schema(
  {
    code: String,
    description: String,
    accessKeyId: String,
    accessKeySecret: String,
    serviceAccount: String,
    preferredRegion: String,
    allowedHeaders: Array,
    allowedMethods: Array,
    allowedOrigins: Array,
    exposeHeaders: Array,
    maxAgeSeconds: Number,
    bucketId: String,
  },
  { timestamps: true }
);
const configurationSchema = new mongoose.Schema(
  {
    uploadUrlTimeout: Number,
    downloadUrlTimeout: Number,
    enableVersioning: Boolean,
  },
  { timestamps: true }
);
const metadataSchema = new mongoose.Schema(
  {
    metadataId: {
      type: String,
      required: true,
    },
    metadataType: {
      type: String,
      required: true,
    },
    label: {
      type: String,
      required: true,
      trim: true,
    },
    value: String,
    options: [],
    isRequired: {
      type: Boolean,
      default: false,
    },
    sortOrder: Number,
    createdBy: String,
    updatedBy: String,
  },
  { timestamps: true }
);

const CabinetSchema = new mongoose.Schema<ICabinetDocument>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    appId: {
      type: String,
      required: true,
      trim: true,
    },
    permissions: [],
    retentionPolicy: {
      type: String,
      trim: true,
      lowercase: true,
    },
    metadata: [{ type: metadataSchema }],
    description: {
      type: String,
      trim: true,
    },
    configuration: {
      type: configurationSchema,
    },
    supportedFileStorage: { type: supportedFileStorageSchema },
    status: {
      type: Boolean,
      default: true,
    },
    additionalInfo: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
metadataSchema.plugin(toJSON);
supportedFileStorageSchema.plugin(toJSON);
CabinetSchema.plugin(toJSON);
CabinetSchema.plugin(paginate);

/**
 * @typedef Cabinet
 */
const Cabinet = mongoose.model<ICabinetDocument, ICabinetModel>(
  "Cabinet",
  CabinetSchema
);

export { Cabinet };
