import mongoose, { Document, Model } from "mongoose";
import { toJSON, paginate, QueryResult } from "./plugins";

interface IFile {
  name: string;
  fileObjectId: string;

  fileSize: string;
  metadata: any[];
  description: string;
  cabinetRefId: string;
  parentFolderRefId: string;
  fileStorageType: string;
  comments: any[];
  viewUrl: string;
  downloadUrl: string;
  createdBy: string;
  updatedBy: string;
  updatedOn: Date;
  status: string;
  refreshedOn: Date;
  migratedOn: Date;
  migratedCreatedOn: Date;
  MigratedUpdatedOn: Date;
  annotations: any[];
  features: Object;
  versions: any[];
  tagList: string[];
  paginate: any;
}

interface IFileDocument extends IFile, Document {}
interface IFileModel extends Model<IFileDocument> {
  paginate: (filter: any, options: any) => Promise<QueryResult>;
}

const commentSchema = new mongoose.Schema(
  {
    commentId: String,
    body: String,
    createdByName: String,
    createdByEmail: String,
    commentViewedBy: [
      {
        type: String,
      },
    ],
  },
  { timestamps: true }
);
const metadataSchema = new mongoose.Schema(
  {
    metadataId: {
      type: String,
      required: true,
    },
    metadataType: {
      type: String,
      required: true,
    },
    label: {
      type: String,
      required: true,
      trim: true,
    },
    value: String,
    options: [],
    isRequired: {
      type: Boolean,
      default: true,
    },
    createdBy: String,
    updatedBy: String,
  },
  { timestamps: true }
);
const fileVersionSchema = new mongoose.Schema(
  {
    versionName: {
      type: String,
      required: true,
      trim: true,
    },
    versionNumber: {
      type: mongoose.Types.Decimal128,
      required: true,
    },
    versionFileObjectId: {
      type: String,
      required: true,
      trim: true,
    },
    fileSize: String,
    versionBy: {
      type: String,
      required: true,
      trim: true,
    },
    status: {
      type: Boolean,
      default: false,
    },
    createdDatetime: {
      type: Date,
      default: new Date(),
    },
    updatedDatetime: {
      type: Date,
      default: new Date(),
    },
  },
  {
    timestamps: true,
  }
);

const annotationSchema = new mongoose.Schema(
  {
    annotationId: {
      type: String,
      required: true,
    },
    annotationTitle: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    tags: [],
    shape: {},
    createdBy: String,
    updatedBy: String,
  },
  { timestamps: true }
);

const FileSchema = new mongoose.Schema<IFileDocument>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    fileObjectId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    fileSize: String,
    metadata: [{ type: metadataSchema }],
    description: {
      type: String,
      trim: true,
    },
    cabinetRefId: {
      type: String,
      required: true,
      trim: true,
    },
    parentFolderRefId: {
      type: String,
      trim: true,
    },
    fileStorageType: {
      type: String,
      trim: true,
    },
    comments: [
      {
        type: commentSchema,
      },
    ],
    viewUrl: String,
    downloadUrl: String,
    createdBy: {
      type: String,
      trim: true,
    },
    updatedBy: {
      type: String,
      trim: true,
    },
    updatedOn: {
      type: Date,
    },
    refreshedOn: {
      type: Date,
      default: new Date(),
    },
    migratedOn: {
      type: Date,
    },
    migratedCreatedOn: {
      type: Date,
    },
    migratedUpdatedOn: {
      type: Date,
    },
    status: {
      type: String,
      default: "InProgress",
    },
    annotations: [
      {
        type: annotationSchema,
      },
    ],
    features: {
      type: Object,
    },
    versions: [
      {
        type: fileVersionSchema,
      },
    ],
    tagList: [
      {
        type: String,
      },
    ],
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
metadataSchema.plugin(toJSON);
fileVersionSchema.plugin(toJSON, true);
FileSchema.plugin(toJSON, true);
FileSchema.plugin(paginate);

/**
 * @typedef File
 */
const File = mongoose.model<IFileDocument, IFileModel>("File", FileSchema);

export { File };
