import mongoose from "mongoose";

const videoProcessingStatsSchema = new mongoose.Schema(
  {
    fileId: String,
    fileObjectId: String,
    name: String,
    module: String,
    status: {
      type: String,
      default: "New",
    },
    events: [{ type: String }],
    createdBy: String,
    updatedBy: String,
  },
  {
    timestamps: true,
  }
);

const VideoProcessingStats = mongoose.model(
  "VideoProcessingStats",
  videoProcessingStatsSchema
);
export { VideoProcessingStats };
