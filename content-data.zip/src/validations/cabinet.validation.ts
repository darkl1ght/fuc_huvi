import Joi from "joi";
import { objectId } from "./custom.validation";

const createCabinet = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    name: Joi.string().required(),
    description: Joi.string(),
    permissions: Joi.array(),
    retentionPolicy: Joi.string(),
    metadata: Joi.array(),
    configuration: Joi.object().required,
    storageType: Joi.string().required(),
    additionalInfo: Joi.string(),
  }),
};

const getAllCabinetsByAppId = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getCabinetById = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    cabinetId: Joi.string().custom(objectId),
  }),
};

const updateCabinetById = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    cabinetId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    apiKey: Joi.string().required(),
    name: Joi.string(),
    description: Joi.string(),
    permissions: Joi.array(),
    retentionPolicy: Joi.string(),
    metadata: Joi.array(),
    configuration: Joi.object(),
    storageType: Joi.string(),
    additionalInfo: Joi.string(),
  }),
};

const deleteCabinetById = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    cabinetId: Joi.string().custom(objectId),
  }),
};

const constraCompanySetUp = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    companyName: Joi.string().required(),
    storageType: Joi.string().required(),
    companyId: Joi.string().required(),
    permissions: Joi.array(),
    retentionPolicy: Joi.string(),
  }),
};

const getCabinetByModuleAndCompanyId = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    companyId: Joi.string().required(),
    moduleName: Joi.string().required(),
  }),
};
export {
  createCabinet,
  getAllCabinetsByAppId,
  getCabinetById,
  deleteCabinetById,
  updateCabinetById,
  constraCompanySetUp,
  getCabinetByModuleAndCompanyId,
};
