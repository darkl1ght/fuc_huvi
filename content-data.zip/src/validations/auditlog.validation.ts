import Joi from "joi";
import { objectId } from "./custom.validation";

const createAuditLog = {
  body: Joi.object().keys({
    entity: Joi.string().required(),
    action: Joi.string().required(),
    cabinetRefId: Joi.string().required().custom(objectId),
    folderRefId: Joi.string().required().allow(null),
    fileRefId: Joi.string().required().allow(null),
    additionalInfo: Joi.string().required().allow(""),
    apiKey: Joi.string().required(),
    auditedBy: Joi.string().required(),
  }),
};

const updateAuditLog = {
  params: Joi.object().keys({
    auditLogId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    entity: Joi.string(),
    action: Joi.string(),
    cabinetRefId: Joi.string(),
    folderRefId: Joi.string().allow(null),
    fileRefId: Joi.string().allow(null),
    additionalInfo: Joi.string().allow(""),
    apiKey: Joi.string(),
    auditedBy: Joi.string(),
  }),
};

const getAuditLog = {
  params: Joi.object().keys({
    auditLogId: Joi.required().custom(objectId),
  }),
};

const searchAuditLog = {
  params: Joi.object().keys({
    entity: Joi.string(),
    action: Joi.string(),
    cabinetRefId: Joi.string(),
    folderRefId: Joi.string().allow(null),
    fileRefId: Joi.string().allow(null),
    additionalInfo: Joi.string().allow(""),
    apiKey: Joi.string(),
    auditedBy: Joi.string(),
  }),
};

const deleteAuditLog = {
  params: Joi.object().keys({
    auditLogId: Joi.required().custom(objectId),
  }),
};

export { createAuditLog, updateAuditLog, getAuditLog, deleteAuditLog, searchAuditLog };
