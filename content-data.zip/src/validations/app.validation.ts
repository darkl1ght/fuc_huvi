import Joi from "joi";
import { objectId } from "./custom.validation";

const createApp = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    apiKey: Joi.string().required(),
    contactName: Joi.string().required(),
    contactEmail: Joi.string().required().email(),
    contactNumber: Joi.string().required(),
    supportedFileStorage: Joi.array().required(),
  }),
};

const getAllApp = {
  query: Joi.object().keys({
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getApp = {
  params: Joi.object().keys({
    appId: Joi.string().custom(objectId),
  }),
};

const updateApp = {
  params: Joi.object().keys({
    appId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    name: Joi.string(),
    contactName: Joi.string(),
    contactEmail: Joi.string().email(),
    contactNumber: Joi.string(),
    apiKey: Joi.string(),
    supportedFileStorage: Joi.array(),
  }),
};

const deleteApp = {
  params: Joi.object().keys({
    appId: Joi.string().custom(objectId),
  }),
};

export { createApp, getAllApp, getApp, deleteApp, updateApp };
