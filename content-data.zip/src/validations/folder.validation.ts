import Joi from "joi";
import { objectId } from "./custom.validation";

const createFolder = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    name: Joi.string().required(),
    description: Joi.string().required().allow(""),
    cabinetRefId: Joi.string().required(),
    parentFolderRefId: Joi.string().allow(null),
    projectId: Joi.string().required(),
    additionalInfo: Joi.string().allow(null),
    status: Joi.boolean(),
  }),
};
const createFolderByFolderPath = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    folderPath: Joi.string().required(),
    description: Joi.string().required().allow(""),
    cabinetRefId: Joi.string().required(),
    parentFolderRefId: Joi.string().allow(null),
    projectId: Joi.string().required(),
    additionalInfo: Joi.string().allow(null),
    status: Joi.boolean(),
  }),
};
const updateFolder = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    folderId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    name: Joi.string(),
    description: Joi.string().allow(""),
    parentFolderRefId: Joi.string().allow(null),
    projectId: Joi.string().required(),
    cabinetRefId: Joi.string().required(),
    status: Joi.boolean(),
  }),
};

const getFolder = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    folderId: Joi.required().custom(objectId),
  }),
};

const getRootFolders = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    cabinetRefId: Joi.required().custom(objectId),
  }),
};

const getSubFolders = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    parentFolderRefId: Joi.required().custom(objectId),
  }),
};

const deleteFolder = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    folderId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    isSoftDelete: Joi.boolean(),
    projectId: Joi.string().required(),
    cabinetRefId: Joi.string().required(),
  }),
};

const deleteFolderInBulk = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    isSoftDelete: Joi.boolean(),
    projectId: Joi.string().required(),
    cabinetRefId: Joi.string().required(),
    folders: Joi.array().items(
      Joi.object({
        folderId: Joi.string(),
      })
    ),
  }),
};

const getProjectFolder = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    companyId: Joi.string().required(),
    projectId: Joi.string().required(),
    moduleName: Joi.string().required(),
  }),
};

const createProjectFolders = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    companyId: Joi.string().required(),
    projectId: Joi.string().required(),
    projectName: Joi.string().required(),
  }),
};
const getFolderContents = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    parentFolderRefId: Joi.required().custom(objectId),
  }),
};

const getFolderTree = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    parentFolderRefId: Joi.required().custom(objectId),
  }),
};

const getProjectFolderTree = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    companyId: Joi.string().required(),
    projectId: Joi.string().required(),
    moduleName: Joi.string().required(),
  }),
};

const getSurveyImageList = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    companyId: Joi.string().required(),
    projectId: Joi.string().required(),
    surveyId: Joi.string().required(),
    moduleName: Joi.string().required(),
    filterOption: Joi.object().keys({
      isMailObject: Joi.boolean(),
      isOutput: Joi.boolean(),
    }),
  }),
};

const getFilesByPagination = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    sortBy: Joi.string(),
    sortDirection: Joi.number().integer(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    folderCount: Joi.number().integer(),
  }),
  params: Joi.object().keys({
    parentFolderRefId: Joi.required().custom(objectId),
  }),
};

const getFieldIssuesFolderContents = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    projectFolderId: Joi.required().custom(objectId),
    floorId: Joi.string().required(),
  }),
};
const getFilesForFieldIssueFolders = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    projectId: Joi.string().required(),
    clientId: Joi.string().required(),
    moduleName: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fieldIssueIds: Joi.array().items(Joi.string().required()),
  }),
};
export {
  createFolder,
  createFolderByFolderPath,
  updateFolder,
  getFolder,
  deleteFolder,
  deleteFolderInBulk,
  getSubFolders,
  getRootFolders,
  getProjectFolder,
  createProjectFolders,
  getFolderContents,
  getFolderTree,
  getProjectFolderTree,
  getSurveyImageList,
  getFilesByPagination,
  getFieldIssuesFolderContents,
  getFilesForFieldIssueFolders,
};
