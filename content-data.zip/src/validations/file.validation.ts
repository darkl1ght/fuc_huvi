import Joi from "joi";
import { objectId } from "./custom.validation";

const createFile = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    name: Joi.string().required(),
    description: Joi.string().required().allow(""),
    tagList: Joi.array().items(Joi.string()).allow(null),
    metadata: Joi.array(),
    fileObjectId: Joi.string().required(),
    fileSize: Joi.string(),
    cabinetRefId: Joi.required().custom(objectId),
    parentFolderRefId: Joi.required().custom(objectId).allow(null),
  }),
};

const createFileInBulk = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    cabinetRefId: Joi.required().custom(objectId),
    parentFolderRefId: Joi.string().allow(null).custom(objectId),
    files: Joi.array().items(
      Joi.object({
        name: Joi.string().required(),
        description: Joi.string(),
        metadata: Joi.array(),
        fileObjectId: Joi.string().required(),
        fileSize: Joi.string(),
      })
    ),
  }),
};

const updateFileStatus = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    cabinetRefId: Joi.required().custom(objectId),
    parentFolderRefId: Joi.required().custom(objectId).allow(null),
    files: Joi.array().items(
      Joi.object({
        fileObjectId: Joi.string(),
      })
    ),
  }),
};

const updateFile = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fileObjectId: Joi.string().required(),
    name: Joi.string().required(),
    description: Joi.string().optional(),
    metadata: Joi.array().items(
      Joi.object({
        metadataId: Joi.string().required(),
        value: Joi.string().required().allow(""),
      })
    ),
    version: Joi.object({
      versionId: Joi.string().required(),
      versionNumber: Joi.string().required(),
    }),
  }),
};

const updateFileName = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fileObjectId: Joi.string().required(),
    name: Joi.string().required(),
    description: Joi.string(),
  }),
};

const getFile = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
  }),
};

const getFileByObjectId = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileObjectId: Joi.string().required(),
  }),
};
const deleteFile = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    isSoftDelete: Joi.boolean(),
  }),
};

const deleteFileInBulk = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    isSoftDelete: Joi.boolean(),
    parentFolderRefId: Joi.required().custom(objectId).allow(null),
    files: Joi.array().items(
      Joi.object({
        fileId: Joi.string(),
      })
    ),
  }),
};

const deleteFileByObjectId = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileObjectId: Joi.string().required(),
    isSoftDelete: Joi.boolean(),
  }),
};

const getViewNDownloadFileUrl = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileObjectId: Joi.string().required(),
    urlExpiresIn: Joi.number().required(),
  }),
};

const createFileVersionUploadUrl = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    versionFileObjectId: Joi.string().required(),
  }),
};
const updateFileVersion = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    name: Joi.string().required(),
    fileSize: Joi.string().required(),
    versionFileObjectId: Joi.string().required(),
    versionNumber: Joi.string().required(),
  }),
};

const createAnnotation = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    annotation: Joi.object().keys({
      annotationId: Joi.string().required().allow(""),
      annotationTitle: Joi.string().required().allow(""),
      description: Joi.string().required().allow(""),
      tags: Joi.array().items(
        Joi.object({
          id: Joi.string(),
          name: Joi.string(),
        })
      ),
      shape: Joi.object().keys({
        guid: Joi.string(),
        label: Joi.string(),
        type: Joi.string(),
      }),
    }),
    features: Joi.any(),
  }),
};

const updateAnnotation = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    annotation: Joi.object().keys({
      annotationId: Joi.string().required(),
      annotationTitle: Joi.string().required().allow(""),
      description: Joi.string().required().allow(""),
      tags: Joi.array().items(
        Joi.object({
          id: Joi.string(),
          name: Joi.string(),
        })
      ),
      shape: Joi.object().keys({
        guid: Joi.string(),
        label: Joi.string(),
        type: Joi.string(),
      }),
    }),
    features: Joi.any(),
  }),
};

const getAnnotation = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
  }),
};

const removeAnnotation = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    annotationId: Joi.string().required(),
  }),
};

const updateFeatures = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    features: Joi.any(),
  }),
};

const getComments = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
  }),
};

const addComment = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    commentId: Joi.string().required(),
    comment: Joi.string().required(),
    projectName: Joi.string().required(),
    projectUsers: Joi.any(),
  }),
};

const removeComment = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    commentId: Joi.string().required(),
  }),
};

const updateFileTags = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    tagList: Joi.array().items(Joi.string()).allow(null),
  }),
};

const reinitiateVideoProcessing = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    fileObjectId: Joi.string().required(),
    force: Joi.boolean(),
  }),
};

const getFileDownloadUrl = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
    fileObjectId: Joi.string().required(),
    fileName: Joi.string().required(),
  }),
};

const getProjectDataVolume = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  params: Joi.object().keys({
    clientId: Joi.string().required(),
    projectId: Joi.string().required(),
  }),
};

const updateMediaInBulk = {
  query: Joi.object().keys({
    apiKey: Joi.string().required(),
  }),
  body: Joi.object().keys({
    description: Joi.string().required().allow(""),
    tagList: Joi.array().items(Joi.string()).allow(null),
    currentParentFolderRefId: Joi.required().custom(objectId).allow(null),
    targetParentFolderRefId: Joi.required().custom(objectId).allow(null),
    cabinetRefId: Joi.string().required(),
    projectId: Joi.string().required(),
    files: Joi.array().items(
      Joi.object({
        fileId: Joi.string(),
      })
    ),
  }),
};

export {
  createFile,
  createFileInBulk,
  updateFile,
  updateFileStatus,
  getFile,
  getFileByObjectId,
  deleteFile,
  deleteFileByObjectId,
  deleteFileInBulk,
  getViewNDownloadFileUrl,
  createFileVersionUploadUrl,
  reinitiateVideoProcessing,
  createAnnotation,
  updateAnnotation,
  getAnnotation,
  getProjectDataVolume,
  removeAnnotation,
  updateFeatures,
  getComments,
  addComment,
  removeComment,
  updateFileVersion,
  updateFileTags,
  getFileDownloadUrl,
  updateFileName,
  updateMediaInBulk,
};
