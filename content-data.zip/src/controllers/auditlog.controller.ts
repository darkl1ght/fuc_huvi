import { AuditLogService } from "../services";
import { catchAsync } from "../utils/catchAsync";

const createAuditLog = catchAsync(async (req, res) => {
  const result = await AuditLogService.createAuditLog(
    req.body.entity,
    req.body.action,
    req.body.cabinetRefId,
    req.body.folderRefId,
    req.body.fileRefId,
    req.body.additionalInfo,
    req.body.apiKey,
    req.body.auditedBy
  );

  res.send(result);
});

const updateAuditLog = catchAsync(async (req, res) => {
  const result = await AuditLogService.updateAuditLog(req.params.auditLogId, req.body);
  res.send(result);
});

const getAuditLog = catchAsync(async (req, res) => {
  const result = await AuditLogService.getAuditLog(req.params.auditLogId);
  res.send(result);
});

const searchAuditLog = catchAsync(async (req, res) => {
  const result = await AuditLogService.searchAuditLog(req.body);
  res.send(result);
});

const deleteAuditLog = catchAsync(async (req, res) => {
  const result = await AuditLogService.deleteAuditLog(req.params.auditLogId);
  res.send(result);
});

export { createAuditLog, updateAuditLog, getAuditLog, deleteAuditLog, searchAuditLog };
