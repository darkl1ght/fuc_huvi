import { pick } from "../utils/pick";
import { FileService, FolderService } from "../services";
import { catchAsync } from "../utils/catchAsync";

const createFolder = catchAsync(async (req, res) => {
  const result = await FolderService.createFolder(
    req.query.apiKey,
    req.body.name,
    req.body.description,
    req.body.cabinetRefId,
    req.body.parentFolderRefId,
    req.body.projectId,
    req.body.additionalInfo,
    req.body.status,
    req.user
  );

  res.send(result);
});

const createFolderByFolderPath = catchAsync(async (req, res) => {
  const result = await FolderService.createFolderByFolderPath(
    req.query.apiKey,
    req.body.folderPath,
    req.body.description,
    req.body.cabinetRefId,
    req.body.parentFolderRefId,
    req.body.projectId,
    req.body.additionalInfo,
    req.body.status,
    req.user
  );

  res.send(result);
});
const updateFolder = catchAsync(async (req, res) => {
  const result = await FolderService.updateFolder(
    req.query.apiKey,
    req.params.folderId,
    req.body,
    req.user
  );
  res.send(result);
});

const getFolder = catchAsync(async (req, res) => {
  const result = await FolderService.getFolder(
    req.query.apiKey,
    req.params.folderId
  );
  res.send(result);
});

const getRootFolders = catchAsync(async (req, res) => {
  const result = await FolderService.getRootFolders(
    req.query.apiKey,
    req.params.cabinetRefId
  );
  res.send(result);
});

const getSubFolders = catchAsync(async (req, res) => {
  const result = await FolderService.getSubFolders(
    req.query.apiKey,
    req.params.parentFolderRefId
  );
  res.send(result);
});

const deleteFolder = catchAsync(async (req, res) => {
  const result = await FolderService.deleteFolder(
    req.query.apiKey,
    req.params.folderId,
    req.body
  );
  res.send(result);
});

const deleteFolderInBulk = catchAsync(async (req, res) => {
  const result = await FolderService.deleteFolderInBulk(
    req.query.apiKey,
    req.body
  );
  res.send(result);
});

const getProjectFolder = catchAsync(async (req, res) => {
  const result = await FolderService.getProjectFolder(
    req.query.apiKey,
    req.params.companyId,
    req.params.projectId,
    req.params.moduleName
  );
  res.send(result);
});
const createProjectFolders = catchAsync(async (req, res) => {
  const result = await FolderService.createProjectFolders(
    req.query.apiKey,
    req.body.companyId,
    req.body.projectId,
    req.body.projectName,
    req.user
  );

  res.send(result);
});
const getFolderContents = catchAsync(async (req, res) => {
  const result = await FolderService.getFolderContents(
    req.query.apiKey,
    req.params.parentFolderRefId
  );
  res.send(result);
});

const getFolderTree = catchAsync(async (req, res) => {
  const result = await FolderService.getFolderTree(
    req.query.apiKey,
    req.params.parentFolderRefId
  );
  res.send(result);
});

const getProjectFolderTree = catchAsync(async (req, res) => {
  const result = await FolderService.getProjectFolderTree(
    req.query.apiKey,
    req.params.companyId,
    req.params.projectId,
    req.params.moduleName
  );
  res.send(result);
});

const getSurveyImageList = catchAsync(async (req, res) => {
  const result = await FolderService.getSurveyImageList(
    req.query.apiKey,
    req.body.companyId,
    req.body.projectId,
    req.body.surveyId,
    req.body.moduleName,
    req.body.filterOption
  );

  res.send(result);
});

const getFilesByPagination = catchAsync(async (req, res) => {
  const filter = {
    parentFolderRefId: req.params.parentFolderRefId,
  };
  const options = {
    page: req.body.page,
    limit: req.body.limit,
    sort: { [req.body.sortBy]: req.body.sortDirection },
  };
  const result = await FolderService.getFilesByPagination(
    req.query.apiKey,
    req.body.folderCount,
    filter,
    options
  );
  res.send(result);
});

const getFieldIssuesFolderContents = catchAsync(async (req, res) => {
  const result = await FolderService.getFieldIssuesFolderContents(
    req.query.apiKey,
    req.params.projectFolderId,
    req.params.floorId
  );
  res.send(result);
});

const getFilesForFieldIssueFolders = catchAsync(async (req, res) => {
  const result = await FolderService.getFilesForFieldIssueFolders(
    req.query.apiKey,
    req.params.projectId,
    req.params.clientId,
    req.params.moduleName,
    req.body.fieldIssueIds
  );

  res.send(result);
});

export {
  createFolder,
  createFolderByFolderPath,
  updateFolder,
  getFolder,
  deleteFolder,
  deleteFolderInBulk,
  getSubFolders,
  getRootFolders,
  getProjectFolder,
  createProjectFolders,
  getFolderContents,
  getFolderTree,
  getProjectFolderTree,
  getSurveyImageList,
  getFilesByPagination,
  getFieldIssuesFolderContents,
  getFilesForFieldIssueFolders,
};
