import { catchAsync } from "../utils/catchAsync";
import { FileService } from "../services";

const createFile = catchAsync(async (req, res) => {
  const file = await FileService.createFile(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(file);
});

const createFileInBulk = catchAsync(async (req, res) => {
  const files = await FileService.createFileInBulk(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(files);
});

const updateFileStatus = catchAsync(async (req, res) => {
  const file = await FileService.updateFileStatus(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(file);
});

const updateFile = catchAsync(async (req, res) => {
  const file = await FileService.updateFile(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(file);
});

const updateFileName = catchAsync(async (req, res) => {
  const file = await FileService.updateFileName(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(file);
});

const getFile = catchAsync(async (req, res) => {
  const result = await FileService.getFile(req.query.apiKey, req.params.fileId);
  res.send(result);
});

const getFileByObjectId = catchAsync(async (req, res) => {
  const result = await FileService.getFileByObjectId(
    req.query.apiKey,
    req.params.fileObjectId
  );
  res.send(result);
});

const deleteFile = catchAsync(async (req, res) => {
  const result = await FileService.deleteFile(
    req.query.apiKey,
    req.params.fileId,
    req.params.isSoftDelete
  );
  res.send(result);
});

const deleteFileByObjectId = catchAsync(async (req, res) => {
  const result = await FileService.deleteFileByObjectId(
    req.query.apiKey,
    req.params.fileObjectId,
    req.params.isSoftDelete
  );
  res.send(result);
});

const deleteFileInBulk = catchAsync(async (req, res) => {
  const result = await FileService.deleteFileInBulk(req.query.apiKey, req.body);
  res.send(result);
});

const getViewNDownloadFileUrl = catchAsync(async (req, res) => {
  const result = await FileService.getViewNDownloadFileUrl(
    req.query.apiKey,
    req.params.fileObjectId,
    req.params.urlExpiresIn
  );
  res.send(result);
});

const createFileVersionUploadUrl = catchAsync(async (req, res) => {
  const file = await FileService.createFileVersionUploadUrl(
    req.query.apiKey,
    req.body
  );
  res.send(file);
});

const updateFileVersion = catchAsync(async (req, res) => {
  const file = await FileService.updateFileVersion(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(file);
});

const createAnnotation = catchAsync(async (req, res) => {
  const file = await FileService.createAnnotation(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(file);
});
const updateAnnotation = catchAsync(async (req, res) => {
  const file = await FileService.updateAnnotation(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(file);
});
const getAnnotation = catchAsync(async (req, res) => {
  const file = await FileService.getAnnotation(
    req.query.apiKey,
    req.params.fileId
  );
  res.send(file);
});
const getProjectDataVolume = catchAsync(async (req, res) => {
  const file = await FileService.getProjectDataVolume(
    req.query.apiKey,
    req.params.clientId,
    req.params.projectId
  );
  res.send(file);
});
const removeAnnotation = catchAsync(async (req, res) => {
  const file = await FileService.removeAnnotation(
    req.query.apiKey,
    req.params.fileId,
    req.params.annotationId,
    req.user
  );
  res.send(file);
});
const updateFeatures = catchAsync(async (req, res) => {
  const file = await FileService.updateFeatures(
    req.query.apiKey,
    req.params.fileId,
    req.body,
    req.user
  );
  res.send(file);
});
const getComments = catchAsync(async (req, res) => {
  const file = await FileService.getComments(
    req.query.apiKey,
    req.params.fileId
  );
  res.send(file);
});
const addComment = catchAsync(async (req, res) => {
  const file = await FileService.addComment(
    req.query.apiKey,
    req.params.fileId,
    req.body,
    req.user
  );
  res.send(file);
});
const removeComment = catchAsync(async (req, res) => {
  const file = await FileService.removeComment(
    req.query.apiKey,
    req.params.fileId,
    req.params.commentId,
    req.user
  );
  res.send(file);
});

const updateFileTags = catchAsync(async (req, res) => {
  const file = await FileService.updateFileTags(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(file);
});

const reinitiateVideoProcessing = catchAsync(async (req, res) => {
  const file = await FileService.reinitiateVideoProcessing(
    req.query.apiKey,
    req.body.fileObjectId,
    req.body.force,
    req.user
  );
  res.send(file);
});

const getFileDownloadUrl = catchAsync(async (req, res) => {
  const file = await FileService.getVersionDownloadUrl(
    req.query.apiKey,
    req.params.fileId,
    req.params.fileObjectId,
    req.params.fileName
  );
  res.send(file);
});

const updateMediaInBulk = catchAsync(async (req, res) => {
  const result = await FileService.updateMediaInBulk(
    req.query.apiKey,
    req.body,
    req.user
  );
  res.send(result);
});

export {
  createFile,
  createFileInBulk,
  updateFile,
  updateFileStatus,
  getFile,
  getFileByObjectId,
  getProjectDataVolume,
  deleteFile,
  deleteFileInBulk,
  deleteFileByObjectId,
  getViewNDownloadFileUrl,
  createFileVersionUploadUrl,
  createAnnotation,
  updateAnnotation,
  getAnnotation,
  removeAnnotation,
  updateFeatures,
  getComments,
  addComment,
  removeComment,
  updateFileVersion,
  reinitiateVideoProcessing,
  updateFileTags,
  getFileDownloadUrl,
  updateFileName,
  updateMediaInBulk,
};
