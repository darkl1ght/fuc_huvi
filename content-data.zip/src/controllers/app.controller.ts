import httpStatus from "http-status";
import { pick } from "../utils/pick";
import { ApiError } from "../utils/ApiError";
import { catchAsync } from "../utils/catchAsync";
import { AppService } from "../services";

const createApp = catchAsync(async (req, res) => {
  const app = await AppService.createApp(req.body);
  res.send(app);
});

const getAllApp = catchAsync(async (req, res) => {
  const filter = {};
  const options = pick(req.query, ["sortBy", "limit", "page"]);
  const result = await AppService.getAllApp(filter, options);
  res.send(result);
});

const getApp = catchAsync(async (req, res) => {
  const app = await AppService.getAppById(req.params.appId);
  if (!app) {
    throw new ApiError(httpStatus.NOT_FOUND, "App not found");
  }
  res.send(app);
});

const updateApp = catchAsync(async (req, res) => {
  const app = await AppService.updateAppById(req.params.appId, req.body);
  res.send(app);
});

const deleteApp = catchAsync(async (req, res) => {
  const delApp = await AppService.deleteAppById(req.params.appId);
  res.send(delApp);
});

export { createApp, getAllApp, getApp, deleteApp, updateApp };
