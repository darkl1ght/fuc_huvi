import { pick } from "../utils/pick";
import { catchAsync } from "../utils/catchAsync";
import { CabinetService } from "../services";

const createCabinet = catchAsync(async (req, res) => {
  const cabinet = await CabinetService.createCabinet(req.query.apiKey, req.body);
  res.send(cabinet);
});

const getAllCabinetsByAppId = catchAsync(async (req, res) => {
  const options = pick(req.query, ["sortBy", "limit", "page"]);
  const result = await CabinetService.getAllCabinetsByAppId(req.query.apiKey, options);
  res.send(result);
});

const getCabinetById = catchAsync(async (req, res) => {
  const cabinet = await CabinetService.getCabinetById(req.query.apiKey, req.params.cabinetId);
  res.send(cabinet);
});

const updateCabinetById = catchAsync(async (req, res) => {
  const app = await CabinetService.updateCabinetById(req.query.apiKey, req.params.cabinetId, req.body);
  res.send(app);
});

const deleteCabinetById = catchAsync(async (req, res) => {
  const delCabinet = await CabinetService.deleteCabinetById(req.query.apiKey, req.params.cabinetId);
  res.send(delCabinet);
});
const constraCompanySetUp = catchAsync(async (req, res) => {
  const cabinet = await CabinetService.constraCompanySetUp(req.query.apiKey, req.body);
  res.send(cabinet);
});
const getCabinetByModuleAndCompanyId = catchAsync(async (req, res) => {
  const cabinet = await CabinetService.getCabinetByModuleAndCompanyId(
    req.query.apiKey,
    req.params.companyId,
    req.params.moduleName
  );
  res.send(cabinet);
});

export {
  createCabinet,
  getAllCabinetsByAppId,
  getCabinetById,
  updateCabinetById,
  deleteCabinetById,
  constraCompanySetUp,
  getCabinetByModuleAndCompanyId,
};
