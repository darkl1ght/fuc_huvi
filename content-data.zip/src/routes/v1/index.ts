import express from "express";
import { config } from "../../config/config";
import { DocsRoute } from "./docs.route";
import { AppRoute } from "./app.route";
import { CabinetRoute } from "./cabinet.route";
import { FolderRouter } from "./folder.route";
import { AuditLogRouter } from "./auditlog.route";
import { FileRouter } from "./file.route";

const router = express.Router();

const defaultRoutes = [
  {
    path: "/app",
    route: AppRoute,
  },
  {
    path: "/cabinet",
    route: CabinetRoute,
  },
  {
    path: "/folder",
    route: FolderRouter,
  },
  {
    path: "/file",
    route: FileRouter,
  },
  {
    path: "/auditlog",
    route: AuditLogRouter,
  },
];

const devRoutes = [
  // routes available only in development mode
  {
    path: "/docs",
    route: DocsRoute,
  },
];

defaultRoutes.forEach((route) => {
  router.use(route.path, route.route);
});

/* istanbul ignore next */
if (config.env === "development") {
  devRoutes.forEach((route) => {
    router.use(route.path, route.route);
  });
}

/* istanbul ignore next */
router.get("/health", (req, res) => {
  const data = {
    uptime: process.uptime(),
    message: "ok",
    date: new Date(),
  };

  res.status(200).send(data);
});

export { router as routes };
