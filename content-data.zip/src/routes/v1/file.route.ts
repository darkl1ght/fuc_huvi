import express from "express";
import { validate } from "../../middlewares/validate";
import { FileValidation } from "../../validations";
import { FileController } from "../../controllers";
import { getUser } from "../../middlewares/user";

const router = express.Router();

router.post(
  "/create",
  getUser(),
  validate(FileValidation.createFile),
  FileController.createFile
);
router.post(
  "/create/bulk",
  getUser(),
  validate(FileValidation.createFileInBulk),
  FileController.createFileInBulk
);
router.put(
  "/update",
  getUser(),
  validate(FileValidation.updateFile),
  FileController.updateFile
);
router.put(
  "/updateFileName",
  getUser(),
  validate(FileValidation.updateFileName),
  FileController.updateFileName
);
router.put(
  "/updateFileStatus",
  getUser(),
  validate(FileValidation.updateFileStatus),
  FileController.updateFileStatus
);
router.get(
  "/:fileId",
  validate(FileValidation.getFile),
  FileController.getFile
);

router.get(
  "/:fileObjectId/fileObjectId",
  validate(FileValidation.getFileByObjectId),
  FileController.getFileByObjectId
);
router.delete(
  "/:fileId/:isSoftDelete?",
  validate(FileValidation.deleteFile),
  FileController.deleteFile
);
router.put(
  "/delete/bulk",
  validate(FileValidation.deleteFileInBulk),
  FileController.deleteFileInBulk
);
router.delete(
  "/:fileObjectId/:isSoftDelete?/byObjectId",
  validate(FileValidation.deleteFileByObjectId),
  FileController.deleteFileByObjectId
);
router.get(
  "/:fileObjectId/:urlExpiresIn/fileUrl",
  validate(FileValidation.getViewNDownloadFileUrl),
  FileController.getViewNDownloadFileUrl
);

router.post(
  "/createAnnotation",
  getUser(),
  validate(FileValidation.createAnnotation),
  FileController.createAnnotation
);
router.put(
  "/updateAnnotation",
  getUser(),
  validate(FileValidation.updateAnnotation),
  FileController.updateAnnotation
);
router.get(
  "/:fileId/getAnnotation",
  validate(FileValidation.getAnnotation),
  FileController.getAnnotation
);
router.delete(
  "/:fileId/:annotationId/removeAnnotation",
  getUser(),
  validate(FileValidation.removeAnnotation),
  FileController.removeAnnotation
);
router.put(
  "/:fileId/updateFeatures",
  getUser(),
  validate(FileValidation.updateFeatures),
  FileController.updateFeatures
);
router.get(
  "/:fileId/getComments",
  validate(FileValidation.getComments),
  FileController.getComments
);
router.post(
  "/:fileId/addComment",
  getUser(),
  validate(FileValidation.addComment),
  FileController.addComment
);
router.delete(
  "/:fileId/:commentId/removeComment",
  getUser(),
  validate(FileValidation.removeComment),
  FileController.removeComment
);

router.post(
  "/reinitiateVideoProcessing",
  getUser(),
  validate(FileValidation.reinitiateVideoProcessing),
  FileController.reinitiateVideoProcessing
);

router.post(
  "/createFileVersionUploadUrl",
  validate(FileValidation.createFileVersionUploadUrl),
  FileController.createFileVersionUploadUrl
);

router.put(
  "/updateFileVersion",
  getUser(),
  validate(FileValidation.updateFileVersion),
  FileController.updateFileVersion
);
router.put(
  "/updateFileTags",
  getUser(),
  validate(FileValidation.updateFileTags),
  FileController.updateFileTags
);
router.get(
  "/:clientId/:projectId/getProjectDataVolume",
  validate(FileValidation.getProjectDataVolume),
  FileController.getProjectDataVolume
);
router.get(
  "/:fileId/:fileObjectId/:fileName/fileDownloadUrl",
  validate(FileValidation.getFileDownloadUrl),
  FileController.getFileDownloadUrl
);

router.put(
  "/updateMedia/bulk",
  getUser(),
  validate(FileValidation.updateMediaInBulk),
  FileController.updateMediaInBulk
);

export { router as FileRouter };
