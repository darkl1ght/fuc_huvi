import express from "express";
import { validate } from "../../middlewares/validate";
import { AuditLogValidation } from "../../validations";
import { AuditLogController } from "../../controllers";

const router = express.Router();

router.post("/", validate(AuditLogValidation.createAuditLog), AuditLogController.createAuditLog);
router.put("/:auditLogId", validate(AuditLogValidation.updateAuditLog), AuditLogController.updateAuditLog);
router.get("/:auditLogId", validate(AuditLogValidation.getAuditLog), AuditLogController.getAuditLog);
router.post("/search", validate(AuditLogValidation.searchAuditLog), AuditLogController.searchAuditLog);
router.delete("/:auditLogId", validate(AuditLogValidation.deleteAuditLog), AuditLogController.deleteAuditLog);

export { router as AuditLogRouter };
