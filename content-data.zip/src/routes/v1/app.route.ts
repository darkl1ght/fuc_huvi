import { Router } from "express";
import { validate } from "../../middlewares/validate";
import { AppValidation } from "../../validations";
import { AppController } from "../../controllers";
const routes = Router();

routes.post("/create", validate(AppValidation.createApp), AppController.createApp);
routes.get("/getAll", validate(AppValidation.getAllApp), AppController.getAllApp);
routes.get("/:appId", validate(AppValidation.getApp), AppController.getApp);
routes.delete("/:appId", validate(AppValidation.deleteApp), AppController.deleteApp);
routes.put("/:appId", validate(AppValidation.updateApp), AppController.updateApp);
export { routes as AppRoute };
