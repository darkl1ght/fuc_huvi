import express from "express";
import { validate } from "../../middlewares/validate";
import { FolderValidation } from "../../validations";
import { FolderController } from "../../controllers";
import { getUser } from "../../middlewares/user";

const router = express.Router();

router.post(
  "/",
  getUser(),
  validate(FolderValidation.createFolder),
  FolderController.createFolder
);

router.put(
  "/:folderId",
  getUser(),
  validate(FolderValidation.updateFolder),
  FolderController.updateFolder
);
router.get(
  "/:parentFolderRefId/subfolders",
  validate(FolderValidation.getSubFolders),
  FolderController.getSubFolders
);

router.get(
  "/:folderId",
  validate(FolderValidation.getFolder),
  FolderController.getFolder
);
router.get(
  "/:cabinetRefId/root",
  validate(FolderValidation.getRootFolders),
  FolderController.getRootFolders
);
router.put(
  "/:folderId/delete",
  validate(FolderValidation.deleteFolder),
  FolderController.deleteFolder
);

router.put(
  "/delete/bulk",
  validate(FolderValidation.deleteFolderInBulk),
  FolderController.deleteFolderInBulk
);

router.get(
  "/:companyId/:projectId/:moduleName",
  validate(FolderValidation.getProjectFolder),
  FolderController.getProjectFolder
);
router.post(
  "/projectFolders",
  getUser(),
  validate(FolderValidation.createProjectFolders),
  FolderController.createProjectFolders
);
router.get(
  "/:parentFolderRefId/contents",
  validate(FolderValidation.getFolderContents),
  FolderController.getFolderContents
);

router.get(
  "/:parentFolderRefId/tree",
  validate(FolderValidation.getFolderTree),
  FolderController.getFolderTree
);

router.get(
  "/:companyId/:projectId/:moduleName/tree",
  validate(FolderValidation.getProjectFolderTree),
  FolderController.getProjectFolderTree
);

router.post(
  "/getSurveyImageList",
  validate(FolderValidation.getSurveyImageList),
  FolderController.getSurveyImageList
);

router.put(
  "/:parentFolderRefId/paginate",
  validate(FolderValidation.getFilesByPagination),
  FolderController.getFilesByPagination
);

router.get(
  "/:projectFolderId/:floorId/get/fieldIssuesFolderContents",
  validate(FolderValidation.getFieldIssuesFolderContents),
  FolderController.getFieldIssuesFolderContents
);

router.post(
  "/createFoldersByFolderPath",
  getUser(),
  validate(FolderValidation.createFolderByFolderPath),
  FolderController.createFolderByFolderPath
);

router.put(
  "/:clientId/:projectId/:moduleName/getFilesForFieldIssueFolders",
  validate(FolderValidation.getFilesForFieldIssueFolders),
  FolderController.getFilesForFieldIssueFolders
);
export { router as FolderRouter };
