import express from "express";
import { validate } from "../../middlewares/validate";
import { CabinetValidation } from "../../validations";
import { CabinetController } from "../../controllers";

const router = express.Router();

router.post("/create", validate(CabinetValidation.createCabinet), CabinetController.createCabinet);
router.put("/:cabinetId", validate(CabinetValidation.updateCabinetById), CabinetController.updateCabinetById);
router.get("/all", validate(CabinetValidation.getAllCabinetsByAppId), CabinetController.getAllCabinetsByAppId);
router.get("/:cabinetId", validate(CabinetValidation.getCabinetById), CabinetController.getCabinetById);
router.delete("/:cabinetId", validate(CabinetValidation.deleteCabinetById), CabinetController.deleteCabinetById);
router.post("/constraCompanySetUp", validate(CabinetValidation.constraCompanySetUp), CabinetController.constraCompanySetUp);
router.get(
  "/:companyId/:moduleName",
  validate(CabinetValidation.getCabinetByModuleAndCompanyId),
  CabinetController.getCabinetByModuleAndCompanyId
);

export { router as CabinetRoute };
