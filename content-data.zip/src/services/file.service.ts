import httpStatus from "http-status";
import { File, Folder, Message } from "../models";
import { ApiError } from "../utils/ApiError";
import { PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { CabinetService, UtilityService } from "../services";
import { constants } from "../config/constants";
import { isRedisConnected, redisDeleteKey } from "../utils/redisHelper";
import { sendMediaTagEmail } from "../utils/email";
import { VideoProcessingStats } from "../models/videoProcessingStats.model";
import { messagingConstants } from "../config/messaging/messaging-constants";
import { MessageBroker } from "../config/messaging/message-broker";

const createFile = async (apiKey: string, file: any, user: any) => {
  const app = await UtilityService.checkValidAppRequest(apiKey);
  let isConstraApp: boolean = false;
  if (
    !!app &&
    app.name?.trim().toLowerCase() == constants.constra.toLowerCase()
  ) {
    isConstraApp = true;
  }

  file.createdBy = user.email;
  file.updatedBy = user.email;
  file.updatedOn = new Date();
  const cabinet = await UtilityService.getCabinetDetails(file.cabinetRefId);
  const bucketParams = {
    Bucket: cabinet.supportedFileStorage.bucketId,
    Key: isConstraApp
      ? cabinet.name + "/" + cabinet.additionalInfo + "/" + file.fileObjectId
      : file.fileObjectId,
  };
  if (
    cabinet.supportedFileStorage.code.toLowerCase() ==
    constants.s3.toLowerCase()
  ) {
    const s3Client = UtilityService.getS3Client(
      cabinet.supportedFileStorage.preferredRegion,
      cabinet.supportedFileStorage.accessKeyId,
      cabinet.supportedFileStorage.accessKeySecret
    );
    const command = new PutObjectCommand(bucketParams);
    // Create the presigned URL.
    const signedUrl = await getSignedUrl(s3Client, command, {
      expiresIn: 600,
    });

    if (
      file.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.mediaTypeCode.toLowerCase()
      )?.value == constants.file.mediaTypeCode.non360Video_MT10002
    ) {
      const isPublishedCabinetMetadata: any = cabinet.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.isPublished.toLowerCase()
      );
      const videoSourceTypeCabinetMetadata: any = cabinet.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.videoSourceType.toLowerCase()
      );
      const videoSourceIdCabinetMetadata: any = cabinet.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.videoSourceId.toLowerCase()
      );
      const isPublishedMetadata: any = {
        metadataId: isPublishedCabinetMetadata?.metadataId,
        metadataType: isPublishedCabinetMetadata?.metadataType,
        label: constants.file.metadata.media.isPublished,
        value: false,
      };
      const videoSourceTypeMetadata: any = {
        metadataId: videoSourceTypeCabinetMetadata?.metadataId,
        metadataType: videoSourceTypeCabinetMetadata?.metadataType,
        label: constants.file.metadata.media.videoSourceType,
        value: "",
      };
      const videoSourceIdMetadata: any = {
        metadataId: videoSourceIdCabinetMetadata?.metadataId,
        metadataType: videoSourceIdCabinetMetadata?.metadataType,
        label: constants.file.metadata.media.videoSourceId,
        value: "",
      };

      file.metadata.push(
        isPublishedMetadata,
        videoSourceTypeMetadata,
        videoSourceIdMetadata
      );
    }

    const createdFile = await File.create(file);
    return {
      fileObjectId: createdFile.fileObjectId,
      fileId: createdFile.id,
      signedUrl: signedUrl,
      message: constants.file.presignedUrlSuccess,
    };
  } else {
    throw new ApiError(
      httpStatus.NOT_FOUND,
      constants.cabinet.unsupportedCloudConfiguration
    );
  }
};

const getSingleFileSizeInBytes = (file: any) => {
  let temp: number;
  let result: number;
  if (file.fileSize?.includes("MB")) {
    temp = parseFloat(file.fileSize); //Eg: 11 MB => 11
    result = isNaN(temp) ? 0 : temp * Math.pow(1024, 2);
  } else if (file.fileSize?.includes("KB")) {
    temp = parseFloat(file.fileSize);
    result = isNaN(temp) ? 0 : 1024 * temp;
  } else if (file.fileSize?.includes("Bytes")) {
    temp = parseFloat(file.fileSize);
    result = isNaN(temp) ? 0 : temp;
  } else if (file.fileSize?.includes("GB")) {
    temp = parseFloat(file.fileSize);
    result = isNaN(temp) ? 0 : Math.pow(1024, 3) * temp;
  } else if (file.fileSize?.includes("TB")) {
    temp = parseFloat(file.fileSize);
    result = isNaN(temp) ? 0 : Math.pow(1024, 4) * temp;
  } else {
    temp = parseFloat(file.fileSize);
    result = isNaN(temp) ? 0 : temp;
  }
  return result;
};
const getFileAndVersionSizes = (file: any) => {
  if (file.versions?.length > 0) {
    let totVersionsSize: number = 0;
    file.versions.forEach((element) => {
      totVersionsSize = totVersionsSize + getSingleFileSizeInBytes(element);
    });
    if (!totVersionsSize) {
      //some file versions don't have sizes captured
      totVersionsSize = getSingleFileSizeInBytes(file);
    }
    return totVersionsSize;
  } else {
    return getSingleFileSizeInBytes(file);
  }
};
const getRecursiveDataVolume = async (folderId: string) => {
  const folder = await Folder.findOne({
    _id: folderId,
    status: true,
  });
  if (!folder) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.folder.folderNotFound
    );
  }
  const subFolders = await Folder.find({
    parentFolderRefId: folderId,
    status: true,
  });
  const files = await File.find({
    parentFolderRefId: folderId,
    status: constants.file.active,
  });
  let totFileDataInBytes = 0;
  if (files?.length > 0) {
    files.forEach((file) => {
      const fileSize = getFileAndVersionSizes(file);
      totFileDataInBytes = totFileDataInBytes + fileSize;
    });
  }
  if (subFolders?.length > 0) {
    const result = await Promise.all(
      subFolders.map((subFolder) => {
        return new Promise<number>(async (resolve) => {
          resolve(await getRecursiveDataVolume(subFolder.id));
        });
      })
    );
    const total = totFileDataInBytes + result.reduce((x, y) => x + y);
    return total;
  } else {
    return totFileDataInBytes;
  }
};
const getFieldIssueDataVolume = async (cabinet: any, projectId: string) => {
  const moduleRootFolder = await Folder.findOne({
    name: projectId,
    cabinetRefId: cabinet._id,
    parentFolderRefId: undefined,
    status: true,
  });
  if (!moduleRootFolder) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.folder.folderNotFound
    );
  }
  const floorTourFolders = await Folder.find({
    description: "Floor Folder",
    parentFolderRefId: moduleRootFolder.id,
    status: true,
  });
  if (floorTourFolders?.length > 0) {
    const finalSizes = await Promise.all(
      floorTourFolders.map(
        (floorTourFolder) =>
          new Promise<number>(async (resolve) => {
            const fieldIssueFolders = await Folder.find({
              description: "Field Issue Folder",
              parentFolderRefId: floorTourFolder.id,
              status: true,
            });
            if (fieldIssueFolders?.length > 0) {
              const sizes = await Promise.all(
                fieldIssueFolders.map(
                  (fieldIssueFolder) =>
                    new Promise<number>(async (fieldIssueResolve) => {
                      const fieldIssueFiles = await File.find({
                        parentFolderRefId: fieldIssueFolder.id,
                        status: constants.file.active,
                      });
                      if (fieldIssueFiles?.length > 0) {
                        let totSize: number = 0;
                        for (const file of fieldIssueFiles) {
                          totSize += getFileAndVersionSizes(file);
                        }
                        fieldIssueResolve(totSize);
                      } else {
                        fieldIssueResolve(0);
                      }
                    })
                )
              );
              resolve(sizes.reduce((x, y) => x + y));
            } else {
              resolve(0);
            }
          })
      )
    );
    return finalSizes.reduce((x, y) => x + y);
  } else {
    return 0;
  }
};

const getModulewiseDataVolume = async (cabinet: any, projectId: string) => {
  const moduleRootFolder = await Folder.findOne({
    name: projectId,
    cabinetRefId: cabinet._id,
    parentFolderRefId: undefined,
    status: true,
  });
  if (!moduleRootFolder) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.folder.folderNotFound
    );
  }
  const result = await getRecursiveDataVolume(moduleRootFolder.id);
  return { module: cabinet.name, size: parseInt(result.toFixed(0)) };
};

const getProjectDataVolume = async (
  apiKey: string,
  companyId: string,
  projectId: string
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinets = await CabinetService.getCabinetsByCompanyId(
    apiKey,
    companyId
  );
  if (cabinets?.length > 0) {
    const FIELD_ISSUES = "field-issues";
    const sections = cabinets.map((cabinet) => {
      return new Promise<{ module: string; size: number }>(async (resolve) => {
        resolve(await getModulewiseDataVolume(cabinet, projectId));
      });
    });
    sections.push(
      new Promise<{ module: string; size: number }>(async (resolve) => {
        const interiorCabinet = cabinets.find(
          (cabinet) => cabinet.name == constants.moduleName.interior
        );
        if (interiorCabinet) {
          const size = await getFieldIssueDataVolume(
            interiorCabinet,
            projectId
          );
          resolve({ module: FIELD_ISSUES, size });
        } else {
          resolve({ module: FIELD_ISSUES, size: 0 });
        }
      })
    );
    //Separating field issues size from interior
    const result = await Promise.all(sections);
    const interior = result.find(
      (item) => item.module == constants.moduleName.interior
    );
    const interiorSize = interior?.size ?? 0;
    const fieldIssueSize =
      result.find((item) => item.module == FIELD_ISSUES)?.size ?? 0;
    if (interior && interiorSize >= fieldIssueSize) {
      interior.size = interiorSize - fieldIssueSize;
    }
    return result;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.cabinet.cabinetNotFound);
  }
};

const processFile = async (
  bulkFileObj: any,
  cabinet: any,
  s3Client: any,
  file: any,
  user: any,
  isConstraApp: boolean
) => {
  return new Promise(async (resolve) => {
    const bucketParams = {
      Bucket: cabinet.supportedFileStorage.bucketId,
      Key: isConstraApp
        ? cabinet.name + "/" + cabinet.additionalInfo + "/" + file.fileObjectId
        : file.fileObjectId,
    };

    const command = new PutObjectCommand(bucketParams);
    // Create the presigned URL.
    const signedUrl = await getSignedUrl(s3Client, command, {
      expiresIn: 600,
    });
    file.cabinetRefId = bulkFileObj.cabinetRefId;
    file.parentFolderRefId = bulkFileObj.parentFolderRefId;
    file.fileStorageType = cabinet.supportedFileStorage.code;
    file.createdBy = user.email;
    file.updatedBy = user.email;
    file.updatedOn = new Date();
    //Video processing
    if (
      file.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.mediaTypeCode.toLowerCase()
      )?.value == constants.file.mediaTypeCode.non360Video_MT10002
    ) {
      const isPublishedCabinetMetadata: any = cabinet.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.isPublished.toLowerCase()
      );
      const videoSourceTypeCabinetMetadata: any = cabinet.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.videoSourceType.toLowerCase()
      );
      const videoSourceIdCabinetMetadata: any = cabinet.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.videoSourceId.toLowerCase()
      );
      const isPublishedMetadata: any = {
        metadataId: isPublishedCabinetMetadata?.metadataId,
        metadataType: isPublishedCabinetMetadata?.metadataType,
        label: constants.file.metadata.media.isPublished,
        value: false,
      };
      const videoSourceTypeMetadata: any = {
        metadataId: videoSourceTypeCabinetMetadata?.metadataId,
        metadataType: videoSourceTypeCabinetMetadata?.metadataType,
        label: constants.file.metadata.media.videoSourceType,
        value: "",
      };
      const videoSourceIdMetadata: any = {
        metadataId: videoSourceIdCabinetMetadata?.metadataId,
        metadataType: videoSourceIdCabinetMetadata?.metadataType,
        label: constants.file.metadata.media.videoSourceId,
        value: "",
      };

      file.metatada.push(
        isPublishedMetadata,
        videoSourceTypeMetadata,
        videoSourceIdMetadata
      );
    }

    const createdFile = await File.create(file);
    return resolve({
      fileObjectId: createdFile.fileObjectId,
      fileId: createdFile.id,
      signedUrl: signedUrl,
    });
  });
};

const processBulkFiles = async (
  bulkFileObj: any,
  cabinet: any,
  s3Client: any,
  user: any,
  isConstraApp: boolean
) => {
  return bulkFileObj.files.map(async (file) => {
    const prcoessedBulkFile = await processFile(
      bulkFileObj,
      cabinet,
      s3Client,
      file,
      user,
      isConstraApp
    );
    return prcoessedBulkFile;
  });
};

const createFileInBulk = async (
  apiKey: string,
  bulkFileObj: any,
  user: any
) => {
  const app = await UtilityService.checkValidAppRequest(apiKey);
  let isConstraApp: boolean = false;
  if (
    !!app &&
    app.name?.trim().toLowerCase() == constants.constra.toLowerCase()
  ) {
    isConstraApp = true;
  }
  let bulkFilesRes: any[] = [];
  const cabinet = await UtilityService.getCabinetDetails(
    bulkFileObj.cabinetRefId
  );
  if (
    cabinet.supportedFileStorage.code.toLowerCase() ==
    constants.s3.toLowerCase()
  ) {
    const s3Client = UtilityService.getS3Client(
      cabinet.supportedFileStorage.preferredRegion,
      cabinet.supportedFileStorage.accessKeyId,
      cabinet.supportedFileStorage.accessKeySecret
    );
    if (!!bulkFileObj.files && bulkFileObj.files.length > 0) {
      await processBulkFiles(bulkFileObj, cabinet, s3Client, user, isConstraApp)
        .then((v) => Promise.all(v))
        .then((v) => (bulkFilesRes = v))
        .catch((err) => {
          throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
        });
      return {
        files: bulkFilesRes,
        message: constants.file.presignedUrlSuccess,
      };
    }
  } else {
    throw new ApiError(
      httpStatus.NOT_FOUND,
      constants.cabinet.unsupportedCloudConfiguration
    );
  }
};

const generateSignedUrlNUpdateFile = async (
  fileObjectId: string,
  fileName: string,
  bucketId: any,
  bucketKeyPrefix: string,
  s3Client: string,
  createdBy: string,
  user: any,
  urlExpiresIn: number = constants.file.urlExpiresIn
) => {
  return new Promise(async (resolve) => {
    const viewSignedUrl = await generateViewUrl(
      bucketId,
      fileObjectId,
      bucketKeyPrefix,
      s3Client,
      urlExpiresIn
    );
    const downloadSignedUrl = await generateDownloadUrl(
      bucketId,
      fileObjectId,
      bucketKeyPrefix,
      fileName,
      s3Client,
      urlExpiresIn
    );

    const fileInfo = await File.findOne({ fileObjectId: fileObjectId });
    if (!fileInfo)
      throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);

    await File.updateOne(
      { fileObjectId: fileObjectId },
      {
        $set: {
          status: constants.file.active,
          viewUrl: viewSignedUrl,
          downloadUrl: downloadSignedUrl,
          updatedBy: user.email,
          updatedOn: new Date(),
          versions: [
            {
              versionName: fileName,
              versionFileObjectId: fileObjectId,
              versionBy: createdBy,
              fileSize: fileInfo?.fileSize,
              versionNumber: constants.file.defaultFileVersion,
              status: true,
              createdDatetime: new Date(),
              updatedDatetime: new Date(),
            },
          ],
        },
      }
    );

    //Video processing
    if (
      fileInfo.metadata.find(
        (item) =>
          item.label.toLowerCase() ===
          constants.file.metadata.media.mediaTypeCode.toLowerCase()
      )?.value == constants.file.mediaTypeCode.non360Video_MT10002
    ) {
      const cabinet = await UtilityService.getCabinetDetails(
        fileInfo.cabinetRefId
      );

      const stat = await VideoProcessingStats.create({
        fileId: fileInfo.id,
        fileObjectId: fileInfo.fileObjectId,
        name: fileInfo.name,
        module: cabinet.name,
        status: messagingConstants.status.NEW,
        events: [messagingConstants.events.EVENT_PUBLISHING],
        createdBy: user.email,
        updatedBy: user.email,
      });

      const message = new Message(
        messagingConstants.messageType.TYPE_START_VIDEO_PROCESSING,
        {
          fileId: fileInfo.id,
          fileObjectId: fileInfo.fileObjectId,
          name: fileInfo.name,
          module: cabinet.name,
          companyId: cabinet.additionalInfo,
        }
      );

      try {
        const connection = await MessageBroker.getInstance();
        await connection.send(
          messagingConstants.queueNames.VIMEO_UPLOAD_QUEUE,
          message
        );

        await VideoProcessingStats.updateOne(
          {
            fileObjectId: fileInfo.fileObjectId,
          },
          {
            $push: {
              events: messagingConstants.events.EVENT_PUBLISHED,
            },
          }
        );
      } catch (error: any) {
        await VideoProcessingStats.updateOne(
          {
            fileObjectId: fileInfo.fileObjectId,
          },
          {
            $push: {
              events: messagingConstants.events.EVENT_PUBLISH_ERROR,
            },
          }
        );
      }
    }

    return resolve({
      fileObjectId: fileObjectId,
      viewUrl: viewSignedUrl,
      downloadUrl: downloadSignedUrl,
    });
  });
};

const updateBulkFiles = async (
  files: any,
  cabinet: any,
  s3Client: any,
  user: any
) => {
  return files.map(async (file: any) => {
    const fileInfo = await File.findOne({
      $and: [
        { status: { $ne: constants.file.active } },
        { fileObjectId: file.fileObjectId },
      ],
    });

    if (!fileInfo) return null;
    const updatedFiles = await generateSignedUrlNUpdateFile(
      fileInfo.fileObjectId,
      fileInfo.name,
      cabinet.supportedFileStorage.bucketId,
      cabinet.name + "/" + cabinet.additionalInfo + "/",
      s3Client,
      fileInfo.createdBy,
      user
    );
    return updatedFiles;
  });
};

const updateFileStatus = async (
  apiKey: string,
  updateBulkFile: any,
  user: any
) => {
  let bulkFilesRes: any[] = [];
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinet = await UtilityService.getCabinetDetails(
    updateBulkFile.cabinetRefId
  );
  if (!!updateBulkFile.files && updateBulkFile.files.length > 0) {
    const s3Client = UtilityService.getS3Client(
      cabinet.supportedFileStorage.preferredRegion,
      cabinet.supportedFileStorage.accessKeyId,
      cabinet.supportedFileStorage.accessKeySecret
    );
    await updateBulkFiles(updateBulkFile.files, cabinet, s3Client, user)
      .then((v) => Promise.all(v))
      .then((v) => (bulkFilesRes = v))
      .catch((err) => {
        throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
      });
    if (!!updateBulkFile.parentFolderRefId) {
      const totalFiles = await getFilesByFolderId(
        apiKey,
        updateBulkFile.parentFolderRefId
      );
      await Folder.updateOne(
        { _id: updateBulkFile.parentFolderRefId },
        { $set: { fileCount: totalFiles?.length } }
      );
    }
    return bulkFilesRes;
  }
};

const updateFile = async (apiKey: string, file: any, user: any) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const fileInfo = await File.findOne({
    $and: [
      { status: constants.file.active },
      { fileObjectId: file.fileObjectId },
    ],
  });

  if (!fileInfo)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);

  const cabinet = await UtilityService.getCabinetDetails(fileInfo.cabinetRefId);
  const cabinetMetadata: any[] = cabinet.metadata;
  let updatedMetadata: any[] = [];
  const metadataItem: any = {
    options: null,
    isRequired: null,
    metadataId: null,
    metadataType: null,
    label: null,
    value: null,
  };

  if (!!cabinetMetadata && cabinetMetadata.length > 0) {
    cabinetMetadata.forEach((cabMetadata: any) => {
      let payloadMetadata = file.metadata.find(
        (item: any) =>
          item.metadataId.toLowerCase() === cabMetadata.metadataId.toLowerCase()
      );
      let existingMetadata = fileInfo.metadata.find(
        (item: any) =>
          item.metadataId.toLowerCase() === cabMetadata.metadataId.toLowerCase()
      );
      metadataItem.options = cabMetadata.options;
      metadataItem.isRequired = cabMetadata.isRequired;
      metadataItem.metadataId = cabMetadata.metadataId;
      metadataItem.metadataType = cabMetadata.metadataType;
      metadataItem.label = cabMetadata.label;
      metadataItem.value = payloadMetadata
        ? payloadMetadata.value
        : existingMetadata
        ? existingMetadata.value
        : null;
      updatedMetadata.push({ ...metadataItem });
    });
  }

  const urlExpiresIn: number = constants.file.urlExpiresIn;

  const bucketKeyPrefix = cabinet.name + "/" + cabinet.additionalInfo + "/";
  const s3Client = UtilityService.getS3Client(
    cabinet.supportedFileStorage.preferredRegion,
    cabinet.supportedFileStorage.accessKeyId,
    cabinet.supportedFileStorage.accessKeySecret
  );
  let downloadSignedUrl = fileInfo.downloadUrl;

  if (fileInfo.name !== file.name) {
    downloadSignedUrl = await generateDownloadUrl(
      cabinet.supportedFileStorage.bucketId,
      file.fileObjectId,
      bucketKeyPrefix,
      file.name,
      s3Client,
      urlExpiresIn
    );
  }

  await File.updateOne(
    {
      fileObjectId: file.fileObjectId,
    },
    {
      name: file.name,
      description: file.description,
      metadata: updatedMetadata,
      updatedBy: user.email,
      downloadUrl: downloadSignedUrl,
      updatedOn: new Date(),
    }
  );

  await File.updateOne(
    {
      fileObjectId: file.fileObjectId,
      "versions._id": file.version.versionId,
    },
    {
      $set: {
        "versions.$.versionNumber": file.version.versionNumber,
        "versions.$.updatedDatetime": new Date(),
        "versions.$.versionName": file.name,
        "versions.$.versionBy": user.email,
      },
    }
  );

  return {
    message: constants.file.fileUpdated,
  };
};

const reinitiateVideoProcessing = async (
  apiKey: string,
  fileObjectId: string,
  force: boolean,
  user: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const fileInfo = await File.findOne({
    $and: [{ status: constants.file.active }, { fileObjectId: fileObjectId }],
  });

  if (!fileInfo)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);

  let reinitiate: boolean = false;
  let statsExist: boolean = false;

  if (
    fileInfo.metadata.find(
      (item) =>
        item.label.toLowerCase() ===
        constants.file.metadata.media.mediaTypeCode.toLowerCase()
    )?.value == constants.file.mediaTypeCode.non360Video_MT10002
  ) {
    const stats = await VideoProcessingStats.findOne({
      fileObjectId: fileObjectId,
    });

    if (stats) {
      statsExist = true;

      if (
        stats.status.toLowerCase() ===
          messagingConstants.status.NEW.toLowerCase() ||
        stats.status.toLowerCase() ===
          messagingConstants.status.PROCESSING.toLowerCase()
      ) {
        if (force) {
          reinitiate = true;
        } else {
          return {
            message: constants.file.videoProcessingAlreadyInitiated,
          };
        }
      } else if (stats.status == messagingConstants.status.COMPLETED) {
        return {
          message: constants.file.videoProcessingAlreadyCompleted,
        };
      } else {
        //status: Error
        reinitiate = true;
      }
    } else {
      statsExist = false;
      reinitiate = true;
    }
  } else {
    return {
      message: constants.file.cannotProcess,
    };
  }

  if (reinitiate) {
    const cabinet = await UtilityService.getCabinetDetails(
      fileInfo.cabinetRefId
    );

    if (!statsExist) {
      await VideoProcessingStats.create({
        fileId: fileInfo.id,
        fileObjectId: fileObjectId,
        name: fileInfo.name,
        module: cabinet.name,
        status: messagingConstants.status.NEW,
        events: [messagingConstants.events.EVENT_PUBLISHING],
        createdBy: user.email,
        updatedBy: user.email,
      });
    }

    const message = new Message(
      messagingConstants.messageType.TYPE_START_VIDEO_PROCESSING,
      {
        fileId: fileInfo.id,
        fileObjectId: fileObjectId,
        name: fileInfo.name,
        module: cabinet.name,
        companyId: cabinet.additionalInfo,
      }
    );

    try {
      await VideoProcessingStats.updateOne(
        {
          fileObjectId,
        },
        {
          $push: {
            events: messagingConstants.events.EVENT_PUBLISHING,
          },
          $set: {
            status: messagingConstants.status.NEW,
            updatedBy: user.email,
          },
        }
      );

      const connection = await MessageBroker.getInstance();
      await connection.send(
        messagingConstants.queueNames.VIMEO_UPLOAD_QUEUE,
        message
      );

      await VideoProcessingStats.updateOne(
        {
          fileObjectId,
        },
        {
          $push: {
            events: messagingConstants.events.EVENT_PUBLISHED,
          },
          $set: {
            updatedBy: user.email,
          },
        }
      );

      return {
        message: constants.file.videoProcessingInitiated,
      };
    } catch (error: any) {
      await VideoProcessingStats.updateOne(
        {
          fileObjectId,
        },
        {
          $push: {
            events: messagingConstants.events.EVENT_PUBLISH_ERROR,
          },
          $set: {
            updatedBy: user.email,
          },
        }
      );
      return {
        message: constants.file.videoProcessingInitiationFailed,
      };
    }
  }
};

const updateFileName = async (apiKey: string, file: any, user: any) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const fileInfo = await File.findOne({
    $and: [
      { status: constants.file.active },
      { fileObjectId: file.fileObjectId },
    ],
  });

  if (!fileInfo)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);

  const cabinet = await UtilityService.getCabinetDetails(fileInfo.cabinetRefId);
  const urlExpiresIn: number = constants.file.urlExpiresIn;

  const bucketKeyPrefix = cabinet.name + "/" + cabinet.additionalInfo + "/";
  const s3Client = UtilityService.getS3Client(
    cabinet.supportedFileStorage.preferredRegion,
    cabinet.supportedFileStorage.accessKeyId,
    cabinet.supportedFileStorage.accessKeySecret
  );
  let downloadSignedUrl = fileInfo.downloadUrl;

  if (fileInfo.name !== file.name) {
    downloadSignedUrl = await generateDownloadUrl(
      cabinet.supportedFileStorage.bucketId,
      file.fileObjectId,
      bucketKeyPrefix,
      file.name,
      s3Client,
      urlExpiresIn
    );
  }

  await File.updateOne(
    {
      fileObjectId: file.fileObjectId,
    },
    {
      name: file.name,
      description: file.description,
      updatedBy: user.email,
      downloadUrl: downloadSignedUrl,
      updatedOn: new Date(),
    }
  );

  return {
    message: constants.file.fileUpdated,
  };
};

const getFile = async (apiKey: string, fileId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const file = await File.findById(fileId);

  if (file) {
    return file;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
};

const getFileByObjectId = async (apiKey: string, fileObjectId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const file = await File.findOne({ fileObjectId: fileObjectId });
  if (file) {
    return file;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
};

const deleteFile = async (
  apiKey: string,
  fileId: string,
  isSoftDelete: boolean = true
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findById(fileId);
  if (!currentFile)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);

  if (isSoftDelete) {
    const fileSoftDeleted = await File.updateOne(
      { _id: fileId },
      { $set: { status: constants.file.inActive } }
    );

    if (fileSoftDeleted.n > 0) {
      const totalFiles = await getFilesByFolderId(
        apiKey,
        currentFile.parentFolderRefId
      );
      await Folder.updateOne(
        { _id: currentFile.parentFolderRefId },
        { $set: { fileCount: totalFiles?.length } }
      );
      return {
        message: constants.file.fileDeleted,
      };
    } else {
      throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
    }
  } else {
    const file = await File.deleteOne({ _id: fileId });
    if (file.deletedCount && file.deletedCount > 0) {
      const totalFiles = await getFilesByFolderId(
        apiKey,
        currentFile.parentFolderRefId
      );
      await Folder.updateOne(
        { _id: currentFile.parentFolderRefId },
        { $set: { fileCount: totalFiles?.length } }
      );
      return {
        message: constants.file.fileDeleted,
      };
    } else {
      throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
    }
  }
};

const deleteFileByObjectId = async (
  apiKey: string,
  fileObjectId: string,
  isSoftDelete: boolean = true
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({ fileObjectId });
  if (!currentFile)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);

  if (isSoftDelete) {
    const fileSoftDeleted = await File.updateOne(
      { fileObjectId },
      { $set: { status: constants.file.inActive } }
    );

    if (fileSoftDeleted.n > 0) {
      const totalFiles = await getFilesByFolderId(
        apiKey,
        currentFile.parentFolderRefId
      );
      await Folder.updateOne(
        { _id: currentFile.parentFolderRefId },
        { $set: { fileCount: totalFiles?.length } }
      );
      return {
        message: constants.file.fileDeleted,
      };
    } else {
      throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
    }
  } else {
    const file = await File.deleteOne({ fileObjectId: fileObjectId });
    if (file.deletedCount && file.deletedCount > 0) {
      const totalFiles = await getFilesByFolderId(
        apiKey,
        currentFile.parentFolderRefId
      );
      await Folder.updateOne(
        { _id: currentFile.parentFolderRefId },
        { $set: { fileCount: totalFiles?.length } }
      );
      return {
        message: constants.file.fileDeleted,
      };
    } else {
      throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
    }
  }
};

const deleteFilesBulk = async (files: any, isSoftDelete: boolean) => {
  return files.map(async (file) => {
    return new Promise(async (resolve) => {
      if (isSoftDelete) {
        await File.updateOne(
          { _id: file.fileId },
          { $set: { status: constants.file.inActive } }
        );
      } else {
        await File.deleteOne({ _id: file.fileId });
      }

      resolve(file.fileId);
    });
  });
};

const deleteFileInBulk = async (apiKey: string, deleteBulkFile: any) => {
  let bulkFilesRes: any[] = [];
  await UtilityService.checkValidAppRequest(apiKey);

  if (!!deleteBulkFile.files && deleteBulkFile.files.length > 0) {
    await deleteFilesBulk(deleteBulkFile.files, deleteBulkFile.isSoftDelete)
      .then((v) => Promise.all(v))
      .then((v) => (bulkFilesRes = v))
      .catch((err) => {
        throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
      });

    if (!!deleteBulkFile.parentFolderRefId) {
      const totalFiles = await getFilesByFolderId(
        apiKey,
        deleteBulkFile.parentFolderRefId
      );
      await Folder.updateOne(
        { _id: deleteBulkFile.parentFolderRefId },
        { $set: { fileCount: totalFiles?.length } }
      );
    }
  }

  return bulkFilesRes;
};

const getFilesByFolderId = async (
  apiKey: string,
  parentFolderRefId: string
) => {
  await UtilityService.checkValidAppRequest(apiKey);

  const files = await File.find({
    parentFolderRefId: parentFolderRefId,
    status: constants.file.active,
  }).sort({ updatedAt: -1 });
  return files;
};

const getViewNDownloadFileUrl = async (
  apiKey: string,
  fileObjectId: string,
  urlExpiresIn: number = 600
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const file = await File.findOne({ fileObjectId: fileObjectId });
  if (!file) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  const cabinet = await UtilityService.getCabinetDetails(file.cabinetRefId);
  const s3Client = UtilityService.getS3Client(
    cabinet.supportedFileStorage.preferredRegion,
    cabinet.supportedFileStorage.accessKeyId,
    cabinet.supportedFileStorage.accessKeySecret
  );
  const viewNDownloadUrl = await generateViewUrl(
    cabinet.supportedFileStorage.bucketId,
    fileObjectId,
    cabinet.name + "/" + cabinet.additionalInfo + "/",
    s3Client,
    urlExpiresIn
  );
  const downloadUrl = await generateDownloadUrl(
    cabinet.supportedFileStorage.bucketId,
    fileObjectId,
    cabinet.name + "/" + cabinet.additionalInfo + "/",
    file.name,
    s3Client,
    urlExpiresIn
  );

  return {
    fileObjectId: fileObjectId,
    viewUrl: viewNDownloadUrl,
    downloadUrl: downloadUrl,
  };
};
const generateViewUrl = async (
  bucketId: string,
  fileObjectId: string,
  bucketKeyPrefix: string,
  s3Client: any,
  urlExpiresIn: number = 604800
) => {
  const bucketParams = {
    Bucket: bucketId,
    Key: bucketKeyPrefix + fileObjectId,
  };
  const command = new GetObjectCommand(bucketParams);
  // Create the presigned URL.
  const signedUrl = await getSignedUrl(s3Client, command, {
    expiresIn: urlExpiresIn,
  });
  return signedUrl;
};

const generateDownloadUrl = async (
  bucketId: string,
  fileObjectId: string,
  bucketKeyPrefix: string,
  fileName: string,
  s3Client: any,
  urlExpiresIn: number = 604800
) => {
  var contentDisposition = `attachment; filename=${fileName}`;
  const bucketParams = {
    Bucket: bucketId,
    Key: bucketKeyPrefix + fileObjectId,
    ResponseContentDisposition: contentDisposition,
  };
  const command = new GetObjectCommand(bucketParams);
  // Create the presigned URL.
  const signedUrl = await getSignedUrl(s3Client, command, {
    expiresIn: urlExpiresIn,
  });
  return signedUrl;
};

const getFilesByFolderIdAndFilterOptions = async (
  parentFolderRefId: string,
  filterOptions: any
) => {
  const formattedFilteredFiles: any[] = [];
  const filteredFiles = await File.find({
    parentFolderRefId: parentFolderRefId,
    status: constants.file.active,
    $and: [
      {
        metadata: {
          $elemMatch: {
            label: constants.file.surveyMetadata.IsOutput,
            value: (!!filterOptions?.isOutput).toString(),
          },
        },
      },
      {
        metadata: {
          $elemMatch: {
            label: constants.file.surveyMetadata.IsMailObject,
            value: (!!filterOptions?.isMailObject).toString(),
          },
        },
      },
    ],
  });
  const objFile = {
    fileObjectId: "",
    name: "",
    description: "",
    fileSize: "",
    createdBy: "",
    metadata: {
      latitude: "",
      longitude: "",
      altitude: "",
      dateTaken: "",
      IsOutput: "",
      IsMailObject: "",
    },
  };
  if (!!filteredFiles && filteredFiles.length > 0) {
    filteredFiles.forEach((file: any) => {
      (objFile.fileObjectId = file.fileObjectId),
        (objFile.name = file.name),
        (objFile.description = file.description),
        (objFile.fileSize = file.fileSize),
        (objFile.createdBy = file.createdBy);
      if (!!file.metadata && file.metadata.length > 0) {
        file.metadata.forEach((meta: any) => {
          switch (meta.label.toLowerCase()) {
            case constants.file.surveyMetadata.latitude.toLowerCase():
              objFile.metadata.latitude = meta.value;
              break;
            case constants.file.surveyMetadata.longitude.toLowerCase():
              objFile.metadata.longitude = meta.value;
              break;
            case constants.file.surveyMetadata.altitude.toLowerCase():
              objFile.metadata.altitude = meta.value;
              break;
            case constants.file.surveyMetadata.dateTaken.toLowerCase():
              objFile.metadata.dateTaken = meta.value;
              break;
            case constants.file.surveyMetadata.IsOutput.toLowerCase():
              objFile.metadata.IsOutput = meta.value;
              break;
            case constants.file.surveyMetadata.IsMailObject.toLowerCase():
              objFile.metadata.IsMailObject = meta.value;
              break;
          }
        });
      }

      formattedFilteredFiles.push({ ...objFile });
    });
  }
  return formattedFilteredFiles;
};
const createFileVersionUploadUrl = async (apiKey: string, fileVersion: any) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileVersion.fileId,
    status: constants.file.active,
  });
  if (!currentFile)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  const cabinet = await UtilityService.getCabinetDetails(
    currentFile.cabinetRefId
  );

  const bucketKeyPrefix = cabinet.name + "/" + cabinet.additionalInfo + "/";
  const bucketParams = {
    Bucket: cabinet.supportedFileStorage.bucketId,
    Key: bucketKeyPrefix + fileVersion.versionFileObjectId,
  };
  if (
    cabinet.supportedFileStorage.code.toLowerCase() ==
    constants.s3.toLowerCase()
  ) {
    const s3Client = UtilityService.getS3Client(
      cabinet.supportedFileStorage.preferredRegion,
      cabinet.supportedFileStorage.accessKeyId,
      cabinet.supportedFileStorage.accessKeySecret
    );
    const command = new PutObjectCommand(bucketParams);
    // Create the presigned URL.
    const versionUploadUrl = await getSignedUrl(s3Client, command, {
      expiresIn: 600,
    });

    return {
      versionFileObjectId: fileVersion.versionFileObjectId,
      fileId: fileVersion.fileId,
      versionUploadUrl: versionUploadUrl,
    };
  } else {
    throw new ApiError(
      httpStatus.NOT_FOUND,
      constants.cabinet.unsupportedCloudConfiguration
    );
  }
};

const updateFileVersion = async (
  apiKey: string,
  fileVersion: any,
  user: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileVersion.fileId,
    status: constants.file.active,
  });
  if (!currentFile)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  const cabinet = await UtilityService.getCabinetDetails(
    currentFile.cabinetRefId
  );
  const s3Client = UtilityService.getS3Client(
    cabinet.supportedFileStorage.preferredRegion,
    cabinet.supportedFileStorage.accessKeyId,
    cabinet.supportedFileStorage.accessKeySecret
  );
  const viewSignedUrl = await generateViewUrl(
    cabinet.supportedFileStorage.bucketId,
    fileVersion.versionFileObjectId,
    cabinet.name + "/" + cabinet.additionalInfo + "/",
    s3Client,
    constants.file.urlExpiresIn
  );
  const downloadSignedUrl = await generateDownloadUrl(
    cabinet.supportedFileStorage.bucketId,
    fileVersion.versionFileObjectId,
    cabinet.name + "/" + cabinet.additionalInfo + "/",
    fileVersion.name,
    s3Client,
    constants.file.urlExpiresIn
  );

  await File.updateOne(
    { _id: fileVersion.fileId },
    {
      $set: {
        name: fileVersion.name,
        viewUrl: viewSignedUrl,
        downloadUrl: downloadSignedUrl,
        fileObjectId: fileVersion.versionFileObjectId,
        fileSize: fileVersion.fileSize,
        updatedBy: user.email,
        updatedOn: new Date(),
      },
      $push: {
        versions: [
          {
            versionName: fileVersion.name,
            versionFileObjectId: fileVersion.versionFileObjectId,
            versionBy: user.email,
            versionNumber: fileVersion.versionNumber,
            fileSize: fileVersion.fileSize,
            status: true,
            createdDatetime: new Date(),
            updatedDatetime: new Date(),
          },
        ],
      },
    }
  );

  return {
    fileId: fileVersion.fileId,
    fileObjectId: fileVersion.versionFileObjectId,
    viewUrl: viewSignedUrl,
    downloadUrl: downloadSignedUrl,
  };
};

const refreshFilesDaily = async (refreshedDate: Date, limit?: number) => {
  let files = !!limit
    ? await File.find({
        $and: [
          { status: constants.file.active },
          {
            refreshedOn: { $lte: refreshedDate },
          },
        ],
      }).limit(limit)
    : await File.find({
        $and: [
          { status: constants.file.active },
          {
            refreshedOn: { $lte: refreshedDate },
          },
        ],
      });
  console.log("files count : " + files?.length); //added to view cron job details
  return files.map(async (file: any) => {
    return await refreshSignedUrlForFile(file);
  });
};

const refreshSignedUrlForFile = async (
  file: any,
  urlExpiresIn: number = constants.file.urlExpiresIn
) => {
  return new Promise(async (resolve) => {
    const cabinet = await UtilityService.getCabinetDetails(file.cabinetRefId);
    const s3Client = UtilityService.getS3Client(
      cabinet.supportedFileStorage.preferredRegion,
      cabinet.supportedFileStorage.accessKeyId,
      cabinet.supportedFileStorage.accessKeySecret
    );
    const bucketKeyPrefix = cabinet.name + "/" + cabinet.additionalInfo + "/";

    const viewSignedUrl = await generateViewUrl(
      cabinet.supportedFileStorage.bucketId,
      file.fileObjectId,
      bucketKeyPrefix,
      s3Client,
      urlExpiresIn
    );
    const downloadSignedUrl = await generateDownloadUrl(
      cabinet.supportedFileStorage.bucketId,
      file.fileObjectId,
      bucketKeyPrefix,
      file.name,
      s3Client,
      urlExpiresIn
    );
    await File.updateOne(
      { fileObjectId: file.fileObjectId },
      {
        $set: {
          viewUrl: viewSignedUrl,
          downloadUrl: downloadSignedUrl,
          refreshedOn: new Date(),
        },
      }
    );

    return resolve({
      fileObjectId: file.fileObjectId,
      viewUrl: viewSignedUrl,
      downloadUrl: downloadSignedUrl,
    });
  });
};

const createAnnotation = async (apiKey: string, body: any, user: any) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: body.fileId,
    status: constants.file.active,
  });
  if (!currentFile) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  body.annotation.annotationId = body.annotation.shape.guid;
  await File.updateOne(
    { _id: body.fileId },
    {
      $push: {
        annotations: body.annotation,
      },
      $set: {
        features: body.features,
        updatedBy: user.email,
        updatedOn: new Date(),
      },
    }
  );
  await File.updateOne(
    {
      _id: body.fileId,
      "versions.versionFileObjectId": currentFile.fileObjectId,
    },
    {
      $set: {
        "versions.$.updatedDatetime": new Date(),
        "versions.$.versionBy": user.email,
      },
    }
  );
  return {
    message: constants.file.annotationCreated,
  };
};
const updateAnnotation = async (apiKey: string, body: any, user: any) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: body.fileId,
    status: constants.file.active,
  });
  if (!currentFile) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  const currentAnnotation = currentFile.annotations.find(
    (item) => item.annotationId === body.annotation.annotationId
  );
  await File.updateOne(
    {
      _id: body.fileId,
      "annotations.annotationId": body.annotation.annotationId,
    },
    {
      $set: {
        "annotations.$.annotationTitle":
          typeof body.annotation.annotationTitle !== "undefined"
            ? body.annotation.annotationTitle
            : currentAnnotation.annotationTitle,
        "annotations.$.description":
          typeof body.annotation.description !== "undefined"
            ? body.annotation.description
            : currentAnnotation.description,
        "annotations.$.tags":
          typeof body.annotation.tags !== "undefined"
            ? body.annotation.tags
            : currentAnnotation.tags,
        "annotations.$.shape":
          typeof body.annotation.shape !== "undefined"
            ? body.annotation.shape
            : currentAnnotation.shape,
        features: body.features,
        updatedBy: user.email,
      },
    }
  );
  await File.updateOne(
    {
      _id: body.fileId,
      "versions.versionFileObjectId": currentFile.fileObjectId,
    },
    {
      $set: {
        "versions.$.updatedDatetime": new Date(),
        "versions.$.versionBy": user.email,
      },
    }
  );
  return {
    message: constants.file.annotationUpdated,
  };
};
const getAnnotation = async (apiKey: string, fileId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileId,
    status: constants.file.active,
  });
  if (!currentFile) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  return currentFile.annotations;
};
const removeAnnotation = async (
  apiKey: string,
  fileId: string,
  annotationId: string,
  user: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileId,
    status: constants.file.active,
  });
  if (!currentFile) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  await File.updateOne(
    { _id: fileId },
    {
      $set: {
        updatedBy: user.email,
        updatedOn: new Date(),
      },
      $pull: {
        annotations: {
          annotationId,
        },
      },
    }
  );
  await File.updateOne(
    {
      _id: fileId,
      "versions.versionFileObjectId": currentFile.fileObjectId,
    },
    {
      $set: {
        "versions.$.updatedDatetime": new Date(),
        "versions.$.versionBy": user.email,
      },
    }
  );
  return {
    message: constants.file.fileUpdated,
  };
};
const updateFeatures = async (
  apiKey: string,
  fileId: string,
  body: any,
  user: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileId,
    status: constants.file.active,
  });
  if (!currentFile) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  await File.updateOne(
    {
      _id: fileId,
    },
    {
      $set: {
        features: body.features,
        updatedBy: user.email,
        updatedOn: new Date(),
      },
    }
  );
  await File.updateOne(
    {
      _id: body.fileId,
      "versions.versionFileObjectId": currentFile.fileObjectId,
    },
    {
      $set: {
        "versions.$.updatedDatetime": new Date(),
        "versions.$.versionBy": user.email,
      },
    }
  );
  return {
    message: constants.file.featureUpdated,
  };
};
const getComments = async (apiKey: string, fileId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileId,
    status: constants.file.active,
  });
  if (!currentFile) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  return currentFile.comments;
};
const addComment = async (
  apiKey: string,
  fileId: string,
  body: any,
  user: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileId,
    status: constants.file.active,
  });
  if (!currentFile) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  const extractEmails = (text) => {
    return text.match(
      /[A-Z0-9._%+-]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,8}[A-Z]{2,63}/gi
    );
  };
  const emails = extractEmails(body.comment);
  const mailTo: any = [];
  if (emails) {
    const projUsers: any = body.projectUsers;
    for (let email of emails) {
      const user = projUsers.filter((projectUser) => {
        return projectUser.email.toLowerCase() === email.toLowerCase();
      });
      if (user.length > 0) {
        mailTo.push({
          email: user[0].email,
          firstName: user[0].firstName,
          name: `${user[0].firstName} ${user[0].lastName}`,
        });
      }
    }
  }
  const commentObj: any = {};
  commentObj.commentId = body.commentId;
  commentObj.body = body.comment;
  commentObj.createdAt = new Date();
  commentObj.createdByName = user.firstName + " " + user.lastName;
  commentObj.createdByEmail = user.email;
  await File.updateOne(
    { _id: fileId },
    {
      $push: {
        comments: commentObj,
      },
      $set: {
        updatedBy: user.email,
        updatedOn: new Date(),
      },
    }
  );
  await File.updateOne(
    {
      _id: body.fileId,
      "versions.versionFileObjectId": currentFile.fileObjectId,
    },
    {
      $set: {
        "versions.$.updatedDatetime": new Date(),
        "versions.$.versionBy": user.email,
      },
    }
  );
  if (mailTo.length > 0) {
    const [mailSentError, mailSentStatus] = await sendMediaTagEmail(
      mailTo,
      body.projectName,
      body.comment
    );
    if (mailSentError) {
      console.error(constants.file.mediaTagEmailError + ": " + mailSentError);
    }
  }
  return {
    message: constants.file.annotationCreated,
  };
};
const removeComment = async (
  apiKey: string,
  fileId: string,
  commentId: string,
  user: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileId,
    status: constants.file.active,
  });
  if (!currentFile) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  }
  await File.updateOne(
    { _id: fileId },
    {
      $set: {
        updatedBy: user.email,
        updatedOn: new Date(),
      },
      $pull: {
        comments: {
          commentId,
        },
      },
    }
  );
  await File.updateOne(
    {
      _id: fileId,
      "versions.versionFileObjectId": currentFile.fileObjectId,
    },
    {
      $set: {
        "versions.$.updatedDatetime": new Date(),
        "versions.$.versionBy": user.email,
      },
    }
  );
  return {
    message: constants.file.commentRemoved,
  };
};

const updateFileTags = async (apiKey: string, file: any, user: any) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: file.fileId,
    status: constants.file.active,
  });
  if (!currentFile)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);
  await File.updateOne(
    { _id: file.fileId },
    {
      $set: {
        tagList: file.tagList,
        updatedBy: user.email,
        updatedOn: new Date(),
      },
    }
  );
  await File.updateOne(
    {
      _id: file.fileId,
      "versions.versionFileObjectId": currentFile.fileObjectId,
    },
    {
      $set: {
        "versions.$.updatedDatetime": new Date(),
        "versions.$.versionBy": user.email,
      },
    }
  );
  return {
    message: constants.file.fileUpdated,
  };
};

const getFileDownloadUrl = async (
  apiKey: string,
  fileId: string,
  fileObjectId: string,
  fileName: string
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const currentFile = await File.findOne({
    _id: fileId,
    status: constants.file.active,
  });
  if (!currentFile)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);

  const fileVersion = currentFile.versions.find(
    (item) => item.versionFileObjectId == fileObjectId
  );

  if (!fileVersion)
    throw new ApiError(httpStatus.NOT_FOUND, constants.file.fileNotFound);

  const cabinet = await UtilityService.getCabinetDetails(
    currentFile.cabinetRefId
  );
  const s3Client = UtilityService.getS3Client(
    cabinet.supportedFileStorage.preferredRegion,
    cabinet.supportedFileStorage.accessKeyId,
    cabinet.supportedFileStorage.accessKeySecret
  );
  const downloadUrl = await generateDownloadUrl(
    cabinet.supportedFileStorage.bucketId,
    fileObjectId,
    cabinet.name + "/" + cabinet.additionalInfo + "/",
    fileName,
    s3Client,
    constants.file.urlExpiresIn
  );
  const viewUrl = await generateViewUrl(
    cabinet.supportedFileStorage.bucketId,
    fileObjectId,
    cabinet.name + "/" + cabinet.additionalInfo + "/",
    s3Client,
    constants.file.urlExpiresIn
  );
  return {
    fileId,
    fileObjectId,
    downloadUrl,
    viewUrl,
  };
};

const updateMedia = async (body: any, user: any) => {
  return body.files.map(async (file: any) => {
    return new Promise(async (resolve) => {
      const fileInfo = await File.findOne({
        $and: [{ status: constants.file.active }, { _id: file.fileId }],
      });

      if (!fileInfo) return null;

      await File.updateOne(
        { _id: file.fileId },
        {
          $set: {
            parentFolderRefId: body.targetParentFolderRefId,
            description: body.description,
            tagList: body.tagList,
            updatedBy: user.email,
            updatedOn: new Date(),
          },
        }
      );
      resolve(file.fileId);
    });
  });
};

const updateMediaInBulk = async (
  apiKey: string,
  updateFiles: any,
  user: any
) => {
  let updateFileRes: any[] = [];
  let projectFolderTreeCacheKey: string;

  await UtilityService.checkValidAppRequest(apiKey);

  const cabinet = await CabinetService.getCabinetById(
    apiKey,
    updateFiles.cabinetRefId
  );

  if (!cabinet) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.cabinet.cabinetNotFound
    );
  }

  if (!!updateFiles.files && updateFiles.files.length > 0) {
    await updateMedia(updateFiles, user)
      .then((v) => Promise.all(v))
      .then(async (v) => {
        updateFileRes = v;
        projectFolderTreeCacheKey =
          updateFiles.projectId.trim() +
          "_" +
          cabinet.name.trim().toLowerCase() +
          "_" +
          constants.folder.projectFolderTree.toLowerCase();
        isRedisConnected && (await redisDeleteKey(projectFolderTreeCacheKey));
        if (!!updateFiles.targetParentFolderRefId) {
          const totalFiles = await getFilesByFolderId(
            apiKey,
            updateFiles.targetParentFolderRefId
          );
          await Folder.updateOne(
            { _id: updateFiles.targetParentFolderRefId },
            {
              $set: { fileCount: totalFiles?.length },
            }
          );
        }
        if (!!updateFiles.currentParentFolderRefId) {
          const totalFiles = await getFilesByFolderId(
            apiKey,
            updateFiles.currentParentFolderRefId
          );
          await Folder.updateOne(
            { _id: updateFiles.currentParentFolderRefId },
            { $set: { fileCount: totalFiles?.length } }
          );
        }
      })

      .catch((err) => {
        throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
      });
  }
  return updateFileRes;
};
export {
  createFile,
  createFileInBulk,
  updateFile,
  updateFileStatus,
  getFile,
  getFileByObjectId,
  deleteFile,
  deleteFileInBulk,
  deleteFileByObjectId,
  getFilesByFolderId,
  getProjectDataVolume,
  getViewNDownloadFileUrl,
  getFilesByFolderIdAndFilterOptions,
  createFileVersionUploadUrl,
  updateFileVersion,
  createAnnotation,
  updateAnnotation,
  getAnnotation,
  removeAnnotation,
  updateFeatures,
  getComments,
  addComment,
  removeComment,
  refreshFilesDaily,
  reinitiateVideoProcessing,
  updateFileTags,
  getFileDownloadUrl as getVersionDownloadUrl,
  updateFileName,
  updateMediaInBulk,
};
