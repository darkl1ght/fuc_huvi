import { responseCodes } from "../../src/config/responseCodes";
import { AuditLog } from "../models/auditlog.model";

const createAuditLog = async (entity, action, cabinetRefId, folderRefId, fileRefId, additionalInfo, apiKey, auditedBy) => {
  const auditLogDoc = await AuditLog.create({
    entity,
    action,
    cabinetRefId,
    folderRefId,
    fileRefId,
    additionalInfo,
    apiKey,
    auditedBy,
  });

  return { code: responseCodes.SUCCESS, message: "AuditLog created", AuditLog: auditLogDoc };
};

const updateAuditLog = async (auditLogId, body) => {
  const auditLog = await AuditLog.updateOne({ _id: auditLogId }, { $set: body });

  if (auditLog.n > 0) {
    return { code: responseCodes.SUCCESS, message: "AuditLog updated" };
  } else {
    return { code: responseCodes.ERROR, message: "AuditLog update failed" };
  }
};

const getAuditLog = async (auditLogId) => {
  const auditLog = await AuditLog.findById(auditLogId);

  if (auditLog) {
    return { code: responseCodes.SUCCESS, message: "AuditLog found", auditLog };
  } else {
    return { code: responseCodes.NOT_FOUND, message: "AuditLog not found" };
  }
};

const searchAuditLog = async (body) => {
  const auditLog = await AuditLog.find(body);

  if (auditLog.length > 0) {
    return { code: responseCodes.SUCCESS, message: "AuditLog found", auditLog };
  } else {
    return { code: responseCodes.NOT_FOUND, message: "AuditLog not found" };
  }
};

const deleteAuditLog = async (auditLogId) => {
  //TBD: Change to soft delete based on requirement
  const auditLog = await AuditLog.deleteOne({ _id: auditLogId });

  if (auditLog.deletedCount && auditLog.deletedCount > 0) {
    return { code: responseCodes.SUCCESS, message: "AuditLog deleted" };
  } else {
    return { code: responseCodes.NOT_FOUND, message: "AuditLog not found" };
  }
};

export { createAuditLog, updateAuditLog, getAuditLog, deleteAuditLog, searchAuditLog };
