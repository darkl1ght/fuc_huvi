import httpStatus from "http-status";
import {
  isRedisConnected,
  redisGetJson,
  redisSetJson,
} from "../utils/redisHelper";
import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { ApiError } from "../utils/ApiError";
import { App, Cabinet } from "../models";

const getS3Client = (
  preferredRegion: string,
  accesskeyId: string,
  accessKeySecret: string
) => {
  const s3Client = new S3Client({
    region: preferredRegion,
    credentials: {
      accessKeyId: accesskeyId,
      secretAccessKey: accessKeySecret,
    },
  });
  return s3Client;
};
const createConstraFolder = async (
  s3Configuration: any,
  bucketId: string,
  folderName: string,
  prefixPath: string = ""
) => {
  const bucketParams = {
    Bucket: bucketId,
    Key:
      prefixPath?.length > 0
        ? prefixPath + "/" + folderName + "/"
        : folderName + "/",
  };
  const s3Client = getS3Client(
    s3Configuration.preferredRegion,
    s3Configuration.accessKeyId,
    s3Configuration.accessKeySecret
  );
  const command = new PutObjectCommand(bucketParams);
  await s3Client.send(command);
};
const checkValidAppRequest = async (apiKey: string) => {
  const appFromCache = !!isRedisConnected
    ? await redisGetJson(apiKey)
    : null;
  if (!appFromCache) {
    const app = await App.findOne({ apiKey: apiKey });
    await redisSetJson(apiKey, app);
    if (!app) {
      throw new ApiError(httpStatus.NOT_FOUND, "Invalid API Key");
    }
    return app;
  } else {
    return appFromCache;
  }
};

const getCabinetDetails = async (cabinetRefId: string) => {
  const cabinetFromCache = !!isRedisConnected
    ? await redisGetJson(cabinetRefId)
    : null;
  if (!cabinetFromCache) {
    const cabinet = await Cabinet.findOne({ _id: cabinetRefId });
    if (!cabinet) {
      throw new ApiError(httpStatus.NOT_FOUND, "Invalid Cabinet");
    }
    await redisSetJson(cabinetRefId, cabinet);
    return cabinet;
  } else {
    return cabinetFromCache;
  }
};
const getCabinetsByCompanyId = async (companyId: string) => {
  const cabinetsFromCache = !!isRedisConnected
    ? await redisGetJson(companyId)
    : null;
  if (!cabinetsFromCache) {
    const cabinets = await Cabinet.find(
      {
        additionalInfo: companyId?.trim(),
      },
      { supportedFileStorage: 0 }
    );
    await redisSetJson(companyId, cabinets);
    return cabinets;
  } else {
    return cabinetsFromCache;
  }
};
export {
  getS3Client,
  createConstraFolder,
  checkValidAppRequest,
  getCabinetDetails,
  getCabinetsByCompanyId,
};
