import { ApiError } from "../utils/ApiError";
import { Folder, File } from "../models";
import { FileService, UtilityService, CabinetService } from "../services";
import httpStatus from "http-status";
import { constants } from "../config/constants";
import {
  isRedisConnected,
  redisGetJson,
  redisSetJson,
  redisDeleteKey,
} from "../utils/redisHelper";

const createFolder = async (
  apiKey: string,
  name: string,
  description: string,
  cabinetRefId: string,
  parentFolderRefId: string,
  projectId: string,
  additionalInfo: string,
  status: boolean,
  user: any
) => {
  let projectFolderTreeCacheKey: string;
  await UtilityService.checkValidAppRequest(apiKey);

  const cabinet = await CabinetService.getCabinetById(apiKey, cabinetRefId);

  if (!cabinet) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.cabinet.cabinetNotFound
    );
  }

  const folder = await Folder.findOne({
    name,
    cabinetRefId,
    parentFolderRefId,
    status: true,
  });

  if (folder) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.responseCodes.ALREADY_EXISTS +
        ": " +
        constants.folder.folderExists
    );
  }

  const folderDoc = await Folder.create({
    name,
    description,
    cabinetRefId,
    parentFolderRefId,
    additionalInfo,
    status,
    createdBy: user.email,
    updatedBy: user.email,
  });

  await updateFolderCount(parentFolderRefId);

  projectFolderTreeCacheKey =
    projectId.trim() +
    "_" +
    cabinet.name.trim().toLowerCase() +
    "_" +
    constants.folder.projectFolderTree.toLowerCase();

  isRedisConnected && (await redisDeleteKey(projectFolderTreeCacheKey));

  return folderDoc;
};

const updateFolderCount = async (folderId: string) => {
  const folderCount = await Folder.count({
    parentFolderRefId: folderId,
    status: true,
  });
  await Folder.updateOne({ _id: folderId }, { $set: { folderCount } });
  return folderCount;
};
const updateFolderCountByChild = async (childFolderId: string) => {
  const childFolder = await Folder.findOne({
    _id: childFolderId,
  });
  const folderCount =
    childFolder &&
    (await Folder.count({
      parentFolderRefId: childFolder.parentFolderRefId,
      status: true,
    }));
  childFolder &&
    (await Folder.updateOne(
      { _id: childFolder.parentFolderRefId },
      { $set: { folderCount } }
    ));
  return folderCount;
};

const createFolderByFolderPath = async (
  apiKey: string,
  folderPath: string,
  description: string,
  cabinetRefId: string,
  parentFolderRefId: string,
  projectId: string,
  additionalInfo: string,
  status: boolean,
  user: any
) => {
  let projectFolderTreeCacheKey: string;
  await UtilityService.checkValidAppRequest(apiKey);

  const cabinet = await CabinetService.getCabinetById(apiKey, cabinetRefId);
  if (!cabinet) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.cabinet.cabinetNotFound
    );
  }
  let createdFolders: any[] = [];
  let currentFolderId = parentFolderRefId;
  const folderNames = folderPath?.split("/");
  for (const folderName of folderNames) {
    if (createdFolders.length > 0) {
      let currentFolder = createdFolders[createdFolders.length - 1];
      currentFolderId = !!currentFolder ? currentFolder._id : parentFolderRefId;
    }
    const folder = await Folder.findOne({
      name: folderName,
      cabinetRefId,
      parentFolderRefId: currentFolderId,
      status: true,
    });
    let folderDoc: any = null;
    if (folder) {
      createdFolders.push(folder);
    } else {
      folderDoc = await Folder.create({
        name: folderName,
        description,
        cabinetRefId,
        parentFolderRefId: currentFolderId,
        additionalInfo,
        status,
        createdBy: user.email,
        updatedBy: user.email,
      });

      await updateFolderCount(currentFolderId);

      createdFolders.push(folderDoc);
      projectFolderTreeCacheKey =
        projectId.trim() +
        "_" +
        cabinet.name.trim().toLowerCase() +
        "_" +
        constants.folder.projectFolderTree.toLowerCase();

      isRedisConnected && (await redisDeleteKey(projectFolderTreeCacheKey));
    }
  }

  return createdFolders;
};

const updateFolder = async (
  apiKey: string,
  folderId: string,
  body: any,
  user: any
) => {
  let projectFolderTreeCacheKey: string;
  const bodyNew = {
    ...body,
    updatedBy: user.email,
  };
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinet = await CabinetService.getCabinetById(
    apiKey,
    body.cabinetRefId
  );

  if (!cabinet) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.cabinet.cabinetNotFound
    );
  }

  const folderDoc = await Folder.findOne({
    name: bodyNew.name,
    cabinetRefId: bodyNew.cabinetRefId,
    parentFolderRefId: bodyNew.parentFolderRefId,
    status: true,
  });

  if (folderDoc) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.responseCodes.ALREADY_EXISTS +
        ": " +
        constants.folder.folderExists
    );
  }

  delete bodyNew.projectId;
  delete bodyNew.cabinetRefId;

  const folder = await Folder.updateOne({ _id: folderId }, { $set: bodyNew });

  if (folder.n > 0) {
    await updateFolderCountByChild(folderId);
    projectFolderTreeCacheKey =
      body.projectId.trim() +
      "_" +
      cabinet.name.trim().toLowerCase() +
      "_" +
      constants.folder.projectFolderTree.toLowerCase();

    isRedisConnected && (await redisDeleteKey(projectFolderTreeCacheKey));

    return {
      message: constants.folder.folderUpdated,
    };
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
  }
};

const getFolder = async (apiKey: string, folderId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const folder = await Folder.findById(folderId);

  if (folder) {
    return folder;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
  }
};

const getRootFolders = async (apiKey: string, cabinetRefId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const folder = await Folder.find({
    cabinetRefId,
    parentFolderRefId: undefined,
    status: true,
  });

  if (folder.length > 0) {
    return folder;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
  }
};

const getSubFolders = async (apiKey: string, parentFolderRefId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const folders = await Folder.find({
    parentFolderRefId: parentFolderRefId,
    status: true,
  });

  if (folders.length > 0) {
    return folders;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
  }
};

const deleteFolder = async (apiKey: string, folderId: string, body: any) => {
  let projectFolderTreeCacheKey: string;
  await UtilityService.checkValidAppRequest(apiKey);
  let isSoftDelete: boolean = true;

  if ("isSoftDelete" in body) {
    isSoftDelete = body.isSoftDelete;
  }

  const cabinet = await CabinetService.getCabinetById(
    apiKey,
    body.cabinetRefId
  );

  if (!cabinet) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.cabinet.cabinetNotFound
    );
  }

  projectFolderTreeCacheKey =
    body.projectId.trim() +
    "_" +
    cabinet.name.trim().toLowerCase() +
    "_" +
    constants.folder.projectFolderTree.toLowerCase();

  if (isSoftDelete) {
    const folderSoftDeleted = await Folder.updateOne(
      { _id: folderId },
      { $set: { status: false } }
    );

    if (folderSoftDeleted.n > 0) {
      await updateFolderCountByChild(folderId);
      isRedisConnected && (await redisDeleteKey(projectFolderTreeCacheKey));
      return {
        message: constants.folder.folderDeleted,
      };
    } else {
      throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
    }
  } else {
    const folderDoc = await Folder.findOne({
      _id: folderId,
    });
    const parentFolderRefId = folderDoc && folderDoc.parentFolderRefId;
    const folder = await Folder.deleteOne({ id: folderId });

    if (folder.deletedCount && folder.deletedCount > 0) {
      parentFolderRefId && (await updateFolderCount(parentFolderRefId));
      isRedisConnected && (await redisDeleteKey(projectFolderTreeCacheKey));
      return {
        message: constants.folder.folderDeleted,
      };
    } else {
      throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
    }
  }
};

const deleteFoldersBulk = async (folders: any, isSoftDelete: boolean) => {
  return folders.map(async (folder) => {
    return new Promise(async (resolve) => {
      if (isSoftDelete) {
        await Folder.updateOne(
          { _id: folder.folderId },
          { $set: { status: false } }
        );
        await updateFolderCountByChild(folder.folderId);
      } else {
        const folderDoc = await Folder.findOne({
          _id: folder.folderId,
        });
        const parentFolderRefId = folderDoc && folderDoc.parentFolderRefId;
        await Folder.deleteOne({
          id: folder.folderId,
        });
        parentFolderRefId && (await updateFolderCount(parentFolderRefId));
      }

      resolve(folder.folderId);
    });
  });
};

const deleteFolderInBulk = async (apiKey: string, deleteBulkFolder: any) => {
  let bulkFoldersRes: any[] = [];
  let isSoftDelete: boolean = true;
  let projectFolderTreeCacheKey: string;

  await UtilityService.checkValidAppRequest(apiKey);

  if ("isSoftDelete" in deleteBulkFolder) {
    isSoftDelete = deleteBulkFolder.isSoftDelete;
  }

  const cabinet = await CabinetService.getCabinetById(
    apiKey,
    deleteBulkFolder.cabinetRefId
  );

  if (!cabinet) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.cabinet.cabinetNotFound
    );
  }

  if (!!deleteBulkFolder.folders && deleteBulkFolder.folders.length > 0) {
    await deleteFoldersBulk(deleteBulkFolder.folders, isSoftDelete)
      .then((v) => Promise.all(v))
      .then(async (v) => {
        bulkFoldersRes = v;
        //folderCount update handled at deleteFoldersBulk
        projectFolderTreeCacheKey =
          deleteBulkFolder.projectId.trim() +
          "_" +
          cabinet.name.trim().toLowerCase() +
          "_" +
          constants.folder.projectFolderTree.toLowerCase();
        isRedisConnected && (await redisDeleteKey(projectFolderTreeCacheKey));
      })
      .catch((err) => {
        throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
      });
  }

  return bulkFoldersRes;
};

const getProjectFolder = async (
  apiKey: string,
  companyId: string,
  projectId: string,
  moduleName: string
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinet = await CabinetService.getCabinetByModuleAndCompanyId(
    apiKey,
    companyId,
    moduleName
  );
  const folder = await Folder.findOne({
    cabinetRefId: cabinet?.id,
    name: projectId,
    parentFolderRefId: undefined,
    status: true,
  });

  if (!!folder) {
    return { folder: folder, cabinet: cabinet };
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
  }
};

const createProjectFolder = async (
  cabinetRefId: string,
  projectId: string,
  projectName: string,
  user: any
) => {
  const folder = await Folder.findOne({
    name: projectId,
    cabinetRefId: cabinetRefId,
    status: true,
  });
  if (folder) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.folder.folderExists
    );
  }

  const folderDoc = await Folder.create({
    name: projectId,
    description: projectName,
    cabinetRefId: cabinetRefId,
    parentFolderRefId: null,
    additionalInfo: projectId,
    status: true,
    createdBy: user.email,
    updatedBy: user.email,
  });
  return folderDoc;
};

const createProjectFoldersForCabinet = async (
  cabinets: any[],
  projectId: string,
  projectName: string,
  user: any
) => {
  return cabinets.map(async (cabinet) => {
    const createdFolders = await createProjectFolder(
      cabinet.id,
      projectId,
      projectName,
      user
    );
    return createdFolders;
  });
};

const createProjectFolders = async (
  apiKey: string,
  companyId: string,
  projectId: string,
  projectName: string,
  user: any
) => {
  let bulkFolderRes: any[] = [];
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinets = await UtilityService.getCabinetsByCompanyId(companyId);
  if (!!cabinets && cabinets.length > 0) {
    await createProjectFoldersForCabinet(cabinets, projectId, projectName, user)
      .then((v) => Promise.all(v))
      .then((v) => (bulkFolderRes = v))
      .catch((err) => {
        throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
      });

    if (bulkFolderRes.length > 0) {
      return {
        message: constants.folder.projectFolderSuccess,
      };
    } else {
      throw new ApiError(
        httpStatus.INTERNAL_SERVER_ERROR,
        constants.folder.folderExists
      );
    }
  }
};
const getFolderContents = async (apiKey: string, parentFolderRefId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const files = await FileService.getFilesByFolderId(apiKey, parentFolderRefId);
  const folders = await Folder.find({
    parentFolderRefId: parentFolderRefId,
    status: true,
  }).sort({ updatedAt: -1 });

  return { folders: folders, files: files };
};

const getChildFolders = async (folderId: string) => {
  const folders = await Folder.find({
    parentFolderRefId: folderId,
    status: true,
  });

  if (!!folders && folders.length === 0) {
    return [
      new Promise(async (resolve) => {
        resolve(null);
      }),
    ];
  }

  return folders.map(async (f) => {
    return new Promise(async (resolve) => {
      const data = await getRecursiveFolders(f.id);
      resolve(data);
    });
  });
};

const getRecursiveFolders = async (folderId: string) => {
  let foldersRes: any[] = [];

  const folder = await Folder.findOne({
    _id: folderId,
    status: true,
  });

  if (!folder) {
    throw new ApiError(
      httpStatus.INTERNAL_SERVER_ERROR,
      constants.folder.folderNotFound
    );
  }

  await getChildFolders(folder.id)
    .then((v) => Promise.all(v))
    .then((v) => (foldersRes = v))
    .catch((err) => {
      throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
    });

  if (foldersRes.length === 1 && foldersRes[0] === null) {
    foldersRes = [];
  }

  return {
    id: folder.id,
    name: folder.name,
    parentFolderRefId: folder.parentFolderRefId,
    subFolders: foldersRes,
  };
};

const getFolderTree = async (apiKey: string, parentFolderRefId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const result = await getRecursiveFolders(parentFolderRefId);
  return result;
};

const getProjectFolderTree = async (
  apiKey: string,
  companyId: string,
  projectId: string,
  moduleName: string
) => {
  const projectFolderTreeCacheKey =
    projectId.trim() +
    "_" +
    moduleName?.trim().toLowerCase() +
    "_" +
    constants.folder.projectFolderTree.toLowerCase();
  await UtilityService.checkValidAppRequest(apiKey);
  const projectFolderTreeFromCache = !!isRedisConnected
    ? await redisGetJson(projectFolderTreeCacheKey)
    : null;

  if (!projectFolderTreeFromCache) {
    const cabinet = await CabinetService.getCabinetByModuleAndCompanyId(
      apiKey,
      companyId,
      moduleName
    );
    const folder = await Folder.findOne({
      cabinetRefId: cabinet?.id,
      name: projectId,
      parentFolderRefId: undefined,
      status: true,
    });

    if (!!folder) {
      const projectFolderTree = await getFolderTree(apiKey, folder.id);
      !!isRedisConnected &&
        (await redisSetJson(projectFolderTreeCacheKey, projectFolderTree));
      return projectFolderTree;
    } else {
      throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
    }
  } else {
    return projectFolderTreeFromCache;
  }
};

const getSurveyImageList = async (
  apiKey: string,
  companyId: string,
  projectId: string,
  surveyId: string,
  moduleName: string,
  filterOption: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinet = await CabinetService.getCabinetByModuleAndCompanyId(
    apiKey,
    companyId,
    moduleName
  );
  const projectFolder = await Folder.findOne({
    cabinetRefId: cabinet?.id,
    name: projectId,
    status: true,
  });
  const surveyFolder = await Folder.findOne({
    cabinetRefId: cabinet?.id,
    name: surveyId,
    parentFolderRefId: projectFolder?.id,
    status: true,
  });
  const files = await FileService.getFilesByFolderIdAndFilterOptions(
    surveyFolder?.id,
    filterOption
  );

  return files;
};

const getFilesByPagination = async (
  apiKey: string,
  folderCount: number,
  filter: any,
  options: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const limit = options.limit;
  const page = options.page;
  const sort = { updatedAt: -1 };
  const fileFilter = {
    parentFolderRefId: filter.parentFolderRefId,
    status: constants.file.active,
  };
  const folderFilter = {
    parentFolderRefId: filter.parentFolderRefId,
    status: true,
  };

  if (page == 1) {
    const folders = await Folder.find(folderFilter)
      .sort(sort)
      .limit(limit)
      .exec();
    const totalFolderCount = await Folder.count(folderFilter);
    const totalFileCount = await File.count(fileFilter);

    if (!!folders && folders.length == limit) {
      return {
        folders,
        files: [],
        totalFolderCount,
        totalFileCount,
      };
    } else {
      const files = await File.find(fileFilter)
        .sort(sort)
        .limit(limit - folders.length)
        .exec();
      return { folders, files, totalFolderCount, totalFileCount };
    }
  } else {
    //page > 1
    const remainder = folderCount % limit;

    if (remainder > 0) {
      const skip = (page - 1) * limit - folderCount;
      const files = await File.find(fileFilter)
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .exec();
      return { folders: [], files };
    } else {
      //No remainder
      const adjacent = folderCount / limit + 1;

      if (page == adjacent) {
        const folders = await Folder.find(folderFilter)
          .sort(sort)
          .skip((page - 1) * limit)
          .limit(limit)
          .exec();

        if (!!folders && folders.length == limit) {
          return {
            folders,
            files: [],
          };
        } else {
          const files = await File.find(fileFilter)
            .sort(sort)
            .skip(folders.length)
            .limit(limit - folders.length)
            .exec();
          return { folders, files };
        }
      } else {
        //Not adjacent
        const skip = (page - 1) * limit - folderCount;
        const files = await File.find(fileFilter)
          .sort(sort)
          .skip(skip)
          .limit(limit)
          .exec();
        return { folders: [], files };
      }
    }
  }
};

const getFieldIssueFiles = async (fieldIssueFolders: any) => {
  return fieldIssueFolders.map(async (folder: any) => {
    return new Promise(async (resolve) => {
      const files = await File.find({
        parentFolderRefId: folder.id,
        status: constants.file.active,
      }).sort({ updatedAt: -1 });

      if (!files) return null;
      resolve({ folder, files });
    });
  });
};

const getFieldIssuesFolderContents = async (
  apiKey: string,
  projectFolderId: string,
  floorId: string
) => {
  await UtilityService.checkValidAppRequest(apiKey);

  const floorFolder = await Folder.findOne({
    name: floorId,
    parentFolderRefId: projectFolderId,
    status: true,
  });

  if (!floorFolder) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.folder.folderNotFound);
  }

  const fieldIssueFolders = await Folder.find({
    parentFolderRefId: floorFolder.id,
    status: true,
  }).sort({ updatedAt: -1 });

  let resFieldIssueFolders: any[] = [];

  if (fieldIssueFolders.length > 0) {
    await getFieldIssueFiles(fieldIssueFolders)
      .then((v) => Promise.all(v))
      .then((v) => (resFieldIssueFolders = v))
      .catch((err) => {
        throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
      });
  }

  return {
    floorId,
    fieldIssueFolders: resFieldIssueFolders,
  };
};

const getFilesForFieldIssueFolders = async (
  apiKey: string,
  projectId: string,
  clientId: string,
  moduleName: string,
  fieldIssueIds: string[]
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinet = await CabinetService.getCabinetByModuleAndCompanyId(
    apiKey,
    clientId,
    moduleName
  );
  const projectFolder = await Folder.findOne({
    cabinetRefId: cabinet?.id,
    name: projectId,
    status: true,
  });

  const fieldIssueFolders = await Folder.find({
    cabinetRefId: cabinet?.id,
    status: true,
    name: { $in: fieldIssueIds },
  });
  let resFieldIssueFiles: any[] = [];

  if (!!projectFolder && fieldIssueFolders.length > 0) {
    await getFieldIssueFiles(fieldIssueFolders)
      .then((v) => Promise.all(v))
      .then((v) => (resFieldIssueFiles = v))
      .catch((err) => {
        throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, err);
      });
  }
  return { resFieldIssueFiles };
};

export {
  createFolder,
  createFolderByFolderPath,
  updateFolder,
  getFolder,
  deleteFolder,
  deleteFolderInBulk,
  getSubFolders,
  getRootFolders,
  getProjectFolder,
  createProjectFolders,
  getFolderContents,
  getFolderTree,
  getProjectFolderTree,
  getSurveyImageList,
  getFilesByPagination,
  getFieldIssuesFolderContents,
  getFilesForFieldIssueFolders,
};
