import httpStatus from "http-status";
import { Cabinet } from "../models";
import { ApiError } from "../utils/ApiError";
import { v4 as uuidv4 } from "uuid";
import { config } from "../config/config";
import { constants } from "../config/constants";
import { UtilityService } from "../services";
import {
  isRedisConnected,
  redisGetJson,
  redisSetJson,
} from "../utils/redisHelper";

const createCabinet = async (
  apiKey: string,
  cabinet: any,
  isConstra: boolean = false
) => {
  const app = await UtilityService.checkValidAppRequest(apiKey);
  cabinet.appId = app.id;
  const configurtion = app.supportedFileStorage.filter((obj) => {
    return obj.code.toLowerCase() === cabinet.storageType.toLowerCase();
  });

  if (configurtion.length <= 0) {
    throw new ApiError(
      httpStatus.NOT_FOUND,
      constants.cabinet.invalidStorageType
    );
  }
  cabinet.supportedFileStorage = configurtion[0];
  if (isConstra) {
    await UtilityService.createConstraFolder(
      cabinet.supportedFileStorage,
      cabinet.supportedFileStorage.bucketId,
      cabinet.additionalInfo,
      cabinet.name
    );
  }
  const cabinetCreated = await Cabinet.create(cabinet);
  return cabinetCreated;
};

const getAllCabinetsByAppId = async (apiKey: string, options: any) => {
  const app = await UtilityService.checkValidAppRequest(apiKey);
  const cabinets = await Cabinet.find(
    { appId: app.id, status: true },
    { supportedFileStorage: 0 }
  );
  return cabinets;
};

const getCabinetById = async (apiKey: string, id: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinet = await Cabinet.findById(id, {
    supportedFileStorage: 0,
  });
  return cabinet;
};

const updateCabinetById = async (
  apiKey: string,
  cabinetId: string,
  updateBody: any
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinet = await getCabinetById(apiKey, cabinetId);
  if (!cabinet) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.cabinet.cabinetNotFound);
  }

  Object.assign(cabinet, updateBody);
  const cabinetUpdated = await Cabinet.updateOne(
    { _id: cabinetId },
    { $set: cabinet }
  );

  if (cabinetUpdated.n > 0) {
    return cabinet;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.cabinet.cabinetNotFound);
  }
};

const deleteCabinetById = async (apiKey: string, cabinetId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinet = await Cabinet.deleteOne({ id: cabinetId });

  if (cabinet.deletedCount && cabinet.deletedCount > 0) {
    return {
      message: constants.cabinet.cabinetDeleted,
    };
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.cabinet.cabinetNotFound);
  }
};

const constraCompanySetUp = async (apiKey: string, companySetupInfo) => {
  const app = await UtilityService.checkValidAppRequest(apiKey);

  if (
    !app ||
    (!!app && app.name?.trim().toLocaleLowerCase() !== constants.constra)
  ) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.invalidApiKey);
  }
  const mediaCabinet = {
    apiKey: apiKey,
    name: constants.moduleName.media,
    storageType: !!companySetupInfo.storageType
      ? companySetupInfo.storageType
      : constants.s3,
    retentionPolicy: !!companySetupInfo.retentionPolicy
      ? companySetupInfo.retentionPolicy
      : constants.retentionPolicy,
    description: companySetupInfo.companyName,
    additionalInfo: companySetupInfo.companyId,
    metadata: await generateMetadataForCabinet(config.mediaMetadata),
  };

  const mediaCabinetResponse = await createCabinet(apiKey, mediaCabinet, true);

  const libraryCabinet = {
    apiKey: companySetupInfo.apiKey,
    name: constants.moduleName.library,
    storageType: !!companySetupInfo.storageType
      ? companySetupInfo.storageType
      : constants.s3,
    retentionPolicy: !!companySetupInfo.retentionPolicy
      ? companySetupInfo.retentionPolicy
      : constants.retentionPolicy,
    description: companySetupInfo.companyName,
    additionalInfo: companySetupInfo.companyId,
    metadata: await generateMetadataForCabinet(config.libraryMetadata),
  };
  const libraryCabinetResponse = await createCabinet(
    apiKey,
    libraryCabinet,
    true
  );
  const rfiCabinet = {
    apiKey: companySetupInfo.apiKey,
    name: constants.moduleName.rfi,
    storageType: !!companySetupInfo.storageType
      ? companySetupInfo.storageType
      : constants.s3,
    retentionPolicy: !!companySetupInfo.retentionPolicy
      ? companySetupInfo.retentionPolicy
      : constants.retentionPolicy,
    description: companySetupInfo.companyName,
    additionalInfo: companySetupInfo.companyId,
    metadata: await generateMetadataForCabinet(config.rfiMetadata),
  };
  const rfiCabinetResponse = await createCabinet(apiKey, rfiCabinet, true);
  const interiorCabinet = {
    apiKey: companySetupInfo.apiKey,
    name: constants.moduleName.interior,
    storageType: !!companySetupInfo.storageType
      ? companySetupInfo.storageType
      : constants.s3,
    retentionPolicy: !!companySetupInfo.retentionPolicy
      ? companySetupInfo.retentionPolicy
      : constants.retentionPolicy,
    description: companySetupInfo.companyName,
    additionalInfo: companySetupInfo.companyId,
    metadata: await generateMetadataForCabinet(config.interiorMetadata),
  };
  const interiorCabinetResponse = await createCabinet(
    apiKey,
    interiorCabinet,
    true
  );
  const exterionCabinet = {
    apiKey: companySetupInfo.apiKey,
    name: constants.moduleName.exterior,
    storageType: !!companySetupInfo.storageType
      ? companySetupInfo.storageType
      : constants.s3,
    retentionPolicy: !!companySetupInfo.retentionPolicy
      ? companySetupInfo.retentionPolicy
      : constants.retentionPolicy,
    description: companySetupInfo.companyName,
    additionalInfo: companySetupInfo.companyId,
    metadata: await generateMetadataForCabinet(),
  };

  const exterionCabinetResponse = await createCabinet(
    apiKey,
    exterionCabinet,
    true
  );
  return { message: constants.cabinet.companySetUpSuccess };
};
const getCabinetByModuleAndCompanyId = async (
  apiKey: string,
  companyId: string,
  moduleName: string
) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinetByModuleNameFromCache = !!isRedisConnected
    ? await redisGetJson(
        companyId.trim() + "_" + moduleName?.trim().toLowerCase()
      )
    : null;
  if (!cabinetByModuleNameFromCache) {
    const cabinet = await Cabinet.findOne(
      {
        additionalInfo: companyId?.trim(),
        name: moduleName?.trim().toLowerCase(),
      },
      { supportedFileStorage: 0 }
    );
    await redisSetJson(
      companyId.trim() + "_" + moduleName?.trim().toLowerCase(),
      cabinet
    );
    return cabinet;
  } else {
    return cabinetByModuleNameFromCache;
  }
};

const getCabinetsByCompanyId = async (apiKey: string, companyId: string) => {
  await UtilityService.checkValidAppRequest(apiKey);
  const cabinets = await Cabinet.find({
    additionalInfo: companyId?.trim(),
    status: true,
  });
  return cabinets;
};

const generateMetadataForCabinet = async (metadataString = "") => {
  const metadata: any[] = [];
  let sortOrder: number = 1;
  if (!!metadataString && metadataString.length > 0) {
    metadataString?.split(",").forEach((individualMetaString) => {
      metadata.push({
        metadataId: uuidv4(),
        label: individualMetaString.split("|")[0],
        metadataType: individualMetaString.split("|")[1],
        options:
          individualMetaString.split("|").length > 2
            ? individualMetaString.split("|")[2]?.split("-")
            : [],
        sortOrder: sortOrder++,
      });
    });
  }

  return metadata;
};
export {
  createCabinet,
  getAllCabinetsByAppId,
  getCabinetById,
  updateCabinetById,
  deleteCabinetById,
  constraCompanySetUp,
  getCabinetByModuleAndCompanyId,
  getCabinetsByCompanyId,
};
