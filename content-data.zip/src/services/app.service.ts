import httpStatus from "http-status";
import { App } from "../models";
import { ApiError } from "../utils/ApiError";
import { constants } from "../config/constants";
import { v4 as uuidv4 } from "uuid";
import {
  S3Client,
  CreateBucketCommand,
  PutBucketCorsCommand,
} from "@aws-sdk/client-s3";

const createApp = async (app: any) => {
  const configurtion = app.supportedFileStorage.filter((obj) => {
    return obj.code.toLowerCase() === constants.s3;
  });

  if (!!configurtion && configurtion.length > 0) {
    const s3Configurtion = configurtion[0];
    const BUCKET_NAME = uuidv4();
    const bucketParams = {
      Bucket: BUCKET_NAME,
    };
    // Set the region
    const s3Client = new S3Client({
      region: !!s3Configurtion.preferredRegion
        ? s3Configurtion.preferredRegion
        : constants.preferredRegion,
      credentials: {
        accessKeyId: s3Configurtion.accessKeyId,
        secretAccessKey: s3Configurtion.accessKeySecret,
      },
    });
    await s3Client.send(new CreateBucketCommand(bucketParams));
    s3Configurtion.bucketId = BUCKET_NAME;
    // Create initial parameters JSON for putBucketCors.
    const thisConfig = {
      AllowedHeaders: !!s3Configurtion.allowedHeaders
        ? s3Configurtion.allowedHeaders
        : constants.allowedHeaders,
      AllowedMethods: !!s3Configurtion.allowedMethods
        ? s3Configurtion.allowedMethods
        : constants.allowedMethods,
      AllowedOrigins: !!s3Configurtion.allowedOrigins
        ? s3Configurtion.allowedOrigins
        : constants.allowedOrigins,
      ExposeHeaders: !!s3Configurtion.exposeHeaders
        ? s3Configurtion.exposeHeaders
        : constants.exposeHeaders,
      MaxAgeSeconds: !!s3Configurtion.maxAgeSeconds
        ? s3Configurtion.maxAgeSeconds
        : constants.maxAgeSeconds,
    };
    // Create an array of configs then add the config object to it.
    const corsRules = new Array(thisConfig);
    const corsParams = {
      Bucket: BUCKET_NAME,
      CORSConfiguration: { CORSRules: corsRules },
    };
    await s3Client.send(new PutBucketCorsCommand(corsParams));
  }

  const appCreated = await App.create(app);
  return {
    message: constants.app.appCreated,
    data: appCreated,
  };
};

const getAllApp = async (filter: any, options: any) => {
  const apps = await App.paginate(filter, options);
  return apps;
};

const getAppById = async (id: string) => {
  return await App.findById(id);
};

const updateAppById = async (appId: string, updateBody: any) => {
  const app = await getAppById(appId);
  if (!app) {
    throw new ApiError(httpStatus.NOT_FOUND, constants.app.appNotFound);
  }
  Object.assign(app, updateBody);
  const appUpdated = await App.updateOne({ id: appId }, { $set: app });

  if (appUpdated.n > 0) {
    return appUpdated;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.app.appNotFound);
  }
};

const deleteAppById = async (appId) => {
  const app = await App.deleteOne({ id: appId });
  if (app.deletedCount && app.deletedCount > 0) {
    return { message: constants.app.appDeleted };
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, constants.app.appNotFound);
  }
};

export {
  createApp,
  getAllApp,
  getAppById,
  deleteAppById,
  updateAppById,
};
