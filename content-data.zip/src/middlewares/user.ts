const jwt = require("jsonwebtoken");
import httpStatus from "http-status";
import { ApiError } from "../utils/ApiError";
import { constants } from "../config/constants";

const getUser = () => (req, res, next) => {
  const token = req.headers["authorization"].split(" ")[1];

  if (token) {
    const payload = jwt.decode(token);
    req.user = payload;
  } else {
    throw new ApiError(httpStatus.FORBIDDEN, constants.user.forbidden);
  }

  next();
};

export { getUser };
