const messagingConstants = Object.freeze({
  queueNames: {
    VIMEO_UPLOAD_QUEUE: "vimeo-upload-queue",
  },
  messageType: {
    TYPE_START_VIDEO_PROCESSING: "Start video processing",
  },
  events: {
    EVENT_PUBLISHING: "Message publishing to video processing queue",
    EVENT_PUBLISHED: "Message published to video processing queue",
    EVENT_PUBLISH_ERROR: "Message publishing to video processing queue failed",
  },
  status: {
    NEW: "New",
    PROCESSING: "Processing",
    ERROR: "Error",
    COMPLETED: "Completed",
  },
});

export { messagingConstants };
