import dotenv from "dotenv";
import path from "path";
import Joi from "joi";

dotenv.config({ path: path.join(__dirname, "../../.env") });

const envVarsSchema = Joi.object()
  .keys({
    NODE_ENV: Joi.string()
      .valid("production", "development", "test")
      .required(),
    PORT: Joi.number().default(4003),
    MONGODB_URL: Joi.string().required().description("Mongo DB url"),
    LIBRARY_METADATA: Joi.string().description(
      "used for setting up library cabinet for constra"
    ),
    MEDIA_METADATA: Joi.string().description(
      "used for setting up media cabinet for constra"
    ),
    EXTERIOR_METADATA: Joi.string().description(
      "used for setting up exterior cabinet for constra"
    ),
    FROM_EMAIL: Joi.string().description(
      "the from field in the emails sent by the app"
    ),
    SENDGRID_KEY: Joi.string().description("Sendgrid key"),
    REDIS_HOST: Joi.string().description("used for redis host"),
    REDIS_PORT: Joi.string().description("used for redis port"),
    NO_DAYS_FOR_REFRESH: Joi.string().description(
      "used for checking days to refresh file urls"
    ),
    SCHEDULE_HOUR_OF_THE_DAY: Joi.string().description(
      "used for setting time in hour for the scheduled job to run"
    ),
    SCHEDULE_MINUTE_OF_THE_DAY: Joi.string().description(
      "used for setting number minutes after the hour for the scheduled job to run"
    ),
    SCHEDULE_TIMEZONE: Joi.string().description(
      "used for setting for the scheduled job to run"
    ),
    MESSAGE_BROKER_URL: Joi.string().description("Message broker url"),
  })
  .unknown();

const { value: envVars, error } = envVarsSchema
  .prefs({ errors: { label: "key" } })
  .validate(process.env);

if (error) {
  throw new Error(`Config validation error: ${error.message}`);
}

const config = {
  env: envVars.NODE_ENV,
  port: envVars.PORT,
  mongoose: {
    url: envVars.MONGODB_URL + (envVars.NODE_ENV === "test" ? "-test" : ""),
    options: {
      useCreateIndex: true,
      useNewUrlParser: true,
      useUnifiedTopology: true,
    },
  },
  email: {
    from: envVars.FROM_EMAIL,
    sendGridKey: envVars.SENDGRID_KEY,
  },
  messageBrokerUrl: envVars.MESSAGE_BROKER_URL,
  libraryMetadata: envVars.LIBRARY_METADATA,
  mediaMetadata: envVars.MEDIA_METADATA,
  interiorMetadata: envVars.INTERIOR_METADATA,
  rfiMetadata: envVars.RFI_METADATA,
  redisHost: envVars.REDIS_HOST,
  redisPort: envVars.REDIS_PORT,
  refreshFileUrlJob: {
    daysToRefresh: envVars.NO_DAYS_FOR_REFRESH,
    schedulerTriggerHour: envVars.SCHEDULE_HOUR_OF_THE_DAY,
    schedulerTriggerMinutes: envVars.SCHEDULE_MINUTE_OF_THE_DAY,
    schedulerTimeZone: envVars.SCHEDULE_TIMEZONE,
  },
};

export { config };
