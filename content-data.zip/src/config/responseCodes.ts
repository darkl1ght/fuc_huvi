const responseCodes = {
  SUCCESS: 10000,
  ERROR: 10001,
  NOT_FOUND: 10003,
  ALREADY_EXISTS: 10004,
};

export { responseCodes };
