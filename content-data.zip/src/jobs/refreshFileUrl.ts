import * as schedule from "node-schedule";
import { FileService } from "../services";
import { config } from "../config/config";
const rule = new schedule.RecurrenceRule();

rule.minute = new schedule.Range(0, 59, 30); //run every 30 mins

rule.tz = config.refreshFileUrlJob.schedulerTimeZone;

const subtractDays = (days: number, fromDate: Date = new Date()): Date => {
  return new Date(fromDate.getTime() - days * 24 * 60 * 60 * 1000);
};
const refreshFileUrlJob = async () => {
  schedule.scheduleJob(rule, async () => {
    await FileService.refreshFilesDaily(
      subtractDays(config.refreshFileUrlJob.daysToRefresh),
      2000
    );
  });
};

export { refreshFileUrlJob };
