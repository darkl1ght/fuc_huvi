import mongoose from "mongoose";
import { sendPersonalizationTagMail } from "./sendEmail";
import { constants } from "../config/constants";
const EmailTemplate = mongoose.model("EmailTemplate");

const sendMediaTagEmail = async (mailTo, projectName, comment) => {
  let mailSentError: any = null;
  let mailSentStatus = "success";
  try {
    let emailTemplate;
    await EmailTemplate.findOne({
      code: "ET10001",
    })
      .then((template) => {
        emailTemplate = template;
      })
      .catch((err) => {
        mailSentError = err;
      });
    if (!mailSentError) {
      let subject;
      let emailContent;
      subject = emailTemplate.subject;
      emailContent = emailTemplate.body
        .replace("{project}", projectName)
        .replace("{comment}", comment);
      const sendGridError = await sendPersonalizationTagMail(
        mailTo,
        subject,
        emailContent
      );

      if (sendGridError) {
        throw sendGridError;
      } else {
        mailSentStatus = "success";
      }
    } else {
      throw mailSentError;
    }
  } catch (err) {
    mailSentError = err;
    mailSentStatus = "failure";
    console.error(
      constants.file.mediaTagEmailError + ": " + JSON.stringify(err)
    );
  }

  return [mailSentError, mailSentStatus];
};

export { sendMediaTagEmail };
