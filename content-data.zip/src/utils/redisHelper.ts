import { config } from "../config/config";
const redis = require("redis");
let redisClient;
let isRedisConnected: boolean = false;

(async () => {
  redisClient = redis.createClient({
    socket: {
      host: config.redisHost,
      port: config.redisPort,
      tls: {},
      maxRetriesPerRequest: 2,
      reconnectOnError: function (err) {
        return false;
      },
      retryStrategy: function (times) {
        return null;
      },
    },
  });

  redisClient
    .on("connect", () => {
      console.log("Redis connect");
    })
    .on("ready", () => {
      isRedisConnected = true;
    })
    .on("error", (e) => {
      console.log("Redis error", e);
      isRedisConnected = false;
    });

  await redisClient.connect();
})();

const redisSetJson = async (
  key: string,
  data: any,
  ttl: number = 3600 //number of seconds till expiry
) => {
  await redisClient.set(key, JSON.stringify(data), { EX: ttl });
};
const redisGetJson = async (key: string) => {
  const jsonValue = await redisClient.get(key);
  return !!jsonValue ? JSON.parse(jsonValue) : null;
};

const redisSetValue = async (
  key: string,
  data: any,
  ttl: number = 3600
) => {
  await redisClient.set(key, data, { EX: ttl });
};
const redisGetValue = async (key: string) => {
  await redisClient.get(key);
};
const redisDeleteKey = async (key: string) => {
  await redisClient.del(key);
};
export {
  isRedisConnected,
  redisSetJson,
  redisGetJson,
  redisSetValue,
  redisGetValue,
  redisDeleteKey,
};
