import { config } from "../config/config";
const SendGridMail = require("@sendgrid/mail");
SendGridMail.setApiKey(config.email.sendGridKey);

const sendPersonalizationTagMail = async (mailTo, subject, emailContent) => {
  try {
    let sendGridStatus;
    let sendGridError: any = null;
    const messages: any[] = [];
    for (let user of mailTo) {
      messages.push({
        to: `${user.name}<${user.email}>`,
        subject: subject,
        from: config.email.from,
        html: emailContent
          .replace(
            "{user}",
            user.firstName.charAt(0).toUpperCase() + user.firstName.slice(1)
          )
          .replace(`${user.email}`, `<strong>${user.email}</strong>`),
      });
    }

    await (async () => {
      try {
        await SendGridMail.send(messages).then(() => {
          sendGridStatus = "success";
        });
      } catch (error: any) {
        sendGridError = error;
        if (error.response) {
          console.error(error.response.body);
        }
      }
    })();

    return sendGridError;
  } catch (err) {
    console.error(err);
  }
};

export { sendPersonalizationTagMail };
