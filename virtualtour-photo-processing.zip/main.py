import pandas
from database import get_tour_details, is_tour_published
from message_reciever import BasicMessageReceiver
from azure_blob import download_blob_file, upload_file_to_blob
import shutil
import subprocess
from os import environ as env
import numpy as np
from uuid import uuid4
import cv2
import pymongo
import threading
import functools
import json
import os
from dotenv import load_dotenv
load_dotenv()

PHOTO_MODE_PROCESSING_QUEUE = env['PHOTO_MODE_PROCESSING_QUEUE']
MESSAGING_BROKER_ID = env['MESSAGING_BROKER_ID']
MESSAGING_USER_ID = env['MESSAGING_USER_ID']
MESSAGING_USER_PASSWORD = env['MESSAGING_USER_PASSWORD']
MESSAGING_BROKER_REGION = env['MESSAGING_BROKER_REGION']


def ack_message(ch, delivery_tag):
    """Note that `ch` must be the same pika channel instance via which
    the message being ACKed was retrieved (AMQP protocol constraint).
    """
    if ch.is_open:
        ch.basic_ack(delivery_tag)
    else:
        # Channel is already closed, so we can't ACK this message;
        # log and/or do something that makes sense for your app in this case.
        pass


def should_requeue(exception):
    """
    Determines whether a message should be requeued based on the exception raised while processing the message.

    Args:
        exception: The exception that was raised while processing the message.

    Returns:
        bool: True if the message should be requeued, False otherwise.
    """
    # Here is an example implementation that will requeue the message if a specific type of exception occurs:
    return True


def do_work(ch, delivery_tag, body):

    try:
        print("[x] Received %r" % body)

        message_body = json.loads(body)
        message = message_body['message']
        if message:
            tour_id = message.get("tourId")
            updatedBy = message.get("updatedBy")
            auth_token = message.get("authToken")

            print("[x] tour_id %r" % tour_id)
            print("[x] auth_token %r" % auth_token)
            if tour_id and auth_token:
                do_photo_processing(ch=ch, delivery_tag=delivery_tag,
                                    tour_id=tour_id, auth_token=auth_token)
            else:
                print("No data to process")

    except Exception as e:
        print(e)
        if should_requeue(e):
            ch.basic_nack(delivery_tag=delivery_tag, requeue=True)
        else:
            ch.basic_ack(delivery_tag=delivery_tag)


def do_photo_processing(ch, delivery_tag, tour_id, auth_token):
    try:
        print(f"Started Photo mode processing")
        source_path = env['SOURCE_PATH']
        processed_path = env['PROCESSED_PATH']

        tour_id = tour_id
        auth_token = auth_token
        tour_data = get_tour_details(tour_id=tour_id)
        tour_images = []

        if tour_data:
            tour_images = tour_data['images']
            if not os.path.exists(processed_path):
                os.mkdir(processed_path)

            if not os.path.exists(f"{processed_path}/{tour_id}"):
                os.mkdir(f"{processed_path}/{tour_id}")
            for imageData in tour_images:
                media_blob_content_id = imageData['blobImageId']
                # download image for processing
                download_blob_file(
                    tour_id=tour_id, file_name=media_blob_content_id)
                # get input and processed file path
                input_file = os.path.join(
                    f"{source_path}/{tour_id}/", media_blob_content_id)
                output_file = os.path.join(
                    f"{processed_path}/{tour_id}/", media_blob_content_id)

                # Deface images/files
                command = "deface"
                args = ["--thresh", "0.5", "input",
                        input_file, "-o", output_file]

                result = subprocess.run(
                    [command] + args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                # uploading processed images
                upload_file_to_blob(
                    tour_id=tour_id, file_name=media_blob_content_id)

                # clean files after processing
                os.remove(input_file)
                os.remove(output_file)

            # Acknowledge the message
            cb = functools.partial(ack_message, ch, delivery_tag)
            ch.connection.add_callback_threadsafe(cb)

        else:
            print("No data to process")
            ch.basic_ack(delivery_tag=delivery_tag)

    except Exception as e:
        print(e)


# Define the callback function that will be called when a message is received
def callback(ch, method_frame, header_frame, body):
    delivery_tag = method_frame.delivery_tag
    t = threading.Thread(target=do_work, args=(ch, delivery_tag, body))
    t.start()


MAX_THREADS = 1

# Create Basic Message Receiver which creates a connection and channel for consuming messages.
basic_message_receiver = BasicMessageReceiver(
    MESSAGING_BROKER_ID,
    MESSAGING_USER_ID,
    MESSAGING_USER_PASSWORD,
    MESSAGING_BROKER_REGION,
    max_threads=MAX_THREADS
)

basic_message_receiver.consume_messages(
    PHOTO_MODE_PROCESSING_QUEUE, callback=callback)

# Close connections.
basic_message_receiver.close()
