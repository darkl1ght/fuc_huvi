import os
from azure.storage.blob import BlobServiceClient
from os.path import exists
import cv2

from os import environ as env
from dotenv import load_dotenv
load_dotenv()

# Retrieve the connection string for use with the application. The storage
# connection string is stored in an environment variable on the machine
# running the application called AZURE_STORAGE_CONNECTION_STRING. If the environment variable is
# created after the application is launched in a console or with Visual Studio,
# the shell or application needs to be closed and reloaded to take the
# environment variable into account.

connect_str = env['AZURE_STORAGE_CONNECTION_STRING']
source_path = env['SOURCE_PATH']
processed_path = env['PROCESSED_PATH']

# Create the BlobServiceClient object
blob_service_client = BlobServiceClient.from_connection_string(connect_str)

# Create a unique name for the container
container_name = 'virtualtour'


def download_blob_file(tour_id, file_name):

    try:
        print(f"Downloading {file_name} from tour {tour_id}")

        # Download the blob to a local file
        # Instantiate a new ContainerClient
        container_client = blob_service_client.get_container_client(
            container_name)

        blob_client = container_client.get_blob_client(
            f"{tour_id}/{file_name}")

        if not os.path.exists(source_path):
            os.mkdir(source_path)
        
        if not os.path.exists(f"{source_path}/{tour_id}"):
            os.mkdir(f"{source_path}/{tour_id}")
        

        if not exists(f"{source_path}/{tour_id}/{file_name}"):

            # [START download_a_blob]
            with open(f"{source_path}/{tour_id}/{file_name}", "wb") as my_blob:
                download_stream = blob_client.download_blob()
                my_blob.write(download_stream.readall())
            
            print(f"Downloading {file_name} from tour {tour_id} complete")

            # [END download_a_blob]

    # Quickstart code goes here

    except Exception as ex:
        print('Exception:')
        print(ex)



def clear_images_from_blob(tour_id):

    try:
       
        # Download the blob to a local file
        # Instantiate a new ContainerClient
        container_client = blob_service_client.get_container_client(
            container_name)

        # Set the path of the folder you want to delete images from
        folder_path = f"{tour_id}/"

        # Get a list of all blobs in the folder
        blobs = container_client.list_blobs(name_starts_with=folder_path)

        # Delete each blob with the .jpg extension in the list
        for blob in blobs:
            if blob.name.endswith(".jpg"):
                print(f"Deleted blob with name {blob.name} from folder {folder_path}")
                container_client.delete_blob(blob)


    except Exception as ex:
        print('Exception:')
        print(ex)


def upload_file_to_blob(tour_id, file_name):

    file_path = f"{processed_path}/{tour_id}/{file_name}"

    container_client = blob_service_client.get_container_client(
            container_name)
    blob_client = container_client.get_blob_client(f'{tour_id}/{file_name}')

    if blob_client.exists():
            blob_client.delete_blob()

     # # [START upload_a_blob]
        # # Upload content to block blob
    with open(file_path, "rb") as data:
        blob_client.upload_blob(data, blob_type="BlockBlob")
        print(f"Uploading {file_name} from tour {tour_id} complete")
    # [END upload_a_blob]