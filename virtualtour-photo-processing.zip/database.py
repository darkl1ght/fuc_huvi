
from pymongo import MongoClient
from datetime import datetime
from os import environ as env
from dotenv import load_dotenv
load_dotenv()
import requests

MONGODB_CONNECTION_STRING = env["MONGODB_CONNECTION_STRING"]
MONGODB_DATABASE_NAME = env["MONGODB_DATABASE_NAME"]
TOUR_IMAGES = env["MONGODB_TOUR_IMAGES"]
LOOKUPS = env["MONGODB_LOOKUPS"]
INTERIOR_TOURS = env["MONGODB_INTERIOR_TOURS"]


client = MongoClient(MONGODB_CONNECTION_STRING)
database = client[MONGODB_DATABASE_NAME]
tour_images_collection = database[TOUR_IMAGES]
lookups_collection = database[LOOKUPS]
interiortours_collection = database[INTERIOR_TOURS]


#  Publish the tour to CONSTRA and update the status of the tour
def is_tour_published(tour_id):

    tour = tour_images_collection.find_one({'tourId': tour_id})

    print(tour, tour['isPublished'])

    return tour['isPublished']

def get_tour_details(tour_id):
    data = tour_images_collection.find_one({'tourId': tour_id})
    return data


def invoke_publish_tour_api(project_id, interior_id, tour_id, auth_token):
    
    url = f"https://constra-api.huviair.com:3000/v1/project/api/virtualtour/{project_id}/interiors/{interior_id}/tour/{tour_id}/publish"
    
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {auth_token}"}
    
    response = requests.put(url, json={}, headers=headers)

    if response.status_code == 200:

        # Update tour status and processing status
        update_event(tour_id=tour_id,
                         message="Tour published successfully")

        update_processing_status(tour_id=tour_id)

    else:
        print("Request failed with status code:", response.status_code)
