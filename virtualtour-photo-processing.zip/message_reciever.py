from message_broker import BasicPikaClient
from os import environ as env
from dotenv import load_dotenv
load_dotenv()


class BasicMessageReceiver(BasicPikaClient):

    def get_message(self, queue):
        method_frame, header_frame, body = self.channel.basic_get(queue)
        if method_frame:
            print(method_frame, header_frame, body)
            self.channel.basic_ack(method_frame.delivery_tag)
            return method_frame, header_frame, body
        else:
            print('No message returned')

    def consume_messages(self, queue, callback):

        try:
            queue_exchange = env['PHOTO_MODE_PROCESSING']
            self.channel.queue_bind(
                queue=queue, exchange=queue_exchange, routing_key=queue_exchange+"-1")

            self.channel.basic_consume(
                queue=queue, on_message_callback=callback, auto_ack=False)

            print(' [*] Waiting for messages. To exit press CTRL+C')
            self.channel.start_consuming()

        except Exception as e:
            print("Connection failure", e)

    def close(self):
        try:
            self.channel.close()
            self.connection.close()

        except Exception as e:
            print("Cannot close channel or connection", e)
