import glob
import natsort

def get_image_paths(directory_name):
    try:
        file_paths = glob.glob(f'{directory_name}/IMAGE-*.png')
        sorted_paths = natsort.natsorted(file_paths) 
        return sorted_paths
    except Exception as e:
        print(e)
