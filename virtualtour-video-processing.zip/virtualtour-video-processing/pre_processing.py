import cv2
import numpy as np
import os
import shutil
from utils import get_image_paths

THRESHOLD = 500

def mse(imageA, imageB):
    err = np.sum((imageA.astype("float") - imageB.astype("float")) ** 2)
    err /= float(imageA.shape[0] * imageA.shape[1])
    return err

def compare_images(imageA, imageB):
    return mse(imageA, imageB)


def start_pre_processing(input_folder):
   
    image_list = get_image_paths(f"{input_folder}/images")
   

    filtered_images = [image_list[0]]

    for i, image_file1 in enumerate(image_list[:-1]):
        img1 = cv2.imread(image_file1, cv2.IMREAD_GRAYSCALE)
        image_file2 = image_list[i + 1]
        img2 = cv2.imread(image_file2, cv2.IMREAD_GRAYSCALE)
        
        similarity = compare_images(img1, img2)

        if similarity > THRESHOLD:
            filtered_images.append(image_file2)

        else :
            print(f"Removed image at {image_file2}")

    
    print("Filtering out image complete")

    # Create the output folder if it doesn't exist
    output_folder = f"{input_folder}/pre-processed-images"
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    
    # Copy the filtered images to the output folder
    for filtered_image_path in filtered_images:
        # Get just the filename from the full path of the filtered image
        filtered_image_filename = os.path.basename(filtered_image_path)
        # Construct the full output path by joining the output folder path with the filtered image filename
        output_image_path = os.path.join(output_folder, filtered_image_filename)
        # Copy the filtered image to the output folder
        shutil.copy(filtered_image_path, output_image_path)


    print(f"Filtered images saved in: {output_folder}")


