
from database import get_tour_details, update_tour_features, update_north_offset, publish_tour
from azure_blob import upload_image_to_blob, clear_images_from_blob
import numpy as np
import random
import math

# Affine transformations
def transform_coordinates(tour_id, coordinates):

    try:
        # Agisoft coordinate system
        (x1, y1) = (coordinates[0]['X-Coordinate'], coordinates[0]['Y-Coordinate'] );
        (x2, y2) = (coordinates[len(coordinates) - 1]['X-Coordinate'], coordinates[len(coordinates) - 1]['Y-Coordinate']);

        #  Floor plan coordinate system
        tour = get_tour_details(tour_id=tour_id)
        (x1n, y1n) = (tour['videoCaptureDetails']['captureStartPoint']['x'],tour['videoCaptureDetails']['captureStartPoint']['y']);
        (x2n, y2n) = (tour['videoCaptureDetails']['captureEndPoint']['x'],tour['videoCaptureDetails']['captureEndPoint']['y']);

        matrix1 = np.array([
          [x1, y1, 1, 0],
          [-y1, x1, 0, 1],
          [x2, y2, 1, 0],
          [-y2, x2, 0, 1],
        ])
       

        matrix2 = np.array([x1n, y1n, x2n, y2n]);

        # a,b,c,d values from the linear equations (ax+by+c) (bx-ay+d)
        newMatrix = np.dot(np.linalg.inv(matrix1), matrix2).tolist();

        a = newMatrix[0];
        b = newMatrix[1];
        c = newMatrix[2];
        d = newMatrix[3];

        image_features = [];

        
        clear_images_from_blob(tour_id=tour_id)
        
        for index, coordinate in enumerate(coordinates):
            x = a * coordinate['X-Coordinate'] + b * coordinate['Y-Coordinate']  + c;
            y = b * coordinate['X-Coordinate'] - a * coordinate['Y-Coordinate']  + d;

            latest_coordinates = [x,y]

            upload_image_to_blob(tour_id, coordinate['Image number'])

            image_features.append({
                'type': 'Feature',
                'geometry': { 
                    'coordinates': latest_coordinates,
                    'type': 'Point'
                 },
                'properties': {
                    'imageNumber': index + 1,
                    'imageId' : coordinate['Image number']+".jpg",
                    'imageName': coordinate['Image number']+".jpg"
                 },
                'id': random.random()
            })
          
        tour_features = {
            'type' : 'FeatureCollection',
            'features' : image_features
        }

        update_tour_features(tour_id=tour_id, features=tour_features)
        

        (pointX2, pointY2) = (coordinates[1]['X-Coordinate'], coordinates[1]['Y-Coordinate'] );
        
       
        update_north_offset(tour_id=tour_id, angle=math.atan2(pointX2 - x, pointY2- y) * (180 / math.pi));


    except Exception as ex:
        print('Exception in transformation:')
        print(ex)

