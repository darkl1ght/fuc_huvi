from utils import get_image_paths

from dotenv import load_dotenv
load_dotenv()

from azure_blob import download_blob_file, upload_file_to_blob
import Metashape
from message_reciever import BasicMessageReceiver
import json
import pandas
import os
import functools
import threading
from database import publish_tour, update_event, update_exported_camera_details, is_tour_published
from coordinates_transformation import transform_coordinates
import cv2
from uuid import uuid4
import numpy as np
from os import environ as env
import subprocess
import shutil

print(f"Using agisoft version {Metashape.version}")

Metashape.app.cpu_enable = True

METASHAPE_PROCESSING_QUEUE = env['METASHAPE_PROCESSING_QUEUE']
MESSAGING_BROKER_ID = env['MESSAGING_BROKER_ID']
MESSAGING_USER_ID = env['MESSAGING_USER_ID']
MESSAGING_USER_PASSWORD = env['MESSAGING_USER_PASSWORD']
MESSAGING_BROKER_REGION = env['MESSAGING_BROKER_REGION']



def ack_message(ch, delivery_tag):
    """Note that `ch` must be the same pika channel instance via which
    the message being ACKed was retrieved (AMQP protocol constraint).
    """
    if ch.is_open:
        ch.basic_ack(delivery_tag)
    else:
        # Channel is already closed, so we can't ACK this message;
        # log and/or do something that makes sense for your app in this case.
        pass


def add_chunk(doc):

    try:
        chunk = Metashape.Chunk
        if len(doc.chunks) > 0:
            chunk = doc.chunk
        else:
            chunk = doc.addChunk()
        chunk.label = "New Chunk"
    except Exception as err:
        print("Error in adding chunk. Error: {}".format(str(err)),
              exc_info=True)
        raise
    else:
        return chunk


"""
JSON object format
{
    "tourId" : "XYZ",
    "mediaBlobContentId": "test.mp4
}
"""


def progress_callback(progress):
    # print(f"Progress: {progress}%")
    pass


def do_work(ch, delivery_tag, body):

    try:
        print("[x] Received %r" % body)

        message = json.loads(body)
        tour_id = message.get("tourId")
        media_blob_content_id = message.get("mediaBlobContentId")
        updatedBy = message.get("updatedBy")
        auth_token = message.get("authToken")

     
        if tour_id and media_blob_content_id and not is_tour_published(tour_id=tour_id):

            update_event(tour_id=tour_id, message="Processing media started")

            # Create a new chunk
            doc = Metashape.Document()
            chunk = add_chunk(doc)

            
            update_event(tour_id=tour_id,
                            message="Downloading of video started")

            # Download .MP4 file
            if not os.path.exists(f"processed_data/{tour_id}/{media_blob_content_id}"):
                download_blob_file(tour_id, media_blob_content_id)

                # Deface video
                command = "deface"
                args = ["--thresh", "0.7","--scale", "640x320","input", f"processed_data/{tour_id}/{media_blob_content_id}"]
                
                result = subprocess.run(
                    [command] + args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            if not os.path.exists(f"processed_data/{tour_id}/images"):
                os.mkdir(f"processed_data/{tour_id}/images")

                video_name = media_blob_content_id[:media_blob_content_id.rfind(
                    ".mp4")]
                vidcap = cv2.VideoCapture(
                    f"processed_data/{tour_id}/{video_name}_anonymized.mp4")

                width = int(vidcap.get(cv2.CAP_PROP_FRAME_WIDTH))
                height = int(vidcap.get(cv2.CAP_PROP_FRAME_HEIGHT))

                
                success, image = vidcap.read()
                success = True
                # count = 0
                image_number = 1
                while success:
                    # save frame as JPEG file
                    frame = cv2.resize(image, (width, height))
                    cv2.imwrite(
                        f"processed_data/{tour_id}/images/IMAGE-{image_number}.png", frame)
                    success, image = vidcap.read()

                    print('Read a new frame: ', success)
                    # count = count + 1
                    image_number += 1

                update_event(tour_id=tour_id,
                            message="Video split to images complete")

            file_paths = get_image_paths(f"processed_data/{tour_id}/images")

            chunk.addPhotos(filenames=file_paths, filegroups=[])
  

            update_event(tour_id=tour_id,
                        message="Importing of images complete")

            # Convert all the sensors into a spherical sensor
            for sensor in chunk.sensors:
                sensor.type = Metashape.Sensor.Type.Spherical

            reference_preselection_value = Metashape.ReferencePreselectionMode.ReferencePreselectionSequential
            keypoints_limit = 60000
            tiepoints_limit = 40000
            keypoints_limit_per_mpx = 10000
            guided_matching = False

            chunk.matchPhotos(downscale=0, generic_preselection=False, reference_preselection_mode=reference_preselection_value, keypoint_limit=keypoints_limit,
                            tiepoint_limit=tiepoints_limit,
                            guided_matching=guided_matching, progress=progress_callback, keypoint_limit_per_mpx=keypoints_limit_per_mpx)

            update_event(tour_id=tour_id,
                        message="Matching of images complete")

            chunk.alignCameras(adaptive_fitting =True,progress=progress_callback)


            aligned = list()
            not_aligned = list()
            for camera in chunk.cameras:
                if camera.transform:
                    aligned.append(camera)
                elif camera.enabled:
                    not_aligned.append(camera)

            if len(not_aligned) > len(aligned) * 0.1:
                print("Realigning cameras")
                chunk.alignCameras(adaptive_fitting= True, cameras = not_aligned, reset_alignment=False)

                
                chunk.matchPhotos(downscale=0, generic_preselection=False, reference_preselection_mode=reference_preselection_value, keypoint_limit=keypoints_limit,
                            tiepoint_limit=tiepoints_limit,
                            guided_matching=guided_matching, progress=progress_callback, keypoint_limit_per_mpx=keypoints_limit_per_mpx, reset_matches=True )

            chunk.exportCameras(path=f"processed_data/{tour_id}/cameras.txt",
                                format=Metashape.CamerasFormat.CamerasFormatOPK)

            update_event(tour_id=tour_id,
                        message="Exporting of cameras complete")


            # Acknowledge the message
            cb = functools.partial(ack_message, ch, delivery_tag)
            ch.connection.add_callback_threadsafe(cb)

            # Read the exported cameras from the txt file
            cameras_data_frame = pandas.read_csv(f"processed_data/{tour_id}/cameras.txt", sep="\t",
                                                skiprows=[0, 1], header=None, usecols=[0, 1, 3])

            cameras_data_frame['row_num'] = np.arange(len(cameras_data_frame))

            cameras_data_frame.columns = [
                "Image number", "X-Coordinate", "Y-Coordinate", "Image-Number"]

            json_dump = json.loads(
                cameras_data_frame.to_json(orient="records"))

            json_dump.sort(key=lambda x: x['Image-Number'])

            update_exported_camera_details(
            tour_id=tour_id, exported_coordinates=json_dump)

            transform_coordinates(tour_id=tour_id, coordinates=json_dump)

            update_event(tour_id=tour_id,
                        message="Uploading of images to the blob complete")

            publish_tour(tour_id=tour_id, auth_token=auth_token)   

            doc.save(path="project.psz", chunks=[doc.chunk])

            print(f"Processing complete for tour - {tour_id}")

            upload_file_to_blob(tour_id=tour_id)

            shutil.rmtree(f"processed_data/{tour_id}")
        else:
            ch.basic_ack(delivery_tag=delivery_tag)
     
           
    except Exception as e:
        print(e)
        if should_requeue(e):
            ch.basic_nack(delivery_tag=delivery_tag, requeue=True)
        else:
            ch.basic_ack(delivery_tag=delivery_tag)

   
def should_requeue(exception):
    """
    Determines whether a message should be requeued based on the exception raised while processing the message.

    Args:
        exception: The exception that was raised while processing the message.

    Returns:
        bool: True if the message should be requeued, False otherwise.
    """
    # Here is an example implementation that will requeue the message if a specific type of exception occurs:
    return True



# Define the callback function that will be called when a message is received
def callback(ch, method_frame, header_frame, body):
    delivery_tag = method_frame.delivery_tag
    t = threading.Thread(target=do_work, args=(ch, delivery_tag, body))
    t.start()



MAX_THREADS = 1

# Create Basic Message Receiver which creates a connection and channel for consuming messages.
basic_message_receiver = BasicMessageReceiver(
    MESSAGING_BROKER_ID,
    MESSAGING_USER_ID,
    MESSAGING_USER_PASSWORD,
    MESSAGING_BROKER_REGION,
    max_threads=MAX_THREADS
)

basic_message_receiver.consume_messages(
            METASHAPE_PROCESSING_QUEUE, callback=callback)

# Close connections.
basic_message_receiver.close()
