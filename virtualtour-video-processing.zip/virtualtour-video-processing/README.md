# Introduction 
A Virtual tour video processing micro-service that uses a photogrammetry software to align 360 images and uploads the data to obtain a virtual tour 

# Getting Started
1.	Installation process <br>
clone the code from `https://huviairtech@dev.azure.com/huviairtech/huviair-app/_git/virtualtour-video-processing`
and checkout the required branch

2.	Software dependencies
    - Install python venv using command `pip install virtualenv`
    - Agisoft Metashape python SDK has to be set up as a prerequisite.
    
3. Start/Stop and check logs of the service  <br>
    `sudo systemctl restart virtual-tour-video-processing.service`
    `sudo systemctl stop virtual-tour-video-processing.service`

    // Check logs of the service
    `sudo journalctl -u virtual-tour-video-processing.service --reverse`

A project.psz file that has been deleted also existed in root folder.
