import os
from azure.storage.blob import BlobServiceClient
from os.path import exists
from database import update_images
import cv2

from os import environ as env

# Retrieve the connection string for use with the application. The storage
# connection string is stored in an environment variable on the machine
# running the application called AZURE_STORAGE_CONNECTION_STRING. If the environment variable is
# created after the application is launched in a console or with Visual Studio,
# the shell or application needs to be closed and reloaded to take the
# environment variable into account.

connect_str = env['AZURE_STORAGE_CONNECTION_STRING']

# Create the BlobServiceClient object
blob_service_client = BlobServiceClient.from_connection_string(connect_str)

# Create a unique name for the container
container_name = 'virtualtour'


def download_blob_file(tour_id, file_name):

    try:
        print(f"Downloading {file_name} from tour {tour_id}")

        # Download the blob to a local file
        # Instantiate a new ContainerClient
        container_client = blob_service_client.get_container_client(
            container_name)

        blob_client = container_client.get_blob_client(
            f"{tour_id}/{file_name}")

        if not os.path.exists("processed_data"):
            os.mkdir("processed_data")
        
        if not os.path.exists(f"processed_data/{tour_id}"):
            os.mkdir(f"processed_data/{tour_id}")
        

        if not exists(f"processed_data/{tour_id}/{file_name}"):

            # [START download_a_blob]
            with open(f"processed_data/{tour_id}/{file_name}", "wb") as my_blob:
                download_stream = blob_client.download_blob()
                my_blob.write(download_stream.readall())
            
            print(f"Downloading {file_name} from tour {tour_id} complete")

            # [END download_a_blob]

    # Quickstart code goes here

    except Exception as ex:
        print('Exception:')
        print(ex)


def upload_image_to_blob(tour_id, image_id):

    try:

        jpeg_file_path =  f'processed_data/{tour_id}/images/{image_id}.jpg'

        png_file_path = f'processed_data/{tour_id}/images/{image_id}.png'
        
        # Read the PNG image
        png_image = cv2.imread(png_file_path)

        resized_img = cv2.resize(png_image, (3840, 1920), interpolation=cv2.INTER_LINEAR)

        # Convert the image to JPEG format with 90% quality
        jpeg_image = cv2.imencode('.jpg', resized_img, [int(cv2.IMWRITE_JPEG_QUALITY), 90])[1]

        # Write the JPEG image to disk
        with open(jpeg_file_path, 'wb') as f:
            f.write(jpeg_image)

        
        print(f"Uploading images with image id {image_id}.jpg")
       
        # Download the blob to a local file
        # Instantiate a new ContainerClient
        container_client = blob_service_client.get_container_client(
            container_name)

        blob_client = container_client.get_blob_client(f'{tour_id}/{image_id}.jpg')

        if blob_client.exists():
            blob_client.delete_blob()

        # # [START upload_a_blob]
        # # Upload content to block blob
        with open(jpeg_file_path, "rb") as data:
            blob_client.upload_blob(data, blob_type="BlockBlob")
            update_images(tour_id=tour_id,image_id=f"{image_id}.jpg")

            # [END upload_a_blob]

    except Exception as ex:
        print('Exception:')
        print(ex)


def clear_images_from_blob(tour_id):

    try:
       
        # Download the blob to a local file
        # Instantiate a new ContainerClient
        container_client = blob_service_client.get_container_client(
            container_name)

        # Set the path of the folder you want to delete images from
        folder_path = f"{tour_id}/"

        # Get a list of all blobs in the folder
        blobs = container_client.list_blobs(name_starts_with=folder_path)

        # Delete each blob with the .jpg extension in the list
        for blob in blobs:
            if blob.name.endswith(".jpg"):
                print(f"Deleted blob with name {blob.name} from folder {folder_path}")
                container_client.delete_blob(blob)


    except Exception as ex:
        print('Exception:')
        print(ex)


def upload_file_to_blob(tour_id):

    cameras_file_path = f"processed_data/{tour_id}/cameras.txt"

    container_client = blob_service_client.get_container_client(
            container_name)
    blob_client = container_client.get_blob_client(f'{tour_id}/cameras.txt')

    if blob_client.exists():
            blob_client.delete_blob()

     # # [START upload_a_blob]
        # # Upload content to block blob
    with open(cameras_file_path, "rb") as data:
        blob_client.upload_blob(data, blob_type="BlockBlob")
    # [END upload_a_blob]