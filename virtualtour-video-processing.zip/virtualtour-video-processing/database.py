
from pymongo import MongoClient
from datetime import datetime
from os import environ as env
import requests

MONGODB_CONNECTION_STRING = env["MONGODB_CONNECTION_STRING"]
MONGODB_DATABASE_NAME = env["MONGODB_DATABASE_NAME"]
VIDEO_CAPTURE_PROCESSING_STATS = env["MONGODB_VIDEO_CAPTURE_PROCESSING_STATS"]
TOUR_IMAGES = env["MONGODB_TOUR_IMAGES"]
LOOKUPS = env["MONGODB_LOOKUPS"]
INTERIOR_TOURS = env["MONGODB_INTERIOR_TOURS"]

client = MongoClient(MONGODB_CONNECTION_STRING)
database = client[MONGODB_DATABASE_NAME]
video_capture_stats_collection = database[VIDEO_CAPTURE_PROCESSING_STATS]
tour_images_collection = database[TOUR_IMAGES]
lookups_collection = database[LOOKUPS]
interiortours_collection = database[INTERIOR_TOURS]


def update_event(tour_id, message):
    video_capture_stats_collection.update_one({'tourId': tour_id}, {"$push":
                                                                    {
                                                                        "events":
                                                                        {
                                                                            "type": message,
                                                                        }
                                                                    }
                                                                    })


#  Publish the tour to CONSTRA and update the status of the tour
def is_tour_published(tour_id):

    tour = tour_images_collection.find_one({'tourId': tour_id})

    print(tour, tour['isPublished'])

    return tour['isPublished']


def update_processing_status(tour_id):
    interior_status_lookup = lookups_collection.find_one({'type': 'interiorStatus',
                                                          'key': 'VW10003'})
    video_capture_stats_collection.update_one({'tourId': tour_id},
                                              {"$set": {
                                                  "status": interior_status_lookup, 
                                                  "isProcessingComplete": True
                                            }})


def update_images(tour_id, image_id):
    tour_images_collection.update_one({'tourId': tour_id}, {"$push":
                                                            {
                                                                "images":
                                                                {
                                                                    "blobImageId": image_id,
                                                                    "imageId": image_id,
                                                                    "imageName": image_id
                                                                }
                                                            }
                                                            })


def update_exported_camera_details(tour_id, exported_coordinates):
    tour_images_collection.update_one({'tourId': tour_id}, {"$set":
                                                            {
                                                                "videoCaptureDetails.exportedCoordinates": exported_coordinates
                                                            }
                                                            })


def get_tour_details(tour_id):
    data = tour_images_collection.find_one({'tourId': tour_id})
    return data


def update_tour_features(tour_id, features):
    tour_images_collection.update_one({'tourId': tour_id}, {"$set":
                                                            {
                                                                "features": features
                                                            }
                                                            })


def update_north_offset(tour_id, angle):
    tour_images_collection.update_one({'tourId': tour_id}, {"$set":
                                                            {
                                                                "floorPlanOrientation": angle
                                                            }
                                                            })


#  Publish the tour to CONSTRA and update the status of the tour
def is_tour_published(tour_id):

    tour = tour_images_collection.find_one({'tourId': tour_id})

    print(tour, tour['isPublished'])

    return tour['isPublished']


#  Publish the tour to CONSTRA and update the status of the tour
def publish_tour(tour_id, auth_token):

    tour = tour_images_collection.find_one({'tourId': tour_id})

    invoke_publish_tour_api(project_id=tour['projectId'], interior_id=tour['interiorId'],tour_id=tour_id, auth_token=auth_token)


def invoke_publish_tour_api(project_id, interior_id, tour_id, auth_token):
    
    url = f"https://constra-api.huviair.com:3000/v1/project/api/virtualtour/{project_id}/interiors/{interior_id}/tour/{tour_id}/publish"
    
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {auth_token}"}
    
    response = requests.put(url, json={}, headers=headers)

    if response.status_code == 200:

        # Update tour status and processing status
        update_event(tour_id=tour_id,
                         message="Tour published successfully")

        update_processing_status(tour_id=tour_id)

    else:
        print("Request failed with status code:", response.status_code)
