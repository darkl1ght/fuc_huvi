"use strict";

const mongoose = require("mongoose");

const EquirectangularImageSchema = new mongoose.Schema(
  {
    interiorId: String,
    projectId: String,
    clientName: String,
    projectName: String,
    interiorName: String,
    tower: String,
    imageData: [],
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model(
  "EquirectangularImage",
  EquirectangularImageSchema
);
