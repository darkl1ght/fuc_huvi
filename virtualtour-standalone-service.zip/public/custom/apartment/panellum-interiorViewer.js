let pannellumViewer;
let logoData;
let apartmentInteriorName;
let imageIndex = 0;

const nextImageButton = document.getElementById("Next-Image");
const previousImageButton = document.getElementById("Previous-Image");

apartmentText = document.getElementById("apartmenttext");
apartmentText.innerHTML = apartmentInteriorData[0].apartmentName;

apartmentInteriorText = document.getElementById("apartmentinteriortext");
apartmentInteriorText.innerHTML =
  apartmentInteriorData[0].apartmentInteriorName;

logoData = imageData.find((item) => item.imageType);
const topRightImage = document.getElementById("topRightImage");
const transitionImage = document.getElementById("transition-image");

if (logoData) {
  topRightImage.innerHTML = `<img src="${logoData.viewUrl}" crossorigin="anonymous">`;
  transition.innerHTML = `<img src="${logoData.viewUrl}" crossorigin="anonymous">`;
} else if (!logoData) {
  transitionImage.setAttribute("src", "/assets/constra.png");
}

const topLeftImage = document.getElementById("topLeftImage");
topLeftImage.addEventListener("click", () => {
  window.open("https://constra.huviair.com", "_blank");
});

// viewer

initializePannellumViewer();

function initializePannellumViewer() {
  pannellumViewer = pannellum.viewer("panorama", {
    default: {
      sceneFadeDuration: 1000,
      showFullscreenCtrl: false,
      showZoomCtrl: false,
      showControls: false,
      loadButton: true,
      startAutorotate: false,
      autoRotate: -2,
      hfov: 120,
    },
    scenes: {},
    type: "equirectangular",
    autoLoad: true,
  });

  apartmentInteriorData.forEach((apartmentInterior) => {
    const { fileObjectId, viewUrl } = apartmentInterior;
    pannellumViewer.addScene(fileObjectId, {
      panorama: viewUrl,
    });
  });

  const imageId = apartmentInteriorData[0].fileObjectId;

  pannellumViewer.loadScene(imageId);

  return pannellumViewer;
}

const apartmentInteriorButtons = document.querySelectorAll(".dropbtn");

apartmentInteriorButtons.forEach((button) => {
  button.addEventListener("click", (event) => {
    const apartmentInterior = event.target.innerText;

    apartmentInteriorText.innerText = apartmentInterior;

    apartmentInteriorData.forEach((el) => {
      if (apartmentInterior === el.apartmentInteriorName) {
        pannellumViewer.loadScene(el.fileObjectId);
        addActiveLocationMarker(el);

        imageIndex = apartmentInteriorData.indexOf(el);
        if (imageIndex === 0) {
          previousImageButton.style.display = "none";
          nextImageButton.style.display = "block";
        } else if (imageIndex === apartmentInteriorData.length - 1) {
          previousImageButton.style.display = "block";
          nextImageButton.style.display = "none";
        } else {
          previousImageButton.style.display = "block";
          nextImageButton.style.display = "block";
        }
      }
    });
  });
});

window.addEventListener("load", function () {
  const transition = document.getElementById("transition");
  setTimeout(function () {
    transition.classList.add("hide");
    transition.style.display = "none";
  }, 2000);
});

const viewer = document.getElementById("panorama");
let clickTimeout;

viewer.addEventListener("click", () => {
  clearTimeout(clickTimeout);

  clickTimeout = setTimeout(() => {
    pannellumViewer.startAutoRotate(-2);
  }, 5000);
});

// obtaining floor plan

let readToken;
let blobContainer;
let blobContentId;
let floorPlanMarker;

readToken = azureSasToken;

blobContainer = azureBlobContainer;

blobContentId = apartmentInteriorData[0].floorPlanDetails.floorPlanBlobId;

floorPlanUrl = blobContainer + blobContentId + "?" + readToken;

let featureLayer;
let imageUrl = floorPlanUrl;
map = L.map("Map", {
  crs: L.CRS.Simple,
  minZoom: -5,
  maxBoundsViscosity: 1,
});

const img = new Image();

img.id = "mapImage";
img.src = imageUrl;
img.onload = () => {
  const w = img.width;
  const h = img.height;
  const bounds = [
    [-10, -10],
    [h, w],
  ];
  L.imageOverlay(imageUrl, bounds).addTo(map);
  map.fitBounds(bounds);
  map.setMaxBounds(bounds);
};

// Adding Markers

function locationMarker() {
  const customIconPath = "../../../assets/inactive-pin.png";
  const customIconOptions = {
    iconUrl: customIconPath,
    iconSize: [32, 32],
  };

  locationMarkerIcon = L.icon(customIconOptions);
}

function activeLocationMarker() {
  const customIconPath = "../../../assets/active-pin.png";
  const customIconOptions = {
    iconUrl: customIconPath,
    iconSize: [32, 32],
  };

  activeLocationMarkerIcon = L.icon(customIconOptions);
}

function setActiveLocationMarker(locationData) {
  const latlng = {
    lat: locationData.floorPlanDetails.floorPlanMarkerLatitude,
    lng: locationData.floorPlanDetails.floorPlanMarkerLongitude,
  };

  activeLocationMarker();
  activeFloorPlanLocationMarker = L.marker(latlng, {
    icon: activeLocationMarkerIcon,
    iconSize: [32, 32],
  }).addTo(map);
}

// Add Markers for all the Interior Locations
addAllMarkers();

// Setting Initial Marker

apartmentInteriorData.forEach((data, index) => {
  if (index === 0) {
    setActiveLocationMarker(data);
  }
});

function addActiveLocationMarker(data) {
  if (activeFloorPlanLocationMarker) {
    map.removeLayer(activeFloorPlanLocationMarker);
  }
  setActiveLocationMarker(data);
}

// Adding All Markers At a time

function addAllMarkers() {
  apartmentInteriorData.forEach((data) => {
    const popupOptions = {
      offset: [0, -8],
      closeButton: true,
      autoClose: true,
    };

    const activeMarkerPopup = L.popup(popupOptions).setContent(
      data.apartmentInteriorName
    );

    const latlng = {
      lat: data.floorPlanDetails.floorPlanMarkerLatitude,
      lng: data.floorPlanDetails.floorPlanMarkerLongitude,
    };

    locationMarker();
    const floorPlanMarker = L.marker(latlng, {
      icon: locationMarkerIcon,
      iconSize: [32, 32],
    }).addTo(map);

    // Adding pop up

    floorPlanMarker.on("mouseover", () => {
      activeMarkerPopup.setLatLng(floorPlanMarker.getLatLng()).openOn(map);
    });

    floorPlanMarker.on("click", (event) => {
      changeImageOnMarkerClick(event);
    });
  });
}

function changeImageOnMarkerClick(event) {
  const lat = event.latlng.lat.toFixed(10);
  const lng = event.latlng.lng.toFixed(10);

  if (activeFloorPlanLocationMarker) {
    map.removeLayer(activeFloorPlanLocationMarker);
  }

  apartmentInteriorData.forEach((el) => {
    if (el.floorPlanDetails) {
      const elementLat =
        el.floorPlanDetails.floorPlanMarkerLatitude.toFixed(10);
      const elementLng =
        el.floorPlanDetails.floorPlanMarkerLongitude.toFixed(10);

      if (lat === elementLat && lng === elementLng) {
        //
        pannellumViewer.loadScene(el.fileObjectId);
        apartmentInteriorText.innerText = el.apartmentInteriorName;
        activeLocationMarker();
        activeFloorPlanLocationMarker = L.marker(event.latlng, {
          icon: activeLocationMarkerIcon,
          iconSize: [32, 32],
        }).addTo(map);

        imageIndex = apartmentInteriorData.indexOf(el);
        if (imageIndex === 0) {
          previousImageButton.style.display = "none";
          nextImageButton.style.display = "block";
        } else if (imageIndex === apartmentInteriorData.length - 1) {
          previousImageButton.style.display = "block";
          nextImageButton.style.display = "none";
        } else if (apartmentInteriorData.length === 1) {
          previousImageButton.style.display = "none";
          nextImageButton.style.display = "none";
        } else {
          previousImageButton.style.display = "block";
          nextImageButton.style.display = "block";
        }
      }
    }
  });
}

// Show and Hide Apartment Buttons

const apartmentButtonsDiv = document.getElementById(
  "apartment-interior-buttons"
);
const displayApartmentButtonsArrowIcon = document.getElementById(
  "Show-buttons-arrow-icon"
);

let apartmentButtonsHidden = false;

displayApartmentButtonsArrowIcon.addEventListener("click", () => {
  if (apartmentButtonsHidden) {
    apartmentButtonsHidden = false;
    displayApartmentButtonsArrowIcon.className =
      "fas fa-chevron-down Show-buttons-arrow-icon";
    apartmentButtonsDiv.style.opacity = 1;
  } else {
    apartmentButtonsHidden = true;
    displayApartmentButtonsArrowIcon.className =
      "fas fa-chevron-up Show-buttons-arrow-icon";
    apartmentButtonsDiv.style.opacity = 0;
  }
});

// Hide Floor Plan

const floorPlanVisibilityButton = document.getElementById("floor-plan-button");
let isFloorplanVisible = true;

floorPlanVisibilityButton.addEventListener("click", () => {
  const mapContainers = document.getElementsByClassName("map-container");

  if (isFloorplanVisible) {
    floorPlanVisibilityButton.innerHTML = "Show floor Plan";
    isFloorplanVisible = false;

    for (const mapContainer of mapContainers) {
      mapContainer.hidden = true;
    }
    apartmentButtonsDiv.style.left = "25%";
    displayApartmentButtonsArrowIcon.style.left = "47%";
  } else {
    floorPlanVisibilityButton.innerHTML = "Hide floor Plan";
    isFloorplanVisible = true;

    for (const mapContainer of mapContainers) {
      mapContainer.hidden = false;
    }
    apartmentButtonsDiv.style.left = "20%";
    displayApartmentButtonsArrowIcon.style.left = "42%";
  }
});

// Next Image

moveToNextImage = () => {
  //
  const interiorImageData = [...apartmentInteriorData];
  imageIndex++;
  if (imageIndex !== 0 && imageIndex < interiorImageData.length) {
    previousImageButton.style.display = "block";
    interiorImageData.find((el) => {
      //
      if (interiorImageData.indexOf(el) === imageIndex) {
        pannellumViewer.loadScene(el.fileObjectId);
        apartmentInteriorText.innerHTML = el.apartmentInteriorName;

        if (activeFloorPlanLocationMarker) {
          map.removeLayer(activeFloorPlanLocationMarker);
        }
        setActiveLocationMarker(el);
      }
    });
    if (imageIndex === interiorImageData.length - 1) {
      nextImageButton.style.display = "none";
    }
  }
};

nextImageButton.addEventListener("click", moveToNextImage);

// Check for Number of Images to display the Next & previous Image buttons

nextImageButtonDisplay = () => {
  const interiorImageData = [...apartmentInteriorData];

  if (interiorImageData.length === 1) {
    nextImageButton.style.display = "none";

    // Also Hiding the navigating buttons if there is only one image in the tour.
    const apartmentInteriorToggleButtons = document.getElementById(
      "apartmentInterior-toggle-buttons"
    );
    apartmentInteriorToggleButtons.style.display = "none";
    displayApartmentButtonsArrowIcon.style.display = "none";
  } else {
    nextImageButton.style.display = "block";
  }
};

nextImageButtonDisplay();

// Previous Image

moveToPreviousImage = () => {
  const interiorImageData = [...apartmentInteriorData];
  imageIndex = imageIndex - 1;

  if (imageIndex < interiorImageData.length) {
    //
    interiorImageData.find((el) => {
      if (interiorImageData.indexOf(el) === imageIndex) {
        pannellumViewer.loadScene(el.fileObjectId);
        apartmentInteriorText.innerHTML = el.apartmentInteriorName;
        nextImageButton.style.display = "block";

        if (activeFloorPlanLocationMarker) {
          map.removeLayer(activeFloorPlanLocationMarker);
        }
        setActiveLocationMarker(el);
      }
    });
    if (imageIndex === 0) {
      previousImageButton.style.display = "none";
    }
  }
};

previousImageButton.addEventListener("click", moveToPreviousImage);

// Download Images

const downloadButton = document.getElementById("download-button");

downloadButton.addEventListener("click", () => {
  downloadButton.innerHTML = "Downloading...";
  downloadButton.style.width = "110px";

  const zipImages = async () => {
    const zip = new JSZip();

    for (let i = 0; i < apartmentInteriorData.length; i++) {
      const response = await fetch(apartmentInteriorData[i].downloadUrl);
      const blob = await response.blob();

      zip.file(
        `${zipData.clientName}->${zipData.projectName}->${zipData.interiorName}->${apartmentInteriorData[i].apartmentName}->${apartmentInteriorData[i].apartmentInteriorName}->${i}.jpg`,
        blob
      );
    }

    const zipBlob = await zip.generateAsync({ type: "blob" });
    saveAs(
      zipBlob,
      `${zipData.clientName}->${zipData.projectName}->${zipData.interiorName}->${zipData.tower}`
    );
    if (zipBlob) {
      downloadButton.innerHTML = "Download";
    }
  };

  zipImages();
});

// Download Floor Plan

const downloadFloorPlanButton = document.getElementById("download-floor-plan");

downloadFloorPlanButton.addEventListener("click", () => {
  const downloadFloorPlan = async () => {
    const response = await fetch(imageUrl);
    const blob = await response.blob();

    const filename = `${zipData.clientName}->${zipData.projectName}->${zipData.interiorName}->Floor-Plan.jpg`;

    saveAs(blob, filename);
  };

  downloadFloorPlan();
});
