let towerName;
let floorName;
let pannellumViewer;
let apartmentText;
let apartmentInteriorText;

let logoData;

apartmentText = document.getElementById("towertext");
apartmentText.innerHTML = panellumData[0].name;

apartmentInteriorText = document.getElementById("floortext");
apartmentInteriorText.innerHTML = panellumData[0].floors[0].name;

logoData = imageData.find((item) => item.imageType);
const topRightImage = document.getElementById("topRightImage");
const transitionImage = document.getElementById("transition-image");

if (logoData) {
  topRightImage.innerHTML = `<img src="${logoData.viewUrl}" crossorigin="anonymous">`;
  transition.innerHTML = `<img src="${logoData.viewUrl}" crossorigin="anonymous">`;
} else if (!logoData) {
  transitionImage.setAttribute("src", "/assets/constra.png");
}

const topLeftImage = document.getElementById("topLeftImage");
topLeftImage.addEventListener("click", () => {
  window.open("https://constra.huviair.com", "_blank");
});

initializePannellumViewer();

function initializePannellumViewer() {
  pannellumViewer = pannellum.viewer("panorama", {
    default: {
      sceneFadeDuration: 1000,
      showFullscreenCtrl: false,
      showZoomCtrl: false,
      showControls: false,
      compass: true,
      compassCircleSize: 0.6,
      compassHeight: 32,
      compassNorthOffset: 0,
      compassWidth: 32,
      loadButton: true,
      startAutorotate: false,
      autoRotate: -2,
      hfov: 120,
    },
    scenes: {},
    type: "equirectangular",
    autoLoad: true,
  });

  panellumData.forEach((tower) => {
    tower.floors.forEach((floor) => {
      const { imageId, image } = floor;
      pannellumViewer.addScene(imageId, {
        panorama: image,
      });
    });
  });

  const imageId = panellumData[0].floors[0].imageId;

  pannellumViewer.loadScene(imageId);

  return pannellumViewer;
}

const floorButtons = document.querySelectorAll(".dropdown-content-btn");
const towerButtons = document.querySelectorAll(".dropbtn");

towerButtons.forEach((button) => {
  button.addEventListener("mouseenter", (event) => {
    const tower = event.target.innerText;
    towerName = tower;
  });
});

floorButtons.forEach((button) => {
  button.addEventListener("click", (event) => {
    const floor = event.target.innerText;
    floorName = floor;
    apartmentInteriorText.innerText = floor;
    apartmentText.innerText = towerName;

    panellumData.forEach((el) => {
      if (towerName === el.name) {
        el.floors.forEach((floor) => {
          if (floor.name === floorName) {
            pannellumViewer.loadScene(floor.imageId);
          }
        });
      }
    });
  });
});

window.addEventListener("load", function () {
  const transition = document.getElementById("transition");
  setTimeout(function () {
    transition.classList.add("hide");
    transition.style.display = "none";
  }, 2000);
});

const viewer = document.getElementById("panorama");
let clickTimeout;

viewer.addEventListener("click", () => {
  clearTimeout(clickTimeout);

  clickTimeout = setTimeout(() => {
    pannellumViewer.startAutoRotate(-2);
  }, 5000);
});

// Show Tower buttons on Click

const displayTowerButtonsArrowIcon = document.getElementById(
  "Show-buttons-arrow-icon"
);

const towerButtonsElement = document.getElementById("image-buttons");

let towerButtonsVisible = true;
displayTowerButtonsArrowIcon.addEventListener("click", () => {
  if (towerButtonsVisible) {
    towerButtonsVisible = false;
    towerButtonsElement.style.display = "none";
    displayTowerButtonsArrowIcon.className =
      "fas fa-chevron-up Show-buttons-arrow-icon";
  } else {
    towerButtonsVisible = true;
    towerButtonsElement.style.display = "";
    displayTowerButtonsArrowIcon.className =
      "fas fa-chevron-down Show-buttons-arrow-icon";
  }
});

const downloadButton = document.getElementById("download-button");

downloadButton.addEventListener("click", () => {
  downloadButton.innerHTML = "Downloading...";
  downloadButton.style.width = "110px";

  const zipImages = async () => {
    const zip = new JSZip();

    for (let i = 0; i < imageData.length; i++) {
      const response = await fetch(imageData[i].downloadUrl);
      const blob = await response.blob();

      if (imageData[i].towerName === "360 View") {
        zip.file(
          `${zipData.clientName}->${zipData.projectName}->${zipData.interiorName}->${imageData[i].apartmentName}-> ${imageData[i].towerName}->${imageData[i].floorName}->${i}.jpg`,
          blob
        );
      } else if (imageData[i].imageType === "Client Logo") {
        zip.file(
          `${zipData.clientName}->${zipData.projectName}->${zipData.interiorName}->${imageData[i].apartmentName}-> ${imageData[i].imageType}->${imageData[i].floorName}->${i}.jpg`,
          blob
        );
      } else {
        zip.file(
          `${zipData.clientName}->${zipData.projectName}->${zipData.interiorName}->${imageData[i].apartmentName}->${imageData[i].floorName}->${i}.jpg`,
          blob
        );
      }
    }

    const zipBlob = await zip.generateAsync({ type: "blob" });
    saveAs(
      zipBlob,
      `${zipData.clientName}->${zipData.projectName}->${zipData.interiorName}->${zipData.tower}`
    );
    if (zipBlob) {
      downloadButton.innerHTML = "Download";
    }
  };

  zipImages();
});
