const express = require("express");
const router = express.Router();
const fs = require("fs");
const EquirectangularImage = require("../../models/EquirectangularImage");
const { uploadFile, deletedFile } = require("../../services/upload360Image");
const { getAzureSASToken } = require("../../services/azure-blob");

router.get("/v1/health", async (req, res, next) => {
  res.json({
    status: "Healthy",
    error: null,
    uptime: process.uptime(),
    date: new Date(),
  });
});

router.get("/:interiorId/:projectId/get360ImageData", async (req, res) => {
  const interiorId = req.params.interiorId;
  const projectId = req.params.projectId;

  try {
    const count = await EquirectangularImage.countDocuments({
      interiorId: interiorId,
      projectId: projectId,
    });
    if (count > 0) {
      const data = await EquirectangularImage.find({
        interiorId: interiorId,
        projectId: projectId,
      });
      res.json({ EquirectangularImageData: data });
    } else {
      res.json({ EquirectangularImageData: [] });
    }
  } catch (err) {
    res.sendStatus(401);
  }
});

router.post("/upload360ViewerImage", async (req, res) => {
  const imageData = JSON.parse(req.body.imageData);
  const floorOrderArray = imageData.floorOrder;
  const interiorId = req.body.interiorId;
  const projectId = req.body.projectId;
  const interiorName = req.body.interiorName;
  const projectName = req.body.projectName;
  const clientName = req.body.clientName;
  const tower = req.body.towerName;
  const apartmentName = imageData.apartmentName;
  const bucketName = process.env.AWS_BUCKET_NAME;

  const { tempFilePath: filePath } = req.files.file;
  const {
    fileObjectId: fileObjectId,
    towerName: towerName,
    floorName: floorName,
  } = imageData;

  const newFileName = fileObjectId;

  const { imageViewURL, imageDownloadURL } = await uploadFile(
    filePath,
    newFileName,
    bucketName
  );

  await EquirectangularImage.find({
    projectId: req.body.projectId,
    interiorId: interiorId,
  })
    .then((data) => {
      if (data.length !== 0) {
        let imageDataArray = [];
        let newDataArray = [];
        let newImageDataObject = {};

        data[0].imageData.forEach((data) => {
          imageDataArray.push(data);
        });

        if (imageData.imageType === "Client Logo") {
          newImageDataObject = {
            imageType: imageData.imageType,
            floorName: floorName,
            fileObjectId: newFileName,
            viewUrl: imageViewURL,
            downloadUrl: imageDownloadURL,
            apartmentName: apartmentName,
          };
        } else if (imageData.apartmentInteriorName) {
          const apartmentInteriorName = imageData.apartmentInteriorName;
          newImageDataObject = {
            towerName: towerName,
            floorName: floorName,
            fileObjectId: newFileName,
            viewUrl: imageViewURL,
            downloadUrl: imageDownloadURL,
            apartmentName: apartmentName,
            apartmentInteriorName: apartmentInteriorName,
            floorPlanDetails: {
              floorPlanMarkerLatitude:
                imageData.floorPlanDetails.floorPlanMarkerLatitude,
              floorPlanMarkerLongitude:
                imageData.floorPlanDetails.floorPlanMarkerLongitude,
              floorPlanBlobId: imageData.floorPlanDetails.floorPlanBlobId,
            },
          };
        } else {
          newImageDataObject = {
            towerName: towerName,
            floorName: floorName,
            fileObjectId: newFileName,
            viewUrl: imageViewURL,
            downloadUrl: imageDownloadURL,
            apartmentName: apartmentName,
          };
        }

        imageDataArray.push(newImageDataObject);

        if (
          imageData.imageType !== "Client Logo" &&
          !imageData.apartmentInteriorName
        ) {
          newDataArray = imageDataArray.sort((a, b) => {
            const indexA = floorOrderArray.indexOf(a.floorName);
            const indexB = floorOrderArray.indexOf(b.floorName);
            return indexA - indexB;
          });
        } else {
          newDataArray = imageDataArray;
        }

        EquirectangularImage.findOneAndUpdate(
          { projectId: req.body.projectId, interiorId: interiorId },
          {
            $set: {
              imageData: newDataArray,
            },
          },
          {
            new: true,
          }
        ).then((updatedData) => {
          if (updatedData) {
            res.send(updatedData);
          } else {
            res.sendStatus(401);
          }
        });
      } else {
        let newFile;
        if (imageData.apartmentInteriorName) {
          newFile = new EquirectangularImage({
            interiorId: interiorId,
            projectId: projectId,
            clientName: clientName,
            projectName: projectName,
            interiorName: interiorName,
            tower: tower,
            imageData: [
              {
                towerName: towerName,
                floorName: floorName,
                fileObjectId: newFileName,
                viewUrl: imageViewURL,
                downloadUrl: imageDownloadURL,
                apartmentName: apartmentName,
                apartmentInteriorName: imageData.apartmentInteriorName,
                floorPlanDetails: {
                  floorPlanMarkerLatitude:
                    imageData.floorPlanDetails.floorPlanMarkerLatitude,
                  floorPlanMarkerLongitude:
                    imageData.floorPlanDetails.floorPlanMarkerLongitude,
                  floorPlanBlobId: imageData.floorPlanDetails.floorPlanBlobId,
                },
              },
            ],
          });
        } else {
          newFile = new EquirectangularImage({
            interiorId: interiorId,
            projectId: projectId,
            clientName: clientName,
            projectName: projectName,
            interiorName: interiorName,
            tower: tower,
            imageData: [
              {
                towerName: towerName,
                floorName: floorName,
                fileObjectId: newFileName,
                viewUrl: imageViewURL,
                downloadUrl: imageDownloadURL,
                apartmentName: apartmentName,
              },
            ],
          });
        }

        newFile.save().then((savedData) => {
          if (savedData) {
            res.send(savedData);
          } else {
            res.sendStatus(401);
          }
        });
      }
    })
    .catch((err) => {
      res.sendStatus(401);
      console.error(err);
    });
  fs.unlinkSync(filePath);
});

router.delete(
  "/:interiorId/:projectId/:fileObjectId/deleteImageData",
  async (req, res) => {
    const fileObjectId = req.params.fileObjectId;

    const deleteParams = {
      Bucket: process.env.AWS_BUCKET_NAME,
      Key: fileObjectId,
    };

    const { deletedFileData } = await deletedFile(deleteParams);

    const updatedImageData = await EquirectangularImage.findOneAndUpdate(
      {
        projectId: req.params.projectId,
        interiorId: req.params.interiorId,
        "imageData.fileObjectId": req.params.fileObjectId,
      },
      {
        $pull: {
          imageData: {
            fileObjectId: req.params.fileObjectId,
          },
        },
      },
      { new: true }
    );

    if (updatedImageData) {
      res.json({ EquirectangularImageData: updatedImageData });
    } else {
      res.sendStatus(401);
    }
  }
);

router.get("/:interiorId/:projectId/viewer", async (req, res) => {
  const interiorId = req.params.interiorId;
  const projectId = req.params.projectId;

  let zipFileData;
  let imageData;
  let viewData;

  const equirectangularImageData = await EquirectangularImage.find({
    projectId: projectId,
    interiorId: interiorId,
  });

  if (equirectangularImageData.length !== 0) {
    zipFileData = equirectangularImageData[0].toObject();
    const data = equirectangularImageData[0].imageData.toObject();
    imageData = data;

    const panellumData = imageData.reduce((acc, curr) => {
      const towerIndex = acc.findIndex((item) => item.name === curr.towerName);
      if (towerIndex === -1) {
        acc.push({
          name: curr.towerName,
          floors: [
            {
              name: curr.floorName,
              image: curr.viewUrl,
              imageId: curr.fileObjectId,
            },
          ],
        });
      } else {
        acc[towerIndex].floors.push({
          name: curr.floorName,
          image: curr.viewUrl,
          imageId: curr.fileObjectId,
        });
      }
      return acc;
    }, []);

    const filteredTransformedData = panellumData.filter((element) => {
      return element.name !== undefined;
    });

    filteredTransformedData.sort(function (a, b) {
      if (a.name === "360 View") return 1;
      if (b.name === "360 View") return -1;
      return a.name.localeCompare(b.name, undefined, {
        numeric: true,
        sensitivity: "base",
      });
    });

    viewData = filteredTransformedData;

    if (viewData.length !== 0 && imageData.length !== 0) {
      res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
      res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
      res.render("index.ejs", { viewData, imageData, zipFileData });
    } else {
      res.render("index-error.ejs", { zipFileData });
    }
  }
});

router.get(
  "/:interiorId/:projectId/:apartmentName/apartmentViewer",
  async (req, res) => {
    const interiorId = req.params.interiorId;
    const projectId = req.params.projectId;
    const apartmentName = req.params.apartmentName;

    let zipFileData;
    let imageData;
    let apartmentInteriorData;

    const equirectangularImageData = await EquirectangularImage.find({
      projectId: projectId,
      interiorId: interiorId,
    });

    if (equirectangularImageData.length !== 0) {
      zipFileData = equirectangularImageData[0].toObject();
      const data = equirectangularImageData[0].imageData.toObject();
      imageData = data;

      const interiorData = [];

      imageData.forEach((element) => {
        if (
          element.apartmentInteriorName &&
          element.apartmentName === apartmentName
        ) {
          interiorData.push(element);
        }
      });

      apartmentInteriorData = interiorData;
      const azureSASDetails = getAzureSASToken(
        process.env.AZURE_BLOB_CONTAINER_NAME
      );

      const azureSasToken = azureSASDetails.sasToken;
      const azureBlobContainer = azureSASDetails.blobContainer;

      if (imageData.length !== 0 && apartmentInteriorData.length !== 0) {
        res.setHeader("Cross-Origin-Embedder-Policy", "credentialless");
        res.setHeader("Cross-Origin-Opener-Policy", "cross-origin");
        res.render("index-apartmentInterior.ejs", {
          imageData,
          zipFileData,
          apartmentInteriorData,
          azureSasToken,
          azureBlobContainer,
        });
      } else {
        res.render("index-error.ejs", { zipFileData });
      }
    }
  }
);

router.put("/:interiorId/:projectId/floorPlanLocation", async (req, res) => {
  const interiorId = req.params.interiorId;
  const projectId = req.params.projectId;

  const apartmentInteriorMarkerLocation =
    req.body.apartmentInteriorMarkerLocation;

  await EquirectangularImage.findOneAndUpdate(
    {
      projectId: projectId,
      interiorId: interiorId,
      imageData: {
        $elemMatch: {
          apartmentName: apartmentInteriorMarkerLocation.apartmentName,
          apartmentInteriorName:
            apartmentInteriorMarkerLocation.apartmentInteriorName,
        },
      },
    },
    {
      $set: {
        "imageData.$.floorPlanDetails.floorPlanMarkerLatitude":
          apartmentInteriorMarkerLocation.latitude,
        "imageData.$.floorPlanDetails.floorPlanMarkerLongitude":
          apartmentInteriorMarkerLocation.longitude,
      },
    },
    {
      new: true,
    }
  ).then((updatedData) => {
    if (updatedData) {
      res.send(updatedData);
    } else {
      res.sendStatus(401);
    }
  });
});

module.exports = router;
