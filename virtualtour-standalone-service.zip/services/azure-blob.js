const {
  generateBlobSASQueryParameters,
  ContainerSASPermissions,
  StorageSharedKeyCredential,
} = require("@azure/storage-blob");
require("dotenv").config();

const getAzureSASToken = (
  container,
  permissionString = "r",
  endTimeInSeconds = 3600
) => {
  const sharedKeyCredential = new StorageSharedKeyCredential(
    process.env.AZURE_BLOB_ACCOUNT_NAME,
    process.env.AZURE_BLOB_ACCOUNT_KEY
  );

  const sasOptions = {
    containerName: container,
    permissions: ContainerSASPermissions.parse(permissionString),
    startsOn: new Date(new Date().valueOf() - 300 * 1000),
    expiresOn: new Date(new Date().valueOf() + (endTimeInSeconds - 300) * 1000),
  };

  const sasToken = generateBlobSASQueryParameters(
    sasOptions,
    sharedKeyCredential
  ).toString();

  const blobContainer = process.env.AZURE_FLOOR_PLAN_BLOB_CONTAINER;

  return { sasToken, blobContainer };
};

module.exports = {
  getAzureSASToken: getAzureSASToken,
};
