const { fileUpload, deleteFile } = require("./utility");

const uploadFile = async (filePath, filename, bucketName) => {
  const uploadedFile = await fileUpload(filePath, filename, bucketName);

  const imageViewURL = `https://${bucketName}.s3.${process.env.AWS_REGION}.amazonaws.com/${filename}`;
  const imageDownloadURL = `https://s3-${process.env.AWS_REGION}.amazonaws.com/${bucketName}/${filename}`;

  return {
    uploadedFile,
    imageViewURL,
    imageDownloadURL,
  };
};

const deletedFile = async (deleteParams) => {
  const deletedFile = await deleteFile(deleteParams);
  return { deletedFile };
};

module.exports = { uploadFile, deletedFile };
