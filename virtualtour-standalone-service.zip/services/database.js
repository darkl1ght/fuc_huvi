const mongoose = require("mongoose");

const mongooseOptions = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
};
const connectToMongoDB = async () => {
  try {
    await mongoose.connect(`${process.env.MONGO_URL_DEV}`, mongooseOptions);
    console.log("Connected to MongoDB");
  } catch (err) {
    console.error(err);
  }
  mongoose.set("debug", true);
};

module.exports = connectToMongoDB;
