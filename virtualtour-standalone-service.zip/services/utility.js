const aws = require("aws-sdk");
const fs = require("fs");

const getS3Client = () => {
  const region = process.env.AWS_REGION;
  const accessKeyId = process.env.AWS_ACCESS_KEY_ID;
  const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;

  const s3 = new aws.S3({
    region,
    accessKeyId,
    secretAccessKey,
  });

  return s3;
};

const fileUpload = async (file, filename, bucketName) => {
  const s3 = getS3Client();
  const fileContent = fs.readFileSync(file);

  const uploadParams = {
    Bucket: bucketName,
    Key: filename,
    Body: fileContent,
    ContentType: "image/jpeg",
  };

  try {
    const data = await s3.upload(uploadParams).promise();
    console.log("File uploaded successfully:", data.Location);
    return data.Location;
  } catch (err) {
    console.log("Error uploading file:", err);
    return err;
  }
};

const deleteFile = async (deleteParams) => {
  const s3 = getS3Client();

  s3.deleteObject(deleteParams, function (err, data) {
    if (err) {
      console.log("Error deleting object:", err);
      return err;
    } else {
      console.log("Object deleted successfully:", data);
      return data;
    }
  });
};

module.exports = {
  fileUpload,
  deleteFile,
};
