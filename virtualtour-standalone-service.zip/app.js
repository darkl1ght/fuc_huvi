const helmet = require("helmet");
const cors = require("cors");
const express = require("express");
const bodyParser = require("body-parser");
const fileUpload = require("express-fileupload");
const morgan = require("morgan");
const connectToMongoDb = require("./services/database");
const userRoutes = require("./routes/api/upload360Image");
const path = require("path");
require("dotenv").config();

const app = express();

// Middleware
app.use(express.json());

// set security HTTP headers
app.use(helmet());

// parse urlencoded request body
app.use(express.urlencoded({ extended: true }));

// enable cors
app.use(cors());

app.options(
  "*",
  cors({
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));

//set view engine

app.set("view engine", "ejs");

//mime type

app.use(
  express.static(path.join(__dirname, "public"), {
    setHeaders: (res, path, stat) => {
      if (path.endsWith(".css")) {
        res.set("Content-Type", "text/css");
      }
    },
  })
);

app.use(
  helmet.contentSecurityPolicy({
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: [
        "'self'",
        "https://cdn.pannellum.org",
        "https://cdn.jsdelivr.net",
        "'nonce-12345'",
      ],
      styleSrc: ["'self'", "https://cdn.pannellum.org"],
      imgSrc: ["'self'", "https://cdn.pannellum.org"],
      connectSrc: ["'self'", "https://cdn.pannellum.org"],
      fontSrc: ["'self'", "https://cdn.pannellum.org"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: [],
    },
  })
);

app.use(function (req, res, next) {
  res.setHeader(
    "Content-Security-Policy",
    "script-src 'self' https://cdn.pannellum.org https://cdn.jsdelivr.net 'nonce-12345'"
  );
  return next();
});

//handling file upload

app.use(
  fileUpload({
    useTempFiles: true,
    limits: {
      fileSize: 10 * 1024 * 1024 * 1024,
    },
  })
);

app.use(morgan("tiny"));

//connect to MongoDB

connectToMongoDb();

// Routes
app.use("/", userRoutes);

app.get("*", (req, res) => {
  res.render("index-anonymous.ejs");
});

// Start server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Listening on port ${port}...`);
});
