import express from "express";
import { SecurityController } from "../../../controllers";

const router = express.Router();

router.delete("/user/:userId", SecurityController.deleteRequest);
router.post("/users/login", SecurityController.postRequest);
router.post("/users/:projectId", SecurityController.postRequest);

export { router };
