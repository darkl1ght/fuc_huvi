import express from "express";
import { router as UsersRoute } from "./users";
import { router as ObscureRoute } from "./obscure";
import { router as ProfileRoute } from "./profiles";
import { SecurityController } from "../../../controllers";

const router = express.Router();

router.use("/", UsersRoute);
router.use("/obscure", ObscureRoute);
router.use("/profiles", ProfileRoute);
router.get("/health", SecurityController.getRequest);

export { router as SecurityRoute };
