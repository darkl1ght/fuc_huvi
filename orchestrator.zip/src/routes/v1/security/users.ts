import express from "express";
import { SecurityController } from "../../../controllers";
import { accessControl } from "../../../middlewares/accessControl";
import { projectUser } from "../../../middlewares/projectUser";
import { constants } from "../../../config/constants";
import { auth } from "../../../middlewares/auth";

const router = express.Router();

router.get("/user", SecurityController.getRequest);
router.put("/user", SecurityController.putRequest);
router.post("/users/login", SecurityController.postRequest);
router.post("/users", SecurityController.postRequest);
router.post("/users/forgot", SecurityController.postRequest);
router.post("/users/register", SecurityController.postRequest);
router.post("/users/confirm", SecurityController.postRequest);
router.post(
  "/users/admin/setpassword",
  auth(),
  accessControl(
    constants.accessObjectKeys.TEAMS_RESET_PASSWORD,
    constants.accessControlConfig.projectIdParamMode.BODY,
    "projectId"
  ),
  projectUser(
    constants.accessControlConfig.projectIdParamMode.BODY,
    "projectId"
  ),
  SecurityController.postRequest
);
router.post("/users/resend-email", SecurityController.postRequest);

export { router };
