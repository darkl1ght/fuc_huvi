import express from "express";
import { SecurityController } from "../../../controllers";

const router = express.Router();

router.get("/:username", SecurityController.getRequest);

export { router };
