import express from "express";
import { ProjectController } from "../../controllers";
import { SecurityRoute } from "./security";
import { DocsRoute } from "./docs.route";
import { ContentDataRoute } from "./contentdata.route";
import { ProjectRoute } from "./project";
import { config } from "../../config/config";

const router = express.Router();

router.use("/security/api", SecurityRoute);
router.use("/project/api", ProjectRoute);
router.get("/project/health", ProjectController.getRequest);
router.use("/contentdata", ContentDataRoute);

const devRoutes = [
  // routes available only in development mode
  {
    path: "/docs",
    route: DocsRoute,
  },
];

/* istanbul ignore next */
if (config.env === "development") {
  devRoutes.forEach((route) => {
    router.use(route.path, route.route);
  });
}

/* istanbul ignore next */
router.get("/health", (req, res) => {
  const data = {
    uptime: process.uptime(),
    message: "ok",
    date: new Date(),
  };

  res.status(200).send(data);
});

export { router as routes };
