import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.get("/:projectId/", ProjectController.getRequest);
router.post("/:projectId/", ProjectController.postRequest);
router.put("/:project/:inspectionId", ProjectController.putRequest);
router.delete("/:project/:inspectionId", ProjectController.deleteRequest);

export { router };
