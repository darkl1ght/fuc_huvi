import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.get("/lookup/:type", ProjectController.getRequest);

export { router };
