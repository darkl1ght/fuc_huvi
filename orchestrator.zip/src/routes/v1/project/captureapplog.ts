import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.post("/log", ProjectController.postRequest);

export { router };
