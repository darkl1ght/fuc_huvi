import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.post("/", ProjectController.postRequest);
router.get("/clients/:client", ProjectController.getRequest);
router.get("/clients/", ProjectController.getRequest);
router.delete("/:client/", ProjectController.deleteRequest);
router.put("/:client/", ProjectController.putRequest);
router.post("/:client/tatreport/", ProjectController.postRequest);

export { router };
