import express from "express";
import { ProjectController } from "../../../controllers";
import { accessControlAdmin } from "../../../middlewares/accessControlAdmin";
import { auth } from "../../../middlewares/auth";

const router = express.Router();

router.post("/procore/procoretokenexchange", ProjectController.postRequest);
router.post("/procore/refreshprocoretoken", ProjectController.postRequest);
router.get("/procore/getprocorecompanies", ProjectController.getRequest);
router.get(
  "/procore/:company_id/observationtype/getcompanyobservationtypes",
  ProjectController.getRequest
);
router.get(
  "/procore/:companyId/:projectId/getprojectlocations",
  ProjectController.getRequest
);
router.get(
  "/procore/:companyId/:projectId/getprocoreprojectusers",
  ProjectController.getRequest
);
router.get(
  "/procore/:company_id/getcontributingconditions",
  ProjectController.getRequest
);
router.get(
  "/procore/:company_id/getcontributingbehaviors",
  ProjectController.getRequest
);
router.get("/procore/:company_id/gethazards", ProjectController.getRequest);
router.get("/procore/:company_id/gettrades", ProjectController.getRequest);
router.get(
  "/procore/:company_id/:project_id/getspecsections",
  ProjectController.getRequest
);
router.get("/procore/:company_id/getprojects", ProjectController.getRequest);
router.post(
  "/procore/:projectId/linkproject",
  auth(),
  accessControlAdmin,
  ProjectController.postRequest
);
router.get(
  "/procore/:projectId/getlinkedproject",
  ProjectController.getRequest
);

export { router };
