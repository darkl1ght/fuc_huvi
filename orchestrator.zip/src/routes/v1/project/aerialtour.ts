import express from "express";
import { ProjectController } from "../../../controllers";
import { accessControl } from "../../../middlewares/accessControl";
import { constants } from "../../../config/constants";
import { auth } from "../../../middlewares/auth";

const router = express.Router();

router.get("/:project/tour", ProjectController.getRequest);
router.get("/:project/wbs", ProjectController.getRequest);
router.post(
  "/:project/tour",
  auth(),
  accessControl(
    constants.accessObjectKeys.AERIAL_CREATE_TOUR,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.postRequest
);
router.post("/:project/aerialtour/:tour/center", ProjectController.postRequest);
router.put(
  "/:project/aerialtour/statictour/:tour",
  ProjectController.putRequest
);
router.delete(
  "/:project/aerialtour/statictour/:tour/tour/:statictourid",
  ProjectController.deleteRequest
);
router.put(
  "/:project/aerialtour/statictour/:tour/chart",
  ProjectController.putRequest
);
router.delete(
  "/:project/aerialtour/statictour/:tour/removechart/:chartId",
  ProjectController.deleteRequest
);
router.put(
  "/:project/aerialtour/statictour/:tour/publish",
  ProjectController.putRequest
);
router.delete(
  "/:project/aerialtour/:tour",
  auth(),
  accessControl(
    constants.accessObjectKeys.AERIAL_DELETE_TOUR,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.deleteRequest
);
router.put(
  "/:project/aerialtour/:tour",
  auth(),
  accessControl(
    constants.accessObjectKeys.AERIAL_EDIT_TOUR,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
router.put("/:project/aerialtour/status/:tour", ProjectController.putRequest);
router.post("/:project/aerialtour/:tour/image", ProjectController.postRequest);
router.post(
  "/:project/aerialtour/:tour/newannotationtype",
  ProjectController.postRequest
);
router.get(
  "/:project/aerialtour/:tour/annotationtypes",
  ProjectController.getRequest
);
router.get("/:project/aerialtour/:tour/image", ProjectController.getRequest);
router.get("/:project/aerialtour/:tour/chart", ProjectController.getRequest);
router.put("/:project/aerialtour/:tour/chart", ProjectController.putRequest);
router.put(
  "/:project/aerialtour/:tour/removechart",
  ProjectController.putRequest
);
router.put("/:project/aerialtour/:tour/publish", ProjectController.putRequest);
router.get(
  "/:project/aerialtour/:tour/mapboxmap/processingsuccess",
  ProjectController.getRequest
);
router.get(
  "/:project/aerialtour/:tour/mapboxmap/mapurl",
  ProjectController.getRequest
);
router.post(
  "/:project/aerialtour/:tour/mapboxmap/mapurl",
  ProjectController.postRequest
);
router.delete(
  "/:project/aerialtour/:tour/mapboxmap/:id",
  ProjectController.deleteRequest
);
router.get(
  "/:project/aerialtour/:tour/mapboxmap/processingstatus",
  ProjectController.getRequest
);
router.post(
  "/:project/aerialtour/:tour/upload/processingparams",
  ProjectController.postRequest
);
router.get(
  "/:project/aerialtour/:tour/processingparams",
  ProjectController.getRequest
);
router.post("/:project/aerialtour/:tour/volume", ProjectController.postRequest);
router.get("/:project/aerialtour/:tour/volume", ProjectController.getRequest);
router.delete(
  "/:project/aerialtour/:tour/volume/:volumeId",
  ProjectController.deleteRequest
);
router.post(
  "/:project/aerialtour/:tour/elevationprofile",
  ProjectController.postRequest
);
router.get(
  "/:project/aerialtour/:tour/elevationProfile",
  ProjectController.getRequest
);
router.delete(
  "/:project/aerialtour/:tour/elevationprofile/:elevationProfileId",
  ProjectController.deleteRequest
);
router.put(
  "/:project/aerialtour/:tour/threedurl",
  ProjectController.putRequest
);
router.put("/:project/legend/:tour/", ProjectController.putRequest);
router.get("/:project/syncwbsmasterdata/:tour/", ProjectController.getRequest);
router.get("/:project/publishwbstourdata/:tour/", ProjectController.getRequest);
router.post(
  "/:project/aerialTour/notify/:tour",
  auth(),
  accessControl(
    constants.accessObjectKeys.AERIAL_SEND_NOTIFICATION,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.postRequest
);
router.get("/:project/:tour", ProjectController.getRequest);
router.get(
  "/:project/tour/:tour/tower/:towerId/wbs/ext/",
  ProjectController.getRequest
);
router.put(
  "/:project/:tour/ext/wbs/progress/bulk",
  auth(),
  accessControl(
    constants.accessObjectKeys.AERIAL_UPDATE_PROGRESS,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
router.put("/:project/:tour/wbs/:wbsId/ext/", ProjectController.putRequest);
router.get(
  "/:project/:tour/wbs/ext/:tower/chart",
  ProjectController.getRequest
);
router.get(
  "/:project/:tour/wbs/ext/:tower/chart/by-tower",
  ProjectController.getRequest
);
router.post(
  "/:project/aerialtour/:tour/elevation-file-upload/:container",
  ProjectController.postRequest
);
router.delete(
  "/:project/aerialtour/:tour/:container/:filename/delete",
  ProjectController.deleteRequest
);
router.get("/:project/access/self-serve", ProjectController.getRequest);
router.get("/:project/aerialtour/:tour", ProjectController.getRequest);
router.put(
  "/:project/aerialtour/tour/:tour/remarks",
  ProjectController.putRequest
);
router.put(
  "/:project/aerialtour/tour/:tour/removeremark",
  ProjectController.putRequest
);
router.put(
  "/:project/aerialtour/tour/:tour/editRemark",
  ProjectController.putRequest
);
router.put(
  "/:project/aerialtour/tour/:tour/editPunchItem",
  ProjectController.putRequest
);
router.post(
  "/:project/aerialtour/tour/:tour/polygonRemarks",
  ProjectController.postRequest
);
router.put(
  "/:project/aerialtour/tour/:tour/punchItemMarkers",
  ProjectController.putRequest
);
router.put(
  "/:project/aerialtour/tour/:tour/polygonPunchItemMarkers",
  ProjectController.putRequest
);
router.delete(
  "/:project/aerialtour/tour/:tour/:punchMarkerId",
  ProjectController.deleteRequest
);
router.put(
  "/:project/restore/ext/tour/:tour/:towerId/",
  auth(),
  accessControl(
    constants.accessObjectKeys.AERIAL_SYNC_WBS,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
router.get("/:project/exportchartdata/ext", ProjectController.getRequest);
router.put(
  "/:project/tour/:tour/pointcloudobjectcount",
  ProjectController.putRequest
);
router.put(
  "/:project/aerialtour/tour/:tour/updateLatLng",
  ProjectController.putRequest
);
router.put(
  "/:project/aerialtour/tour/:tour/updateMapboxLayerOrder",
  ProjectController.putRequest
);
router.put(
  "/:project/aerialtour/:tour/droneflightdata",
  ProjectController.putRequest
);
router.delete(
  "/:project/aerialtour/:tour/droneflightdata",
  ProjectController.deleteRequest
);
router.put(
  "/:project/aerialtour/:tour/droneflightvideo",
  ProjectController.putRequest
);
router.delete(
  "/:project/aerialtour/:tour/droneflightvideo",
  ProjectController.deleteRequest
);
router.put(
  "/:project/aerialtour/:tour/shapefileColor",
  ProjectController.putRequest
);

router.delete(
  "/:project/aerialtour/:tour/deleteTourImages",
  ProjectController.deleteRequest
);

router.post(
  "/:project/aerialTour/emailnotify/:tour",
  auth(),
  accessControl(
    constants.accessObjectKeys.AERIAL_SEND_NOTIFICATION,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.postRequest
);
router.put(
  "/:project/aerialtour/:tour/tags",
  auth(),
  ProjectController.putRequest
);
router.post(
  "/:project/aerialtour/:tour/saveannotationtypetoproject",
  ProjectController.postRequest
);
router.post(
  "/:project/aerialtour/:tour/saveannotationtypetoallprojects",
  ProjectController.postRequest
);
router.get(
  "/:project/aerialtour/:tour/annotationtypesfromproject",
  ProjectController.getRequest
);
router.get("/:project/:tour/status/:status", ProjectController.getRequest);

export { router };
