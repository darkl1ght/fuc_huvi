import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.post("/:project/query/:category", ProjectController.postRequest);
router.post("/:project/querybypage/:category", ProjectController.postRequest);
router.post("/:project/paginate/:category", ProjectController.postRequest);
router.get("/:project/punchitem/:task", ProjectController.getRequest);
router.delete("/:project/punchitem/:task", ProjectController.deleteRequest);
router.post("/:project/", ProjectController.postRequest);
router.put("/:project/punchitem/:task", ProjectController.putRequest);
router.post(
  "/:project/punchitem/:task/savePunchItemAnnotation",
  ProjectController.postRequest
);
router.put("/:project/punchitem/floorplan/:task", ProjectController.putRequest);
router.put("/:project/punchitem/media/:task", ProjectController.putRequest);
router.put("/:project/punchitem/reassign/:task", ProjectController.putRequest);
router.put(
  "/:project/punchitem/resolve/level1/:task",
  ProjectController.putRequest
);
router.put(
  "/:project/punchitem/resolve/level2/:task",
  ProjectController.putRequest
);
router.delete(
  "/:project/punchitem/:task/:mediaId",
  ProjectController.deleteRequest
);
router.put(
  "/:project/punchitem/:task/bulkdeletemedia",
  ProjectController.putRequest
);
router.post("/:project/bulk", ProjectController.postRequest);
router.post("/:project/comment/:task", ProjectController.postRequest);
router.delete(
  "/:project/comment/:task/:commentId",
  ProjectController.deleteRequest
);
router.get("/:project/comment/:task", ProjectController.getRequest);
router.post("/:project/sharereport/:task", ProjectController.postRequest);
router.get("/:project/downloadpdfreport/:task", ProjectController.getRequest);
router.get(
  "/:project/overall/dashboard/workpackage/:type",
  ProjectController.getRequest
);
router.get(
  "/:project/overall/dashboard/location/:type",
  ProjectController.getRequest
);
router.get(
  "/:project/overall/dashboard/status/:type",
  ProjectController.getRequest
);
router.get(
  "/:project/overall/dashboard/priority/:type",
  ProjectController.getRequest
);
router.get(
  "/:project/overall/dashboard/conformity/:type",
  ProjectController.getRequest
);
router.get(
  "/:project/overall/dashboard/overdue/:type",
  ProjectController.getRequest
);
router.get("/:project/dashboard/snagstatistics", ProjectController.getRequest);
router.get("/:projectId/nextseq/:punchListId", ProjectController.getRequest);
router.get("/:projectId/lookup/punchlist", ProjectController.getRequest);
router.post("/:project/aerials/bulk", ProjectController.postRequest);
router.get("/:projectId/punchList/:tourId/", ProjectController.getRequest);

router.get("/:project/onsitetask/all", ProjectController.getRequest);
router.post("/:project/onsitetask", ProjectController.postRequest);
router.delete("/:project/onsitetask/:task", ProjectController.deleteRequest);

export { router };
