import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.post("/generate", ProjectController.postRequest);
router.get("/:shareId", ProjectController.getRequest);

export { router };
