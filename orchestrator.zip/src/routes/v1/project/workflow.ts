import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.get("/:projectId/workflow/", ProjectController.getRequest);
router.get("/:projectId/rfi/", ProjectController.getRequest);
router.post("/:projectId/workflow/", ProjectController.postRequest);
router.delete("/:projectId/:type/:workFlowId", ProjectController.deleteRequest);

export { router };
