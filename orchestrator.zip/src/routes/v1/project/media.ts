import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.get("/:project/album", ProjectController.getRequest);
router.post("/:project/album", ProjectController.postRequest);
router.delete("/:project/album/:album", ProjectController.deleteRequest);
router.put("/:project/album/remove", ProjectController.putRequest);
router.put("/:project/album/:album", ProjectController.putRequest);
router.post("/:project/album/media", ProjectController.postRequest);
router.get("/:project/album/:album", ProjectController.getRequest);
router.delete(
  "/:project/album/:album/media/:media",
  ProjectController.deleteRequest
);
router.put(
  "/:project/album/:album/media/bulkdelete",
  ProjectController.putRequest
);
router.post("/:project/media/:media/comment", ProjectController.postRequest);
router.put(
  "/:project/media/:media/removecomment",
  ProjectController.putRequest
);
router.get("/:project/media/:media/comments", ProjectController.getRequest);
router.put("/:project/media/:album/update", ProjectController.putRequest);
router.post("/:project/media/:media/annotation", ProjectController.postRequest);
router.get("/:project/media/:media/annotation", ProjectController.getRequest);
router.put(
  "/:project/media/:media/annotations/remove",
  ProjectController.putRequest
);
router.put("/:project/media/:media/annotations", ProjectController.putRequest);
router.put("/:project/media/:media/features", ProjectController.putRequest);
router.post("/:project/album/notify", ProjectController.postRequest);
router.get("/vimeo/:vimeoId", ProjectController.getRequest);

export { router };
