import express from "express";
import { ProjectController } from "../../../controllers";
import { accessControl } from "../../../middlewares/accessControl";
import { constants } from "../../../config/constants";
import { auth } from "../../../middlewares/auth";
const router = express.Router();

router.get("/fetch", ProjectController.getRequest);

export { router };
