import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.get("/sas/:container/", ProjectController.getRequest);
router.get("/sas/:container/blob/:blobName", ProjectController.getRequest);
router.get("/sas/read/:container/", ProjectController.getRequest);
router.get("/sas/longRunningTask/:container/", ProjectController.getRequest);

export { router };
