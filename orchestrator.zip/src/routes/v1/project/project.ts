import express from "express";
import { ProjectController } from "../../../controllers";
import { accessControl } from "../../../middlewares/accessControl";
import { constants } from "../../../config/constants";
import { auth } from "../../../middlewares/auth";

const router = express.Router();

router.get("/createAccess", ProjectController.getRequest);
router.get("/logocheck", ProjectController.getRequest);
router.get("/", ProjectController.getRequest);
router.get("/:project/getProjectDataVolume", ProjectController.getRequest);
router.get("/:project/getprojectusers", ProjectController.getRequest);
router.get("/searchbyclientId/:clientId", ProjectController.getRequest);
router.post("/createproject/:clientId", ProjectController.postRequest);
router.post("/", ProjectController.postRequest);
router.get("/projectsAndInteriors", ProjectController.getRequest);
router.get("/:project", ProjectController.getRequest);
router.put("/:project", ProjectController.putRequest);
router.delete("/:project", ProjectController.deleteRequest);
router.get("/:project/users", ProjectController.getRequest);
router.put(
  "/:project/users/:user",
  auth(),
  accessControl(
    constants.accessObjectKeys.TEAMS_EDIT_USER,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
router.put(
  "/:project/user/blockunblock",
  auth(),
  accessControl(
    constants.accessObjectKeys.TEAMS_BLOCK_USER,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
router.put("/:project/users/:user/signature", ProjectController.putRequest);
router.post(
  "/:project/users",
  auth(),
  accessControl(
    constants.accessObjectKeys.TEAMS_ADD_USER,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.postRequest
);
router.delete(
  "/:project/users/:user",
  auth(),
  accessControl(
    constants.accessObjectKeys.TEAMS_DELETE_USER,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.deleteRequest
);
router.get("/:project/documents", ProjectController.getRequest);
router.post("/:project/documents", ProjectController.postRequest);
router.delete("/:project/documents/:document", ProjectController.deleteRequest);
router.put("/:project/documents/:document", ProjectController.putRequest);
router.post("/:project/livestream", ProjectController.postRequest);
router.delete("/:project/livestream/:device", ProjectController.deleteRequest);
router.get("/:project/livestream/devices", ProjectController.getRequest);
router.get("/:project/templateforusers", auth(), ProjectController.getRequest);
router.post("/:project/bulkuploadusers", auth(), ProjectController.postRequest);

export { router };
