import express from "express";
import { router as InteriorRoute } from "./interior";
import { router as VideoCaptureRoute } from "./videocapture";
import { router as FieldIssueRoute } from "./fieldissue";

const router = express.Router();

router.use("/", InteriorRoute);
router.use("/videocapture", VideoCaptureRoute);
router.use("/fieldissue", FieldIssueRoute);

export { router };
