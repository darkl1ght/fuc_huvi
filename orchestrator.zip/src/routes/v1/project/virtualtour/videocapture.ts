import express from "express";
import { ProjectController } from "../../../../controllers";

const router = express.Router();

router.post(
  "/:project/tour/:tour/start-processing",
  ProjectController.postRequest
);
router.put(
  "/:project/tour/:tour/video-capture-details",
  ProjectController.putRequest
);
router.put("/:project/tour/:tour/capture-points", ProjectController.putRequest);
router.put(
  "/:project/tour/:tour/update-transformations",
  ProjectController.putRequest
);
router.get(
  "/:project/interior/:interiorId/tower/:towerId/get-processing-stats",
  ProjectController.getRequest
);
router.put(
  "/:project/tour/:tour/update-path-coordinates",
  ProjectController.putRequest
);
router.put(
  "/:project/tour/:tour/delete-path-coordinates",
  ProjectController.putRequest
);
router.post(
  "/:project/publish-pending-messages",
  ProjectController.postRequest
);

router.post(
  "/:project/publish-pending-messages-by-tour/:tourId",
  ProjectController.postRequest
);

router.put(
  "/:project/tour/:tour/publish-photo-mode-messages",
  ProjectController.putRequest
);

export { router };
