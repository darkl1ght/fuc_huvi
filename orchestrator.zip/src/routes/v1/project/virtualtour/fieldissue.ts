import express from "express";
import { ProjectController } from "../../../../controllers";

const router = express.Router();

router.post("/:project/:tour/create", ProjectController.postRequest);
router.put("/:project/:tour/update", ProjectController.putRequest);
router.get(
  "/:project/:tour/:towerId/:floorId/list",
  ProjectController.getRequest
);
router.put(
  "/:project/:issueId/downloadpdfreport",
  ProjectController.putRequest
);
router.post(
  "/:project/:tour/:issueId/savemarkerannotation",
  ProjectController.postRequest
);
router.put(
  "/:project/:tour/:towerId/:floorId/:issueId/discussion/:discussionId",
  ProjectController.putRequest
);
router.delete(
  "/:project/:tour/:towerId/:floorId/:issueId/discussion/:discussionId",
  ProjectController.deleteRequest
);

router.get("/:project/:towerId/:floorId/list", ProjectController.getRequest);
export { router };
