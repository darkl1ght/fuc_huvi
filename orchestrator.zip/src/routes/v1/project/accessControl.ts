import express from "express";
import { ProjectController } from "../../../controllers";
import { accessControlAdmin } from "../../../middlewares/accessControlAdmin";
import { auth } from "../../../middlewares/auth";

const router = express.Router();

router.get("/getprojectroles", ProjectController.getRequest);
router.get("/:role/getaccessmapping", ProjectController.getRequest);
router.put(
  "/:role/setaccessmapping",
  auth(),
  accessControlAdmin,
  ProjectController.putRequest
);
router.post(
  "/createaccessmapping",
  auth(),
  accessControlAdmin,
  ProjectController.postRequest
);

//TBD: To be removed
router.post(
  "/:fromrole/:torole/copyaccessmapping",
  auth(),
  accessControlAdmin,
  ProjectController.postRequest
);

//TBD: To be removed
router.post(
  "/createandcopyaccessmapping",
  auth(),
  accessControlAdmin,
  ProjectController.postRequest
);

router.post(
  "/getaccesspointallrolesformat",
  auth(),
  accessControlAdmin,
  ProjectController.postRequest
);

router.put(
  "/addaccesspointallroles",
  auth(),
  accessControlAdmin,
  ProjectController.putRequest
);

router.delete(
  "/removecachekey/:key",
  auth(),
  accessControlAdmin,
  ProjectController.deleteRequest
);

router.get(
  "/getallcachekeys",
  auth(),
  accessControlAdmin,
  ProjectController.getRequest
);

router.post(
  "/setCache",
  auth(),
  accessControlAdmin,
  ProjectController.postRequest
);

router.delete(
  "/:objectkey/remove",
  auth(),
  accessControlAdmin,
  ProjectController.deleteRequest
);

export { router };
