import express from "express";
import { ProjectController } from "../../../controllers";
const router = express.Router();

router.post("/fetchaerialcaptures", ProjectController.postRequest);
router.post("/fetchcapturemetrics", ProjectController.postRequest);
router.post("/fetchcontractdates", ProjectController.postRequest);
router.post("/fetchvirtualcaptures", ProjectController.postRequest);
router.post("/fetchfieldissues", ProjectController.postRequest);
router.post("/fetchwirs", ProjectController.postRequest);
router.post("/fetchpunchlists", ProjectController.postRequest);
router.get("/getclientsbyuser", ProjectController.getRequest);
router.get("/getprojectsbyuser", ProjectController.getRequest);

export { router };
