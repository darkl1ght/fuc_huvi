import express from "express";
import { ProjectController } from "../../../controllers";
import { accessControl } from "../../../middlewares/accessControl";
import { constants } from "../../../config/constants";
import { auth } from "../../../middlewares/auth";

const router = express.Router();

router.get("/:project/createExcel", ProjectController.getRequest);
router.delete(
  "/:project/interior/remove/:towerId/:floorId/:wbsId",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_INTERIOR_DELETE,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.deleteRequest
);
router.delete(
  "/:project/exterior/remove/:towerId/:wbsId",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_EXTERIOR_DELETE,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.deleteRequest
);
router.post(
  "/:project/interior/create/:towerId/:floorId/",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_INTERIOR_ADD,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.postRequest
);
router.post(
  "/:project/exterior/create/:towerId/",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_EXTERIOR_ADD,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.postRequest
);
router.put(
  "/:project/interior/update/:towerId/:floorId/:wbsId",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_INTERIOR_EDIT,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
router.put(
  "/:project/exterior/update/:towerId/:wbsId",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_EXTERIOR_EDIT,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
router.post(
  "/:project/upload",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_BULK_UPLOAD,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.postRequest
);

router.put(
  "/:project/interior/calculateWeightage/:towerId/",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_INTERIOR_CALCULATE_WEIGHTAGE,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
router.put(
  "/:project/performanceindex/:type",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_SCHEDULE_INTERIOR_EDIT,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.putRequest
);
export { router };
