import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.post("/:appType", ProjectController.postRequest);
router.delete("/:appType/:token/:deviceId", ProjectController.deleteRequest);

export { router };
