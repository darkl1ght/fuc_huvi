import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.post("/:project/:tour/", ProjectController.postRequest);
router.get("/:project/:tour/", ProjectController.getRequest);
router.delete("/:project/:tour/:annotationId", ProjectController.deleteRequest);
router.get("/types", ProjectController.getRequest);

export { router };
