import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.get(
  "/:projectId/wbs/int/:towerId/:floorId",
  ProjectController.getRequest
);
router.get("/:projectId/wbs/ext/:towerId/", ProjectController.getRequest);
router.post("/:projectId/wbs/int/", ProjectController.postRequest);
router.post("/:projectId/wbs/ext/", ProjectController.postRequest);
router.delete(
  "/:projectId/wbs/ext/:towerId/remove",
  ProjectController.deleteRequest
);
router.delete(
  "/:projectId/wbs/int/:towerId/:floorId/remove",
  ProjectController.deleteRequest
);
router.put("/:projectId/wbs/ext/publish_wbs", ProjectController.putRequest);
router.put("/:projectId/wbs/int/publish_wbs", ProjectController.putRequest);
router.get("/:projectId/wbs/wbs_publish_status", ProjectController.getRequest);
router.get("/:project/interior/activities", ProjectController.getRequest);
router.get(
  "/:project/interior/activities/:towerId/:floorId/",
  ProjectController.getRequest
);
export { router };
