import express from "express";
import { ProjectController } from "../../../controllers";
import { auth } from "../../../middlewares/auth";
import { accessControl } from "../../../middlewares/accessControl";
import { constants } from "../../../config/constants";

const router = express.Router();

router.get("/oauth/token", ProjectController.getRequest);
router.get("/buckets/list", ProjectController.getRequest);
router.get("/buckets/details/:bucketkey", ProjectController.getRequest);
router.post("/buckets/:project/create", ProjectController.postRequest);
router.delete("/buckets/delete/:project", ProjectController.deleteRequest);
router.post(
  "/buckets/:project/:locationId/upload/objects",
  auth(),
  accessControl(
    constants.accessObjectKeys.WORK_LOCATION_UPLOAD_BIM_MODEL,
    constants.accessControlConfig.projectIdParamMode.PARAM,
    "project"
  ),
  ProjectController.postRequest
);
router.delete(
  "/buckets/:project/:locationId/delete/objects",
  ProjectController.deleteRequest
);
router.post("/jobs/:project/:locationId", ProjectController.postRequest);
router.get("/translate/status/:urn", ProjectController.getRequest);

export { router };
