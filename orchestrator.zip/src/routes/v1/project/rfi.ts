import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.get("/:project/", ProjectController.getRequest);
router.get("/:project/rfino/", ProjectController.getRequest);
router.post("/:project/", ProjectController.postRequest);
router.put("/:project/:rfiId", ProjectController.putRequest);
router.put("/:project/:rfiId/:type", ProjectController.putRequest);
router.delete("/:project/:rfiId", ProjectController.deleteRequest);
router.put(
  "/:project/:rfiId/assessment/:questionId",
  ProjectController.putRequest
);
router.delete(
  "/:project/:rfiId/assessment/:questionId/:imageId",
  ProjectController.deleteRequest
);
router.get("/:project/downloadpdfreport/:rfi", ProjectController.getRequest);
router.post(
  "/:project/:rfiId/:questionId/:blobContentId/savemarkerannotation",
  ProjectController.postRequest
);
export { router };
