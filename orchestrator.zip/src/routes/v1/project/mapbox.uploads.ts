import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.post("/:project/:tour/:type", ProjectController.postRequest);

export { router };
