import express from "express";
import { ProjectController } from "../../../controllers";

const router = express.Router();

router.get("/:project/daystocomplete/:towerId", ProjectController.getRequest);

router.put("/:project/cardview", ProjectController.putRequest);

router.get(
  "/:project/alltasks/d3donut/:assignee",
  ProjectController.getRequest
);

router.get(
  "/:project/:taskType/chart/:chartType/:assignee",
  ProjectController.getRequest
);

router.get("/:project/latest/readytour", ProjectController.getRequest);

router.post("/:project/alltasks/list", ProjectController.postRequest);

export { router };
