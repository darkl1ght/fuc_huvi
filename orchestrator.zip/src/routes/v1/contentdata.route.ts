import express from "express";
import { ContentDataController } from "../../controllers";
import { auth } from "../../middlewares/auth";
const router = express.Router();
//cabinet routes
router.post("/cabinet/create", auth(), ContentDataController.createCabinet);
router.put(
  "/cabinet/:cabinetId",
  auth(),
  ContentDataController.updateCabinetById
);
router.get("/cabinet/all", auth(), ContentDataController.getAllCabinetsByAppId);
router.get("/cabinet/:cabinetId", auth(), ContentDataController.getCabinetById);
router.delete(
  "/cabinet/:cabinetId",
  auth(),
  ContentDataController.deleteCabinetById
);
router.post(
  "/cabinet/constraCompanySetUp",
  auth(),
  ContentDataController.constraCompanySetUp
);
router.get(
  "/cabinet/:companyId/:moduleName",
  auth(),
  ContentDataController.getCabinetByModuleAndCompanyId
);
//folder routes
router.post("/folder", auth(), ContentDataController.createFolder);
router.post(
  "/folder/createFoldersByFolderPath",
  auth(),
  ContentDataController.createFoldersByFolderPath
);
router.put("/folder/:folderId", auth(), ContentDataController.updateFolder);
router.get(
  "/folder/:parentFolderRefId/subfolders",
  auth(),
  ContentDataController.getSubFolders
);
router.get("/folder/:folderId", auth(), ContentDataController.getFolder);
router.get(
  "/folder/:cabinetRefId/root",
  auth(),
  ContentDataController.getRootFolders
);
router.put(
  "/folder/:folderId/delete",
  auth(),
  ContentDataController.deleteFolder
);

router.put(
  "/folder/delete/bulk",
  auth(),
  ContentDataController.deleteFolderBulk
);

router.get(
  "/folder/:companyId/:projectId/:moduleName",
  auth(),
  ContentDataController.getProjectFolder
);

router.post(
  "/folder/projectFolders",
  auth(),
  ContentDataController.createProjectFolders
);
router.get(
  "/folder/:parentFolderRefId/contents",
  auth(),
  ContentDataController.getFolderContents
);

router.get(
  "/folder/:parentFolderRefId/tree",
  auth(),
  ContentDataController.getFolderTree
);

router.get(
  "/folder/:companyId/:projectId/:moduleName/tree",
  auth(),
  ContentDataController.getProjectFolderTree
);

router.post(
  "/folder/getSurveyImageList",
  auth(),
  ContentDataController.getSurveyImageList
);

router.put(
  "/folder/:parentFolderRefId/paginate",
  auth(),
  ContentDataController.getFilesByPagination
);

router.get(
  "/folder/:projectFolderId/:floorId/get/fieldIssuesFolderContents",
  auth(),
  ContentDataController.getFieldIssuesFolderContents
);

//file routes
router.post("/file/create", auth(), ContentDataController.createFile);
router.post(
  "/file/create/bulk",
  auth(),
  ContentDataController.createFileInBulk
);
router.put("/file/update", auth(), ContentDataController.updateFile);
router.put(
  "/file/updateFileName",
  auth(),
  ContentDataController.updateFileName
);
router.put(
  "/file/updateFileStatus",
  auth(),
  ContentDataController.updateFileStatus
);
router.get("/file/:fileId", auth(), ContentDataController.getFile);
router.get(
  "/file/:clientId/:projectId/getProjectDataVolume",
  auth(),
  ContentDataController.getProjectDataVolume
);
router.get(
  "/file/:fileObjectId/fileObjectId",
  auth(),
  ContentDataController.getFileByObjectId
);
router.delete(
  "/file/:fileId/:isSoftDelete?",
  auth(),
  ContentDataController.deleteFile
);

router.put("/file/delete/bulk", auth(), ContentDataController.deleteFileBulk);

router.delete(
  "/file/:fileObjectId/:isSoftDelete?/byObjectId",
  auth(),
  ContentDataController.deleteFileByObjectId
);
router.get(
  "/file/:fileObjectId/:urlExpiresIn/fileUrl",
  auth(),
  ContentDataController.getViewNDownloadFileUrl
);

router.post(
  "/file/createFileVersionUploadUrl",
  auth(),
  ContentDataController.createFileVersionUploadUrl
);

router.post(
  "/file/createAnnotation",
  auth(),
  ContentDataController.createAnnotation
);
router.put(
  "/file/updateAnnotation",
  auth(),
  ContentDataController.updateAnnotation
);
router.get("/file/:fileId/getAnnotation", ContentDataController.getAnnotation);
router.delete(
  "/file/:fileId/:annotationId/removeAnnotation",
  ContentDataController.removeAnnotation
);
router.put(
  "/file/:fileId/updateFeatures",
  ContentDataController.updateFeatures
);
router.get("/file/:fileId/getComments", ContentDataController.getComments);
router.delete(
  "/file/:fileId/:commentId/removeComment",
  ContentDataController.removeComment
);
router.post("/file/:fileId/addComment", ContentDataController.addComment);
router.post(
  "/file/reinitiateVideoProcessing",
  ContentDataController.reinitiateVideoProcessing
);
router.put(
  "/file/updateFileVersion",
  auth(),
  ContentDataController.updateFileVersion
);

router.get(
  "/file/:fileId/:fileObjectId/:fileName/fileDownloadUrl",
  auth(),
  ContentDataController.getFileDownloadUrl
);

router.put(
  "/file/updateFileTags",
  auth(),
  ContentDataController.updateFileTags
);

router.put(
  "/file/updateMedia/bulk",
  auth(),
  ContentDataController.updateMediaInBulk
);

router.put(
  "/folder/:clientId/:projectId/:moduleName/getFilesForFieldIssueFolders",
  auth(),
  ContentDataController.getFilesForFieldIssueFolders
);

export { router as ContentDataRoute };
