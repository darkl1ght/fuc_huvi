import { constants } from "../../src/config/constants";
import { getProjectUsers, getAccessMapping } from "./helper";
import { logger } from "../config/logger";

//Checks whether the current user has access to the project, and the role has access to access point
const accessControl =
  (objectKey: string, projectIdParamMode: string, projectIdParamName: string) =>
  async (req: any, res: any, next: any) => {
    const email = req.payload.email.toLowerCase();
    let projectId: string = "";

    switch (projectIdParamMode) {
      case constants.accessControlConfig.projectIdParamMode.PARAM:
        projectId = req.params[projectIdParamName];
        break;
      case constants.accessControlConfig.projectIdParamMode.BODY:
        projectId = req.body[projectIdParamName];
        break;
    }

    if (projectId) {
      let role: string;

      if (req.payload.isAdmin) {
        role = "Super Admin";

        await getAccessMapping(role, req)
          .then((accessMapping) => {
            if (accessMapping) {
              const objectMapping = accessMapping.accessMapping.find(
                (item: any) => item.objectKey == objectKey
              );

              if (objectMapping && objectMapping.isAllowed) {
                next();
              } else {
                unauthorizedApiAccess(objectKey, email, projectId, res);
              }
            } else {
              unauthorizedApiAccess(objectKey, email, projectId, res);
            }
          })
          .catch(() => {
            unauthorizedApiAccess(objectKey, email, projectId, res);
          });
      } else {
        await getProjectUsers(projectId, req)
          .then(async (projectUsers) => {
            if (projectUsers && projectUsers.users?.length > 0) {
              role = projectUsers.users.find(
                (item: any) => item.email?.toLowerCase() == email
              )?.role?.code;

              if (role) {
                await getAccessMapping(role, req)
                  .then((accessMapping) => {
                    if (accessMapping) {
                      const objectMapping = accessMapping.accessMapping.find(
                        (item: any) => item.objectKey == objectKey
                      );

                      if (objectMapping && objectMapping.isAllowed) {
                        next();
                      } else {
                        unauthorizedApiAccess(objectKey, email, projectId, res);
                      }
                    } else {
                      unauthorizedApiAccess(objectKey, email, projectId, res);
                    }
                  })
                  .catch(() => {
                    unauthorizedApiAccess(objectKey, email, projectId, res);
                  });
              } else {
                unauthorizedApiAccess(objectKey, email, projectId, res);
              }
            } else {
              unauthorizedApiAccess(objectKey, email, projectId, res);
            }
          })
          .catch(() => {
            unauthorizedApiAccess(objectKey, email, projectId, res);
          });
      }
    } else {
      unauthorizedApiAccess(objectKey, email, projectId, res);
    }
  };

const unauthorizedApiAccess = (
  objectKey: string,
  email: string,
  projectId: string,
  res: any
) => {
  logger.warn(
    `Unauthorized api access! objectKey: ${objectKey}, email: ${email}, projectId: ${projectId}`
  );
  res.status(403).send("Forbidden");
};

export { accessControl };
