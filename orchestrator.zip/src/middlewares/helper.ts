import config from "config";
const serviceConfig: any = config.get("microservice.config.services");
import { getData } from "../services/gateway.service";
import { constants } from "../../src/config/constants";
import { redisGetJson, redisSetJson } from "../utils/redisHelper";

const getProjectUsers = async (projectId: string, req: any) => {
  const projectUsersCacheKey =
    constants.accessControlConfig.PROJECT_USERS_CACHE_KEY_PREFIX + projectId;
  const projectUsersFromCache = await redisGetJson(projectUsersCacheKey);

  if (projectUsersFromCache) {
    return projectUsersFromCache;
  } else {
    const projectBaseURL = process.env.PROJECT_URL || serviceConfig.project.url;
    let serviceUrl =
      projectBaseURL +
      ":" +
      serviceConfig.project.port +
      constants.accessControlConfig.PROJECT_BASE_URL +
      "/" +
      projectId +
      constants.accessControlConfig.API_GET_PROJECT_USERS;
    const [err, response]: any = await getData(req, serviceUrl);
    let projectUsersFromDb;

    if (!err) {
      projectUsersFromDb = response.body;
    }

    if (projectUsersFromDb) {
      await redisSetJson(projectUsersCacheKey, projectUsersFromDb);
      return projectUsersFromDb;
    } else {
      throw new Error();
    }
  }
};

const getAccessMapping = async (role: string, req: any) => {
  const accessMappingCacheKey =
    constants.accessControlConfig.ROLE_ACCESS_MAPPING_CACHE_KEY_PREFIX + role;
  const accessMappingFromCache = await redisGetJson(accessMappingCacheKey);

  if (accessMappingFromCache) {
    return accessMappingFromCache;
  } else {
    const projectBaseURL = process.env.PROJECT_URL || serviceConfig.project.url;
    let serviceUrl =
      projectBaseURL +
      ":" +
      serviceConfig.project.port +
      constants.accessControlConfig.PROJECT_BASE_URL +
      constants.accessControlConfig.ACCESS_CONTROL_BASE_URL +
      "/" +
      role +
      constants.accessControlConfig.API_GET_ACCESS_MAPPING;
    const [err, response]: any = await getData(req, serviceUrl);
    let accessMappingFromDb;

    if (!err) {
      accessMappingFromDb = response.body;
    }

    if (accessMappingFromDb?.accessMapping) {
      await redisSetJson(accessMappingCacheKey, accessMappingFromDb);
      return accessMappingFromDb;
    } else {
      throw new Error();
    }
  }
};

export { getProjectUsers, getAccessMapping };
