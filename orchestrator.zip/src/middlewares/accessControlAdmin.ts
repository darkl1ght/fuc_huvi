const accessControlAdmin = (req: any, res: any, next: any) => {
  if (req.payload.isAdmin) {
    next();
  } else {
    res.status(403).send("Forbidden");
  }
};

export { accessControlAdmin };
