import { constants } from "../../src/config/constants";
import { getProjectUsers } from "./helper";

//To validate if a particular email id belongs to a project's users
//Use this along with and after accessControl middleware
const projectUser =
  (projectIdParamMode: string, projectIdParamName: string) =>
  async (req: any, res: any, next: any) => {
    const FORBIDDEN = "Forbidden";
    let projectId: string = "";

    switch (projectIdParamMode) {
      case constants.accessControlConfig.projectIdParamMode.PARAM:
        projectId = req.params[projectIdParamName];
        break;
      case constants.accessControlConfig.projectIdParamMode.BODY:
        projectId = req.body[projectIdParamName];
        break;
    }

    if (projectId) {
      await getProjectUsers(projectId, req)
        .then(async (projectUsers) => {
          if (projectUsers && projectUsers.users?.length > 0) {
            const projUser = projectUsers.users.find(
              (item: any) =>
                item.email?.toLowerCase() ==
                req.body?.user?.email?.toLowerCase() //TBD: Handle generic
            );

            if (projUser) {
              next();
            } else {
              res.status(403).send(FORBIDDEN);
            }
          } else {
            res.status(403).send(FORBIDDEN);
          }
        })
        .catch(() => {
          res.status(403).send(FORBIDDEN);
        });
    } else {
      res.status(403).send(FORBIDDEN);
    }
  };

export { projectUser };
