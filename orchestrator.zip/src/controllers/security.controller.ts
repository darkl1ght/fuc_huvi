import { catchAsync } from "../utils/catchAsync";
import { GatewayService } from "../services";
import { constants } from "../../src/config/constants";

const getRequest = catchAsync(async (req, res) => {
  const [err, response]: any = await GatewayService.apiGateway(
    req,
    constants.securityMicroservice,
    constants.apiHttpVerb.get
  );

  err
    ? res.status(err.statusCode).send(err)
    : res.status(response.statusCode).send(response.body);
});

const postRequest = catchAsync(async (req, res) => {
  const [err, response]: any = await GatewayService.apiGateway(
    req,
    constants.securityMicroservice,
    constants.apiHttpVerb.post
  );
  err
    ? res.status(err.statusCode).send(err)
    : res.status(response.statusCode).send(response.body);
});

const putRequest = catchAsync(async (req, res) => {
  const [err, response]: any = await GatewayService.apiGateway(
    req,
    constants.securityMicroservice,
    constants.apiHttpVerb.put
  );

  err
    ? res.status(err.statusCode).send(err)
    : res.status(response.statusCode).send(response.body);
});

const deleteRequest = catchAsync(async (req, res) => {
  const [err, response]: any = await GatewayService.apiGateway(
    req,
    constants.securityMicroservice,
    constants.apiHttpVerb.delete
  );

  err
    ? res.status(err.statusCode).send(err)
    : res.status(response.statusCode).send(response.body);
});

export { getRequest, postRequest, putRequest, deleteRequest };
