import { catchAsync } from "../utils/catchAsync";
import { ContentdataGatewayService } from "../services";
import { constants } from "../../src/config/constants";

const createCabinet = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const getAllCabinetsByAppId = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const getCabinetById = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const updateCabinetById = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});
const deleteCabinetById = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.delete
  );
  res.send(err ? err : response);
});

const constraCompanySetUp = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const getCabinetByModuleAndCompanyId = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const createFolder = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});
const createFoldersByFolderPath = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});
const updateFolder = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const getSubFolders = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const getFolder = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const getRootFolders = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});
const getProjectFolder = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const deleteFolder = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const deleteFolderBulk = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const createProjectFolders = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const getFieldIssuesFolderContents = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const getFolderContents = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const getFolderTree = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const getProjectFolderTree = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const getSurveyImageList = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const getFilesByPagination = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const createFile = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const createFileInBulk = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});
const updateFile = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});
const updateFileName = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});
const updateFileStatus = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});
const getFile = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});
const getProjectDataVolume = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});
const getFileByObjectId = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const deleteFile = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.delete
  );
  res.send(err ? err : response);
});

const deleteFileBulk = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const deleteFileByObjectId = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.delete
  );
  res.send(err ? err : response);
});

const getViewNDownloadFileUrl = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const getFileDownloadUrl = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const createFileVersionUploadUrl = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const createAnnotation = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const updateAnnotation = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const getAnnotation = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const removeAnnotation = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.delete
  );
  res.send(err ? err : response);
});

const updateFeatures = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const getComments = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.get
  );
  res.send(err ? err : response);
});

const addComment = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const removeComment = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.delete
  );
  res.send(err ? err : response);
});

const reinitiateVideoProcessing = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.post
  );
  res.send(err ? err : response);
});

const updateFileVersion = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const updateFileTags = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});
const updateMediaInBulk = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});

const getFilesForFieldIssueFolders = catchAsync(async (req, res) => {
  const [err, response]: any = await ContentdataGatewayService.apiGateway(
    req,
    constants.apiHttpVerb.put
  );
  res.send(err ? err : response);
});
export {
  createCabinet,
  getAllCabinetsByAppId,
  getCabinetById,
  updateCabinetById,
  deleteCabinetById,
  constraCompanySetUp,
  getCabinetByModuleAndCompanyId,
  createFolder,
  createFoldersByFolderPath,
  updateFolder,
  getSubFolders,
  getFolder,
  getRootFolders,
  getProjectFolder,
  deleteFolder,
  deleteFolderBulk,
  getProjectDataVolume,
  createProjectFolders,
  getFolderContents,
  getFieldIssuesFolderContents,
  getFolderTree,
  getProjectFolderTree,
  getSurveyImageList,
  createFile,
  createFileInBulk,
  updateFile,
  updateFileStatus,
  getFile,
  getFileByObjectId,
  deleteFile,
  deleteFileBulk,
  deleteFileByObjectId,
  getViewNDownloadFileUrl,
  getFileDownloadUrl,
  createFileVersionUploadUrl,
  reinitiateVideoProcessing,
  createAnnotation,
  updateAnnotation,
  getAnnotation,
  removeAnnotation,
  updateFeatures,
  getComments,
  addComment,
  removeComment,
  updateFileVersion,
  getFilesByPagination,
  updateFileTags,
  updateFileName,
  updateMediaInBulk,
  getFilesForFieldIssueFolders,
};
