import config from "config";
import { config as configEnv } from "../config/config";
const serviceConfig: any = config.get("microservice.config.services");
import { constants } from "../../src/config/constants";
import request from "request";
import fs from "fs";

const getData = async (req, url: string) => {
  const authToken = req.headers[constants.gatewayService.authorization];
  const procoreToken = req.headers[constants.gatewayService.procoreToken];

  const headers: any = {
    "Content-Type": constants.gatewayService.contentType,
    Authorization: `${authToken}`,
  };

  if (procoreToken) {
    headers["Procore-Token"] = procoreToken;
  }

  return new Promise(function (resolve, reject) {
    request.get(
      url,
      {
        headers,
        json: true,
      },
      async (err, response) => {
        if (err) resolve([err, null]);
        resolve([null, response]);
      }
    );
  });
};

const putData = async (req, url: string) => {
  const authToken = req.headers[constants.gatewayService.authorization];
  const procoreToken = req.headers[constants.gatewayService.procoreToken];

  const headers: any = {
    "Content-Type": constants.gatewayService.contentType,
    Authorization: `${authToken}`,
  };

  if (procoreToken) {
    headers["Procore-Token"] = procoreToken;
  }

  return new Promise(function (resolve, reject) {
    request.put(
      url,
      {
        body: req.body,
        headers,
        json: true,
      },
      async (err, response) => {
        if (err) resolve([err, null]);
        resolve([null, response]);
      }
    );
  });
};

const postData = async (req, url: string) => {
  const authToken = req.headers[constants.gatewayService.authorization];
  const procoreToken = req.headers[constants.gatewayService.procoreToken];

  if (req.files && req.files.file) {
    const headers: any = {
      "Content-Type": "multipart/form-data",
      Authorization: `${authToken}`,
    };
    let formData = {
      file: {
        value: fs.createReadStream(req.files.file.tempFilePath),
        options: {
          filename: req.files.file.name,
        },
      },
    };

    //Uncomment below code if any post request is having additional form data fields apart from files.
    // for (const item in req.body) {
    //   formData[item] = req.body[item];
    // }

    return new Promise(function (resolve, reject) {
      request.post(
        { url: url, formData: formData, headers },
        (err, response, body) => {
          if (err) resolve([err, null]);
          resolve([null, response]);
          fs.unlink(req.files.file.tempFilePath, (_err) => {
            // console.log("File was deleted");
          });
        }
      );
    });
  } else {
    const headers: any = {
      "Content-Type": constants.gatewayService.contentType,
      Authorization: `${authToken}`,
    };

    if (procoreToken) {
      headers["Procore-Token"] = procoreToken;
    }

    return new Promise(function (resolve, reject) {
      request.post(
        url,
        {
          body: req.body,
          headers,
          json: true,
        },
        async (err, response) => {
          if (err) resolve([err, null]);
          resolve([null, response]);
        }
      );
    });
  }
};

const deleteData = async (req, url: string) => {
  const authToken = req.headers[constants.gatewayService.authorization];
  const procoreToken = req.headers[constants.gatewayService.procoreToken];

  const headers: any = {
    "Content-Type": constants.gatewayService.contentType,
    Authorization: `${authToken}`,
  };

  if (procoreToken) {
    headers["Procore-Token"] = procoreToken;
  }

  return new Promise(function (resolve, reject) {
    request.delete(
      url,
      {
        headers,
        json: true,
      },
      async (err, response) => {
        if (err) resolve([err, null]);
        resolve([null, response]);
      }
    );
  });
};

const apiGateway = async (
  req: any,
  microserviceType: string,
  requestType: string
) => {
  let serviceUrl = "";

  switch (microserviceType.toLowerCase()) {
    case constants.projectMicroservice.toLowerCase():
      const projectBaseURL =
        process.env.PROJECT_URL || serviceConfig.project.url;
      serviceUrl =
        projectBaseURL + ":" + serviceConfig.project.port + req.originalUrl;
      break;
    case constants.securityMicroservice.toLowerCase():
      const securityBaseURL =
        process.env.SECURITY_URL || serviceConfig.security.url;
      serviceUrl =
        securityBaseURL + ":" + serviceConfig.security.port + req.originalUrl;
      break;
  }

  switch (requestType.toLowerCase()) {
    case constants.apiHttpVerb.post:
      return await postData(req, serviceUrl);
      break;
    case constants.apiHttpVerb.put:
      return await putData(req, serviceUrl);
      break;
    case constants.apiHttpVerb.delete:
      return await deleteData(req, serviceUrl);
      break;
    case constants.apiHttpVerb.get:
      return await getData(req, serviceUrl);
      break;
    default:
  }
};

export { postData, getData, putData, deleteData, apiGateway };
