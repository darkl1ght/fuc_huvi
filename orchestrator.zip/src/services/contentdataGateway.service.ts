import axios from "axios";
import config from "config";
import { config as configEnv } from "../config/config";
const serviceConfig: any = config.get("microservice.config.services");
import { constants } from "../../src/config/constants";

const getData = async (req, url: string) => {
  let svcResponse, svcErr;
  const authToken = req.headers[constants.gatewayService.authorization];

  const headers: any = {
    "Content-Type": constants.gatewayService.contentType,
    Authorization: `${authToken}`,
  };

  await axios
    .get(url, {
      headers: headers,
    })
    .then((response) => {
      svcResponse = {
        status: constants.gatewayService.success,
        data: response ? response.data : {},
        message: constants.gatewayService.successMessage,
      };
    })
    .catch((error) => {
      let err = error.response.data;
      svcErr = {
        status: constants.gatewayService.error,
        code: err && err.code ? err.code : constants.gatewayService.errorCode,
        data: error.response.data,
        message:
          err && err.message
            ? err.message
            : constants.gatewayService.errorMessage,
      };
    });

  return [svcErr, svcResponse];
};

const putData = async (req, url: string) => {
  let svcResponse, svcErr;
  const authToken = req.headers[constants.gatewayService.authorization];

  const headers: any = {
    "Content-Type": constants.gatewayService.contentType,
    Authorization: `${authToken}`,
  };

  await axios
    .put(url, req.body, {
      headers: headers,
    })
    .then((response) => {
      svcResponse = {
        status: constants.gatewayService.success,
        data: response ? response.data : {},
        message: constants.gatewayService.successMessage,
      };
    })
    .catch((error) => {
      let err = error.response.data;
      svcErr = {
        status: constants.gatewayService.error,
        code: err && err.code ? err.code : constants.gatewayService.errorCode,
        data: error.response.data,
        message:
          err && err.message
            ? err.message
            : constants.gatewayService.errorMessage,
      };
    });

  return [svcErr, svcResponse];
};

const postData = async (req, url: string) => {
  let svcResponse, svcErr;

  const authToken = req.headers[constants.gatewayService.authorization];

  const headers: any = {
    "Content-Type": constants.gatewayService.contentType,
    Authorization: `${authToken}`,
  };

  await axios
    .post(url, req.body, {
      headers: headers,
    })
    .then((response) => {
      svcResponse = {
        status: constants.gatewayService.success,
        data: response ? response.data : {},
        message: constants.gatewayService.successMessage,
      };
    })
    .catch((error) => {
      let err = error.response.data;
      svcErr = {
        status: constants.gatewayService.error,
        code: err && err.code ? err.code : constants.gatewayService.errorCode,
        data: error.response.data,
        message:
          err && err.message
            ? err.message
            : constants.gatewayService.errorMessage,
      };
    });

  return [svcErr, svcResponse];
};

const deleteData = async (req, url: string) => {
  let svcResponse, svcErr;
  const authToken = req.headers[constants.gatewayService.authorization];

  const headers: any = {
    "Content-Type": constants.gatewayService.contentType,
    Authorization: `${authToken}`,
  };

  await axios
    .delete(url, {
      headers: headers,
    })
    .then((response) => {
      svcResponse = {
        status: constants.gatewayService.success,
        data: response ? response.data : {},
        message: constants.gatewayService.successMessage,
      };
    })
    .catch((error) => {
      let err = error.response.data;
      svcErr = {
        status: constants.gatewayService.error,
        code: err && err.code ? err.code : constants.gatewayService.errorCode,
        data: error.response.data,
        message:
          err && err.message
            ? err.message
            : constants.gatewayService.errorMessage,
      };
    });

  return [svcErr, svcResponse];
};

const apiGateway = async (req: any, requestType: string) => {
  let serviceUrl = "";
  const contentdataBaseURL =
    process.env.CONTENTDATA_URL || serviceConfig.content.url;
  const appendApiKey: string =
    constants.appendApiKeyPrefix + configEnv.constraContentDataApiKey;
  serviceUrl =
    contentdataBaseURL +
    ":" +
    serviceConfig.content.port +
    (req.baseUrl?.split("/").pop().toLowerCase() ==
    constants.contentDataMicroserviceBase.toLowerCase()
      ? req.originalUrl + appendApiKey
      : req.originalUrl);

  switch (requestType.toLowerCase()) {
    case constants.apiHttpVerb.post:
      return await postData(req, serviceUrl);
      break;
    case constants.apiHttpVerb.put:
      return await putData(req, serviceUrl);
      break;
    case constants.apiHttpVerb.delete:
      return await deleteData(req, serviceUrl);
      break;
    case constants.apiHttpVerb.get:
      return await getData(req, serviceUrl);
      break;
    default:
  }
};

export { apiGateway };
