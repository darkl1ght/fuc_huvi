export * as GatewayService from "./gateway.service";
export * as ContentdataGatewayService from "./contentdataGateway.service";
