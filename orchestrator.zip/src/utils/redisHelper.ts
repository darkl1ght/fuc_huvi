import { config } from "../config/config";
const redis = require("redis");
let redisClient;
let isRedisConnected = false;

(async () => {
  redisClient = redis.createClient({
    socket: {
      host: config.redisHost,
      port: config.redisPort,
      tls: {},
      maxRetriesPerRequest: 2,
      reconnectOnError: function (err) {
        return false;
      },
      retryStrategy: function (times) {
        return null;
      },
    },
  });

  redisClient
    .on("connect", () => {})
    .on("ready", () => {
      console.log("Redis connected");
      isRedisConnected = true;
    })
    .on("error", (e) => {
      console.log("Redis error: ", e);
      isRedisConnected = false;
    });

  await redisClient.connect();
})();

const redisSetJson = async (
  key,
  data,
  ttl = 3600 //number of seconds till expiry
) => {
  await redisClient.set(key, JSON.stringify(data), { EX: ttl });
};
const redisGetJson = async (key) => {
  const jsonValue = await redisClient.get(key);
  return !!jsonValue ? JSON.parse(jsonValue) : null;
};

const redisSetValue = async (key, data, ttl = 3600) => {
  console.log({ key });
  await redisClient.set(key, data, { EX: ttl });
};
const redisGetValue = async (key) => {
  await redisClient.get(key);
};
const redisDeleteKey = async (key) => {
  await redisClient.del(key);
};

export {
  isRedisConnected,
  redisSetJson,
  redisGetJson,
  redisSetValue,
  redisGetValue,
  redisDeleteKey,
};
