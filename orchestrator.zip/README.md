# Constra-API's development setup

1. Create a folder called **Constra** and clone / move the orchestrator microservice.

2. Look out for `docker-compose.yml` and `docker-compose.dev.yml` files in the orchestrator repo, move these files out to the root of the **Constra** folder

3. The folder structure after performing the above two steps will look like this
   - Constra
     - orchestrator
     - docker-compose.yml
     - docker-compose.dev.yml
     - -- Other microservices --
4. To bring the services up, make sure that docker desktop is installed in the machine and execute the following command in the **Constra** directory\
   `docker-compose -f docker-compose.yml -f docker-compose.dev.yml up -d`

5. -d in the above command indicates running the containers in a detached mode.

6. To bring the services down, execute the following command in the **Constra** directory\
   `docker-compose down`

7. To interact with other services, from the **orchestrator**, edit the .env file in the **orchestrator** with the following

```
PROJECT_URL=http://project
SECURITY_URL=http://security
CONTENTDATA_URL=http://content-data
```
