module.exports = {
  secret:
    process.env.NODE_ENV === "production"
      ? process.env.SECRET
      : "401b09eab3c013d4ca54922bb802bec8fd5318192b0a75f201d8b3727429090fb337591abd3e44453b954555b7a0812e1081c39b740293f765eae731f5a65ed1",
  resetKey: "KHD*#E#E#(gbv36ed36e37ecc3u7ddzgdye7f37cyvedvedy",
  registrationKey: "KHDdendeidne7763763ndnjdhecc3u7ddzgdye7f37cyvedvedy",
  fromEmail: "Huviair Support<info@huviair.com>",
  sendGridKey:
    "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",
  passwordReset: {
    subject: "Password Reset",
    link:
      process.env.NODE_ENV === "production"
        ? process.env.passwordResetLink
        : "http://localhost:4200/reset?key=",
  },
  userRegistration: {
    subject: "Click on link to activate your account",
    link:
      process.env.NODE_ENV === "production"
        ? process.env.registrationLink
        : "http://localhost:4200/confirm?key=",
  },
};
