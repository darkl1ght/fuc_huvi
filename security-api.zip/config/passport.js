"use strict";

const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const mongoose = require("mongoose");
const User = mongoose.model("User");
const ObscureUser = mongoose.model("ObscureUser");

passport.use(
  new LocalStrategy(
    {
      usernameField: "user[email]",
      passwordField: "user[password]",
    },
    function (email, password, done) {
      User.findOne({ email: email.toLowerCase() }, function (err, user) {
        if (!err && user && user.validPassword(password)) {
          return done(null, user);
        }

        ObscureUser.findOne(
          { userId: email.toLowerCase() },
          function (err, user) {
            if (!err && user && user.validPassword(password)) {
              return done(null, user);
            }

            return done(null, false, {
              errors: { "Email or Password": "is invalid" },
            });
          }
        );
      });
    }
  )
);
