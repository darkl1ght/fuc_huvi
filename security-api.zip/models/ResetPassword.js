"use strict";

const mongoose = require("mongoose");
const crypto = require("crypto");
const resetSaltKey = require("../config").resetKey;

const ResetPasswordSchema = new mongoose.Schema(
  {
    email: String,
    hash: String,
    isReset: Boolean,
  },
  { timestamps: true }
);

ResetPasswordSchema.methods.getResetHash = function (resetKey) {
  const hash = crypto
    .pbkdf2Sync(resetKey, resetSaltKey, 10000, 512, "sha512")
    .toString("hex");
  return hash;
};

ResetPasswordSchema.methods.setResetKey = function (resetKey) {
  this.hash = crypto
    .pbkdf2Sync(resetKey, resetSaltKey, 10000, 512, "sha512")
    .toString("hex");
};

mongoose.model("ResetPassword", ResetPasswordSchema);
