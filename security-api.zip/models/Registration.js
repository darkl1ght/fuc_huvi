"use strict";

const mongoose = require("mongoose");
const crypto = require("crypto");
const registrationSaltKey = require("../config").registrationKey;

const RegistrationSchema = new mongoose.Schema(
  {
    email: String,
    hash: String,
    isExpired: Boolean,
  },
  { timestamps: true }
);

RegistrationSchema.methods.getRegistrationKey = function (registrationKey) {
  const hash = crypto
    .pbkdf2Sync(registrationKey, registrationSaltKey, 10000, 512, "sha512")
    .toString("hex");
  return hash;
};

RegistrationSchema.methods.setRegistrationKey = function (registrationKey) {
  this.hash = crypto
    .pbkdf2Sync(registrationKey, registrationSaltKey, 10000, 512, "sha512")
    .toString("hex");
};

mongoose.model("Registration", RegistrationSchema);
