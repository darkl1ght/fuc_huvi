"use strict";

const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const secret = require("../config").secret;
const { token } = require("morgan");

const ObscureUserSchema = new mongoose.Schema(
  {
    userId: { type: String, unique: true, required: [true, "can't be blank"] },
    firstName: {
      type: String,
      required: [true, "can't be blank"],
      match: [/^[a-zA-ZÀ-ÿ]+[a-zA-ZÀ-ÿ'\\\-,. ]*$/, "is invalid"],
    },
    lastName: {
      type: String,
      required: [true, "can't be blank"],
      match: [/^[a-zA-ZÀ-ÿ]+[a-zA-ZÀ-ÿ'\\\-,. ]*$/, "is invalid"],
    },
    email: { type: String, required: true },
    userToken: String,
    projectId: { type: String, required: true },
    isConfirmed: Boolean,
    hash: String,
    salt: String,
  },
  { timestamps: true }
);

ObscureUserSchema.index({ email: 1, projectId: 1 }, { unique: true });
ObscureUserSchema.plugin(uniqueValidator, { message: "is already taken." });

ObscureUserSchema.methods.validPassword = function (password) {
  const hash = crypto
    .pbkdf2Sync(password, this.salt, 10000, 512, "sha512")
    .toString("hex");
  return this.hash === hash;
};

ObscureUserSchema.methods.setPassword = function (password) {
  this.salt = crypto.randomBytes(16).toString("hex");
  this.hash = crypto
    .pbkdf2Sync(password, this.salt, 10000, 512, "sha512")
    .toString("hex");
};

ObscureUserSchema.methods.generateJWT = function () {
  const today = new Date();
  const exp = new Date(today);
  exp.setDate(today.getDate() + 100000);

  return jwt.sign(
    {
      id: this._id,
      firstName: this.firstName,
      lastName: this.lastName,
      email: this.email.toLowerCase(),
      isAdmin: false,
      exp: parseInt(exp.getTime() / 1000),
    },
    secret
  );
};

ObscureUserSchema.methods.toAuthJSON = function () {
  return {
    id: this._id,
    firstName: this.firstName,
    lastName: this.lastName,
    email: this.email.toLowerCase(),
    isAdmin: false,
    token: this.generateJWT(),
    userToken: this.userToken,
  };
};

ObscureUserSchema.methods.toProfileJSON = function () {
  return {
    id: this._id,
    firstName: this.firstName,
    lastName: this.lastName,
    email: this.email.toLowerCase(),
    userToken: this.userToken,
    projectId: this.projectId,
  };
};

ObscureUserSchema.methods.toProfileJSONFor = function (user) {
  return {
    firstName: this.firstName,
    lastName: this.lastName,
  };
};

mongoose.model("ObscureUser", ObscureUserSchema);
