"use strict";

const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const secret = require("../config").secret;

const UserSchema = new mongoose.Schema(
  {
    userId: { type: String, unique: true, required: [true, "can't be blank"] },
    firstName: {
      type: String,
      required: [true, "can't be blank"],
      match: [/^[a-zA-ZÀ-ÿ]+[a-zA-ZÀ-ÿ'\\\-,. ]*$/, "is invalid"],
    },
    lastName: {
      type: String,
      required: [true, "can't be blank"],
      match: [/^[a-zA-ZÀ-ÿ]+[a-zA-ZÀ-ÿ'\\\-,. ]*$/, "is invalid"],
    },
    email: { type: String, unique: true, required: [true, "can't be blank"] },
    phone: String,
    language: { type: String, default: "en"},
    isConfirmed: Boolean,
    isAdmin: Boolean,
    image: String,
    hash: String,
    salt: String,
  },
  { timestamps: true }
);

UserSchema.plugin(uniqueValidator, { message: "is already taken." });

UserSchema.methods.validPassword = function (password) {
  const hash = crypto
    .pbkdf2Sync(password, this.salt, 10000, 512, "sha512")
    .toString("hex");
  return this.hash === hash;
};

UserSchema.methods.setPassword = function (password) {
  this.salt = crypto.randomBytes(16).toString("hex");
  this.hash = crypto
    .pbkdf2Sync(password, this.salt, 10000, 512, "sha512")
    .toString("hex");
};

UserSchema.methods.generateJWT = function () {
  const today = new Date();
  const exp = new Date(today);
  exp.setDate(today.getDate() + 6000);

  return jwt.sign(
    {
      id: this._id,
      firstName: this.firstName,
      lastName: this.lastName,
      email: this.email.toLowerCase(),
      isAdmin: this.isAdmin,
      exp: parseInt(exp.getTime() / 1000),
    },
    secret
  );
};

UserSchema.methods.toAuthJSON = function () {
  return {
    id: this._id,
    firstName: this.firstName,
    lastName: this.lastName,
    email: this.email.toLowerCase(),
    isAdmin: this.isAdmin,
    token: this.generateJWT(),
    image: this.image,
    phone: this.phone,
    language: this.language
  };
};

UserSchema.methods.toProfileJSONFor = function (user) {
  return {
    firstName: this.firstName,
    lastName: this.lastName,
    image: this.image,
  };
};

UserSchema.methods.toResendEmailJSON = function (user) {
  return {
    firstName: this.firstName,
    lastName: this.lastName,
    email: this.email,
  };
};

mongoose.model("User", UserSchema);
