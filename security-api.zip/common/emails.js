"use strict";

const mongoose = require("mongoose");
const User = mongoose.model("User");
const Registration = mongoose.model("Registration");
const SendGridMail = require("@sendgrid/mail");
const fromEmail = require("../config").fromEmail;
const sendGridKey = require("../config").sendGridKey;

SendGridMail.setApiKey(sendGridKey);
const EmailService = {};

EmailService.getUserDetail = async (emailAddress) => {
  const user = await User.findOne({ email: emailAddress });
  return user;
};

EmailService.registerUser = async (emailAddress, registrationKey) => {
  try {
    await Registration.countDocuments(
      { email: emailAddress },
      async function (err, count) {
        if (count > 0) {
          await Registration.remove({ email: emailAddress });
        }
        const register = new Registration();
        register.email = emailAddress;
        register.isExpired = false;
        register.setRegistrationKey(registrationKey);
        register.save();
      }
    );
    return true;
  } catch (err) {
    return false;
  }
};

EmailService.sendMail = async (mailTo, subject, emailContent) => {
  let status;
  let err;
  const message = {
    to: mailTo,
    from: fromEmail,
    subject: subject,
    html: emailContent,
  };

  await (async () => {
    try {
      await SendGridMail.send(message).then(() => {
        status = "success";
      });
    } catch (error) {
      err = error;
      if (error.response) {
        console.error(error.response.body);
      }
    }
  })();

  return [err, status];
};

module.exports = EmailService;
