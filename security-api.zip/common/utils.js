"use strict";

const Fs = require("fs");
const Path = require("path");
const EmailService = require("./emails");
const passwordReset = require("../config").passwordReset;
const userRegistration = require("../config").userRegistration;
const uuid = require("uuid");

const sendRegistrationEmail = async (user) => {
  await Fs.readFile(
    Path.dirname(require.main.filename) + "/templates/email-confirmation.html",
    "utf8",
    async (err, fileData) => {
      if (err) {
        return false;
      }
      const fullName = user.firstName + " " + user.lastName;
      const registrationKey = uuid.v4();

      const status = await EmailService.registerUser(
        user.email,
        registrationKey
      );
      let finalEmailHTMLData = fileData;
      if (status) {
        // replace user name
        finalEmailHTMLData = finalEmailHTMLData.replace("[fullName]", fullName);
        // replace link
        finalEmailHTMLData = finalEmailHTMLData.replace(
          "[link1]",
          userRegistration.link + registrationKey
        );
        // replace link
        finalEmailHTMLData = finalEmailHTMLData.replace(
          "[link2]",
          userRegistration.link + registrationKey
        );
        // replace link
        finalEmailHTMLData = finalEmailHTMLData.replace(
          "[link3]",
          userRegistration.link + registrationKey
        );

        if (user.email) {
          const [error, data] = await EmailService.sendMail(
            user.email,
            userRegistration.subject,
            finalEmailHTMLData
          );
          return error ? false : true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
  );
};

const sendPasswordResetEmail = async (userEmail, resetKey) => {
  await Fs.readFile(
    Path.dirname(require.main.filename) + "/templates/password-reset.html",
    "utf8",
    async (err, fileData) => {
      if (err) {
        return false;
      }

      const user = await EmailService.getUserDetail(userEmail);
      let finalEmailHTMLData = fileData;
      if (user) {
        // replace user name
        finalEmailHTMLData = finalEmailHTMLData.replace(
          "[fullName]",
          user.firstName + " " + user.lastName
        );
        // replace link
        finalEmailHTMLData = finalEmailHTMLData.replace(
          "[link]",
          passwordReset.link + resetKey
        );
        // replace link
        finalEmailHTMLData = finalEmailHTMLData.replace(
          "[link2]",
          passwordReset.link + resetKey
        );
        // replace link
        finalEmailHTMLData = finalEmailHTMLData.replace(
          "[link3]",
          passwordReset.link + resetKey
        );

        if (userEmail) {
          const [error, data] = await EmailService.sendMail(
            user.email,
            passwordReset.subject,
            finalEmailHTMLData
          );
          return error ? false : true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
  );
};

module.exports = {
  sendRegistrationEmail,
  sendPasswordResetEmail,
};
