"use strict";

const mongoose = require("mongoose");
const router = require("express").Router();
const passport = require("passport");
const ObscureUser = mongoose.model("ObscureUser");
const auth = require("../auth");
const uuid = require("uuid");
const Utils = require("../../common/utils");
const crypto = require("crypto");

router.delete("/user/:userId", auth.required, function (req, res, next) {
  ObscureUser.deleteOne({
    userId: req.params.userId,
  })
    .exec()
    .then((data) => {
      res.json({
        status: "success",
      });
    })
    .catch(next);
});

router.post("/users/login", async function (req, res, next) {
  if (!req.body.user.userToken || !req.body.user.projectId) {
    return res.status(422).json({ errors: { email: "can't be blank" } });
  }

  const obUser = await ObscureUser.findOne({
    userToken: req.body.user.userToken,
    projectId: req.body.user.projectId,
  })
    .select({ userId: 1, _id: 0 })
    .exec();

  if (obUser) {
    req.body.user.email = obUser.userId;
    req.body.user.password = req.body.user.userToken;
  }

  console.log(obUser);

  passport.authenticate(
    "local",
    { session: false },
    function (err, user, info) {
      if (err) {
        return next(err);
      }

      if (user && user.isConfirmed) {
        user.token = user.generateJWT();
        return res.json({ user: user.toAuthJSON() });
      } else {
        console.log(info);
        return res.status(422).json(info);
      }
    }
  )(req, res, next);
});

router.post("/users/:projectId", async function (req, res, next) {
  await ObscureUser.countDocuments(
    {
      email: req.body.user.email.toLowerCase(),
      projectId: req.params.projectId,
    },
    async (err, count) => {
      if (count === 0 && req.params.projectId) {
        const user = new ObscureUser();
        const token = crypto.randomBytes(16).toString("hex");

        user.userId = uuid.v4();
        user.firstName = req.body.user.firstName;
        user.lastName = req.body.user.lastName;
        user.email = req.body.user.email.toLowerCase();
        user.projectId = req.params.projectId;
        user.userToken = token;
        user.isConfirmed = true;
        user.setPassword(token);

        user
          .save()
          .then(async function (user) {
            console.log(user);
            return res.json({ user: user.toProfileJSON() });
          })
          .catch(next);
      } else {
        ObscureUser.findOne({
          email: req.body.user.email,
          projectId: req.params.projectId,
        })
          .then(function (user) {
            if (!user) {
              return res.sendStatus(401);
            }
            return res.json({ user: user.toProfileJSON() });
          })
          .catch(next);
      }
    }
  );
});

module.exports = router;
