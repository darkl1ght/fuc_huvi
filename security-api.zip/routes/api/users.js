"use strict";

const mongoose = require("mongoose");
const router = require("express").Router();
const passport = require("passport");
const User = mongoose.model("User");
const ResetPassword = mongoose.model("ResetPassword");
const Registration = mongoose.model("Registration");
const auth = require("../auth");
const uuid = require("uuid");
const Utils = require("../../common/utils");

router.get("/user", auth.required, function (req, res, next) {
  User.findById(req.payload.id)
    .then(function (user) {
      if (!user) {
        return res.sendStatus(401);
      }

      return res.json({ user: user.toAuthJSON() });
    })
    .catch(next);
});

router.put("/user", auth.required, function (req, res, next) {
  User.findById(req.payload.id)
    .then(function (user) {
      if (!user) {
        return res.sendStatus(401);
      }

      // only update fields that were actually passed...
      if (typeof req.body.user.firstName !== "undefined") {
        user.firstName = req.body.user.firstName;
      }

      if (typeof req.body.user.lastName !== "undefined") {
        user.lastName = req.body.user.lastName;
      }
      if (typeof req.body.user.image !== "undefined") {
        user.image = req.body.user.image;
      }
      if (typeof req.body.user.phone !== "undefined") {
        user.phone = req.body.user.phone;
      }
      if (typeof req.body.user.language !== "undefined") {
        user.language = req.body.user.language;
      }      

      if (
        typeof req.body.user.password !== "undefined" &&
        req.body.user.password &&
        req.body.user.password !== ""
      ) {
        user.setPassword(req.body.user.password);
      }

      return user.save().then(function () {
        return res.json({ user: user.toAuthJSON() });
      });
    })
    .catch(next);
});

router.post("/users/login", function (req, res, next) {
  if (!req.body.user.email) {
    return res.status(422).json({ errors: { email: "can't be blank" } });
  }

  if (!req.body.user.password) {
    return res.status(422).json({ errors: { password: "can't be blank" } });
  }

  passport.authenticate(
    "local",
    { session: false },
    function (err, user, info) {
      if (err) {
        return next(err);
      }

      if (user) {
        if (user.isConfirmed) {
          user.token = user.generateJWT();
          return res.json({ user: user.toAuthJSON() });
        } else {
          return res.status(400).send({
            status: "isNotConfirmed",
            user: user.toResendEmailJSON(),
          });
        }
      } else {
        return res.status(422).json(info);
      }
    }
  )(req, res, next);
});

router.post("/users", async function (req, res, next) {
  const user = new User();
  user.userId = uuid.v4();
  user.firstName = req.body.user.firstName;
  user.lastName = req.body.user.lastName;
  user.email = req.body.user.email.toLowerCase();
  user.isConfirmed = false;
  user.setPassword(req.body.user.password);

  user
    .save()
    .then(async function (user) {
      await Utils.sendRegistrationEmail(user);
      return res.json({
        status: "00000",
        user: user.toResendEmailJSON(),
      });
    })
    .catch(next);
});

router.post("/users/forgot", async function (req, res, next) {
  if (!req.body.email) {
    return res.status(422).json({ errors: { email: "can't be blank" } });
  } else {
    //check if valid user and already registered
    const user = await User.findOne({
      email: req.body.email.toLowerCase(),
      isConfirmed: true,
    });

    if (!user) {
      return res.json({ status: "10001" });
    }

    ResetPassword.countDocuments(
      { email: req.body.email.toLowerCase() },
      async function (err, count) {
        if (count > 0) {
          const rec = await ResetPassword.deleteOne({
            email: req.body.email.toLowerCase(),
          });
        }
        const resetKey = uuid.v4();
        const reset = new ResetPassword();
        reset.email = req.body.email.toLowerCase();
        reset.isReset = false;
        reset.setResetKey(resetKey);

        reset
          .save()
          .then(async function () {
            await Utils.sendPasswordResetEmail(
              req.body.email.toLowerCase(),
              resetKey
            );
            return res.json({ status: "00000" });
          })
          .catch(next);
      }
    ).catch(next);
  }
});

router.post("/users/register", function (req, res, next) {
  if (!req.body.key) {
    return res.status(422).json({ errors: { key: "can't be blank" } });
  } else {
    const registration = new Registration();
    const hashByte = registration.getRegistrationKey(req.body.key);

    Registration.findOne({ hash: hashByte }, function (err, obj) {
      if (obj) {
        if (obj.isExpired) {
          return res.status(422).json({ status: "10002" });
        }

        obj.isExpired = true; // set reset status to true
        return obj.save().then(function () {
          User.findOne({ email: obj.email.toLowerCase() })
            .then(function (user) {
              if (!user) {
                return res.status(422).json({ status: "10001" });
              }
              user.isConfirmed = true;
              user.isAdmin = false;
              user
                .save()
                .then(async function (user) {
                  user.token = user.generateJWT();
                  return res.json({ user: user.toAuthJSON(), status: "00000" });
                })
                .catch(next);
            })
            .catch(next);
        });
      } else {
        return res.status(422).json({ status: "10001" });
      }
    }).catch(next);
  }
});

router.post("/users/confirm", function (req, res, next) {
  if (!req.body.key || !req.body.password) {
    return res.status(422).json({ errors: { reset: "invalid request" } });
  } else {
    const reset = new ResetPassword();
    reset.isReset = false;
    const hashByte = reset.getResetHash(req.body.key);

    ResetPassword.findOne(
      { hash: hashByte, isReset: false },
      function (err, obj) {
        if (obj) {
          obj.isReset = true; // set reset status to true
          return obj.save().then(function () {
            User.findOne({ email: obj.email.toLowerCase() })
              .then(function (user) {
                if (!user) {
                  return res.sendStatus(401);
                }
                if (typeof req.body.password !== "undefined") {
                  user.setPassword(req.body.password);
                }
                return user.save().then(function () {
                  return res.json({ user: user.toAuthJSON() });
                });
              })
              .catch(next);
          });
        } else {
          return res.status(422).json({ status: "10001" });
        }
      }
    ).catch(next);
  }
});

router.post(
  "/users/admin/setpassword",
  auth.required,
  function (req, res, next) {
    if (!req.body.user) {
      return res.status(422).json({ errors: { reset: "invalid request" } });
    } else {
      User.findOne({ email: req.body.user.email.toLowerCase() })
        .then(function (user) {
          if (!user) {
            const newUser = new User();
            newUser.userId = uuid.v4();
            newUser.firstName = req.body.user.firstName;
            newUser.lastName = req.body.user.lastName;
            newUser.email = req.body.user.email.toLowerCase();
            newUser.isConfirmed = true;
            newUser.setPassword(req.body.user.password);

            newUser
              .save()
              .then(async function (newUser) {
                return res.json({ status: "success" });
              })
              .catch(next);
          } else {
            user.setPassword(req.body.user.password);
            return user.save().then(function () {
              return res.json({ status: "success" });
            });
          }
        })
        .catch(next);
    }
  }
);

router.post("/users/resend-email", async function (req, res, next) {
  const user = new User();
  user.firstName = req.body.user.firstName;
  user.lastName = req.body.user.lastName;
  user.email = req.body.user.email.toLowerCase();
  await Utils.sendRegistrationEmail(user);
  return res.json({ status: "00000" });
});

module.exports = router;
