"use strict";
const mongoose = require("mongoose");
const User = mongoose.model("User");
const router = require("express").Router();

router.use("/", require("./users"));
router.use("/obscure", require("./obscure"));
router.use("/profiles", require("./profiles"));
router.get("/health", async (req, res, next) => {
  try {
    await User.find()
      .countDocuments((err, _) => {
        if (err) {
          return res.sendStatus(500).json({
            status: "Unhealthy",
            error: JSON.stringify(err),
            uptime: process.uptime(),
            date: new Date(),
          });
        }

        return res.json({
          status: "Healthy",
          error: null,
          uptime: process.uptime(),
          date: new Date(),
        });
      })
      .catch(next);
  } catch (err) {
    res.sendStatus(500).json({
      status: "Unhealthy",
      error: "Catch Err: " + JSON.stringify(err),
      uptime: process.uptime(),
      date: new Date(),
    });
  }
});

router.use(function (err, req, res, next) {
  if (err.name === "ValidationError") {
    return res.status(422).json({
      errors: Object.keys(err.errors).reduce(function (errors, key) {
        errors[key] = err.errors[key].message;

        return errors;
      }, {}),
    });
  }

  return next(err);
});

module.exports = router;
