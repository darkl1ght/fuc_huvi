#!/usr/local/bin/python3.9
import os
from datetime import datetime

from bson.objectid import ObjectId
import motor.motor_asyncio
import getpass
linux_username = getpass.getuser()
from dotenv import load_dotenv
dotenv_path="/home/{0}/geoprocessing-api/app/.env".format(linux_username)
load_dotenv(dotenv_path)

MONGODB_CONNECTION_STRING = os.environ.get("MONGODB_CONNECTION_STRING")
MONGODB_DATABASE_NAME = os.environ.get("MONGODB_DATABASE_NAME")

client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_CONNECTION_STRING)

database = client[MONGODB_DATABASE_NAME]

processing_statistics_collection = database.get_collection(
    "processingstatistics")


# Update a processing status with event using tour ID
async def update_proc_status(tour_id: str, description: str, status: str):

    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if proc_status:
        proc_status["overall_processing_status"] = "Processing"
        proc_status["events"].append({
            "description": description,
            "time": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
            "status": status
        })
        updated_proc_status = await processing_statistics_collection.update_one(
            {"_id": ObjectId(proc_status["_id"])}, {"$set": proc_status}
        )
        if updated_proc_status:
            return True
        return False


async def update_dem_status(tour_id: str, file_type: str):
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if proc_status:
        proc_status["last_dem_built"] = file_type
        updated_proc_status = await processing_statistics_collection.update_one(
            {"_id": ObjectId(proc_status["_id"])}, {"$set": proc_status}
        )
        if updated_proc_status:
            return True
        return False


async def get_proc_status(tour_id):
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    return proc_status
