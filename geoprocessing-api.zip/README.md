# Introduction

TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project.

# Getting Started

TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:

1. Installation process
2. Software dependencies
3. Latest releases
4. API references

# Build and Test

TODO: Describe and show how to build your code and run the tests.

# Contribute

TODO: Explain how other users and developers can contribute to make your code better.

# important things to note / reference

1.  doubts on fastapi-mongo [here][1]
2.  `export PYTHONPATH=$PWD` // never ever forget this before running fastapi/uvicorn application
3.  `setfacl -R -m u:celery:rwx /home/<username>/geoprocessing-api/` to give celery permission it needs
4.  `sudo chown -R username:usergroup file_path` // to give the user permissions for execution
5.  `sudo systemctl [start/stop/restart] geoprocessing.service` // to check geoprocessing-service status
6.  `journalctl -e -u geoprocessing.service` // to check geoprocessing-service journal log
7.  for running metashape in heedless mode, with no display, reference here -> [this][0]
8.  `uvicorn app.server.app:app --host 0.0.0.0 --port 8000`
9.  install pymongo, motor, azure-blob-storage, python-dotenv, sendgrid, dnspython for geoprocessing service in the location where begin_processing.py is placed.
10. To install any package in metashape library
    `cd <path_to_metashape-pro>`
    `LD_LIBRARY_PATH=`pwd`/python/lib ./python/bin/python3.x -m pip install python_module_name`
    x will be the version of python inside the metashape-pro python directory
    We have to install pytz, dnspython, bson, motor, python-dotenv packages for metashape to run.
11. If metashape UI does not open on linux, then refer [this][2]
12. Please make sure to deactivate the previous metashape instance,
    in case it is not used later using the below command:
    `cd <path_to_metashape-pro>`
    `./metashape.sh --deactivate`
    Also, save the activation key stored in the metashape folder in a .license file
13. To activate the metashape instance using the metashape activation key, use the below command:
    `cd <path_to_metashape-pro>`
    `./metashape.sh --activate xxxxx-xxxxx-xxxxx-xxxxx-xxxxx`
14. Make sure that aws-cli(v1 or v2) is installed on the system, for mapbox uploads to work.



[0]:[https://www.agisoft.com/forum/index.php?topic=7376.0]
[1]:[https://testdriven.io/blog/fastapi-mongo/]
[2]:[https://www.agisoft.com/forum/index.php?topic=13155.0]
