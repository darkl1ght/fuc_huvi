import os
import json
import tempfile
import asyncio
import logging
from time import sleep
from grass_engine import (
    grass,
    GrassEngineException,
    MEDIA_ROOT,
    BASE_DIR,
)
import motor.motor_asyncio
from bson.objectid import ObjectId
from dotenv import load_dotenv

HOME = os.environ.get("HOME")
dotenv_path = "{home}/geoprocessing-api/app/.env".format(home=HOME)
load_dotenv(dotenv_path)
print(os.environ.copy())
volume_calc_statuses = []
MACHINE_ID = os.environ.get("MACHINE_ID")
# with open("/etc/machine-id", "r") as reader:
#     MACHINE_ID = reader.readline().rstrip("\n")
MONGODB_CONNECTION_STRING = os.environ.get("MONGODB_CONNECTION_STRING")
MONGODB_DATABASE_NAME = os.environ.get("MONGODB_DATABASE_NAME")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_CONNECTION_STRING)
database = client[MONGODB_DATABASE_NAME]
volume_calc_collection = database.get_collection("mapvolumes")


async def update_vol_calc_status(vol_obj: object, status: str, volume=None):
    vol_doc = await volume_calc_collection.find_one(
        {"volumeUniqueId": vol_obj["volume_unique_id"]}
    )
    if vol_doc:
        if volume:
            vol_doc["volume"] = "{}".format(volume)
        vol_doc["status"] = status
        updated_vol_doc = await volume_calc_collection.update_one(
            {"_id": ObjectId(vol_doc["_id"])}, {"$set": vol_doc}
        )
        if updated_vol_doc:
            return True
        return False


async def calulate_volume(vol_obj):
    """
    Calculates Volume of the Polygon drawn on the DSM
    input: polygon_geojson , point_geojson, dsm file location
    output: volume
    """
    # Sample Volume Object
    # vol_obj = {
    #     "polygon_geojson": < polygon_geojson >,
    #     "point_geojson": < points_geojson >,
    #     "tour_id": "<tour_id>",
    #     "project_id": "<project_id>",
    #     "machine_id": "",
    #     "tour_type": "<tour_type>"
    # }
    tour_id = vol_obj["tour_id"]
    area = vol_obj["polygon_geojson"]
    points = vol_obj["point_geojson"]
    base_tour_dir = os.path.join(MEDIA_ROOT, tour_id)
    dsm = os.path.join(base_tour_dir, "dsm.tif")
    await update_vol_calc_status(vol_obj, "inprogress")

    try:

        if not os.path.isfile(dsm):
            raise Exception("DSM file not found")

        if vol_obj["is_surface_elevation_request"]:
            cut_context = grass.create_context(
                {
                    "auto_cleanup": False,
                    "base_dir": base_tour_dir,
                }
            )
            cut_context.add_file("area_file.geojson", json.dumps(area))
            cut_context.add_file("points_file.geojson", json.dumps(points))
            cut_context.add_param("dsm_file", dsm)
            cut_context.set_location(dsm)
            cut_context.add_param("surface_elevation",
                                  vol_obj["surface_elevation"])
            cut_volume = cut_context.execute(
                os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    "grass_volume_calc_at_surface_elev_cut.py",
                )
            )
            fill_context = grass.create_context(
                {
                    "auto_cleanup": False,
                    "base_dir": base_tour_dir,
                }
            )
            fill_context.add_file("area_file.geojson", json.dumps(area))
            fill_context.add_file("points_file.geojson", json.dumps(points))
            fill_context.add_param("dsm_file", dsm)
            fill_context.set_location(dsm)
            fill_context.add_param("surface_elevation",
                                   vol_obj["surface_elevation"])
            fill_volume = fill_context.execute(
                os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    "grass_volume_calc_at_surface_elev_fill.py",
                )
            )
            try:
                value_error = None
                try:
                    float(cut_volume)
                except:
                    value_error = "cut_volume value error"
                if value_error is None:
                    try:
                        float(fill_volume)
                    except:
                        value_error = "fill_volume value error"
                if value_error is None:
                    total_volume = str(
                        round(float(cut_volume) - float(fill_volume), 3))
                    volume = " | ".join([
                        "Cut: " + cut_volume,
                        "Fill: " + fill_volume,
                        "Total: " + total_volume,
                    ])
                else:
                    raise ValueError(value_error)
            except ValueError as err:
                volume = err

        else:
            context = grass.create_context(
                {
                    "auto_cleanup": False,
                    "base_dir": base_tour_dir,
                }
            )
            context.add_file("area_file.geojson", json.dumps(area))
            context.add_file("points_file.geojson", json.dumps(points))
            context.add_param("dsm_file", dsm)
            context.set_location(dsm)
            volume = context.execute(
                os.path.join(
                    os.path.dirname(os.path.abspath(__file__)
                                    ), "grass_volume_calc.py"
                )
            )

        if type(volume) == type("str"):
            # Update the value to DB
            # print(volume)
            await update_vol_calc_status(vol_obj, "completed", volume)
        else:
            await update_vol_calc_status(vol_obj, "error")
            # print("Error while completing task")

        # Clean the temporary folders
        if vol_obj["is_surface_elevation_request"]:
            fill_context.cleanup()
            cut_context.cleanup()
        else:
            context.cleanup()
    except Exception as err:
        context.cleanup()
        print("Error in calc_volume.py: {}".format(err))
        await update_vol_calc_status(vol_obj, "error: {}".format(err))


def volume_calc_status_helper(volume_process_status):
    return {
        "id": str(volume_process_status["_id"]),
        "label": volume_process_status["label"],
        "tour_id": volume_process_status["tourId"],
        "project_id": volume_process_status["projectId"],
        "status": volume_process_status["status"],
        "polygon_geojson": volume_process_status["polygonGeojson"],
        "point_geojson": volume_process_status["pointGeojson"],
        "tour_type": volume_process_status["tourType"],
        "volume_unique_id": volume_process_status["volumeUniqueId"],
        "created_by": volume_process_status["createdBy"],
        "machine_id": volume_process_status.get("machineId",""),
        "is_surface_elevation_request": volume_process_status.get(
            "isSurfaceElevationRequest", False
        ),
        "surface_elevation": volume_process_status.get("surfaceElevation", None),
    }


async def retrieve_volume_calc_queue():
    global volume_calc_statuses
    vol_calc_status = await volume_calc_collection.find_one(
        {"status": "new", "machineId": MACHINE_ID}
    )
    if vol_calc_status:
        if check_tour_dsm_exists(volume_calc_status_helper(vol_calc_status)["tour_id"]):
            volume_calc_statuses.append(volume_calc_status_helper(vol_calc_status))
        else:
            await update_vol_calc_status(volume_calc_status_helper(vol_calc_status), "completed", "Error: DSM File does not exist.")
    return


logger = logging.getLogger(__name__)


def check_tour_dsm_exists(tour_id):
    if os.path.isfile(os.path.join(MEDIA_ROOT, tour_id, "dsm.tif")):
        return True
    return False


def is_vol_calc_request_valid(volume_obj):
    try:
        if (
            volume_obj["machine_id"].lower() == MACHINE_ID.lower()
            and volume_obj["status"].lower() == "new"
            and volume_obj["tour_type"] == "L"
        ):
            return True
        return False
    except Exception as err:
        logger.error("Error in is_vol_calc_request_valid method")
        raise Exception("Error in is_vol_calc_request_valid method")
        return False


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    while True:
        volume_calc_statuses = []
        try:
            loop.run_until_complete(retrieve_volume_calc_queue())
            new_vol_calc_req = False
            for vol_cal_req in volume_calc_statuses:
                if is_vol_calc_request_valid(vol_cal_req):
                    new_vol_calc_req = vol_cal_req
                    break
            if new_vol_calc_req:
                loop.run_until_complete(calulate_volume(new_vol_calc_req))
            else:
                sleep(120)
        except Exception as e:
            logger.info(e)
