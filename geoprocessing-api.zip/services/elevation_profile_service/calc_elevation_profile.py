# %module
# % description: Calculate elevation profile data from DSM and input coordinate pairs
# %end
# %option
# % key: dsm_file
# % type: string
# % required: yes
# % multiple: no
# % description: GeoTIFF DEM containing the surface
# %end
# %option
# % key: resolution
# % type: string
# % required: yes
# % multiple: no
# % description: Interval for the elevation profile
# %end
# %option
# % key: coord_list
# % required: yes
# % multiple: no
# % description: Easting and Northing of coordinate pairs, separated by comma
# %end
# %option
# % key: elevation_profile_file
# % required: yes
# % multiple: no
# % description: File to save elevation profile data
# %end


import sys
import json
from grass.pygrass.modules import Module
import grass.script as grass


def main():
    # r.import input=C:\Users\Administrator\Downloads\volume_research\mine-test-data\dsm43N.tif output=dsm43N --overwrite
    Module("r.import", input=opts["dsm_file"], output="dsm", overwrite=True)
    # Set Grass region and resolution to DSM
    Module("g.region", raster="dsm")
    # r.profile - g - c input = dsm@PERMANENT coordinates = ["331442.09899391147, 2901277.315221538","331533.2243629607, 2901388.874764253"] resolution = 5 units = meters
    Module("r.profile", input="dsm", resolution=opts["resolution"],
           units="meters", coordinates=opts["coord_list"].split(","),
           g=True, c=True, overwrite=True,
           output=opts["elevation_profile_file"])
    return 0


if __name__ == "__main__":
    opts, _ = grass.parser()
    sys.exit(main())
