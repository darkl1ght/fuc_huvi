# %module
# % description: Calculate projected UTM coordinates from WGS84 projection LongLat
# %end
# %option
# % key: dsm_file
# % type: string
# % required: yes
# % multiple: no
# % description: GeoTIFF DEM containing the surface
# %end
# %option
# % key: wgs84_coord_file
# % type: string
# % required: yes
# % multiple: no
# % description: File containing coordinates in WGS84 projection from Mapbox
# %end
# %option
# % key: utm_coord_file
# % type: string
# % required: yes
# % multiple: no
# % description: File containing coordinates in DSM file Projection
# %end


import sys
from grass.pygrass.modules import Module
import grass.script as grass


def main():
    Module("r.external", input=opts["dsm_file"], output="dsm", overwrite=True)
    # Set Grass region and resolution to DSM
    Module(
        "m.proj",
        i=True,
        input=opts["wgs84_coord_file"],
        output=opts["utm_coord_file"],
        separator="comma,comma",
        overwrite=True,
        c=True,
        d=True
    )
    return 0


if __name__ == "__main__":
    opts, _ = grass.parser()
    sys.exit(main())
