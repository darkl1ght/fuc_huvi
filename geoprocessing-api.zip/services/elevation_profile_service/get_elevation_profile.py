import math
import os
import json
import tempfile
import asyncio
import logging
from time import sleep
from grass_engine import (
    grass,
    GrassEngineException,
    MEDIA_ROOT,
    BASE_DIR,
)
import motor.motor_asyncio
from bson.objectid import ObjectId
from dotenv import load_dotenv
from geojson import utils
import csv
from osgeo import gdal, osr


HOME = os.environ.get("HOME")
dotenv_path = "{home}/geoprocessing-api/app/.env".format(home=HOME)
load_dotenv(dotenv_path)

elev_profile_statuses = []
MACHINE_ID = os.environ.get("MACHINE_ID")
# with open("/etc/machine-id", "r") as reader:
#     MACHINE_ID = reader.readline().rstrip("\n")
MONGODB_CONNECTION_STRING = os.environ.get("MONGODB_CONNECTION_STRING")
MONGODB_DATABASE_NAME = os.environ.get("MONGODB_DATABASE_NAME")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_CONNECTION_STRING)
database = client[MONGODB_DATABASE_NAME]
elev_profile_collection = database.get_collection("elevationprofiles")


async def update_elev_profile_status(ele_profile_obj: object, status: str, elev_profile_chart_info=None):
    elev_profile_doc = await elev_profile_collection.find_one(
        {"elevationProfileUniqueId": ele_profile_obj["elec_profile_unique_id"]}
    )
    if elev_profile_doc:
        if elev_profile_chart_info:
            elev_profile_doc["elevProfileChartInfo"] = elev_profile_chart_info
        elev_profile_doc["status"] = status
        updated_elev_profile_doc = await elev_profile_collection.update_one(
            {"_id": ObjectId(elev_profile_doc["_id"])}, {
                "$set": elev_profile_doc}
        )
        if updated_elev_profile_doc:
            return True
        return False


def get_projection_of_dsm(dsm_path):
    zone = "ZONE_NOT_PROVIDED"
    isNorth = False
    ds = gdal.Open(dsm_path)
    prj = ds.GetProjection()
    srs = osr.SpatialReference(wkt=prj)
    if srs.IsProjected:
        # projection value sample = WGS 84 / UTM zone 55N
        projection = srs.GetAttrValue('projcs')[-3:]
        isNorth = True if projection[-1] == "N" else False
        zone = float(projection[:-1])
    return {"zone": zone, "isNorth": isNorth}


def utmToLatLng(zone, easting, northing, northernHemisphere=True):
    if not northernHemisphere:
        northing = 10000000 - northing

    a = 6378137
    e = 0.081819191
    e1sq = 0.006739497
    k0 = 0.9996

    arc = northing / k0
    mu = arc / (a * (1 - math.pow(e, 2) / 4.0 - 3 *
                math.pow(e, 4) / 64.0 - 5 * math.pow(e, 6) / 256.0))

    ei = (1 - math.pow((1 - e * e), (1 / 2.0))) / \
        (1 + math.pow((1 - e * e), (1 / 2.0)))

    ca = 3 * ei / 2 - 27 * math.pow(ei, 3) / 32.0

    cb = 21 * math.pow(ei, 2) / 16 - 55 * math.pow(ei, 4) / 32
    cc = 151 * math.pow(ei, 3) / 96
    cd = 1097 * math.pow(ei, 4) / 512
    phi1 = mu + ca * math.sin(2 * mu) + cb * math.sin(4 * mu) + \
        cc * math.sin(6 * mu) + cd * math.sin(8 * mu)

    n0 = a / math.pow((1 - math.pow((e * math.sin(phi1)), 2)), (1 / 2.0))

    r0 = a * (1 - e * e) / \
        math.pow((1 - math.pow((e * math.sin(phi1)), 2)), (3 / 2.0))
    fact1 = n0 * math.tan(phi1) / r0

    _a1 = 500000 - easting
    dd0 = _a1 / (n0 * k0)
    fact2 = dd0 * dd0 / 2

    t0 = math.pow(math.tan(phi1), 2)
    Q0 = e1sq * math.pow(math.cos(phi1), 2)
    fact3 = (5 + 3 * t0 + 10 * Q0 - 4 * Q0 * Q0 -
             9 * e1sq) * math.pow(dd0, 4) / 24

    fact4 = (61 + 90 * t0 + 298 * Q0 + 45 * t0 * t0 - 252 *
             e1sq - 3 * Q0 * Q0) * math.pow(dd0, 6) / 720

    lof1 = _a1 / (n0 * k0)
    lof2 = (1 + 2 * t0 + Q0) * math.pow(dd0, 3) / 6.0
    lof3 = (5 - 2 * Q0 + 28 * t0 - 3 * math.pow(Q0, 2) + 8 *
            e1sq + 24 * math.pow(t0, 2)) * math.pow(dd0, 5) / 120
    _a2 = (lof1 - lof2 + lof3) / math.cos(phi1)
    _a3 = _a2 * 180 / math.pi

    latitude = 180 * (phi1 - fact1 * (fact2 + fact3 + fact4)) / math.pi

    if not northernHemisphere:
        latitude = -latitude

    longitude = ((zone > 0) and (6 * zone - 183.0) or 3.0) - _a3

    return {"latitude": latitude, "longitude": longitude}


async def get_utm_coordinates(base_tour_dir, ele_profile_obj, dsm_path):
    utm_coord_list = []
    try:
        file_coord_list = []
        for coord in list(utils.coords(ele_profile_obj["line_string"])):
            file_coord_list.append(",".join(map(str, coord)))

        context = grass.create_context(
            {
                "auto_cleanup": False,
                "base_dir": base_tour_dir,
            }
        )
        context.add_file("wgs84_coord_file.txt", "\n".join(file_coord_list))
        context.add_file("utm_coord_file.csv", "")
        context.add_param("dsm_file", dsm_path)
        context.set_location(dsm_path)
        status = await context.execute(
            os.path.join(
                os.path.dirname(os.path.abspath(__file__)
                                ), "wgs84_to_utm_coordinates.py"
            )
        )
        if type(status) == type("str") and status == "success":
            with open(context.serialize()["script_opts"]["utm_coord_file"], 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    utm_coord_list.append(row['x'])
                    utm_coord_list.append(row['y'])
            context.cleanup()
            return utm_coord_list
        else:
            context.cleanup()
            print("Error while completing task")
    except Exception as err:
        context.cleanup()
        print("Error in get_utm_coordinates method: {}".format(err))
        await update_elev_profile_status(ele_profile_obj, "error: {}".format(err))


async def calc_elev_profile(ele_profile_obj):
    try:
        tour_id = ele_profile_obj["tour_id"]
        base_tour_dir = os.path.join(MEDIA_ROOT, tour_id)
        dsm_path = os.path.join(base_tour_dir, "dsm.tif")
        await update_elev_profile_status(ele_profile_obj, "inprogress")
        if not os.path.isfile(dsm_path):
            raise Exception("DSM file not found")
        utm_coord_list = await get_utm_coordinates(base_tour_dir, ele_profile_obj, dsm_path)
        context = grass.create_context(
            {
                "auto_cleanup": False,
                "base_dir": base_tour_dir,
            }
        )
        context.add_param("coord_list", ",".join(utm_coord_list))
        context.add_param("resolution", ele_profile_obj["resolution"])
        context.add_param("dsm_file", dsm_path)
        context.add_file("elevation_profile_file.txt", "")
        context.set_location(dsm_path)
        status = await context.execute(
            os.path.join(
                os.path.dirname(os.path.abspath(__file__)
                                ), "calc_elevation_profile.py"
            )
        )
        if type(status) == type("str") and status == "success":
            elev_data = []
            projection = get_projection_of_dsm(dsm_path)
            zone = projection["zone"]
            isNorth = projection["isNorth"]
            with open(context.serialize()["script_opts"]["elevation_profile_file"], 'r') as file:
                cf = csv.DictReader(
                    file,
                    fieldnames=[
                        'easting',
                        'northing',
                        'distance',
                        'elevation',
                        'rgbColor'
                    ],
                    delimiter=" "
                )
                for row in cf:
                    lnglat = utmToLatLng(
                        zone,
                        float(row["easting"]),
                        float(row["northing"]),
                        isNorth
                    )
                    row["latitude"] = str(lnglat["latitude"])
                    row["longitude"] = str(lnglat["longitude"])
                    elev_data.append(row)

            await update_elev_profile_status(ele_profile_obj, "completed", elev_data)
        else:
            print("Error while completing elevation profile task")
        context.cleanup()
    except Exception as err:
        print("Error in get_elevation_profile.py: {}".format(err))
        await update_elev_profile_status(ele_profile_obj, "error: {}".format(err))


def elev_profile_helper(elev_profile_status):
    return {
        "id": str(elev_profile_status["_id"]),
        "tour_id": elev_profile_status["tourId"],
        "project_id": elev_profile_status["projectId"],
        "status": elev_profile_status["status"],
        "line_string": elev_profile_status["lineString"],
        "tour_type": elev_profile_status["tourType"],
        "elec_profile_unique_id": elev_profile_status["elevationProfileUniqueId"],
        "created_by": elev_profile_status["createdBy"],
        "machine_id": elev_profile_status.get("machineId", ""),
        "resolution": elev_profile_status["resolution"],
    }


async def retrieve_elev_profile_queue():
    global elev_profile_statuses
    elev_profile_statuses = []
    elev_profile_status = await elev_profile_collection.find_one(
        {"status": "new", "machineId": MACHINE_ID}
    )
    if elev_profile_status:
        print(elev_profile_status)
        if check_tour_dsm_exists(elev_profile_helper(elev_profile_status)["tour_id"]):
            elev_profile_statuses.append(
                elev_profile_helper(elev_profile_status))
        else:
            await update_elev_profile_status(elev_profile_helper(elev_profile_status), " Error: DSM File does not exist.")
    return


logger = logging.getLogger(__name__)


def check_tour_dsm_exists(tour_id):
    if os.path.isfile(os.path.join(MEDIA_ROOT, tour_id, "dsm.tif")):
        return True
    return False


def is_elev_profile_req_valid(elev_profile_obj):
    try:
        if (
            elev_profile_obj["machine_id"] != ""
            and elev_profile_obj["machine_id"].lower() == MACHINE_ID.lower()
            and elev_profile_obj["status"].lower() == "new"
            and elev_profile_obj["tour_type"] == "L"
        ):
            return True
        return False
    except Exception as err:
        logger.error("Error in is_elev_profile_req_valid method")
        raise Exception("Error in is_elev_profile_req_valid method")
        return False


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    while True:
        elev_profile_statuses = []
        try:
            loop.run_until_complete(retrieve_elev_profile_queue())
            new_elev_profile_req = False
            if len(elev_profile_statuses) > 0:
                for elev_profile_req in elev_profile_statuses:
                    if is_elev_profile_req_valid(elev_profile_req):
                        new_elev_profile_req = elev_profile_req
                        break
                if new_elev_profile_req:
                    loop.run_until_complete(
                        calc_elev_profile(new_elev_profile_req))
            else:
                sleep(120)
        except Exception as e:
            print(e)
            logger.info(e)
