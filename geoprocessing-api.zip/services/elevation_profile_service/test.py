from geojson import FeatureCollection, utils

line_string = {
    "type": "FeatureCollection",
    "features": [
            {
                "type": "Feature",
                "properties": {},
                "geometry": {
                    "type": "LineString",
                    "coordinates": [
                        [
                            73.395516872406,
                            26.227603744028972
                        ],
                        [
                            73.39549541473389,
                            26.224600937787763
                        ],
                        [
                            73.39641809463501,
                            26.22232953285104
                        ]
                    ]
                }
            },

    ]
}
file_data = []
for coord in list(utils.coords(line_string)):
    file_data.append(",".join(map(str, coord)))
print("\n".join(file_data))
