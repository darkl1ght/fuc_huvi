import multiprocessing
import os
import getpass
linux_username = getpass.getuser()
from dotenv import load_dotenv
dotenv_path="/home/{0}/geoprocessing-api/app/.env".format(linux_username)
load_dotenv(dotenv_path)

name = "HUVIAiR's Gunicorn Config for FastAPI"
accesslog = "/home/{0}/geoprocessing-api/services/gunicorn_fastapi_service/logs/gunicorn-access.log".format(linux_username)
errorlog = "/home/{0}/geoprocessing-api/services/gunicorn_fastapi_service/logs/gunicorn-error.log".format(linux_username)

bind = "unix:app.server.app.sock"
umask = 7
worker_class = "uvicorn.workers.UvicornWorker"
workers = 4#multiprocessing.cpu_count() * 2 + 1
worker_connections = 1024
backlog = 2048
max_requests = 5120
timeout = 120
keepalive = 2

debug = os.environ.get("debug", "false") == "true"
reload = debug
preload_app = False
daemon = False
