#!/usr/local/bin/python3.9

from dotenv import load_dotenv
import os
import re
import json
import random
import logging
import subprocess
import glob
import shutil
import requests
from time import sleep
from datetime import datetime, timedelta
from pymongo import MongoClient
from bson.objectid import ObjectId
import itertools
from subprocess import CalledProcessError
import motor.motor_asyncio
import asyncio
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from datetime import datetime, timedelta
from sendgrid.helpers.mail import Mail, From, Subject, To, Cc, Bcc
from sendgrid import SendGridAPIClient
import getpass
import zipfile

linux_username = getpass.getuser()
dotenv_path = "/home/{0}/geoprocessing-api/app/.env".format(linux_username)
load_dotenv(dotenv_path)


# BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(
#     os.path.dirname(os.path.abspath(__file__)))))
BASE_DIR = "/home/{0}".format(linux_username)
MACHINE_ID = os.environ.get("MACHINE_ID")
# with open("/etc/machine-id", "r") as reader:
#     MACHINE_ID = reader.readline().rstrip("\n")
MAPBOX_ACCESS_TOKEN = os.environ.get("MAPBOX_ACCESS_TOKEN")
MAPBOX_USERNAME = os.environ.get("MAPBOX_USERNAME")
MONGODB_CONNECTION_STRING = os.environ.get("MONGODB_CONNECTION_STRING")
MONGODB_DATABASE_NAME = os.environ.get("MONGODB_DATABASE_NAME")
MAPOUTPUTS_CONTAINER = os.environ.get("MAPOUTPUTS_CONTAINER")
POINTCLOUDS_CONTAINER = os.environ.get("POINTCLOUDS_CONTAINER")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_CONNECTION_STRING)
database = client[MONGODB_DATABASE_NAME]
config_master_data_collection = database.get_collection("processingparams")
processing_statistics_collection = database.get_collection(
    "processingstatistics")
aerial_tours_collection = database.get_collection("aerialtours")
projects_collection = database.get_collection("projects")
email_templates_collection = database.get_collection("emailtemplates")

from_email = From("info@huviair.com", "Huviair Support")
project_id = ""
tour_id = ""

# to e-mail blob url

tiled_model_blob_url = ""
blob_dtm_url = ""
blob_dsm_url = ""
zipped_main_folder_url = ""
blob_orthomosaic_url = ""


async def begin_image_processing(processing_status):
    # with MongoClient(MONGO_DETAILS) as connection:
    #     database = connection.geoprocessing_db
    #     global processing_statistics_collection
    #     processing_statistics_collection = database.get_collection(
    #         "processing_statistics_collection")
    try:
        global tour_id
        tour_id = processing_status["tour_id"]
        global project_id
        project_id = processing_status["project_id"]
        start_time = datetime.now()

        curr_step = 1
        processing_params: dict = json.loads(
            processing_status["processing_params"])
        blob_path = processing_params.get("blob_path")
        geo_projection = "EPSG::4326"

        await update_processing_event(
            tour_id, "Process Started", "Started", "Process Started"
        )

        # get images downloaded from the blob path
        images_source_path = await download_images_from_blob(blob_path, start_time)

        tours_base_dir = os.path.join(BASE_DIR, "tours")
        tour_dir = os.path.join(tours_base_dir, tour_id)
        # TODO test next 3 statements if they are required or not.
        if processing_params.get("tour_dir_created", "false") == "false":
            # os.makedirs(name=tours_base_dir, mode=0o777, exist_ok=True)
            oldmask = os.umask(000)
            os.makedirs(name=tour_dir, mode=0o777, exist_ok=True)
            images_dest_path = os.path.join(tour_dir, "images")
            os.makedirs(name=images_dest_path, mode=0o777, exist_ok=True)
            os.makedirs(name=os.path.join(tour_dir, "main"),
                        mode=0o755, exist_ok=True)
            os.makedirs(
                name=os.path.join(tour_dir, "export"), mode=0o777, exist_ok=True
            )
            os.makedirs(name=os.path.join(tour_dir, "logs"),
                        mode=0o777, exist_ok=True)
            os.umask(oldmask)

        # deleting existing images in the destination path
        for image in os.listdir(images_dest_path):
            image_path = os.path.join(images_dest_path, image)
            try:
                if os.path.isfile(image_path) or os.path.islink(image_path):
                    os.unlink(image_path)
                elif os.path.isdir(image_path):
                    shutil.rmtree(image_path)
            except Exception as err:
                print("Failed to delete %s. Reason: %s" % (image_path, err))

        # copy/move image paths from blob downloaded location to images folder created above
        # print("copying files from {0} to {1}".format(
        #     images_source_path, images_dest_path))
        for jpgfile in glob.iglob(os.path.join(images_source_path, "**")):
            shutil.move(jpgfile, images_dest_path)
        # print("copying files completed")
        res = await update_processing_event(
            tour_id,
            "Downloading Blob Images Completed",
            "Completed",
            "Downloading Blob Images",
        )

        # deleting downloaded temporary folder
        # print("deleting downloaded temporary folder at location: {}".format(
        #     images_source_path))
        os.rmdir(images_source_path)
        # print("deleted temporary folder successfully")

        # executing tasks sequentially
        await update_overall_processing_status(
            tour_id, "Image Processing Started", start_time
        )
        # Step 1
        output = False
        step_options = {
            "tour_id": tour_id,
            "geo_projection": geo_projection,
            "execution_step": 1,
        }
        args = get_command(step_options)
        curr_step = step_options["execution_step"]
        output = await run_command(args)

        if output:
            output = False
            # Step 2
            alignment_accuracy = processing_params.get("alignment_accuracy")
            keypoint_limit = processing_params.get("keypoint_limit")
            tiepoint_limit = processing_params.get("tiepoint_limit")
            guided_matching = processing_params.get("guided_matching")

            step_options = {
                "tour_id": tour_id,
                "geo_projection": geo_projection,
                "alignment_accuracy": alignment_accuracy,
                "keypoint_limit": keypoint_limit,
                "tiepoint_limit": tiepoint_limit,
                "guided_matching": guided_matching,
                "execution_step": 2,
            }
            args = get_command(step_options)
            curr_step = step_options["execution_step"]
            output = await run_command(args)

        if output:
            output = False
            # Step 3
            depthmap_accuracy = processing_params.get("depthmap_accuracy")
            filter_mode = processing_params.get("filter_mode")
            reuse_depth = processing_params.get("reuse_depth")

            step_options = {
                "tour_id": tour_id,
                "geo_projection": geo_projection,
                "depthmap_accuracy": depthmap_accuracy,
                "filter_mode": filter_mode,
                "execution_step": 3,
                "reuse_depth": reuse_depth,
            }
            args = get_command(step_options)
            curr_step = step_options["execution_step"]
            output = await run_command(args)

        # checking whether to execute step 4 or not
        execute_step_4 = (
            processing_params.get("build_dsm", "false") == "true"
            or processing_params.get("build_dtm", "false") == "true"
        )

        # Step 4
        if execute_step_4 and output:
            output = False
            build_dsm = processing_params.get("build_dsm")
            export_dsm_tiff = processing_params.get("export_dsm_tiff")
            export_dsm_xyz = processing_params.get("export_dsm_xyz")
            build_dtm = processing_params.get("build_dtm")
            export_dtm = processing_params.get("export_dtm")
            max_angle = processing_params.get("max_angle")
            max_distance = processing_params.get("max_distance")
            cell_size = processing_params.get("cell_size")

            step_options = {
                "tour_id": tour_id,
                "geo_projection": geo_projection,
                "export_dsm_tiff": export_dsm_tiff,
                "export_dsm_xyz": export_dsm_xyz,
                "build_dtm": build_dtm,
                "build_dsm": build_dsm,
                "export_dtm": export_dtm,
                "max_angle": max_angle,
                "max_distance": max_distance,
                "cell_size": cell_size,
                "execution_step": 4,
            }

            if (
                processing_params.get("dsm_projection_code", False)
                and processing_params.get("tour_type") == "L"
            ):
                step_options["dsm_projection_code"] = processing_params.get(
                    "dsm_projection_code"
                )
                step_options["export_volume_dsm"] = "true"

            args = get_command(step_options)
            curr_step = step_options["execution_step"]
            output = await run_command(args)

        # Step 5
        # checking whether to execute step 5 or not
        execute_step_5 = processing_params.get(
            "export_raster", "false") == "true"
        if execute_step_5 and output:
            output = False
            export_raster = processing_params.get("export_raster")
            refine_seamlines = processing_params.get("refine_seamlines")
            step_options = {
                "tour_id": tour_id,
                "geo_projection": geo_projection,
                "refine_seamlines": refine_seamlines,
                "export_raster": export_raster,
                "execution_step": 5,
            }
            args = get_command(step_options)
            curr_step = step_options["execution_step"]
            output = await run_command(args)

        # Step 6
        # checking whether to execute step 6 or not
        execute_step_6 = processing_params.get(
            "build_tiled_model", "false") == "true"

        if execute_step_6 and output:
            output = False
            face_count = processing_params.get("face_count")
            build_tiled_model = processing_params.get("build_tiled_model")
            export_tiled_model = processing_params.get("export_tiled_model")

            step_options = {
                "tour_id": tour_id,
                "geo_projection": geo_projection,
                "face_count": face_count,
                "build_tiled_model": build_tiled_model,
                "export_tiled_model": export_tiled_model,
                "execution_step": 6,
            }
            args = get_command(step_options)
            curr_step = step_options["execution_step"]
            output = await run_command(args)

        execute_shape_step = processing_params.get(
            "build_contour", "false") == "true"

        if execute_shape_step and output:
            output = False
            # shape step options
            build_contour = processing_params.get("build_contour")
            contour_interval = processing_params.get("contour_interval")
            shape_file_type = processing_params.get("shape_file_type")
            export_contour = processing_params.get("export_contour")

            step_options = {
                "tour_id": tour_id,
                "geo_projection": geo_projection,
                "build_contour": build_contour,
                "contour_interval": contour_interval,
                "shape_file_type": shape_file_type,
                "build_dtm": "true",
                "export_contour": export_contour,
                "execution_step": 7,
            }
            args = get_command(step_options)
            curr_step = step_options["execution_step"]
            output = await run_command(args)

        # Step 8
        # checking whether to execute step 6 or not
        execute_step_8 = processing_params.get(
            "export_point_cloud", "false") == "true" and \
            processing_params.get("dsm_projection_code", False) and \
            (
            processing_params.get("tour_type") == "L" or
                processing_params.get("tour_type") == "M" or
            processing_params.get("tour_type") == "C" or
            processing_params.get("tour_type") == "F"
        )

        if execute_step_8 and output:
            output = False
            export_point_cloud = processing_params.get("export_point_cloud")
            step_options = {
                "tour_id": tour_id,
                "geo_projection": geo_projection,
                "export_point_cloud": export_point_cloud,
                "execution_step": 8,
                "dsm_projection_code": processing_params.get("dsm_projection_code"),
            }
            args = get_command(step_options)
            curr_step = step_options["execution_step"]
            output = await run_command(args)

        step_4_files_present = False
        step_5_files_present = False
        step_6_files_present = False
        step_7_files_present = False
        step_8_files_present = False
        if output:
            # check all the export files exist or not
            try:
                if execute_step_4:
                    if processing_params.get("export_dsm_tiff", "false") == "true":
                        step_4_files_present = os.path.isfile(
                            os.path.join(tour_dir, "export", "dsm-mapbox.tif")
                        )
                        step_4_files_present = os.path.isfile(
                            os.path.join(tour_dir, "export",
                                         "dsm-elevation.tif")
                        )
                    if processing_params.get("export_dtm", "false") == "true":
                        step_4_files_present = os.path.isfile(
                            os.path.join(tour_dir, "export", "dtm-mapbox.tif")
                        )
                        step_4_files_present = os.path.isfile(
                            os.path.join(tour_dir, "export",
                                         "dtm-elevation.tif")
                        )
                if execute_step_5 and (
                    processing_params.get("export_raster", "false") == "true"
                ):
                    step_5_files_present = os.path.isfile(
                        os.path.join(tour_dir, "export", "orthomosaic.tif")
                    )
                if execute_step_6 and (
                    processing_params.get(
                        "export_tiled_model", "false") == "true"
                ):
                    step_6_files_present = os.path.isfile(
                        os.path.join(tour_dir, "export", "tiled_model.slpk")
                    )
                if execute_shape_step and (
                    processing_params.get("export_contour", "false") == "true"
                ):
                    step_7_files_present = os.path.isfile(
                        os.path.join(tour_dir, "export", "contour.zip")
                    )
                if execute_step_8 and (
                    processing_params.get(
                        "export_point_cloud", "false") == "true"
                ):
                    step_8_files_present = os.path.isfile(
                        os.path.join(tour_dir, "export", "%s.zip" % (tour_id))
                    )
            except Exception as err:
                error = "Error while searching for exported files. Error: {}".format(
                    str(err)
                )
                await update_overall_processing_status(
                    tour_id, "Error: {}".format(error), start_time
                )
                await send_email("error", error)
                print(json.dumps({"success": False, "error": error}))
                return {"success": False, "error": error}

        step_4_upload_complete = True
        step_5_upload_complete = True
        step_6_upload_complete = True
        step_7_upload_complete = True
        step_8_upload_complete = True
        if execute_step_4 and step_4_files_present:
            step_4_upload_complete = False
            try:
                if processing_params.get("export_dsm_tiff", "false") == "true":
                    dsm_mapbox_tif = os.path.join(
                        tour_dir, "export", "dsm-mapbox.tif")
                    if processing_params.get("tour_type") == "C":
                        res = await upload_files_to_blob(
                            dsm_mapbox_tif, tour_id, start_time, "blob-dsm"
                        )
                        if not res["success"]:
                            error = "Error while uploading dsm-mapbox.tif. Error: {}".format(
                                res["error"]
                            )
                            raise Exception(error)
                    else:
                        res = await upload_files_to_mapbox(
                            dsm_mapbox_tif, tour_id, "dsm-mapbox.tif", "dsm", start_time
                        )
                        if not res["success"]:
                            error = "Error while uploading dsm-mapbox.tif. Error: {}".format(
                                res["error"]
                            )
                            raise Exception(error)
                        dsm_blob_tif = os.path.join(
                            tour_dir, "export", "dsm-elevation.tif"
                        )
                        res = await upload_files_to_blob(
                            dsm_blob_tif, tour_id, start_time, "blob-dsm-elevation"
                        )
                        if not res["success"]:
                            error = "Error while uploading dsm-elevation.tif. Error: {}".format(
                                res["error"]
                            )
                            raise Exception(error)
                if processing_params.get("export_dtm", "false") == "true":
                    dtm_mapbox_tif = os.path.join(
                        tour_dir, "export", "dtm-mapbox.tif")
                    if processing_params.get("tour_type") == "C":
                        res = await upload_files_to_blob(
                            dtm_mapbox_tif, tour_id, start_time, "blob-dtm"
                        )
                        if not res["success"]:
                            error = "Error while uploading dtm-mapbox.tif to blob. Error: {}".format(
                                res["error"]
                            )
                            raise Exception(error)
                    else:
                        res = await upload_files_to_mapbox(
                            dtm_mapbox_tif, tour_id, "dtm-mapbox.tif", "dtm", start_time
                        )
                        if not res["success"]:
                            error = "Error while uploading dtm-mapbox.tif to Mapbox. Error: {}".format(
                                res["error"]
                            )
                            raise Exception(error)
                        dtm_blob_tif = os.path.join(
                            tour_dir, "export", "dtm-elevation.tif"
                        )
                        res = await upload_files_to_blob(
                            dtm_blob_tif, tour_id, start_time, "blob-dtm-elevation"
                        )
                        if not res["success"]:
                            error = "Error while uploading dtm-elevation.tif. Error: {}".format(
                                res["error"]
                            )
                            raise Exception(error)
                step_4_upload_complete = True
            except Exception as err:
                await update_overall_processing_status(
                    tour_id, "Error: {}".format(err), start_time
                )
                await send_email("error", err)
                return {"success": False, "error": err}

        if (
            execute_step_5
            and step_5_files_present
            and (processing_params.get("export_raster", "false") == "true")
        ):
            step_5_upload_complete = False
            try:
                orthomosaic_file_path = os.path.join(
                    tour_dir, "export", "orthomosaic.tif"
                )
                res = await upload_files_to_mapbox(
                    orthomosaic_file_path,
                    tour_id,
                    "orthomosaic.tif",
                    "orthomosaic",
                    start_time,
                )
                if not res["success"]:
                    error = "Error while uploading orthomosaic.tif to Mapbox. Error: {}".format(
                        res["error"]
                    )
                    raise Exception(error)
                step_5_upload_complete = True
            except Exception as err:
                await update_overall_processing_status(
                    tour_id, "Error: {}".format(err), start_time
                )
                await send_email("error", err)
                return {"success": False, "error": err}

        if (
            execute_step_6
            and step_6_files_present
            and (processing_params.get("export_tiled_model", "false") == "true")
        ):
            step_6_upload_complete = False
            try:
                tiled_model_file_path = os.path.join(
                    tour_dir, "export", "tiled_model.slpk"
                )
                res = await upload_files_to_blob(
                    tiled_model_file_path, tour_id, start_time, "tiled-model"
                )
                if not res["success"]:
                    error = "Error while uploading tiled_model.slpk. Error: {}".format(
                        res["error"]
                    )
                    raise Exception(error)
                step_6_upload_complete = True
            except Exception as err:
                await update_overall_processing_status(
                    tour_id, "Error: {}".format(err), start_time
                )
                await send_email("error", err)
                return {"success": False, "error": err}

        if (
            execute_shape_step
            and step_7_files_present
            and (processing_params.get("export_contour", "false") == "true")
        ):
            step_7_upload_complete = False
            try:
                shape_file_path = os.path.join(
                    tour_dir, "export", "contour.zip")
                res = await upload_files_to_mapbox(
                    shape_file_path, tour_id, "contour.zip", "shapefile", start_time
                )
                if not res["success"]:
                    error = "Error while uploading contour.zip to Mapbox. Error: {}".format(
                        res["error"]
                    )
                    raise Exception(error)
                step_7_upload_complete = True
            except Exception as err:
                await update_overall_processing_status(
                    tour_id, "Error: {}".format(err), start_time
                )
                await send_email("error", err)
                print(json.dumps({"success": False, "error": err}))
                return {"success": False, "error": err}

        if (
            execute_step_8
            and step_8_files_present
            and processing_params.get("export_point_cloud", "false") == "true"
        ):
            step_8_upload_complete = False
            try:
                point_cloud_file_path = os.path.join(
                    tour_dir, "export", "%s.zip" % (tour_id)
                )
                extracted_point_cloud_folder_path = point_cloud_file_path.split(".")[
                    0]
                with zipfile.ZipFile(point_cloud_file_path, 'r') as zip_ref:
                    zip_ref.extractall(extracted_point_cloud_folder_path)

                res = await upload_point_cloud_folder_to_blob(
                    extracted_point_cloud_folder_path, tour_id, start_time, "point-cloud"
                )
                if not res["success"]:
                    error = "Error while uploading point cloud. Error: {}".format(
                        res["error"]
                    )
                    raise Exception(error)
                step_8_upload_complete = True
            except Exception as err:
                await update_overall_processing_status(
                    tour_id, "Error: {}".format(err), start_time
                )
                await send_email("error", err)
                return {"success": False, "error": err}

        if (
            step_4_upload_complete
            and step_5_upload_complete
            and step_6_upload_complete
            and step_7_upload_complete
            and step_8_upload_complete
        ):
            # proc_status = await retrieve_proc_status_by_tour_id(
            #     tour_id)
            # print(json.dumps({
            #     "success": True,
            #     "error": None,
            #     "message": "Processing and Uploads Complete",
            #     "status": proc_status
            # }))
            # print("{} success".format(tour_id))

            # copy map urls to aerial_tour and update status
            proc_status = await processing_statistics_collection.find_one(
                {"tour_id": tour_id}
            )
            await aerial_tours_collection.find_one_and_update(
                {"tourId": tour_id},
                {
                    "$set": {
                        "mapUrls": proc_status["map_urls"],
                        "status.code": "AT10003",
                        "status.desc": "Ready for visualization",
                    }
                },
            )

            await update_overall_processing_status(
                tour_id, "Image Processing and Uploads Complete", start_time
            )

            if processing_params.get("tour_type") == "S" and step_5_files_present:
                orthomosaic_file_path = os.path.join(
                    tour_dir, "export", "orthomosaic.tif"
                )
                await upload_files_to_blob(
                    orthomosaic_file_path,
                    tour_id,
                    start_time,
                    "blob-orthomosaic",
                    72
                )
            else:
                # moving images
                processed_folder_path = os.path.join(tour_dir, "processed_psx")
                if not os.path.isdir(processed_folder_path):
                    os.makedirs(processed_folder_path,
                                mode=0o777, exist_ok=True)
                final_images_path = os.path.join(
                    processed_folder_path, "images")
                if not os.path.isdir(final_images_path):
                    os.makedirs(final_images_path, mode=0o777, exist_ok=True)

                for jpgfile in glob.iglob(os.path.join(images_dest_path, "**")):
                    shutil.move(jpgfile, final_images_path)

                # moving main folder
                final_main_path = os.path.join(processed_folder_path, "main")
                if not os.path.isdir(final_main_path):
                    os.makedirs(final_main_path, mode=0o777, exist_ok=True)
                main_folder_path = os.path.join(tour_dir, "main")
                for file in glob.iglob(os.path.join(main_folder_path, "**")):
                    shutil.move(file, final_main_path)

                zip_main_file_path = processed_folder_path + ".zip"
                shutil.make_archive(
                    processed_folder_path,
                    "zip",
                    processed_folder_path,
                )

                await upload_files_to_blob(
                    zip_main_file_path, tour_id, start_time, "zipped_main_file", 72
                )

            await update_processing_event(
                tour_id, "Process Complete", "Completed", "Process Complete"
            )

            await send_email("success", None)

            logs_dir = os.path.join(BASE_DIR, "geoprocessing_logs")
            if not os.path.isdir(logs_dir):
                os.makedirs(logs_dir, exist_ok=True)

            log_src_path = os.path.join(tour_dir, "logs", "process_log.log")
            log_file_name = "{0}_process_log.log".format(tour_id)
            log_dest_path = os.path.join(logs_dir, log_file_name)
            shutil.move(log_src_path, log_dest_path)

            shutil.rmtree(tour_dir, ignore_errors=True)
            project_id = ""
            tour_id = ""
            # return {
            #     "success": True,
            #     "error": None,
            #     "message": "Processing and Uploads Complete",
            #     "status": proc_status
            # }
        else:
            error = "Some error occured. Step {}".format(curr_step)
            await update_overall_processing_status(
                tour_id, "Error: {}".format(error), start_time
            )
            await send_email("error", error)
            print(json.dumps({"success": False, "error": error}))
            return {"success": False, "error": error}
    except Exception as err:
        error = "Some exception occured. Step:{0}. Error: {1}".format(
            curr_step, str(err)
        )
        await update_overall_processing_status(tour_id, error, start_time)
        await send_email("error", error)
        # print(json.dumps({"success": False, "error": error}))
        return {"success": False, "error": error}


def generateUUID():
    # generates UUID of size 21 size from below pattern
    # generateUUID takes very less time in comparison to regex sub function below
    # text = ":x::x::x::x:-4:x::x::x:-:y::x::z::x:"
    # def repl(m):
    #     r = random.randint(0, 15)
    #     contents = m.group(1)
    #     if contents == "x":
    #         return hex(r)[2:]
    #     if contents == "y":
    #         return hex((r & 3) | 8)[2:]
    #     if contents == "z":
    #         return hex(int(datetime.now().timestamp()))[2:]

    # print(re.sub(":(.+?):", repl, text))
    z = hex(int(datetime.now().timestamp()))[2:]
    s = "xxxx-4xxx-yxzx"
    uuid = ""
    for i in range(0, len(s)):
        if s[i] == "x" or s[i] == "y":
            r = random.randint(0, 15)
            v = hex(r if s[i] == "x" else (r & 3) | 8)[2:]
            a = "{}".format(s[i]).replace(s[i], v)
            uuid = uuid + a
        else:
            uuid = uuid + s[i]
    uuid = uuid.replace("z", z)
    return uuid


async def get_aerial_tour_details(tour_id, project_id):
    data = {}
    project = await projects_collection.find_one({"projectId": project_id})
    data["project_name"] = project["projectName"]
    tour = await aerial_tours_collection.find_one({"tourId": tour_id})
    data["tour_name"] = tour["tourName"]
    return data


async def send_email(email_type, error_msg=None):
    global tiled_model_blob_url
    global blob_dtm_url
    global blob_dsm_url
    global zipped_main_folder_url
    global blob_orthomosaic_url
    global from_email
    html_content = ""
    data = await get_aerial_tour_details(tour_id, project_id)
    if email_type == "success":
        email_template = await email_templates_collection.find_one({"code": "ET10003"})

        # to_emails = await get_email_recipients(project_id)
        # currently sending success emails to OPS team only
        # change when to-emails are modified
        html_content = email_template["body"].format(
            project=data["project_name"], tour=data["tour_name"], user="Team"
        )

        # tour blob urls
        blob_url_info = "Urls: <br />"
        if tiled_model_blob_url != "":
            blob_url_info += (
                "<br /><strong>Blob Tiled Model URL:</strong> {url}<br />".format(
                    url=tiled_model_blob_url
                )
            )
            tiled_model_blob_url = ""
        if blob_dtm_url != "":
            blob_url_info += "<br /><strong>Blob DTM URL:</strong> {url}<br />".format(
                url=blob_dtm_url
            )
            blob_dtm_url = ""
        if blob_dsm_url != "":
            blob_url_info += "<br /><strong>Blob DSM URL:</strong> {url}<br />".format(
                url=blob_dsm_url
            )
            blob_dsm_url = ""
        if zipped_main_folder_url != "":
            blob_url_info += (
                "<br /><strong>Zipped Metashape PSX file:</strong> {url}<br />".format(
                    url=zipped_main_folder_url
                )
            )
            zipped_main_folder_url = ""
        if blob_orthomosaic_url != "":
            blob_url_info += (
                "<br /><strong>Blob Orthomosaic URL:</strong> {url}<br />".format(
                    url=blob_orthomosaic_url
                )
            )
            blob_orthomosaic_url = ""

        if blob_url_info != "Urls: <br />":
            html_content = html_content.format(extra=blob_url_info)
        else:
            html_content = html_content.format(extra="")

    elif email_type == "error":
        email_template = await email_templates_collection.find_one({"code": "ET10006"})

        html_content = email_template["body"].format(
            project=data["project_name"],
            tour=data["tour_name"],
            user="Team",
            error=error_msg,
        )

    # cleaning up html code to make plain text
    plain_text_content = re.sub(
        "\{.*?\}", "", re.sub("<.*?>", "",
                              html_content.replace("<br />", "\n"))
    ).replace("table, th, td ", "")

    email_subject = Subject(
        email_template["subject"].format(
            project=data["project_name"], tour=data["tour_name"]
        )
    )

    to_emails = []
    for person in email_template["to"]:
        to_emails.append(To(person["email"], person["name"], p=0))

    cc_email = []
    for person in email_template["cc"]:
        cc_email.append(Cc(person["email"], person["name"], p=0))

    bcc_email = []
    for person in email_template["bcc"]:
        bcc_email.append(Bcc(person["email"], person["name"], p=0))

    message = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=email_subject,
        html_content=html_content,
        plain_text_content=plain_text_content,
        is_multiple=True,
    )

    if len(bcc_email) != 0:
        message.bcc = bcc_email

    if len(cc_email) != 0:
        message.cc = cc_email

    try:
        sg = SendGridAPIClient(os.environ.get("SENDGRID_API_KEY"))
        response = sg.send(message)
        print(response.status_code)
        # print(response.body)
        # print(response.headers)
    except Exception as e:
        print("Error while sending email: {}".format(e))
        return {"success": False, "error": "Error while sending email"}
    finally:
        tiled_model_blob_url = ""
        blob_dtm_url = ""
        blob_dsm_url = ""
        zipped_main_folder_url = ""
        blob_orthomosaic_url = ""


def get_command(options):
    metashape_shell_path = "/home/{0}/metashape-pro/metashape.sh".format(
        linux_username)
    metashape_script = "/home/{0}/geoprocessing-api/init_doc.py".format(
        linux_username)
    params = [
        ["--{}".format(opt), "{}".format(value)] for opt, value in options.items()
    ]
    joinedparams = list(itertools.chain(*params))
    command = [metashape_shell_path, "-platform",
               "offscreen", "-r", metashape_script]
    command.extend(joinedparams)

    return command


async def run_command(args):
    try:
        print("Executing command: {}".format(" ".join(args)))
        env_copy = os.environ.copy()
        process = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            universal_newlines=True,
            env=env_copy,
        )
        # print("Processing Started...")
        while True:
            output = process.stdout.readline()
            # print(output.strip())
            # Do something else
            return_code = process.poll()
            if return_code is not None:
                print("RETURN CODE {}".format(return_code))
                # Process has finished, read rest of the output
                if return_code == 0:
                    # print("Processing Completed.")
                    pass
                else:
                    for output in process.stdout.readlines():
                        print("non zero return code error: {}".format(
                            output.strip()))
                    error = (
                        "Some Error occured during script execution. Script: {}".format(
                            " ".join(args)
                        )
                    )
                    print(error)
                    return False
                break

    except Exception as err:
        print("Error while excuting the script. Error: {}".format(err))
        await send_email("error", err)
        return False
    else:
        return True


async def upload_files_to_mapbox(
    file_path, tour_id, file_name, file_type, start_time
) -> dict:
    prefix = ""
    if file_type == "dsm":
        prefix = "Mapbox DSM"
    elif file_type == "dtm":
        prefix = "Mapbox DTM"
    elif file_type == "orthomosaic":
        prefix = "Mapbox Orthomosaic"
    elif file_type == "shapefile":
        prefix = "Mapbox Shape File"
    try:
        status = "Mapbox Upload"
        desc = prefix + " Uploading Started."
        await update_processing_event(tour_id, desc, status, "Uploading Files")
        params = {"access_token": MAPBOX_ACCESS_TOKEN}
        credential_response = requests.post(
            "https://api.mapbox.com/uploads/v1/{username}/credentials".format(
                username=MAPBOX_USERNAME
            ),
            params=params,
        )
        if credential_response.status_code == requests.codes.ok:
            bucket_credentials = {
                "bucket": credential_response.json()["bucket"],
                "key": credential_response.json()["key"],
                "access_key_id": credential_response.json()["accessKeyId"],
                "secret_access_key": credential_response.json()["secretAccessKey"],
                "session_token": credential_response.json()["sessionToken"],
                "url": credential_response.json()["url"],
            }
            # $ export AWS_ACCESS_KEY_ID={accessKeyId}
            # $ export AWS_SECRET_ACCESS_KEY = {secretAccessKey}
            # $ export AWS_SESSION_TOKEN = {sessionToken}
            environ_copy = os.environ.copy()
            environ_copy["AWS_ACCESS_KEY_ID"] = bucket_credentials["access_key_id"]
            environ_copy["AWS_SECRET_ACCESS_KEY"] = bucket_credentials[
                "secret_access_key"
            ]
            environ_copy["AWS_SESSION_TOKEN"] = bucket_credentials["session_token"]
            args = [
                "aws",
                "s3",
                "cp",
                file_path,
                "s3://{bucket}/{key}".format(
                    bucket=bucket_credentials["bucket"], key=bucket_credentials["key"]
                ),
                "--region",
                "us-east-1",
            ]
            # example ["aws", "s3", "cp", "/Users/Darkl1ght/Downloads/dtm.tif", "s3://tilestream-tilesets-production/3b/_pending/sivkxkky7s2242g0h0uehwjkc/darkl1ght", "--region", "us-east-1"]
            process = subprocess.Popen(
                args, env=environ_copy, stdout=subprocess.PIPE, universal_newlines=True
            )
            # print("S3 Bucket Upload Started...")
            while True:
                output = process.stdout.readline()
                # print(output.strip())
                return_code = process.poll()
                if return_code is not None:
                    print("RETURN CODE {}".format(return_code))
                    # Process has finished, read rest of the output
                    if return_code == 0:
                        pass
                        # print("S3 Bucket Uploading Completed.")
                    else:
                        for output in process.stdout.readlines():
                            # pass
                            print(output.strip())
                        await send_email(
                            "error", "Error while uploading file to aws s3 bucket."
                        )
                        print(
                            "Some Error occured during script execution. Script: '{}'".format(
                                " ".join(args)
                            )
                        )
                    break
            if return_code != 0:
                error = "Some Error occured during script exection"
                await update_overall_processing_status(
                    tour_id, "Error: {}".format(error), start_time
                )
                await send_email("error", error)
                return {"success": False, "error": error}
            else:
                tileset_name = "{}".format(generateUUID())
                upload_id_payload = {
                    "url": "http://{bucket}.s3.amazonaws.com/{key}".format(
                        bucket=bucket_credentials["bucket"],
                        key=bucket_credentials["key"],
                    ),
                    "tileset": "{username}.{tileset_name}".format(
                        username=MAPBOX_USERNAME, tileset_name=tileset_name
                    ),
                    "name": "{tileset_name}".format(tileset_name=tileset_name),
                }
                headers = {
                    "Content-Type": "application/json",
                    "Cache-Control": "no-cache",
                }
                upload_id_response = requests.post(
                    "https://api.mapbox.com/uploads/v1/{username}".format(
                        username=MAPBOX_USERNAME
                    ),
                    params=params,
                    data=json.dumps(upload_id_payload),
                    headers=headers,
                )
                if upload_id_response.status_code == requests.codes.created:
                    while True:
                        sleep(5)
                        upload_status_response = requests.get(
                            "https://api.mapbox.com/uploads/v1/{username}/{id}".format(
                                username=MAPBOX_USERNAME,
                                id=upload_id_response.json()["id"],
                            ),
                            params=params,
                        )
                        if upload_status_response.status_code != requests.codes.ok:
                            error = "Error while fetching uploaded file's status. Upload File Respons Status Code: {}".format(
                                upload_status_response.status_code
                            )
                            await update_overall_processing_status(
                                tour_id, "Error: {}".format(error), start_time
                            )
                            await send_email("error", error)
                            return {"success": False, "error": error}
                        else:
                            if upload_status_response.json()["error"]:
                                error = (
                                    "Error while uploading the file. Error: {}".format(
                                        upload_status_response.json()["error"]
                                    )
                                )
                                await update_overall_processing_status(
                                    tour_id, "Error: {}".format(
                                        error), start_time
                                )
                                await send_email("error", error)
                                return {"success": False, "error": error}
                            if upload_status_response.json()["complete"]:
                                url = upload_status_response.json()["tileset"]
                                status = "Mapbox Upload"
                                desc = prefix + " Uploading Completed."
                                # print(status)
                                await update_processing_event(
                                    tour_id, desc, status, "Uploading Files"
                                )
                                await update_url(
                                    tour_id, url, file_type, file_name, "mapbox"
                                )
                                break
                            else:
                                # sleeping the process for 60 seconds before
                                # retrying another request to check if the
                                # upload is successfull
                                sleep(60)
                else:
                    error = "Error while fetching the uploaded file's upload_id. Upload id Response Status Code: {}".format(
                        upload_id_response.status_code
                    )
                    await update_overall_processing_status(
                        tour_id, "Error: {}".format(error), start_time
                    )
                    await send_email("error", error)
                    return {"success": False, "error": error}
        else:
            error = "Error while fetching mapbox S3 bucket credentials. Credential Response Status Code: {}".format(
                credential_response.status_code
            )
            await update_overall_processing_status(
                tour_id, "Error: {}".format(error), start_time
            )
            await send_email("error", error)
            return {"success": False, "error": error}
    except Exception as err:
        error = "Error in upload_files_to_mapbox function: Error: {}".format(
            str(err))
        await update_overall_processing_status(
            tour_id, "Error: {}".format(error), start_time
        )
        await send_email("error", error)
        return {"success": False, "error": error}
    else:
        return {"success": True, "error": ""}


async def upload_files_to_blob(filepath, tour_id, start_time, file_type, duration=24):
    try:
        prefix = ""
        if file_type == "blob-dsm-elevation":
            prefix = "Blob DSM Elevation"
        elif file_type == "blob-dtm-elevation":
            prefix = "Blob DTM Elevation"
        elif file_type == "tiled-model":
            prefix = "Blob Tiled Model"
        elif file_type == "blob-dtm":
            prefix = "Blob DTM"
        elif file_type == "blob-dsm":
            prefix = "Blob DSM"
        elif file_type == "zipped_main_file":
            prefix = "Zipped PSX Metashape File"
        elif file_type == "blob-orthomosaic":
            prefix = "Blob Orthomosaic"
        status = "Blob Upload"
        desc = (prefix + " Uploading Started.").strip()
        await update_processing_event(tour_id, desc, status, "Uploading Files")
        local_file_name = os.path.basename(filepath)
        upload_file_path = filepath
        connect_str = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
        AZURE_ACCOUNT_NAME = os.environ.get("AZURE_ACCOUNT_NAME")
        AZURE_PRIMARY_KEY = os.environ.get("AZURE_ACCOUNT_KEY")
        AZURE_BLOB = "{0}-{1}".format(generateUUID(), local_file_name)
        # Create the BlobServiceClient object which will be used to create a container client
        blob_service_client = BlobServiceClient.from_connection_string(
            connect_str)
        # Create a blob client using the local file name as the name for the blob
        blob_client = blob_service_client.get_blob_client(
            container=MAPOUTPUTS_CONTAINER, blob=AZURE_BLOB
        )

        def get_blob_sas(
            account_name, account_key, container_name, blob_name, duration
        ):
            return generate_blob_sas(
                account_name=account_name,
                container_name=container_name,
                blob_name=blob_name,
                account_key=account_key,
                permission=BlobSasPermissions(read=True),
                expiry=datetime.utcnow() + timedelta(hours=duration),
            )

        sas_token = get_blob_sas(
            AZURE_ACCOUNT_NAME,
            AZURE_PRIMARY_KEY,
            MAPOUTPUTS_CONTAINER,
            AZURE_BLOB,
            duration,
        )

        # print("\nUploading to Azure Storage as blob:\n\t" + local_file_name)
        # Upload the created file
        with open(upload_file_path, "rb") as data:
            blob_client.upload_blob(data)
        blob_url = blob_client.url
        blob_download_url = blob_url + "?" + sas_token
        status = "Blob Upload"
        desc = prefix + " Uploading Completed."
        update_url_for_mail(file_type, blob_download_url)
        await update_processing_event(tour_id, desc, status, "Uploading Files")
        await update_url(tour_id, blob_url, file_type, local_file_name, "blob")
    except Exception as err:
        error = "{}".format(str(err))
        await update_overall_processing_status(
            tour_id, "Error: {}".format(error), start_time
        )
        await send_email("error", error)
        return {"success": False, "error": error}
    else:
        return {"success": True, "error": ""}


async def upload_point_cloud_folder_to_blob(local_folder_path, tour_id, start_time, file_type):
    try:
        prefix = ""
        if file_type == "point-cloud":
            prefix = "Blob Point Cloud"
        status = "Blob Upload"
        desc = (prefix + " Uploading Started.").strip()
        await update_processing_event(tour_id, desc, status, "Uploading Files")
        connect_str = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
        blob_service_client = BlobServiceClient.from_connection_string(
            connect_str)
        container_client = blob_service_client.get_container_client(
            container=POINTCLOUDS_CONTAINER
        )
        path_remove = os.path.dirname(local_folder_path)
        for r, d, f in os.walk(local_folder_path):
            if f:
                for file in f:
                    file_path_on_azure = os.path.join(
                        r, file).replace(path_remove + "/", "")
                    file_path_on_local = os.path.join(r, file)
                    blob_client = container_client.get_blob_client(
                        file_path_on_azure)
                    with open(file_path_on_local, 'rb') as data:
                        blob_client.upload_blob(data)

        status = "Blob Upload"
        desc = prefix + " Uploading Completed."
        await update_processing_event(tour_id, desc, status, "Uploading Files")
        await aerial_tours_collection.find_one_and_update(
            {"tourId": tour_id},
            {
                "$set": {
                    "isPointCloudAvailable": True,
                }
            },
        )
    except Exception as err:
        error = "{}".format(str(err))
        await update_overall_processing_status(
            tour_id, "Error: {}".format(error), start_time
        )
        await send_email("error", error)
        return {"success": False, "error": error}
    else:
        return {"success": True, "error": ""}


def update_url_for_mail(file_type, blob_url):
    global tiled_model_blob_url
    global blob_dtm_url
    global blob_dsm_url
    global zipped_main_folder_url
    global blob_orthomosaic_url
    if file_type == "tiled-model":
        tiled_model_blob_url = blob_url
    elif file_type == "blob-dtm":
        blob_dtm_url = blob_url
    elif file_type == "blob-dsm":
        blob_dsm_url = blob_url
    elif file_type == "zipped_main_file":
        zipped_main_folder_url = blob_url
    elif file_type == "blob-orthomosaic":
        blob_orthomosaic_url = blob_url


async def get_email_recipients(project_id):
    project_data = await projects_collection.find_one({"projectId": project_id})
    email_recipients = []
    project_users = project_data["users"]
    for user in project_users:
        user_role = user["role"]
        # append only admins of the project for the mail
        if user_role["code"] == "UR10001":
            email_recipients.append(
                To(
                    email="{}".format(user["email"]),
                    name="{0} {1}".format(
                        user["firstName"].capitalize(
                        ), user["lastName"].capitalize()
                    ),
                    p=0,
                )
            )

    return email_recipients


async def update_overall_processing_status(
    tour_id, overall_processing_status, start_time
):
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if proc_status:
        proc_status["overall_processing_status"] = overall_processing_status
        proc_status["overall_processing_time"] = str(
            datetime.now() - start_time)
        updated_proc_status = await processing_statistics_collection.update_one(
            {"_id": ObjectId(proc_status["_id"])}, {"$set": proc_status}
        )
        if updated_proc_status:
            return True
        return False


# Retrieve a tour processing status with a matching tour ID
async def retrieve_proc_status_by_tour_id(tour_id: str):
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if proc_status:
        return processing_status_helper(proc_status)


def processing_status_helper(tour_processing_status):
    return {
        "id": str(tour_processing_status["_id"]),
        "tour_id": str(tour_processing_status["tour_id"]),
        "project_id": str(tour_processing_status["project_id"]),
        "current_status": tour_processing_status["current_status"],
        "machine": tour_processing_status["machine"],
        "overall_processing_time": tour_processing_status["overall_processing_time"],
        "overall_processing_status": tour_processing_status[
            "overall_processing_status"
        ],
        "map_urls": tour_processing_status["map_urls"],
        "events": tour_processing_status["events"],
        "payload": tour_processing_status["payload"],
        "processing_params": tour_processing_status["processing_params"],
    }


async def update_url(
    tour_id: str, url: str, filetype: str, file_name: str, uploadedTo: str
):
    mapbox_url_prefix = "mapbox://"
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    url_obj = ""
    if proc_status:
        if filetype == "dsm":
            url_obj = {
                "type": filetype,
                "key": "mapbox_dsm_url",
                "value": mapbox_url_prefix + url,
                "appendIndex": 1,
                "disabled": False,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "dtm":
            url_obj = {
                "type": filetype,
                "key": "mapbox_dtm_url",
                "value": mapbox_url_prefix + url,
                "appendIndex": 0,
                "disabled": False,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "orthomosaic":
            url_obj = {
                "type": filetype,
                "key": "mapbox_orthomosaic_url",
                "value": mapbox_url_prefix + url,
                "appendIndex": 2,
                "disabled": False,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "shapefile":
            url_obj = {
                "type": filetype,
                "shapeFileData": {
                    "type": "contour",
                    "columns": ["FID", "ELEVATION", "LAYER", "NAME"],
                },
                "key": "mapbox_shape_file_url",
                "value": mapbox_url_prefix + url,
                "appendIndex": 3,
                "disabled": True,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "blob-dsm-elevation":
            url_obj = {
                "type": filetype,
                "key": "dsm_elevation_blob_url",
                "value": url,
                "appendIndex": -1,
                "disabled": True,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "blob-dtm-elevation":
            url_obj = {
                "type": filetype,
                "key": "dtm_elevation_blob_url",
                "value": url,
                "appendIndex": -1,
                "disabled": True,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "tiled-model":
            url_obj = {
                "type": filetype,
                "key": "tiled_model_url",
                "value": url,
                "appendIndex": -1,
                "disabled": True,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "blob-dtm":
            url_obj = {
                "type": filetype,
                "key": "dtm_blob_url",
                "value": url,
                "appendIndex": -1,
                "disabled": True,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "blob-dsm":
            url_obj = {
                "type": filetype,
                "key": "dsm_blob_url",
                "value": url,
                "appendIndex": -1,
                "disabled": True,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        elif filetype == "blob-orthomosaic":
            url_obj = {
                "type": filetype,
                "key": "orthomosaic_blob_url",
                "value": url,
                "appendIndex": -1,
                "disabled": True,
                "addedBy": "system",
                "uploadedAt": datetime.now(),
                "filename": file_name,
                "uploadedTo": uploadedTo,
            }
        if url_obj != "":
            proc_status["map_urls"].append(url_obj)
            updated_proc_status = await processing_statistics_collection.update_one(
                {"_id": ObjectId(proc_status["_id"])}, {"$set": proc_status}
            )
            if updated_proc_status:
                return True
            return False


async def update_processing_event(
    tour_id: str,
    description: str,
    status: str,
    overall_processing_status: str,
    machine_id=None,
):
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if proc_status:
        if machine_id:
            proc_status["machine"] = "{}".format(machine_id)
        proc_status["overall_processing_status"] = overall_processing_status
        proc_status["events"].append(
            {
                "description": description,
                "time": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                "status": status,
            }
        )
        updated_proc_status = await processing_statistics_collection.update_one(
            {"_id": ObjectId(proc_status["_id"])}, {"$set": proc_status}
        )
        if updated_proc_status:
            return True
        return False


async def download_images_from_blob(blob_path, start_time):
    try:
        # print("Azure Blob Storage v" + __version__)
        # Retrieve the connection string for use with the application. The storage
        # connection string is stored in an environment variable on the machine
        # running the application called AZURE_STORAGE_CONNECTION_STRING. If the environment variable is
        # created after the application is launched in a console or with Visual Studio,
        # the shell or application needs to be closed and reloaded to take the
        # environment variable into account.
        await update_processing_event(
            tour_id,
            "Downloading Blob Images",
            "Started",
            "Downloading Blob Images",
            MACHINE_ID,
        )
        connect_str = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
        # print(connect_str)
        # Create the BlobServiceClient object which will be used to create a container client

        # https://huviairinspection.blob.core.windows.net/aerialtour/0f8bb4a7-68de-4792-85aa-84dc5c44cf76/000120b8-f327-4940-87df-07c1f79dd421.JPG
        container_name = blob_path.split("blob")[1].split("/")[1].split("/")[0]
        blob_folder_name = blob_path.split(container_name)[1][1:].split("/")[0]
        blob_service_client = BlobServiceClient.from_connection_string(
            connect_str)
        container_client = blob_service_client.get_container_client(
            container_name)
        # print("container name {}".format(container_name))
        # print("blob_folder_name {}".format(blob_folder_name))

        data_dir = os.path.join(BASE_DIR, "blob_temp")
        if not os.path.isdir(data_dir):
            # print("[{}]:[INFO] : Creating local directory for container".format(
            #     datetime.utcnow()))
            os.makedirs(data_dir, exist_ok=True)

        def download_blob(blob_client, destination_file):
            # print("[{}]:[INFO] : Downloading {} ...".format(
            #     datetime.utcnow(), destination_file))
            with open(destination_file, "wb") as my_blob:
                blob_data = blob_client.download_blob()
                blob_data.readinto(my_blob)
            # print("[{}]:[INFO] : download finished".format(
            #     datetime.utcnow()))

        images_source_path = os.path.join(data_dir, blob_folder_name)
        blob_list = container_client.list_blobs()
        for blob in blob_list:
            # check if the path contains a folder structure, create the folder structure
            if "/" in "{}".format(blob.name):
                # extract the folder path and check if that folder exists locally, and if not create it
                head, _ = os.path.split("{}".format(blob.name))
                if (
                    not (os.path.isdir(os.path.join(data_dir, head)))
                    and head == blob_folder_name
                ):
                    # print("[{}]:[INFO] : Blob name: {}".format(
                    #     datetime.utcnow(), blob.name))
                    # create the diretcory and download the file to it
                    # print("[{}]:[INFO] : {} directory doesn't exist, creating it now".format(
                    #     datetime.utcnow(), os.path.join(data_dir, head)))
                    os.makedirs(images_source_path, exist_ok=True)
                    break

        for blob in blob_list:
            head, _ = os.path.split("{}".format(blob.name))
            if head == blob_folder_name:
                # Finally, download the blob
                blob_client = container_client.get_blob_client(blob.name)
                download_blob(blob_client, os.path.join(data_dir, blob.name))

    except Exception as ex:
        await send_email("error", ex)
        print("Exception: {}".format(ex))
    else:
        await update_processing_event(
            tour_id,
            "Downloading Blob Images Moving",
            "Moving",
            "Downloading Blob Images",
        )
        return images_source_path


tour_proc_statuses = []


async def retrieve_statuses():
    global tour_proc_statuses
    proc_status = await processing_statistics_collection.find_one(
        {"overall_processing_status":"New"}
    )
    if proc_status:
        tour_proc_statuses.append(processing_status_helper(proc_status))
    return


# get an instance of the logger object this module will use
logger = logging.getLogger(__name__)


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    while True:
        tour_proc_statuses = []
        try:
            loop.run_until_complete(retrieve_statuses())
            status_with_new = False
            for status in tour_proc_statuses:
                if status["overall_processing_status"] == "New":
                    status_with_new = status
                    break
            if status_with_new:
                loop.run_until_complete(
                    begin_image_processing(status_with_new))
            else:
                sleep(120)
        except Exception as e:
            logger.info(e)
