from fastapi import APIRouter, Body, Depends
from fastapi.encoders import jsonable_encoder

from app.auth.auth_bearer import JWTBearer
from app.server.db.processing_status import (
    retrieve_statuses,
    add_tour_proc_status,
    retrieve_proc_status_by_id,
    retrieve_proc_status_by_tour_id,
    update_proc_status_with_status,
    delete_proc_status
)
from app.server.models.process_status_model import ProcessingStatusSchema
from app.server.models.common import (
    ErrorResponseModel,
    ResponseModel
)

router = APIRouter()


@router.post("/", dependencies=[Depends(JWTBearer())], response_description="Config data added into the database")
async def add_config_data(processing_status: ProcessingStatusSchema = Body(...)):
    processing_status = jsonable_encoder(processing_status)
    new_processing_status = await add_tour_proc_status(processing_status)
    return ResponseModel(new_processing_status, "New Tour Processing Status added successfully.")


@router.get("/", dependencies=[Depends(JWTBearer())], response_description="processing statuses retrieved")
async def get_proc_statuses():
    statuses = await retrieve_statuses()
    if statuses:
        return ResponseModel(statuses, "Processing Statuses data retrieved successfully")
    return ResponseModel(statuses, "Empty list returned")


@router.get("/{tour_id}", dependencies=[Depends(JWTBearer())], response_description="processing statuses by tour_id retrieved")
async def get_proc_status_by_tour_id(tour_id: str):
    proc_status = await retrieve_proc_status_by_tour_id(tour_id)
    if proc_status:
        return ResponseModel(proc_status, "Config data retrieved successfully")
    return ErrorResponseModel("An error occurred.", 404, "Config doesn't exist.")


@router.get("/url/{tour_id}", dependencies=[Depends(JWTBearer())], response_description="fetch urls for a processed tour_id")
async def get_processed_tour_url(tour_id: str):
    proc_status = await retrieve_proc_status_by_tour_id(tour_id)
    if proc_status:
        return {"url": proc_status["map_urls"]}
    return {"url": []}
