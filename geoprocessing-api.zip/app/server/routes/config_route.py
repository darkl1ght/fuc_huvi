from fastapi import APIRouter, Body, Depends
from fastapi.encoders import jsonable_encoder

from app.auth.auth_bearer import JWTBearer
from app.server.db.configs import (
    add_config,
    delete_config,
    retrieve_configs,
    retrieve_config_by_id,
    update_config_by_id,
    update_config_by_tour_type,
    retrieve_config_by_tour_type
)
from app.server.models.config_model import MasterDataSchema
from app.server.models.common import (
    ErrorResponseModel,
    ResponseModel
)

router = APIRouter()


@router.post("/", dependencies=[Depends(JWTBearer())], response_description="Config data added into the database")
async def add_config_data(config: MasterDataSchema = Body(...)):
    config = jsonable_encoder(config)
    new_config = await add_config(config)
    return ResponseModel(new_config, "Config added successfully.")


@router.get("/", dependencies=[Depends(JWTBearer())], response_description="All configs retrieved")
async def get_configs():
    configs = await retrieve_configs()
    if len(configs) > 0:
        return ResponseModel(configs, "Configs data retrieved successfully")
    return ResponseModel(None, "Empty list returned")


@router.get("/{tourType}", dependencies=[Depends(JWTBearer())],  response_description="config data by tourType retrieved")
async def get_config_data(tourType):
    config = await retrieve_config_by_tour_type(tourType)
    if config:
        return ResponseModel(config, "Config data retrieved successfully")
    return ErrorResponseModel("An error occurred.", 404, "Config doesn't exist.")


@router.put("/{id}", dependencies=[Depends(JWTBearer())], response_description="Updated config by ID")
async def update_config_by_tourType(id: str, req: dict = Body(...)):
    req = {k: v for k, v in req.dict().items() if v is not None}
    updated_config = await update_config_by_id(id, req)
    if updated_config:
        return ResponseModel(
            "Config with type: {} name update is successful".format(type),
            "Config name updated successfully"
        )
    return ErrorResponseModel(
        "An error occurred",
        404,
        "There was an error updating the Config data."
    )


@router.put("/{type}", dependencies=[Depends(JWTBearer())], response_description="Update Config By tour Type")
async def update_config_by_tourType(type: str, req: dict = Body(...)):
    req = {k: v for k, v in req.dict().items() if v is not None}
    updated_config = await update_config_by_tour_type(type, req)
    if updated_config:
        return ResponseModel(
            "Config with type: {} name update is successful".format(type),
            "Config name updated successfully"
        )
    return ErrorResponseModel(
        "An error occurred",
        404,
        "There was an error updating the Config data."
    )


@router.delete("/{id}", dependencies=[Depends(JWTBearer())], response_description="Config deleted from the database")
async def delete_config_by_id(id: str):
    deleted_config = await delete_config(id)
    if deleted_config:
        return ResponseModel(
            "Config with ID: {} removed".format(
                id), "Config deleted successfully"
        )
    return ErrorResponseModel(
        "An error occurred", 404, "Config with id {0} doesn't exist".format(
            id)
    )
