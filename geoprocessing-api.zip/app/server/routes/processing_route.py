import os
import json
from datetime import datetime

from fastapi import APIRouter, Body, Depends
from fastapi.encoders import jsonable_encoder

from app.auth.auth_bearer import JWTBearer
from app.celery.tasks import start_processing
from app.server.models.processing import ProcessingPayload
from app.server.db.configs import (
    retrieve_config_by_tour_type,
    config_master_data_helper,
)
from app.server.db.processing_status import (
    check_if_tour_exists,
    add_tour_proc_status,
    update_overall_processing_status,
)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))
router = APIRouter()


@router.post("/beginImageProcessing/{project_id}/{tour_id}", dependencies=[Depends(JWTBearer())])
async def image_process(project_id: str, tour_id: str, req: ProcessingPayload = Body(...)):
    # below statements makes req a dict
    req = jsonable_encoder(req)
    # convert True/False to "true"/"false" resp
    req = {k: v for k, v in req.items() if v is not None}
    processing_params = {
        k: ("true" if v == True else "false") if type(v) == type(
            True) else v for k, v in req["processing_params"].items() if v is not None
    }

    processing_params["tour_type"] = req["tour_type"]
    processing_params["blob_path"] = req["blob_path"]

    exist = await check_if_tour_exists(tour_id)
    if not exist:
        await add_tour_proc_status(
            {
                "tour_id": tour_id,
                "project_id": project_id,
                "current_status": "New",
                "machine": "",
                "overall_processing_time": 0,
                "overall_processing_status": "New",
                "map_urls": [],
                "events": [],
                "payload": json.dumps(req),
                "processing_params": json.dumps(processing_params),
            }
        )
    else:
        start_time = datetime.now()
        await update_overall_processing_status(
            tour_id, "New", start_time)

    # res = start_processing.delay(tour_id, json.dumps(req.__dict__), config)
    # res = start_processing.delay()
    return {"status": "success"}
