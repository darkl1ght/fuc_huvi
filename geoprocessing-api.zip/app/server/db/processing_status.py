from datetime import datetime

from bson.objectid import ObjectId

from app.server.db.database import processing_statistics_collection


def processing_status_helper(tour_processing_status) -> dict:
    return {
        "id": str(tour_processing_status["_id"]),
        "tour_id": str(tour_processing_status["tour_id"]),
        "project_id": str(tour_processing_status["project_id"]),
        "current_status": tour_processing_status["current_status"],
        "machine": tour_processing_status["machine"],
        "overall_processing_time": tour_processing_status["overall_processing_time"],
        "overall_processing_status": tour_processing_status["overall_processing_status"],
        "map_urls": tour_processing_status["map_urls"],
        "events": tour_processing_status["events"],
        "payload": tour_processing_status["payload"],
    }


# Retrieve all tours processing statuses present in the db
async def retrieve_statuses():
    tour_proc_statuses = []
    async for proc_status in processing_statistics_collection.find():
        tour_proc_statuses.append(processing_status_helper(proc_status))
    return tour_proc_statuses


# Add a new tour processing status into to the database
async def add_tour_proc_status(status: dict) -> dict:
    proc_status = await processing_statistics_collection.insert_one(status)
    new_proc_status = await processing_statistics_collection.find_one({"_id": proc_status.inserted_id})
    return processing_status_helper(new_proc_status)


# Retrieve a tour processing status with a matching ID
async def retrieve_proc_status_by_id(id: str) -> dict:
    proc_status = await processing_statistics_collection.find_one({"_id": ObjectId(id)})
    if proc_status:
        return processing_status_helper(proc_status)


# Retrieve a tour processing status with a matching tour ID
async def retrieve_proc_status_by_tour_id(tour_id: str) -> dict:
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if proc_status:
        return processing_status_helper(proc_status)


# Update a processing status with event using tour ID
async def update_proc_status_with_status(tour_id: str, proc_status: dict, status: str):
    # Return false if an empty request body is sent.
    if len(proc_status) < 1:
        return False
    proc_status = await processing_statistics_collection.find_one({"tour_id": ObjectId(tour_id)})
    if proc_status:
        proc_status.events.append(status)
        updated_proc_status = await processing_statistics_collection.update_one(
            {"_id": ObjectId(proc_status.id)}, {"$set": proc_status}
        )
        if updated_proc_status:
            return True
        return False


# Update a processing status with event using tour ID
async def update_proc_status_with_event(tour_id: str, event: dict):
    # Return false if an empty request body is sent.
    # if len(proc_status) < 1:
    #     return False
    proc_status = await processing_statistics_collection.find_one({"tour_id": ObjectId(tour_id)})
    if proc_status:
        proc_status.events.append(event)
        updated_proc_status = await processing_statistics_collection.update_one(
            {"_id": ObjectId(proc_status["_id"])}, {"$set": proc_status}
        )
        if updated_proc_status:
            return True
        return False


# Delete a config from the database
async def delete_proc_status(id: str):
    config = await processing_statistics_collection.find_one({"_id": ObjectId(id)})
    if config:
        await processing_statistics_collection.delete_one({"_id": ObjectId(id)})
        return True


# Delete a config from the database
async def delete_proc_status_with_tour_id(tour_id: str):
    proc_status = await processing_statistics_collection.find_one({"tour_id": ObjectId(tour_id)})
    if proc_status:
        await processing_statistics_collection.delete_one({"_id": ObjectId(proc_status["_id"])})
        return True


# Update processing event array
async def update_processing_event(tour_id: str, description: str, status: str, overall_processing_status: str):
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if proc_status:
        proc_status["overall_processing_status"] = overall_processing_status
        proc_status["events"].append({
            "description": description,
            "time": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
            "status": status
        })
        updated_proc_status = await processing_statistics_collection.update_one(
            {"_id": ObjectId(proc_status["_id"])}, {"$set": proc_status}
        )
        if updated_proc_status:
            return True
        return False


# Updates overall processing status value with time field
async def update_overall_processing_status(tour_id: str, overall_processing_status: str, start_time: datetime):
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if proc_status:
        proc_status["overall_processing_status"] = overall_processing_status
        proc_status["overall_processing_time"] = str(
            datetime.now() - start_time
        )
        updated_proc_status = await processing_statistics_collection.update_one(
            {"_id": ObjectId(proc_status["_id"])}, {"$set": proc_status}
        )
        if updated_proc_status:
            return True
        return False


# check if tour already exits or not
async def check_if_tour_exists(tour_id: str):
    proc_status = await processing_statistics_collection.find_one({"tour_id": tour_id})
    if (proc_status):
        return True
    return False
