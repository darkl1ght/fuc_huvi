import os
from motor import motor_asyncio

MONGO_CONNECTION_STRING = os.environ.get("MONGODB_CONNECTION_STRING")
MONGODB_DATABASE_NAME = os.environ.get("MONGODB_DATABASE_NAME")

client = motor_asyncio.AsyncIOMotorClient(MONGO_CONNECTION_STRING)
database = client[MONGODB_DATABASE_NAME]

config_master_data_collection = database.get_collection(
    "processingparams")
processing_statistics_collection = database.get_collection(
    "processingstatistics")
