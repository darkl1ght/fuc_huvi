from bson.objectid import ObjectId

from app.server.db.database import config_master_data_collection


def config_master_data_helper(config) -> dict:
    return {
        "id": str(config["_id"]),
        "config": config["config"],
        "tourType": config["tourType"]
    }


# Retrieve all configs present in the database
async def retrieve_configs():
    configs = []
    async for config in config_master_data_collection.find():
        configs.append(config_master_data_helper(config))
    return configs


# Add a new config into to the database
async def add_config(config_data: dict) -> dict:
    config = await config_master_data_collection.insert_one(config_data)
    new_config = await config_master_data_collection.find_one({"_id": config.inserted_id})
    return config_master_data_helper(new_config)


# Retrieve a config with a matching ID
async def retrieve_config_by_id(id: str) -> dict:
    config = await config_master_data_collection.find_one({"_id": ObjectId(id)})
    if config:
        return config_master_data_helper(config)


# Retrieve a config with a matching ID
async def retrieve_config_by_tour_type(tourType: str) -> dict:
    config = await config_master_data_collection.find_one({"tourType": tourType})
    if config:
        return config_master_data_helper(config)


# Update a config with a matching ID
async def update_config_by_id(id: str, config_data: dict):
    # Return false if an empty request body is sent.
    if len(config_data) < 1:
        return False
    config = await config_master_data_collection.find_one({"_id": ObjectId(id)})
    if config:
        updated_config = await config_master_data_collection.update_one(
            {"_id": ObjectId(id)}, {"$set": config_data}
        )
        if updated_config:
            return True
        return False


# Update a config with a matching tour type
async def update_config_by_tour_type(tour_type: str, config_data: dict):
    # Return false if an empty request body is sent.
    if len(config_data) < 1:
        return False
    config = await config_master_data_collection.find_one({"tourType": ObjectId(tour_type)})
    if config:
        updated_config = await config_master_data_collection.update_one(
            {"_id": ObjectId(config.id)}, {"$set": config_data}
        )
        if updated_config:
            return True
        return False


# Delete a config from the database
async def delete_config(id: str):
    config = await config_master_data_collection.find_one({"_id": ObjectId(id)})
    if config:
        await config_master_data_collection.delete_one({"_id": ObjectId(id)})
        return True
