from typing import Optional, List
from datetime import datetime

from pydantic import BaseModel, Field


class ProcessingParams(BaseModel):
    alignment_accuracy: Optional[str] = None
    keypoint_limit: Optional[str] = None
    tiepoint_limit: Optional[str] = None
    guided_matching: Optional[str] = None
    filter_mode: Optional[str] = None
    reuse_depth: Optional[str] = None
    depthmap_accuracy: Optional[str] = None
    export_dsm_tiff: Optional[str] = None
    export_dsm_xyz: Optional[str] = None
    build_dtm: Optional[str] = None
    build_dsm: Optional[str] = None
    export_dtm: Optional[str] = None
    max_angle: Optional[float] = None
    max_distance: Optional[float] = None
    cell_size: Optional[float] = None
    export_raster: Optional[str] = None
    face_count: Optional[str] = None
    build_tiled_model: Optional[str] = None
    export_tiled_model: Optional[str] = None
    export_contour: Optional[str] = None
    build_contour: Optional[str] = None
    contour_interval: Optional[float] = None
    shape_file_type: Optional[str] = None
    refine_seamlines: Optional[str] = None
    dsm_projection_code: Optional[str] = None
    export_point_cloud: Optional[str] = None


class ProcessingPayload(BaseModel):
    blob_path: Optional[str] = ""
    tour_dir_created: Optional[str] = "false"
    execution_step: Optional[int] = 1
    tour_type: str = Field(...)
    processing_params: ProcessingParams = Field(...)
