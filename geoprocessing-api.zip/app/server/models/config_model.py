from typing import Optional, List
from datetime import datetime

from pydantic import BaseModel, Field


class AgisoftConfig(BaseModel):
    shape_file_type: Optional[str]
    contour_interval: Optional[float]
    build_contour: Optional[str]
    export_contour: Optional[str]
    export_tiled_model: Optional[str]
    build_tiled_model: Optional[str]
    export_raster: Optional[str]
    export_dtm: Optional[str]
    build_dtm: Optional[str]
    build_dsm: Optional[str]
    max_angle: Optional[float]
    max_distance: Optional[float]
    cell_size: Optional[float]
    export_dsm_xyz: Optional[str]
    export_dsm_tiff: Optional[str]
    face_count: Optional[str]
    filter_mode: Optional[str]
    reuse_depth: Optional[str]
    depthmap_accuracy: Optional[str]
    guided_matching: Optional[str]
    tiepoint_limit: Optional[int]
    keypoint_limit: Optional[int]
    alignment_accuracy: Optional[str]
    refine_seamlines: Optional[str]
    export_point_cloud: Optional[str]


class MasterDataSchema(BaseModel):
    tourType: str = Field(...)
    config: AgisoftConfig

    class Config:
        schema_extra = {
            "example": {
                "tourType": "PT10001",
                "config": {
                    "shape_file_type": "shp",
                    "contour_interval": 1,
                    "build_contour": "false",
                    "export_tiled_model": "true",
                    "build_tiled_model": "true",
                    "export_raster": "true",
                    "export_dtm": "true",
                    "build_dtm": "true",
                    "build_dsm": "true",
                    "max_angle": 15,
                    "max_distance": 0.5,
                    "cell_size": 30.0,
                    "export_dsm_xyz": "false",
                    "export_dsm_tiff": "true",
                    "face_count": "medium",
                    "filter_mode": "mild",
                    "reuse_depth": "true",
                    "depthmap_accuracy": "high",
                    "guided_matching": "false",
                    "tiepoint_limit": 4000,
                    "keypoint_limit": 40000,
                    "alignment_accuracy": "high",
                    "export_point_cloud": "true"
                }
            }
        }
