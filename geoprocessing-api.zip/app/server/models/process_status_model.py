from typing import Optional, List
from datetime import datetime

from pydantic import BaseModel, Field


class MapURLs(BaseModel):
    type: Optional[str] = ""
    key: Optional[str] = ""
    value: Optional[str] = ""
    appendIndex: Optional[int] = ""
    disabled: Optional[bool] = ""
    addedBy: Optional[str] = ""
    uploadedAt: Optional[datetime] = ""
    filename: Optional[str] = ""
    uploadedTo: Optional[str] = ""


class Events(BaseModel):
    description: Optional[str]
    time: Optional[datetime]
    status: Optional[str] = "Not Started"


class ProcessingStatusSchema(BaseModel):
    tour_id: str = Field(...)
    project_id: str = Field(...)
    current_status: Optional[str] = "Not Started"
    machine: Optional[str]
    overall_processing_time: Optional[datetime]
    overall_processing_status: Optional[str] = "Not Started"
    map_urls: Optional[List[MapURLs]]
    events: Optional[List[Events]]

    class Config:
        schema_extra = {
            "example": {
                "tour_id": "aaa",
                "project_id": "abc",
                "current_status": "Not Started",
                "machine": "",
                "overall_processing_time": "",
                "overall_processing_status": "",
                "map_urls": [],
                "events": []
            }
        }
