from app.server.routes.config_route import router as ConfigRouter
from app.server.routes.process_status_route import router as ProcessingStatusRouter
from app.server.routes.processing_route import router as ProcessingRouter
from app.auth.auth_bearer import JWTBearer
from app.celery.tasks import add
import os
import shutil

from fastapi import FastAPI, Depends

import getpass
linux_username = getpass.getuser()
from dotenv import load_dotenv
dotenv_path="/home/{0}/geoprocessing-api/app/.env".format(linux_username)
load_dotenv(dotenv_path)


app = FastAPI()

app.include_router(
    ConfigRouter,
    tags=["Config"],
    prefix="/config"
)
app.include_router(
    ProcessingStatusRouter,
    tags=["Process Status"],
    prefix="/process_status"
)
app.include_router(
    ProcessingRouter,
    tags=["Processing"],
    prefix="/process"
)


@app.get("/", tags=["Root"])
async def read_root():
    return {"message": "Welcome to this fantastic app!"}


@app.get("/add/{x}/{y}", dependencies=[Depends(JWTBearer())], tags=["Root"])
def test_celery(x: float, y: float):
    add.delay(x, y)
    return {"message": "Adding {} and {}. Check celery logs to confirm".format(x, y)}
