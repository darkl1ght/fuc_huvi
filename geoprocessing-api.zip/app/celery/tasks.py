#!/usr/bin/env
import os
from celery import Celery

from bson.objectid import ObjectId
from celery.utils.log import get_task_logger

app = Celery("tasks", broker="pyamqp://guest@localhost//", backend="rpc://")
logger = get_task_logger(__name__)


@app.task
def add(x, y):
    logger.info("Adding %s + %s, res: " % (x, y))
    return x + y


@app.task
def start_processing():
    logger.info("Starting Processing. But just add code")
    return "blah blah"
