#!/usr/local/bin/python3.9
import sys
import os
import csv
import shutil
import logging
import asyncio
from pathlib import Path
import datetime as dt
from datetime import datetime

import Metashape

import pytz
from zipfile import ZipFile

from metashape_db import update_proc_status, update_dem_status, get_proc_status

# IMPORTANT: To install any package in metashape library
# cd <path_to_metashape-pro>
# LD_LIBRARY_PATH=`pwd`/python/lib ./python/bin/python3.5 -m pip install python_module_name

base_dir = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))
old_timezone = pytz.timezone("UTC")
new_timezone = pytz.timezone("Asia/Kolkata")
logger = logging.getLogger("huviair")
save_path = ""
tour_id = ""


class MyFormatter(logging.Formatter):
    def converter(self, timestamp):
        # TODO suggest not to change timezone, stick to GMT/ UTC
        return (old_timezone.localize(
            datetime.now())).astimezone(new_timezone)

    def formatTime(self, record, datefmt=None):
        dt = self.converter(record.created)
        if datefmt:
            s = dt.strftime(datefmt)
        else:
            # dt.isoformat gives error, expects 1 arg, given 2
            # s = dt.isoformat(sep="T", timespec="milliseconds")
            # getting time
            t = dt.strftime("%Y-%m-%dT%H:%M:%S")
            # getting timezone info
            z = dt.strftime("%z")
            # merging time + miliseconds + timezone info
            s = "%s.%03d%s" % (t, record.msecs, z)
        return s


def initialize_logging(tour_folder_name):

    try:
        # create log folder
        log_folder_path = os.path.join(base_dir,
                                       "tours",
                                       tour_folder_name,
                                       "logs")

        os.makedirs(name=log_folder_path, mode=0o777, exist_ok=True)

        # create log file
        log_file_path = os.path.join(log_folder_path, "process_log.log")

        # set log level to info
        logger.setLevel(logging.INFO)

        # add log handler
        file_handler = logging.FileHandler(filename=log_file_path)
        logger.addHandler(file_handler)

        # set formatter
        f = "%(asctime)s %(levelname)-6s[%(filename)s:%(lineno)3d] %(message)s"
        file_handler.setFormatter(MyFormatter(
            fmt=f))
    except Exception as err:
        print(err)
        exit
    else:
        logger.info("*"*100)
        logger.info("Logger initiated")


def add_chunk(doc):

    try:
        logger.info("Retrieve/Add Chunk")
        chunk = Metashape.Chunk
        if len(doc.chunks) > 0:
            chunk = doc.chunk
        else:
            chunk = doc.addChunk()
        chunk.label = "New Chunk"
    except Exception as err:
        logger.error("Error in adding chunk. Error: {}".format(str(err)),
                     exc_info=True)
        raise
    else:
        logger.info("Adding Chunk Completed")
        return chunk


def extract_options():

    if (((len(sys.argv)-1) // 2) == 0
            or len(sys.argv) < 5):
        raise Exception("Args cannot be less than 4 and should be in pairs")
        # sys.exit("Args cannot be less than 10")
    optionsArg = sys.argv[1:]
    extracted_options = dict()
    for i in range(0, len(optionsArg), 2):
        if (optionsArg[i][0:2] == "--"):
            extracted_options[optionsArg[i][2:]] = optionsArg[i + 1]
        else:
            raise Exception(
                "Error while extracting Options: {}".format(optionsArg[i]))

    return extracted_options


def get_photo_list(image_path):

    logger.info("Looking for images in {}".format(image_path))
    # loading images
    image_list = os.listdir(image_path)
    photo_list = list()
    count = 0
    for photo in image_list:
        if photo.rsplit(".", 1)[1].lower() \
                in ["jpg", "jpeg", "tif", "tiff"]:
            photo_list.append("/".join([image_path, photo]))
            count = count+1

    logger.info("{} images found".format(count))

    return photo_list


def declare_paths(tour_folder_name):

    # path to photos and exporting data
    image_path = os.path.join(base_dir, "tours",
                              tour_folder_name, "images")
    if (not os.path.isdir(image_path)):
        logger.error(
            "Photos are not available at location: {}".format(image_path))
        # raise
        sys.exit(
            {"error": "Photos are not available at location: {}".format(image_path)})
    export_path = os.path.join(base_dir, "tours",
                               tour_folder_name, "export")
    os.makedirs(name=export_path, mode=0o777, exist_ok=True)

    return image_path, export_path


def save_doc(doc):
    try:
        logger.info("Saving tour")
        doc.save(path=os.path.join(save_path, tour_id))
    except Exception as err:
        logger.error("Error while saving file. Error: {}".format(str(err)),
                     exc_info=True)
        raise
    else:
        logger.info("File saved successfully")
    # try:
    #     logger.info("Opening Saved file")
    #     doc.open(path=save_path + "/" + tour_id)
    #     chunk = doc.chunks[0]
    # except Exception as err:
    #     logger.error("Unable to open file. Error: {}".format( err),
    #                  exc_info=True)
    #     raise
    # else:
    #     logger.info("Opened Successfully")
    #     return chunk


async def begin_image_processing(
        doc, chunk, image_path,
        export_path, epsg_code,
        execution_step, options):

    try:
        tour_folder_name = options.get("tour_id")
    except Exception as err:
        logger.error("Tour Id is compulsory. Error {}".format(str(err)),
                     exc_info=True)
        raise RuntimeError(str(err))

    # tracking error situations
    if (options.get("export_dsm_tiff") == "true" and
        options.get("export_dtm") == "true" and
            not options.get("build_dtm")):
        raise RuntimeError(
            "build_dtm option must be provided "
            "while exporting both DSM and DTM")

    # projection
    projection = Metashape.OrthoProjection()
    projection.crs = Metashape.CoordinateSystem(epsg_code)

    if(execution_step == 1):
        # step1
        # add photos
        desc = "Step 1 started."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Started")
        try:
            image_layout = options.get("image_layout", False) \
                or Metashape.ImageLayout.FlatLayout  # photo/image layout
            # get photos list
            photo_list = get_photo_list(image_path)
            desc = "Adding photos started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            chunk.addPhotos(
                filenames=photo_list,
                layout=image_layout
            )
        except Exception as err:
            error_msg = "Error in Add Photos Step. Error: {}".format(str(err)),
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Adding photos completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")
            save_doc(doc)
        desc = "Step 1 completed."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Completed")

    if(execution_step == 2):
        # Step  2
        # match photos params
        desc = "Step 2 started."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Started")
        # Metashape.Accuracy.HighAccuracy
        # align photos accuracy
        # For matching accuracy the correspondence should be the following:
        # Highest = 0
        # High = 1
        # Medium = 2
        # Low = 4
        # Lowest = 8
        alignment_accuracy_dict = {
            "highest": 0,
            "high": 1,
            "medium": 2,
            "low": 4,
            "lowest": 8
        }
        try:
            alignment_accuracy_dict[(options.get("alignment_accuracy")).lower()] \
                if options.get("alignment_accuracy") \
                else None
        except KeyError as err:
            error_msg = "Depth Map Accuracy Value. Error: {}".format(str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            downscale_align_accuracy = alignment_accuracy_dict[(options.get(
                "alignment_accuracy")).lower()] \
                if options.get("alignment_accuracy") \
                else 1

        # source preselection mode
        reference_preselection_value = options.get("reference_preselection") \
            or Metashape.ReferencePreselectionMode.ReferencePreselectionSource
        # align photos key point limit
        keypoints_limit = int(options.get("keypoint_limit")) \
            if options.get("keypoint_limit") \
            else 40000
        # align photos tie point limit
        tiepoints_limit = int(options.get("tiepoint_limit")) \
            if options.get("tiepoint_limit") \
            else 4000
        # align photos guiding option -> default False
        guided_matching_value = options.get("guided_matching") == "true"

        # align photos
        try:
            desc = "Match photos started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            chunk.matchPhotos(
                downscale=downscale_align_accuracy,
                reference_preselection_mode=reference_preselection_value,
                keypoint_limit=keypoints_limit,
                tiepoint_limit=tiepoints_limit,
                guided_matching=guided_matching_value
            )
        except Exception as err:
            error_msg = "Error in Match Photos Step. Error: {}".format(
                str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Match photos completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")

        try:
            desc = "Aligning cameras started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            chunk.alignCameras(adaptive_fitting=True)
        except Exception as err:
            error_msg = "Error in align cameras step. Error: {}".format(
                str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Aligning cameras completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")
            save_doc(doc)

        desc = "Step 2 completed."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Completed")

    dem_source_data = Metashape.DataSource.DenseCloudData

    if(execution_step == 3):
        # Step  3
        desc = "Step 3 started."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Started")
        # depthmap options
        # For depth maps quality:
        # Ultra = 1
        # High = 2
        # Medium = 4
        # Low = 8
        # Lowest = 16
        depthmapQualityDict = {
            "highest": 1,
            "high": 2,
            "medium": 4,
            "low": 8,
            "lowest": 16
        }
        try:
            depthmapQualityDict[(options.get("depthmap_accuracy")).lower()] \
                if options.get("depthmap_accuracy") \
                else None
        except KeyError as err:
            logger.error("Depth Map Accuracy Value. Error: {}".format(str(err)),
                         exc_info=True)
            await update_proc_status(tour_folder_name,
                                     "Depth Map Accuracy Value. Error: {}".format(
                                         str(err)),
                                     "Error")
            raise
        else:
            downscale_depthmap_accuracy = depthmapQualityDict[(options.get(
                "depthmap_accuracy")).lower()] \
                if options.get("depthmap_accuracy") \
                else 2

        filtering_mode_dict = {
            "mild": Metashape.FilterMode.MildFiltering,
            "aggressive": Metashape.FilterMode.AggressiveFiltering,
            "moderate": Metashape.FilterMode.ModerateFiltering
        }
        try:
            filtering_mode_dict[(options.get("filter_mode")).lower()] \
                if options.get("filter_mode") \
                else None
        except KeyError as err:
            error_msg = "Filter Mode Value. Error: {}".format(str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            depthmap_filter_mode = filtering_mode_dict[
                (options.get("filter_mode")).lower()] \
                if options.get("filter_mode") \
                else Metashape.FilterMode.MildFiltering

        # default value -> True
        reuse_depth = False \
            if options.get("reuse_depth") == "false" \
            else True

        try:
            # build depthmap
            desc = "Building Depthmaps started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            chunk.buildDepthMaps(
                downscale=downscale_depthmap_accuracy,  # accuracy
                filter_mode=depthmap_filter_mode,
                reuse_depth=reuse_depth
            )
        except Exception as err:
            error_msg = "Error in Build Depth Maps Step. Error: {}".format(
                str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Building Depthmaps completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")

        try:
            # build dense cloud
            desc = "Building Dense Cloud started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            chunk.buildDenseCloud()
        except Exception as err:
            error_msg = "Error in Build Depth Maps Step. Error: {}".format(
                str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Building Dense Cloud completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")
            save_doc(doc)

        try:
            # build dem
            desc = "Building DEM started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            chunk.buildDem(
                source_data=dem_source_data,
                projection=projection
            )
        except Exception as err:
            error_msg = "Error in Build DEM Step. Error: {}".format(str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Building DEM completed."
            logger.info(desc)
            await update_dem_status(tour_folder_name, "dsm")
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")
            save_doc(doc)

        desc = "Step 3 completed."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Completed")

    # Step  4
    if (execution_step == 4):
        desc = "Step 4 started."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Started")

        proc_status = await get_proc_status(tour_folder_name)
        if (options.get("build_dsm") == "true" and proc_status["last_dem_built"] == "dtm"):
            try:
                # build dem
                desc = "Building DEM started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                chunk.buildDem(
                    source_data=dem_source_data,
                    projection=projection
                )
            except Exception as err:
                error_msg = "Error in Build DEM Step. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Building DEM completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                await update_dem_status(tour_folder_name, "dsm")
                save_doc(doc)

        if(options.get("export_dsm_tiff") == "true"):
            try:
                desc = "Exporting DSM(.tif) Started"
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                # export DSM
                chunk.exportRaster(
                    path=os.path.join(export_path, "dsm-mapbox.tif"),
                    format=Metashape.RasterFormatTiles,
                    image_format=Metashape.ImageFormat.ImageFormatTIFF,
                    raster_transform=Metashape.RasterTransformType.RasterTransformPalette,
                    projection=projection,
                    save_world=True,
                    save_alpha=True,
                    image_description="DSM Layer Mapbox",
                    white_background=True,
                    save_kml=True,
                    source_data=Metashape.DataSource.ElevationData
                )
            except Exception as err:
                error_msg = "Error while exporting DSM(.tif). Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Exporting DSM(.tif) completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")

            wgs84_projection = Metashape.OrthoProjection()
            wgs84_projection.crs = Metashape.CoordinateSystem("EPSG::4326")
            new_resolution = chunk.elevation.resolution * 4
            try:
                desc = "Exporting DSM Elevation File started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                # export DSM
                chunk.exportRaster(
                    path=os.path.join(
                        export_path, "dsm-elevation.tif"),
                    format=Metashape.RasterFormatTiles,
                    image_format=Metashape.ImageFormat.ImageFormatTIFF,
                    projection=wgs84_projection,
                    save_world=False,
                    save_alpha=True,
                    image_description="DSM Elevation Blob",
                    white_background=True,
                    save_kml=False,
                    source_data=Metashape.DataSource.ElevationData,
                    resolution=new_resolution
                )
            except Exception as err:
                error_msg = "Error while exporting DSM Elevation. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Exporting DSM Elevation completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                # dsm_src_path = os.path.realpath(export_path
                #                                 + "/dsm-elevation.tif")
                # dsm_dst_path = r"/home/<username>/huviair_volume_calc" \
                #     r"/files/dsm-" + tour_folder_name + ".tif"
                # shutil.copyfile(dsm_src_path, dsm_dst_path)

        if(options.get("export_volume_dsm") == "true"):
            projection = Metashape.OrthoProjection()
            projection.crs = Metashape.CoordinateSystem(
                "EPSG::%s" % (options.get("dsm_projection_code"))
            )
            try:
                desc = "Exporting Projected DSM (EPSG::%s) File started." % options.get(
                    "dsm_projection_code")
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                chunk.exportRaster(
                    path=os.path.join(export_path, "dsm.tif"),
                    format=Metashape.RasterFormatTiles,
                    image_format=Metashape.ImageFormat.ImageFormatTIFF,
                    projection=projection,
                    save_alpha=False,
                    image_description="DSM for Volume Calc",
                    source_data=Metashape.DataSource.ElevationData,
                )
            except Exception as err:
                error_msg = "Error while exporting Projected DSM for Volume Calculation. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Exporting Projected DSM completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                dsm_src_path = os.path.abspath(
                    os.path.join(
                        export_path,
                        "dsm.tif"
                    )
                )
                dsm_dst_path = os.path.join(
                    "/home/ec2-user/volume_calc/media",
                    tour_folder_name
                )
                if not os.path.isdir(dsm_dst_path):
                    os.makedirs(
                        name=dsm_dst_path,
                        mode=0o777,
                        exist_ok=True
                    )
                shutil.move(dsm_src_path, dsm_dst_path)

        if (options.get("export_dsm_xyz") == "true"):
            proc_status = await get_proc_status(tour_folder_name)
            if (proc_status["last_dem_built"] == "dtm"):
                chunk.buildDem(
                    source_data=dem_source_data,
                    projection=projection
                )
            try:
                desc = "Exporting DSM(.xyz) started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                # export DSM
                chunk.exportRaster(
                    path=os.path.join(export_path, "dsm-xyz.xyz"),
                    format=Metashape.RasterFormatTiles,
                    image_format=Metashape.ImageFormat.ImageFormatXYZ,
                    projection=projection,
                    save_world=True,
                    save_alpha=True,
                    image_description="DSM",
                    white_background=True,
                    save_kml=True,
                    source_data=Metashape.DataSource.ElevationData
                )
            except Exception as err:
                error_msg = "Error while exporting DSM(.xyz). Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                doc.save()
                desc = "Exporting DSM(.xyz) completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")

        proc_status = await get_proc_status(tour_folder_name)
        if (options.get("build_dtm") == "true" and proc_status["last_dem_built"] == "dsm"):
            max_angle = float(options.get("max_angle")) \
                if options.get("max_angle") \
                else 15.0
            max_distance = float(options.get("max_distance")) \
                if options.get("max_distance") \
                else 1.0
            cell_size = float(options.get("cell_size")) \
                if options.get("cell_size") \
                else 50.0
            chunk.dense_cloud.classifyGroundPoints(
                max_angle=max_angle,
                max_distance=max_distance,
                cell_size=cell_size
            )

            try:
                desc = "Building DEM for DTM(with Ground Class) started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                # Here"s the correspondence between dense point classes
                # and their indices required for the buildDem() function:
                # Created = 0,
                # Unclassified = 1,
                # Ground = 2,
                # LowVegetation = 3,
                # MediumVegetation = 4,
                # HighVegetation = 5,
                # Building = 6,
                # LowPoint = 7,
                # ModelKeyPoint = 8,
                # Water = 9,
                # OverlapPoints = 12
                chunk.buildDem(
                    source_data=dem_source_data,
                    projection=projection,
                    classes=[2]
                )
            except Exception as err:
                error_msg = "Error while building DEM for Ground Class. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Building DEM for DTM(with Ground Class) completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                await update_dem_status(tour_folder_name, "dtm")
                save_doc(doc)

        if (options.get("export_dtm") == "true"):

            try:
                desc = "Exporting DTM started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                chunk.exportRaster(
                    path=os.path.join(export_path, "dtm-mapbox.tif"),
                    format=Metashape.RasterFormatTiles,
                    image_format=Metashape.ImageFormat.ImageFormatTIFF,
                    raster_transform=Metashape.RasterTransformType.RasterTransformPalette,
                    projection=projection,
                    save_world=True,
                    save_alpha=True,
                    image_description="DTM Layer Mapbox",
                    white_background=True,
                    save_kml=True,
                    source_data=Metashape.DataSource.ElevationData
                )

            except Exception as err:
                error_msg = "Error while exporting DTM. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Exporting DTM completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                save_doc(doc)

            wgs84_projection = Metashape.OrthoProjection()
            wgs84_projection.crs = Metashape.CoordinateSystem("EPSG::4326")
            new_resolution = chunk.elevation.resolution * 4

            try:
                desc = "Exporting DTM Elevation started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                chunk.exportRaster(
                    path=os.path.join(
                        export_path, "dtm-elevation.tif"),
                    format=Metashape.RasterFormatTiles,
                    image_format=Metashape.ImageFormat.ImageFormatTIFF,
                    projection=wgs84_projection,
                    save_world=True,
                    save_alpha=True,
                    image_description="DTM Elevation Blob",
                    white_background=True,
                    save_kml=False,
                    source_data=Metashape.DataSource.ElevationData,
                    resolution=new_resolution
                )
            except Exception as err:
                error_msg = "Error while exporting DTM Elevation. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Exporting DTM Elevation completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                save_doc(doc)

        desc = "Step 4 completed."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Completed")

        # with open(export_path + "/dtm-elevation.csv", "w", newline="") as elevation_csv_file:
        #     writer = csv.writer(elevation_csv_file)
        #     writer.writerow(["longitude", "latitude", "altitude"])
        #     with open(export_path + "/dtm-elevation.xyz", "r") as elevation_xyz_file:
        #         rowData = csv.reader(elevation_xyz_file, delimiter="\t")
        #         for row in rowData:
        #             writer.writerow(row)

    if(execution_step == 5):
        # Step  5
        # build orthomosaic
        desc = "Step 5 started."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Started")
        try:
            desc = "Building Orthomosaic started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            refine_seamlines = options.get(
                "refine_seamlines", "false") == "true"
            chunk.buildOrthomosaic(
                surface_data=Metashape.DataSource.ElevationData,
                # blending_mode=blending,
                projection=projection,
                refine_seamlines=refine_seamlines
            )
        except Exception as err:
            error_msg = "Error in Build Depth Maps Step. Error: {}".format(
                str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Building Orthomosaic completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")
            save_doc(doc)

        if (options.get("export_raster") == "true"):
            # orthomosaic options
            # blending = Metashape.BlendingMode.MosaicBlending  # blending mode
            raster_compression = Metashape.ImageCompression()
            raster_compression.tiff_compression = Metashape. \
                ImageCompression.TiffCompressionJPEG
            raster_compression.jpeg_quality = 90
            raster_compression.tiff_big = True
            raster_compression.tiff_tiled = False

            try:
                desc = "Exporting Raster started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")

                psize = chunk.orthomosaic.resolution
                mapdim = [chunk.orthomosaic.width,  chunk.orthomosaic.height]
                if max(mapdim) > 65500:
                    # define a new variable just in case the original resolution is needed
                    psize_r = max(mapdim)/65500*psize
                else:
                    psize_r = psize

                logger.info("Orthomosaic resolution: " + str(psize_r))
                # export orthophoto
                chunk.exportRaster(
                    path=os.path.join(export_path, "orthomosaic.tif"),
                    format=Metashape.RasterFormatTiles,
                    image_format=Metashape.ImageFormat.ImageFormatTIFF,
                    projection=projection,
                    save_world=True,
                    save_alpha=True,
                    image_description="Orthomosaic",
                    image_compression=raster_compression,
                    white_background=True,
                    save_kml=False,
                    resolution=psize_r
                )
            except Exception as err:
                error_msg = "Error while exporting Orthomosaic. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Exporting Raster completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                save_doc(doc)

        desc = "Step 5 completed."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Completed")

    if(execution_step == 6):
        # Step  6
        desc = "Step 6 started"
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Started")
        # build mesh interpolation
        # interpolation = Metashape.Interpolation.EnabledInterpolation
        # build mesh polygon count
        # high/ medium / low -> 1/5, 1/15, 1/45
        face_count_dict = {
            "high": 36000,
            "medium": 12000,
            "low": 4000
        }
        try:
            face_count_dict[(options.get("face_count")).lower()] \
                if options.get("face_count") \
                else None
        except KeyError as err:
            error_msg = "Face Count Value. Error: {}".format(str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            face_count_value = face_count_dict[
                (options.get("face_count")).lower()] \
                if options.get("face_count") \
                else 4000

        # build tiled model
        if (options.get("build_tiled_model") == "true"):
            try:
                desc = "Building Tiled Model started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                chunk.buildTiledModel(
                    face_count=face_count_value,
                    ghosting_filter=True
                )
            except Exception as err:
                error_msg = "Error in Build Tiled Model Step. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Building Tiled Model completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                save_doc(doc)

        if (options.get("export_tiled_model") == "true"):
            try:
                desc = "Exporting Tiled Model started."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Started")
                chunk.exportTiledModel(
                    path=os.path.join(export_path, "tiled_model.slpk"),
                    format=Metashape.TiledModelFormat.TiledModelFormatSLPK,
                    crs=Metashape.CoordinateSystem(epsg_code)
                )
            except Exception as err:
                error_msg = "Error while exporting Tiled Model. Error: {}".format(
                    str(err))
                logger.error(error_msg, exc_info=True)
                await update_proc_status(tour_folder_name,
                                         error_msg,
                                         "Error")
                raise
            else:
                desc = "Exporting Tiled Model completed."
                logger.info(desc)
                await update_proc_status(tour_folder_name,
                                         desc,
                                         "Completed")
                save_doc(doc)

        desc = "Step 6 completed."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Completed")

    if (options.get("build_dtm") == "true" and options.get("build_contour") == "true"):

        countour_interval_value = float(options.get("contour_interval")) \
            if options.get("contour_interval") \
            else 1.0

        try:
            desc = "Building Contour started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            chunk.buildContours(source_data=Metashape.DataSource.ElevationData,
                                interval=countour_interval_value,
                                prevent_intersections=True)
        except Exception as err:
            error_msg = "Error while building Contour. Error: {}".format(
                str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Building Contour completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")
            save_doc(doc)

    if (chunk.shapes and len(chunk.shapes) > 0 and options.get("export_contour") == "true"):

        exportShapeFileType = Metashape.ShapesFormat.ShapesFormatDXF \
            if options.get("shape_file_type") == "dxf" \
            else Metashape.ShapesFormat.ShapesFormatSHP
        try:
            desc = "Exporting Contour started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")
            if(options.get("shape_file_type") == "dxf"):
                chunk.exportShapes(path=os.path.join(export_path, "contour.dxf"),
                                   format=exportShapeFileType,
                                   crs=Metashape.CoordinateSystem(epsg_code))
            else:
                chunk.exportShapes(path=os.path.join(export_path, "contour.shp"),
                                   format=exportShapeFileType,
                                   crs=Metashape.CoordinateSystem(epsg_code),
                                   polygons_as_polylines=True)
            if (options.get("shape_file_type") == "dxf"):
                with ZipFile(os.path.join(export_path, "contour.zip"), "w") as newzip:
                    newzip.write(filename=os.path.join(
                        export_path, "contour.dxf"))
                    newzip.write(filename=os.path.join(
                        export_path, "contour.prj"))
            elif (options.get("shape_file_type") == "shp"):
                with ZipFile(os.path.join(export_path, "contour.zip"), "w") as newzip:
                    newzip.write(filename=os.path.join(
                        export_path, "contour.shp"))
                    newzip.write(filename=os.path.join(
                        export_path, "contour.shx"))
                    newzip.write(filename=os.path.join(
                        export_path, "contour.prj"))
                    newzip.write(filename=os.path.join(
                        export_path, "contour.dbf"))
        except Exception as err:
            error_msg = "Error while exporting Contour. Error: {}".format(
                str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Exporting Contour completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")
            save_doc(doc)

    if execution_step == 8 and options.get("dsm_projection_code"):
        desc = "Step 8 started"
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Started")
        try:
            desc = "Exporting Point Cloud started."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Started")

            chunk.exportPoints(
                path=os.path.join(
                    export_path, "{}.zip".format(tour_folder_name)),
                format=Metashape.PointsFormat.PointsFormatPotree,
                colors_rgb_8bit=False,
                save_comment=False,
                save_normals=False,
                save_confidence=False,
                crs=Metashape.CoordinateSystem(
                    "EPSG::%s" % (options.get(
                        "dsm_projection_code"))
                ),
                clip_to_boundary=False,
            )
        except Exception as err:
            error_msg = "Error while exporting Point Cloud. Error: {}".format(
                str(err))
            logger.error(error_msg, exc_info=True)
            await update_proc_status(tour_folder_name,
                                     error_msg,
                                     "Error")
            raise
        else:
            desc = "Exporting Point Cloud completed."
            logger.info(desc)
            await update_proc_status(tour_folder_name,
                                     desc,
                                     "Completed")
            save_doc(doc)

        desc = "Step 8 completed."
        logger.info(desc)
        await update_proc_status(tour_folder_name,
                                 desc,
                                 "Completed")


async def process():
    # converted currrent time to epoch time using timestamp()
    # start_time = str((old_timezone.localize(datetime.now())).
    #                  astimezone(new_timezone).timestamp())

    # extracting args
    options = extract_options()
    tour_folder_name = options["tour_id"]

    # initialize logger
    initialize_logging(tour_folder_name)

    logger.info("Options: {}".format(str(options)))
    logger.info("Processing started")

    # save path
    global save_path
    save_path = os.path.join(base_dir, "tours",
                             tour_folder_name, "main")

    # creating save directory
    os.makedirs(name=save_path, mode=0o777, exist_ok=True)

    global tour_id
    tour_id = "main_file.psx"

    # creating document
    doc = Metashape.Document()

    # epsg_code
    epsg_code = options["geo_projection"]

    if (os.path.isfile(path=os.path.join(save_path, tour_id))):
        # open existing document
        logger.info("Opening existing file: {}".format(
                    os.path.join(save_path, tour_id)))
        doc.open(path=os.path.join(save_path, tour_id))
    else:
        # saving document
        doc.save(path=os.path.join(save_path, tour_id))

    # adding chunk
    chunk = add_chunk(doc)

    # adding co-ordinate reference system
    chunk.crs = Metashape.CoordinateSystem(epsg_code)

    # creating and declaring paths
    image_path, export_path = declare_paths(tour_folder_name)

    execution_step = int(options.get("execution_step", 1)) \
        if options.get("execution_step", 1) else 1

    # # starting image process
    await begin_image_processing(
        doc,
        chunk,
        image_path,
        export_path,
        epsg_code,
        execution_step,
        options
    )

    logger.info("Processing complete")
    doc.save(path=os.path.join(save_path, tour_id))
    return


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(process())
