#!/bin/bash
DIR="/usr/local/WowzaStreamingEngine-4.8.10/content"
/usr/local/bin/inotifywait -m -r -e close_write --format '%w%f' "$DIR" | while read f

do
  if [[ "$f" != *".tmp"* ]]; then
    echo Got new file "$f"
    /home/ec2-user/wowza-background-service/.venv/bin/python3.9 ./upload_file_to_blob.py "$f"
  fi
 
done
