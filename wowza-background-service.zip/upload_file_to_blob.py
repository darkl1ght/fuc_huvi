#!/usr/local/bin/python3.9
import sys
import os
import shutil
import random
import logging
import asyncio
import subprocess
from datetime import datetime
from time import sleep
from bson.objectid import ObjectId
import motor.motor_asyncio
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, __version__
from dotenv import load_dotenv
import vimeo
import json
load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MONGODB_CONN_STRING = os.environ.get("MONGODB_CONN_STRING")
MONGODB_DB_NAME = os.environ.get("MONGODB_DB_NAME")
BLOB_UPLOAD_CONTAINER = os.environ.get("BLOB_UPLOAD_CONTAINER")
AZURE_STORAGE_CONNECTION_STRING = os.environ.get(
    "AZURE_STORAGE_CONNECTION_STRING")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_CONN_STRING)
database = client[MONGODB_DB_NAME]
projects_collection = database.get_collection(
    "projects")
lookups_collection = database.get_collection(
    "lookups")
devices_collection = database.get_collection(
    "devices")
project_album_collection = database.get_collection(
    "projectalbums")

staging_folder_path = os.path.join(
    BASE_DIR,
    "ffmpeg_staging"
)
vimeo_client = vimeo.VimeoClient(
    token=os.environ.get("VIMEO_PERSONAL_ACCESS_TOKEN"),
    key=os.environ.get("VIMEO_CLIENT_ID"),
    secret=os.environ.get("VIMEO_CLIENT_SECRET"),
)
if not os.path.isdir(staging_folder_path):
    os.makedirs(staging_folder_path, mode=0o777, exist_ok=True)


async def get_lookups(lookup_type):
    lookups = []
    async for lookup in lookups_collection.find({"type": lookup_type}):
        lookups.append(lookup)
    return lookups


def generateUUID():
    # generates UUID of size 32 size from below pattern
    z = hex(int(datetime.now().timestamp()))[2:]
    s = "xxxxxxxx-xxxx-4xxx-yxxx-xxxzxx"
    uuid = ""
    for i in range(0, len(s)):
        if s[i] == "x" or s[i] == "y":
            r = random.randint(0, 15)
            v = hex(r if s[i] == "x" else (r & 3) | 8)[2:]
            a = "{}".format(s[i]).replace(s[i], v)
            uuid = uuid + a
        else:
            uuid = uuid + s[i]
    uuid = uuid.replace("z", z)
    return uuid


async def upload_to_blob(file_path, upload_file_name):
    try:
        if os.path.exists(file_path):
            connect_str = AZURE_STORAGE_CONNECTION_STRING
            blob_ref = "{0}.{1}".format(
                upload_file_name,
                os.path.basename(file_path).split(".").pop()
            )
            # Create the BlobServiceClient object which will be used to create a container client
            blob_service_client = BlobServiceClient.from_connection_string(
                connect_str)
            # Create a blob client using the local file name as the name for the blob
            blob_client = blob_service_client.get_blob_client(
                container=BLOB_UPLOAD_CONTAINER,
                blob=blob_ref
            )

            # Upload the created file
            with open(file_path, "rb") as data:
                blob_client.upload_blob(data)

            blob_url = blob_client.url
            os.remove(file_path)
        else:
            raise Exception("file to be uploaded does not exist")
    except Exception as err:
        error = "{}".format(str(err))
        return {"success": False, "error": error}
    else:
        return {"success": True, "blob_url": blob_url, "blob_ref": blob_ref}


async def run_subprocess_command(args):
    try:
        process = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            universal_newlines=True
        )
        # print("ffmpeg conversion Started...")
        while True:
            output = process.stdout.readline()
            # print(output.strip())
            return_code = process.poll()
            if return_code is not None:
                print("RETURN CODE {}".format(return_code))
                # Process has finished, read rest of the output
                if return_code == 0:
                    pass
                    # print("ffmpeg conversion Completed.")
                else:
                    for output in process.stdout.readlines():
                        # pass
                        print(output.strip())
                    print(
                        "Some Error occured during script execution. Script: '{}'".format(
                            " ".join(args)
                        )
                    )
                break
        return {"success": True, "error": None}
    except Exception as err:
        return {"success": False, "error": "{}".format(err)}


async def check_transcoder_progress(uri):
    response = ""
    while True:
        response = vimeo_client.get(uri + '?fields=transcode.status').json()
        try:
            if response['transcode']['status'] == 'in_progress':
                sleep(30)
            else:
                break
        except Exception as e:
            return "error"

    if response['transcode']['status'] == 'complete':
        return "success"
    elif response['transcode']['status'] == 'error':
        return "error"


async def upload_to_vimeo(input_file_path, upload_file_name, count):
    file_ext = os.path.basename(input_file_path).split(".").pop()
    try:
        uri = vimeo_client.upload(input_file_path, data={
            'name': "%s.%s" % (upload_file_name, file_ext),
            'description': os.path.basename(input_file_path)
        })
        # print('Your video URI is: %s' % (uri))
        progress = await check_transcoder_progress(uri)
        if progress == "error" and count <= 3:
            count += 1
            await upload_to_vimeo(input_file_path, count)
        elif progress == "error" and count > 3:
            raise Exception(
                "Video Upload Stopped after 3 retries for transcoding")
        else:
            response = vimeo_client.get(uri + '?fields=link').json()
            vimeo_id = response['link'].split(".com/")[1]
            return {"success": True, "error": None, "vimeo_id": vimeo_id}
    except Exception as err:
        error = "Error in Vimeo Upload: %s" % err
        return {"success": False, "error": error}


async def generate_thumbnail(input_file_path, output_file_path):
    try:
        args = [
            "ffmpeg",
            "-hide_banner", "-nostats",
            "-loglevel", "warning",
            "-i", input_file_path,
            "-ss", "00:00:01.000",
            "-vframes", "1",
            output_file_path
        ]
        run_status = await run_subprocess_command(args)
        if not run_status["success"]:
            raise Exception(run_status["error"])
        else:
            return {"success": True, "output_file_path": output_file_path}
    except Exception as err:
        error = "Error in generate_thumbnail function: {}".format(err)
        return {"success": False, "error": error}


async def handle_thumbnail(orig_file_path, upload_file_name):
    file_name = os.path.basename(orig_file_path)
    thumbnail_file_name = file_name[:-4] + ".png"
    thumbnail_staging_file_path = os.path.join(
        staging_folder_path,
        thumbnail_file_name
    )
    status = await generate_thumbnail(orig_file_path, thumbnail_staging_file_path)
    if status["success"]:
        upload_status = await upload_to_blob(
            status["output_file_path"],
            upload_file_name
        )
    else:
        print(status["error"])


async def handle_db_update(file_name, blob_ref, project_id, device_type, file_size, vimeo_id=None):
    try:
        generated_time_string = file_name.split(
            "_t")[1][:-8]
        date_taken = datetime.strptime(
            generated_time_string, "%Y-%m-%d-%H.%M.%S.%f")
        media_file_name = "Livestream_{}".format(
            date_taken.strftime("%Y-%m-%d %H:%M:%S")
        )
        media_id = blob_ref.split(".")[0]

        # meta obj
        metaDataObj = {}
        metaDataObj["lat"] = ""
        metaDataObj["lng"] = ""
        metaDataObj["alt"] = ""
        metaDataObj["dateTaken"] = date_taken
        metaDataObj["fileName"] = file_name
        metaDataObj["fileSize"] = file_size
        metaDataObj["updatedBy"] = "system"
        metaDataObj["updatedByEmail"] = "system"
        metaDataObj["updatedAt"] = datetime.now()

        # media obj
        media = {}
        media["mediaId"] = media_id
        media["blobContentId"] = blob_ref
        media["fileDate"] = date_taken
        media["mediaName"] = media_file_name
        media["projectId"] = project_id
        media["isPublished"] = True
        media["mediaType"] = {"code": "MT10004", "desc": "Panaromic Video"} \
            if device_type["code"] == "DT10002" \
            else {"code": "MT10002", "desc": "Video"}
        if not device_type["code"] == "DT10002" and vimeo_id is not None:
            media["videoSource"] = {"isVimeo": True, "vimeoId": vimeo_id}
        media["meta"] = metaDataObj
        project_albums = []
        async for project_album in project_album_collection.find({"projectId": project_id}):
            project_albums.append(project_album)
        album_id = None
        for project_album in project_albums:
            if project_album["albumName"] == "Un-mapped":
                album_id = project_album["_id"]
                break

        if not album_id:
            new_unmapped_album = await project_album_collection.insert_one(
                {
                    "albumId": generateUUID(),
                    "projectId": project_id,
                    "albumDate": datetime.now(),
                    "albumName": "Un-mapped",
                    "isActive": True,
                    "createdBy": "system",
                    "media": []
                }
            )
            new_album_id = new_unmapped_album.inserted_id
            curr_album = await project_album_collection.find_one(
                {"_id": ObjectId(new_album_id)}
            )
            # media["albumId"] = new_album_id
            await projects_collection.find_one_and_update(
                {"projectId": project_id},
                {"$push": {"album": ObjectId(new_album_id)}}
            )
        else:
            curr_album = await project_album_collection.find_one(
                {"projectId": project_id, "albumName": "Un-mapped"}
            )
            # media["albumId"] = ObjectId(curr_album["_id"])

        media["projectId"] = project_id
        media["createdBy"] = "system"
        media["updatedBy"] = "system"
        media["tags"] = []
        curr_album["media"].append(media)
        curr_album["isActive"] = True
        await project_album_collection.update_one(
            {"_id": ObjectId(curr_album["_id"])},
            {"$set": curr_album}
        )
        vimeo_id = None
    except Exception as err:
        print("Error in handle_db_update function: {}".format(err))


async def handle_video(orig_file_path, project_id, device_type, upload_file_name):
    file_name = os.path.basename(orig_file_path)
    file_size = os.path.getsize(orig_file_path)
    staging_file_path = os.path.join(
        staging_folder_path,
        file_name
    )
    shutil.move(orig_file_path, staging_file_path)
    vimeo_upload_status = {}
    if not device_type["code"] == "DT10002":
        vimeo_upload_status = await upload_to_vimeo(staging_file_path, upload_file_name, 1)
    blob_upload_status = await upload_to_blob(staging_file_path, upload_file_name)
    if blob_upload_status["success"] and vimeo_upload_status.get("success", False):
        await handle_db_update(
            file_name,
            blob_upload_status["blob_ref"],
            project_id,
            device_type,
            file_size,
            vimeo_upload_status["vimeo_id"],
        )
    elif blob_upload_status["success"]:
        await handle_db_update(
            file_name,
            blob_upload_status["blob_ref"],
            project_id,
            device_type,
            file_size,
            ""
        )
    elif not blob_upload_status["success"]:
        print(blob_upload_status["error"])
    elif not vimeo_upload_status.get("success", True):
        print(vimeo_upload_status["error"])


async def begin_processing(orig_file_path):
    try:
        upload_file_name = generateUUID()
        device_id = os.path.basename(orig_file_path).split("_t")[0]
        if device_id == "":
            raise Exception("Device ID not found")
        devices = await devices_collection.find_one(
            {"deviceId": device_id}
        )
        project_id = devices["projectId"]
        device_type = devices["deviceType"]
        # device_type_lookups = await get_lookups("deviceType")
        await handle_thumbnail(orig_file_path, upload_file_name)
        await handle_video(orig_file_path, project_id, device_type, upload_file_name)
    except Exception as err:
        print("Error in begin_processing function: {}".format(str(err)))
        return

if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(begin_processing(sys.argv[1]))
    client.close()


# async def optimize_media_with_ffmpeg(input_file_path):
#     try:
#         output_file_path = input_file_path[:-4] + \
#             "_ffmpeg" + \
#             input_file_path[-4:]
#         args = [
#             "ffmpeg",
#             "-hide_banner", "-nostats",
#             "-loglevel", "warning",
#             "-i", input_file_path,
#             "-pix_fmt", "yuv420p",
#             "-deinterlace",
#             "-vf", "scale=852:480",
#             "-vsync", "1",
#             "-vcodec", "libx264",
#             "-r", "59.940",
#             "-threads", "0",
#             "-crf", "23",
#             "-preset", "medium",
#             "-profile:v", "baseline",
#             "-tune", "film",
#             "-g", "60",
#             "-sc_threshold", "0",
#             "-f", "mp4",
#             "-y", output_file_path
#         ]
#         run_status = await run_subprocess_command(args)
#         if not run_status["success"]:
#             raise Exception(run_status["error"])
#         else:
#             os.remove(input_file_path)
#             os.rename(output_file_path, input_file_path)
#             new_file_size = os.path.getsize(input_file_path)
#             return {"success": True, "output_file_path": input_file_path, "new_file_size": new_file_size}
#     except Exception as err:
#         error = "Error in optimize_media_with_ffmpeg function: {}".format(err)
#         return {"success": False, "error": error}
