import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { Errors, UserService, SnackbarService, UiService } from "../core";
import {} from "src/app/core";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
@Component({
  selector: "app-auth-page",
  templateUrl: "./auth.component.html",
  styleUrls: ["./auth.component.scss"],
})
export class AuthComponent implements OnInit {
  @ViewChild("authenticationForm") authenticationForm;
  emailPattern = /^([A-Z\d][A-Z\d._%+-]*@[A-Z\d][A-Z\d.-]*\.[A-Z]{2,4})$/i;
  authType: String = "";
  title: String = "";
  errors: Errors = { errors: {} };
  isSubmitting = false;
  authForm: FormGroup;
  invalidLoginAttempt: number;
  formSubmitAttempt: boolean;
  registrationStatus: boolean = false;
  loginStatus: boolean = false;
  resendUser = {};
  hide: boolean = true;
  recaptchaAttempts: any;
  token: any;
  buttonDisabled: boolean;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private fb: FormBuilder,
    private ts: TranslateService,
    private snackService: SnackbarService,
    private uiSvc: UiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {
    this.recaptchaAttempts = this.config.recaptchaAttempts;
    this.authForm = this.fb.group({
      email: ["", [Validators.required, Validators.pattern(this.emailPattern)]],
      password: ["", [this.checkPassword]],
    });
  }

  ngOnInit() {
    this.invalidLoginAttempt = 0;
    this.route.url.subscribe((data) => {
      // Get the last piece of the URL (it's either 'login' or 'register')
      this.authType = data[data.length - 1].path;
      // Set a title for the page accordingly
      this.title = this.authType === "login" ? "Sign in" : "Register new user";
      // add form control for username if this is the register page
      if (this.authType === "register") {
        this.authForm.addControl(
          "firstName",
          new FormControl("", [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(255),
          ])
        );
        this.authForm.addControl(
          "lastName",
          new FormControl("", [
            Validators.required,
            Validators.minLength(1),
            Validators.maxLength(255),
          ])
        );
      }
    });
  }

  get f() {
    return this.authForm.controls;
  }

  checkPassword(control) {
    let enteredPassword = control.value;
    let passwordCheck =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$#!%*^?&])[A-Za-z\d@$#!%*^?&]{8,30}$/;
    return !passwordCheck.test(enteredPassword) && enteredPassword
      ? { requirements: true }
      : null;
  }

  isFieldInvalid(field: string) {
    return (
      (!this.authForm.get(field).valid && this.authForm.get(field).touched) ||
      (this.authForm.get(field).untouched && this.formSubmitAttempt)
    );
  }

  getRegistrationPasswordError() {
    return this.authForm.get("password").hasError("required")
      ? this.ts.instant("auth.messages.registerPasswordRequired")
      : this.authForm.get("password").hasError("requirements")
      ? this.ts.instant("auth.messages.registerPasswordRequirement")
      : "";
  }

  getLoginPasswordError() {
    return this.authForm.get("password").hasError("required")
      ? this.ts.instant("auth.messages.providePassword")
      : this.authForm.get("password").hasError("requirements")
      ? this.ts.instant("auth.messages.provideValidPassword")
      : "";
  }

  checkRecaptcha() {
    if (this.invalidLoginAttempt == this.recaptchaAttempts) {
      return (this.buttonDisabled = true);
    }
  }

  resolved(captchaResponse: string) {
    this.buttonDisabled = false;
    this.invalidLoginAttempt = 0;
  }

  onSubmit() {
    this.formSubmitAttempt = true;
    if (this.authForm.valid) {
      this.uiSvc.show();
      this.authForm.value.email = this.authForm.value.email.toLowerCase();
      const credentials = this.authForm.value;
      this.userService.attemptAuth(this.authType, credentials).subscribe(
        (user) => {
          localStorage.setItem("userId", user.id);
          this.uiSvc.hide();
          if (this.authType === "login") {
            user.language ? this.ts.use(user.language) : this.ts.use("en");

            if (user.isAdmin) {
              this.router.navigateByUrl("/client");
            } else {
              this.router.navigateByUrl("/");
            }
          } else if (this.authType === "register") {
            this.reset();
            this.registrationStatus = true;
            this.resendUser = { ...user };
          }
        },
        (err) => {
          if (err?.status == "isNotConfirmed") {
            this.registrationStatus = true;
            this.loginStatus = true;
            this.resendUser = { ...err.user };
          }
          this.uiSvc.hide();
          this.errors = err;
          this.isSubmitting = false;
        }
      );
    }
    this.invalidLoginAttempt++;
  }
  reSend() {
    let alert = "";
    this.uiSvc.show();
    this.userService.resendEmail(this.resendUser).subscribe(
      (data) => {
        this.uiSvc.hide();
        alert = this.ts.instant("auth.messages.resendMsg");
        this.snackService.successSnackBar(alert);
      },
      (err) => {
        this.uiSvc.hide();
        this.errors = err;
      }
    );
  }
  reset() {
    this.errors = { errors: {} };
    this.isSubmitting = false;
    this.authenticationForm.resetForm();
    this.authForm.reset();
  }

  login() {
    this.router.navigate(["/login"]);
  }

  register() {
    this.router.navigate(["/register"]);
  }
}
