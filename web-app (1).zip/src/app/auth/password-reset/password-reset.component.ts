import { Component, OnInit, Inject } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { UserService, UiService, SnackbarService } from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { take, tap } from "rxjs/operators";
@Component({
  selector: "app-password-reset",
  templateUrl: "./password-reset.component.html",
  styleUrls: ["./password-reset.component.scss"],
})
export class PasswordResetComponent implements OnInit {
  emailPattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
  emailAddress = "";
  password = "";
  confirmPassword = "";
  action: string = "";
  title = "";
  resetKey = "";
  error: boolean = false;
  success: boolean = false;
  requestCompleted: boolean = false;
  requestSubmitted: boolean = false;
  resetSuccess: boolean = false;
  validationMsg: string = "";
  passHide: boolean = true;
  confirmPassHide: boolean = true;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private ts: TranslateService,
    private snackService: SnackbarService,
    private uiSvc: UiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.resetKey = params["key"];
    });

    this.route.url.subscribe((data) => {
      this.action = data[0].path;

      if (this.action === "forgot") {
        this.ts
          .get("auth.passwordReset.labels.resetPassword")
          .subscribe((title: string) => {
            this.title = title;
          });
      } else if (this.action === "reset") {
        this.ts
          .get("auth.passwordReset.labels.submit")
          .subscribe((title: string) => {
            this.title = title;
          });
      }
    });
  }

  resetRequest() {
    if (this.emailAddress) {
      this.uiSvc.show();
      this.userService
        .forgot(this.emailAddress)
        .pipe(
          take(1),
          tap((data) => {
            this.requestCompleted = true;
            if (data.status === "00000") {
              this.success = true;
              this.uiSvc.hide();
            } else {
              this.uiSvc.hide();
              this.error = true;
            }
          })
        )
        .subscribe();
    }
  }

  submitReset() {
    this.requestSubmitted = true;
    let alert = "";
    if (
      this.verifyPassword(this.password, this.confirmPassword) &&
      this.resetKey
    ) {
      this.uiSvc.show();
      this.userService
        .confirm(this.resetKey, this.password)
        .pipe(
          take(1),
          tap(
            (data) => {
              this.uiSvc.hide();
              alert = this.ts.instant(
                "auth.passwordReset.messages.passwordResetSuccess"
              );
              this.snackService.successSnackBar(alert);
              // this.router.navigateByUrl("/");
              this.resetSuccess = true;
            },
            (error) => {
              this.uiSvc.hide();
              alert = this.ts.instant(
                "auth.passwordReset.messages.passwordResetFailed"
              );
              this.snackService.successSnackBar(alert);
              this.requestCompleted = true;
              this.error = true;
            }
          )
        )
        .subscribe();
    }
  }

  verifyPassword(password, confirmPassword) {
    this.validationMsg = "";

    if (!password || !confirmPassword) {
      this.validationMsg = this.ts.instant(
        "auth.passwordReset.messages.validPassword"
      );
      return false;
    }

    if (password !== confirmPassword) {
      this.validationMsg = this.ts.instant(
        "auth.passwordReset.messages.passwordMismatch"
      );
      return false;
    }

    //minimum password length validation
    if (password.length < 8) {
      this.ts.instant("auth.passwordReset.messages.minPasswordLengthLimit");
      return false;
    }

    //maximum length of password validation
    if (password > 30) {
      this.ts.instant("auth.passwordReset.messages.maxPasswordLengthLimit");
      return false;
    }

    let passwordCheck =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$#!%*^?&])[A-Za-z\d@$#!%*^?&]{8,30}$/;
    if (!passwordCheck.test(password)) {
      this.validationMsg = this.ts.instant(
        "auth.passwordReset.messages.regexMatch"
      );
      return false;
    }

    return true;
  }
  login() {
    this.router.navigateByUrl("/login");
  }
}
