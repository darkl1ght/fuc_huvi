import { NgModule } from "@angular/core";
import { AuthComponent } from "./auth.component";
import { NoAuthGuard } from "./no-auth-guard.service";
import { SharedModule } from "../shared";
import { AuthRoutingModule } from "./auth-routing.module";
import { PasswordResetComponent } from "./password-reset/password-reset.component";
import { ConfirmRegistrationComponent } from "./confirm-registration/confirm-registration.component";
import { ObscureUserComponent } from "./obscure-user/obscure-user.component";
import {
  RECAPTCHA_SETTINGS,
  RecaptchaFormsModule,
  RecaptchaModule,
  RecaptchaSettings,
} from "ng-recaptcha";
import { environment } from "src/environments/environment";
@NgModule({
  imports: [
    SharedModule,
    AuthRoutingModule,
    RecaptchaFormsModule,
    RecaptchaModule,
  ],
  declarations: [
    AuthComponent,
    PasswordResetComponent,
    ConfirmRegistrationComponent,
    ObscureUserComponent,
  ],
  providers: [
    NoAuthGuard,
    {
      provide: RECAPTCHA_SETTINGS,
      useValue: {
        siteKey: environment.recaptcha.siteKey,
      } as RecaptchaSettings,
    },
  ],
})
export class AuthModule {}
