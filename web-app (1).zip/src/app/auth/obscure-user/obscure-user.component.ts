import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { UiService, UserService } from "src/app/core";

@Component({
  selector: "app-obscure-user",
  templateUrl: "./obscure-user.component.html",
  styleUrls: ["./obscure-user.component.scss"],
})
export class ObscureUserComponent implements OnInit {
  userToken: string;
  invalidCredentials: boolean = false;
  idtoken: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private userSvc: UserService,
    private uiService: UiService,
    public router: Router
  ) {
    // var url =
    //   window.location != window.parent.location
    //     ? document.referrer
    //     : document.location.href;

    var qs = this.getQueryStrings();
    this.userToken = qs["token"];
    this.idtoken = qs["idtoken"];

    if (window !== window.top) {
      if (this.userToken && this.idtoken) {
        this.login(this.userToken, this.idtoken);
      } else {
        this.invalidCredentials = true;
      }
    } else {
      this.invalidCredentials = true;
    }
  }

  ngOnInit() {}

  login(hashKey: string, idtoken: string) {
    let cred = { userToken: hashKey, projectId: idtoken };
    if (hashKey) {
      this.uiService.show();
      this.userSvc.obscureUserLogin(cred).subscribe(
        (value) => {
          this.router.navigateByUrl(`/project/detail/${idtoken}/exterior/list`);
          this.invalidCredentials = false;
          this.uiService.hide();
        },
        (error) => {
          this.invalidCredentials = true;
          this.uiService.hide();
        },
        () => {}
      );
    }
  }

  getQueryStrings() {
    var assoc = {};
    var decode = function (s) {
      return decodeURIComponent(s.replace(/\+/g, " "));
    };
    var queryString = location.search.substring(1);
    var keyValues = queryString.split("&");

    for (var i in keyValues) {
      var key = keyValues[i].split("=");
      if (key.length > 1) {
        assoc[decode(key[0])] = decode(key[1]);
      }
    }

    return assoc;
  }
}
