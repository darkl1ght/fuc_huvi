import { Component, OnInit, Inject } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { UserService, SnackbarService } from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { take, tap } from "rxjs/operators";

@Component({
  selector: "confirm-registration",
  templateUrl: "./confirm-registration.component.html",
  styleUrls: ["./confirm-registration.component.scss"],
})
export class ConfirmRegistrationComponent implements OnInit {
  registrationKey: string = "";
  status: string = "";

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private ts: TranslateService,
    private snackService: SnackbarService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.registrationKey = params["key"];
      this.confirmRegistration();
    });
  }
  gotoLogin() {
    this.router.navigate(["/login"]);
  }
  confirmRegistration() {
    let alert = "";
    if (this.registrationKey) {
      this.userService
        .confirmRegistration(this.registrationKey)
        .pipe(
          take(1),
          tap(
            (data) => {
              if (data.status === "00000") {
                alert = this.ts.instant(
                  "auth.confirmReg.messages.registrationSuccessful"
                );
                this.snackService.successSnackBar(alert);
                this.status = data.status;
              }
            },
            (error) => {
              this.status = error.status;
            }
          )
        )
        .subscribe();
    }
  }
}
