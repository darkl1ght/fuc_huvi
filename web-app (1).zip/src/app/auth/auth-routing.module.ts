import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthComponent } from "./auth.component";
import { NoAuthGuard } from "./no-auth-guard.service";
import { PasswordResetComponent } from "./password-reset/password-reset.component";
import { ConfirmRegistrationComponent } from "./confirm-registration/confirm-registration.component";
import { ObscureUserComponent } from "./obscure-user/obscure-user.component";

const routes: Routes = [
  {
    path: "login",
    component: AuthComponent,
    canActivate: [NoAuthGuard],
  },
  {
    path: "ob",
    component: ObscureUserComponent,
    canActivate: [NoAuthGuard],
  },
  {
    path: "register",
    component: AuthComponent,
    canActivate: [NoAuthGuard],
  },
  {
    path: "forgot",
    component: PasswordResetComponent,
    canActivate: [NoAuthGuard],
  },
  {
    path: "reset",
    component: PasswordResetComponent,
    canActivate: [NoAuthGuard],
  },
  {
    path: "confirm",
    component: ConfirmRegistrationComponent,
    canActivate: [NoAuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AuthRoutingModule {}
