import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

@Component({
  selector: "app-confirm-alert",
  templateUrl: "./confirm-alert.component.html",
  styleUrls: ["./confirm-alert.component.scss"],
})
export class ConfirmAlertComponent implements OnInit {
  title: string;
  message: string;
  successBtn: string;
  icon: string;
  showCloseIcon: boolean = true;

  constructor(
    public dialogRef: MatDialogRef<ConfirmAlertComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmAlertModel
  ) {
    // Update view with given values
    this.title = data.title;
    this.message = data.message;
    this.successBtn = data.successBtn;
    this.icon = data.icon;
    this.showCloseIcon =
      data.showCloseIcon === undefined ? true : data.showCloseIcon;
  }

  ngOnInit() {}

  onConfirm(): void {
    // Close the dialog, return true
    this.dialogRef.close(true);
  }

  onDismiss(): void {
    // Close the dialog, return false
    this.dialogRef.close(false);
  }
}

/**
 * Class to represent confirm dialog model.
 *
 * It has been kept here to keep it as part of shared component.
 */
export class ConfirmAlertModel {
  constructor(
    public title: string,
    public message: string,
    public successBtn: string,
    public icon: string,
    public data?: any,
    public dataLabel?: string,
    public showCloseIcon?: boolean
  ) {}
}
