import { MasterDataService } from "src/app/core";
import {
  Component,
  Input,
  OnInit,
  OnChanges,
  ViewChild,
  Inject,
  OnDestroy,
} from "@angular/core";
import { MatMenuTrigger } from "@angular/material/menu";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { LocalStorageService } from "./../../../core/services/local-storage.service";
import _ from "lodash/capitalize";
import { Subscription } from "rxjs";
import { v4 as uuidv4 } from "uuid";

@Component({
  selector: "app-weather",
  templateUrl: "./weather.component.html",
  styleUrls: ["./weather.component.scss"],
})
export class WeatherComponent implements OnInit, OnChanges, OnDestroy {
  @Input() lat: number;
  @Input() lng: number;
  @Input() location: string = "";
  @ViewChild("trigger") trigger: MatMenuTrigger;
  errors = {};
  isError: boolean = false;
  iconExtn: string = ".png";
  icon2x: string = "@2x";
  days: string[] = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  isLoading: boolean = true;
  description: string = "";
  temp: string = "";
  feelsLike: string = "";
  iconUrlx1: string = "";
  iconUrlx2: string = "";
  weatherDataList: WeatherData[] = [];
  myId: string;
  refreshWeatherSubscription: Subscription;
  matTooltipDelay: number = 200;

  constructor(
    @Inject(APP_CONFIG) private config: AppConfig,
    private masterDataService: MasterDataService,
    private localStorageService: LocalStorageService
  ) {}

  ngOnInit(): void {
    if (!this.myId) {
      this.myId = uuidv4();
    }

    this.refreshWeatherSubscription =
      this.masterDataService.refreshWeather$.subscribe({
        next: (id) => {
          if (this.myId != id) {
            this.getWeatherData(false);
          }
        },
      });
  }

  ngOnChanges(): void {
    if (!this.myId) {
      this.myId = uuidv4();
    }

    if (this.lat && this.lng) {
      this.getWeatherData(true);
    }
  }

  ngOnDestroy(): void {
    this.refreshWeatherSubscription.unsubscribe();
  }

  getWeatherData(notify: boolean): void {
    this.isLoading = true;

    const storedWeather: any = this.localStorageService.getWeather(
      parseFloat(this.lat.toString()).toFixed(3),
      parseFloat(this.lng.toString()).toFixed(3)
    );

    if (storedWeather) {
      this.setWeatherData(storedWeather);
      this.isLoading = false;
      this.isError = false;
    } else {
      this.masterDataService
        .getWeatherOneCall_1_0(
          parseFloat(this.lat.toString()).toFixed(3),
          parseFloat(this.lng.toString()).toFixed(3)
        )
        .subscribe(
          (data) => {
            this.setWeatherData(data);
            this.localStorageService.setWeather(data);
            this.isLoading = false;
            this.isError = false;
          },
          (err) => {
            this.errors = err;
            this.isError = true;
            this.isLoading = false;
          }
        );
    }

    if (notify) {
      this.masterDataService.sendRefreshWeather(this.myId);
    }
  }

  setWeatherData(data: any) {
    this.description = _(data.current.weather[0].description);
    this.temp = parseFloat(data.current.temp).toFixed(1);
    this.iconUrlx2 =
      this.config.weatherIconBaseUrl +
      data.current.weather[0].icon +
      this.icon2x +
      this.iconExtn;
    this.iconUrlx1 =
      this.config.weatherIconBaseUrl +
      data.current.weather[0].icon +
      this.iconExtn;
    this.feelsLike = parseFloat(data.current.feels_like).toFixed(1);
    this.weatherDataList = [];

    for (const day of data.daily) {
      const utcInSecs = day.dt;
      const dt = new Date(parseInt(utcInSecs) * 1000);
      const iconUrl =
        this.config.weatherIconBaseUrl + day.weather[0].icon + this.iconExtn;
      const description = _(day.weather[0].description);

      const weatherData = new WeatherData(
        this.days[dt.getDay()],
        iconUrl,
        description,
        parseFloat(day.temp.day).toFixed(1)
      );

      this.weatherDataList.push(weatherData);
    }
  }

  openWeatherMore() {
    this.trigger.openMenu();
  }
}

class WeatherData {
  constructor(
    private day: string,
    private icon: string,
    private description: string,
    private temp: string
  ) {}
}
