import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { MaterialModule } from "src/app/shared/material/material.module";
import { WeatherComponent } from "./weather.component";
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    TranslateModule,
    FlexLayoutModule,
  ],
  declarations: [WeatherComponent],
  exports: [WeatherComponent],
})
export class WeatherModule {}
