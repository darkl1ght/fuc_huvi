import { Component } from "@angular/core";

import { TranslateService } from "@ngx-translate/core";

interface Page {
  link: string;
  name: string;
  icon: string;
}

@Component({
  selector: "reports-left-menu",
  templateUrl: "./reports-sidebar.component.html",
  styleUrls: ["./reports-sidebar.component.scss"],
})
export class ReportsSidebarComponent {
  public topPages: Page[];

  constructor(private ts: TranslateService) {}

  ngOnInit() {
    this.topPages = [
      {
        name: this.ts.instant("reportsMenu.captureStatistics"),
        link: "capturestats",
        icon: "center_focus_strong",
      },
      {
        name: this.ts.instant("reportsMenu.adoptionStatistics"),
        link: "adoptionstats",
        icon: "task_alt",
      },
      {
        name: this.ts.instant("reportsMenu.captureMetrics"),
        link: "capturemetrics",
        icon: "account_tree",
      },
      {
        name: this.ts.instant("reportsMenu.contractDates"),
        link: "contractdates",
        icon: "gavel",
      },
    ];
  }
}
