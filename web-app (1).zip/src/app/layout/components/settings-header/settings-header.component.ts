import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { throwError } from "rxjs/internal/observable/throwError";
import { catchError, finalize, map } from "rxjs/operators";
import { ProjectService } from "src/app/core";

@Component({
  selector: "settings-header",
  templateUrl: "./settings-header.component.html",
  styleUrls: ["./settings-header.component.scss"],
})
export class SettingsHeaderComponent implements OnInit {
  public projectId: string;
  public project;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private projectService: ProjectService
  ) {
    this.projectId = this.route.parent.snapshot.paramMap.get("projectId");
  }

  ngOnInit() {
    this.route.parent.params.subscribe((params) => {
      this.projectId = params["projectId"];
    });

    this.getProjectData(this.projectId);
  }

  getProjectData(projectId) {
    this.projectService
      .get(this.projectId)
      .pipe(
        map(
          (data) => {
            this.project = data;
          },
          (err) => {
            // console.log(err);
          }
        ),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  gotoAerial() {
    if (
      this.project.aerialTours?.length == 0 &&
      this.project.interiors.length > 0
    ) {
      this.router.navigate([`/detail/${this.projectId}/interior`]);
    } else {
      this.router.navigate(["/detail", this.projectId]);
    }
  }

  private handleError(error: any) {
    return throwError(error);
  }
}
