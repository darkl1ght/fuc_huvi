import { Component } from "@angular/core";
import { AppMessageService, LocalStorageService } from "src/app/core";

@Component({
  selector: "app-dynamic-message",
  templateUrl: "./dynamic-message.component.html",
  styleUrls: ["./dynamic-message.component.scss"],
})
export class DynamicMessageComponent {
  message: string;
  messageTitle: string;
  messages: string[];

  constructor(
    private localStorage: LocalStorageService,
    private appMessageSvc: AppMessageService
  ) {}

  ngOnInit() {
    this.messages = this.localStorage.getItem("Messages");
    if (this.messages) {
      const randomIndex = Math.floor(this.messages.length * Math.random());
      this.message = this.messages[randomIndex];
    } else {
      this.appMessageSvc.getDynamicMessage().subscribe((data) => {
        let appMessages = data.appMessages.map((item) => {
          return item.messageContent;
        });
        this.localStorage.setItem("Messages", appMessages);
        this.messages = appMessages;
        const randomIndex = Math.floor(this.messages.length * Math.random());
        this.message = this.messages[randomIndex];
      });
    }
  }
}
