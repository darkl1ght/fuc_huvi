import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { MaterialModule } from "src/app/shared/material/material.module";
import { ImageEditorComponent } from "./image-editor.component";
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    TranslateModule,
    FlexLayoutModule,
  ],
  declarations: [ImageEditorComponent],
  exports: [ImageEditorComponent],
})
export class ImageEditorModule {}
