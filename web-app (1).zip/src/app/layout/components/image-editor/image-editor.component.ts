import { Component, Output, EventEmitter } from "@angular/core";
import { ImageEnhancementProps } from "../../project/detail/components/interior/walkthrough/walkthrough-utils";

@Component({
  selector: "app-image-editor",
  templateUrl: "./image-editor.component.html",
  styleUrls: ["./image-editor.component.scss"],
})
export class ImageEditorComponent {
  imageEnhancementProps: ImageEnhancementProps;

  @Output() imageProperties = new EventEmitter<ImageEnhancementProps>();
  @Output() close = new EventEmitter();

  constructor() {
    this.imageEnhancementProps = new ImageEnhancementProps(100, 100);
  }
  updateProps() {
    this.imageProperties.emit(this.imageEnhancementProps);
  }
  resetValues() {
    this.imageEnhancementProps.resetValues();
    this.imageProperties.emit(this.imageEnhancementProps);
  }

  closePanel() {
    this.close.emit();
  }
}
