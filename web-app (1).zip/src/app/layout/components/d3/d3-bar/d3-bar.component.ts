import { AfterViewInit, Component, Input } from "@angular/core";
import * as d3 from "d3";

@Component({
  selector: "d3-bar",
  templateUrl: "./d3-bar.component.html",
  styleUrls: ["./d3-bar.component.scss"],
})
export class D3BarComponent implements AfterViewInit {
  @Input() chartId: string;
  @Input() width: number; // = 1000 - this.margin * 2;
  @Input() height: number; // = 600 - this.margin * 2;
  @Input() labelFontSize: string = "10px";
  @Input() data: SimpleDataModel[];

  title = "Bar Chart";
  constructor() {}

  ngAfterViewInit(): void {
    this.drawBars(this.data);
  }

  private drawBars(data: SimpleDataModel[]): void {
    const width = this.width;
    const height = this.height;
    const marginTop = 30;
    const marginRight = 0;
    const marginBottom = 30;
    const marginLeft = 40;

    const x = d3
      .scaleBand()
      .domain(
        d3.groupSort(
          data,
          ([d]) => -d.value,
          (d) => d.name
        )
      )
      .range([marginLeft, width - marginRight])
      .padding(0.1);

    const y = d3
      .scaleLinear()
      .domain([0, Number(d3.max(data, (d) => d.value)) + 2])
      .range([height - marginBottom, marginTop]);

    const svg = d3
      .select(`div#${this.chartId}`)
      .append("svg")
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", [0, 0, width, height])
      .attr("style", "max-width: 100%; height: auto;");

    svg
      .append("g")
      .attr("fill", "steelblue")
      .selectAll()
      .data(data)
      .join("rect")
      .attr("x", (d) => x(d.name))
      .attr("y", (d) => y(Number(d.value)))
      .attr("height", (d) => y(0) - y(Number(d.value)))
      .attr("width", x.bandwidth())
      .attr("fill", (d) => d.color);

    svg
      .append("g")
      .attr("transform", `translate(0,${height - marginBottom})`)
      .call(d3.axisBottom(x).tickSizeOuter(0))
      .style("font-size", this.labelFontSize);

    svg
      .append("g")
      .attr("transform", `translate(${marginLeft},0)`)
      .call(
        d3
          .axisLeft(y)
          .tickFormat(d3.format("d"))
          .ticks(Math.ceil((this.height - marginBottom) / 40))
      )
      .call((g) => g.select(".domain").remove());
    // .call((g) =>
    //   g
    //     .append("text")
    //     .attr("x", -marginLeft)
    //     .attr("y", 15)
    //     .attr("fill", "currentColor")
    //     .attr("text-anchor", "start")
    //     .text("Count")
    // );

    svg
      .selectAll("text.bar")
      .data(data)
      .enter()
      .append("text")
      .attr("class", "yAxis-label")
      .attr("text-anchor", "middle")
      .attr("fill", "#70747a")
      .attr("x", (d) => x(d.name) + x.bandwidth() / 2)
      .attr("y", (d) => y(Number(d.value)))
      .attr("height", (d) => y(0) - y(Number(d.value)))
      .text((d) => d.value)
      .style("font-size", "12px")
      .style("font-weight", "bold");
  }
}

interface SimpleDataModel {
  name: string;
  value: string;
  color?: string;
}
