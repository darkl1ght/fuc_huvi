import { Component, Input } from "@angular/core";
import * as d3 from "d3";

@Component({
  selector: "d3-pie",
  templateUrl: "./d3-pie.component.html",
  styleUrls: ["./d3-pie.component.scss"],
})
export class D3PieComponent {
  title = "Pie Chart";

  @Input() chartId: string;
  @Input() width!: number;
  @Input() height!: number;
  @Input() labelFontSize: string = "10px";
  @Input() isValuePercentage: boolean = false;
  @Input() enablePolylines: boolean = false;
  @Input() innerRadius: number = 100;
  @Input() inputData!: PieDataItem[];
  @Input() showLabelsOnChart: boolean = false;
  textColor: string = "#000";
  private svg: any;
  private margin: number = 25;
  radius: number;
  private colors: any;
  private pieData: any;
  constructor() {}

  ngOnInit() {
    this.pieData = this.inputData;
    this.createColors();
    this.drawChart();
  }

  private createColors(data = this.pieData): void {
    this.colors = d3
      .scaleOrdinal()
      .domain(data.map((d) => d.count.toString()))
      .range([
        "#6773f1",
        "#32325d",
        "#6162b5",
        "#6586f6",
        "#8b6ced",
        "#1b1b1b",
        "#212121",
      ]);
  }

  private drawChart(data = this.pieData): void {
    let pieData = [];
    let oldPieData = [];
    let filteredPieData = [];
    let tweenDuration = 1050;
    let radius = 150;
    let textOffset = 24;

    // Compute the position of each group on the pie
    const pie = d3.pie<any>().value((d: any) => Number(d.count));

    // The radius of the pieplot is half the width or half the height (smallest one). I subtract a bit of margin.
    // let radius = Math.min(this.width, this.height) / 2 - this.margin;

    let outerArc = d3
      .arc()
      .startAngle((d) => d.startAngle)
      .endAngle((d) => d.endAngle)
      .innerRadius(0)
      .outerRadius(radius * 0.9);

    // The arc generator
    let arc = d3.arc().outerRadius(radius * 0.8);

    this.svg = d3
      .select(`div#${this.chartId}`)
      .append("svg:svg")
      .attr("width", this.width)
      .attr("height", this.height);

    const div = d3
      .select(`div#${this.chartId}`)
      .append("div")
      .attr("class", "toolTip");

    //GROUP FOR ARCS/PATHS
    var arc_group = this.svg
      .append("svg:g")
      .attr("class", "arc")
      .attr(
        "transform",
        "translate(" + this.width / 2 + "," + this.height / 2 + ")"
      );

    const update = (data) => {
      oldPieData = filteredPieData;
      pieData = pie(data);

      let sliceProportion = 0; //size of this slice
      const filterData = (element, index, array) => {
        element.name = data[index].label;
        element.value = data[index].count;
        sliceProportion += element.value;
        return element.value > 0;
      };
      filteredPieData = pieData.filter(filterData);

      //DRAW ARC PATHS
      let paths = arc_group.selectAll("path").data(filteredPieData);
      paths
        .enter()
        .append("svg:path")
        .attr("stroke", "white")
        .attr("stroke-width", 0.5)
        .attr("fill", (d, i) => {
          return this.colors(i);
        })
        .transition()
        .duration(tweenDuration)
        .attrTween("d", pieTween);
      paths.transition().duration(tweenDuration).attrTween("d", pieTween);
      paths
        .exit()
        .transition()
        .duration(tweenDuration)
        .attrTween("d", removePieTween)
        .remove();

      paths.on("mousemove", (e, d) => {
        div.style("left", e.x + 10 + "px");
        div.style("top", e.y - 25 + "px");
        div.style("display", "inline-block");
      });

      paths.on("mouseout", (d) => {
        div.style("display", "none");
      });
    };

    // Interpolate the arcs in data space.
    const pieTween = (d, i) => {
      var s0;
      var e0;
      if (oldPieData[i]) {
        s0 = oldPieData[i].startAngle;
        e0 = oldPieData[i].endAngle;
      } else if (!oldPieData[i] && oldPieData[i - 1]) {
        s0 = oldPieData[i - 1].endAngle;
        e0 = oldPieData[i - 1].endAngle;
      } else if (!oldPieData[i - 1] && oldPieData.length > 0) {
        s0 = oldPieData[oldPieData.length - 1].endAngle;
        e0 = oldPieData[oldPieData.length - 1].endAngle;
      } else {
        s0 = 0;
        e0 = 0;
      }
      let i2 = d3.interpolate(
        {
          startAngle: s0,
          endAngle: e0,
          innerRadius: 0,
          outerRadius: radius * 0.9,
        },
        {
          startAngle: d.startAngle,
          endAngle: d.endAngle,
          innerRadius: 0,
          outerRadius: radius * 0.9,
        }
      );
      return (t) => {
        let b = i2(t);
        return outerArc(b);
      };
    };

    const removePieTween = (d, i) => {
      let s0 = 2 * Math.PI;
      let e0 = 2 * Math.PI;
      let i2 = d3.interpolate(
        {
          startAngle: d.startAngle,
          endAngle: d.endAngle,
          innerRadius: 0,
          outerRadius: radius * 0.9,
        },
        {
          startAngle: s0,
          endAngle: e0,
          innerRadius: 0,
          outerRadius: radius * 0.9,
        }
      );
      return (t) => {
        let b = i2(t);
        return outerArc(b);
      };
    };

    const textTween = (d, i) => {
      var a;
      if (oldPieData[i]) {
        a = (oldPieData[i].startAngle + oldPieData[i].endAngle - Math.PI) / 2;
      } else if (!oldPieData[i] && oldPieData[i - 1]) {
        a =
          (oldPieData[i - 1].startAngle +
            oldPieData[i - 1].endAngle -
            Math.PI) /
          2;
      } else if (!oldPieData[i - 1] && oldPieData.length > 0) {
        a =
          (oldPieData[oldPieData.length - 1].startAngle +
            oldPieData[oldPieData.length - 1].endAngle -
            Math.PI) /
          2;
      } else {
        a = 0;
      }
      var b = (d.startAngle + d.endAngle - Math.PI) / 2;

      var fn = d3.interpolateNumber(a, b);
      return (t) => {
        var val = fn(t);
        return (
          "translate(" +
          Math.cos(val) * (radius + textOffset) +
          "," +
          Math.sin(val) * (radius + textOffset) +
          ")"
        );
      };
    };

    update(data);
  }
}

interface PieDataItem {
  label: string;
  count: number;
  color: string;
}
