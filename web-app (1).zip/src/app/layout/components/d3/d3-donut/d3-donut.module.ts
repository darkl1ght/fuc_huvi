import { NgModule } from "@angular/core";
import { D3DonutComponent } from "./d3-donut.component";
import { DragDropModule } from "@angular/cdk/drag-drop";
import { CommonModule } from "@angular/common";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { MaterialModule } from "src/app/shared/material/material.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    TranslateModule,
    FlexLayoutModule,
    DragDropModule,
  ],
  declarations: [D3DonutComponent],
  exports: [D3DonutComponent],
})
export class D3DonutModule {}
