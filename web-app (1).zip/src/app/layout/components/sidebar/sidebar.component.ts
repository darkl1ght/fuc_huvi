import { Component, OnInit, Input } from "@angular/core";
import {
  onSideNavChange,
  animateText,
} from "src/app/core/animations/animations";
import { SidenavService } from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { ActivatedRoute, Router } from "@angular/router";
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import { fieldIssueIcon } from "../../project/detail/components/interior/walkthrough/walkthrough-utils";
interface Page {
  link: string;
  name: string;
  icon: string;
}

@Component({
  selector: "app-left-menu",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.scss"],
  animations: [onSideNavChange, animateText],
})
export class LeftMenuComponent implements OnInit {
  public sideNavState: boolean = false;
  public linkText: boolean = false;
  @Input() projectType;
  public projectId: string;

  public topPages: Page[];
  public bottomPages: Page[];
  helpDeskLink: string;

  constructor(
    private _sidenavService: SidenavService,
    private ts: TranslateService,
    private route: ActivatedRoute,
    private router: Router,
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer
  ) {
    this.projectId = this.route.parent.snapshot.paramMap.get("projectId");
    iconRegistry.addSvgIconLiteral(
      "field-issue",
      sanitizer.bypassSecurityTrustHtml(fieldIssueIcon)
    );
  }

  ngOnInit() {
    this.onSidenavToggle();
    this.setMenu();

    this.route.parent.params.subscribe((params) => {
      this.projectId = params["projectId"];
    });
  }

  onSidenavToggle() {
    this.sideNavState = !this.sideNavState;

    setTimeout(() => {
      this.linkText = this.sideNavState;
    }, 200);
    this._sidenavService.sideNavState$.next(this.sideNavState);
  }

  setMenu() {
    this.topPages = [
      {
        name: this.ts.instant("sidebar.dashboard"),
        link: "dashboard",
        icon: "dashboard",
      },
      {
        name: this.ts.instant("sidebar.aerial"),
        link: "exterior",
        icon: "public",
      },
      {
        name: this.ts.instant("sidebar.interior"),
        link: "interior",
        icon: "switch_video",
      },
      {
        name: this.ts.instant("sidebar.punchlist"),
        link: "task",
        icon: "task_alt",
      },
      {
        name: this.ts.instant("sidebar.smartmedia"),
        link: "smartmedia",
        icon: "photo_library",
      },
      {
        name: this.ts.instant("sidebar.documents"),
        link: "document",
        icon: "folder",
      },
      {
        name: this.ts.instant("sidebar.rfis"),
        link: "rfi",
        icon: "receipt",
      },
      {
        name: this.ts.instant("sidebar.fieldIssue"),
        link: "fieldIssue",
        icon: "fieldIssueCustom",
      },
    ];

    this.bottomPages = [
      {
        name: this.ts.instant("sidebar.settings"),
        link: "settings",
        icon: "settings",
      },
    ];
  }

  goToSettings() {
    this.router.navigate(["../settings", this.projectId]);
  }
}
