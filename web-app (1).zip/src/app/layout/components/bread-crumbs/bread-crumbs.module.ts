import { NgModule } from "@angular/core";
import { BreadCrumbsComponent } from "./bread-crumbs.component";
import { DragDropModule } from "@angular/cdk/drag-drop";
import { CommonModule } from "@angular/common";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { MaterialModule } from "src/app/shared/material/material.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    TranslateModule,
    FlexLayoutModule,
    DragDropModule,
  ],
  declarations: [BreadCrumbsComponent],
  exports: [BreadCrumbsComponent],
})
export class BreadCrumbsModule {}
