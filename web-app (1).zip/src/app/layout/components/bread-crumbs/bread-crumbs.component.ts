import { Component, OnInit, Input } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-bread-crumbs",
  templateUrl: "./bread-crumbs.component.html",
  styleUrls: ["./bread-crumbs.component.scss"],
})
export class BreadCrumbsComponent implements OnInit {
  @Input() navType: any;
  @Input() pageName: any;
  isIframe: boolean = false;

  constructor(private router: Router, private route: ActivatedRoute) {}

  ngOnInit() {
    if (window !== window.top) {
      this.isIframe = true;
    }
  }

  goToProject() {
    this.router.navigate(["../list"]);
  }

  goToInterior() {
    this.router.navigate(["../interior"], { relativeTo: this.route.parent });
  }

  goToInspectionList(navFrom) {
    let relativeToPath;
    if (navFrom === "dashboard") {
      relativeToPath = this.route.parent.parent.parent;
    } else if (navFrom === "inspection") {
      relativeToPath = this.route.parent;
    }
    this.router.navigate(["../activity/list"], {
      relativeTo: relativeToPath,
    });
  }

  goToAlbum() {
    this.router.navigate(["../media"], { relativeTo: this.route.parent });
  }
}
