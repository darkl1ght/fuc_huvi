import { Component, OnInit, Input } from "@angular/core";
import { ProjectService, UiService, User, UserService } from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { ActivatedRoute, Router } from "@angular/router";

interface Page {
  link: string;
  name: string;
  icon: string;
}

@Component({
  selector: "settings-left-menu",
  templateUrl: "./settings-sidebar.component.html",
  styleUrls: ["./settings-sidebar.component.scss"],
})
export class SettingsLeftMenuComponent implements OnInit {
  public sideNavState: boolean = false;
  public linkText: boolean = false;
  public projectId: string;

  public topPages: Page[];
  public bottomPage: Page;
  public currentUser: User;
  public currentClientID: string;

  // hardcoding production client Id for "test Jayant"
  private clientIds: any = ["a363b0b6-f73b-4685-93c7-0508d757e632"];

  constructor(
    private ts: TranslateService,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private projectService: ProjectService,
    private uiService: UiService
  ) {
    this.projectId = this.route.parent.snapshot.paramMap.get("projectId");
    this.currentUser = this.userService.getCurrentUser();
  }

  ngOnInit() {
    this.uiService.show();
    this.topPages = [
      {
        name: this.ts.instant("settingsMenu.workTrades"),
        link: "workpackage",
        icon: "engineering",
      },
      {
        name: this.ts.instant("settingsMenu.location"),
        link: "location",
        icon: "pin_drop",
      },
      {
        name: this.ts.instant("settingsMenu.schedule"),
        link: "schedule",
        icon: "schedule",
      },
      {
        name: this.ts.instant("settingsMenu.inspectionchecklist"),
        link: "inspectionchecklist",
        icon: "checklist",
      },
    ];
    this.projectService.get(this.projectId).subscribe((project) => {
      this.currentClientID = project.clientId;
      this.setMenu();
    });
  }

  setMenu() {
    if (
      this.currentUser.isAdmin ||
      this.clientIds.indexOf(this.currentClientID) === -1
    ) {
      this.topPages.push({
        name: this.ts.instant("settingsMenu.team"),
        link: "team",
        icon: "group",
      });
    }
    if (this.currentUser.isAdmin) {
      this.topPages.push(
        {
          name: this.ts.instant("settingsMenu.userroles"),
          link: "userroles",
          icon: "shield",
        },
        {
          name: this.ts.instant("settingsMenu.workFlow"),
          link: "workflow",
          icon: "rebase_edit",
        },
        {
          name: this.ts.instant("settingsMenu.integration"),
          link: "integration",
          icon: "sync_alt",
        }
      );
    }
    this.uiService.hide();
  }

  goToSettings() {
    this.router.navigate(["../settings", this.projectId]);
  }
}
