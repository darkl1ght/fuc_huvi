import { Component, OnInit, EventEmitter, Output } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: "reports-header",
  templateUrl: "./reports-header.component.html",
  styleUrls: ["./reports-header.component.scss"],
})
export class ReportsHeaderComponent {
  @Output() closeSideNav = new EventEmitter();

  constructor(private route: ActivatedRoute, private router: Router) {}

  ngOnInit() {}

  onToggleClose() {
    this.closeSideNav.emit();
  }

  goToProjects() {
    this.router.navigate(["/project"]);
    this.onToggleClose();
  }
}
