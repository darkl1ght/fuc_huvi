import { NgModule } from "@angular/core";
import { DataTableComponent } from "./data-table.component";
import { CommonModule } from "@angular/common";
import { FlexLayoutModule } from "@angular/flex-layout";
import { TranslateModule } from "@ngx-translate/core";
import { MaterialModule } from "src/app/shared/material/material.module";

@NgModule({
  imports: [CommonModule, MaterialModule, TranslateModule, FlexLayoutModule],
  declarations: [DataTableComponent],
  exports: [DataTableComponent],
})
export class DataTableModule {}
