import { Component, OnInit, Inject, ElementRef } from "@angular/core";
import {
  MatDialogConfig,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";

@Component({
  selector: "app-simple-alert",
  templateUrl: "./simple-alert.component.html",
  styleUrls: ["./simple-alert.component.scss"],
})
export class SimpleAlertComponent implements OnInit {
  title: string;
  message: string;
  successBtn: string;
  icon: string;
  private positionRelativeToElement: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<SimpleAlertComponent>,
    @Inject(MAT_DIALOG_DATA) public data: SimpleAlertModel
  ) {
    // Update view with given values
    this.title = data.title;
    this.message = data.message;
    this.successBtn = data.successBtn;
    this.icon = data.icon;
    this.positionRelativeToElement = data.positionRelativeToElement;
  }

  ngOnInit() {
    const matDialogConfig = new MatDialogConfig();
    const rect: DOMRect =
      this.positionRelativeToElement.nativeElement.getBoundingClientRect();

    matDialogConfig.position = {
      left: `${rect.right - rect.left / 2 - 100}px`,
      top: `35vh`,
    };
    this.dialogRef.updatePosition(matDialogConfig.position);
  }

  onConfirm(): void {
    // Close the dialog, return true
    this.dialogRef.close(true);
  }

  onDismiss(): void {
    // Close the dialog, return false
    this.dialogRef.close(false);
  }
}

/**
 * Class to represent confirm dialog model.
 *
 * It has been kept here to keep it as part of shared component.
 */
export class SimpleAlertModel {
  constructor(
    public title: string,
    public message: string,
    public successBtn: string,
    public icon: string,
    public positionRelativeToElement?: ElementRef
  ) {}
}
