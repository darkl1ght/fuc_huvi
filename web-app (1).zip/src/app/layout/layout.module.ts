import { NgModule } from "@angular/core";
import { SharedModule } from "../shared/shared.module";
import { LayoutRoutingModule } from "./layout-routing.module";

import { LayoutComponent } from "./layout.component";
import { ProfileComponent } from "./profile/profile.component";
import { ToolbarComponent } from "./nav/toolbar/toolbar.component";
import { SidenavListComponent } from "./nav/sidebar/sidebar.component";
import { UploadDocumentsComponent } from "./upload-documents/upload-documents.component";
import { CallbackComponent } from "./callback/callback.component";

@NgModule({
  imports: [LayoutRoutingModule, SharedModule],
  declarations: [
    ProfileComponent,
    CallbackComponent,
    LayoutComponent,
    ToolbarComponent,
    SidenavListComponent,
    UploadDocumentsComponent,
  ],
})
export class LayoutModule {}
