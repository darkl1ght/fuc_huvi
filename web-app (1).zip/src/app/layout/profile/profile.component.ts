import { Component, OnInit } from "@angular/core";
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  UntypedFormControl,
  Validators,
  FormGroupDirective,
  NgForm,
} from "@angular/forms";
import { Subscription } from "rxjs";
import { MatDialog } from "@angular/material/dialog";
import { User, UserService, SnackbarService } from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { ErrorStateMatcher } from "@angular/material/core";

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(
    control: UntypedFormControl | null,
    form: FormGroupDirective | NgForm | null
  ): boolean {
    const invalidCtrl = !!(control && control.invalid && control.parent.dirty);
    const invalidParent = !!(
      control &&
      control.parent &&
      control.parent.invalid &&
      control.parent.dirty
    );

    return invalidCtrl || invalidParent;
  }
}

@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.scss"],
})
export class ProfileComponent implements OnInit {
  profileForm: UntypedFormGroup;
  resetPasswordForm: UntypedFormGroup;
  post: any = "";
  formSubmitted: boolean = false;
  user: User = {} as User;
  isValidPassword: boolean = true;
  subscription: Subscription;

  formSubmitAttempt: boolean = false;
  errors = {};
  wasFormChanged = false;
  randomPassword: string;
  matcher = new MyErrorStateMatcher();
  passwordChars: string =
    "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789";
  specialChars: string = "@$#!%*^?&";

  constructor(
    private formBuilder: UntypedFormBuilder,
    private userSvc: UserService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.createForm();
    this.setUserProfile();
  }

  createForm() {
    this.profileForm = this.formBuilder.group({
      email: [{ value: "", disabled: true }],
      firstName: [null, Validators.required],
      lastName: [null, Validators.required],
      contactNumber: null,
      language: null,
    });

    this.resetPasswordForm = this.formBuilder.group(
      {
        password: new UntypedFormControl(
          "",
          Validators.compose([
            Validators.required,
            Validators.minLength(8),
            Validators.maxLength(30),
            this.checkPassword,
          ])
        ),
        confirmPassword: [""],
      },
      { validators: this.matchPassword }
    );
  }

  selectTab(event) {
    if (event.index === 1) {
      this.setUserPassword();
    }
  }

  setUserProfile() {
    this.user = this.userSvc.getCurrentUser();
    if (this.user && this.user.email) {
      this.profileForm.patchValue({
        email: this.user.email,
        firstName: this.user.firstName,
        lastName: this.user.lastName,
        contactNumber: this.user.phone,
        language: this.user.language ? this.user.language : "en",
      });
    }
  }

  setUserPassword() {
    // this.randomPassword = this.setRandomPassword(
    //   7,
    //   this.passwordChars,
    //   this.specialChars
    // );
    this.resetPasswordForm.patchValue({
      password: "",
      confirmPassword: "",
    });
  }

  setRandomPassword(length, chars, specialChars) {
    let result = "";
    for (let i = length - 1; i > 0; --i)
      result += chars[Math.floor(Math.random() * chars.length)];
    result += Math.floor(Math.random() * 10);
    result += specialChars[Math.floor(Math.random() * specialChars.length)];
    return result;
  }

  get firstName() {
    return this.profileForm.get("firstName") as UntypedFormControl;
  }

  get lastName() {
    return this.profileForm.get("lastName") as UntypedFormControl;
  }

  get contactNumber() {
    return this.profileForm.get("contactNumber") as UntypedFormControl;
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  checkPassword(control) {
    let enteredPassword = control.value;
    let passwordCheck =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$#!%*^?&])[A-Za-z\d@$#!%*^?&]+$/;
    return enteredPassword && !passwordCheck.test(enteredPassword)
      ? { requirements: true }
      : null;
  }

  get f() {
    return this.resetPasswordForm.controls;
  }

  onProfileSubmit() {
    let alert = "";
    this.formSubmitted = true;
    let email = this.user.email;
    if (this.profileForm.valid) {
      this.updateUserForProfile(this.profileForm.value, email);
      this.userSvc.update(this.user).subscribe(
        (data) => {
          data.language ? this.ts.use(data.language) : this.ts.use("en");
          alert = this.ts.instant("userProfile.messages.profileSaveSuccess");
          this.snackService.successSnackBar(alert);
          this.dialog.closeAll();
        },
        (err) => {
          alert = this.ts.instant("userProfile.messages.profileSaveFailed");
          this.snackService.errorSnackBar(alert);
          this.dialog.closeAll();
        }
      );
    }
  }

  updateUserForProfile(values: Object, email: string) {
    this.user.email = email;
    this.user.firstName = values["firstName"].trim();
    this.user.lastName = values["lastName"].trim();
    this.user.phone = values["contactNumber"]
      ? values["contactNumber"].trim()
      : "";
    this.user.language = values["language"];
    this.user.password = "";
  }

  closeDialog() {
    this.dialog.closeAll();
  }

  matchPassword(group: UntypedFormGroup) {
    const password = group.controls.password.value;
    const confirmPassword = group.controls.confirmPassword.value;
    return password === confirmPassword ? null : { notSame: true };
  }

  getPasswordError() {
    return this.resetPasswordForm.get("password").hasError("required")
      ? this.ts.instant("userProfile.messages.provideNewPassword")
      : this.resetPasswordForm.get("password").hasError("maxlength")
      ? this.ts.instant("userProfile.messages.maxLengthPassword")
      : this.resetPasswordForm.get("password").hasError("minlength")
      ? this.ts.instant("userProfile.messages.minLengthPassword")
      : this.resetPasswordForm.get("password").hasError("requirements")
      ? this.ts.instant("userProfile.messages.regexRequirement")
      : "";
  }

  onResetSubmit() {
    let alert = "";
    this.formSubmitAttempt = true;
    if (this.resetPasswordForm.valid) {
      this.updateUserPassword(this.resetPasswordForm.value);
      this.userSvc.update(this.user).subscribe(
        (data) => {
          this.user.password = "";
          alert = this.ts.instant("userProfile.messages.passwordResetSuccess");
          this.snackService.successSnackBar(alert);
          this.dialog.closeAll();
        },
        (err) => {
          alert = this.ts.instant("userProfile.messages.passwordResetFailed");
          this.snackService.errorSnackBar(alert);
          this.dialog.closeAll();
        }
      );
    }
  }

  updateUserPassword(values) {
    this.user.password = values["password"].trim();
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.resetPasswordForm.reset();
  }
}
