import { STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";
import { Component, Inject, OnInit } from "@angular/core";
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { BlobServiceClient } from "@azure/storage-blob";
import { TranslateService } from "@ngx-translate/core";
import {
  ClientData,
  Client,
  ClientService,
  Guid,
  UiService,
  ContentDataService,
  SnackbarService,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";

@Component({
  selector: "new-client",
  templateUrl: "./new-client.component.html",
  styleUrls: ["./new-client.component.scss"],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false },
    },
  ],
})
export class NewClientComponent implements OnInit {
  clientNameFG: UntypedFormGroup;
  clientAdminFG: UntypedFormGroup;

  url: any;
  savedImageBlobUrl: string;

  clientAdmin: string;
  emailPattern = /^[A-Z\d._%+-]+@[A-Z\d.-]+\.[A-Z]{2,4}$/i;
  client: Client = {} as Client;
  errors: any;
  clientId: string = "";

  // Storage tokens
  accessToken: string;
  blobReadToken: string;

  isEditClient: Boolean = false;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private clientData: ClientData,
    private clientSvc: ClientService,
    private contentDataService: ContentDataService,
    private snackService: SnackbarService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private uiSvc: UiService,
    private ts: TranslateService
  ) {}

  public ngOnInit(): void {
    this.clientNameFG = this.fb.group({
      clientName: ["", Validators.required],
    });
    this.clientAdminFG = this.fb.group({
      email: ["", [Validators.required, Validators.pattern(this.emailPattern)]],
      firstName: [
        "",
        [
          Validators.required,
          Validators.pattern("^[a-zA-ZÀ-ÿ][a-zA-ZÀ-ÿ'\\-,. ]*$"),
        ],
      ],
      lastName: [
        "",
        [
          Validators.required,
          Validators.pattern("^[a-zA-ZÀ-ÿ][a-zA-ZÀ-ÿ'\\-,. ]*$"),
        ],
      ],
    });

    if (this.clientData) {
      this.accessToken = this.clientData.token;
      this.blobReadToken = this.clientData.blobReadToken;
      this.isEditClient = this.clientData.isClientUpdate;
      if (this.clientData.client) {
        this.setClientData(this.clientData.client);
      }
    }
  }

  get clientNameForm() {
    return this.clientNameFG.controls;
  }

  get clientAdminForm() {
    return this.clientAdminFG.controls;
  }

  setClientData(client: Client) {
    this.clientAdminFG.patchValue({
      email: client.email,
      firstName: client.firstName,
      lastName: client.lastName,
    });
    this.clientId = client.clientId;
    this.clientNameFG.patchValue({
      clientName: client.clientName,
    });

    if (client.blobContentId)
      this.savedImageBlobUrl =
        this.config.mediaBlobUrl +
        client.blobContentId +
        "?" +
        this.blobReadToken;
  }

  onSelectFile(event) {
    try {
      if (event.target.files && event.target.files[0]) {
        let extn = event.target.files[0].name.split(".").pop();

        if (this.isImage(extn)) {
          this.uiSvc.show();
          const reader = new FileReader();
          reader.readAsDataURL(event.target.files[0]); // read file as data url
          reader.onload = (event) => {
            this.url = event.target.result;
            this.uiSvc.hide();
          };
        }
      }
    } catch (error) {
      this.uiSvc.hide();
    }
  }

  saveClient() {
    let alert = "";
    if (this.clientNameFG.valid && this.clientAdminFG.valid) {
      const clientNameFormValue = this.clientNameFG.value;
      const clientAdminFormValue = this.clientAdminFG.value;
      this.updateClientDetail(clientNameFormValue, clientAdminFormValue);

      this.clientSvc.saveClient(this.client).subscribe(
        (client) => {
          this.saveClientLogo(this.client.blobContentId);

          if (!this.client.clientId) {
            this.contentDataService
              .createConstraCompany({
                companyId: client.clientId,
                companyName: client.clientName,
                storageType: "s3",
              })
              .subscribe({
                next: () => {
                  alert = this.ts.instant("client.newClient.messages.created");
                  this.snackService.successSnackBar(alert);
                  this.dialog.closeAll();
                },
              });
          } else {
            alert = this.ts.instant("client.newClient.messages.created");
            this.snackService.successSnackBar(alert);
            this.dialog.closeAll();
          }
        },
        (err) => {
          if (err.status == "400" || err.status == "409") {
            alert = this.ts.instant("client.newClient.messages.alreadyExist");
          } else {
            alert = this.ts.instant("client.newClient.messages.failed");
          }

          this.errors = err;
          this.snackService.errorSnackBar(alert);
        }
      );
    } else {
      alert = this.ts.instant("client.newClient.messages.required");
      this.snackService.errorSnackBar(alert);
    }
  }

  saveClientLogo(fileName) {
    if (this.url) this.uploadThumbnail(this.url, fileName);
  }

  dataURLtoFile(dataurl, filename) {
    const arr = dataurl.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);

    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  async uploadThumbnail(dataUrl, fileName) {
    let fileData;
    try {
      fileData = this.dataURLtoFile(dataUrl, fileName);

      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.accessToken
      );
      const containerClient = blobServiceClient.getContainerClient(
        this.config.mediaContainer
      );
      const promises = [];
      const blockBlobClient = containerClient.getBlockBlobClient(fileName);
      promises.push(blockBlobClient.uploadBrowserData(fileData));
      await Promise.all(promises);
    } catch (error) {}
  }

  updateClientDetail(ClientName, clientAdmin) {
    this.client.clientId = this.clientId;
    this.client.clientName = ClientName["clientName"].trim();
    this.client.email = clientAdmin["email"].trim().toLowerCase();
    this.client.firstName = clientAdmin["firstName"].trim();
    this.client.lastName = clientAdmin["lastName"].trim();
    this.client.isActive = true;
    if (this.url) {
      this.client.blobContentId = `${Guid.newGuid()}.jpeg`;
    }
  }

  isImage(ext) {
    switch (ext.toLowerCase()) {
      case "jpg":
      case "jpeg":
      case "gif":
      case "bmp":
      case "tif":
      case "tiff":
      case "png":
        //etc
        return true;
    }
    return false;
  }

  closeDialog() {
    this.dialog.closeAll();
  }
}
