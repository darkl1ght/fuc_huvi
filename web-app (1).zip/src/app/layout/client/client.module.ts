import { NgModule } from "@angular/core";
import { SharedModule } from "src/app/shared";
import { ClientRoutingModule } from "./client-routing.module";
import { ClientComponent } from "./client.component";
import { NewClientComponent } from "./new/new-client.component";

@NgModule({
  imports: [ClientRoutingModule, SharedModule],
  declarations: [ClientComponent, NewClientComponent],
})
export class ClientModule {}
