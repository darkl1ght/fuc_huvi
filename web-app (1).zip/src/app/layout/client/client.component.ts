import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { Observable, throwError } from "rxjs";
import { catchError, finalize, map } from "rxjs/operators";
import {
  Client,
  ClientService,
  LocalStorageService,
  SharedService,
  StorageService,
  UiService,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "../components/confirm-dialog/confirm-dialog.component";
import { NewClientComponent } from "./new/new-client.component";

@Component({
  selector: "app-client",
  templateUrl: "./client.component.html",
  styleUrls: ["./client.component.scss"],
})
export class ClientComponent implements OnInit {
  dataSource: any;
  searchText = "";
  value = "";
  dateObj = new Date();
  source: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  obs: Client[] = [];
  errors = {};
  clientDS: Observable<any>;
  accessToken: string;
  thumbnailContainer: string;
  mediaContainer: string;
  mediaBlobUrl: string;
  readToken: string;
  isShowingClientInput: boolean = false;
  isLoaded: boolean = false;

  constructor(
    public clientSvc: ClientService,
    public dialog: MatDialog,
    private uiSvc: UiService,
    private storageSvc: StorageService,
    private localStorage: LocalStorageService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private router: Router,
    private dataSvc: SharedService,
    private ts: TranslateService
  ) {}

  ngOnInit() {
    this.mediaBlobUrl = this.config.mediaBlobUrl;
    this.mediaContainer = this.config.mediaContainer;
    this.dataSvc.setProjectId("");
    this.localStorage.removeProjectId();
    this.localStorage.removeLibraryFolderId();
    this.thumbnailContainer = this.config.imageThumbnailContainer;
    this.getClientData();
    this.getAccessToken();
    this.getReadTokenAndData();
  }

  navigateToProject(client: Client) {
    this.localStorage.setClientId(client.clientId);
    this.router.navigate(["/project"]);
  }

  waitAndReload(event: any, blobContentId: string) {
    const originalSrc = event.target.src;
    if (
      parseInt(event.target.getAttribute("data-retry"), 3) !==
      parseInt(event.target.getAttribute("data-max-retry"), 3)
    ) {
      event.target.setAttribute(
        "data-retry",
        parseInt(event.target.getAttribute("data-retry"), 3) + 1
      );
      event.target.src = "assets/images/placeholder.gif";
      setTimeout(function () {
        event.target.src = originalSrc;
      }, 6000);
    } else {
      event.target.src =
        this.mediaBlobUrl + blobContentId + "?" + this.readToken;
    }
  }

  getClientData() {
    this.uiSvc.show();
    this.source = this.clientSvc
      .getClients()
      .pipe(
        map(
          (data) => {
            this.obs = data.clients;
            this.loadTable();
            this.isLoaded = true;
            this.uiSvc.hide();
          },
          (_) => {
            this.uiSvc.hide();
          }
        ),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  loadTable() {
    this.dataSource = new MatTableDataSource(this.obs);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.clientDS = this.dataSource.connect();
  }

  getAccessToken() {
    let container = this.config.mediaContainer;
    this.storageSvc.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getReadTokenAndData() {
    this.storageSvc.getReadToken(this.mediaContainer).subscribe(
      (data) => {
        this.readToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  toggleClientsFilterInput() {
    this.isShowingClientInput = !this.isShowingClientInput;
  }

  deleteClientConfirmation(c: Client) {
    const message = this.ts.instant("dialog.messages.removeClient");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      if (dialogResult) {
        this.clientSvc.removeClient(c.clientId).subscribe(
          (data) => {
            this.getClientData();
          },
          (err) => {
            this.errors = err;
          }
        );
      }
    });
  }

  updateDialog(c: Client) {
    const dialogRef = this.dialog.open(NewClientComponent, {
      width: "60%",
      disableClose: true,
      data: {
        client: c,
        token: this.accessToken,
        blobReadToken: this.readToken,
        isClientUpdate: true,
      },
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getClientData();
    });
  }

  ngOnDestroy() {
    if (this.source) {
      this.source = null;
    }
  }

  onNewClient(): void {
    const dialogRef = this.dialog.open(NewClientComponent, {
      width: "60%",
      disableClose: true,
      data: { token: this.accessToken, blobReadToken: this.readToken },
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getClientData();
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  private handleError(error: any) {
    return throwError(error);
  }
}
