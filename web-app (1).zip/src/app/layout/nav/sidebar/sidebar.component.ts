import { Component, OnInit, EventEmitter, Output } from "@angular/core";
import { Router } from "@angular/router";
import { UserService, ContentDataService } from "src/app/core";

@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.scss"],
})
export class SidenavListComponent implements OnInit {
  @Output() closeSideNav = new EventEmitter();

  constructor(
    private userService: UserService,
    private contentDataService: ContentDataService,
    private router: Router
  ) {}

  onToggleClose() {
    this.closeSideNav.emit();
  }

  ngOnInit() {}

  gotoClients() {
    this.router.navigate(["/client"]);
    this.onToggleClose();
  }

  gotoProjects() {
    this.router.navigate(["/project"]);
    this.onToggleClose();
  }

  logoutUser() {
    this.contentDataService.onLogout();
    this.userService.purgeAuth();
    this.router.navigate(["/login"]);
  }

  gotoReports() {
    this.router.navigate(["/reports"]);
    this.onToggleClose();
  }
}
