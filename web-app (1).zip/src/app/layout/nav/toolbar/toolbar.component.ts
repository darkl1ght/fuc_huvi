import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  OnChanges,
  Output,
} from "@angular/core";
import {
  LocalStorageService,
  Project,
  ProjectService,
  SharedService,
  User,
  UserService,
  ContentDataService,
  ClientService,
  Client,
  IntegrationService,
  ShareService,
  AccessControlService,
  AccessMappingLocalStorage,
} from "src/app/core";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { ProfileComponent } from "../../profile/profile.component";
import { MatDialog } from "@angular/material/dialog";
import {
  catchError,
  filter,
  finalize,
  map,
  mergeMap,
  startWith,
} from "rxjs/operators";
import { throwError } from "rxjs/internal/observable/throwError";
import moment from "moment";
import { forkJoin, Subscription } from "rxjs";
import isEmpty from "lodash/isEmpty";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "app-toolbar",
  templateUrl: "./toolbar.component.html",
  styleUrls: ["./toolbar.component.scss"],
})
export class ToolbarComponent implements OnInit, OnChanges, OnDestroy {
  @Output() SideNavToggle = new EventEmitter();

  user: User = {} as User;
  errors: Object = {};
  isSubmitting = false;
  projectId: string;
  projects: Project[] = [];
  source: any;
  clientId: string = "";
  href: string = "";
  isCustomLogo: boolean = false;
  client: Client;
  hideClientTitle: boolean = false;
  hideProcoreLogin: boolean = false;
  lat: number;
  lng: number;
  location: string = "";
  refreshToolbarSubscription: Subscription;
  contractExpiryMsg: string = "";

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private userService: UserService,
    private projectSvc: ProjectService,
    private accessControlService: AccessControlService,
    private localStorage: LocalStorageService,
    private integrationService: IntegrationService,
    private shareService: ShareService,
    private ts: TranslateService,
    private dataSvc: SharedService,
    private clientService: ClientService,
    private contentDataService: ContentDataService
  ) {}

  ngOnInit() {
    this.checkClientLogo();
    this.initializeProjectData();
    this.refreshToolbarSubscription =
      this.shareService.refreshToolbar$.subscribe({
        next: (isRefresh) => {
          if (!!isRefresh) this.initializeProjectData(true);
        },
      });
    this.dataSvc.getProjectId().subscribe((pId) => {
      if (!pId) {
        this.initializeProjectData();
        this.projectId = pId;
        this.contractExpiryMsg = "";
      }
      this.projectId = pId;

      if (this.projectId) {
        this.getProjectLocation();
      }
    });
    // TODO
    this.user = this.userService.getCurrentUser();

    this.listenForRouteChange();

    window.onbeforeunload = () => this.ngOnDestroy();
  }

  ngOnChanges(): void {
    if (this.projectId) {
      this.getProjectLocation();
    }
  }

  procoreLogin() {
    this.integrationService.procoreLogin();
  }

  listenForRouteChange() {
    this.source = this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        startWith(this.router)
      )
      .subscribe((event: NavigationEnd) => {
        // there will be first router.url - and next - router events
        if (event.url.includes("/client")) {
          this.hideClientTitle = true;
          this.hideProcoreLogin = true;
        } else {
          this.hideClientTitle = false;
          this.hideProcoreLogin = false;
        }
      });
  }

  checkClientLogo() {
    this.projectSvc
      .customLogoCheck()
      .pipe(
        map((response) => {
          this.isCustomLogo = response.isCustomLogo;
        })
      )
      .subscribe();
  }

  openSidenav() {
    this.SideNavToggle.emit();
  }

  initializeProjectData(isShareableRefresh = false) {
    this.source = this.userService.currentUser.subscribe((user) => {
      if (!isEmpty(user)) {
        this.user = user;
        if (user.isAdmin) {
          this.clientId = this.localStorage.getClientId();
          this.getProjectsByClientId(this.clientId);
        } else {
          if (!isShareableRefresh) {
            this.hideClientTitle = true;
            this.getProjectData();
          } else {
            this.hideClientTitle = false;
            this.projectId = this.localStorage.getProjectId();
            this.getProjectLocation();
          }
        }
      }
    });
  }

  getProjectsByClientId(clientId: string) {
    let projectsObservable = this.projectSvc.getProjectsByClientId(clientId);
    let clientDetailsObservable = this.clientService.getClient(clientId);

    this.source = forkJoin([projectsObservable, clientDetailsObservable])
      .pipe(
        map((results) => {
          this.projects = results[0].projects;
          this.client = results[1].client;
        }),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  getProjectData() {
    this.projectSvc
      .getProjects()
      .pipe(
        mergeMap((data) => {
          this.projects = data.projects;
          return this.clientService.getClient(this.projects[0].clientId);
        })
      )
      .subscribe(
        (data) => {
          this.client = data.client;
        },
        (error) => {
          catchError(this.handleError);
        }
      );
  }

  getProjectLocation() {
    const currentProj = this.projects.filter(
      (project) => project.projectId == this.projectId
    );
    if (currentProj && currentProj.length > 0) {
      this.lat = currentProj[0].lat;
      this.lng = currentProj[0].lng;
      this.location = currentProj[0].location;
      this.setContractExpiryMessage(
        currentProj[0].isCompleted,
        currentProj[0].contractEndDate
      );
      this.localStorage.setClientId(currentProj[0].clientId);
      this.clientService.getClient(currentProj[0].clientId).subscribe(
        (data) => {
          this.client = data.client;
        },
        (error) => {
          catchError(this.handleError);
        }
      );
    } else {
      this.projectSvc.get(this.projectId).subscribe(
        (data) => {
          this.lat = data.lat;
          this.lng = data.lng;
          this.location = data.location;
          this.setContractExpiryMessage(data.isCompleted, data.contractEndDate);
          this.clientService.getClient(data.clientId).subscribe(
            (data) => {
              this.client = data.client;
              this.localStorage.setClientId(this.client?.clientId);
            },
            (error) => {
              catchError(this.handleError);
            }
          );
        },
        (error) => {
          catchError(this.handleError);
        }
      );
    }
  }

  setContractExpiryMessage(
    isCompleted: boolean | string, //The 2 calls are sending inputs in 2 different formats
    contractEndDate: Date
  ) {
    let isCompletedTemp = false;
    if (typeof isCompleted === "boolean") {
      isCompletedTemp = isCompleted;
    } else {
      isCompletedTemp = isCompleted === "Completed";
    }
    if (!isCompletedTemp && contractEndDate) {
      const contractEndDateTemp = moment(contractEndDate);
      const today = moment().startOf("day");
      const dayDiff = contractEndDateTemp.diff(today, "day");
      if (dayDiff < 0) {
        //Expired
        this.contractExpiryMsg = this.contractExpiryMsg = this.ts.instant(
          "navbar.toolbar.contractExpired"
        );
      } else if (dayDiff === 0) {
        //Expiring today
        this.contractExpiryMsg = this.contractExpiryMsg = this.ts.instant(
          "navbar.toolbar.contractExpiringToday"
        );
      } else if (dayDiff === 1) {
        //Expiring in one day
        this.contractExpiryMsg = this.contractExpiryMsg = this.ts.instant(
          "navbar.toolbar.contractExpiringInOneDay"
        );
      } else if (dayDiff <= 30) {
        //Expiring in N days
        this.contractExpiryMsg = this.ts.instant(
          "navbar.toolbar.contractExpiringInNDays",
          {
            count: dayDiff,
          }
        );
      } else {
        // >30 days
        this.contractExpiryMsg = "";
      }
    } else {
      this.contractExpiryMsg = "";
    }
  }

  changeProject(e) {
    let role: string = "";
    this.projectId = e.value;
    this.localStorage.removeLibraryFolderId();
    this.getProjectLocation();
    const currentProject: any = this.projects.find(
      (projects) => projects.projectId === e.value
    );

    if (!!currentProject) {
      this.localStorage.setProjectId(e.value);
    }

    if (this.user.isAdmin) {
      role = "Super Admin";
    } else {
      role = this.projects
        .find((item) => item.projectId == this.projectId)
        .users.find(
          (item) => item.email.toLowerCase() == this.user.email.toLowerCase()
        ).role.code;
    }
    this.accessControlService.getAccessMapping(role).subscribe({
      next: (data) => {
        const dataLocalStorage: AccessMappingLocalStorage = {
          ...data,
          projectId: this.projectId,
        };
        this.localStorage.setAccessMapping(dataLocalStorage);

        if (
          currentProject.aerialTours?.length == 0 &&
          currentProject.interiors.length > 0
        ) {
          this.router.navigate([`/detail/${e.value}/interior`]);
        } else {
          this.router.navigate(["/detail", e.value], {
            relativeTo: this.route.parent,
          });
        }
      },
    });
  }

  logoutUser() {
    this.contentDataService.onLogout();
    this.userService.purgeAuth();
    this.router.navigate(["/login"]);
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(ProfileComponent, {
      width: "70%",
      disableClose: true,
      data: {},
    });
  }

  ngOnDestroy() {
    this.refreshToolbarSubscription.unsubscribe();
    if (this.source) {
      this.source = null;
    }
  }

  private handleError(error: any) {
    return throwError(error);
  }

  userSettings() {
    this.openDialog();
  }
}
