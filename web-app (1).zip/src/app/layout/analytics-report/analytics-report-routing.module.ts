import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AnalyticsReportComponent } from "./analytics-report.component";

const routes: Routes = [
  {
    path: "",
    component: AnalyticsReportComponent,
    children: [
      {
        path: "",
        redirectTo: "capturestats",
        pathMatch: "full",
      },
      {
        pathMatch: "prefix",
        path: "capturestats",
        loadChildren: () =>
          import(
            "./components/capture-statistics/capture-statistics.module"
          ).then((m) => m.CaptureStatisticsModule),
      },
      {
        pathMatch: "prefix",
        path: "adoptionstats",
        loadChildren: () =>
          import(
            "./components/adoption-statistics/adoption-statistics.module"
          ).then((m) => m.AdoptionStatisticsModule),
      },
      {
        pathMatch: "prefix",
        path: "capturemetrics",
        loadChildren: () =>
          import("./components/capture-metrics/capture-metrics.module").then(
            (m) => m.CaptureMetricsModule
          ),
      },
      {
        pathMatch: "prefix",
        path: "contractdates",
        loadChildren: () =>
          import("./components/contract-dates/contract-dates.module").then(
            (m) => m.ContractDatesModule
          ),
      },
    ],
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AnalyticsReportRoutingModule {}
