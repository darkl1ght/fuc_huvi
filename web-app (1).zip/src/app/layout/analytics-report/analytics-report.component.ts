import { Component } from "@angular/core";

@Component({
  selector: "app-analytics-report",
  templateUrl: "./analytics-report.component.html",
  styleUrls: ["./analytics-report.component.scss"],
})
export class AnalyticsReportComponent {
  ngOnInit() {}
}
