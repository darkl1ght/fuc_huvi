import { Component } from '@angular/core';

@Component({
  selector: 'app-adoption-statistics',
  templateUrl: './adoption-statistics.component.html',
  styleUrls: ['./adoption-statistics.component.scss']
})
export class AdoptionStatisticsComponent {

}
