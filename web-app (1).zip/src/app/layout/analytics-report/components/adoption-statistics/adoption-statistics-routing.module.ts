import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AdoptionStatisticsComponent } from "./adoption-statistics.component";
import { AdoptionListComponent } from "./list/adoption-list.component";

const routes: Routes = [
  {
    path: "",
    component: AdoptionStatisticsComponent,
    children: [
      {
        path: "",
        redirectTo: "list",
        pathMatch: "full",
      },
      {
        path: "list",
        component: AdoptionListComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdoptionStatisticsRoutingModule {}
