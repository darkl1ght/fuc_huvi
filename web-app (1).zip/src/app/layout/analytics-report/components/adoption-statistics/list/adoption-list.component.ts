import { Component, ViewChild } from "@angular/core";
import { UntypedFormBuilder, UntypedFormGroup } from "@angular/forms";
import { MatOption } from "@angular/material/core";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { MatSelect } from "@angular/material/select";
import { Project, Reports, UiService, User, UserService } from "src/app/core";
import { ReportService } from "src/app/core/services/reports.service";
import { Chart, ChartConfiguration } from "chart.js";
import ChartDataLabels from "chartjs-plugin-datalabels";

@Component({
  selector: "app-adoption-list",
  templateUrl: "./adoption-list.component.html",
  styleUrls: ["./adoption-list.component.scss"],
})
export class AdoptionListComponent {
  @ViewChild("select") select: MatSelect;
  @ViewChild("filterProjectForm") filterProjectForm;
  dataSource: any;
  filteredProjects: Record<string, string>[] = [];
  user: User;
  errors = {};
  projects: Project[] = [];
  filterProjects: UntypedFormGroup;
  formSubmitAttempt: boolean = false;
  wasFormChanged = false;
  allSelected = false;
  createdDateFilterRangeStartDate: Date;
  public chart: Chart;
  chartPlugin = ChartDataLabels;
  chartLegend: boolean = true;
  snagCharts = [];
  wirCharts = [];
  fieldIssuesCharts = [];
  showSnagCharts: boolean = false;
  showWirCharts: boolean = false;
  showFieldIssuesChart: boolean = false;
  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
      x: {
        ticks: {
          autoSkip: true,
          callback: function (value, index) {
            return this.getLabelForValue(index).toString().slice(0, 28);
          },
        },
      },
    },
    layout: {
      padding: {
        top: 30, // Adjust the top padding to accommodate the label
      },
    },
    plugins: {
      legend: {
        position: "right",
        align: "start",
      },
      datalabels: {
        formatter: function (value, context) {
          if (value > 0) {
            value = value.toString();
            value = value.split(/(?=(?:...)*$)/);
            value = value.join(",");
            return value;
          } else {
            value = "";
            return value;
          }
        },
        anchor: "end",
        align: "end",
        labels: {
          value: {
            color: "black",
          },
        },
      },
    },
  };

  constructor(
    private userService: UserService,
    private uiSvc: UiService,
    private _formBuilder: UntypedFormBuilder,
    private reportService: ReportService
  ) {
    this.filterProjects = this._formBuilder.group({
      projects: ["", ""],
      startDate: ["", ""],
      endDate: ["", ""],
    });
  }

  ngOnInit(): void {
    this.user = this.userService.getCurrentUser();
    this.getProjectsByUser();
  }

  get f() {
    return this.filterProjects.controls;
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  getProjectsByUser() {
    this.uiSvc.show();
    this.reportService.getProjectsByUser().subscribe(
      (data) => {
        this.projects = data;
        this.uiSvc.hide();
      },
      (err) => {
        this.uiSvc.hide();
        this.errors = err;
      }
    );
  }

  filterCreatedDateRangeStartChanged(e: MatDatepickerInputEvent<Date>) {
    this.createdDateFilterRangeStartDate = e.value;
  }

  filterCreatedDateRangeEndChanged(e: MatDatepickerInputEvent<Date>) {
    this.createdDateFilterRangeStartDate = e.value;
  }

  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  filterApply() {
    this.formSubmitAttempt = true;
    if (this.filterProjects.valid) {
      this.submitData();
    }
  }

  public bar = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#4E9117",
        borderColor: "#4E9117",
        fill: false,
        data: [],
        hoverBackgroundColor: "#4E9117",
        hoverBorderColor: "#4E9117",
      },
      {
        label: "",
        backgroundColor: "#FED825",
        borderColor: "#FED825",
        fill: false,
        data: [],
        hoverBackgroundColor: "#FED825",
        hoverBorderColor: "#FED825",
      },
      {
        label: "",
        backgroundColor: "#F42125",
        borderColor: "#F42125",
        fill: false,
        data: [],
        hoverBackgroundColor: "#F42125",
        hoverBorderColor: "#F42125",
      },
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        hoverBackgroundColor: "#42A5F5",
        hoverBorderColor: "#1E88E5",
      },
    ],
  };

  public bars = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#4E9117",
        borderColor: "#4E9117",
        fill: false,
        data: [],
        hoverBackgroundColor: "#4E9117",
        hoverBorderColor: "#4E9117",
      },

      {
        label: "",
        backgroundColor: "#FED825",
        borderColor: "#FED825",
        fill: false,
        data: [],
        hoverBackgroundColor: "#FED825",
        hoverBorderColor: "#FED825",
      },
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        hoverBackgroundColor: "#42A5F5",
        hoverBorderColor: "#1E88E5",
      },
    ],
  };

  submitData() {
    this.uiSvc.show();
    this.snagCharts = [];
    this.wirCharts = [];
    this.fieldIssuesCharts = [];
    const result = this.filterProjects.value;
    let payload: Reports;
    payload = {
      projectIds: result.projects,
      startDate: result.startDate,
      endDate: result.endDate,
    };
    this.reportService.fetchPunchLists(payload).subscribe({
      next: (data) => {
        for (let key of Object.keys(data)) {
          let barChart = {
            chartType: "bar",
            chartName: this.toCamelCase(key) + " " + "Wise",
            data: null,
          };
          let chart = structuredClone(this.bar);
          chart.labels = data[key].labels;
          chart.datasets[0].data = data[key].accepted;
          chart.datasets[0].label = "Accepted";
          chart.datasets[1].data = data[key].conditionallyAccepted;
          chart.datasets[1].label = "Conditionally Accepted";
          chart.datasets[2].data = data[key].notAccepted;
          chart.datasets[2].label = "Rejected";
          chart.datasets[3].data = data[key].pending;
          chart.datasets[3].label = "Pending";
          barChart.data = chart;
          this.snagCharts.push(barChart);
        }
        this.showSnagCharts =
          this.snagCharts.find((item) => item.chartName === "Project Wise")
            ?.data?.labels?.length > 0;
        this.uiSvc.hide();
      },
      error: (err) => {
        this.errors = err;
        this.uiSvc.hide();
      },
    });
    this.reportService.fetchWirs(payload).subscribe({
      next: (data) => {
        for (let key of Object.keys(data)) {
          let barChart = {
            chartType: "bar",
            chartName: this.toCamelCase(key) + " " + "Wise",
            data: null,
          };
          let chart = structuredClone(this.bars);
          chart.labels = data[key].labels;
          chart.datasets[0].data = data[key].approved;
          chart.datasets[0].label = "Approved";
          chart.datasets[1].data = data[key].new;
          chart.datasets[1].label = "New";
          chart.datasets[2].data = data[key].pending;
          chart.datasets[2].label = "Pending";
          barChart.data = chart;
          this.wirCharts.push(barChart);
        }
        this.showWirCharts =
          this.wirCharts.find((item) => item.chartName === "Project Wise")?.data
            ?.labels?.length > 0;
        this.uiSvc.hide();
      },
      error: (err) => {
        this.errors = err;
        this.uiSvc.hide();
      },
    });
    this.reportService.fetchFieldIsuues(payload).subscribe({
      next: (data) => {
        for (let key of Object.keys(data)) {
          let barChart = {
            chartType: "bar",
            chartName: this.toCamelCase(key) + " " + "Wise",
            data: null,
          };
          let chart = structuredClone(this.bar);
          chart.labels = data[key].labels;
          chart.datasets[0].data = data[key].verified;
          chart.datasets[0].label = "Verified";
          chart.datasets[1].data = data[key].archived;
          chart.datasets[1].label = "Archived";
          chart.datasets[2].data = data[key].open;
          chart.datasets[2].label = "Open";
          chart.datasets[3].data = data[key].resolved;
          chart.datasets[3].label = "Resolved";
          barChart.data = chart;
          this.fieldIssuesCharts.push(barChart);
        }
        this.showFieldIssuesChart =
          this.fieldIssuesCharts.find(
            (item) => item.chartName === "Project Wise"
          )?.data?.labels?.length > 0;
        this.uiSvc.hide();
      },
      error: (err) => {
        this.errors = err;
        this.uiSvc.hide();
      },
    });
  }

  toCamelCase(str) {
    return str
      .replace(/(?:^\w|[A-Z]|\b\w)/g, function (word, index) {
        return index === 0 ? word.toUpperCase() : " " + word.toUpperCase();
      })
      .replace(/\s+/g, "");
  }
}
