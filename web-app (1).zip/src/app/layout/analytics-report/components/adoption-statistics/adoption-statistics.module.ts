import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "src/app/shared";
import { AdoptionStatisticsRoutingModule } from "./adoption-statistics-routing.module";
import { AdoptionStatisticsComponent } from "./adoption-statistics.component";
import { AdoptionListComponent } from "./list/adoption-list.component";
import { MatSelectSearchModule } from "mat-select-search";

@NgModule({
  declarations: [AdoptionStatisticsComponent, AdoptionListComponent],
  imports: [
    CommonModule,
    AdoptionStatisticsRoutingModule,
    SharedModule,
    MatSelectSearchModule,
  ],
})
export class AdoptionStatisticsModule {}
