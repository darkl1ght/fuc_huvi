import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSelect } from "@angular/material/select";
import { MatOption } from "@angular/material/core";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { Project, Reports, UiService, User, UserService } from "src/app/core";
import { UntypedFormBuilder, UntypedFormGroup } from "@angular/forms";
import { ReportService } from "src/app/core/services/reports.service";
import { Chart, ChartConfiguration } from "chart.js";
import ChartDataLabels from "chartjs-plugin-datalabels";

@Component({
  selector: "app-list",
  templateUrl: "./capture-list.component.html",
  styleUrls: ["./capture-list.component.scss"],
})
export class CaptureListComponent implements OnInit {
  @ViewChild("select") select: MatSelect;
  @ViewChild("filterProjectForm") filterProjectForm;
  allSelected = false;
  source: any;
  clientId: string = "";
  user: User;
  errors = {};
  projects: Project[] = [];
  filterProjects: UntypedFormGroup;
  formSubmitAttempt: boolean = false;
  wasFormChanged = false;
  public chart: Chart;
  filteredProjects: Record<string, string>[] = [];
  chartLegend: boolean = true;
  aerialCharts = [];
  virtualCharts = [];
  showAerialCharts: boolean = false;
  showVirtualCharts: boolean = false;
  createdDateFilterRangeStartDate: Date;
  chartPlugin = ChartDataLabels;
  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
        title: {
          display: true,
          text: "# of captures",
          font: {
            size: 12,
            family: "Poppins",
          },
        },
      },
      x: {
        ticks: {
          autoSkip: true,
          callback: function (value, index) {
            return this.getLabelForValue(index).toString().slice(0, 28);
          },
        },
      },
    },
    layout: {
      padding: {
        top: 30, // Adjust the top padding to accommodate the label
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      datalabels: {
        anchor: "end",
        align: "end",
        labels: {
          value: {
            color: "black",
          },
        },
      },
    },
  };

  constructor(
    private userService: UserService,
    private uiSvc: UiService,
    private _formBuilder: UntypedFormBuilder,
    private reportService: ReportService
  ) {
    this.filterProjects = this._formBuilder.group({
      projects: ["", ""],
      startDate: ["", ""],
      endDate: ["", ""],
    });
  }

  ngOnInit() {
    this.getProjectsByUser();
    this.user = this.userService.getCurrentUser();
  }

  get f() {
    return this.filterProjects.controls;
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  getProjectsByUser() {
    this.uiSvc.show();
    this.reportService.getProjectsByUser().subscribe(
      (data) => {
        this.projects = data;
        this.uiSvc.hide();
      },
      (err) => {
        this.errors = err;
        this.uiSvc.hide();
      }
    );
  }

  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  filterCreatedDateRangeStartChanged(e: MatDatepickerInputEvent<Date>) {
    this.createdDateFilterRangeStartDate = e.value;
  }

  filterCreatedDateRangeEndChanged(e: MatDatepickerInputEvent<Date>) {
    this.createdDateFilterRangeStartDate = e.value;
  }

  filterApply() {
    this.formSubmitAttempt = true;
    if (this.filterProjects.valid) {
      this.submitData();
    }
  }

  submitData() {
    this.uiSvc.show();
    this.aerialCharts = [];
    this.virtualCharts = [];
    const result = this.filterProjects.value;
    let payload: Reports;
    payload = {
      projectIds: result.projects,
      startDate: result.startDate,
      endDate: result.endDate,
    };
    this.reportService.fetchAerialCaptures(payload).subscribe({
      next: (data) => {
        for (let key of Object.keys(data)) {
          let barChart = {
            chartType: "bar",
            chartName: this.toCamelCase(key) + " " + "Wise",
            data: null,
          };
          let chart = structuredClone(this.bar);
          chart.labels = data[key].labels;
          chart.datasets[0].data = data[key].values;
          barChart.data = chart;
          this.aerialCharts.push(barChart);
        }
        this.showAerialCharts =
          this.aerialCharts.find((item) => item.chartName === "Project Wise")
            ?.data?.labels?.length > 0;
        this.uiSvc.hide();
      },
      error: (err) => {
        this.errors = err;
        this.uiSvc.hide();
      },
    });
    this.reportService.fetchVirtualCaptures(payload).subscribe({
      next: (data) => {
        for (let key of Object.keys(data)) {
          let barChart = {
            chartType: "bar",
            chartName: this.toCamelCase(key) + " " + "Wise",
            data: null,
          };
          let chart = structuredClone(this.bar);
          chart.labels = data[key].labels;
          chart.datasets[0].data = data[key].values;
          barChart.data = chart;
          this.virtualCharts.push(barChart);
        }
        this.showVirtualCharts =
          this.virtualCharts.find((item) => item.chartName === "Project Wise")
            ?.data?.labels?.length > 0;
        this.uiSvc.hide();
      },
      error: (err) => {
        this.errors = err;
        this.uiSvc.hide();
      },
    });
  }

  public bar = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        hoverBackgroundColor: "#42A5F5",
        hoverBorderColor: "#1E88E5",
      },
    ],
  };

  toCamelCase(str) {
    return str
      .replace(/(?:^\w|[A-Z]|\b\w)/g, function (word, index) {
        return index === 0 ? word.toUpperCase() : " " + word.toUpperCase();
      })
      .replace(/\s+/g, "");
  }
}
