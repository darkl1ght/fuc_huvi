import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "src/app/shared";
import { CaptureStatisticsRoutingModule } from "./capture-statistics-routing.module";
import { CaptureStatisticsComponent } from "./capture-statistics.component";
import { CaptureListComponent } from "./list/capture-list.component";
import { MatSelectSearchModule } from "mat-select-search";

@NgModule({
  declarations: [CaptureStatisticsComponent, CaptureListComponent],
  imports: [
    CommonModule,
    CaptureStatisticsRoutingModule,
    SharedModule,
    MatSelectSearchModule,
  ],
})
export class CaptureStatisticsModule {}
