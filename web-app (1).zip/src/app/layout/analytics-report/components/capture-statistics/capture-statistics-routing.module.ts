import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CaptureStatisticsComponent } from "./capture-statistics.component";
import { CaptureListComponent } from "./list/capture-list.component";

const routes: Routes = [
  {
    path: "",
    component: CaptureStatisticsComponent,
    children: [
      {
        path: "",
        redirectTo: "list",
        pathMatch: "full",
      },
      {
        path: "list",
        component: CaptureListComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CaptureStatisticsRoutingModule {}
