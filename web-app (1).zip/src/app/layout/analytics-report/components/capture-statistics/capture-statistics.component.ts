import { Component } from '@angular/core';

@Component({
  selector: 'app-capture-statistics',
  templateUrl: './capture-statistics.component.html',
  styleUrls: ['./capture-statistics.component.scss']
})
export class CaptureStatisticsComponent {

}
