import { Component } from '@angular/core';

@Component({
  selector: 'app-contract-dates',
  templateUrl: './contract-dates.component.html',
  styleUrls: ['./contract-dates.component.scss']
})
export class ContractDatesComponent {

}
