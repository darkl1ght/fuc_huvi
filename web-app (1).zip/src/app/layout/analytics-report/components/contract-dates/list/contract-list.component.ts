import { Component, ViewChild } from "@angular/core";
import { UntypedFormBuilder, UntypedFormGroup } from "@angular/forms";
import { MatOption } from "@angular/material/core";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { MatPaginator } from "@angular/material/paginator";
import { MatSelect } from "@angular/material/select";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import * as moment from "moment-timezone";
import {
  Client,
  ContractDates,
  ContractReport,
  UiService,
  User,
  UserService,
} from "src/app/core";
import { ReportService } from "src/app/core/services/reports.service";

@Component({
  selector: "app-contract-list",
  templateUrl: "./contract-list.component.html",
  styleUrls: ["./contract-list.component.scss"],
})
export class ContractListComponent {
  @ViewChild("select") select: MatSelect;
  @ViewChild("filterClientsForm") filterClientsForm;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  dataSource: any;
  filteredClients: Record<string, string>[] = [];
  user: User;
  errors = {};
  contractList: ContractDates[] = [];
  filterClients: UntypedFormGroup;
  formSubmitAttempt: boolean = false;
  wasFormChanged = false;
  clients: Client[] = [];
  allSelected = false;
  displayedColumns: string[] = [
    "client",
    "project",
    "contractDate",
    "contractStatus",
  ];
  createdDateFilterRangeStartDate: Date;

  constructor(
    private userService: UserService,
    private uiSvc: UiService,
    private _formBuilder: UntypedFormBuilder,
    private reportService: ReportService
  ) {
    this.filterClients = this._formBuilder.group({
      clients: ["", ""],
      startDate: ["", ""],
      endDate: ["", ""],
    });
  }

  ngOnInit(): void {
    this.getClientsByUser();
    this.user = this.userService.getCurrentUser();
  }

  get f() {
    return this.filterClients.controls;
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  getClientsByUser() {
    this.uiSvc.show();
    this.reportService.getClientsByUser().subscribe(
      (data) => {
        this.clients = data;
        this.uiSvc.hide();
      },
      (err) => {
        this.errors = err;
        this.uiSvc.hide();
      }
    );
  }

  filterCreatedDateRangeStartChanged(e: MatDatepickerInputEvent<Date>) {
    this.createdDateFilterRangeStartDate = e.value;
  }

  filterCreatedDateRangeEndChanged(e: MatDatepickerInputEvent<Date>) {
    this.createdDateFilterRangeStartDate = e.value;
  }

  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  filterApply() {
    this.formSubmitAttempt = true;
    if (this.filterClients.valid) {
      this.submitData();
    }
  }

  submitData() {
    this.uiSvc.show();
    const result = this.filterClients.value;
    let payload: ContractReport;
    payload = {
      clientIds: result.clients,
      startDate: result.startDate,
      endDate: result.endDate,
    };
    this.reportService.fetchContractDates(payload).subscribe({
      next: (data) => {
        for (const el of data) {
          const contractEndDateTemp = moment(el.contractEndDate);
          const today = moment().startOf("day");
          const dayDiff = contractEndDateTemp.diff(today, "day");
          el.colourCode = "green";
          if (dayDiff < 0 && !el.isCompleted) {
            el.colourCode = "red";
          }
        }
        this.contractList = data;
        this.bindData(this.contractList);
        this.uiSvc.hide();
      },
      error: (err) => {
        this.errors = err;
        this.uiSvc.hide();
      },
    });
  }

  bindData(data) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.paginator = this.paginator;
    this.sortingDataAccessor(this.dataSource);
    this.dataSource.sort = this.sort;
  }

  sortingDataAccessor(dataSource) {
    dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case "client":
          return item.clientName;
        case "project":
          return item.projectName;
        case "contractDate":
          return item.contractEndDate;
        case "contractStatus":
          return item.status;
        default:
          return item[property];
      }
    };
  }
}
