import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ContractDatesRoutingModule } from "./contract-dates-routing.module";
import { ContractDatesComponent } from "./contract-dates.component";
import { ContractListComponent } from "./list/contract-list.component";
import { SharedModule } from "src/app/shared";
import { MatSelectSearchModule } from "mat-select-search";

@NgModule({
  declarations: [ContractDatesComponent, ContractListComponent],
  imports: [
    CommonModule,
    ContractDatesRoutingModule,
    SharedModule,
    MatSelectSearchModule,
  ],
})
export class ContractDatesModule {}
