import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ContractDatesComponent } from "./contract-dates.component";
import { ContractListComponent } from "./list/contract-list.component";

const routes: Routes = [
  {
    path: "",
    component: ContractDatesComponent,
    children: [
      {
        path: "",
        redirectTo: "list",
        pathMatch: "full",
      },
      {
        path: "list",
        component: ContractListComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ContractDatesRoutingModule {}
