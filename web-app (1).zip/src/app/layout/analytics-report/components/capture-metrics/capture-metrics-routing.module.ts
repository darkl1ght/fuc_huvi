import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CaptureMetricsComponent } from "./capture-metrics.component";
import { CaptureMetricsListComponent } from "./list/capture-metrics-list.component";

const routes: Routes = [
  {
    path: "",
    component: CaptureMetricsComponent,
    children: [
      {
        path: "",
        redirectTo: "list",
        pathMatch: "full",
      },
      {
        path: "list",
        component: CaptureMetricsListComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CaptureMetricsRoutingModule {}
