import { Component } from '@angular/core';

@Component({
  selector: 'app-capture-metrics',
  templateUrl: './capture-metrics.component.html',
  styleUrls: ['./capture-metrics.component.scss']
})
export class CaptureMetricsComponent {

}
