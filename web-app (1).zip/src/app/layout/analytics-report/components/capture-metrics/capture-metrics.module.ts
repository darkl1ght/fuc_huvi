import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "src/app/shared";
import { CaptureMetricsRoutingModule } from "./capture-metrics-routing.module";
import { CaptureMetricsComponent } from "./capture-metrics.component";
import { CaptureMetricsListComponent } from "./list/capture-metrics-list.component";
import { MatSelectSearchModule } from "mat-select-search";

@NgModule({
  declarations: [CaptureMetricsComponent, CaptureMetricsListComponent],
  imports: [
    CommonModule,
    CaptureMetricsRoutingModule,
    SharedModule,
    MatSelectSearchModule,
  ],
})
export class CaptureMetricsModule {}
