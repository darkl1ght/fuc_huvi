import { Component, ViewChild } from "@angular/core";
import { UntypedFormBuilder, UntypedFormGroup } from "@angular/forms";
import { MatOption } from "@angular/material/core";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { MatSelect } from "@angular/material/select";
import {
  CaptureMetrics,
  Project,
  Reports,
  UiService,
  User,
  UserService,
} from "src/app/core";
import { ReportService } from "src/app/core/services/reports.service";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";

@Component({
  selector: "app-capture-metrics-list",
  templateUrl: "./capture-metrics-list.component.html",
  styleUrls: ["./capture-metrics-list.component.scss"],
})
export class CaptureMetricsListComponent {
  @ViewChild("select") select: MatSelect;
  @ViewChild("filterProjectForm") filterProjectForm;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  dataSource: any;
  filteredProjects: Record<string, string>[] = [];
  user: User;
  errors = {};
  projects: Project[] = [];
  captureList: CaptureMetrics[] = [];
  filterProjects: UntypedFormGroup;
  formSubmitAttempt: boolean = false;
  wasFormChanged = false;
  allSelected = false;
  displayedColumns: string[] = [
    "project",
    "type",
    "tourDate",
    "tourName",
    "tower",
    "floor",
    "images",
  ];
  createdDateFilterRangeStartDate: Date;

  constructor(
    private userService: UserService,
    private uiSvc: UiService,
    private _formBuilder: UntypedFormBuilder,
    private reportService: ReportService
  ) {
    this.filterProjects = this._formBuilder.group({
      projects: ["", ""],
      startDate: ["", ""],
      endDate: ["", ""],
    });
  }

  ngOnInit(): void {
    this.user = this.userService.getCurrentUser();
    this.getProjectsByUser();
  }

  get f() {
    return this.filterProjects.controls;
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  getProjectsByUser() {
    this.uiSvc.show();
    this.reportService.getProjectsByUser().subscribe(
      (data) => {
        this.projects = data;
        this.uiSvc.hide();
      },
      (err) => {
        this.uiSvc.hide();
        this.errors = err;
      }
    );
  }

  filterCreatedDateRangeStartChanged(e: MatDatepickerInputEvent<Date>) {
    this.createdDateFilterRangeStartDate = e.value;
  }

  filterCreatedDateRangeEndChanged(e: MatDatepickerInputEvent<Date>) {
    this.createdDateFilterRangeStartDate = e.value;
  }

  toggleAllSelection() {
    if (this.allSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
  }

  filterApply() {
    this.formSubmitAttempt = true;
    if (this.filterProjects.valid) {
      this.submitData();
    }
  }

  submitData() {
    this.uiSvc.show();
    const result = this.filterProjects.value;
    let payload: Reports;
    payload = {
      projectIds: result.projects,
      startDate: result.startDate,
      endDate: result.endDate,
    };
    this.reportService.fetchCaptureMetrics(payload).subscribe({
      next: (data) => {
        this.captureList = data;
        this.bindData(this.captureList);
        this.uiSvc.hide();
      },
      error: (err) => {
        this.uiSvc.hide();
        this.errors = err;
      },
    });
  }

  bindData(data) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.paginator = this.paginator;
    this.sortingDataAccessor(this.dataSource);
    this.dataSource.sort = this.sort;
  }

  sortingDataAccessor(dataSource) {
    dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case "project":
          return item.projectName;
        case "tower":
          return item.towerName;
        case "floor":
          return item.floorName;
        case "images":
          return item.imagecount;
        default:
          return item[property];
      }
    };
  }
}
