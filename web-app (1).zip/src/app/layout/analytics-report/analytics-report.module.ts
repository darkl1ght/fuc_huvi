import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "src/app/shared";
import { AnalyticsReportRoutingModule } from "./analytics-report-routing.module";
import { ReportsHeaderComponent } from "../components/reports-header/reports-header.component";
import { ReportsSidebarComponent } from "../components/reports-sidebar/reports-sidebar.component";
import { AnalyticsReportComponent } from "./analytics-report.component";
import { FormsModule } from "@angular/forms";
import { MatSelectSearchModule } from "mat-select-search";

@NgModule({
  declarations: [
    AnalyticsReportComponent,
    ReportsHeaderComponent,
    ReportsSidebarComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    AnalyticsReportRoutingModule,
    FormsModule,
    MatSelectSearchModule,
  ],
})
export class AnalyticsReportModule {}
