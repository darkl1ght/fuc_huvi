import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import {
  IntegrationService,
  UiService,
  SnackbarService,
  ProcoreTokenExchangePayload,
  ProcoreToken,
} from "src/app/core";

@Component({
  selector: "app-callback",
  templateUrl: "./callback.component.html",
  styleUrls: ["./callback.component.scss"],
})
export class CallbackComponent implements OnInit {
  constructor(
    private activatedRoute: ActivatedRoute,
    private integrationService: IntegrationService,
    private uiService: UiService,
    private snackService: SnackbarService,
    private ts: TranslateService
  ) {}

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe((params) => {
      if (params["code"]) {
        this.uiService.show();
        this.getAccessToken(params["code"], params["state"], params["goback"])
          .then(async (data) => {
            this.integrationService.setProcoreAccessToken(data.access_token);
            this.integrationService.setProcoreRefreshToken(data.refresh_token);

            this.uiService.hide();
            this.snackService.successSnackBar(
              this.ts.instant("integration.procore.messages.connectionSuccess")
            );
            await this.stall(2000);

            if (params["goback"]) {
              window.location.href = params["goback"];
            }
          })
          .catch(async () => {
            this.uiService.hide();
            this.snackService.errorSnackBar(
              this.ts.instant("integration.procore.messages.connectionFailed")
            );
            await this.stall(2000);

            if (params["goback"]) {
              window.location.href = params["goback"];
            }
          });
      }
    });
  }

  getAccessToken(code: string, state: string, goback: string) {
    return new Promise<ProcoreToken>((resolve, reject) => {
      if (state !== (this.integrationService.getProcoreAuthState() as string)) {
        return;
      }

      const payload: ProcoreTokenExchangePayload = {
        code,
        code_verifier:
          this.integrationService.getProcoreAuthCodeVerifier() as string,
        redirect_uri: goback,
      };

      this.integrationService.procoreTokenExchange(payload).subscribe({
        next: (data) => {
          resolve(data);
        },
        error: (err) => {
          reject(true);
        },
      });
    });
  }

  async stall(delay: number) {
    await new Promise((resolve) => {
      setTimeout(resolve, delay);
    });
  }
}
