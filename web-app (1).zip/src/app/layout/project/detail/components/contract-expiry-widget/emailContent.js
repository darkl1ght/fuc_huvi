// The Body of the Contract Expiry Image

const emailBody = {
  body: `

Hello! Team CONSTRA, %0D%0A%0D%0A

I hope this message finds you well. 
%0D%0A%0D%0A
We wish to discuss the possibility of renewing our contract for {projectName}.
%0D%0A
We believe that continuing our partnership is in our mutual interest.
%0D%0A%0D%0A
We would like to schedule a meeting to discuss the terms of the contract renewal at your earliest convenience. 
We look forward to the opportunity to continue our collaboration.
%0D%0A
%0D%0A
Thank you for your attention to this matter.
%0D%0A
%0D%0A
Best regards,
%0D%0A
{clientName}

`,
};

export default emailBody;
