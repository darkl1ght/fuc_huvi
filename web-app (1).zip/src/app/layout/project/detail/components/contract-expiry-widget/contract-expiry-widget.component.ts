import { Component } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import {
  ClientService,
  ProjectService,
  LocalStorageService,
  SnackbarService,
  UiService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import emailBody from "./emailContent";

@Component({
  selector: "app-contract-expiry-widget",
  templateUrl: "./contract-expiry-widget.component.html",
  styleUrls: ["./contract-expiry-widget.component.scss"],
})
export class ContractExpiryWidgetComponent {
  clientId: any;
  clientName: any;
  projectId: any;
  projectName: any;

  constructor(
    private dialog: MatDialog,
    private clientService: ClientService,
    private projectService: ProjectService,
    private localStorageService: LocalStorageService,
    private snackbarService: SnackbarService,
    private ts: TranslateService,
    private uiService: UiService
  ) {}

  ngOnInit() {
    this.clientId = this.localStorageService.getClientId();
    this.projectId = this.localStorageService.getProjectId();
    this.obtainClientDetails();
  }

  obtainClientDetails() {
    this.clientService.getClient(this.clientId).subscribe((clientDetails) => {
      this.clientName = clientDetails.client.clientName;

      if (this.clientName) {
        this.projectService.get(this.projectId).subscribe((projectDetails) => {
          this.projectName = projectDetails.projectName;
        });
      } else {
        let alert;
        alert = this.ts.instant("contracts.messages.detailsUnavailable");
        this.snackbarService.errorSnackBar(alert);
      }
    });
  }

  closeExpiryPopUp() {
    this.dialog.closeAll();
    this.uiService.hide();
  }

  openMail() {
    const recipient = "contracts@huviair.com";
    const subject = "Contract Renewal Request";
    const { body } = emailBody;
    const finalBody = body
      .replace("{projectName}", this.projectName)
      .replace("{clientName}", this.clientName);

    const gmailUrl =
      "https://mail.google.com/mail/?view=cm&fs=1&to=" +
      recipient +
      "&su=" +
      subject +
      "&body=" +
      finalBody;

    window.open(gmailUrl, "_blank");
  }
}
