import {
  FileGrid,
  User,
  ProjectUser,
  AppConstants as Constants,
  ImageViewerData,
  FileAnnotation,
  UiService,
  ProjectUserService,
  ContentDataService,
  UserService,
  UpdateFeaturesPayload,
  IMetadata,
  ProjectService,
  LocalStorageService,
  SnackbarService,
} from "src/app/core";
import { Component, Inject, ViewChild } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import * as L from "leaflet";
import screenfull, { Screenfull } from "screenfull";
import { v4 as uuidv4 } from "uuid";
import domtoimage from "dom-to-image";
import { TranslateService } from "@ngx-translate/core";
import { Clipboard } from "@angular/cdk/clipboard";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
declare const window: any;

@Component({
  selector: "library-image-viewer",
  templateUrl: "./library-image-viewer.component.html",
  styleUrls: ["./library-image-viewer.component.scss"],
})
export class LibraryImageViewerComponent {
  @ViewChild("trigger") trigger;
  currentIndex: number;
  userAction: string;
  annotationList: FileAnnotation[] = [];
  featureGroup: L.FeatureGroup;
  map: L.Map;
  currentUser: User;
  layerData: any;
  projectId: string;
  fileId: string;
  featureData: any;
  members: ProjectUser[];
  annotationDetails: FileAnnotation;
  imageList: FileGrid[];
  image: FileGrid;
  metaData: IMetadata[];
  nLayersLoaded: number = 0;
  nLayers: number = 0;
  shapes: any = [];
  annotationId: string;
  polygonCount: number = 0;
  layerDataFromStorage: any;
  geoJsonGroup: any;
  errors = {};
  isOpen: boolean = false;
  shareLink: string = null;
  isNextEnabled: boolean = true;
  isPrevEnabled: boolean = true;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: ImageViewerData,
    @Inject(APP_CONFIG) private config: AppConfig,
    private uiService: UiService,
    private ts: TranslateService,
    private snackService: SnackbarService,
    private userSvc: ProjectUserService,
    private contentDataService: ContentDataService,
    private userService: UserService,
    private projectSvc: ProjectService,
    private clipboard: Clipboard,
    private localStorage: LocalStorageService
  ) {
    this.currentUser = this.userService.getCurrentUser();
    this.featureGroup = new L.FeatureGroup();
  }

  public ngOnInit(): void {
    this.imageList = this.data.allImages;
    this.projectId = this.data.projectId;

    if (this.imageList.length == 0) {
      this.imageList.push(this.data.image);
    }

    this.initializeCurrentImage(this.data.image);
    this.initializeImage(this.data.image);

    this.userSvc.getAll(this.projectId).subscribe(
      (data) => {
        this.members = data.users;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  initializeCurrentImage(image: FileGrid) {
    for (let i = 0; i < this.imageList.length; i++) {
      this.imageList[i].index = i;

      if (this.imageList[i].fileObjectId === image.fileObjectId) {
        this.currentIndex = i;
      }
    }

    this.enablePrevNext();
  }

  enablePrevNext() {
    this.isNextEnabled = this.currentIndex < this.imageList.length - 1;
    this.isPrevEnabled = this.currentIndex != 0;
  }

  initializeImage(image: FileGrid) {
    this.fileId = image.id;
    this.image = image;
    this.metaData = this.image.metadata;
    this.userAction = Constants.annotation_action.view;
    this.annotationList = this.image.annotations ? this.image.annotations : [];

    const imageUrl = this.image.viewUrl;
    this.uiService.show();
    this.nLayersLoaded = 0;
    this.nLayers = 0;

    const MIN_ZOOM = 1;
    const MAX_ZOOM = 5;
    const INITIAL_ZOOM = 3;
    const ACTUAL_SIZE_ZOOM = 3;

    if (!this.map) {
      this.map = L.map("map", {
        minZoom: MIN_ZOOM,
        maxZoom: MAX_ZOOM,
        center: [0, 0],
        zoom: INITIAL_ZOOM,
        crs: L.CRS.Simple,
        fullscreenControl: true,
        fullscreenControlOptions: {
          position: "topleft",
        },
      });

      // this.setDrawingTools();
      const drawControl = new L.Control.Draw({
        position: "topleft",
        draw: {
          polyline: false,
          circle: false,
          polygon: false,
          circlemarker: false,
          rectangle: {
            shapeOptions: {
              color: "#bada55",
            },
            metric: false,
          },
          marker: false,
        },
        edit: {
          featureGroup: this.featureGroup,
          edit: false,
        },
      });

      this.map.addControl(drawControl);
      // new Screenshot({ position: "topleft" }).addTo(this.map);
      this.map.on("draw:created", (e: any) => {
        const layer = e.layer;
        const guid = uuidv4();
        const type = e.layerType;
        if (type === "rectangle") {
          const label = this.generateUniqueString();
          let radius: number;

          this.addShapeToMap(type, guid, label, layer, radius, true);
        }
      });

      this.map.on("draw:deleted", (e: any) => {
        const layers = e.layers;
        layers.eachLayer((layer: any) => {
          const type = layer.feature.properties.type;
          const guid = layer.feature.properties.guid;

          if (type === "rectangle") {
            this.shapes = this.shapes.filter((obj: any) => {
              this.deleteAnnotation(this.fileId, guid);

              // this.featureGroup.removeLayer(layer);
              this.featureGroup.eachLayer((layer: any) => {
                const type1 = layer.feature.properties.type;
                const guid1 = layer.feature.properties.guid;

                if (type1 === "rectangle" && guid1 === guid) {
                  this.featureGroup.removeLayer(layer);
                }
              });
              return obj.guid !== guid;
            });

            if (
              this.polygonCount -
                parseInt(layer.feature.properties.label.split("-")[1]) ===
              0
            ) {
              this.polygonCount -= 1;
            }
          }
        });
        this.layerData = this.featureGroup.toGeoJSON();
        this.updateFeatureLayer(this.fileId, this.layerData);
      });
    } else {
      // to reset the view of the map while changing images
      this.map.setView([0, 0], INITIAL_ZOOM);
    }

    this.map.on("enterFullscreen", () => {
      this.map.setView([0, 0], 4);
    });

    this.map.on("exitFullscreen", () => {
      this.map.setView([0, 0], 3);
    });

    if (this.featureGroup && this.map.hasLayer(this.featureGroup)) {
      this.map.removeLayer(this.featureGroup);
      this.featureGroup.clearLayers();
    }

    this.map.eachLayer((layer) => {
      this.map.removeLayer(layer);
    });

    const w = (4 * 440) / 3;
    const h = 440;
    const url = imageUrl;

    const southWest = this.map.unproject([0, h], ACTUAL_SIZE_ZOOM);
    const northEast = this.map.unproject([w, 0], ACTUAL_SIZE_ZOOM);
    const bounds = new L.LatLngBounds(southWest, northEast);

    const imgLayer = L.imageOverlay(url, bounds);
    try {
      this.nLayers++;
      imgLayer.on("load", () => {
        this.nLayersLoaded++;
        if (this.nLayersLoaded == this.nLayers) {
          this.uiService.hide();
        }
      });
    } catch (error) {
      this.uiService.hide();
    }

    imgLayer.addTo(this.map);
    this.map.setMaxBounds(bounds);
    this.map.addLayer(this.featureGroup);

    this.layerDataFromStorage = this.image.features;
    if (
      this.layerDataFromStorage &&
      this.layerDataFromStorage !== null &&
      this.layerDataFromStorage !== undefined &&
      this.layerDataFromStorage.features.length > 0
    ) {
      this.geoJsonGroup = L.geoJSON(this.image.features);
      this.geoJsonGroup.eachLayer((layer: any) => {
        const type = layer.feature.properties.type;
        const guid = layer.feature.properties.guid;

        if (type === "rectangle") {
          let radius: number;
          const label = layer.feature.properties.label;
          this.addShapeToMap(type, guid, label, layer, radius, false);
        }
      });
    }

    //set media annotation visibility
    this.annotationList.forEach((x) => {
      x.hidden = false;
    });
  }

  viewPrevMedia() {
    this.viewMedia(-1);
  }

  viewNextMedia() {
    this.viewMedia(1);
  }

  viewMedia(index: number) {
    let selectedIndex = this.currentIndex + index;
    let selectedImage: FileGrid;

    if (selectedIndex < 0) selectedIndex = 0;
    if (selectedIndex > this.imageList.length - 1)
      selectedIndex = this.imageList.length - 1;

    if (selectedIndex !== this.currentIndex) {
      this.currentIndex = selectedIndex;
      this.enablePrevNext();
      selectedImage = this.imageList[selectedIndex];

      this.uiService.show();
      this.contentDataService
        .getFileByObjectId(selectedImage.fileObjectId)
        .subscribe({
          next: (file) => {
            const newFile: FileGrid = {
              id: file.id,
              fileObjectId: file.fileObjectId,
              parentFolderRefId: file.parentFolderRefId,
              downloadUrl: file.downloadUrl,
              viewUrl: file.viewUrl,
              thumbnailUrl: file.viewUrl,
              type: "file",
              isSelected: false,
              name: file.name,
              description: file.description,
              updatedAt: file.updatedAt,
              createdAt: file.createdAt,
              lastModifiedBy: file.updatedBy,
              lastModifiedDate: file.updatedAt.toString(),
              metadata: file.metadata,
              annotations: file.annotations,
              features: file.features,
              comments: file.comments,
              tags: file.tags,
            };
            this.imageList.splice(selectedIndex, 1, newFile);
            selectedImage = this.imageList[selectedIndex];
            this.initializeImage(selectedImage);
            this.uiService.hide();
          },
          error: () => {
            this.uiService.hide();
          },
        });
    }
  }

  addShapeToMap(
    type: String,
    guid: string,
    label: string,
    layer: any,
    radius?: number,
    isNewShape?: boolean
  ) {
    let shape: any;
    let latlng: any;

    if (type === "rectangle") {
      latlng = layer._latlngs;
      shape = new L.Rectangle(latlng);
    }

    const shapeDetails = {
      label,
      guid,
    };

    this.shapes.push(shapeDetails);

    shape
      .bindTooltip(label, {
        permanent: true,
        direction: "bottom",
        className: "labelstyle",
      })
      .openTooltip();

    shape.on("click", (e: any) => {
      if (this.userAction === Constants.annotation_action.view) {
        const annotation = this.annotationList.find(
          (x) =>
            x.annotationId === e.target.feature.properties.guid && !x.hidden
        );
        if (annotation) {
          this.userAction = Constants.annotation_action.edit;
          this.annotationId = annotation.annotationId;
          this.featureGroup.eachLayer((layer: any) => {
            const type = layer.feature.properties.type;
            const guid = layer.feature.properties.guid;
            if (type === "rectangle" && guid === annotation.annotationId) {
              this.featureData = layer;
              this.layerData = this.featureGroup.toGeoJSON();
              this.annotationDetails = annotation;
            }
          });
        }
      }
    });

    shape.feature = {
      type: "Feature",
      geometry: null,
      properties: { guid, label, type },
      id: L.Util.stamp(shape),
    };

    if (
      this.userAction === Constants.annotation_action.create ||
      this.userAction === Constants.annotation_action.edit
    ) {
      const alert = this.ts.instant(
        "media.imageViewer.messages.newAnnotationError"
      );
      this.snackService.errorSnackBar(alert);
    } else {
      this.featureGroup.addLayer(shape);
      this.getMaxLastPolygonCount(label);
      if (isNewShape) {
        this.featureData = shape;
        this.layerData = this.featureGroup.toGeoJSON();
        this.updateMapToFitBound(shape);
        this.userAction = Constants.annotation_action.create;
      }
    }
  }

  updateMapToFitBound(layer) {
    this.map.fitBounds(layer.getBounds(), { padding: [50, 50] });
  }

  getMaxLastPolygonCount(polygonLabel: string) {
    const prevPolygonCount = parseInt(polygonLabel.split("-")[1]);
    if (prevPolygonCount > this.polygonCount) {
      this.polygonCount = prevPolygonCount;
    }
  }

  annotationCancel(layer) {
    if (this.userAction === Constants.annotation_action.create) {
      this.featureGroup.removeLayer(layer);
    }
    this.userAction = Constants.annotation_action.view;
  }

  annotationSaved() {
    this.userAction = Constants.annotation_action.view;
    this.getAnnotations();
  }

  getAnnotations() {
    this.contentDataService.getAnnotations(this.fileId).subscribe(
      (data) => {
        this.annotationList = data;
        //set media annotation visibility
        this.annotationList.forEach((x) => {
          x.hidden = false;
        });
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  highlight(annotation: FileAnnotation) {
    const highlightGuid = annotation.shape["guid"];
    const label = annotation.shape["label"];
    this.featureGroup.eachLayer((layer: any) => {
      const type = layer.feature.properties.type;
      const guid = layer.feature.properties.guid;

      if (type === "rectangle" && guid === highlightGuid) {
        this.map.fitBounds(layer.getBounds());

        layer.closeTooltip().unbindTooltip();

        layer
          .bindTooltip(label, {
            direction: "bottom",
            className: "highlight",
          })
          .openTooltip();
        setTimeout(() => {
          layer.closeTooltip().unbindTooltip();
          layer
            .bindTooltip(label, {
              permanent: true,
              direction: "bottom",
              className: "labelstyle",
            })
            .openTooltip();
        }, 2000);
      }
    });
  }

  deleteAnnotationFromGrid(annotation: FileAnnotation) {
    const highlightGuid = annotation.shape["guid"];
    this.featureGroup.eachLayer((layer: any) => {
      const type = layer.feature.properties.type;
      const guid = layer.feature.properties.guid;

      if (type === "rectangle" && guid === highlightGuid) {
        this.featureGroup.removeLayer(layer);
        this.layerData = this.featureGroup.toGeoJSON();

        this.deleteAnnotation(this.fileId, guid);
        this.updateFeatureLayer(this.fileId, this.layerData);
      }
    });
  }

  deleteAnnotation(fileId, annotationId) {
    if (fileId && annotationId) {
      this.contentDataService
        .removeAnnotation(fileId, annotationId)
        .subscribe((data) => {});
    }
  }

  updateFeatureLayer(fileId, layer) {
    if (fileId && layer) {
      const payload: UpdateFeaturesPayload = {
        features: layer,
      };
      this.contentDataService.updateFeatures(fileId, payload).subscribe(() => {
        this.getAnnotations();
        this.userAction = Constants.annotation_action.view;
      });
    }
  }

  hideLayerOnMap(annotation: FileAnnotation) {
    annotation.hidden = !annotation.hidden;
    const highlightGuid = annotation.shape["guid"];
    const label = annotation.shape["label"];
    this.featureGroup.eachLayer((layer: any) => {
      const type = layer.feature.properties.type;
      const guid = layer.feature.properties.guid;

      if (type === "rectangle" && guid === highlightGuid) {
        if (annotation.hidden) {
          layer.closeTooltip().unbindTooltip();
          layer.setStyle({
            weight: 2,
            color: "rgba(0,0,0,0)",
            dashArray: "",
            fillOpacity: 0.1,
            opacity: 0.9,
          });
        } else {
          layer.closeTooltip().unbindTooltip();

          layer.setStyle({
            weight: 2,
            color: "rgb(51, 136, 255)",
            dashArray: "",
            fillOpacity: 0.1,
            opacity: 0.9,
          });

          layer
            .bindTooltip(label, {
              permanent: true,
              direction: "bottom",
              className: "labelstyle",
            })
            .openTooltip();
        }
      }
    });
  }

  generateUniqueString() {
    const ts = String(new Date().getTime());
    let out = "";
    for (let i = 0; i < ts.length; i += 2) {
      out += Number(ts.substr(i, 2)).toString(36);
    }
    return out.toUpperCase();
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
  generateShareLink() {
    const shareInfo: any = {
      clientId: this.localStorage.getClientId(),
      projectId: this.projectId,
      fileId: this.fileId,
      data: this.image,
    };
    this.projectSvc
      .generateShareLink("library", this.fileId, shareInfo)
      .subscribe(
        (data: any) => {
          this.isOpen = true;
          const share = data.share;
          this.shareLink = eval("`" + this.config.shareUrl + "`");
        },
        (error) => {
          this.errors = error;
        }
      );
  }
  copyShareLink() {
    if (!!this.shareLink) {
      this.clipboard.copy(this.shareLink);
      this.snackService.successSnackBar(
        this.ts.instant("general.messages.copyLink")
      );
    }
  }
}

export class Screenshot extends L.Control {
  constructor(options?: L.ControlOptions) {
    super(options);
  }

  onAdd(map: L.Map) {
    const container = L.DomUtil.create(
      "div",
      "leaflet-bar leaflet-control leaflet-control-custom"
    );

    container.style.backgroundColor = "white";
    container.style.backgroundImage = "url(assets/images/screenshot.png)";
    container.style.backgroundSize = "30px 30px";
    container.style.width = "30px";
    container.style.height = "30px";
    container.title = "Download Annotated Image";

    container.onmouseover = function () {
      container.style.backgroundColor = "#F5F5F5";
    };
    container.onmouseout = function () {
      container.style.backgroundColor = "white";
    };
    container.onclick = () => {
      let sf = <Screenfull>screenfull;
      if (sf.isFullscreen) {
        if (map.getZoom() == 4) {
          this.downloadImage(1);
        } else {
          map.setView([0, 0], 4);
          map.once("moveend zoomend", () => {
            this.downloadImage(1);
          });
        }
      } else {
        if (map.getZoom() == 3) {
          this.downloadImage(2);
        } else {
          map.setView([0, 0], 3);
          map.once("moveend zoomend", () => {
            this.downloadImage(2);
          });
        }
      }
    };
    return container;
  }

  downloadImage(sizeFactor) {
    // hiding controls on the map for screenshot
    const mapControls = document.getElementsByClassName(
      "leaflet-control-container"
    )[0] as HTMLElement;
    mapControls.style.display = "none";

    const node = document.getElementById("map");
    const props = {
      width: node.clientWidth * sizeFactor,
      height: node.clientHeight * sizeFactor,
      style: {
        transform: "scale(" + sizeFactor + ")",
        "transform-origin": "top left",
      },
    };

    domtoimage
      .toBlob(node, props)
      .then((file) => {
        window.saveAs(file, uuidv4() + ".png");
        //displaying controls after the screenshot has been taken
        mapControls.style.display = "block";
        // this.uiService.hide();
      })
      .catch((error) => {
        //displaying controls after the screenshot has been taken
        mapControls.style.display = "block";
        // this.uiService.hide();
      });
  }

  onRemove(map: L.Map) {
    // Nothing to do here
  }
}
