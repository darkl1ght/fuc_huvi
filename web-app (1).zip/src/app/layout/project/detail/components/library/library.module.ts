import { LibraryComponent } from "./library.component";
import { SharedModule } from "src/app/shared";
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { LibraryRoutingModule } from "./library-routing.module";
import { LibraryListComponent } from "./library-list/library-list.component";
import { DocumentViewerComponent } from "./viewer/viewer.component";
import { PdfViewerModule } from "ng2-pdf-viewer";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { VgCoreModule } from "@videogular/ngx-videogular/core";
import { VgControlsModule } from "@videogular/ngx-videogular/controls";
import { VgOverlayPlayModule } from "@videogular/ngx-videogular/overlay-play";
import { VgBufferingModule } from "@videogular/ngx-videogular/buffering";
import { VgStreamingModule } from "@videogular/ngx-videogular/streaming";
import { LibraryTagComponent } from "./tag/library-tag.component";
import { LibraryHistoryComponent } from "./history/library-history.component";
import { LibraryImageViewerComponent } from "./image-viewer/library-image-viewer.component";
import { LibraryDiscussionComponent } from "./discussion/library-discussion.component";
import { LibraryMetadataComponent } from "./metadata/library-metadata.component";
import { LibraryAnnotationComponent } from "./annotation/library-annotation.component";

@NgModule({
  declarations: [
    LibraryListComponent,
    LibraryComponent,
    DocumentViewerComponent,
    LibraryTagComponent,
    LibraryHistoryComponent,
    LibraryImageViewerComponent,
    LibraryDiscussionComponent,
    LibraryMetadataComponent,
    LibraryAnnotationComponent,
  ],
  imports: [
    LibraryRoutingModule,
    SharedModule,
    VgCoreModule,
    VgControlsModule,
    VgOverlayPlayModule,
    VgBufferingModule,
    VgStreamingModule,
    PdfViewerModule,
    InfiniteScrollModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class LibraryModule {}
