import { MatChipInputEvent } from "@angular/material/chips";
import {
  Component,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  ElementRef,
} from "@angular/core";
import {
  ContentDataService,
  FileAnnotation,
  MediaAnnotation,
  ProjectUser,
  SaveAnnotationNFeaturesPayload,
  SnackbarService,
} from "src/app/core";
import { startWith, map } from "rxjs/operators";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  UntypedFormControl,
} from "@angular/forms";
import { ENTER, COMMA } from "@angular/cdk/keycodes";
import { Observable } from "rxjs/internal/Observable";
import {
  MatAutocomplete,
  MatAutocompleteSelectedEvent,
} from "@angular/material/autocomplete";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "library-annotation",
  templateUrl: "./library-annotation.component.html",
  styleUrls: ["./library-annotation.component.scss"],
})
export class LibraryAnnotationComponent {
  @Input() properties: any;
  @Input() features: any;
  @Input() fileId: string;
  @Input() projectId: string;
  @Input() marker: MediaAnnotation;
  @Input() userAction: string;
  @Input() members: ProjectUser[];
  @Output() annotationCancel: EventEmitter<any> = new EventEmitter();
  @Output() annotationSaved: EventEmitter<string> = new EventEmitter();
  @ViewChild("tagInput") tagInput: ElementRef;
  @ViewChild("auto") matAutocomplete: MatAutocomplete;

  formSubmitAttempt: boolean = false;
  options: UntypedFormGroup;
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = false;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  tagCtrl = new UntypedFormControl();
  filteredTags: Observable<string[]>;
  tags: any = [];
  allTags: any = [];
  errors: any;
  annotation: FileAnnotation = {} as FileAnnotation;
  annotationId: string = "";
  annotationMetadata: any;

  constructor(
    private fb: UntypedFormBuilder,
    private contentDataService: ContentDataService,
    private snackService: SnackbarService,
    private ts: TranslateService
  ) {
    this.options = fb.group({
      annotationId: ["", null],
      description: ["", null],
      tags: ["", null],
    });

    this.filteredTags = this.tagCtrl.valueChanges.pipe(
      startWith(null),
      map((tag: string | null) =>
        tag ? this._filter(tag) : this.allTags.slice()
      )
    );

    if (this.userAction === "edit" && this.marker) {
      this.setAnnotationDetails(this.marker);
    }
  }

  ngOnInit() {
    this.annotationMetadata = this.properties.feature.properties;
    this.setUsers();
    this.setAnnotationDetails(this.marker);
  }

  setAnnotationDetails(annotation: MediaAnnotation) {
    if (annotation && annotation.annotationId) {
      this.options.patchValue({
        annotationId: annotation.annotationId,
        description: annotation.description,
        tags: annotation.tags,
      });
      this.tags = annotation.tags;
    }
  }

  setUsers() {
    this.members.forEach((member) => {
      this.allTags.push({
        id: member.email,
        name: member.firstName + " " + member.lastName,
      });
    });
  }

  get f() {
    return this.options.controls;
  }

  closeDialog() {
    this.annotationCancel.emit(this.properties);
  }

  addAnnotation() {
    let alert = "";
    this.formSubmitAttempt = true;
    if (this.options.valid) {
      this.annotation.annotationId = this.options.value["annotationId"]
        ? this.options.value["annotationId"]
        : "";
      this.annotation.description = this.options.value["description"].trim();
      this.annotation.tags = this.tags;
      this.annotation.shape = this.annotationMetadata;
      this.annotation.annotationTitle = this.options.value["description"];

      const payload: SaveAnnotationNFeaturesPayload = {
        fileId: this.fileId,
        annotation: this.annotation,
        features: this.features,
      };

      this.contentDataService.saveAnnotationNFeatures(payload).subscribe(
        (annotationId) => {
          if (annotationId) {
            alert = this.ts.instant(
              "media.annotation.messages.annotationCreated"
            );
            this.snackService.successSnackBar(alert);
            this.annotationSaved.emit(annotationId);
          }
        },
        (err) => {
          alert = this.ts.instant(
            "media.annotation.messages.annotationCreationFailed"
          );
          this.errors = err;
          this.formSubmitAttempt = false;
          this.snackService.errorSnackBar(alert);
          this.annotationCancel.emit(this.properties);
        }
      );
    }
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;

    // Reset the input value
    if (input) {
      input.value = "";
    }

    this.tagCtrl.setValue(null);
  }

  remove(tag, indx): void {
    this.tags.splice(indx, 1);
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.tags.push(event.option.value);
    this.tagInput.nativeElement.value = "";
    this.tagCtrl.setValue(null);
  }

  private _filter(value: any): string[] {
    return this.allTags.filter((tag) => tag.id === value.id);
  }
}
