import { Component, Input, SimpleChanges } from "@angular/core";
import { FileGrid } from "src/app/core";

@Component({
  selector: "library-metadata",
  templateUrl: "./library-metadata.component.html",
  styleUrls: ["./library-metadata.component.scss"],
})
export class LibraryMetadataComponent {
  @Input() file: FileGrid;
  name: String;
  updatedBy: String;
  updatedAt: String;
  mediaDescription: string;

  constructor() {}

  ngOnInit() {
    this.name = this.file.name;
    this.updatedBy = this.file.lastModifiedBy;
    this.updatedAt = this.file.updatedAt.toString();
    this.mediaDescription = this.file.description ? this.file.description : "";
  }

  ngOnChanges(changes: SimpleChanges) {
    for (let propName in changes) {
      // only run when property "data" changed
      if (propName === "file") {
        //  this line will update posts values
        this.file = changes[propName].currentValue;
        this.name = this.file.name;
        this.updatedBy = this.file.lastModifiedBy;
        this.updatedAt = this.file.updatedAt.toString();
        this.mediaDescription = this.file.description
          ? this.file.description
          : "";
      }
    }
  }
}
