import {
  Component,
  OnInit,
  ViewChild,
  Inject,
  ElementRef,
} from "@angular/core";
import { FormControl } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  ContentDataService,
  FileTagPayload,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { COMMA, ENTER } from "@angular/cdk/keycodes";
import { MatChipInputEvent } from "@angular/material/chips";

@Component({
  selector: "document-tag",
  templateUrl: "./library-tag.component.html",
  styleUrls: ["./library-tag.component.scss"],
})
export class LibraryTagComponent implements OnInit {
  @ViewChild("tagInput") tagInput: ElementRef<HTMLInputElement>;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  tagCtrl = new FormControl();
  tagList: string[] = [];
  isDataSaved: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<LibraryTagComponent>,
    private contentDataService: ContentDataService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    @Inject(MAT_DIALOG_DATA) public data: FileTagPayload
  ) {}

  public ngOnInit(): void {
    this.tagList = this.data.tagList;
  }

  saveDocumentTag() {
    let alert = "";
    let fileTagPayload: FileTagPayload;
    fileTagPayload = {
      fileId: this.data.fileId,
      tagList: this.data.tagList,
    };
    this.contentDataService.updateFiletags(fileTagPayload).subscribe({
      next: () => {
        this.isDataSaved = true;
        alert = this.ts.instant("library.messages.success");
        this.snackService.successSnackBar(alert);
      },
      error: () => {
        alert = this.ts.instant("library.messages.failed");
        this.snackService.successSnackBar(alert);
      },
    });
  }

  closeDialog(): void {
    this.dialogRef.close(this.isDataSaved);
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    if ((value || "").trim()) {
      this.tagList.push(value.trim());
    }

    if (input) {
      input.value = "";
    }

    this.tagCtrl.setValue(null);
    this.saveDocumentTag();
  }

  remove(item: string): void {
    const index = this.tagList.indexOf(item);

    if (index >= 0) {
      this.tagList.splice(index, 1);
    }

    this.saveDocumentTag();
  }

  saveTag() {
    const value = this.tagInput.nativeElement.value.trim();

    if ((value || "").trim()) {
      this.tagList.push(value.trim());
    }

    this.tagCtrl.setValue(null);
    this.saveDocumentTag();
  }
}
