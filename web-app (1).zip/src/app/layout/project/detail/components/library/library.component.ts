import { ActivatedRoute } from "@angular/router";
import { NewFolderComponent } from "../../components/new-folder/new-folder.component";
import { MatDialog } from "@angular/material/dialog";
import { Subscription } from "rxjs";
import {
  AfterViewChecked,
  Component,
  ElementRef,
  Inject,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import {
  BulkFileUpdateResponse,
  ContentDataService,
  FolderPayload,
  IMetadata,
  FolderTree,
  UploadFileLibrary,
  UploadFilePayload,
  LocalStorageService,
  ThumbnailView,
  FileGrid,
  FileEditPayload,
  UiService,
  FileVersionUploadUrlPayload,
  UpdateFileVersionPayload,
  FileVersion,
  FileEditVersion,
  RecordCountStatus,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { v4 as uuidv4 } from "uuid";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { HttpEvent, HttpEventType } from "@angular/common/http";

@Component({
  selector: "app-document",
  templateUrl: "./library.component.html",
  styleUrls: ["./library.component.scss"],
})
export class LibraryComponent implements OnInit, AfterViewChecked, OnDestroy {
  @ViewChild("sideDrawer") sidePanel: any;
  @ViewChild("otherReasonAdd") otherReasonAddInput: ElementRef;
  @ViewChild("otherReasonEdit") otherReasonEditInput: ElementRef;
  @ViewChild("editName") editNameInput: ElementRef;
  @ViewChild("editExtension") editExtensionInput: ElementRef;
  @ViewChild("versionFileName") versionFileNameInput: ElementRef;
  @ViewChild("majorVersion") majorVersionInput: ElementRef;
  @ViewChild("minorVersion") minorVersionInput: ElementRef;
  showSearchFilter: boolean = false;
  fileData: UploadFileLibrary[] = [];
  dataSource: MatTableDataSource<UploadFileLibrary>;
  readonly displayedColumns: string[] = ["name", "version", "actions"];
  renameFileUploadSelectedId: number = -1;
  isRenameFileUploadFocused: boolean = false;
  categoryOptions: any[] = [];
  addFileCategoryValue: number = 0;
  editFileCategoryValue: number = 0;
  editFileCategoryOtherValue: string;
  editFileName: string;
  editFileExtension: string;
  openAddFilesPanelSubscription: Subscription;
  openUploadVersionPanelSubscription: Subscription;
  currentFolderIdSubscription: Subscription;
  folderTreeSubscription: Subscription;
  selectAllToParentSubscription: Subscription;
  editFileSubscription: Subscription;
  indeterminateSubscription: Subscription;
  anySelectedSubscription: Subscription;
  recordCountStatusSubscription: Subscription;
  maxStaticFolderPathLength: number = 2; //positive integer
  folderPath: FolderTree[] = [];
  folderPathForMenu: FolderTree[] = [];
  folderPathStatic: FolderTree[] = [];
  cabinetId: string;
  cabinetMetadata: IMetadata[] = [];
  bulkUploadSignedUrls: BulkFileUpdateResponse[];
  readonly uploadType: UploadType = {
    S3: 1,
    STATUS: 2,
  };
  currentFolderId: string;
  folderTree: FolderTree;
  projectId: string;
  totalFilesMsg: string;
  isThumbnailView: boolean = false;
  isAllSelected: boolean = false;
  readonly filenamePattern = /^[\w.()-]+[\w(). -]*$/;
  isUploadInEdit: boolean = false;
  errorMsg: string = "";
  editSingleFile: FileGrid;
  readonly fileModes: FileMode = {
    ADD: 1,
    EDIT: 2,
    NEW_VERSION: 3,
    CLOSED: 4,
  };
  fileMode: number = this.fileModes.CLOSED;
  readonly CATEGORY: string = this.ts.instant("library.labels.category");
  readonly OTHER_CATEGORY: string = this.ts.instant(
    "library.labels.otherCategory"
  );
  readonly responseCodes: ResponseCodes = {
    SUCCESS: "10000",
    ALREADY_EXISTS: "10001",
  };
  isIndeterminate: boolean = false;
  isAnySelected: boolean = false;
  readonly OTHER: string = "Other";
  uploadVersionFile: FileGrid;
  readonly MAX_MAJOR_VERSION: number = 999;
  readonly MAX_MINOR_VERSION: number = 9;
  currentMajorVersion: number;
  currentMinorVersion: number;
  suggestedMajorVersion: number;
  suggestedMinorVersion: number;
  versionFile: FileList;
  versionFileSelected: boolean = false;
  currentVersionToDisplay: string;
  currentShortVersionToDisplay: string;
  versionUploadProgressPercent: number = 0;
  isVersionUploading: boolean = false;
  recordCountStatus: string;
  companyId: string;

  constructor(
    private contentDataService: ContentDataService,
    public createFolderDialog: MatDialog,
    private ts: TranslateService,
    private route: ActivatedRoute,
    private snackService: SnackbarService,
    private localStorage: LocalStorageService,
    private uiService: UiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {
    this.dataSource = new MatTableDataSource<UploadFileLibrary>();
  }

  ngOnInit(): void {
    const libThumbnailView: ThumbnailView =
      this.localStorage.getItem("libThumbnailView");

    if (libThumbnailView) {
      this.isThumbnailView = libThumbnailView.enabled;
    } else {
      const thumbnailView: ThumbnailView = {
        enabled: false,
        folder: true,
        file: true,
      };

      this.localStorage.setItem("libThumbnailView", thumbnailView);
    }

    this.companyId = this.localStorage.getClientId();
    this.projectId = this.localStorage.getProjectId();
    this.contentDataService
      .getProjectFolder(this.companyId, this.projectId, "library")
      .subscribe({
        next: (data) => {
          this.cabinetId = data.cabinet.id;
          this.cabinetMetadata = data.cabinet.metadata;
          this.categoryOptions = data.cabinet.metadata.find(
            (meta) => meta.label === this.CATEGORY
          )?.options;
          this.addFileCategoryValue = 0;
          this.editFileCategoryValue = 0;
        },
        error: () => {
          this.snackService.errorSnackBar(
            this.ts.instant("library.messages.fetchFailed")
          );
        },
      });

    this.openAddFilesPanelSubscription =
      this.contentDataService.openAddFilesPanel$.subscribe((show) => {
        if (show) {
          this.fileMode = this.fileModes.ADD;
          this.showSidePanel();
        }
      });

    this.currentFolderIdSubscription =
      this.contentDataService.currentFolderId$.subscribe({
        next: (folderId) => {
          this.currentFolderId = folderId;
          this.createFolderPath();
        },
      });

    this.folderTreeSubscription =
      this.contentDataService.projectFolderTreeToParent$.subscribe({
        next: (tree) => {
          this.folderTree = tree;
        },
      });

    this.selectAllToParentSubscription =
      this.contentDataService.selectAllToParent$.subscribe({
        next: (isSelectAll: boolean) => {
          this.isAllSelected = isSelectAll;
        },
      });

    this.editFileSubscription = this.contentDataService.editFileSub$.subscribe({
      next: (file: FileGrid) => {
        this.fileMode = this.fileModes.EDIT;
        this.editSingleFile = file;
        this.assignFileNameAndExtension(file.name);
        this.editFileCategoryValue = this.categoryOptions.indexOf(
          file.category
        );
        this.editFileCategoryOtherValue = file.otherCategory;
        this.getSuggestedVersionNumbers(file);
        this.showSidePanel();
      },
    });

    this.openUploadVersionPanelSubscription =
      this.contentDataService.openUploadVersionPanel$.subscribe({
        next: (file: FileGrid) => {
          this.fileMode = this.fileModes.NEW_VERSION;
          this.uploadVersionFile = file;
          this.getSuggestedVersionNumbers(file);
          this.showSidePanel();
        },
      });

    this.indeterminateSubscription =
      this.contentDataService.indeterminateToParent$.subscribe({
        next: (isIndeterminate: boolean) => {
          this.isIndeterminate = isIndeterminate;
        },
      });

    this.anySelectedSubscription =
      this.contentDataService.anySelected$.subscribe({
        next: (isAnySelected: boolean) => {
          this.isAnySelected = isAnySelected;
        },
      });

    this.recordCountStatusSubscription =
      this.contentDataService.recordCountStatus$.subscribe({
        next: (status: RecordCountStatus) => {
          const count = status.count;
          const total = status.total;

          if (count != 0 && total != 0) {
            this.recordCountStatus = eval(
              "`" + this.ts.instant("library.messages.recordCountStatus") + "`"
            );
          } else {
            this.recordCountStatus = "";
          }
        },
      });
  }

  ngAfterViewChecked() {
    this.renameFileUploadSelectedId != -1 &&
      !this.isRenameFileUploadFocused &&
      this.focusFileName("txt_" + this.renameFileUploadSelectedId) &&
      (this.isRenameFileUploadFocused = true);
  }

  focusFileName(id: string) {
    const txt = document.getElementById(id) as HTMLInputElement;

    if (txt) {
      let lastIndexOfDot = txt.value.lastIndexOf(".");

      if (lastIndexOfDot == -1) {
        txt.setSelectionRange(0, txt.value.length);
      } else {
        txt.setSelectionRange(0, lastIndexOfDot);
      }

      txt.focus();
      return true;
    }

    return false;
  }

  ngOnDestroy(): void {
    this.openAddFilesPanelSubscription.unsubscribe();
    this.openUploadVersionPanelSubscription.unsubscribe();
    this.currentFolderIdSubscription.unsubscribe();
    this.folderTreeSubscription.unsubscribe();
    this.selectAllToParentSubscription.unsubscribe();
    this.editFileSubscription.unsubscribe();
    this.indeterminateSubscription.unsubscribe();
    this.anySelectedSubscription.unsubscribe();
    this.recordCountStatusSubscription.unsubscribe();
  }

  assignFileNameAndExtension(fileName: string) {
    let name: string | undefined = "";
    let extension: string | undefined = "";

    if (fileName) {
      name = fileName;

      if (fileName.includes(".")) {
        name = fileName.substring(0, fileName.lastIndexOf("."));
        extension = fileName.split(".").pop();
      }
    }

    this.editFileName = name;
    this.editFileExtension = extension;
  }

  toggleSearchFilter() {
    this.showSearchFilter = !this.showSearchFilter;

    if (!this.showSearchFilter) {
      this.contentDataService.sendLibraryFilter("");
    }
  }

  showSidePanel() {
    this.errorMsg = "";
    this.sidePanel.open();
  }

  closeSidePanel() {
    this.errorMsg = "";
    this.fileData = [];
    this.sidePanel.close();
    this.fileMode = this.fileModes.CLOSED;
  }

  filesUploadCancel() {
    this.closeSidePanel();
  }

  filesEditCancel() {
    this.closeSidePanel();
  }

  uploadVersionCancel() {
    this.versionFile = null;
    this.versionFileSelected = false;
    this.closeSidePanel();
  }

  addFilesClicked() {
    this.fileMode = this.fileModes.ADD;
    this.showSidePanel();
  }

  handleFileInput(event) {
    const files: FileList = event.target.files;
    let maxId: number = -1;

    if (this.fileData.length > 0) {
      maxId = Math.max(...this.fileData.map((item) => item.id));
    }

    for (let i = 0; i < files.length; i++) {
      maxId++;
      this.fileData.push({
        id: maxId,
        name: files[i].name,
        file: files[i],
        isEditable: false,
      });
    }

    for (const item of this.fileData) {
      item.isEditable = false;
    }

    this.isUploadInEdit = false;

    if (this.fileData.length > 0) {
      this.dataSource.data = this.fileData;
      this.assignTotalFilesCount(this.fileData.length);
    }
  }

  droppedFiles(event) {
    let maxId: number = -1;
    const files = event.files;

    if (this.fileData.length > 0) {
      maxId = Math.max(...this.fileData.map((item) => item.id));
    }

    for (let i = 0; i < files.length; i++) {
      maxId++;
      this.fileData.push({
        id: maxId,
        name: files[i].name,
        file: files[i],
        isEditable: false,
      });
    }

    for (const item of this.fileData) {
      item.isEditable = false;
    }

    this.isUploadInEdit = false;

    if (this.fileData.length > 0) {
      this.dataSource.data = this.fileData;
      this.assignTotalFilesCount(this.fileData.length);
    }
  }

  deleteFile(element) {
    this.fileData = this.fileData.filter((item) => item.id != element.id);
    this.renameFileUploadSelectedId = -1;
    this.validateAddFileNames();

    if (this.fileData.length > 0) {
      this.dataSource.data = this.fileData;
      this.assignTotalFilesCount(this.fileData.length);
    }
  }

  editFile(element) {
    this.renameFileUploadSelectedId = element.id;
    element.isEditable = true;
    this.isUploadInEdit = true;
    this.isRenameFileUploadFocused = false;
    this.dataSource.data = this.fileData;
    this.assignTotalFilesCount(this.fileData.length);
  }

  saveFileEdit(element) {
    const fileNameTxt = document.getElementById(
      "txt_" + element.id
    ) as HTMLInputElement;
    element.name = fileNameTxt.value.trim();
    element.isEditable = false;
    this.renameFileUploadSelectedId = -1;
    this.isUploadInEdit = this.fileData.find((item) => item.isEditable)
      ? true
      : false;
    this.validateAddFileNames();
    this.dataSource.data = this.fileData;
    this.assignTotalFilesCount(this.fileData.length);
  }

  cancelUploadFileGridEdit(element) {
    element.isEditable = false;
    this.renameFileUploadSelectedId = -1;
    this.isUploadInEdit = this.fileData.find((item) => item.isEditable)
      ? true
      : false;
    this.dataSource.data = this.fileData;
    this.assignTotalFilesCount(this.fileData.length);
  }

  bulkUploadFiles() {
    if (this.fileData.length === 0 || !this.cabinetId || this.isUploadInEdit)
      return;
    if (!this.validateAddFileNames()) return;
    if (!this.validateFileExtensions()) return;
    if (!this.validateAddFileOtherCategory()) return;

    let otherCategoryFileMetadata: IMetadata;
    let categoryMetaData: IMetadata;
    const uploadFilesReq: UploadFilePayload[] = [];
    let uploadFilePayLoad: UploadFilePayload;

    otherCategoryFileMetadata = {
      metadataId: this.cabinetMetadata.find(
        (item) => item.label.toLowerCase() === this.OTHER_CATEGORY.toLowerCase()
      ).metadataId,
      metadataType: this.cabinetMetadata.find(
        (item) => item.label.toLowerCase() === this.OTHER_CATEGORY.toLowerCase()
      ).metadataType,
      label: this.OTHER_CATEGORY,
      value: "",
    };

    if (this.categoryOptions[this.addFileCategoryValue] == this.OTHER) {
      otherCategoryFileMetadata.value =
        this.otherReasonAddInput.nativeElement.value.trim();
    }

    for (const file of this.fileData) {
      categoryMetaData = {
        metadataId: this.cabinetMetadata.find(
          (item) => item.label.toLowerCase() === this.CATEGORY.toLowerCase()
        ).metadataId,
        metadataType: this.cabinetMetadata.find(
          (item) => item.label.toLowerCase() === this.CATEGORY.toLowerCase()
        ).metadataType,
        label: this.CATEGORY,
        value: this.categoryOptions[this.addFileCategoryValue],
      };

      uploadFilePayLoad = {
        cabinetRefId: this.cabinetId,
        parentFolderRefId: this.currentFolderId,
        name: file.name,
        description: this.ts.instant("library.messages.fileForLibrary"),
        fileObjectId: this.generateFileObjectId(file.name),
        fileSize: file.file.size.toString(),
        metadata: [categoryMetaData, otherCategoryFileMetadata],
        fileContent: this.fileData.find(
          (item) => item.fileObjectId === file.fileObjectId
        ).file,
      };

      file.fileObjectId = uploadFilePayLoad.fileObjectId; //save for reference
      uploadFilesReq.push(uploadFilePayLoad);
    }

    this.contentDataService.uploadFiles(uploadFilesReq);
    this.closeSidePanel();
  }

  updateFile() {
    let otherCategoryFileMetadata: IMetadata;
    let fileCategoryMetaData: IMetadata;
    let fileEditPayload: FileEditPayload;
    const newMajorVersionNumber: number = parseInt(
      this.majorVersionInput.nativeElement.value.trim()
    );
    const newMinorVersionNumber: number = parseInt(
      this.minorVersionInput.nativeElement.value.trim()
    );
    const newVersionNumber =
      newMajorVersionNumber.toString() + "." + newMinorVersionNumber.toString();

    const fileName = this.editNameInput.nativeElement.value.trim();
    const fileNameExtension =
      this.editExtensionInput.nativeElement.value.trim();
    const fullName = fileNameExtension
      ? `${fileName}.${fileNameExtension}`
      : fileName;

    if (!this.validateFileName(fullName)) {
      return;
    }

    if (
      !this.validateFileExtension(
        this.editExtensionInput.nativeElement.value.trim()
      )
    ) {
      return;
    }

    if (!this.validateUpdateFileOtherCategory()) {
      return;
    }

    if (
      !this.validateVersionNumberForFileEdit(
        newMajorVersionNumber,
        newMinorVersionNumber
      )
    )
      return;

    const category = this.categoryOptions[this.editFileCategoryValue];
    const categoryOther =
      category === this.OTHER
        ? this.otherReasonEditInput.nativeElement.value.trim()
        : null;

    fileCategoryMetaData = {
      metadataId: this.cabinetMetadata.find(
        (item) => item.label.toLowerCase() === this.CATEGORY.toLowerCase()
      ).metadataId,
      value: !!category ? category : "",
    };

    const currentVersion: FileVersion = this.editSingleFile.versions.sort(
      (a, b) =>
        parseFloat(b.versionNumber.$numberDecimal) -
        parseFloat(a.versionNumber.$numberDecimal)
    )[0];

    const versionPayload: FileEditVersion = {
      versionId: currentVersion.id,
      versionNumber: newVersionNumber,
    };

    fileEditPayload = {
      name: fullName,
      description: this.editSingleFile.description,
      fileObjectId: this.editSingleFile.fileObjectId,
      metadata: [fileCategoryMetaData],
      version: versionPayload,
    };

    const otherCategoryFileMetadataId = this.cabinetMetadata.find(
      (item) => item.label.toLowerCase() === this.OTHER_CATEGORY.toLowerCase()
    ).metadataId;

    if (category === this.OTHER) {
      otherCategoryFileMetadata = {
        metadataId: otherCategoryFileMetadataId,
        value: categoryOther,
      };
    } else {
      otherCategoryFileMetadata = {
        metadataId: otherCategoryFileMetadataId,
        value: "",
      };
    }

    fileEditPayload.metadata.push(otherCategoryFileMetadata);
    this.uiService.show();
    this.contentDataService.updateFile(fileEditPayload).subscribe({
      next: () => {
        this.uiService.hide();
        this.snackService.successSnackBar(
          this.ts.instant("library.messages.fileUpdated")
        );
        this.closeSidePanel();

        if (category === this.OTHER) {
          this.editFileCategoryOtherValue = categoryOther;
        } else {
          this.editFileCategoryOtherValue = "";
        }

        this.contentDataService.refreshFiles(true);
        this.closeSidePanel();
        this.currentVersionToDisplay = "";
        this.currentShortVersionToDisplay = "";
        this.currentMajorVersion = 0;
        this.currentMinorVersion = 0;
        this.suggestedMajorVersion = 0;
        this.suggestedMinorVersion = 0;
        const alert = this.ts.instant("library.messages.detailsSaved");
        this.snackService.successSnackBar(alert);
      },
      error: () => {
        this.uiService.hide();
        this.snackService.errorSnackBar(
          this.ts.instant("library.messages.saveFailed")
        );
      },
    });
  }

  validateAddFileNames(): boolean {
    for (const file of this.fileData) {
      if (!this.filenamePattern.test(file.name)) {
        this.errorMsg = this.ts.instant("library.messages.validFilename");
        return false;
      }
    }

    this.errorMsg = "";
    return true;
  }

  validateFileExtensions(): boolean {
    const invalidExtensions = this.config.libraryInvalidExtensions;
    let extension: string;

    invalidExtensions.forEach((item, index) => {
      invalidExtensions[index] = item.toLowerCase();
    });

    for (const file of this.fileData) {
      if (file.name.includes(".")) {
        extension = file.name.split(".").pop().trim().toLowerCase();

        if (this.config.libraryInvalidExtensions.includes(extension)) {
          this.errorMsg = eval(
            "`" + this.ts.instant("library.messages.invalidExtensions") + "`"
          );
          return false;
        }
      }
    }

    this.errorMsg = "";
    return true;
  }

  validateFileName(filename: string): boolean {
    if (!this.filenamePattern.test(filename)) {
      this.errorMsg = this.ts.instant("library.messages.validFilename");
      return false;
    }

    this.errorMsg = "";
    return true;
  }

  validateAddFileOtherCategory(): boolean {
    if (
      this.categoryOptions[this.addFileCategoryValue] == this.OTHER &&
      this.otherReasonAddInput.nativeElement.value.trim() === ""
    ) {
      this.errorMsg = this.ts.instant("library.messages.requiredOtherReason");
      return false;
    }

    this.errorMsg = "";
    return true;
  }

  validateUpdateFileOtherCategory(): boolean {
    if (
      this.categoryOptions[this.editFileCategoryValue] == this.OTHER &&
      this.otherReasonEditInput.nativeElement.value.trim() === ""
    ) {
      this.errorMsg = this.ts.instant("library.messages.requiredOtherReason");
      return false;
    }

    this.errorMsg = "";
    return true;
  }

  validateFileExtension(ext: string): boolean {
    const extension: string = ext.trim().toLowerCase();
    const invalidExtensions = this.config.libraryInvalidExtensions;

    invalidExtensions.forEach((item, index) => {
      invalidExtensions[index] = item.toLowerCase();
    });

    if (extension && invalidExtensions.includes(extension)) {
      this.errorMsg = eval(
        "`" + this.ts.instant("smartMedia.messages.invalidExtensions") + "`"
      );
      return false;
    }

    this.errorMsg = "";
    return true;
  }

  validateFileExtensionForNewVersion(filename: string): boolean {
    const invalidExtensions = this.config.libraryInvalidExtensions;
    let extension: string;

    invalidExtensions.forEach((item, index) => {
      invalidExtensions[index] = item.toLowerCase();
    });

    if (filename.includes(".")) {
      extension = filename.split(".").pop().trim().toLowerCase();

      if (this.config.libraryInvalidExtensions.includes(extension)) {
        this.errorMsg = eval(
          "`" + this.ts.instant("library.messages.invalidExtensions") + "`"
        );
        return false;
      }
    }

    this.errorMsg = "";
    return true;
  }

  createFolderPath() {
    let path: FolderTree[] = [];

    if (this.folderTree) {
      this.matchFolderRecursive(this.folderTree, this.currentFolderId, path);
    }

    this.folderPath = path;
    const folderPathTemp = path.slice(1);

    this.folderPathStatic = folderPathTemp.slice(
      -this.maxStaticFolderPathLength
    );

    this.folderPathForMenu = folderPathTemp.slice(
      0,
      folderPathTemp.length - this.folderPathStatic.length
    );
  }

  matchFolderRecursive(
    tree: FolderTree,
    folderIdToMatch: string,
    path: FolderTree[]
  ) {
    let isBreak: boolean = false;
    path.push({
      id: tree.id,
      name:
        tree.parentFolderRefId === null
          ? this.ts.instant("library.labels.root")
          : tree.name,
      parentFolderRefId: tree.parentFolderRefId,
    });

    if (tree.id === folderIdToMatch) {
      return true;
    } else {
      if (tree.subFolders.length === 0) {
        path.pop();
        return false;
      }

      for (const subFolder of tree.subFolders) {
        if (this.matchFolderRecursive(subFolder, folderIdToMatch, path)) {
          isBreak = true;
          break;
        }
      }

      if (isBreak) {
        return true;
      } else {
        path.pop();
        return false;
      }
    }
  }

  menuGoToFolder(folder: FolderTree) {
    this.contentDataService.menuGoToFolder(folder);
  }

  createFolder() {
    const dialogData: FolderPayload = {
      isCreate: true,
      name: null,
      description: this.ts.instant("library.messages.folderForLibrary"),
      cabinetRefId: this.cabinetId,
      parentFolderRefId: this.currentFolderId,
      projectId: this.projectId,
      additionalInfo: null,
      status: true,
    };
    const dialogRef = this.createFolderDialog.open(NewFolderComponent, {
      width: "35%",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.contentDataService
          .getProjectFolderTree(this.companyId, this.projectId, "library")
          .subscribe({
            next: (folderTree) => {
              this.folderTree = folderTree;
              this.contentDataService.refreshFiles(true);
            },
          });
      }
    });
  }

  generateFileObjectId(fileName) {
    const fileObjectId = uuidv4();

    if (fileName.includes(".")) {
      return fileObjectId + "." + fileName.split(".").pop();
    } else {
      return fileObjectId;
    }
  }

  deleteBulk() {
    this.contentDataService.sendDeleteBulk();
  }

  downloadBulk() {
    this.contentDataService.sendDownloadBulk();
  }

  toggleThumbnailView() {
    this.isThumbnailView = !this.isThumbnailView;
    const thumbnailView: ThumbnailView =
      this.localStorage.getItem("libThumbnailView");

    if (thumbnailView) {
      thumbnailView.enabled = this.isThumbnailView;
      this.localStorage.setItem("libThumbnailView", thumbnailView);
    }

    this.contentDataService.toggleThumbnailView(this.isThumbnailView);
  }

  assignTotalFilesCount(total: number) {
    if (total === 1) {
      this.totalFilesMsg = eval(
        "`" + this.ts.instant("library.messages.nFile") + "`"
      );
    } else {
      this.totalFilesMsg = eval(
        "`" + this.ts.instant("library.messages.nFiles") + "`"
      );
    }
  }

  selectAll(checked) {
    this.isAllSelected = checked;
    this.isIndeterminate = false;
    this.contentDataService.sendSelectAllToChild(checked);
  }

  editCategoryChanged() {
    this.errorMsg = "";
  }

  addCategoryChanged() {
    this.errorMsg = "";
  }

  applySearchFilter(filterValue: string) {
    this.contentDataService.sendLibraryFilter(filterValue.trim().toLowerCase());
  }

  handleVersionFileInput(event) {
    this.versionFile = event.target.files;
    this.versionFileSelected = true;
    this.versionUploadProgressPercent = 0;
    this.versionFileNameInput.nativeElement.value = this.versionFile[0].name;
    this.errorMsg = "";
  }

  getSuggestedVersionNumbers(file: FileGrid) {
    const currentVersion: FileVersion = file.versions.sort(
      (a, b) =>
        parseFloat(b.versionNumber.$numberDecimal) -
        parseFloat(a.versionNumber.$numberDecimal)
    )[0];
    const versionNumber: string = currentVersion.versionNumber.$numberDecimal;
    this.currentVersionToDisplay = eval(
      "`" + this.ts.instant("library.messages.versionNumber") + "`"
    );
    this.currentShortVersionToDisplay =
      currentVersion.versionNumber.$numberDecimal;
    const [majorVersion, minorVersion]: number[] =
      currentVersion.versionNumber.$numberDecimal
        .split(".")
        .map((item) => parseInt(item));
    this.currentMajorVersion = majorVersion;
    this.currentMinorVersion = minorVersion;

    if (this.currentMajorVersion === this.MAX_MAJOR_VERSION) {
      this.suggestedMajorVersion = this.MAX_MAJOR_VERSION;

      if (this.currentMinorVersion === this.MAX_MINOR_VERSION) {
        this.suggestedMinorVersion = this.MAX_MINOR_VERSION;
      } else {
        if (this.fileMode === this.fileModes.EDIT) {
          this.suggestedMinorVersion = this.currentMinorVersion;
        } else {
          //Upload new version
          this.suggestedMinorVersion = this.currentMinorVersion + 1;
        }
      }
    } else {
      if (this.fileMode === this.fileModes.EDIT) {
        this.suggestedMajorVersion = this.currentMajorVersion;
        this.suggestedMinorVersion = this.currentMinorVersion;
      } else {
        this.suggestedMajorVersion = this.currentMajorVersion + 1;
        this.suggestedMinorVersion = 0;
      }
    }
  }

  uploadNewVersion() {
    const fileName: string =
      this.versionFileNameInput.nativeElement.value.trim();
    const newMajorVersionNumber: number = parseInt(
      this.majorVersionInput.nativeElement.value.trim()
    );
    const newMinorVersionNumber: number = parseInt(
      this.minorVersionInput.nativeElement.value.trim()
    );
    const newVersionNumber =
      newMajorVersionNumber.toString() + "." + newMinorVersionNumber.toString();

    if (!this.versionFile) {
      this.errorMsg = this.ts.instant("library.messages.selectVersionFile");
      return;
    }

    if (!this.validateFileName(fileName)) return;
    if (!this.validateFileExtensionForNewVersion(fileName)) return;

    if (
      !this.validateVersionNumberForVersionUpload(
        newMajorVersionNumber,
        newMinorVersionNumber
      )
    )
      return;

    const versionFileObjectId = this.generateFileObjectId(
      this.uploadVersionFile.name
    );
    const fileVersionUploadUrlPayload: FileVersionUploadUrlPayload = {
      fileId: this.uploadVersionFile.id,
      versionFileObjectId,
    };

    this.uiService.show();
    this.versionUploadProgressPercent = 0;
    this.isVersionUploading = true;
    this.contentDataService
      .createFileVersionUploadUrl(fileVersionUploadUrlPayload)
      .subscribe({
        next: (data) => {
          this.contentDataService
            .uploadFileS3(data.versionUploadUrl, this.versionFile[0], {
              reportProgress: true,
              observe: "events",
            })
            .subscribe({
              next: (event: HttpEvent<any>) => {
                switch (event.type) {
                  case HttpEventType.UploadProgress:
                    this.showVersionUploadProgress(
                      this.uploadType.S3,
                      event.loaded,
                      event.total
                    );
                }
              },
              error: () => {
                this.snackService.errorSnackBar(
                  this.ts.instant("library.messages.saveFailed")
                );
                this.isVersionUploading = false;
                this.uiService.hide();
              },
              complete: () => {
                const updateFileVersionPayload: UpdateFileVersionPayload = {
                  fileId: this.uploadVersionFile.id,
                  name: fileName,
                  fileSize: this.versionFile[0].size.toString(),
                  versionFileObjectId,
                  versionNumber: newVersionNumber,
                };

                this.contentDataService
                  .updateFileVersion(updateFileVersionPayload)
                  .subscribe({
                    next: async () => {
                      this.showVersionUploadProgress(
                        this.uploadType.STATUS,
                        100,
                        100
                      );

                      this.contentDataService.refreshFiles(true);
                      this.snackService.successSnackBar(
                        this.ts.instant("library.messages.newVersionUploaded")
                      );
                      await this.stall(1000);
                      this.closeSidePanel();
                      this.versionFile = null;
                      this.versionFileSelected = false;
                      this.isVersionUploading = false;
                      this.currentVersionToDisplay = "";
                      this.currentShortVersionToDisplay = "";
                      this.currentMajorVersion = 0;
                      this.currentMinorVersion = 0;
                      this.suggestedMajorVersion = 0;
                      this.suggestedMinorVersion = 0;
                      this.versionFileNameInput.nativeElement.value = "";
                      this.versionUploadProgressPercent = 0;
                      this.uiService.hide();
                    },
                    error: () => {
                      this.snackService.errorSnackBar(
                        this.ts.instant("library.messages.saveFailed")
                      );
                      this.isVersionUploading = false;
                      this.uiService.hide();
                    },
                  });
              },
            });
        },
        error: () => {
          this.uiService.hide();
          this.snackService.errorSnackBar(
            this.ts.instant("library.messages.saveFailed")
          );
          this.isVersionUploading = false;
          this.uiService.hide();
        },
      });
  }

  validateVersionNumberForVersionUpload(
    newMajorVersion: number,
    newMinorVersion: number
  ) {
    if (
      this.currentMajorVersion === this.MAX_MAJOR_VERSION &&
      this.currentMinorVersion === this.MAX_MINOR_VERSION
    ) {
      this.errorMsg = this.ts.instant(
        "library.messages.maxVersionNumberReached"
      );
      return false;
    } else if (
      newMajorVersion < 0 ||
      newMajorVersion > this.MAX_MAJOR_VERSION
    ) {
      const max: number = this.MAX_MAJOR_VERSION;
      this.errorMsg = eval(
        "`" + this.ts.instant("library.messages.majorVersionOutOfRange") + "`"
      );
      return false;
    } else if (
      newMinorVersion < 0 ||
      newMinorVersion > this.MAX_MINOR_VERSION
    ) {
      const max: number = this.MAX_MINOR_VERSION;
      this.errorMsg = eval(
        "`" + this.ts.instant("library.messages.minorVersionOutOfRange") + "`"
      );
      return false;
    } else {
      if (
        newMajorVersion + newMinorVersion / 10 <=
        this.currentMajorVersion + this.currentMinorVersion / 10
      ) {
        this.errorMsg = this.ts.instant(
          "library.messages.selectHigherVersionNumber"
        );
        return false;
      }
    }

    this.errorMsg = "";
    return true;
  }

  validateVersionNumberForFileEdit(
    newMajorVersion: number,
    newMinorVersion: number
  ) {
    if (newMajorVersion < 0 || newMajorVersion > this.MAX_MAJOR_VERSION) {
      const max: number = this.MAX_MAJOR_VERSION;
      this.errorMsg = eval(
        "`" + this.ts.instant("library.messages.majorVersionOutOfRange") + "`"
      );
      return false;
    } else if (
      newMinorVersion < 0 ||
      newMinorVersion > this.MAX_MINOR_VERSION
    ) {
      const max: number = this.MAX_MINOR_VERSION;
      this.errorMsg = eval(
        "`" + this.ts.instant("library.messages.minorVersionOutOfRange") + "`"
      );
      return false;
    } else {
      if (
        newMajorVersion + newMinorVersion / 10 <
        this.currentMajorVersion + this.currentMinorVersion / 10
      ) {
        this.errorMsg = this.ts.instant(
          "library.messages.selectLowerVersionNumber"
        );
        return false;
      }
    }

    this.errorMsg = "";
    return true;
  }

  showVersionUploadProgress(type: number, loaded: number, total: number) {
    if (!total) return;

    let progressPercent = Math.floor((loaded * 100) / total);
    let prevProgressPercent: number = this.versionUploadProgressPercent;

    if (type === this.uploadType.S3 && Math.floor(progressPercent) === 100)
      return; //Show complete only after status update

    if (
      Math.floor(progressPercent / 10) > Math.floor(prevProgressPercent / 10)
    ) {
      this.versionUploadProgressPercent = progressPercent;
    }
  }

  async stall(delay) {
    await new Promise((resolve) => {
      setTimeout(resolve, delay);
    });
  }
}
export interface UploadType {
  S3: number;
  STATUS: number;
}

export interface FileMode {
  ADD: number;
  EDIT: number;
  NEW_VERSION: number;
  CLOSED: number;
}

export interface ResponseCodes {
  SUCCESS: string;
  ALREADY_EXISTS: string;
}
