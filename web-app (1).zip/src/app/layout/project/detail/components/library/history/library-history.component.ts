import { MatTableDataSource } from "@angular/material/table";
import {
  ContentDataService,
  FileVersion,
  FileGrid,
  UiService,
} from "src/app/core";
import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import moment from "moment";
import { TranslateService } from "@ngx-translate/core";
import { DocumentViewerComponent } from "../viewer/viewer.component";
import { MatSort } from "@angular/material/sort";
const FileSaver = require("file-saver");

@Component({
  selector: "app-library-history",
  templateUrl: "./library-history.component.html",
  styleUrls: ["./library-history.component.scss"],
})
export class LibraryHistoryComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  dataSource: MatTableDataSource<FileVersion>;
  gridData: FileVersion[];
  readonly columnsToDisplay: string[] = [
    "name",
    "size",
    "lastModified",
    "action",
  ];
  readonly tooltipDelay: number = 200;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: FileGrid,
    private ts: TranslateService,
    private contentDataService: ContentDataService,
    private uiService: UiService
  ) {
    this.dataSource = new MatTableDataSource<FileVersion>();
  }

  ngOnInit(): void {
    this.gridData = this.data.versions;

    this.gridData.forEach((item) => {
      item.updatedAtMoment = moment(new Date(item.updatedDatetime)).fromNow();
      item.fileSizeReadable = this.getReadableFileSize(item.fileSize);
    });

    this.gridData.sort(
      (a, b) =>
        parseFloat(b.versionNumber.$numberDecimal) -
        parseFloat(a.versionNumber.$numberDecimal)
    );

    this.dataSource.data = this.gridData;
    this.sortingDataAccessor();
    setTimeout(() => {
      this.dataSource.sort = this.sort;
    });
  }

  sortingDataAccessor() {
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case "name":
          return item.versionName.toString().toLocaleLowerCase();
        case "lastModified":
          return new Date(item.updatedDatetime).getTime().toString();
        case "size":
          return parseInt(item.fileSize ? item.fileSize : "0");
        default:
          return item[property]?.toString().toLocaleLowerCase();
      }
    };
  }

  openFile(element: FileVersion) {
    this.downloadFile(element);
    /*if (this.getExt(element.versionName) === "pdf") {
      this.openViewer(element);
    } else {
      this.downloadFile(element);
    }*/
  }

  openViewer(element: FileVersion): void {
    this.uiService.show();
    this.contentDataService
      .getFileDownloadUrl(
        this.data.id,
        element.versionFileObjectId,
        element.versionName
      )
      .subscribe({
        next: (data) => {
          this.uiService.hide();

          if (data.downloadUrl) {
            this.dialog.open(DocumentViewerComponent, {
              width: "60%",
              position: { top: ".5em" },
              disableClose: true,
              panelClass: "dialog-box",
              data: { url: data.downloadUrl },
            });
          }
        },
        error: () => {
          this.uiService.hide();
        },
      });
  }

  downloadFile(element: FileVersion) {
    this.uiService.show();
    this.contentDataService
      .getFileDownloadUrl(
        this.data.id,
        element.versionFileObjectId,
        element.versionName
      )
      .subscribe({
        next: (data) => {
          if (data.downloadUrl) {
            FileSaver.saveAs(data.downloadUrl);
          }

          this.uiService.hide();
        },
        error: () => {
          this.uiService.hide();
        },
      });
  }

  getExt(filename) {
    const dot_pos = filename.lastIndexOf(".");
    if (dot_pos == -1) {
      return "";
    }
    return filename.substr(dot_pos + 1).toLowerCase();
  }

  getReadableFileSize(fileSize: string) {
    const incomingSize = parseInt(fileSize);
    let size: string;

    if (isNaN(incomingSize)) {
      return "";
    } else {
      if (incomingSize >= 1024 * 1024 * 1024) {
        size = (incomingSize / (1024 * 1024 * 1024)).toFixed(1);
        return eval(
          "`" + this.ts.instant("libraryHistory.labels.sizeGB") + "`"
        );
      } else if (incomingSize >= 1024 * 1024) {
        size = (incomingSize / (1024 * 1024)).toFixed(1);
        return eval(
          "`" + this.ts.instant("libraryHistory.labels.sizeMB") + "`"
        );
      } else if (incomingSize >= 1024) {
        size = (incomingSize / 1024).toFixed(0);
        return eval(
          "`" + this.ts.instant("libraryHistory.labels.sizeKB") + "`"
        );
      } else {
        size = incomingSize.toString();
        return eval(
          "`" + this.ts.instant("libraryHistory.labels.sizeBytes") + "`"
        );
      }
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
