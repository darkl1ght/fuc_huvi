import { Component, OnInit, Input, OnChanges } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import {
  User,
  UserService,
  ContentDataService,
  ProjectUserService,
  ProjectUser,
  FileComment,
  AddFileCommentPayload,
  ProjectService,
} from "src/app/core";
import { map, catchError, finalize } from "rxjs/operators";
import { throwError } from "rxjs";
import { v4 as uuidv4 } from "uuid";

@Component({
  selector: "library-discussion",
  templateUrl: "./library-discussion.component.html",
  styleUrls: ["./library-discussion.component.scss"],
})
export class LibraryDiscussionComponent implements OnInit, OnChanges {
  @Input() projectId: string;
  @Input() fileId: string;
  comment: string = "";
  members: ProjectUser[] = [];
  comments: FileComment[] = [];
  mentionItems: any[] = [];
  allowDropUp: boolean = false;
  user: User = {} as User;
  errors: any;
  projectName: string;
  projectUsers: ProjectUser[] = [];

  constructor(
    public dialog: MatDialog,
    private contentDataService: ContentDataService,
    private userSvc: UserService,
    private projectUserSvc: ProjectUserService,
    private projectService: ProjectService
  ) {}

  public ngOnInit(): void {
    this.user = this.userSvc.getCurrentUser();
    this.getComments();
  }

  ngOnChanges() {
    this.getComments();

    if (this.projectId) {
      this.getProjectUserData(this.projectId);
    }
  }

  addComment() {
    this.comment = this.comment.trim();

    if (this.comment) {
      this.projectService.get(this.projectId).subscribe({
        next: (project) => {
          this.projectName = project.projectName;
          this.projectUsers = project.users;
          const payLoad: AddFileCommentPayload = {
            commentId: uuidv4(),
            comment: this.comment,
            projectName: this.projectName,
            projectUsers: this.projectUsers,
          };
          this.contentDataService
            .addComment(this.fileId, payLoad)
            .pipe(
              map(() => {
                this.comment = "";
                this.getComments();
              }),
              catchError(this.handleError),
              finalize(() => {})
            )
            .subscribe();
        },
      });
    }
  }

  getComments() {
    this.contentDataService
      .getComments(this.fileId)
      .pipe(
        map((data) => {
          this.comments = this.sortComments(data);
        }),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  deleteComment(comment) {
    this.contentDataService
      .deleteComment(this.fileId, comment.commentId)
      .pipe(
        map(() => {
          this.getComments();
        }),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  getProjectUserData(projectId) {
    this.projectUserSvc.getAll(projectId).subscribe(
      (data) => {
        this.members = data.users;
        this.setMentionData(this.members);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  setMentionData(users: ProjectUser[]) {
    this.mentionItems = [];
    users.forEach((element) => {
      this.mentionItems.push({
        tag:
          element.firstName +
          " " +
          element.lastName +
          " [" +
          element.role.desc +
          "]",
        display: element.email,
      });
    });
  }

  sortComments(comments) {
    if (comments) {
      comments.sort(function (a, b) {
        return +new Date(a.createdAt) - +new Date(b.createdAt);
      });
    }

    return comments;
  }

  private handleError(error: any) {
    return throwError(error);
  }

  itemMentioned(tag) {
    return tag.display;
  }
}
