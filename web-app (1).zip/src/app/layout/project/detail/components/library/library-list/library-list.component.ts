import { forkJoin, Subscription, throwError } from "rxjs";
import { MatTableDataSource } from "@angular/material/table";
import { MatDialog } from "@angular/material/dialog";
import { MatSort } from "@angular/material/sort";
import {
  ContentDataService,
  FolderTree,
  Folder,
  FileGrid,
  FileId,
  FolderId,
  DeleteFileBulk,
  DeleteFolderBulk,
  DeleteFolder,
  LocalStorageService,
  ThumbnailView,
  FolderPayload,
  UiService,
  PaginatePayload,
  ImageViewerData,
  ProjectService,
  ShareService,
  PdfViewerData,
  SnackbarService,
} from "src/app/core";
import { Component, OnInit, OnDestroy, ViewChild, Inject } from "@angular/core";
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from "@angular/animations";
import {
  ConfirmAlertComponent,
  ConfirmAlertModel,
} from "src/app/layout/components/confirm-alert/confirm-alert.component";
import { TranslateService } from "@ngx-translate/core";
import { catchError, finalize, map } from "rxjs/operators";
import moment from "moment";
import { DocumentViewerComponent } from "../viewer/viewer.component";
const FileSaver = require("file-saver");
import JSZip from "jszip";
import { NewFolderComponent } from "../../new-folder/new-folder.component";
import { LibraryTagComponent } from "../tag/library-tag.component";
import { LibraryHistoryComponent } from "../history/library-history.component";
import { LibraryImageViewerComponent } from "../image-viewer/library-image-viewer.component";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { Clipboard } from "@angular/cdk/clipboard";
import { MatMenuTrigger } from "@angular/material/menu";

@Component({
  selector: "app-document-list",
  templateUrl: "./library-list.component.html",
  styleUrls: ["./library-list.component.scss"],
  animations: [
    trigger("detailExpand", [
      state("collapsed", style({ height: "0px", minHeight: "0" })),
      state("expanded", style({ height: "*" })),
      transition(
        "expanded <=> collapsed",
        animate("225ms cubic-bezier(0.4, 0.0, 0.2, 1)")
      ),
    ]),
  ],
})
export class LibraryListComponent implements OnInit, OnDestroy {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild("trigger") trigger: MatMenuTrigger;
  folderId: string;
  projectFolder: Folder;
  dataSource: MatTableDataSource<FileGrid>;
  gridData: FileGrid[] = [];
  gridDataThumbnailViewFile: FileGrid[] = [];
  gridDataThumbnailViewFolder: FileGrid[] = [];
  readonly columnsToDisplay: string[] = [
    "select",
    "name",
    "uploadedDate",
    "category",
    "lastModified",
    "annotations",
    "actions",
  ];
  readonly months: string[] = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  isLoading: boolean = false;
  isAllSelected: boolean = false;
  expandedElement: any;
  refreshLibrarySubscription: Subscription;
  menuGoToFolderSubscription: Subscription;
  bulkDeleteSubscription: Subscription;
  selectAllToChildSubscription: Subscription;
  bulkDownloadSubscription: Subscription;
  toggleThumbnailViewSubscription: Subscription;
  libraryFilterSubscription: Subscription;
  folderIdParam: string;
  projectId: string;
  cabinetId: string;
  isThumbnailView: boolean = false;
  fileExpansionPanelOpenState: boolean = true;
  folderExpansionPanelOpenState: boolean = true;
  totalFoldersMsg: string;
  totalFilesMsg: string;
  errors: any;
  readonly CATEGORY: string = this.ts.instant("library.labels.category");
  readonly OTHER_CATEGORY = this.ts.instant("library.labels.otherCategory");
  readonly itemTypes: ItemType = {
    FILE: "file",
    FOLDER: "folder",
  };
  isIndeterminate: boolean = false;
  readonly tooltipDelay: number = 200;
  searchText: string = "";
  page_number: number = 1;
  completeRecords: boolean = false;
  readonly PAGE_LIMIT: number = 20;
  paginatePayload: PaginatePayload = {
    sortBy: "updatedAt",
    sortDirection: -1,
    limit: this.PAGE_LIMIT,
    page: 1,
    folderCount: 0,
  };
  isVirtualScrollFetch: boolean = false;
  totalFolderCount: number = 0;
  totalFileCount: number = 0;
  companyId: string;
  isOpen: boolean = false;
  shareLink: string = null;
  fileId: string;

  constructor(
    private contentDataService: ContentDataService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private projectService: ProjectService,
    private dialog: MatDialog,
    private uiService: UiService,
    private ts: TranslateService,
    private snackService: SnackbarService,
    private localStorageService: LocalStorageService,
    private shareService: ShareService,
    private localStorage: LocalStorageService,
    private projectSvc: ProjectService,
    private clipboard: Clipboard
  ) {
    this.dataSource = new MatTableDataSource<FileGrid>();
  }

  ngOnInit(): void {
    this.isLoading = true;
    this.companyId = this.localStorageService.getClientId();
    this.projectId = this.localStorageService.getProjectId();

    const libThumbnailView: ThumbnailView =
      this.localStorageService.getItem("libThumbnailView");
    this.sortingDataAccessor();
    this.dataSource.filterPredicate = (data, filterValue) => {
      filterValue = filterValue.trim().toLowerCase();
      return (
        data.name.toLowerCase().includes(filterValue) ||
        data.category?.toLowerCase().includes(filterValue) ||
        data.lastModifiedBy.toLowerCase().includes(filterValue) ||
        !!data.tagList?.find((item) => item.toLowerCase().includes(filterValue))
      );
    };

    if (libThumbnailView) {
      this.isThumbnailView = libThumbnailView.enabled;
      this.fileExpansionPanelOpenState = libThumbnailView.file;
      this.folderExpansionPanelOpenState = libThumbnailView.folder;
    } else {
      const thumbnailView: ThumbnailView = {
        enabled: false,
        folder: true,
        file: true,
      };

      this.localStorageService.setItem("libThumbnailView", thumbnailView);
    }

    const projFolder = this.contentDataService.getProjectFolder(
      this.companyId,
      this.projectId,
      "library"
    );
    const projFolderTree = this.contentDataService.getProjectFolderTree(
      this.companyId,
      this.projectId,
      "library"
    );
    this.uiService.show();

    forkJoin([projFolder, projFolderTree])
      .pipe(
        map(async (results) => {
          this.projectFolder = results[0].folder;
          this.folderId = !!this.folderId
            ? this.folderId
            : this.projectFolder.id;
          this.localStorageService.setLibraryFolderId(this.folderId);
          this.cabinetId = results[0].folder.cabinetRefId;
          this.contentDataService.sendProjectFolderTreeToParent(results[1]);
          this.contentDataService.sendCurrentFolderId(this.folderId);
          this.fetchGridData(true);
          await this.stall(300);
          await this.loadSharedLibraryInfo();
          this.uiService.hide();
        }),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();

    this.refreshLibrarySubscription =
      this.contentDataService.refreshFiles$.subscribe({
        next: (showSpinner) => {
          this.fetchGridData(showSpinner);
        },
      });

    this.toggleThumbnailViewSubscription =
      this.contentDataService.thumbnailView$.subscribe({
        next: (isThumbnailView: boolean) => {
          this.isThumbnailView = isThumbnailView;
        },
      });

    this.menuGoToFolderSubscription =
      this.contentDataService.menuGoToFolder$.subscribe({
        next: (folder) => {
          this.openFolder(folder);
        },
      });

    this.bulkDeleteSubscription = this.contentDataService.deleteBulk$.subscribe(
      {
        next: (isDelete) => {
          if (isDelete) {
            this.deleteBulk();
          }
        },
      }
    );

    this.libraryFilterSubscription =
      this.contentDataService.libraryFilter$.subscribe({
        next: (filterValue) => {
          this.searchText = filterValue.trim().toLowerCase();
          this.dataSource.filter = this.searchText;
          this.filterThumbnail(this.searchText);
        },
      });

    this.bulkDownloadSubscription =
      this.contentDataService.downloadBulk$.subscribe({
        next: (download) => {
          if (download) {
            this.downloadBulk();
          }
        },
      });

    this.selectAllToChildSubscription =
      this.contentDataService.selectAllToChild$.subscribe({
        next: (isSelectAll: boolean) => {
          this.isAllSelected = isSelectAll;
          this.isIndeterminate = false;

          for (const item of this.gridData) {
            item.isSelected = isSelectAll;
          }
        },
      });
  }

  ngOnDestroy(): void {
    this.refreshLibrarySubscription.unsubscribe();
    this.menuGoToFolderSubscription.unsubscribe();
    this.bulkDeleteSubscription.unsubscribe();
    this.toggleThumbnailViewSubscription.unsubscribe();
    this.selectAllToChildSubscription.unsubscribe();
    this.libraryFilterSubscription.unsubscribe();
    this.bulkDownloadSubscription.unsubscribe();
  }

  loadSharedLibraryInfo() {
    //code to view shared info
    const shareId = this.localStorage.getShareId();
    if (!!shareId) {
      const sharedObject = this.shareService.getShareObject();
      const fileShared = sharedObject.data;
      this.localStorage.removeShareId();
      this.shareService.setShareObject(null);
      this.isVirtualScrollFetch = true;
      this.shareService.refreshToolbar(true);
      this.contentDataService.getFileById(sharedObject.fileId).subscribe({
        next: (file: any) => {
          file.type = this.itemTypes.FILE;
          this.openFile(file, true);
          this.isVirtualScrollFetch = false;
        },
        error: () => {
          this.uiService.hide();
        },
      });
    }
  }

  fetchGridData(showSpinner: boolean, pageNumber: number = 1) {
    this.isLoading = true;
    let gridDataItem: FileGrid;
    let gridData: FileGrid[] = [];
    this.page_number = pageNumber;
    this.paginatePayload = {
      ...this.paginatePayload,
      page: this.page_number,
      folderCount: this.gridData.filter(
        (item) => item.type === this.itemTypes.FOLDER
      ).length,
    };

    if (showSpinner) {
      this.uiService.show();
    }
    if (pageNumber > 1) {
      this.isVirtualScrollFetch = true;
    }

    this.contentDataService
      .getFilesByPagination(this.folderId, this.paginatePayload)
      .subscribe({
        next: (data) => {
          for (const item of data.folders) {
            gridDataItem = {
              type: this.itemTypes.FOLDER,
              id: item.id,
              isSelected: false,
              fileCount: item.fileCount,
              folderCount: item.folderCount,
              parentFolderRefId: item.parentFolderRefId,
              name: item.name,
              downloadUrl: null,
              viewUrl: null,
              thumbnailUrl: null,
              lastModifiedBy: item.updatedBy,
              updatedAt: this.getUpdatedAt(
                item.updatedAt,
                item.migratedOn,
                item.migratedUpdatedOn,
                item.updatedOn
              ),
              createdAt: item.createdAt,
              lastModifiedDate: moment(
                this.getUpdatedAt(
                  item.updatedAt,
                  item.migratedOn,
                  item.migratedUpdatedOn,
                  item.updatedOn
                )
              ).fromNow(),
            };

            gridData.push(gridDataItem);
          }

          for (const item of data.files) {
            gridDataItem = {
              type: this.itemTypes.FILE,
              icon: this.getFileIcon(item.name),
              id: item.id,
              fileObjectId: item.fileObjectId,
              description: item.description,
              isSelected: false,
              fileCount: null,
              folderCount: null,
              name: item.name,
              parentFolderRefId: item.parentFolderRefId,
              metadata: item.metadata,
              category: item.metadata.find(
                (meta) => meta.label === this.CATEGORY
              )?.value,
              otherCategory:
                item.metadata.find((meta) => meta.label === this.CATEGORY)
                  ?.value === "Other"
                  ? item.metadata.find((meta) => meta.label === "Other Reason")
                      ?.value
                  : null,
              downloadUrl: item.downloadUrl,
              viewUrl: item.viewUrl,
              thumbnailUrl: item.viewUrl,
              isThumbnailLoaded: false,
              tagList: item.tagList,
              lastModifiedBy: item.updatedBy,
              updatedAt: this.getUpdatedAt(
                item.updatedAt,
                item.migratedOn,
                item.migratedUpdatedOn,
                item.updatedOn
              ),
              createdAt: item.createdAt,
              lastModifiedDate: moment(
                this.getUpdatedAt(
                  item.updatedAt,
                  item.migratedOn,
                  item.migratedUpdatedOn,
                  item.updatedOn
                )
              ).fromNow(),
              versions: item.versions,
              currentVersion: Math.max(
                ...item.versions.map((value) =>
                  parseFloat(value.versionNumber.$numberDecimal)
                )
              )
                .toFixed(1)
                .toString(),
              annotations: item.annotations,
              features: item.features,
              comments: item.comments,
              tags: item.tags,
            };
            gridData.push(gridDataItem);
          }

          if (pageNumber === 1) {
            this.totalFolderCount = data.totalFolderCount;
            this.totalFileCount = data.totalFileCount;
          }

          if (gridData.length === 0 && pageNumber > 1) {
            this.page_number = this.page_number - 1;
          }

          this.gridData =
            pageNumber === 1 ? gridData : [...this.gridData, ...gridData];
          this.gridDataThumbnailViewFolder = [
            ...this.gridData
              .filter((item) => item.type === this.itemTypes.FOLDER)
              .sort((a, b) => a.name.localeCompare(b.name)),
          ];
          this.gridDataThumbnailViewFile = [
            ...this.gridData
              .filter((item) => item.type === this.itemTypes.FILE)
              .sort((a, b) => a.name.localeCompare(b.name)),
          ];
          this.dataSource.data = this.gridData;

          if (pageNumber === 1) {
            this.isAllSelected = false;
            this.contentDataService.sendSelectAllToParent(this.isAllSelected);
            this.contentDataService.sendAnySelected(false);
            this.isIndeterminate = false;
            this.contentDataService.sendIndeterminateToParent(
              this.isIndeterminate
            );
          } else {
            if (gridData.length > 0) {
              if (this.isAllSelected) {
                this.isAllSelected = false;
                this.contentDataService.sendSelectAllToParent(
                  this.isAllSelected
                );
                this.isIndeterminate = true;
                this.contentDataService.sendIndeterminateToParent(
                  this.isIndeterminate
                );
              }
            }
          }

          this.contentDataService.sendRecordCountStatus({
            count: this.gridData.length,
            total: this.totalFolderCount + this.totalFileCount,
          });

          this.dataSource.sort = this.sort;
          this.filterThumbnail(this.searchText);
          this.isLoading = false;
          if (showSpinner) {
            this.uiService.hide();
          }
          if (pageNumber > 1) {
            this.isVirtualScrollFetch = false;
          }
        },
        error: () => {
          this.isLoading = false;
          this.snackService.errorSnackBar(
            this.ts.instant("library.messages.fetchFailed")
          );
          if (showSpinner) {
            this.uiService.hide();
          }
          if (pageNumber > 1) {
            this.isVirtualScrollFetch = false;
            this.page_number = this.page_number - 1;
          }
        },
      });
  }

  onScrollDown() {
    if (
      this.gridData.length < this.page_number * this.PAGE_LIMIT ||
      this.gridData.length === this.totalFolderCount + this.totalFileCount
    ) {
      return;
    }
    this.fetchGridData(false, this.page_number + 1);
  }

  getUpdatedAt(
    updatedAt: Date,
    migratedOn: Date,
    migratedUpdatedOn: Date,
    updatedOn: Date
  ) {
    if (!!updatedOn) return new Date(updatedOn);
    if (migratedOn && migratedUpdatedOn && updatedAt) {
      if (
        new Date(updatedAt).toLocaleDateString("en-US") ==
        new Date(migratedOn).toLocaleDateString("en-US")
      ) {
        return new Date(migratedUpdatedOn);
      }
    }

    return new Date(updatedAt);
  }

  async stall(delay) {
    await new Promise((resolve) => {
      setTimeout(resolve, delay);
    });
  }

  openAddFilesPanel() {
    this.contentDataService.openAddFilesPanel();
  }

  getFormattedDate(date: Date) {
    return `${
      this.months[date.getMonth()]
    } ${date.getDate()}, ${date.getFullYear()}`;
  }

  selectAll(checked) {
    this.isAllSelected = checked;
    this.contentDataService.sendSelectAllToParent(checked);
    this.isIndeterminate = false;
    this.contentDataService.sendIndeterminateToParent(this.isIndeterminate);
    this.contentDataService.sendAnySelected(checked);

    for (const item of this.gridData) {
      item.isSelected = checked;
    }
  }

  selectOne(event: any, element: FileGrid) {
    element.isSelected = event.checked;

    if (event.checked) {
      if (this.gridData.filter((item) => !item.isSelected).length == 0) {
        this.isAllSelected = true;
        this.contentDataService.sendSelectAllToParent(this.isAllSelected);
        this.isIndeterminate = false;
        this.contentDataService.sendIndeterminateToParent(this.isIndeterminate);
      } else {
        this.isIndeterminate = true;
        this.contentDataService.sendIndeterminateToParent(this.isIndeterminate);
      }

      this.contentDataService.sendAnySelected(true);
    } else {
      if (this.gridData.find((item) => item.isSelected)) {
        this.isIndeterminate = true;
        this.contentDataService.sendIndeterminateToParent(this.isIndeterminate);
        this.contentDataService.sendAnySelected(true);
      } else {
        this.isIndeterminate = false;
        this.contentDataService.sendIndeterminateToParent(this.isIndeterminate);
        this.contentDataService.sendAnySelected(false);
      }

      this.isAllSelected = false;
      this.contentDataService.sendSelectAllToParent(this.isAllSelected);
    }
  }

  filterThumbnail(filterValue: string) {
    this.gridDataThumbnailViewFolder = [
      ...this.gridData
        .filter(
          (item) =>
            item.type === this.itemTypes.FOLDER &&
            item.name.toLowerCase().includes(filterValue)
        )
        .sort((a, b) => a.name.localeCompare(b.name)),
    ];
    this.gridDataThumbnailViewFile = [
      ...this.gridData
        .filter(
          (item) =>
            (item.type === this.itemTypes.FILE &&
              item.name.toLowerCase().includes(filterValue)) ||
            !!item.tagList?.find((item) =>
              item.toLowerCase().includes(filterValue)
            )
        )
        .sort((a, b) => a.name.localeCompare(b.name)),
    ];
    this.assignTotalFoldersCount(this.gridDataThumbnailViewFolder.length);
    this.assignTotalFilesCount(this.gridDataThumbnailViewFile.length);
  }

  sortingDataAccessor() {
    this.dataSource.sortingDataAccessor = (item, property) => {
      let folderSort: string;
      let fileSort: string;

      if (this.sort.direction == "desc") {
        folderSort = "2";
        fileSort = "1";
      } else {
        folderSort = "1";
        fileSort = "2";
      }

      switch (property) {
        case "lastModified":
          return item.type === "folder"
            ? folderSort + item.updatedAt.getTime().toString()
            : fileSort + item.updatedAt.getTime().toString();
        case "uploadedDate":
          return item.type === "folder"
            ? folderSort + new Date(item.createdAt).getTime().toString()
            : fileSort + new Date(item.createdAt).getTime().toString();
        default:
          return item.type === "folder"
            ? folderSort + item[property]?.toString().toLocaleLowerCase()
            : fileSort + item[property]?.toString().toLocaleLowerCase();
      }
    };
  }

  showHistory(element: FileGrid) {
    const dialogRef = this.dialog.open(LibraryHistoryComponent, {
      width: "70%",
      disableClose: true,
      data: element,
      panelClass: "dialog-box",
    });
    dialogRef.afterClosed().subscribe((dialogResult) => {});
  }

  openFolder(element: FileGrid | FolderTree) {
    this.folderId = element.id;
    this.localStorageService.setLibraryFolderId(this.folderId);
    this.contentDataService.sendCurrentFolderId(this.folderId);
    this.fetchGridData(true);
  }

  openObject(element: FileGrid) {
    if (element.type === this.itemTypes.FOLDER) {
      this.openFolder(element);
    } else {
      this.openFile(element, false);
    }
  }

  deleteOneMenuClick(element: FileGrid) {
    this.getUserConfirmationOnDelete().subscribe({
      next: (confirm) => {
        if (confirm) {
          if (element.type === this.itemTypes.FILE) {
            this.uiService.show();
            this.contentDataService.deleteFileById(element.id).subscribe({
              next: () => {
                this.uiService.hide();

                this.snackService.successSnackBar(
                  this.ts.instant("library.messages.fileDeleted")
                );
                this.fetchGridData(true);
              },
              error: () => {
                this.uiService.hide();
                this.snackService.errorSnackBar(
                  this.ts.instant("library.messages.deleteFailed")
                );
              },
            });
          } else if (element.type === this.itemTypes.FOLDER) {
            const deleteFolderPayload: DeleteFolder = {
              isSoftDelete: true,
              projectId: this.projectId,
              cabinetRefId: this.cabinetId,
            };
            this.uiService.show();
            this.contentDataService
              .deleteFolder(element.id, deleteFolderPayload)
              .subscribe({
                next: () => {
                  this.contentDataService
                    .getProjectFolderTree(
                      this.companyId,
                      this.projectId,
                      "library"
                    )
                    .subscribe({
                      next: (folderTree) => {
                        this.contentDataService.sendProjectFolderTreeToParent(
                          folderTree
                        );
                        this.uiService.hide();
                        this.snackService.successSnackBar(
                          this.ts.instant("library.messages.folderDeleted")
                        );
                        this.fetchGridData(true);
                      },
                      error: () => {
                        this.uiService.hide();
                      },
                    });
                },
                error: () => {
                  this.uiService.hide();
                  this.snackService.errorSnackBar(
                    this.ts.instant("library.messages.deleteFailed")
                  );
                },
              });
          }
        }
      },
      error: () => {
        this.snackService.errorSnackBar(
          this.ts.instant("library.messages.fetchFailed")
        );
      },
    });
  }

  getUserConfirmationOnDelete() {
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.confirmAction"),
      this.ts.instant("library.messages.deleteConfirm"),
      this.ts.instant("dialog.deleteBtn"),
      "warning",
      null,
      null,
      true
    );

    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      panelClass: "dialog-box",
      data: dialogData,
    });

    return dialogRef.afterClosed();
  }

  deleteBulk() {
    const deleteBulkFileList: FileId[] = [];
    const deleteBulkFolderList: FolderId[] = [];
    let deleteBulkFilePayload: DeleteFileBulk;
    let deleteBulkFolderPayload: DeleteFolderBulk;

    for (const item of this.gridData) {
      if (item.isSelected) {
        if (item.type === this.itemTypes.FILE) {
          deleteBulkFileList.push({ fileId: item.id });
        } else if (item.type === this.itemTypes.FOLDER) {
          deleteBulkFolderList.push({ folderId: item.id });
        }
      }
    }

    deleteBulkFilePayload = {
      isSoftDelete: true,
      parentFolderRefId: this.folderId,
      files: deleteBulkFileList,
    };

    deleteBulkFolderPayload = {
      isSoftDelete: true,
      projectId: this.projectId,
      cabinetRefId: this.cabinetId,
      folders: deleteBulkFolderList,
    };

    if (
      deleteBulkFilePayload.files.length > 0 ||
      deleteBulkFolderPayload.folders.length > 0
    ) {
      this.getUserConfirmationOnDelete().subscribe({
        next: (confirm) => {
          if (confirm) {
            if (
              deleteBulkFilePayload.files.length > 0 &&
              deleteBulkFolderPayload.folders.length > 0
            ) {
              this.uiService.show();
              forkJoin({
                deleteFileBulk: this.contentDataService.deleteFileBulk(
                  deleteBulkFilePayload
                ),
                deleteFolderBulk: this.contentDataService.deleteFolderBulk(
                  deleteBulkFolderPayload
                ),
              })
                .pipe(
                  map((response) => {
                    return {
                      files: response.deleteFileBulk,
                      folders: response.deleteFolderBulk,
                    };
                  })
                )
                .subscribe({
                  next: () => {
                    this.contentDataService
                      .getProjectFolderTree(
                        this.companyId,
                        this.projectId,
                        "library"
                      )
                      .subscribe({
                        next: (folderTree) => {
                          this.contentDataService.sendProjectFolderTreeToParent(
                            folderTree
                          );
                          this.uiService.hide();
                          this.snackService.successSnackBar(
                            this.ts.instant(
                              "library.messages.filesNfoldersDeleted"
                            )
                          );
                          this.fetchGridData(true);
                        },
                        error: () => {
                          this.uiService.hide();
                        },
                      });
                  },
                  error: () => {
                    this.uiService.hide();
                    this.snackService.errorSnackBar(
                      this.ts.instant("library.messages.deleteFailed")
                    );
                  },
                });
            } else if (deleteBulkFilePayload.files.length > 0) {
              this.uiService.show();
              this.contentDataService
                .deleteFileBulk(deleteBulkFilePayload)
                .subscribe({
                  next: () => {
                    this.uiService.hide();
                    if (deleteBulkFilePayload.files.length === 1) {
                      this.snackService.successSnackBar(
                        this.ts.instant("library.messages.fileDeleted")
                      );
                    } else {
                      this.snackService.successSnackBar(
                        this.ts.instant("library.messages.filesDeleted")
                      );
                    }
                    this.fetchGridData(true);
                  },
                  error: () => {
                    this.uiService.hide();
                    this.snackService.errorSnackBar(
                      this.ts.instant("library.messages.deleteFailed")
                    );
                  },
                });
            } else if (deleteBulkFolderPayload.folders.length > 0) {
              this.uiService.show();
              this.contentDataService
                .deleteFolderBulk(deleteBulkFolderPayload)
                .subscribe({
                  next: () => {
                    this.contentDataService
                      .getProjectFolderTree(
                        this.companyId,
                        this.projectId,
                        "library"
                      )
                      .subscribe({
                        next: (folderTree) => {
                          this.contentDataService.sendProjectFolderTreeToParent(
                            folderTree
                          );
                          this.uiService.hide();
                          if (deleteBulkFolderPayload.folders.length === 1) {
                            this.snackService.successSnackBar(
                              this.ts.instant("library.messages.folderDeleted")
                            );
                          } else {
                            this.snackService.successSnackBar(
                              this.ts.instant("library.messages.foldersDeleted")
                            );
                          }
                          this.fetchGridData(true);
                        },
                      });
                  },
                  error: () => {
                    this.uiService.hide();
                    this.snackService.errorSnackBar(
                      this.ts.instant("library.messages.deleteFailed")
                    );
                  },
                });
            }
          }
        },
        error: () => {
          this.snackService.errorSnackBar(
            this.ts.instant("library.messages.fetchFailed")
          );
        },
      });
    }
  }

  openFile(element: FileGrid, isShare: boolean) {
    if (element.type === "file") {
      const ext = this.getExt(element.name);
      if (ext === "pdf") {
        this.openPDFViewer(element);
      } else if (
        ext === "jpg" ||
        ext === "jpeg" ||
        ext === "gif" ||
        ext === "bmp" ||
        ext === "png"
      ) {
        this.openImageViewer(element, isShare);
      } else {
        this.downloadFile(element);
      }
    } else if (element.type === "folder") {
      return null;
    }
  }

  openImageViewer(element: FileGrid, isShare: boolean) {
    const data: ImageViewerData = {
      image: element,
      allImages: isShare
        ? []
        : this.gridData.filter((item) => {
            if (item.type === this.itemTypes.FOLDER) return false;
            const extn = this.getExt(item.name);
            switch (extn) {
              case "jpg":
              case "jpeg":
              case "gif":
              case "bmp":
              case "png":
                return true;
              default:
                return false;
            }
          }),
      projectId: this.projectId,
    };
    const dialogRef = this.dialog.open(LibraryImageViewerComponent, {
      panelClass: "full-screen-dialog",
      disableClose: true,
      data,
    });
    dialogRef.afterClosed().subscribe(() => {
      this.contentDataService.refreshFiles(true);
    });
  }

  openPDFViewer(element: FileGrid): void {
    const data: PdfViewerData = {
      image: element,
      projectId: this.projectId,
    };
    this.dialog.open(DocumentViewerComponent, {
      width: "60%",
      position: { top: ".5em" },
      disableClose: true,
      data,
    });
  }

  downloadFile(element: FileGrid) {
    FileSaver.saveAs(element.downloadUrl);
  }

  async getAllFilesData(files: FileGrid[]) {
    return files.map(async (fileItem) => {
      return new Promise<FileData>(async (resolve) => {
        this.contentDataService.getFileContent(fileItem.downloadUrl).subscribe({
          next: (data) => {
            resolve({ file: fileItem, data });
          },
          error: (err) => {
            resolve({ file: fileItem, data: null });
          },
        });
      });
    });
  }

  async downloadBulk() {
    if (
      this.gridData.find(
        (item) => item.isSelected && item.type == this.itemTypes.FOLDER
      )
    ) {
      const dialogData = new ConfirmAlertModel(
        this.ts.instant("smartMedia.labels.alert"),
        this.ts.instant("smartMedia.messages.bulkDownloadOnlyFilesWarning"),
        this.ts.instant("smartMedia.labels.ok"),
        "warning",
        null,
        null,
        false
      );
      this.dialog.open(ConfirmAlertComponent, {
        maxWidth: "400px",
        panelClass: "dialog-box",
        data: dialogData,
      });

      return;
    }

    const files = this.gridData.filter(
      (item) => item.type == this.itemTypes.FILE && item.isSelected
    );

    this.uiService.show();

    if (files.length > 1) {
      this.getAllFilesData(files)
        .then((v) => Promise.all(v))
        .then((v) => {
          const zip = new JSZip();
          let isFileDataExists: boolean = false;

          v.forEach((item) => {
            if (item.data) {
              isFileDataExists = true;
              zip.file(item.file.name, item.data);
            }
          });

          if (isFileDataExists) {
            const getProject = this.projectService.get(this.projectId);
            const getFolder = this.contentDataService.getFolder(this.folderId);

            forkJoin([getProject, getFolder]).subscribe({
              next: (data) => {
                const projectName = data[0].projectName;
                const folderName = data[1].name;
                const currentDate = new Date().getTime();
                let fileName: string;

                if (data[1].parentFolderRefId) {
                  fileName = `documents-${projectName.toLowerCase()}-${folderName.toLowerCase()}-${currentDate}.zip`;
                } else {
                  fileName = `documents-${projectName.toLowerCase()}-${currentDate}.zip`;
                }

                zip.generateAsync({ type: "blob" }).then(function (content) {
                  FileSaver.saveAs(content, fileName);
                });
                this.uiService.hide();
              },
              error: () => {
                this.uiService.hide();
              },
            });
          } else {
            this.uiService.hide();
          }
        })
        .catch((err) => {
          console.log(err);
          this.uiService.hide();
        });
    } else if (files.length == 1) {
      FileSaver.saveAs(files[0].downloadUrl);
      this.uiService.hide();
    }
  }

  tagLibrary(element: FileGrid): void {
    const dialogRef = this.dialog.open(LibraryTagComponent, {
      width: "45%",
      disableClose: true,
      data: { fileId: element.id, tagList: element.tagList },
      panelClass: "dialog-box",
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.contentDataService.refreshFiles(true);
      }
    });
  }

  getExt(filename) {
    const dot_pos = filename.lastIndexOf(".");
    if (dot_pos == -1) {
      return "";
    }
    return filename.substr(dot_pos + 1).toLowerCase();
  }

  assignTotalFoldersCount(total: number) {
    if (total === 1) {
      this.totalFoldersMsg = eval(
        "`" + this.ts.instant("library.messages.nFolder") + "`"
      );
    } else {
      this.totalFoldersMsg = eval(
        "`" + this.ts.instant("library.messages.nFolders") + "`"
      );
    }
  }

  assignTotalFilesCount(total: number) {
    if (total === 1) {
      this.totalFilesMsg = eval(
        "`" + this.ts.instant("library.messages.nFile") + "`"
      );
    } else {
      this.totalFilesMsg = eval(
        "`" + this.ts.instant("library.messages.nFiles") + "`"
      );
    }
  }

  folderExpansionPanelOpen(isOpen: boolean) {
    this.folderExpansionPanelOpenState = isOpen;
    const thumbnailView: ThumbnailView =
      this.localStorageService.getItem("libThumbnailView");

    if (thumbnailView) {
      thumbnailView.folder = isOpen;
      this.localStorageService.setItem("libThumbnailView", thumbnailView);
    }
  }

  fileExpansionPanelOpen(isOpen: boolean) {
    this.fileExpansionPanelOpenState = isOpen;
    const thumbnailView: ThumbnailView =
      this.localStorageService.getItem("libThumbnailView");

    if (thumbnailView) {
      thumbnailView.file = isOpen;
      this.localStorageService.setItem("libThumbnailView", thumbnailView);
    }
  }

  imageError(event, element: FileGrid) {
    event.target.src = this.getFallbackThumbnailUrl(element.name);
  }

  getFileIcon(name: string) {
    const dotIndex = name.lastIndexOf(".");
    let extn: string = "";

    if (dotIndex > -1) {
      extn = name.substring(dotIndex + 1);
    }

    switch (extn.toLowerCase()) {
      case "jpg":
      case "png":
      case "jpeg":
      case "gif":
      case "tif":
      case "tiff":
      case "bmp":
        return "image";
      case "m4v":
      case "mp4":
      case "avi":
      case "mpg":
      case "mov":
        return "video_file";
      case "txt":
        return "text_snippet";
      case "pdf":
        return "picture_as_pdf";
      default:
        return "insert_drive_file";
    }
  }

  getThumbnailUrl(fileObjectId: string) {
    const dotIndex = fileObjectId.lastIndexOf(".");
    let extn: string = "";
    const baseUrl = "https://thumbnail-dest-bkt.s3.ap-south-1.amazonaws.com/"; //TBD
    const thumbnailPrefix: string = "thumbnail_"; //TBD

    if (dotIndex > -1) {
      extn = fileObjectId.substring(dotIndex + 1);
    }

    switch (extn.toLowerCase()) {
      case "jpg":
      case "png":
      case "jpeg":
      case "gif":
      case "mp4": //TBD
        return baseUrl + thumbnailPrefix + fileObjectId;
      case "tif":
      case "tiff":
        return "assets/images/placeholder-media-image.png";
      case "m4v":
      case "avi":
      case "mpg":
      case "mov":
        return "assets/images/placeholder-video.png";
      case "txt":
        return "assets/images/placeholder-txt.png";
      case "pdf":
        return "assets/images/placeholder-pdf.png";
      default:
        return "assets/images/placeholder-image.png";
    }
  }

  getFallbackThumbnailUrl(fileName: string) {
    const dotIndex = fileName.lastIndexOf(".");
    let extn: string = "";

    if (dotIndex > -1) {
      extn = fileName.substring(dotIndex + 1);
    }

    switch (extn.toLowerCase()) {
      case "jpg":
      case "png":
      case "jpeg":
      case "gif":
      case "tif":
      case "tiff":
        return "assets/images/placeholder-media-image.png";
      case "mp4":
      case "m4v":
      case "avi":
      case "mpg":
      case "mov":
        return "assets/images/placeholder-video.png";
      case "txt":
        return "assets/images/placeholder-txt.png";
      case "pdf":
        return "assets/images/placeholder-pdf.png";
      default:
        return "assets/images/placeholder-image.png";
    }
  }

  editFile(element: FileGrid) {
    this.contentDataService.sendEditFile(element);
  }

  editFolder(element: FileGrid) {
    const dialogData: FolderPayload = {
      folderId: element.id,
      isCreate: false,
      name: element.name,
      description: null,
      cabinetRefId: this.cabinetId,
      parentFolderRefId: this.folderId,
      projectId: this.projectId,
      additionalInfo: null,
      status: true,
    };
    const dialogRef = this.dialog.open(NewFolderComponent, {
      width: "35%",
      data: dialogData,
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.contentDataService
          .getProjectFolderTree(this.companyId, this.projectId, "library")
          .subscribe({
            next: (folderTree) => {
              this.contentDataService.sendProjectFolderTreeToParent(folderTree);
              this.contentDataService.refreshFiles(true);
            },
          });
      }
    });
  }

  uploadNewVersionClicked(element: FileGrid) {
    this.contentDataService.openUploadVersionPanel(element);
  }
  private handleError(error: any) {
    this.uiService.hide();
    this.snackService.errorSnackBar(
      this.ts.instant("library.messages.fetchFailed")
    );
    return throwError(error);
  }

  generateShareLink(element: FileGrid) {
    this.isOpen = !this.isOpen;
    const shareInfo: any = {
      clientId: this.localStorage.getClientId(),
      projectId: this.projectId,
      fileId: element.id,
      data: element,
    };
    this.projectSvc
      .generateShareLink("library", element.id, shareInfo)
      .subscribe(
        (data: any) => {
          this.isOpen = true;
          const share = data.share;
          this.shareLink = eval("`" + this.config.shareUrl + "`");
        },
        (error) => {
          this.errors = error;
        }
      );
  }
  copyShareLink() {
    if (!!this.shareLink) {
      this.clipboard.copy(this.shareLink);
      this.snackService.successSnackBar(
        this.ts.instant("general.messages.copyLink")
      );
    }
  }
  closeDialog(): void {
    this.dialog.closeAll();
  }
}

export interface ItemType {
  FILE: string;
  FOLDER: string;
}

export interface FileData {
  file: FileGrid;
  data: any;
}
