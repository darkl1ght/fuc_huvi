import { Component, OnInit, Inject, ViewChild } from "@angular/core";
import {
  FileGrid,
  LocalStorageService,
  ProjectService,
  UiService,
  SnackbarService,
} from "src/app/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { Clipboard } from "@angular/cdk/clipboard";
const FileSaver = require("file-saver");

@Component({
  selector: "app-viewer",
  templateUrl: "./viewer.component.html",
  styleUrls: ["./viewer.component.scss"],
})
export class DocumentViewerComponent implements OnInit {
  @ViewChild("trigger") trigger;
  url: string;
  errors = {};
  isOpen: boolean = false;
  shareLink: string = null;
  projectId: string;
  fileId: string;
  image: FileGrid;

  constructor(
    public dialog: MatDialog,
    private uiService: UiService,
    @Inject(MAT_DIALOG_DATA) private data: any,
    @Inject(APP_CONFIG) private config: AppConfig,
    private ts: TranslateService,
    private snackService: SnackbarService,
    private projectSvc: ProjectService,
    private clipboard: Clipboard,
    private localStorage: LocalStorageService
  ) {}

  ngOnInit(): void {
    this.uiService.show();
    this.url = this.data.image.viewUrl;
    this.projectId = this.data.projectId;
    this.image = this.data.image;
    this.fileId = this.image.id;
  }

  pageRendered() {
    this.uiService.hide();
  }

  downloadFile() {
    FileSaver.saveAs(this.url);
    const alert = this.ts.instant("library.messages.downloadSuccess");
    this.snackService.successSnackBar(alert);
    (err) => {
      this.errors = err;
      const alert = this.ts.instant("library.messages.downloadFail");
      this.snackService.errorSnackBar(alert);
    };
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
  generateShareLink() {
    const shareInfo: any = {
      clientId: this.localStorage.getClientId(),
      projectId: this.projectId,
      fileId: this.fileId,
      data: this.data.image,
    };
    this.projectSvc
      .generateShareLink("library", this.fileId, shareInfo)
      .subscribe(
        (data: any) => {
          this.isOpen = true;
          const share = data.share;
          this.shareLink = eval("`" + this.config.shareUrl + "`");
        },
        (error) => {
          this.errors = error;
        }
      );
  }
  copyShareLink() {
    if (!!this.shareLink) {
      this.clipboard.copy(this.shareLink);
      this.snackService.successSnackBar(
        this.ts.instant("general.messages.copyLink")
      );
    }
  }
}
