import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-aerial-tour",
  templateUrl: "./aerial-tour.component.html",
  styleUrls: ["./aerial-tour.component.scss"],
})
export class AerialTourComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
