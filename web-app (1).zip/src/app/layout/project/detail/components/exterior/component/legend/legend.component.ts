import { Component, OnInit, Inject } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  Guid,
  UiService,
  StorageService,
  TourLegend,
  InteriorService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";
import { take, tap } from "rxjs/operators";

@Component({
  selector: "legend",
  templateUrl: "./legend.component.html",
  styleUrls: ["./legend.component.scss"],
})
export class LegendComponent implements OnInit {
  errors = {};
  projectId: string;
  tourId: string;
  accessToken: string;
  filesSelected: boolean = false;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private intService: InteriorService,
    private snackService: SnackbarService,
    private storageService: StorageService,
    private uiService: UiService,
    private ts: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  public ngOnInit(): void {
    this.getToken();
    this.tourId = this.data.tourId;
    this.projectId = this.data.projectId;
  }

  onFileChange(event: any): void {
    let alert = "";
    if (this.tourId && event.length > 1) {
      alert = this.ts.instant("exterior.legend.messages.uploadErrorFileCount");
      this.snackService.errorSnackBar(alert);
      return;
    }
    this.filesSelected = true;
    this.uploadFiles(event);
  }

  async uploadFiles(files) {
    let alert;
    try {
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.accessToken
      );
      const containerClient = blobServiceClient.getContainerClient(
        this.config.mediaContainer
      );
      const promises = [];
      this.uiService.show();
      for (const file of files) {
        let fileName = file.name;
        let fileId = Guid.newGuid();
        let extn = file.name.split(".").pop();
        let docId = fileId + "." + extn;

        const blockBlobClient = containerClient.getBlockBlobClient(docId);
        promises.push(blockBlobClient.uploadBrowserData(file));
        this.updateFileData(fileId, fileName, docId);
      }

      await Promise.all(promises);
      alert = this.ts.instant("exterior.legend.messages.uploadSuccess");
      this.snackService.successSnackBar(alert);
      this.closeDialog();
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
      alert = this.ts.instant("exterior.legend.messages.uploadFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  getToken() {
    let container = this.config.mediaContainer;
    this.storageService.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  private updateFileData(
    legendId: string,
    legendName: string,
    blobContentId: string
  ) {
    let legend: TourLegend = {} as TourLegend;

    legend.blobContentId = blobContentId;
    legend.legendName = legendName;
    legend.legendId = legendId;

    this.intService
      .addNewLegend(this.projectId, this.tourId, legend)
      .pipe(
        take(1),
        tap((data) => {
          return;
        })
      )
      .subscribe();
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
