import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { ActivatedRoute, Router } from "@angular/router";
import { MatPaginator } from "@angular/material/paginator";
import {
  ConfirmAlertComponent,
  ConfirmAlertModel,
} from "src/app/layout/components/confirm-alert/confirm-alert.component";
import { NewAerialTourComponent } from "../new/new-aerial-tour.component";
import {
  AerialTour,
  UserService,
  User,
  UiService,
  AerialTourService,
  ProjectUser,
  ProjectService,
  ShareService,
  LocalStorageService,
  AccessControlService,
  AppConstants,
  SnackbarService,
} from "src/app/core";
import { UploadAerialTourDataComponent } from "../upload/upload-data.component";
import { TranslateService } from "@ngx-translate/core";
import { MapSettingsComponent } from "../settings/map-settings.component";
import { MapboxComponent } from "../mapbox/mapbox.component";
import { StaticExteriorTourComponent } from "../static-map/static-map.component";
import { StaticExteriorTourViewerComponent } from "../static-tour-viewer/static-tour-viewer.component";
import { LegendComponent } from "../legend/legend.component";
import { Observable } from "rxjs";
import { ReportComponent } from "../report/report.component";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { Clipboard } from "@angular/cdk/clipboard";
import { UploadDroneDataComponent } from "../upload-drone-data/upload-drone-data.component";
import { MatIconRegistry } from "@angular/material/icon";
import { droneIcon } from "../mapbox/mapbox-utils";
import { flightControlIcon } from "../mapbox/mapbox-utils";
import { DomSanitizer } from "@angular/platform-browser";
import { AerialTagComponent } from "../tag/aerial-tag.component";

@Component({
  selector: "aerial-tour-list",
  templateUrl: "./aerial-tour-list.component.html",
  styleUrls: ["./aerial-tour-list.component.scss"],
})
export class AerialTourListComponent implements OnInit {
  @ViewChild("trigger") trigger;
  result: string = "";
  projectId: string;
  tourDS: Observable<any>;
  dataSource: any;
  tourList: AerialTour[] = [];
  displayedColumns: string[] = [
    "tourDate",
    "tourName",
    "status.desc",
    "totalImage",
    "action",
    " ",
  ];
  @ViewChild(MatSort) sort: MatSort;
  errors = {};
  @ViewChild(MatPaginator) paginator: MatPaginator;
  showDiscussionPanel: boolean = false;
  tourId: string;
  user: User;
  isShowingAerialInput: boolean = false;
  isLoaded: boolean = false;
  projectUsers: ProjectUser[] = [];
  isOpen: boolean = false;
  shareLink: string = null;
  project: any;
  accessCreateTour: boolean;
  accessEditTour: boolean;
  accessDeleteTour: boolean;
  accessSendNotification: boolean;

  constructor(
    public dialog: MatDialog,
    private snackService: SnackbarService,
    private ts: TranslateService,
    private route: ActivatedRoute,
    private userService: UserService,
    private uiService: UiService,
    public router: Router,
    private tourService: AerialTourService,
    private projectSvc: ProjectService,
    private shareService: ShareService,
    private accessControlService: AccessControlService,
    private localStorage: LocalStorageService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private clipboard: Clipboard,
    private projectService: ProjectService,
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer
  ) {
    this.projectId =
      this.route.parent.parent.parent.snapshot.paramMap.get("projectId");

    iconRegistry.addSvgIconLiteral(
      "droneIcon",
      sanitizer.bypassSecurityTrustHtml(droneIcon)
    );

    iconRegistry.addSvgIconLiteral(
      "flightControlIcon",
      sanitizer.bypassSecurityTrustHtml(flightControlIcon)
    );
  }

  ngOnInit() {
    this.accessControlService
      .getObjectAccesses([
        AppConstants.accessObjectKeys.AERIAL_CREATE_TOUR,
        AppConstants.accessObjectKeys.AERIAL_EDIT_TOUR,
        AppConstants.accessObjectKeys.AERIAL_DELETE_TOUR,
        AppConstants.accessObjectKeys.AERIAL_SEND_NOTIFICATION,
      ])
      .subscribe({
        next: (data) => {
          const [
            accessCreateTour,
            accessEditTour,
            accessDeleteTour,
            accessSendNotification,
          ] = data;
          this.accessCreateTour = accessCreateTour.isAllowed;
          this.accessEditTour = accessEditTour.isAllowed;
          this.accessDeleteTour = accessDeleteTour.isAllowed;
          this.accessSendNotification = accessSendNotification.isAllowed;
        },
      });

    this.route.parent.parent.parent.params.subscribe((params) => {
      this.projectId = params["projectId"];
      this.getTourData();
      this.getProjectUserList();
    });

    // this.getTourData();

    this.projectService.get(this.projectId).subscribe((project) => {
      this.project = project;
    });
    this.user = this.userService.getCurrentUser();
  }

  getProjectUserList() {
    this.projectSvc.get(this.projectId).subscribe(
      (data) => {
        this.projectUsers = data.users;
      },
      (error) => {
        this.errors = error;
      }
    );
  }
  openDialog(): void {
    const dialogRef = this.dialog.open(NewAerialTourComponent, {
      width: "450px",
      disableClose: true,
      data: { projectId: this.projectId, tour: undefined },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getTourData();
    });
  }

  updateDialog(tour: AerialTour): void {
    const dialogRef = this.dialog.open(NewAerialTourComponent, {
      width: "450px",
      disableClose: true,
      data: { projectId: this.projectId, tour: tour },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getTourData();
    });
  }

  uploadTourImage(tour: AerialTour): void {
    const dialogRef = this.dialog.open(UploadAerialTourDataComponent, {
      width: "80%",
      disableClose: true,
      data: { projectId: this.projectId, tour: tour, tourId: tour.tourId },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getTourData();
    });
  }

  getTourData() {
    this.uiService.show();
    this.tourService.getTours(this.projectId).subscribe(
      (data) => {
        this.tourList = data.tours;
        this.tourList.forEach((el) => {
          el.totalImage = el.images.length;
        });
        this.dataSource = new MatTableDataSource(this.tourList);
        this.sortingDataAccessor(this.dataSource);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.filterPredicate = (data, filterValue) => {
          filterValue = filterValue.trim().toLowerCase();
          return (
            data.tourName.toLowerCase().includes(filterValue) ||
            data.tagList?.find((item) =>
              item.toLowerCase().includes(filterValue)
            )
          );
        };
        this.tourDS = this.dataSource.connect();
        //code to view shared info
        const shareId = this.localStorage.getShareId();
        if (!!shareId) {
          const sharedObject = this.shareService.getShareObject();
          const exteriorShared = this.tourList.find(
            (tour) => tour.tourId == sharedObject.tourId
          );

          this.localStorage.removeShareId();
          this.shareService.setShareObject(null);
          this.visitTour(exteriorShared);
        }
        this.uiService.hide();
        this.isLoaded = true;
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  confirmDialog(tour: AerialTour): void {
    const message = this.ts.instant("dialog.messages.removeTour");
    const successBtn = this.ts.instant("dialog.deleteBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.aerialDeleteTitle"),
      message,
      successBtn,
      icon
    );
    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.tourService.destroy(this.projectId, tour.tourId).subscribe(
          (data) => {
            const alert = this.ts.instant(
              "exterior.list.messages.tourDeleteSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.getTourData();
          },
          (err) => {
            const alert = this.ts.instant(
              "exterior.list.messages.tourDeleteFail"
            );
            this.snackService.errorSnackBar(alert);
            this.errors = err;
          }
        );
      }
    });
  }

  confirmNotificationDialog(tour: AerialTour): void {
    const message = this.ts.instant("dialog.messages.notifyUsers");
    const successBtn = this.ts.instant("dialog.notifyBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.aerialNotifyTitle"),
      message,
      successBtn,
      icon
    );

    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.tourService.notifyUsers(this.projectId, tour.tourId).subscribe(
          (data) => {
            const alert = this.ts.instant(
              "exterior.list.messages.notifiedUsersSuccesfully"
            );
            this.snackService.successSnackBar(alert);
            this.getTourData();
          },
          (err) => {
            const alert = this.ts.instant(
              "exterior.list.messages.notifingUsersFailed"
            );
            this.snackService.errorSnackBar(alert);
            this.errors = err;
          }
        );
      }
    });
  }

  initiateDataProcessing(tour: AerialTour): void {
    let alert;
    if (tour.status.code === "AT10001") {
      if (tour.images.length > 10) {
        const message = this.ts.instant("dialog.messages.startDataProcessing");
        const successBtn = this.ts.instant("dialog.processBtn");
        const icon = "";
        const dialogData = new ConfirmAlertModel(
          this.ts.instant("dialog.aerialProcessTitle"),
          message,
          successBtn,
          icon
        );
        const dialogRef = this.dialog.open(ConfirmAlertComponent, {
          maxWidth: "400px",
          data: dialogData,
        });

        dialogRef.afterClosed().subscribe((dialogResult) => {
          this.result = dialogResult;
          if (this.result) {
            this.tourService.processData(this.projectId, tour.tourId).subscribe(
              (data) => {
                if (data.status == "success") {
                  this.getTourData();
                  alert = this.ts.instant(
                    "exterior.list.messages.processingStartedSuccessfully"
                  );
                  this.snackService.successSnackBar(alert);
                } else {
                  if (data.code === "10001") {
                    alert = this.ts.instant(
                      "exterior.list.messages.processingStartFailed"
                    );
                  } else if (data.code === "10002") {
                    alert = this.ts.instant(
                      "exterior.list.messages.processingParameterUnset"
                    );
                  }
                  this.snackService.errorSnackBar(alert);
                }
              },
              (err) => {
                this.snackService.errorSnackBar(err.message);
                this.errors = err;
              }
            );
          }
        });
      } else {
        alert = this.ts.instant("exterior.list.messages.processingError");
        this.snackService.errorSnackBar(alert);
      }
    }
  }

  visitTour(tour: AerialTour) {
    if (tour.mapType !== "S" && tour.status.code === "AT10003") {
      const dialogRef = this.dialog.open(MapboxComponent, {
        panelClass: "full-screen-dialog",
        disableClose: true,
        data: {
          projectId: this.projectId,
          tour: tour,
          allTours: this.tourList.filter(
            (tour) =>
              tour.mapType !== "S" &&
              tour.status.code === "AT10003" &&
              tour.isActive
          ),
          tourId: tour.tourId,
        },
      });

      dialogRef.afterClosed().subscribe((dialogResult) => {
        this.getTourData();
      });
    } else if (
      tour.mapType === "S" &&
      tour.staticMap.urls &&
      tour.staticMap.urls.length > 0
    ) {
      this.visitStaticTour(tour);
    }
  }

  visitStaticTour(tour: AerialTour) {
    const dialogRef = this.dialog.open(StaticExteriorTourViewerComponent, {
      panelClass: "full-screen-dialog",
      disableClose: true,
      data: { projectId: this.projectId, tour: tour, tourId: tour.tourId },
    });
  }

  mapSettings(tour: AerialTour) {
    const dialogRef = this.dialog.open(StaticExteriorTourComponent, {
      panelClass: "full-screen-dialog",
      disableClose: true,
      data: { projectId: this.projectId, tour: tour, tourId: tour.tourId },
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getTourData();
    });
  }

  sortingDataAccessor(dataSource) {
    dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case "status.desc":
          return item.status.desc;
        default:
          return item[property];
      }
    };
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  openSettings(tour: AerialTour) {
    const dialogRef = this.dialog.open(MapSettingsComponent, {
      panelClass: "full-screen-dialog",
      disableClose: true,
      data: { projectId: this.projectId, tour: tour, tourId: tour.tourId },
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getTourData();
    });
  }

  uploadLegend(tour: AerialTour) {
    const dialogRef = this.dialog.open(LegendComponent, {
      width: "450px",
      disableClose: true,
      data: { projectId: this.projectId, tourId: tour.tourId },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getTourData();
    });
  }

  toggleProjectsFilterInput() {
    this.isShowingAerialInput = !this.isShowingAerialInput;
  }

  reportDialog(tour): void {
    const dialogRef = this.dialog.open(ReportComponent, {
      width: "90%",
      height: "88%",
      disableClose: true,
      data: { tour: tour, projectId: this.projectId },
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {});
  }

  uploadDroneData(tour): void {
    const dialogRef = this.dialog.open(UploadDroneDataComponent, {
      width: "425px",
      disableClose: true,
      data: {
        projectId: this.projectId,
        project: this.project,
        tourId: tour.tourId,
        tour: tour,
      },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getTourData();
    });
  }

  isUserProjectAdmin() {
    let user = this.projectUsers.find((user) => user.email === this.user.email);
    return user && user.role.code === "Project Admin" ? true : false;
  }

  getShareLinkObservable(tour: AerialTour) {
    const shareInfo: any = {
      clientId: this.localStorage.getClientId(),
      projectId: this.projectId,
      tourId: tour.tourId,
    };
    return this.projectSvc.generateShareLink(
      "exterior",
      tour.tourId,
      shareInfo
    );
  }

  generateShareLink(tour: AerialTour) {
    const shareLinkObs = this.getShareLinkObservable(tour);
    shareLinkObs.subscribe(
      (data: any) => {
        this.isOpen = true;
        const share = data.share;
        this.shareLink = eval("`" + this.config.shareUrl + "`");
      },
      (error) => {
        this.errors = error;
      }
    );
  }

  copyShareLink() {
    if (!!this.shareLink) {
      this.clipboard.copy(this.shareLink);
      this.snackService.successSnackBar(
        this.ts.instant("general.messages.copyLink")
      );
    }
  }

  sendEmailNotification(tour: AerialTour) {
    const message = this.ts.instant("dialog.messages.emailNotifyUsers");
    const successBtn = this.ts.instant("dialog.notifyBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.emailNotifyTitle"),
      message,
      successBtn,
      icon
    );

    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        const shareLinkObs = this.getShareLinkObservable(tour);
        shareLinkObs.subscribe(
          (data: any) => {
            const share = data.share;
            this.shareLink = eval("`" + this.config.shareUrl + "`");
            this.tourService
              .emailNotifyUsers(this.projectId, tour.tourId, this.shareLink)
              .subscribe(
                (data) => {
                  const alert = this.ts.instant(
                    "exterior.list.messages.notifiedUsersSuccesfully"
                  );
                  this.snackService.successSnackBar(alert);
                  this.getTourData();
                },
                (err) => {
                  const alert = this.ts.instant(
                    "exterior.list.messages.notifingUsersFailed"
                  );
                  this.snackService.errorSnackBar(alert);
                  this.errors = err;
                }
              );
          },
          (error) => {
            this.errors = error;
          }
        );
      }
    });
  }

  tagAerial(tour: AerialTour) {
    const dialogRef = this.dialog.open(AerialTagComponent, {
      width: "45%",
      disableClose: true,
      data: { projectId: this.projectId, tour: tour },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((data) => {
      this.getTourData();
    });
  }
}
