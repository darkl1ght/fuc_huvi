import { HttpEventType, HttpResponse } from "@angular/common/http";
import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { UntypedFormBuilder, UntypedFormGroup } from "@angular/forms";
import { FormGroup, Validators } from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { TranslateService } from "@ngx-translate/core";
import {
  AerialTour,
  AerialTourDialogData,
  AerialTourService,
  AppConstants as Constants,
  ProjectChart,
  UiService,
  User,
  UserService,
  SnackbarService,
} from "src/app/core";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";
import * as XLSX from "xlsx";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import {
  ConfirmAlertComponent,
  ConfirmAlertModel,
} from "src/app/layout/components/confirm-alert/confirm-alert.component";
import { MatTable } from "@angular/material/table";
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { LayerColorComponent } from "../../layer-color/layer-color.component";

declare const JSONEditor: any;
type AOA = any[][];

@Component({
  selector: "map-settings",
  templateUrl: "./map-settings.component.html",
  styleUrls: ["./map-settings.component.scss"],
})
export class MapSettingsComponent implements OnInit {
  @ViewChild("uploadLayers") uploadLayers: any;
  @ViewChild("uploadCharts") uploadCharts: any;
  @ViewChild("latLngForm") newlatLngForm: any;
  public latLngForm: FormGroup;
  showUploadLayers: boolean = false;
  uploadInProgress: boolean = false;
  fileData: any;
  dataError: boolean = false;
  uploadedFiles: any[] = [];
  projectCharts: ProjectChart[] = [];
  chart: ProjectChart = {} as ProjectChart;
  charts: any = [];

  currentUser: User;

  fileName: string = "";
  progress: number = 0;
  tour: AerialTour;
  tourId: string = "";
  projectId: string = "";
  events: any = [];
  output: any = [];
  displayedColumns: string[] = [
    "type",
    "filename",
    "uploadedAt",
    "addedBy",
    "selectColor",
    "action",
  ];
  dataSource: any;
  @ViewChild(MatSort) sort: MatSort;
  errors = {};
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild("table") table: MatTable<string>;
  uploadForm: UntypedFormGroup;
  uploadChartForm: UntypedFormGroup;
  result: string;
  editor: any;
  configOptions: any;
  configOptionsFiltered: any;
  selectedParam: string;
  tourCategory: string;
  tourCategoryOptions: any;
  showUploadCharts: boolean = false;
  threeDUrl: string = "";
  pointCloudObjectCount: number = 1;
  wasFormChanged: boolean;
  tourReadyToVisualise: boolean = false;
  newMapboxLayerArray: any;
  editMapboxTourLayerOrder: boolean = false;
  submitMapboxTourLayerOrder: boolean = false;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: AerialTourDialogData,
    private uiService: UiService,
    private tourSvc: AerialTourService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    private userService: UserService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {
    this.currentUser = this.userService.getCurrentUser();
    this.uploadForm = this.fb.group({
      layer: [""],
    });

    this.uploadChartForm = this.fb.group({
      layer: [""],
    });

    this.latLngForm = this.fb.group({
      latitude: ["", [Validators.required]],
      longitude: ["", [Validators.required]],
    });
  }

  public ngOnInit(): void {
    this.tourId = this.data.tourId;
    this.projectId = this.data.projectId;
    this.tour = this.data.tour;
    this.tour.objectCount &&
      (this.pointCloudObjectCount = this.tour.objectCount);
    this.getProcessingStatus();
    this.getMapOutput();
    this.getAerialTourLatLngData();
  }

  getMapOutput() {
    this.uiService.show();
    this.tourSvc.getMapOutput(this.projectId, this.tourId).subscribe(
      (data) => {
        this.output = data.urls;
        this.dataSource = new MatTableDataSource(data.urls);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.uiService.hide();
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  getProcessingStatus() {
    this.uiService.show();
    this.tourSvc.getProcessingStatus(this.projectId, this.tourId).subscribe(
      (data) => {
        this.events = data.processingStatus.events;
        this.uiService.hide();
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  deleteLayer(element) {
    const message = this.ts.instant("dialog.messages.removeLayer");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        if (
          element.filename === "dsm-elevation.tif" ||
          element.filename === "dtm-elevation.tif"
        ) {
          let container = this.config.mapoutputsContainer;

          this.tourSvc
            .deleteElevationFilesFromBlob(
              this.projectId,
              this.tourId,
              container,
              element.filename
            )
            .subscribe(
              (data) => {
                this.getMapOutput();
              },
              (err) => {
                this.errors = err;
              }
            );
        } else {
          this.tourSvc
            .removeLayer(this.projectId, this.tourId, element.appendIndex)
            .subscribe(
              (data) => {
                this.getMapOutput();
              },
              (err) => {
                this.errors = err;
              }
            );
        }
      }
    });
  }

  onFileChange(event: any): void {
    let alert = "";
    if (event.length > 1) {
      alert = this.ts.instant(
        "exterior.settings.messages.uploadErrorFileCount"
      );
      this.snackService.errorSnackBar(alert);
      return;
    }
    this.uploadFiles(event);
  }

  selectTab(event) {
    if (event.index === 2) {
      this.getProcessingParams();
    } else if (event.index === 3) {
      this.getCharts();
    }
  }

  getCharts() {
    this.uiService.show();
    this.tourSvc.getCharts(this.projectId, this.tourId).subscribe(
      (data) => {
        this.charts = data.charts;
        this.uiService.hide();
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  setJsonEditor(data) {
    this.editor = null;
    const container = document.getElementById("jsoneditor");

    if (container && container.firstChild) {
      while (container.firstChild) {
        container.removeChild(container.lastChild);
      }
    }

    const options = {};
    if (!this.editor) {
      this.editor = new JSONEditor(container, options);
      this.editor.set(data);
    } else {
      this.editor.set(data);
    }
  }

  changeParam(event) {
    let data: any;
    if (this.selectedParam) {
      data = this.configOptions.find((o) => o.tourType === event.value).config;
      this.setJsonEditor(data);
    }
  }

  getConfigurations() {
    this.uiService.show();
    this.tourSvc.getProcessingStatus(this.projectId, this.tourId).subscribe(
      (data) => {
        this.events = data.processingStatus.events;
        this.uiService.hide();
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  saveProcessingParams() {
    if (!this.tourCategory) {
      const alert = this.ts.instant(
        "exterior.settings.messages.selectTourCategory"
      );
      this.snackService.errorSnackBar(alert);
      return;
    }

    let params = this.editor.get();
    let alert;
    if (params) {
      this.tourSvc
        .postProcessingParams(
          this.projectId,
          this.tourId,
          params,
          this.tourCategory
        )
        .subscribe(
          (data) => {
            alert = this.ts.instant(
              "exterior.settings.messages.detailsCreated"
            );
            this.snackService.successSnackBar(alert);
          },
          (err) => {
            alert = this.ts.instant(
              "exterior.settings.messages.detailsSavefailed"
            );
            this.errors = err;
            this.snackService.errorSnackBar(alert);
          }
        );
    }
  }

  getProcessingParams() {
    let selectedData;
    this.uiService.show();
    this.tourCategory = "";
    this.tourSvc.getProcessingParams(this.projectId, this.tourId).subscribe(
      (data) => {
        this.tourCategoryOptions = data.tourCategoryOptions.sort((a, b) =>
          a.key > b.key ? 1 : -1
        );
        this.configOptions = data.params;
        selectedData = data.selectedParam;
        if (selectedData) this.setJsonEditor(selectedData);
        this.uiService.hide();
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  changeParamValues(event) {
    this.configOptionsFiltered = this.configOptions
      .filter((ele) => ele.tourType[0] == event.value)
      .sort((a, b) => (a.tourType > b.tourType ? 1 : -1));
  }

  async uploadFiles(files) {
    let alert;
    const file = files[0];
    const filename = file.name;
    const fileExtension = file.name.split(".").pop();
    const allowed_files = Constants.custom_layers.allowed_files;
    const fileType = allowed_files[fileExtension];
    try {
      if (
        filename === "dsm-elevation.tif" ||
        filename === "dtm-elevation.tif"
      ) {
        const container = this.config.mapoutputsContainer;

        this.fileName = file.name;
        this.progress = 0;

        if (!fileType) {
          alert = this.ts.instant(
            "exterior.settings.messages.extensionNotAllowed"
          );
          this.snackService.errorSnackBar(alert);
          return;
        }

        this.tourSvc
          .uploadElevationFiles(this.projectId, this.tourId, container, file)
          .subscribe(
            (event) => {
              if (event.type === HttpEventType.UploadProgress) {
                this.uploadInProgress = true;
                this.progress = Math.round((100 * event.loaded) / event.total);
              } else if (event instanceof HttpResponse) {
                alert = this.ts.instant(
                  "exterior.settings.messages.dataUploaded"
                );
                this.snackService.successSnackBar(alert);
                this.uploadInProgress = false;
                this.getMapOutput();
              }
            },
            (err) => {
              this.uploadInProgress = false;
              alert = this.ts.instant(
                "exterior.settings.messages.uploadFailed"
              );
              this.snackService.errorSnackBar(alert);
              this.closeUploadLayers();
            }
          );
        this.uploadInProgress = false;
        this.closeUploadLayers();
      } else {
        this.fileName = file.name;
        this.progress = 0;

        if (!fileType) {
          alert = this.ts.instant(
            "exterior.settings.messages.extensionNotAllowed"
          );
          this.snackService.errorSnackBar(alert);
          return;
        }

        this.tourSvc
          .uploadCustomLayers(this.projectId, this.tourId, fileType, file)
          .subscribe(
            (event) => {
              if (event.type === HttpEventType.UploadProgress) {
                this.uploadInProgress = true;
                this.progress = Math.round((100 * event.loaded) / event.total);
              } else if (event instanceof HttpResponse) {
                alert = this.ts.instant(
                  "exterior.settings.messages.dataUploaded"
                );
                this.snackService.successSnackBar(alert);
                this.uploadInProgress = false;
                this.getMapOutput();
              }
            },
            (err) => {
              this.uploadInProgress = false;
              alert = this.ts.instant(
                "exterior.settings.messages.uploadFailed"
              );
              this.snackService.errorSnackBar(alert);
              this.closeUploadLayers();
            }
          );
        this.uploadInProgress = false;
        this.closeUploadLayers();
      }
    } catch (error) {
      this.uploadInProgress = false;
      alert = this.ts.instant("exterior.settings.messages.uploadFailed");
      this.snackService.errorSnackBar(alert);
      this.closeUploadLayers();
    }
  }

  onChartUpload(files) {
    let alert;
    if (!this.isExcelFile(files[0])) {
      alert = this.ts.instant("exterior.settings.messages.invalidFile");
      this.snackService.errorSnackBar(alert);
      return;
    }

    this.uploadedFiles.push(files[0]);
    const target: DataTransfer = <DataTransfer>files;
    if (files.length !== 1) throw new Error("Cannot use multiple files");
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: "binary" });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.fileData = <AOA>XLSX.utils.sheet_to_json(ws, {
        header: ["ChartTitle", "ChartType", "ChartData"],
      });
    };
    reader.readAsBinaryString(files[0]);
  }

  uploadData() {
    let alert;
    let charts: ProjectChart[] = [];
    this.fileData.forEach(async (row) => {
      try {
        if (row["ChartData"] !== "Chart Data") {
          let chart: ProjectChart = {} as ProjectChart;
          chart.chartTitle = row["ChartTitle"];
          chart.chartType = row["ChartType"];
          chart.chartData = JSON.parse(row["ChartData"]);
          charts.push(chart);
        }
      } catch (e) {
        this.dataError = true;
        alert = this.ts.instant("exterior.settings.messages.detailsSavefailed");
        this.snackService.errorSnackBar(alert);
        this.uiService.hide();
      }
    });

    this.saveChartData(charts);
  }

  saveChartData(charts) {
    let alert;
    this.uiService.show();
    if (charts.length === 0) {
      alert = this.ts.instant("exterior.settings.messages.detailsSavefailed");
      this.snackService.errorSnackBar(alert);
      this.uiService.hide();
    } else {
      this.tourSvc.uploadChart(this.projectId, this.tourId, charts).subscribe(
        (value) => {
          this.uiService.hide();
          alert = this.ts.instant("exterior.settings.messages.uploadSuccess");
          this.snackService.successSnackBar(alert);
        },
        (error) => {
          this.uiService.hide();
          alert = this.ts.instant(
            "exterior.settings.messages.detailsSavefailed"
          );
          this.snackService.errorSnackBar(alert);
        },
        () => {}
      );
    }
  }

  deleteChart(element: ProjectChart) {
    const message = this.ts.instant("dialog.messages.removeChart");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.tourSvc
          .deleteChart(this.projectId, this.tourId, element)
          .subscribe(
            (data) => {
              this.tour = data.tour;
              this.charts = data.tour.charts;
            },
            (err) => {
              this.errors = err;
            }
          );
      }
    });
  }

  isExcelFile(file: File) {
    let fileName = file.name.split(".").pop();
    return fileName === "xls" || fileName === "xlsx" ? true : false;
  }

  uploadNewLayer() {
    this.showUploadLayers = true;
    this.uploadLayers.toggle();
  }

  closeUploadLayers() {
    this.showUploadLayers = false;
    this.uploadLayers.toggle();
  }

  uploadNewCharts() {
    this.showUploadCharts = true;
    this.uploadCharts.toggle();
  }

  closeUploadCharts() {
    this.showUploadCharts = false;
    this.uploadCharts.toggle();
  }

  async closeDialog(): Promise<void> {
    this.dialog.closeAll();
  }

  save3DUrl() {
    let alert;
    if (this.threeDUrl) {
      this.tourSvc
        .updateThreeD(this.projectId, this.tourId, this.threeDUrl)
        .subscribe(
          (value) => {
            this.tour = value.tour;
            this.uiService.hide();
            alert = this.ts.instant("exterior.settings.messages.dataUploaded");
            this.snackService.successSnackBar(alert);
            this.threeDUrl = "";
          },
          (error) => {
            this.uiService.hide();
            alert = this.ts.instant("exterior.threeDUrl.messages.failedToSave");
            this.snackService.errorSnackBar(alert);
          },
          () => {}
        );
    }
  }

  deleteTourUrl() {
    let alert;
    this.tourSvc.updateThreeD(this.projectId, this.tourId, "").subscribe(
      (value) => {
        this.tour = value.tour;
        this.uiService.hide();
        alert = this.ts.instant("exterior.threeDUrl.messages.urlDeleted");
        this.snackService.successSnackBar(alert);
      },
      (error) => {
        this.uiService.hide();
        alert = this.ts.instant("exterior.threeDUrl.messages.failedToSave");
        this.snackService.errorSnackBar(alert);
      },
      () => {}
    );
  }

  updatePointCloudObjectCount(count) {
    let alert: string;
    if (count == 0) {
      alert = this.ts.instant(
        "exterior.pointCloudObjects.messages.objectCountZeroError"
      );
      this.snackService.errorSnackBar(alert);
      return;
    }
    this.tourSvc
      .updatePointCloudObjectCount(this.projectId, this.tourId, parseInt(count))
      .subscribe(
        (value) => {
          this.tour = value.tour;
          this.pointCloudObjectCount = value.tour.objectCount;
          this.uiService.hide();
          alert = this.ts.instant(
            "exterior.pointCloudObjects.messages.dataSaveSuccess"
          );
          this.snackService.successSnackBar(alert);
        },
        (error) => {
          this.uiService.hide();
          alert = this.ts.instant(
            "exterior.pointCloudObjects.messages.failedToSave"
          );
          this.snackService.errorSnackBar(alert);
        },
        () => {}
      );
  }

  // Updating Aerial Tour Latitude and Longitude

  get f() {
    return this.latLngForm.controls;
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  getAerialTourLatLngData() {
    if (this.tour.status.code === "AT10003") {
      this.tourReadyToVisualise = true;
    }
    if (this.tourReadyToVisualise) {
      this.latLngForm.patchValue({ latitude: this.tour.lat });
      this.latLngForm.patchValue({ longitude: this.tour.lng });
    }
  }

  latLngFormReset() {
    this.getAerialTourLatLngData();
  }

  onSubmit() {
    const newLatLngValues = this.latLngForm.value;
    if (this.latLngForm.valid) {
      const message = this.ts.instant("dialog.messages.updateAerialTourLatLng");
      const successBtn = this.ts.instant("dialog.updateBtn");
      const icon = "warning";
      const dialogData = new ConfirmAlertModel(
        this.ts.instant("dialog.updateLatLng"),
        message,
        successBtn,
        icon
      );
      const dialogRef = this.dialog.open(ConfirmAlertComponent, {
        maxWidth: "400px",
        data: dialogData,
      });

      dialogRef.afterClosed().subscribe((dialogResult) => {
        this.result = dialogResult;
        if (this.result) {
          this.uiService.show();
          this.tourSvc
            .updateAerialTourLatLng(
              this.projectId,
              this.tourId,
              newLatLngValues
            )
            .subscribe(
              (data) => {
                const alert = this.ts.instant(
                  "exterior.list.messages.aerialTourLatLngUpdatedSuccessfully"
                );
                this.uiService.hide();
                this.snackService.successSnackBar(alert);
              },
              (err) => {
                const alert = this.ts.instant(
                  "exterior.list.messages.aerialTourLatLngUpdateFailed"
                );
                this.uiService.hide();
                this.snackService.errorSnackBar(alert);
                this.errors = err;
              }
            );
        } else {
          this.getAerialTourLatLngData();
        }
      });
    } else {
      const alert = this.ts.instant("exterior.list.messages.enterLatLngValues");
      this.snackService.errorSnackBar(alert);
    }
  }

  // Re-arranging mapbox layer visibility using table row drag-drop

  editMapboxLayerOrder() {
    this.editMapboxTourLayerOrder = !this.editMapboxTourLayerOrder;
  }

  dropTable(event: CdkDragDrop<string[]>) {
    const prevIndex = this.dataSource.filteredData.findIndex(
      (d) => d === event.item.data
    );
    moveItemInArray(
      this.dataSource.filteredData,
      prevIndex,
      event.currentIndex
    );
    this.table.renderRows();
    this.newMapboxLayerArray = event.container.data["filteredData"];
  }

  submitMapboxLayerOrder() {
    this.submitMapboxTourLayerOrder = !this.submitMapboxTourLayerOrder;

    if (this.newMapboxLayerArray === undefined) {
      this.editMapboxTourLayerOrder = !this.editMapboxTourLayerOrder;
      this.submitMapboxTourLayerOrder = false;

      const alert = this.ts.instant(
        "exterior.settings.messages.layerOrderUnchanged"
      );
      this.snackService.warningSnackBar(alert);
    }

    if (
      this.submitMapboxTourLayerOrder &&
      this.newMapboxLayerArray !== undefined
    ) {
      const newMapboxLayerArray = this.newMapboxLayerArray;

      this.submitMapboxLayerOrderArray(newMapboxLayerArray);
    }
  }

  submitMapboxLayerOrderArray(newMapboxLayerArray) {
    const message = this.ts.instant("dialog.messages.updateMapboxLayerOrder");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      let alert;
      if (dialogResult) {
        this.uiService.show();
        this.tourSvc
          .updateMapboxLayerOrder(
            this.projectId,
            this.tourId,
            newMapboxLayerArray
          )
          .subscribe(
            (data) => {
              this.submitMapboxTourLayerOrder =
                !this.submitMapboxTourLayerOrder;
              this.getMapOutput();
              this.uiService.hide();
              this.editMapboxTourLayerOrder = !this.editMapboxTourLayerOrder;
              alert = this.ts.instant(
                "exterior.settings.messages.layerOrderUpdatedSuccessfully"
              );
              this.snackService.successSnackBar(alert);
            },
            (err) => {
              this.uiService.hide();
              this.editMapboxTourLayerOrder = !this.editMapboxTourLayerOrder;
              alert = this.ts.instant(
                "exterior.settings.messages.layerOrderUpdateFailed"
              );
              this.snackService.errorSnackBar(alert);
            }
          );
      } else {
        this.uiService.show();
        this.editMapboxTourLayerOrder = false;
        this.submitMapboxTourLayerOrder = !this.submitMapboxTourLayerOrder;
        this.getMapOutput();
        this.uiService.hide();
      }
    });
  }

  openColorPanel(element) {
    const dialogRef = this.dialog.open(LayerColorComponent, {
      width: "425px",
      height: "300px",
      disableClose: true,
      data: {
        projectId: this.projectId,
        tourId: this.tourId,
        tour: this.tour,
        layerData: element,
      },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {});
  }

  hasReadyForVisualizeAccess(currentUser: User) {
    switch (currentUser.email) {
      case "sanjay@huviair.com":
      case "ayush@huviair.com":
        return true;
      default:
        return false;
    }
  }

  makeTourReadyForVisualization() {
    this.uiService.show();
    let alert;
    this.tourSvc
      .changeTourStatus(this.projectId, this.tourId, "AT10003")
      .subscribe({
        next: (data) => {
          if (data.status === "success") {
            this.uiService.hide();
            alert = this.ts.instant(
              "exterior.settings.messages.successStatusChangeToReadyForVisual"
            );
            this.snackService.successSnackBar(alert);
          }
        },
        error: (err) => {
          this.uiService.hide();
          alert = this.ts.instant(
            "exterior.settings.messages.failureStatusChangeToReadyForVisual"
          );
          this.snackService.errorSnackBar(alert);
        },
      });
  }
}
