import { Component, Input, Output, EventEmitter, OnInit } from "@angular/core";
import { ChartConfiguration, Colors } from "chart.js";

export class ChartHoveredData {
  public elements: any;
  public elevation: any;
  constructor(elements: any, elevation: any) {
    this.elevation = elevation;
    this.elements = elements;
  }
}

@Component({
  selector: "elevation-profile-chart",
  templateUrl: "./elevation-profile-chart.component.html",
  styleUrls: ["./elevation-profile-chart.component.scss"],
})
export class ElevationProfileChartComponent implements OnInit {
  @Input() elevation: any;
  @Output() chartHovered = new EventEmitter<ChartHoveredData>();
  chartHoveredData: ChartHoveredData;
  lineChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: { title: { text: "Elevation (m)", display: true } },
      x: { title: { text: "Distance (m)", display: true } },
    },
    elements: { line: { tension: 0.3 } },
    plugins: {
      legend: {
        display: false,
      },
    },
    events: ["click", "mousemove", "mouseout", "mouseenter", "mouseover"],
    hover: {
      mode: "nearest",
      intersect: false,
      axis: "x",
      includeInvisible: false,
    },
    onHover: (event, elements, chart) => {
      this.chartHoveredData.elements = elements;
      this.chartHovered.emit(this.chartHoveredData);
    },
  };

  public lineChartType: string = "line";
  private lineChartColors: any = {
    borderColor: "#2d4059",
    backgroundColor: "rgba(45,64,89,0.7)", //162, 217, 206
    borderWidth: 2,
    pointBackgroundColor: "rgba(45,64,89,1)",
    pointBorderColor: "#fff",
    // pointBorderWidth: 1,
    // pointRadius: 4,
    pointHoverBackgroundColor: "#fff",
    pointHoverBorderColor: "rgba(45,64,89,1)",
    fill: "origin",
    // pointHoverBorderWidth: 1,
  };

  ngOnInit(): void {
    this.elevation.lineChartData = JSON.parse(
      JSON.stringify([
        {
          ...this.elevation.lineChartData[0],
          ...this.lineChartColors,
        },
      ])
    );
    this.chartHoveredData = new ChartHoveredData({}, this.elevation);
  }
}
