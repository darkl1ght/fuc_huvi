import { Component, Inject } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import * as XLSX from "xlsx";
import { v4 as uuidv4 } from "uuid";
import {
  AerialTourService,
  ContentDataService,
  LocalStorageService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";
const FileSaver = require("file-saver");

@Component({
  selector: "app-upload-drone-data",
  templateUrl: "./upload-drone-data.component.html",
  styleUrls: ["./upload-drone-data.component.scss"],
})
export class UploadDroneDataComponent {
  droneFlightLogData = [];
  droneCoordinates = [];
  droneFlightData = [];
  projectId: string;
  tourId: string;
  clientId: string;
  tour: any;
  fileExtensionAllowed: boolean = false;
  uploadedFile: any;
  droneFlightDataPresent: boolean = false;
  cabinetId: any;
  cabinetMetadata: any;
  cabinetRefId: any;
  parentFolderRefId: any;
  uploadUrl: any;
  showSpinner: boolean = false;
  droneFlightVideoExists: boolean = false;
  uploadSuccess: boolean = false;
  dataIsLog: boolean = false;
  project: any;
  isLogButtonDisabled: boolean = true;
  isVideoButtonDisabled: boolean = true;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog,
    public aerialTourService: AerialTourService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    private contentDataService: ContentDataService,
    private localStorage: LocalStorageService
  ) {}

  ngOnInit() {
    this.tour = this.data.tour;
    this.projectId = this.data.projectId;
    this.tourId = this.data.tourId;
    this.project = this.data.project;
    this.droneDataCheck();

    this.clientId = this.localStorage.getClientId();

    this.contentDataService
      .getProjectFolder(this.clientId, this.projectId, "library")
      .subscribe({
        next: (data) => {
          this.cabinetId = data.cabinet.id;
          this.cabinetMetadata = data.cabinet.metadata;
          this.cabinetRefId = data.folder.cabinetRefId;
          this.parentFolderRefId = data.folder.id;
        },
        error: () => {
          this.snackService.errorSnackBar(
            this.ts.instant("Failed to fetch the cabinet details.")
          );
        },
      });
  }

  droneDataCheck() {
    if (
      !this.data.tour.droneFlightData ||
      this.data.tour.droneFlightData.length === 0
    ) {
      this.droneFlightDataPresent = false;
    } else {
      this.droneFlightDataPresent = true;
    }

    if (
      !this.data.tour.droneFlightVideoData ||
      this.data.tour.droneFlightVideoData.length === 0
    ) {
      this.droneFlightVideoExists = false;
    } else {
      this.droneFlightVideoExists = true;
    }
  }

  closeDialog() {
    this.dialog.closeAll();
  }

  onFileChange($event) {
    this.uploadedFile = $event.target.files[0];

    if (this.uploadedFile) {
      this.uploadSuccess = false;
    }

    const fileUploadedName = document.getElementById("fileUploadedName");

    if (this.uploadedFile) {
      fileUploadedName.innerHTML = this.uploadedFile.name;
    }

    const fileExtension = this.uploadedFile.name.split(".").pop();

    if (fileExtension === "xlsx" || fileExtension === "csv") {
      this.isLogButtonDisabled = false;
      this.fileExtensionAllowed = true;
      this.dataIsLog = true;

      const fileReader = new FileReader();

      fileReader.readAsBinaryString(this.uploadedFile);

      fileReader.onload = (e) => {
        const result = e.target?.result;

        const workbook = XLSX.read(result, { type: "binary" });

        workbook.SheetNames.forEach((sheet) => {
          const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheet]);

          this.droneFlightLogData = data;
        });
      };
    } else if (fileExtension === "mp4" || fileExtension === "mov") {
      this.fileExtensionAllowed = true;
      this.isVideoButtonDisabled = false;
      this.dataIsLog = false;
    } else {
      let alert;
      alert = this.ts.instant("exterior.settings.messages.extensionNotAllowed");
      this.snackService.errorSnackBar(alert);
      if (this.fileExtensionAllowed) {
        this.fileExtensionAllowed = false;
        this.isLogButtonDisabled = true;
        this.dataIsLog = false;
        this.isVideoButtonDisabled = true;
      }
    }
  }

  onSubmit() {
    if (this.fileExtensionAllowed && this.dataIsLog) {
      this.showSpinner = !this.showSpinner;
      this.fileExtensionAllowed = false;
      this.isLogButtonDisabled = true;

      if (
        this.droneFlightLogData[0]["time"] !== undefined ||
        this.droneFlightLogData[0]["heading"] !== undefined ||
        this.droneFlightLogData[0]["pitch"] !== undefined ||
        this.droneFlightLogData[0]["roll"] !== undefined
      ) {
        const firstInstanceTimeMS = this.droneFlightLogData[0]["time"];
        const lastInstanceTimeMS =
          this.droneFlightLogData[this.droneFlightLogData.length - 1]["time"];

        const timeForEachInstance =
          (lastInstanceTimeMS - firstInstanceTimeMS) /
          this.droneFlightLogData.length;

        this.droneFlightLogData.forEach((el, index) => {
          this.droneCoordinates.push({
            el,
            time: index * timeForEachInstance,
          });

          const droneFlightDataObject = {
            time: index * timeForEachInstance,
            latitude: el.latitude,
            longitude: el.longitude,
            heading: el.compass_heading,
            pitch: el.pitch,
            roll: el.roll,
          };

          this.droneFlightData.push(droneFlightDataObject);
        });

        this.saveDroneFlightData();
      } else {
        let alert;
        alert = this.ts.instant("exterior.list.messages.incorrectFlightLog");
        this.snackService.errorSnackBar(alert);
        this.showSpinner = false;
        this.isLogButtonDisabled = false;
      }
    } else {
      let alert;
      alert = this.ts.instant("exterior.settings.messages.extensionNotAllowed");
      this.snackService.errorSnackBar(alert);
    }
  }

  saveDroneFlightData() {
    const droneFlightData = [];
    const completeData = {
      flightDataId: uuidv4(),
      uploadedDate: new Date(),
      droneFlightData: this.droneFlightData,
    };

    droneFlightData.push(completeData);

    this.aerialTourService
      .saveDroneFlightData(this.projectId, this.tourId, droneFlightData)
      .subscribe((data) => {
        const result = data.tour.droneFlightData;

        if (Array.isArray(result) && result.length !== 0) {
          let alert;
          alert = this.ts.instant(
            "exterior.list.messages.flightLogSaveSuccess"
          );
          this.snackService.successSnackBar(alert);
          this.uploadSuccess = true;
          this.showSpinner = !this.showSpinner;
          setTimeout(() => this.closeDialog(), 3000);
          setTimeout(() => (this.uploadSuccess = false), 2900);
        } else {
          let alert;
          alert = this.ts.instant("exterior.list.messages.logSaveFailed");
          this.snackService.errorSnackBar(alert);

          setTimeout(() => this.closeDialog(), 2000);
        }
      });
  }

  generateFileObjectId(fileName) {
    const fileObjectId = uuidv4();

    if (fileName.includes(".")) {
      return fileObjectId + "." + fileName.split(".").pop();
    } else {
      return fileObjectId;
    }
  }

  onVideoSubmit() {
    if (this.fileExtensionAllowed && !this.dataIsLog) {
      this.showSpinner = !this.showSpinner;
      this.isLogButtonDisabled = true;

      const flightTour = this.tour.tourName;
      const flightProject = this.project.projectName;
      const fileName = this.uploadedFile.name;
      const fileSize = this.uploadedFile.fileSize;
      const fileObjectId = this.generateFileObjectId(fileName);

      const fileObj = {
        cabinetRefId: this.cabinetRefId,
        parentFolderRefId: this.parentFolderRefId,
        name: fileName,
        description: `Drone Flight Video -> Project - ${flightProject} &  Tour - ${flightTour}`,
        fileObjectId: fileObjectId,
        fileSize: fileSize,
        metadata: [],
      };

      this.contentDataService.uploadFile(fileObj).subscribe((data) => {
        this.uploadUrl = data.signedUrl;
        this.contentDataService
          .uploadFileS3(this.uploadUrl, this.uploadedFile, "")
          .subscribe((data) => {
            let fileDetails = {
              cabinetRefId: this.cabinetRefId,
              parentFolderRefId: this.parentFolderRefId,
              files: [{ fileObjectId: fileObjectId }],
            };
            this.contentDataService
              .updateFileStatus(fileDetails)
              .subscribe((data) => {
                const droneFlightVideoData = data;
                this.aerialTourService
                  .saveDroneFlightVideoData(
                    this.projectId,
                    this.tourId,
                    droneFlightVideoData
                  )
                  .subscribe((data) => {
                    if (data) {
                      this.showSpinner = !this.showSpinner;
                      this.uploadSuccess = !this.uploadSuccess;

                      let alert;
                      alert = this.ts.instant(
                        "exterior.list.messages.flightVideoSaveSuccess"
                      );
                      this.snackService.successSnackBar(alert);

                      setTimeout(() => this.closeDialog(), 3000);
                      setTimeout(() => (this.uploadSuccess = false), 2900);
                    } else {
                      this.showSpinner = false;
                      let alert;
                      alert = this.ts.instant(
                        "exterior.list.messages.flightVideoSaveFailed"
                      );
                      this.snackService.errorSnackBar(alert);
                    }
                  });
              });
          });
      });
    } else {
      let alert;
      alert = this.ts.instant("exterior.settings.messages.extensionNotAllowed");
      this.snackService.errorSnackBar(alert);
    }
  }

  deleteDroneVideo() {
    let fileObjectId = this.tour.droneFlightVideoData[0].fileObjectId;

    const message = this.ts.instant("exterior.list.messages.videoDelete");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      let result = dialogResult;
      if (result) {
        this.showSpinner = true;
        this.contentDataService
          .deleteFileByObjectId(fileObjectId, true)
          .subscribe((data) => {
            if (data.message === "File deleted successfully.") {
              this.aerialTourService
                .deleteDroneFlightVideoData(
                  this.projectId,
                  this.tourId,
                  fileObjectId
                )
                .subscribe((data) => {
                  if (data) {
                    let droneFlightVideoData = data.tour.droneFlightVideoData;
                    if (
                      Array.isArray(droneFlightVideoData) &&
                      droneFlightVideoData.length === 0
                    ) {
                      this.showSpinner = false;
                      this.uploadSuccess = true;
                      const alert = this.ts.instant(
                        "exterior.list.messages.videoDeleteSuccess"
                      );
                      this.snackService.successSnackBar(alert);
                    } else {
                      const alert = this.ts.instant(
                        "exterior.list.messages.videoDeleteFailed"
                      );
                      this.snackService.errorSnackBar(alert);
                    }
                  }
                  setTimeout(() => this.closeDialog(), 1000);
                });
            } else {
              const alert = this.ts.instant(
                "exterior.list.messages.videoDeleteFailed"
              );
              this.snackService.errorSnackBar(alert);
            }
          });
      }
    });
  }

  downloadDroneVideo() {
    const fileObjectId = this.tour.droneFlightVideoData[0].fileObjectId;

    this.contentDataService
      .getFileByObjectId(fileObjectId)
      .subscribe((data) => {
        let downloadURL = data.downloadUrl;
        FileSaver.saveAs(downloadURL);
      });
  }

  deleteDroneFlightLog() {
    const message = this.ts.instant("exterior.list.messages.flightLogDelete");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      let result = dialogResult;
      if (result) {
        this.showSpinner = true;
        const droneFlightLogId = this.tour.droneFlightData[0].flightDataId;

        this.aerialTourService
          .deleteDroneFlightLogData(
            this.projectId,
            this.tourId,
            droneFlightLogId
          )
          .subscribe((data) => {
            if (data) {
              let droneFlightData = data.tour.droneFlightData;
              if (
                Array.isArray(droneFlightData) &&
                droneFlightData.length === 0
              ) {
                const alert = this.ts.instant(
                  "exterior.list.messages.flightLogDeleteSuccess"
                );
                this.snackService.successSnackBar(alert);

                this.showSpinner = false;
                this.uploadSuccess = true;
              } else {
                const alert = this.ts.instant(
                  "exterior.list.messages.flightLogDeleteFailed"
                );
                this.snackService.errorSnackBar(alert);
              }
            }
            setTimeout(() => this.closeDialog(), 2000);
          });
      }
    });
  }
}
