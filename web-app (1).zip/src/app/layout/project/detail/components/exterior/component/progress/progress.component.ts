import { Component, Inject, Input, OnChanges, OnInit } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MatSliderChange } from "@angular/material/slider";
import { TranslateService } from "@ngx-translate/core";
import {
  AccessControlService,
  AerialTourService,
  AppConstants,
  InteriorDialogData,
  MasterDataService,
  UiService,
  UpdateWbsProgressBulk,
  SnackbarService,
} from "src/app/core";
import moment from "moment";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";

@Component({
  selector: "project-progress-component",
  templateUrl: "./progress.component.html",
  styleUrls: ["./progress.component.scss"],
})
export class ProjectProgressComponent implements OnInit, OnChanges {
  @Input() projectId: any;
  @Input() tourId: any;
  masterData: any;
  towerList = [];
  tower: string;
  autoTicks = false;
  invert = false;
  max = 100;
  min = 0;
  showTicks = false;
  step = 1;
  thumbLabel = false;
  value = 7;
  vertical = false;
  tickInterval = 1;
  color = "primary";
  isAnyModified: boolean = false;
  isLoaded = false;
  wbsData: any = [];
  errors: any;
  lowerProgressWarning = this.ts.instant(
    "exterior.list.messages.lowerProgressWarning"
  );
  isIST: boolean = false;
  accessSyncWbs: boolean;
  accessUpdateProgress: boolean;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private uiService: UiService,
    private aerialTourService: AerialTourService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private masterDataSvc: MasterDataService,
    private accessControlService: AccessControlService,
    private snackService: SnackbarService,
    private ts: TranslateService
  ) {}

  public ngOnInit(): void {
    this.accessControlService
      .getObjectAccesses([
        AppConstants.accessObjectKeys.AERIAL_SYNC_WBS,
        AppConstants.accessObjectKeys.AERIAL_UPDATE_PROGRESS,
      ])
      .subscribe({
        next: (data) => {
          const [accessSyncWbs, accessUpdateProgress] = data;
          this.accessSyncWbs = accessSyncWbs.isAllowed;
          this.accessUpdateProgress = accessUpdateProgress.isAllowed;
        },
      });

    this.isIST = new Date().getTimezoneOffset() / 60 == -5.5;
    this.publishWBSTourData();
  }

  ngOnChanges(): void {
    this.getMasterData();
  }

  formatDate(date: Date) {
    return moment(date).fromNow();
  }

  getMasterData() {
    this.masterDataSvc.getMasterData(this.projectId).subscribe(
      (data) => {
        this.masterData = data.master;
        this.setMasterData(this.masterData);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  setMasterData(data) {
    data.workLocation.forEach((location) => {
      if (!location.parentLocationId) {
        this.towerList.push(location);
      }
    });

    //set First tower as default
    if (this.towerList.length > 0) {
      this.selectTower(this.towerList[0].locationId);
    }
  }

  selectTower(loc: string) {
    this.tower = loc;
    this.getWBSData(this.projectId, this.tourId, this.tower);
  }

  getWBSData(projectId, tourId, towerId) {
    this.uiService.show();
    this.aerialTourService.getWBSStatus(projectId, tourId, towerId).subscribe(
      (data) => {
        this.wbsData = data.wbsData;
        this.isAnyModified = false;
        this.wbsData.forEach((element) => {
          element.prev = element.actual;
          element.actualUpdated = false;
          element.isLowerWarning = false;
        });
        this.isLoaded = true;
        this.uiService.hide();
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getSliderTickInterval(): number | "auto" {
    if (this.showTicks) {
      return this.autoTicks ? "auto" : this.tickInterval;
    }

    return 0;
  }

  onInputChange(event: MatSliderChange, wbs) {
    wbs.actualUpdated = true;
    this.isAnyModified = true;
    wbs.actual = event.value;
    this.checkLowerProgressWarning(wbs);
  }

  onActualTextChange(wbs) {
    wbs.actualUpdated = true;
    this.isAnyModified = true;
    this.checkLowerProgressWarning(wbs);
  }

  checkLowerProgressWarning(wbs) {
    if (parseFloat(wbs.actual) < parseFloat(wbs.prev)) {
      if (!wbs.isLowerWarning) {
        wbs.isLowerWarning = true;
        this.snackService.warningSnackBar(this.lowerProgressWarning);
      }
    } else if (parseFloat(wbs.actual) >= parseFloat(wbs.prev)) {
      wbs.isLowerWarning = false;
    }
  }

  updateActualWBSBulk() {
    let payload: UpdateWbsProgressBulk[] = [];
    let isValid: boolean = true;

    this.wbsData.forEach((element) => {
      if (element.actual == undefined) {
        isValid = false;
      }

      element.actual = element.actual > 100 ? 100 : element.actual;
      element.actual = element.actual < 0 ? 0 : element.actual;
      element.comment = element.comment.trim();

      if (element.actualUpdated) {
        payload.push({
          wbsId: element.wbsId,
          progress: element.actual,
          comment: element.comment,
        });
      }
    });

    if (!isValid || payload.length < 1) return;

    this.uiService.show();
    this.aerialTourService
      .updateWBSProgressBulk(this.projectId, this.tourId, payload)
      .subscribe(
        (data) => {
          this.getWBSData(this.projectId, this.tourId, this.tower);
          this.uiService.hide();
        },
        (err) => {
          this.errors = err;
          this.uiService.hide();
        }
      );
  }

  updateActualWBS(wbs) {
    this.uiService.show();
    wbs.actual = wbs.actual > 100 ? 100 : wbs.actual;
    wbs.actual = wbs.actual < 0 ? 0 : wbs.actual;
    wbs.comment = wbs.comment.trim();

    this.aerialTourService
      .updateWBSProgress(
        this.projectId,
        this.tourId,
        wbs.wbsId,
        wbs.actual,
        wbs.comment
      )
      .subscribe(
        (data) => {
          this.getWBSData(this.projectId, this.tourId, this.tower);
          this.uiService.hide();
        },
        (err) => {
          this.errors = err;
          this.uiService.hide();
        }
      );
  }

  publishWBSTourData() {
    this.uiService.show();
    this.aerialTourService
      .publishWBSTourData(this.projectId, this.tourId)
      .subscribe(
        (data) => {
          this.getWBSData(this.projectId, this.tourId, this.tower);
          this.uiService.hide();
        },
        (err) => {
          this.errors = err;
        }
      );
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  onCommentChange(wbs): void {
    wbs.actualUpdated = true;
    this.isAnyModified = true;
  }

  updateActuals() {
    if (this.projectId && this.tourId) {
      let alert: string;
      this.uiService.show();
      this.aerialTourService
        .syncWBSMasterData(this.projectId, this.tourId)
        .subscribe(
          (data) => {
            if (data.status) {
              alert = this.ts.instant(
                "exterior.list.messages.wbsActualsPublished"
              );
              this.snackService.successSnackBar(alert);
            } else {
              alert = this.ts.instant(
                "exterior.list.messages.wbsActualPublishFailed"
              );
              this.snackService.errorSnackBar(alert);
            }

            this.uiService.hide();
          },
          (err) => {
            const alert = this.ts.instant(
              "exterior.list.messages.errorWhileSaving"
            );
            this.snackService.errorSnackBar(alert);
            this.errors = err;
            this.uiService.hide();
          }
        );
    }
  }

  restoreData() {
    this.uiService.show();
    this.aerialTourService
      .restoreWBSBaseline(this.projectId, this.tourId, this.tower)
      .subscribe(
        (data) => {
          this.getWBSData(this.projectId, this.tourId, this.tower);
          this.uiService.hide();
        },
        (err) => {
          this.errors = err;
        }
      );
  }
}
