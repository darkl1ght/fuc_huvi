import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import { UntypedFormGroup, UntypedFormBuilder } from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  AerialTourDialogData,
  ProjectChart,
  StaticUrl,
  AerialTourService,
  UserService,
  User,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";
import * as XLSX from "xlsx";
type AOA = any[][];

@Component({
  selector: "static-map",
  templateUrl: "./static-map.component.html",
  styleUrls: ["./static-map.component.scss"],
})
export class StaticExteriorTourComponent implements OnInit {
  @ViewChild("uploadCharts") uploadCharts: any;
  showUploadCharts: boolean = false;
  tourName: string;
  tourUrl: string;
  displayedColumns: string[] = ["tourName", "tourUrl", "action"];
  dataSource = [];
  tour: StaticUrl = {} as StaticUrl;
  projectId: string = "";
  tourId: string = "";
  result: string = "";
  errors: any;
  fileData: any;
  dataError: boolean = false;
  uploadedFiles: any[] = [];
  projectCharts: ProjectChart[] = [];
  chart: ProjectChart = {} as ProjectChart;
  charts: any = [];
  uploadChartForm: UntypedFormGroup;
  selectedFile: string;
  currentUser: User;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: AerialTourDialogData,
    private tourSvc: AerialTourService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    private userService: UserService
  ) {
    this.currentUser = this.userService.getCurrentUser();
    this.uploadChartForm = this.fb.group({
      layer: [""],
    });
  }

  public ngOnInit(): void {
    this.projectId = this.data.projectId;
    this.tourId = this.data.tour.tourId;
    this.getTourData(this.data.tour);
  }

  getTourData(tour) {
    this.dataSource = tour.staticMap.urls ? tour.staticMap.urls : [];
    this.charts = tour.staticMap.charts ? tour.staticMap.charts : [];
  }

  saveTourData() {
    let alert: string = "";
    if (this.tourName.trim() && this.tourUrl.trim()) {
      this.tour.tourName = this.tourName.trim();
      this.tour.tourUrl = this.tourUrl.trim();

      this.tourSvc
        .saveStaticTourUrl(this.projectId, this.tourId, this.tour)
        .subscribe(
          (data) => {
            alert = this.ts.instant(
              "exterior.staticMap.messages.tourAddSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.getTourData(data);
            this.onReset();
          },
          (err) => {
            alert = this.ts.instant(
              "exterior.staticMap.messages.detailsSavefailed"
            );
            this.snackService.errorSnackBar(alert);
          }
        );
    } else {
      alert = this.ts.instant("exterior.staticMap.messages.tourDataMissing");
      this.snackService.successSnackBar(alert);
    }
  }

  deleteTourUrl(tour): void {
    const message = this.ts.instant("dialog.messages.removeTour");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.tourSvc
          .removeStaticUrl(this.projectId, this.tourId, tour.tourId)
          .subscribe(
            (data) => {
              this.getTourData(data.tour);
            },
            (err) => {
              this.errors = err;
            }
          );
      }
    });
  }

  onReset() {
    this.tourName = "";
    this.tourUrl = "";
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  uploadNewCharts() {
    this.showUploadCharts = true;
    this.uploadCharts.toggle();
  }

  closeUploadCharts() {
    this.showUploadCharts = false;
    this.uploadCharts.toggle();
  }

  onChartUpload(files) {
    let alert;
    if (!this.isExcelFile(files[0])) {
      alert = this.ts.instant("exterior.staticMap.messages.invalidFile");
      this.snackService.errorSnackBar(alert);
      return;
    }
    this.selectedFile = files[0].name;
    this.uploadedFiles.push(files[0]);
    const target: DataTransfer = <DataTransfer>files;
    if (files.length !== 1) throw new Error("Cannot use multiple files");
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: "binary" });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.fileData = <AOA>XLSX.utils.sheet_to_json(ws, {
        header: ["ChartTitle", "ChartType", "ChartData"],
      });
    };
    reader.readAsBinaryString(files[0]);
  }

  uploadData() {
    let alert;
    let charts: ProjectChart[] = [];
    this.fileData.forEach(async (row) => {
      try {
        if (row["ChartData"] !== "Chart Data") {
          let chart: ProjectChart = {} as ProjectChart;
          chart.chartTitle = row["ChartTitle"];
          chart.chartType = row["ChartType"];
          chart.chartData = JSON.parse(row["ChartData"]);
          charts.push(chart);
        }
      } catch (e) {
        this.dataError = true;
        alert = this.ts.instant(
          "exterior.staticMap.messages.detailsSavefailed"
        );
        this.snackService.errorSnackBar(alert);
      }
    });

    this.saveChartData(charts);
  }

  saveChartData(charts) {
    let alert;
    if (charts.length === 0) {
      alert = this.ts.instant("exterior.staticMap.messages.uploadFailed");
      this.snackService.errorSnackBar(alert);
    } else {
      this.tourSvc
        .saveStaticTourChart(this.projectId, this.tourId, charts)
        .subscribe(
          (value) => {
            alert = this.ts.instant(
              "exterior.staticMap.messages.uploadSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.getTourData(value);
          },
          (error) => {
            alert = this.ts.instant("exterior.staticMap.messages.uploadFailed");
            this.snackService.errorSnackBar(alert);
          },
          () => {}
        );
    }
  }

  deleteChart(element: ProjectChart) {
    const message = this.ts.instant("dialog.messages.removeChart");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.tourSvc
          .removeStaticChart(this.projectId, this.tourId, element.chartId)
          .subscribe(
            (data) => {
              this.getTourData(data.tour);
            },
            (err) => {
              this.errors = err;
            }
          );
      }
    });
  }

  isExcelFile(file: File) {
    let fileName = file.name.split(".").pop();
    return fileName === "xls" || fileName === "xlsx" ? true : false;
  }

  publishTour() {
    let alert = "";
    this.tourSvc.publishStaticTour(this.projectId, this.tourId).subscribe(
      (value) => {
        alert = this.ts.instant(
          "exterior.staticMap.messages.tourPublishSuccessful"
        );
        this.snackService.successSnackBar(alert);
        this.closeDialog();
      },
      (error) => {
        alert = this.ts.instant(
          "exterior.staticMap.messages.tourPublishFailed"
        );
        this.snackService.errorSnackBar(alert);
        this.closeDialog();
      },
      () => {}
    );
  }
}
