import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import { ContentDataService, SnackbarService } from "src/app/core";
@Component({
  selector: "aerial-video-mapping",
  templateUrl: "./aerial-video-mapping.component.html",
  styleUrls: ["./aerial-video-mapping.component.scss"],
})
export class AerialVideoMappingComponent {
  @Input() videoUpload: any;
  @Input() tour: any;
  @Input() flightEnded: any;
  @Output() notifyVideoUpload: EventEmitter<any> = new EventEmitter();
  @Output() notifyVideoEnded: EventEmitter<any> = new EventEmitter();
  @Output() notifyVideoPlay: EventEmitter<any> = new EventEmitter();
  @Output() notifyVideoPause: EventEmitter<any> = new EventEmitter();
  @Output() notifyVideoTimeUpdate: EventEmitter<any> = new EventEmitter();
  @Output() notifyVideoStopped = new EventEmitter();
  @ViewChild("droneVideo") droneVideo: ElementRef;
  @ViewChild("exampleBox") exampleBox: ElementRef;
  @ViewChild("videoElement") videoElementRef: ElementRef;

  droneFlightAerialTour: any;
  fileObjectId: any;
  downloadUrl: any;
  viewUrl: any;
  width: any;
  height: any;

  constructor(
    private ts: TranslateService,
    private snackService: SnackbarService,
    private contentDataService: ContentDataService
  ) {}
  ngOnInit() {
    this.droneFlightAerialTour = this.tour;
    this.setDroneVideoSrc();
  }

  ngAfterViewInit() {
    this.droneVideo.nativeElement.addEventListener("ended", (event) => {
      this.notifyVideoEnded.emit(event);
    });

    this.droneVideo.nativeElement.addEventListener("play", (event) => {
      this.notifyVideoPlay.emit(event);
    });

    this.droneVideo.nativeElement.addEventListener("pause", (event) => {
      this.notifyVideoPause.emit(event);
    });

    this.droneVideo.nativeElement.addEventListener("timeupdate", (event) => {
      this.notifyVideoTimeUpdate.emit(event);
    });
  }

  stopVideo() {
    this.droneVideo.nativeElement.pause();
    this.notifyVideoStopped.emit();
  }

  closeVideo() {
    this.videoUpload = !this.videoUpload;
    this.notifyVideoUpload.emit(false);
  }

  setDroneVideoSrc() {
    if (this.droneFlightAerialTour.droneFlightVideoData.length !== 0) {
      const droneVideoData = this.droneFlightAerialTour.droneFlightVideoData[0];
      this.fileObjectId = droneVideoData.fileObjectId;

      this.contentDataService
        .getFileByObjectId(this.fileObjectId)
        .subscribe((data) => {
          this.downloadUrl = data.downloadUrl;
          this.viewUrl = data.viewUrl;

          const droneVideo = document.getElementById("droneVideo");
          droneVideo["src"] = this.viewUrl;
        });
    } else {
      let alert;
      alert = this.ts.instant("exterior.mapbox.messages.droneVideoNotUploaded");
      this.snackService.errorSnackBar(alert);
    }
  }
}
