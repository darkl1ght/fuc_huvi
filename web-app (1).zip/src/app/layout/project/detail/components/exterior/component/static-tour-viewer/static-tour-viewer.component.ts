import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ChartConfiguration } from "chart.js";
import {
  AerialTour,
  AerialTourDialogData,
  DashboardChart,
  UiService,
} from "src/app/core";

@Component({
  selector: "static-tour-viewer",
  templateUrl: "./static-tour-viewer.component.html",
  styleUrls: ["./static-tour-viewer.component.scss"],
})
export class StaticExteriorTourViewerComponent implements OnInit {
  @ViewChild("progressBarPanel") sideNave: any;
  mapUrl: string = "";
  tour: AerialTour;
  tourId: string;
  tourList: any;
  projectCharts: DashboardChart[] = [];
  chartLegend: boolean = true;
  errors: any;
  selectedTourId: string;

  // bar chart
  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    hover: {
      intersect: true,
      mode: "x",
      axis: "x",
    },
    scales: {
      y: {
        beginAtZero: true,
        // max: 100,
        ticks: {
          precision: 0,
        },
      },
    },
  };
  //progress bar
  showProgressBar: boolean = true;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: AerialTourDialogData,
    private uiService: UiService
  ) {}

  public ngOnInit(): void {
    this.tour = this.data.tour;
    this.tourList = this.data.tour.staticMap.urls;
    this.mapUrl = this.data.tour.staticMap.urls[0].tourUrl;
    this.tourId = this.data.tour.staticMap.urls[0].tourId;
    this.setUpProjectCharts(this.data.tour.staticMap.charts);
  }

  changeTour(e) {
    this.uiService.show();
    this.tourId = e.tourId;
    this.mapUrl = this.tourList.find((x) => x.tourId === this.tourId).tourUrl;
    setTimeout(() => {
      this.uiService.hide();
    }, 3000);
  }

  setUpProjectCharts(charts) {
    this.projectCharts = charts;
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  showProgressChart() {
    this.showProgressBar = true;
    this.sideNave.toggle();
  }

  closeProgressBar() {
    this.showProgressBar = false;
    this.sideNave.toggle();
  }
}
