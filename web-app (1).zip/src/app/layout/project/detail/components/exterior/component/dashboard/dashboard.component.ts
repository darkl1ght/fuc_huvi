import { Component, Inject, Input, OnChanges, OnInit } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  AerialTour,
  AerialTourService,
  DashboardChart,
  InteriorDialogData,
  UiService,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { ChartConfiguration, ChartType, Color } from "chart.js";
@Component({
  selector: "ext-dashboard-component",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"],
})
export class ExtDashboardComponent implements OnInit, OnChanges {
  @Input() tour: AerialTour;
  projectCharts: DashboardChart[] = [];
  fileData: any;
  dataError: boolean = false;
  projectId: string;
  tourId: string;
  chartLegend: boolean = true;
  errors: any;

  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
      x: {
        ticks: {
          autoSkip: true,
          callback: function (value, index) {
            return this.getLabelForValue(index).toString().slice(0, 28);
          },
        },
      },
    },
    hover: {
      intersect: true,
      mode: "x",
      axis: "x",
    },
    plugins: {
      colors: { enabled: false },
      tooltip: {
        callbacks: {
          label: (context) => {
            const {
              dataset,
              parsed: { y },
            } = context;
            return `${dataset.label}: ${y}%`;
          },
        },
      },
    },
  };

  public pieChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: "top",
      },
      colors: { enabled: true },
    },
    aspectRatio: 2,
  };

  public scatterChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      colors: { enabled: true },
      legend: {
        // Reference:
        // https://www.youtube.com/watch?v=aAzZDG_L-i4&ab_channel=ChartJS
        display: true,
        onClick: (click, legendItem, legend) => {
          const datasets = legend.legendItems.map((dataset, index) => {
            return dataset.text;
          });
          const index = datasets.indexOf(legendItem.text);
          if (legend.chart.isDatasetVisible(index)) {
            legend.chart.hide(index);
          } else {
            legend.chart.show(index);
          }
        },
        labels: {
          usePointStyle: true,
          generateLabels: (chart) => {
            let visibility = [];
            for (let i in chart.data.datasets) {
              if (chart.isDatasetVisible(parseInt(i))) {
                visibility.push(false);
              } else {
                visibility.push(true);
              }
            }
            let pointStyle = [];
            chart.data.datasets.forEach((dataset) => {
              pointStyle.push(dataset["pointStyle"]);
            });
            return chart.data.datasets.map((dataset, index) => ({
              text: dataset.label,
              fillStyle: dataset.backgroundColor as Color,
              strokeStyle: dataset.backgroundColor as Color,
              pointStyle: pointStyle[index],
              hidden: visibility[index],
            }));
          },
        },
      },
    },
  };

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private uiService: UiService,
    private aerialTourService: AerialTourService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  public ngOnInit(): void {}

  ngOnChanges(): void {
    this.getCharts();
  }

  getChartOptions(chartType: ChartType): ChartConfiguration["options"] {
    let options: ChartConfiguration["options"];
    switch (chartType) {
      case "line":
      case "bar":
        options = this.barChartOptions;
        break;
      case "pie":
        options = this.pieChartOptions;
        break;
      case "scatter":
        options = this.scatterChartOptions;
        break;
    }

    return options;
  }

  getCharts() {
    this.uiService.show();
    this.aerialTourService
      .getCharts(this.tour.projectId, this.tour.tourId)
      .subscribe(
        (data) => {
          this.projectCharts = data.charts?.length ? data.charts : [];
          this.projectCharts.map((chart) => {
            // Handling scatter charts separately due to varying titles
            // on the x and y axis from labels in chartData,
            // requiring different scale options.
            if (chart.chartType === "scatter") {
              chart.chartOptions = JSON.parse(
                JSON.stringify(this.scatterChartOptions)
              );
              chart.chartOptions.scales = {
                y: {
                  title: {
                    text: chart.chartData.labels[1] || "y-title",
                    display: true,
                    font: {
                      size: 16,
                      weight: 400,
                    },
                  },
                },
                x: {
                  title: {
                    text: chart.chartData.labels[0] || "x-title",
                    display: true,
                    font: {
                      size: 16,
                      weight: 400,
                    },
                  },
                  type: "linear",
                  position: "bottom",
                },
              };
            }
            return chart.chartData.datasets.map((data) => {
              if (chart.chartType === "line" || chart.chartType === "bar") {
                data.hoverBackgroundColor = data.backgroundColor;
                data.hoverBorderColor = data.borderColor;
              }
              data.hoverOffset = 4;
            });
          });
          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
