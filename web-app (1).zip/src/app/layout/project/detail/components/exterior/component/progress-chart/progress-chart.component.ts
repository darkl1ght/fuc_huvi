import { Component, Inject, Input, OnChanges, OnInit } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import {
  AerialTour,
  AerialTourService,
  DashboardChart,
  InteriorDialogData,
  MasterDataService,
  UiService,
  WBSData,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { saveAs } from "file-saver";
import { ChartConfiguration } from "chart.js";

@Component({
  selector: "ext-self-serve-progress-chart",
  templateUrl: "./progress-chart.component.html",
  styleUrls: ["./progress-chart.component.scss"],
})
export class ProgressChartComponent implements OnInit, OnChanges {
  @Input() tour: AerialTour;
  projectCharts: DashboardChart[] = [];
  projectChartsOverAll: DashboardChart[] = [];
  fileData: any;
  dataError: boolean = false;
  projectId: string;
  tourId: string;
  chartLegend: boolean = true;
  errors: any;

  masterData: any;
  towerList = [];
  tower: string;
  autoTicks = false;
  isLoaded = false;
  showFullProject: boolean = false;
  barDefaultColor: any = "#9CCC65";

  // bar chart
  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
      x: {
        ticks: {
          autoSkip: true,
          callback: function (value, index) {
            return this.getLabelForValue(index).toString().slice(0, 28);
          },
        },
      },
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: (context) => {
            const {
              dataset,
              datasetIndex,
              dataIndex,
              parsed: { y },
            } = context;
            if (datasetIndex == 0) {
              return `${dataset.label}: ${y}%`;
            } else if (datasetIndex == 1) {
              // for actuals
              const modLabel = `${dataset.label}: ${y}% ${
                dataset["toolTip"] ? dataset["toolTip"][dataIndex] : ""
              }`;
              return modLabel.trim();
            }
          },
        },
      },
    },
  };

  public sCurveData = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        pointHoverBackgroundColor: "#42A5F5",
        pointHoverBorderColor: "#1E88E5",
        pointBackgroundColor: "#42A5F5",
        pointBorderColor: "#1E88E5",
      },
      {
        label: "",
        backgroundColor: "#9CCC65",
        borderColor: "#7CB342",
        fill: false,
        data: [],
        pointHoverBackgroundColor: "#9CCC65",
        pointHoverBorderColor: "#7CB342",
        pointBackgroundColor: "#9CCC65",
        pointBorderColor: "#7CB342",
      },
    ],
  };

  public bar = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        hoverBackgroundColor: "#42A5F5",
        hoverBorderColor: "#1E88E5",
      },
      {
        label: "",
        backgroundColor: [], // "#9CCC65",
        borderColor: "#7CB342",
        fill: false,
        data: [],
        toolTip: [],
        hoverBackgroundColor: "#9CCC65",
        hoverBorderColor: "#7CB342",
      },
    ],
  };

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private uiService: UiService,
    private aerialTourService: AerialTourService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private masterDataSvc: MasterDataService,
    private ts: TranslateService
  ) {}

  public ngOnInit(): void {}

  ngOnChanges(): void {
    this.getMasterData();
  }

  getMasterData() {
    this.masterDataSvc.getMasterData(this.tour.projectId).subscribe(
      (data) => {
        this.masterData = data.master;
        this.setMasterData(this.masterData);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  setMasterData(data) {
    data.workLocation.forEach((location) => {
      if (!location.parentLocationId) {
        this.towerList.push(location);
      }
    });

    //set First tower as default
    if (this.towerList.length > 0) {
      this.selectTower(this.towerList[0].locationId);
    }
  }

  selectTower(loc: string) {
    this.tower = loc;
    this.getChartsByTower(this.tour.projectId, this.tour.tourId, this.tower);
  }

  getCharts(projectId, tourId, towerId) {
    this.uiService.show();
    this.aerialTourService
      .getProgressChart(projectId, tourId, towerId)
      .subscribe(
        (response) => {
          this.projectChartsOverAll = [];
          let data = response.response;
          this.isLoaded = true;
          let sCurve: DashboardChart = {} as DashboardChart;

          if (data.sCurve && data.sCurve.labels.length > 0) {
            sCurve.chartName = this.ts.instant(
              "exterior.mapbox.labels.scurveLabel"
            );
            sCurve.chartType = "line";

            this.sCurveData.labels = data.sCurve.labels;
            this.sCurveData.datasets[0].label = this.ts.instant(
              "exterior.mapbox.labels.plannedLabel"
            );
            this.sCurveData.datasets[0].data = data.sCurve.planned;
            this.sCurveData.datasets[1].label = this.ts.instant(
              "exterior.mapbox.labels.actualLabel"
            );
            this.sCurveData.datasets[1].data = data.sCurve.actual;

            sCurve.data = this.sCurveData;
            this.projectChartsOverAll.push(sCurve);
          }

          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }

  getChartsByTower(projectId, tourId, towerId) {
    this.uiService.show();
    this.aerialTourService
      .getProgressChartByTower(projectId, tourId, towerId)
      .subscribe(
        (response) => {
          this.projectCharts = [];
          let data = response.response;
          this.isLoaded = true;
          let sCurve: DashboardChart = {} as DashboardChart;
          let wbsChart: DashboardChart = {} as DashboardChart;

          if (data.sCurve && data.sCurve.labels.length > 0) {
            sCurve.chartName = this.ts.instant(
              "exterior.mapbox.labels.scurveLabel"
            );
            sCurve.chartType = "line";

            this.sCurveData.labels = data.sCurve.labels;
            this.sCurveData.datasets[0].label = this.ts.instant(
              "exterior.mapbox.labels.plannedLabel"
            );
            this.sCurveData.datasets[0].data = data.sCurve.planned;
            this.sCurveData.datasets[1].label = this.ts.instant(
              "exterior.mapbox.labels.actualLabel"
            );
            this.sCurveData.datasets[1].data = data.sCurve.actual;

            sCurve.data = this.sCurveData;
            this.projectCharts.push(sCurve);
          }

          if (data.wbsChart && data.wbsChart.labels.length > 0) {
            wbsChart.chartName = this.ts.instant(
              "exterior.mapbox.labels.wbsLabel"
            );
            wbsChart.chartType = "bar";

            this.bar.labels = data.wbsChart.labels;
            this.bar.datasets[0].label = this.ts.instant(
              "exterior.mapbox.labels.plannedLabel"
            );
            this.bar.datasets[0].data = data.wbsChart.planned;
            this.bar.datasets[1].label = this.ts.instant(
              "exterior.mapbox.labels.actualLabel"
            );

            this.bar.datasets[1].data = data.wbsChart.actual;

            this.bar.datasets[1].toolTip = data.wbsChart.toolTip;

            if (data?.performanceIndex?.exterior) {
              let colorData: any = [];
              this.bar.datasets[0].data.forEach((item: any, index: any) => {
                let diff = item - this.bar.datasets[1].data[index];
                if (diff >= data.performanceIndex.exterior.wbs.value.rangeVal) {
                  colorData.push(data.performanceIndex.exterior.wbs.color);
                } else {
                  colorData.push(this.barDefaultColor);
                }
              });
              this.bar.datasets[1].backgroundColor = colorData;
            } else {
              let colorData: any = [];
              for (let dat of this.bar.datasets[1].data) {
                colorData.push(this.barDefaultColor);
              }
              this.bar.datasets[1].backgroundColor = colorData;
            }
            wbsChart.data = this.bar;
            this.projectCharts.push(wbsChart);
          }

          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }

  tabClick(tab) {
    this.isLoaded = false;
    if (tab.index === 1) {
      this.getCharts(
        this.tour.projectId,
        this.tour.tourId,
        this.towerList[0].locationId
      );
    } else {
      this.getChartsByTower(this.tour.projectId, this.tour.tourId, this.tower);
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  downloadChartData() {
    this.uiService.show();
    this.aerialTourService
      .downloadChartData(this.tour.projectId)
      .subscribe((file) => {
        const byteArray = new Uint8Array(
          atob(file)
            .split("")
            .map((char) => char.charCodeAt(0))
        );
        var blob = new Blob([byteArray], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8",
        });
        saveAs(blob, `${this.tour.tourName}.xlsx`);
        this.uiService.hide();
      });
  }
}
