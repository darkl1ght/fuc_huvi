import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AerialTourListComponent } from "./component/list/aerial-tour-list.component";
import { AerialTourComponent } from "./aerial-tour.component";

const routes: Routes = [
  {
    path: "",
    component: AerialTourComponent,
    children: [
      {
        path: "",
        redirectTo: "list",
        pathMatch: "prefix",
      },
      {
        path: "list",
        component: AerialTourListComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AerialTourRoutingModule {}
