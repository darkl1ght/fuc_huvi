import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import {
  ConfirmAlertComponent,
  ConfirmAlertModel,
} from "src/app/layout/components/confirm-alert/confirm-alert.component";
import { MatTableDataSource } from "@angular/material/table";
import { TranslateService } from "@ngx-translate/core";
import { take, tap } from "rxjs/operators";
import {
  LookUpService,
  PunchItem,
  PunchListConfig,
  PunchListService,
  UiService,
  User,
  UserService,
  SnackbarService,
  Lookup,
} from "src/app/core";
import { TaskDetailComponent } from "../../../task/component/task-detail/task-detail.component";

@Component({
  selector: "task-list",
  templateUrl: "./task-list.component.html",
  styleUrls: ["./task-list.component.scss"],
})
export class TaskListComponent implements OnInit {
  @Output() notifyClickOnPunchItemDelete: EventEmitter<any> =
    new EventEmitter();
  @Output() notifyClickOnZoomInMarkerIcon: EventEmitter<boolean> =
    new EventEmitter();
  @Output() notifyClickOnPunchItemMarkerType: EventEmitter<any> =
    new EventEmitter();
  @Output() sendPunchItemPolygonMarkerId: EventEmitter<any> =
    new EventEmitter();
  @Input() projectId: string;
  @Input() tourId: string;
  @Input() projectName: string;
  displayedColumns: string[] = [
    "dueDate",
    "workPackage",
    "taskDescription",
    "Action",
  ];
  params: PunchListConfig = {} as PunchListConfig;
  dataSource: any;
  isLoaded: boolean = false;
  punchList: PunchItem[] = [];
  totalRecords: number = 0;
  currentUser: User;
  taskId: any;
  result: any;
  errors: any;
  priorityList: Lookup[];
  isLoading: boolean = false;

  constructor(
    public dialog: MatDialog,
    private punchListSvc: PunchListService,
    private snackService: SnackbarService,
    private lookupSvc: LookUpService,
    private uiService: UiService,
    private ts: TranslateService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.currentUser = this.userService.getCurrentUser();
    this.initializeList();
    this.getTaskPriorityData();
  }

  initializeList() {
    this.getInitialPunchList(this.projectId, this.tourId);
  }

  getTaskPriorityData() {
    this.lookupSvc.getAll("taskPriority").subscribe(
      (data) => {
        this.priorityList = data;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  zoomMarker(element) {
    this.notifyClickOnZoomInMarkerIcon.emit(element);
  }

  getInitialPunchList(projectId, tourId) {
    this.isLoading = true;

    this.punchListSvc
      .getPunchItemsList(this.projectId, this.tourId)
      .pipe(
        take(1),
        tap((data) => {
          if (data) {
            this.punchList = data.punchListData;

            this.punchList.forEach((obj) => {
              obj.workLocationData = [
                obj.workLocation.level1,
                obj.workLocation.level2,
                obj.workLocation.level3,
                obj.workLocation.level4,
              ]
                .filter(Boolean)
                .join(" / ");
            });
            this.totalRecords = data.itemCount;
            this.setUpPunchData(this.punchList);
            this.isLoaded = true;
            this.isLoading = false;
          }
        })
      )
      .subscribe();
  }

  openTaskDetails(item: PunchItem) {
    const dialogRef = this.dialog.open(TaskDetailComponent, {
      panelClass: "full-screen-dialog",
      disableClose: true,
      data: {
        projectId: this.projectId,
        punchItem: item,
        priorityList: this.priorityList,
        projectName: this.projectName,
      },
    });

    dialogRef.afterClosed().subscribe(() => {
      this.initializeList();
    });
  }

  setUpPunchData(punchItemList: PunchItem[]) {
    if (punchItemList.length > 0) {
      this.dataSource = new MatTableDataSource(punchItemList);
    }
  }

  onPunchItemDelete(punchItem) {
    this.deletePunchItem(punchItem);
  }

  deletePunchItem(punchItem) {
    const message = this.ts.instant("dialog.messages.removePunchItem");
    const successBtn = this.ts.instant("dialog.deleteBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.confirmAction"),
      message,
      successBtn,
      icon
    );
    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.uiService.show();

        this.punchListSvc.destroy(this.projectId, punchItem.taskId).subscribe(
          () => {
            const punchListItemMarkerId = punchItem.punchItemMarkerId;
            const punchItemMarkerType = punchItem.markerType;
            const punchItemPolygonMarkerId = punchItem.punchItemPolygonMarkerId;

            this.notifyClickOnPunchItemMarkerType.emit(punchItemMarkerType);
            this.notifyClickOnPunchItemDelete.emit(punchListItemMarkerId);
            this.sendPunchItemPolygonMarkerId.emit(punchItemPolygonMarkerId);

            this.initializeList();
            const alert = this.ts.instant(
              "task.list.messages.punchDeleteSuccess"
            );
            this.uiService.hide();
            this.snackService.successSnackBar(alert);
          },
          (err) => {
            const alert = this.ts.instant(
              "task.list.messages.punchItemDeleteFailed"
            );
            this.snackService.errorSnackBar(alert);
            this.uiService.hide();
            this.errors = err;
          }
        );
      }
    });
  }
}
