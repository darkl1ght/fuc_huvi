import {
  Component,
  OnInit,
  ViewChild,
  Inject,
  ElementRef,
} from "@angular/core";
import { FormControl } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  AerialTagPayload,
  AerialTourService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { COMMA, ENTER } from "@angular/cdk/keycodes";
import { MatChipInputEvent } from "@angular/material/chips";

@Component({
  selector: "aerial-tag",
  templateUrl: "./aerial-tag.component.html",
  styleUrls: ["./aerial-tag.component.scss"],
})
export class AerialTagComponent implements OnInit {
  @ViewChild("tagInput") tagInput: ElementRef<HTMLInputElement>;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  tagCtrl = new FormControl();
  tagList: string[] = [];
  isDataSaved: boolean = false;
  projectId: string;
  tourId: string;

  constructor(
    public dialogRef: MatDialogRef<AerialTagComponent>,
    private tourService: AerialTourService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  public ngOnInit(): void {
    this.tagList = this.data.tour.tagList
      ? JSON.parse(JSON.stringify(this.data.tour.tagList))
      : [];
    this.projectId = this.data.projectId;
    this.tourId = this.data.tour.tourId;
  }

  saveAerialTag() {
    let alert = "";
    let aerialTagPayload: AerialTagPayload;
    aerialTagPayload = {
      tagList: this.tagList,
    };
    this.tourService
      .updateAerialTags(this.projectId, this.tourId, aerialTagPayload)
      .subscribe({
        next: () => {
          this.isDataSaved = true;
          alert = this.ts.instant("exterior.new.messages.detailsCreated");
          this.snackService.successSnackBar(alert);
        },
        error: () => {
          alert = this.ts.instant("exterior.new.messages.detailsSavefailed");
          this.snackService.successSnackBar(alert);
        },
      });
  }

  closeDialog(): void {
    this.dialogRef.close(this.isDataSaved);
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    if ((value || "").trim()) {
      this.tagList.push(value.trim());
    }

    if (input) {
      input.value = "";
    }

    this.tagCtrl.setValue(null);
    this.saveAerialTag();
  }

  remove(item: string): void {
    const index = this.tagList.indexOf(item);

    if (index >= 0) {
      this.tagList.splice(index, 1);
    }

    this.saveAerialTag();
  }
  saveTag() {
    const value = this.tagInput.nativeElement.value.trim();

    if ((value || "").trim()) {
      this.tagList.push(value.trim());
    }

    this.tagCtrl.setValue(null);
    this.saveAerialTag();
  }
}
