import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import {
  Lookup,
  SnackbarService,
  UiService,
  AerialTourService,
  LookUpService,
  MapboxAnnotation,
  MapBoxAnnotationData,
} from "src/app/core";

@Component({
  selector: "new-annotation",
  templateUrl: "./annotation.component.html",
  styleUrls: ["./annotation.component.scss"],
})
export class AnnotationComponent implements OnInit {
  @ViewChild("annotationForm") annotationForm;
  public breakpoint: number;
  public annotationLabel: string = "";
  public addAnnotationForm: UntypedFormGroup;
  annotationTypeList: Lookup[] = [];
  formSubmitAttempt: boolean = false;
  errors = {};
  wasFormChanged = false;
  projectId: string;
  tourId: string;
  annotation: MapboxAnnotation;
  showNewAnnotationFields: boolean = false;
  defaultColor: string = "#ffffff";
  annotationSaveOptions = [
    "Save to Tour",
    "Save to Project",
    "Save to All Projects",
  ];
  selectedSaveType: string = "Save to Tour";
  saveAnnotationTypeToProject: boolean = false;
  saveAnnotationTypeToAllProjects: boolean = false;

  constructor(
    private fb: UntypedFormBuilder,
    private dialogRef: MatDialogRef<AnnotationComponent>,
    @Inject(MAT_DIALOG_DATA) private data: MapBoxAnnotationData,
    private aerialTourService: AerialTourService,
    private lookupSvc: LookUpService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    private uiService: UiService
  ) {
    this.addAnnotationForm = this.fb.group({
      annotationLabel: [
        this.annotationLabel,
        [
          Validators.required,
          Validators.pattern(
            /^[a-zA-Z0-9]+[a-zA-Z0-9+\-,:;=@&#|'<>^*()%!_\.\/\\ ]*$/
          ),
        ],
      ],
      annotationType: ["", [Validators.required]],
      newAnnotationType: "",
      newAnnotationColor: "",
      annotationSaveType: [this.selectedSaveType, Validators.required],
    });

    this.addAnnotationForm
      .get("annotationType")
      .valueChanges.subscribe((val) => {
        if (val === "#9A7D0A") {
          // for setting validations
          this.addAnnotationForm
            .get("newAnnotationType")
            .setValidators(Validators.required);
          this.addAnnotationForm
            .get("newAnnotationColor")
            .setValidators(Validators.required);
        } else {
          // for clearing validations
          this.addAnnotationForm.get("newAnnotationType").clearValidators();
          this.addAnnotationForm.get("newAnnotationColor").clearValidators();
        }
        this.addAnnotationForm
          .get("newAnnotationType")
          .updateValueAndValidity();
        this.addAnnotationForm
          .get("newAnnotationColor")
          .updateValueAndValidity();
      });
  }

  public ngOnInit(): void {
    this.tourId = this.data.tourId;
    this.projectId = this.data.projectId;
    this.annotation = this.data.annotation;
    this.annotationTypeList = this.data.listType;
    if (this.annotation.polygon_label && this.annotation.polygon_color) {
      this.addAnnotationForm.patchValue({
        annotationLabel: this.annotation.polygon_label,
        annotationType: this.annotation.polygon_color,
      });
    }
  }

  get f() {
    return this.addAnnotationForm.controls;
  }

  public onAnnotationAdd(): void {
    this.formSubmitAttempt = true;
    this.markAsDirty(this.addAnnotationForm);
    this.onSubmit();
  }

  closeDialog(): void {
    this.dialogRef.close();
    this.onReset();
  }

  // Choose project type using select dropdown
  changeAnnotationType(e) {
    this.annotationType.setValue(e.value, {
      onlySelf: true,
    });

    if (e.value === "#9A7D0A") {
      this.showNewAnnotationFields = true;
    } else {
      this.showNewAnnotationFields = false;
    }
  }

  onEventLog(eventName: string, event: any) {
    if (eventName === "colorPickerClose" && event) {
      this.newAnnotationColor.setValue(event);
    }
  }

  get annotationType() {
    return this.addAnnotationForm.get("annotationType");
  }

  get newAnnotationType() {
    return this.addAnnotationForm.get("newAnnotationType");
  }

  get newAnnotationColor() {
    return this.addAnnotationForm.get("newAnnotationColor");
  }

  //tslint:disable-next-line:no-any
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 2;
  }

  private markAsDirty(group: UntypedFormGroup): void {
    group.markAsDirty();
    for (const i in group.controls) {
      group.controls[i].markAsDirty();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  getLookupData() {
    this.lookupSvc.getAll("layerColor").subscribe(
      (data) => {
        this.annotationTypeList = data;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  saveAnnotations(newAnnotationTypeColorData, projectId, tourId, annotation) {
    this.aerialTourService
      .saveMapboxAnnotations(projectId, tourId, annotation)
      .subscribe(
        (data) => {
          let alert;
          alert = this.ts.instant(
            "exterior.annotation.messages.annotationSaveSuccess"
          );
          this.snackService.successSnackBar(alert);
          if (newAnnotationTypeColorData.newAnnotationType) {
            this.dialogRef.close({
              newAnnotationTypeColor: [
                newAnnotationTypeColorData.newAnnotationType,
              ],
            });
          } else {
            this.dialogRef.close({
              newAnnotationTypeColor: [],
            });
          }

          this.onReset();
        },
        (err) => {
          let alert;
          alert = this.ts.instant(
            "exterior.annotation.messages.annotationSaveFail"
          );
          this.errors = err;
          this.formSubmitAttempt = false;
          this.snackService.errorSnackBar(alert);
          this.dialogRef.close();
        }
      );
  }

  onSubmit() {
    this.formSubmitAttempt = true;
    if (this.addAnnotationForm.valid) {
      const annotationSaveType =
        this.addAnnotationForm.value.annotationSaveType;
      if (annotationSaveType === "Save to Project") {
        this.saveAnnotationTypeToProject = true;
      } else if (annotationSaveType === "Save to All Projects") {
        this.saveAnnotationTypeToAllProjects = true;
      }

      this.updateAnnotation(this.addAnnotationForm.value);
      if (this.showNewAnnotationFields) {
        this.aerialTourService
          .saveNewAnnotationTypeToTour(this.tourId, this.projectId, {
            value: this.newAnnotationType.value,
            key: this.newAnnotationColor.value,
          })
          .subscribe((newAnnotationTypeColorData) => {
            if (this.saveAnnotationTypeToProject) {
              this.saveAnnotationTypeToProject = false;
              this.aerialTourService
                .saveNewAnnotationTypeToProject(this.tourId, this.projectId, {
                  value: this.newAnnotationType.value,
                  key: this.newAnnotationColor.value,
                })
                .subscribe((newAnnotationTypeProject) => {
                  if (newAnnotationTypeProject.newAnnotationType.length !== 0) {
                    this.saveAnnotations(
                      newAnnotationTypeColorData,
                      this.projectId,
                      this.tourId,
                      this.annotation
                    );
                  }
                });
            } else if (this.saveAnnotationTypeToAllProjects) {
              this.uiService.show();
              this.saveAnnotationTypeToAllProjects = false;

              this.aerialTourService
                .saveNewAnnotationTypeToAllProjects(
                  this.tourId,
                  this.projectId,
                  {
                    value: this.newAnnotationType.value,
                    key: this.newAnnotationColor.value,
                  }
                )
                .subscribe((newAnnotationTypeAllProjects) => {
                  this.uiService.hide();
                  if (
                    newAnnotationTypeAllProjects.newAnnotationType.length !== 0
                  ) {
                    this.saveAnnotations(
                      newAnnotationTypeColorData,
                      this.projectId,
                      this.tourId,
                      this.annotation
                    );
                  }
                });
            } else {
              this.saveAnnotations(
                newAnnotationTypeColorData,
                this.projectId,
                this.tourId,
                this.annotation
              );
            }
          });
      } else {
        this.saveAnnotations({}, this.projectId, this.tourId, this.annotation);
      }
    }
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.annotationForm.resetForm();
    this.addAnnotationForm.reset();
  }

  updateAnnotation(values: Object) {
    this.annotation.polygon_label = values["annotationLabel"].trim();
    if (this.showNewAnnotationFields) {
      this.annotation.polygon_color = this.newAnnotationColor.value;
    } else {
      this.annotation.polygon_color = this.annotationTypeList.find(
        (x) => x.key === values["annotationType"]
      ).key;
    }
  }
}
