import { NgModule } from "@angular/core";
import { SharedModule } from "src/app/shared";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { AerialTourComponent } from "./aerial-tour.component";
import { AerialTourListComponent } from "./component/list/aerial-tour-list.component";
import { NewAerialTourComponent } from "./component/new/new-aerial-tour.component";
import { AerialTourRoutingModule } from "./aerial-tour-routing.module";
import { UploadAerialTourDataComponent } from "./component/upload/upload-data.component";
import {
  MapboxComponent,
  SurfaceElevationComponent,
  SurfaceVolumeComponent,
} from "./component/mapbox/mapbox.component";
import { MapSettingsComponent } from "./component/settings/map-settings.component";
import { AnnotationComponent } from "./component/annotation/annotation.component";
import { ExtDashboardComponent } from "./component/dashboard/dashboard.component";
import { StaticExteriorTourComponent } from "./component/static-map/static-map.component";
import { StaticExteriorTourViewerComponent } from "./component/static-tour-viewer/static-tour-viewer.component";
import { LegendComponent } from "./component/legend/legend.component";
import { ProjectProgressComponent } from "./component/progress/progress.component";
import { ProgressChartComponent } from "./component/progress-chart/progress-chart.component";
import { ColorPickerModule } from "ngx-color-picker";
import { ReportComponent } from "./component/report/report.component";
import { NewTaskComponent } from "./component/new-task/new-task.component";
import { TaskListComponent } from "./component/task-list/task-list.component";
import { ElevationProfileChartComponent } from "./component/elevation-profile-chart/elevation-profile-chart.component";
import { AerialVideoMappingComponent } from "./component/aerial-video-mapping/aerial-video-mapping.component";
import { UploadDroneDataComponent } from "./component/upload-drone-data/upload-drone-data.component";
import { LayerColorComponent } from "./layer-color/layer-color.component";
import { AerialTagComponent } from "./component/tag/aerial-tag.component";

@NgModule({
  imports: [AerialTourRoutingModule, SharedModule, ColorPickerModule],
  declarations: [
    AerialTourComponent,
    AerialTourListComponent,
    NewAerialTourComponent,
    UploadAerialTourDataComponent,
    MapboxComponent,
    MapSettingsComponent,
    AnnotationComponent,
    ExtDashboardComponent,
    StaticExteriorTourComponent,
    StaticExteriorTourViewerComponent,
    SurfaceVolumeComponent,
    SurfaceElevationComponent,
    LegendComponent,
    ProjectProgressComponent,
    ProgressChartComponent,
    ReportComponent,
    NewTaskComponent,
    TaskListComponent,
    ElevationProfileChartComponent,
    AerialVideoMappingComponent,
    UploadDroneDataComponent,
    LayerColorComponent,
    AerialTagComponent,
  ],
  providers: [
    { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} },
  ],
})
export class AerialTourModule {}
