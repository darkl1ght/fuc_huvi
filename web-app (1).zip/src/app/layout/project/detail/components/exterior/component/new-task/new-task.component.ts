import {
  Component,
  OnInit,
  ViewChild,
  Input,
  Output,
  EventEmitter,
  Inject,
} from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import {
  Lookup,
  LookUpService,
  MasterDataService,
  PunchItem,
  PunchListService,
  PunchListData,
  UiService,
  Guid,
  StorageService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";

import { MatDialog } from "@angular/material/dialog";
import { uuidv4 } from "../../../interior/walkthrough/walkthrough-utils";

@Component({
  selector: "new-task",
  templateUrl: "./new-task.component.html",
  styleUrls: ["./new-task.component.scss"],
})
export class NewTaskComponent implements OnInit {
  @ViewChild("newTaskForm") newTaskForm;
  @Output() notifyClose: EventEmitter<boolean> = new EventEmitter();
  @Output() notifyPunchItemMarkerCancellation: EventEmitter<boolean> =
    new EventEmitter();
  @Output() notifyPunchItemDataSave: EventEmitter<string> = new EventEmitter();
  @Output() notifyDescriptionInput: EventEmitter<string> = new EventEmitter();
  @Output() notifyPunchItemRemarkDescription: EventEmitter<string> =
    new EventEmitter();
  @Input() projectId: string;
  @Input() tour: any;
  @Input() files: any;
  @Input() punchItemMarkerId: any;
  @Input() punchItemMarkerLat: any;
  @Input() punchItemMarkerLng: any;
  @Input() markerType: any;
  @Input() punchItemPolygonMarkerId: any;
  public breakpoint: number;
  public addTaskForm: UntypedFormGroup;

  workPackage = [];
  level1Location = [];
  level2Location = [];
  level3Location = [];
  level4Location = [];
  stage1Approver = [];
  stage2Approver = [];
  priorityList: Lookup[] = [];
  formSubmitAttempt: boolean = false;
  punchListData: PunchListData = {} as PunchListData;
  errors = {};
  wasFormChanged = false;
  masterData: any;
  selectedLocations: string[] = [];
  punchGroupId: string;
  formSubmitted: boolean;

  workPackageId: string;
  dueDate: string;
  level1Approvers: string[] = [];
  level2Approvers: string[] = [];
  accessToken: string;
  readonly NoWhitespaceRegExp: RegExp = new RegExp("\\S");

  constructor(
    private fb: UntypedFormBuilder,
    private lookupSvc: LookUpService,
    private masterDataSvc: MasterDataService,
    private snackService: SnackbarService,
    private punchListService: PunchListService,
    private uiService: UiService,
    private ts: TranslateService,
    public dialog: MatDialog,
    @Inject(APP_CONFIG) private config: AppConfig,
    private storageSvc: StorageService
  ) {
    this.addTaskForm = this.fb.group({
      punchId: null,
      description: [
        "",
        [Validators.required, Validators.pattern(this.NoWhitespaceRegExp)],
      ],
      ramark: ["", null],
      taskPriority: ["", [Validators.required]],
      workPackage: ["", [Validators.required]],
      dueDate: ["", [Validators.required]],
      level1Approver: [this.level1Approvers, [Validators.required]],
      level2Approver: [this.level2Approvers, [Validators.required]],
      isNonConformity: [true, ""],
    });
  }

  public ngOnInit(): void {
    this.getToken();
    this.getLookupData();
    this.getMasterData();
  }

  getLookupData() {
    this.lookupSvc.getAll("taskPriority").subscribe(
      (data) => {
        this.priorityList = data;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getMasterData() {
    this.masterDataSvc.getMasterData(this.projectId).subscribe(
      (data) => {
        this.masterData = data.master;
        this.setMasterData(this.masterData);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  changeWorkPackage(event) {
    this.stage1Approver = [];
    this.stage2Approver = [];
    if (event) {
      this.workPackage.forEach((wp) => {
        if (wp.tradeId === event.value) {
          this.stage1Approver = this.stage1Approver.concat(wp.level1);
          this.stage2Approver = this.stage2Approver.concat(wp.level2);
        }
      });
    }
  }

  get f() {
    return this.addTaskForm.controls;
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 2;
  }

  setMasterData(data) {
    data.workPackage.forEach((wp) => {
      if (
        wp.level1 &&
        wp.level1.length > 0 &&
        wp.level2 &&
        wp.level2.length > 0
      ) {
        this.workPackage.push(wp);
      }
    });
    data.workLocation.forEach((location) => {
      if (!location.parentLocationId) {
        this.level1Location.push(location);
      }
    });
  }

  onSubmit(refresh: boolean) {
    this.formSubmitAttempt = true;
    if (this.addTaskForm.valid) {
      const fileId = Guid.newGuid();
      this.uploadFiles(this.files, fileId);
    }
  }

  submitPunchData(mediaList) {
    this.uiService.show();
    let alert = "";
    this.formSubmitted = true;
    this.updatePunchData(this.addTaskForm.value, mediaList);
    this.notifyPunchItemRemarkDescription.emit(
      this.punchListData.punchItems[0].taskDescription
    );
    this.punchListService
      .bulkUploadAerialPunchItem(this.projectId, this.punchListData)
      .subscribe(
        (value) => {
          this.uiService.hide();
          alert = this.ts.instant("task.new.messages.punchDataSaveSuccess");
          this.snackService.successSnackBar(alert);
          this.notifyPunchItemDataSave.emit(
            this.punchListData.punchItemMarkerId
          );

          this.closeDialog(true);
          this.formSubmitted = false;
        },
        (error) => {
          this.uiService.hide();
          alert = this.ts.instant("task.new.messages.punchDataSaveFailed");
          this.snackService.errorSnackBar(alert);
          this.formSubmitted = false;
        },
        () => {}
      );
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.newTaskForm.resetForm();
    this.addTaskForm.reset();
  }

  updatePunchData(values: Object, mediaList) {
    const task: PunchItem = {} as PunchItem;
    this.punchListData.workPackageId = values["workPackage"].trim();
    this.punchListData.dueDate = values["dueDate"];
    this.punchListData.tourId = this.tour.tourId;
    this.punchListData.tourName = this.tour.tourName;
    this.punchListData.punchItemMarkerId = uuidv4();
    this.punchListData.punchItemMarkerLat = this.punchItemMarkerLat;
    this.punchListData.punchItemMarkerLng = this.punchItemMarkerLng;
    this.punchListData.markerType = this.markerType;
    this.punchListData.punchItemPolygonMarkerId = this.punchItemPolygonMarkerId;
    this.punchListData.stage1Approver = values["level1Approver"];
    this.punchListData.stage2Approver = values["level2Approver"];

    this.punchListData.locations = [
      this.tour.locationId ? this.tour.locationId : this.tour.towerId,
    ];

    task.taskDescription = values["description"];
    task.remark = values["ramark"];
    task.isNonConformity = values["isNonConformity"] ? true : false;
    task.taskPriority = {
      code: this.priorityList.find((x) => x.key === values["taskPriority"]).key,
      desc: this.priorityList.find((x) => x.key === values["taskPriority"])
        .value,
    };

    task.mediaList = mediaList;

    this.punchListData.punchItems = [task];
  }

  closeDialog(refresh: boolean) {
    this.onReset();
    this.notifyClose.emit(refresh);
  }

  removePunchItemMarkerOnCancel(refresh: boolean) {
    this.onReset();
    this.notifyPunchItemMarkerCancellation.emit(refresh);
  }

  sendDescription(input: string) {
    this.notifyDescriptionInput.emit(input);
  }

  async uploadFiles(files, fileId: string) {
    const extn = "jpeg";
    const blobRef = fileId + "." + extn;
    if (files) {
      try {
        this.uiService.show();
        const blobServiceClient = new BlobServiceClient(
          this.config.blobUrl + "/?" + this.accessToken
        );

        const containerClient = blobServiceClient.getContainerClient(
          this.config.mediaContainer
        );
        const promises = [];
        const blockBlobClient = containerClient.getBlockBlobClient(blobRef);
        promises.push(blockBlobClient.uploadBrowserData(files));
        await Promise.all(promises);
        this.savePunchListData(fileId, blobRef);
        this.uiService.hide();
      } catch (error) {
        this.uiService.hide();
      }
    } else {
      this.savePunchListData(fileId, blobRef);
      this.uiService.hide();
    }
  }

  savePunchListData(fileId, blobRef) {
    let mediaList = [
      {
        mediaId: fileId,
        blobReference: blobRef,
        fileName: blobRef,
        features: null,
        mediaCreateDate: null,
        state: "created",
      },
    ];

    this.submitPunchData(mediaList);
  }

  getToken() {
    const container = this.config.mediaContainer;
    this.storageSvc.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }
}
