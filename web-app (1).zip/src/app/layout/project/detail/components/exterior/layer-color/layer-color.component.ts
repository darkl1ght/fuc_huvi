import { Component, ElementRef, Inject, ViewChild } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import { AerialTourService, SnackbarService } from "src/app/core";
@Component({
  selector: "layer-color",
  templateUrl: "./layer-color.component.html",
  styleUrls: ["./layer-color.component.scss"],
})
export class LayerColorComponent {
  @ViewChild("colorCodePicker") colorCodePicker: ElementRef;
  tour: any;
  projectId: any;
  tourId: any;
  project: any;
  newColorArray = [];
  colorChanged: boolean = false;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog,
    private AerialTourService: AerialTourService,
    private ts: TranslateService,
    private snackService: SnackbarService
  ) {}
  color: string;
  presentColor: string;
  layerData = this.data.layerData;

  ngOnInit() {
    this.tour = this.data.tour;
    this.projectId = this.data.projectId;
    this.tourId = this.data.tourId;
    this.project = this.data.project;

    if (
      this.layerData.filename === "contour.zip" ||
      this.layerData.key === "CONTOUR"
    ) {
      this.contourLayerColor(this.layerData);
    } else if (
      this.layerData.filename === "boundary.zip" ||
      this.layerData.key === "BOUNDARY"
    ) {
      this.boundaryLayerColor(this.layerData);
    }

    const initialColorCode = document.getElementById("colorCode");
    initialColorCode.innerHTML = this.presentColor;
  }

  closeDialog() {
    this.dialog.closeAll();
  }

  contourLayerColor(layerData) {
    if (layerData.shapefileColor) {
      this.presentColor = layerData.shapefileColor;
    } else {
      this.presentColor = "#000000";
    }
  }

  boundaryLayerColor(layerData) {
    if (layerData.shapefileColor) {
      this.presentColor = layerData.shapefileColor;
    } else {
      this.presentColor = "#ff0000";
    }
  }

  onColorChange(event) {
    if (event) {
      this.color = event.target.value;
    }

    const colorCode = document.getElementById("colorCode");

    if (this.color !== this.presentColor) {
      colorCode.innerHTML = this.color;
      this.colorChanged = true;
    }

    const colorObject = {
      layerName: this.layerData.filename,
      newLayerColor: this.color,
    };

    const newColorArray = [];

    newColorArray.push(colorObject);
    this.newColorArray = newColorArray;
  }

  onSubmit() {
    if (this.color) {
      this.AerialTourService.saveShapefileColorData(
        this.projectId,
        this.tourId,
        this.newColorArray
      ).subscribe((data) => {
        const updatedData = data;

        if (updatedData) {
          const alert = this.ts.instant(
            "exterior.settings.messages.layerColorUpdateSuccess"
          );
          this.snackService.successSnackBar(alert);
        } else {
          const alert = this.ts.instant(
            "exterior.settings.messages.layerColorUpdateFailed"
          );
          this.snackService.errorSnackBar(alert);
        }

        setTimeout(() => {
          this.closeDialog();
          this.colorChanged = false;
        }, 1000);
      });
    }
  }
}
