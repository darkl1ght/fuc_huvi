import {
  Component,
  OnInit,
  ViewChild,
  Inject,
  OnChanges,
  HostListener,
  ChangeDetectorRef,
  AfterViewInit,
} from "@angular/core";
declare const window: any;

import * as mapboxgl from "mapbox-gl";
import * as turf from "@turf/turf";
import MapboxDraw from "@mapbox/mapbox-gl-draw";
import RulerControl from "mapbox-gl-controls/lib/ruler.js";
import CompassControl from "mapbox-gl-controls/lib/compass.js";

import { v4 as uuidv4 } from "uuid";
import { environment } from "src/environments/environment";
import domtoimage from "dom-to-image";

// raster layer elevation extractor
declare let L;
import "leaflet";
import "node_modules/leaflet-geotiff/leaflet-geotiff";
import "node_modules/leaflet-geotiff/leaflet-geotiff-plotty.js";
import "node_modules/leaflet-geotiff/leaflet-geotiff-vector-arrows.js";
import {
  AerialTourDialogData,
  MapboxAnnotation,
  MapboxLayer,
  MapVolumeData,
  Project,
  ElevationProfileData,
  AerialTour,
  User,
  PunchItem,
  ProjectService,
  AerialTourService,
  StorageService,
  LookUpService,
  UiService,
  UserService,
  PunchListService,
  LocalStorageService,
  SnackbarService,
  Lookup,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { AnnotationComponent } from "../annotation/annotation.component";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";
import _ from "lodash";
import { UntypedFormControl, Validators } from "@angular/forms";
import { catchError, take, tap } from "rxjs/operators";
import { empty } from "rxjs";
import { ConnectionPositionPair } from "@angular/cdk/overlay";
import {
  ConfirmAlertComponent,
  ConfirmAlertModel,
} from "src/app/layout/components/confirm-alert/confirm-alert.component";
import { ChartHoveredData } from "../elevation-profile-chart/elevation-profile-chart.component";
import { MatSliderChange } from "@angular/material/slider";
import { Clipboard } from "@angular/cdk/clipboard";
import { AerialVideoMappingComponent } from "../aerial-video-mapping/aerial-video-mapping.component";
import {
  StyleSwitcherControl,
  LengthUnitSymbol,
  AreaMultiplicationFactor,
  AreaUnitSymbol,
  LengthMultiplicationFactor,
  VolumeMultiplicationFactor,
  LengthUnit,
} from "./mapbox-utils";
import { ChartConfiguration } from "chart.js";

@Component({
  selector: "app-mapbox",
  templateUrl: "./mapbox.component.html",
  styleUrls: ["./mapbox.component.scss"],
})
export class MapboxComponent implements OnInit, OnChanges, AfterViewInit {
  @ViewChild("trigger") trigger;
  @ViewChild("taskListTrigger") taskListTrigger;
  @ViewChild("remarksListTrigger") remarksListTrigger;
  @ViewChild("createRemarksTrigger") createRemarksTrigger;
  @ViewChild("projectprogressBarPanel") projectProgressBar;
  @ViewChild("progressBarPanel") sideNave: any;
  @ViewChild("volumePanel") volumePanel: any;
  @ViewChild("elevationPanel") elevationPanel: any;
  @ViewChild("elevationChart") elevationChartCanvas: any;
  @ViewChild("selfServeDashboard") selfServe: any;
  @ViewChild("punchListSideBar") punchSideNav: any;
  @ViewChild("punchItemListTable") punchItemListTable: any;
  @ViewChild(AerialVideoMappingComponent)
  videoComponent: AerialVideoMappingComponent;
  @ViewChild("drawer") layerDrawer: any;

  showProgressBar: boolean = false;
  showSelfServe: Boolean = false;
  isLegendExist: boolean = false;
  isLegendOpen: boolean = false;
  tourType: string = "2D";
  showProjectProgress: boolean = false;
  cadFileName: string = "";
  overlayFile: File;
  overlayProgress: number = 0;

  tour: AerialTour;
  allTours: AerialTour[];
  projectId: string;
  projectName: string;
  tourId: string;

  draw: MapboxDraw;
  map: mapboxgl.Map;
  sidebarMapOverLayer: any;
  style = "mapbox://styles/mapbox/streets-v11";
  lat: number;
  lng: number;
  w_lat: number;
  w_lng: number;
  location: string = "";

  toggleMenuControl: boolean;
  dtmElevationLayer: any;
  dsmElevationLayer: any;
  poylgon_drawn: boolean = false;
  currSelectedAnnotationId: string = null;
  hasSSAccess: boolean = false;

  // for ruler tool
  prevDsmLayerVisibility: string;
  prevDtmLayerVisibility: string;

  colors: Lookup[] = [];
  errors: any;
  defaultZoom: number = 16;
  minZoom: number = 13;
  dsmTileId: string;
  dtmTileId: string;
  mapUrls: MapboxLayer[] = [];
  currMapLayers: MapboxLayer[] = [];
  markerImage: any;

  showVolumeTool: boolean = false;
  volumeList: MapVolumeData[] = [];
  isVolumePending: boolean;
  volumeApiInterval: any;
  project: Project;

  currentMarkers = [];

  showElevationProfileTool: boolean = false;
  elevationProfileList: ElevationProfileData[] = [];
  isElevationProfilePending: boolean;
  elevationProfileApiInterval: any;

  unitOfCalculation: turf.Units = "meters";
  measurementSystem: string = "imperial";

  /**/
  opacityControlOption: boolean = true;
  availableLayers: any;
  _container: HTMLElement;
  allLayers: any[] = [];
  annotationLayers: MapboxAnnotation[] = null;
  toggleAllMapLayers: boolean = true;
  toggleAnnotationLayers: boolean = true;
  toggleAnnotationColorLayers: boolean = true;
  /**/
  blobStorageAccessToken: string;
  mediaAccessToken: string;
  legendUrl: string;

  showElevationTool: boolean = false;
  elevationList: ElevationProfileData[] = [];
  isElevationPending: boolean;

  //elevation chart
  lineChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    events: ["click", "mousemove", "mouseout"],
    hover: { mode: "nearest", intersect: false, axis: "x" },
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: { title: { text: "Elevation (m)", display: true } },
      x: { title: { text: "Distance (m)", display: true } },
    },
  };

  public lineChartLegend = false;
  public lineChartType = "line";
  public lineChartPlugins = [];
  pointcloudUrl: String = null;
  currentUser: User;
  newAnnotationTypeColor: any;
  downloadProgress: any = 0;
  annotationSearchTerm: string = "";
  prevAnnotationSearchTerm: string = "";

  cdkConnectionPairs: ConnectionPositionPair[] = [
    {
      offsetX: -2,
      originX: "start",
      originY: "top",
      overlayX: "end",
      overlayY: "top",
      panelClass: null,
    },
  ];
  showPunchPanel: boolean = false;
  showCreateRemarks: boolean = false;
  showEditRemarks: boolean = false;
  showAll: boolean = false;
  isRemark: boolean = false;
  remarks = [];
  remarksMarkers = [];
  remarksDescription: string;
  editedRemarksDescription: string;
  marker = new mapboxgl.Marker();
  cursorChange: boolean = false;
  markerLat: number;
  markerLng: number;
  snapshot: any;
  readonly NoWhitespaceRegExp: RegExp = new RegExp("\\S");
  remarksFormControl = new UntypedFormControl("", [
    Validators.required,
    Validators.pattern(this.NoWhitespaceRegExp),
  ]);
  editRemarksFormControl = new UntypedFormControl("", [
    Validators.required,
    Validators.pattern(this.NoWhitespaceRegExp),
  ]);
  offset: any = 0;
  limit: any = 5;
  punchList: PunchItem[] = [];
  punchListItemMarkerId: string;
  dataSource: any;
  showPunchListPanel: boolean = false;
  punchCursorChange: boolean = false;
  createAerialPunchListItem: boolean = false;
  displayedColumns: string[] = [
    "dueDate",
    "workPackage",
    "workLocation",
    "taskDescription",
  ];
  createdMarker = [];
  punchItemMarkers = [];
  punchItemMarkerLat: any;
  punchItemMarkerLng: any;
  punchMarkers = [];
  punchItemMarkersList = [];
  punchItemMarkerDescription: any;
  isRemarksDrawMode: boolean = false;
  isPunchItemDrawMode: boolean = false;
  remarkResult: any;
  showElevationLine: any = false;
  deleteElevationProfileDialogResult: any;
  deleteVolumeCalculationDialogResult: any;
  showVolumeCalculationPolygon: boolean = false;
  drawElevationLineMode: boolean = false;
  drawVolumePolygonMode: boolean;
  selectedRemarkToEdit: any;
  volumeEscapeButtonClick: any;
  elevationEscapeButtonClick: any;
  drawRemarkPolygonMode: boolean = false;
  polygonRemarkId: string;
  polygonRemarksCoordinates = [];
  polygonRemarkType: string;
  polygonRemarksLatitudeArray = [];
  polygonRemarksLongitudeArray = [];
  averagePolygonRemarkLat: number;
  polygonRemarkLatSum: number;
  polygonRemarkLngSum: number;
  averageploygonRemarkLng: number;
  polygonRemarkLatitude: number;
  polygonRemarkLongitude: number;
  createNewPunchItemPolygonMode: boolean = false;
  polygonPunchListLongitudeArray = [];
  polygonPunchListLatitudeArray = [];
  polygonPunchListLatSum: number;
  polygonPunchListLngSum: number;
  averagePunchListRemarkLat: number;
  averagePunchListRemarkLng: number;
  polygonPunchListId: any;
  polygonPunchListCoordinates = [];
  polygonPunchListType: string;
  polygonPunchListLatitude: number;
  polygonPunchListLongitude: number;
  markerType: any;
  punchItemMarkerType: any;
  punchItemMarkerId: string;
  drawAnnotationPolygon: boolean = false;
  punchItemPolygonMarkerIdToDelete: any;
  isOpen: boolean = false;
  shareLink: string = null;
  videoUpload: boolean = false;
  currentVideoTimeMS: number;
  droneFlightData = [];
  droneCoordinates = [];
  playTheVideo: boolean;
  droneFlightPath: boolean = false;
  tourLng: any;
  tourLat: any;
  isDroneFlightDataAvailable: boolean = false;
  droneVideoData = [];
  flightEnded: boolean = false;
  droneFlightMode: boolean = false;
  flightMarker: mapboxgl.Marker;
  flightPathCoordinates = [];
  droneFlyCoordinates = [];
  flightButtons: boolean = false;
  showFlightButtons: boolean = false;
  flyData = [];
  markerIndex: any;
  timeoutIds = [];
  playFlightMarkerFlag: boolean = true;
  pauseFlightMarkerFlag: boolean = false;
  resetFlightMarkerFlag: boolean = false;
  droneLogDataAvailable: boolean = false;
  contourLayerColor: any;
  boundaryLayerColor: any;
  count: number = 1;

  LengthUnitSymbol = {
    [LengthUnit.METERS]: "m",
    [LengthUnit.KILOMETERS]: "km",
    [LengthUnit.INCHES]: "inch",
    [LengthUnit.FEET]: "ft",
  };

  LengthMultiplicationFactor = {
    [LengthUnit.METERS]: 1,
    [LengthUnit.KILOMETERS]: 0.001,
    [LengthUnit.INCHES]: 39.3701,
    [LengthUnit.FEET]: 3.28084,
  };

  styles = [
    {
      title: "Streets",
      url: "mapbox://styles/mapbox/streets-v12",
    },
    {
      title: "Satellite",
      url: "mapbox://styles/mapbox/satellite-v9",
    },
    {
      title: "Terrain",
      url: "mapbox://styles/huviair-support/clhyry6a602a701pn6wbf0030",
    },
    {
      title: "Ocean",
      url: "mapbox://styles/huviair-support/clhysnckq02ah01qu40fc2awe",
    },
    {
      title: "Satellite+Streets",
      url: "mapbox://styles/mapbox/satellite-streets-v12",
    },
    {
      title: "Topographical",
      url: "mapbox://styles/mapbox/outdoors-v12",
    },
  ];

  confirmAlertComponentDialogRef: MatDialogRef<ConfirmAlertComponent>;
  annotationComponentDialogRef: MatDialogRef<AnnotationComponent>;
  confirmDialogComponentDialogRef: MatDialogRef<ConfirmDialogComponent>;
  surfaceVolumeComponentDialogRef: MatDialogRef<SurfaceVolumeComponent>;
  surfaceElevationComponentDialogRef: MatDialogRef<SurfaceElevationComponent>;

  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<MapboxComponent>,
    @Inject(MAT_DIALOG_DATA) private data: AerialTourDialogData,
    private projectService: ProjectService,
    private punchListSvc: PunchListService,
    private snackService: SnackbarService,
    private lookupSvc: LookUpService,
    private uiService: UiService,
    private aerialTourService: AerialTourService,
    private storageService: StorageService,
    private ts: TranslateService,
    private userService: UserService,
    private snackBarSvc: SnackbarService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private cdr: ChangeDetectorRef,
    private projectSvc: ProjectService,
    private clipboard: Clipboard,
    private localStorage: LocalStorageService
  ) {
    Object.getOwnPropertyDescriptor(mapboxgl, "accessToken").set(
      environment.mapboxAccessToken
    );
  }

  async ngOnInit() {
    this.currentUser = this.userService.getCurrentUser();
    this.tourId = this.data.tourId;
    this.projectId = this.data.projectId;
    this.tour = this.data.tour;
    this.allTours = this.data.allTours;
    this.setViewPortSize();
    this.allLayers = [];
    this.mapUrls = [...this.tour.mapUrls];
    this.getBlobAccessToken();

    await this.getTourData(this.projectId, this.tourId);
    this.getLayerData(this.projectId);

    // do not delete below tourId and objectCount declaration, used for eval statement
    const tourId = this.tourId;
    const objectCount = this.tour.objectCount || 1;
    this.pointcloudUrl = this.tour.threeDUrl
      ? this.tour.threeDUrl
      : this.tour.isPointCloudAvailable
      ? eval("`" + this.config.pointcloudUrl + "`")
      : null;
    if (this.tour.lat && this.tour.lng) {
      this.lat = this.tour.lat;
      this.lng = this.tour.lng;
      this.initiate_map();
    } else {
      this.getProjectDetails();
    }

    if (this.tour.legend && this.tour.legend.blobContentId) {
      this.getLegendUrl(this.tour.legend.blobContentId);
      this.isLegendExist = true;
    }

    if (this.projectId) {
      if (!this.w_lat || !this.w_lng || !this.location) {
        this.getProjectLocation();
      }
    }

    //check if user has access to self serve
    this.hasSelfServeAccess();
  }

  @HostListener("window:resize", ["$event"])
  onResize(event) {
    this.setViewPortSize();
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  ngOnChanges(): void {
    if (this.projectId) {
      if (!this.lat || !this.lng || !this.location) {
        this.getProjectLocation();
      }
    }
  }

  async onTourChange(e: any) {
    this.closeDialogs();
    this.currentMarkers = [];
    this.annotationLayers = [];
    this.elevationList = [];
    this.remarks = [];
    this.remarksMarkers = [];
    this.createdMarker = [];
    this.punchItemMarkers = [];
    this.punchMarkers = [];
    this.punchItemMarkersList = [];
    this.polygonRemarksCoordinates = [];
    this.polygonRemarksLatitudeArray = [];
    this.polygonRemarksLongitudeArray = [];
    this.polygonPunchListLongitudeArray = [];
    this.polygonPunchListLatitudeArray = [];
    this.polygonPunchListCoordinates = [];
    this.timeoutIds = [];
    this.flyData = [];
    this.droneFlyCoordinates = [];
    this.flightPathCoordinates = [];
    this.droneVideoData = [];
    this.droneCoordinates = [];
    this.droneFlightData = [];
    this.volumeList = [];
    this.currMapLayers = [];
    this.layerDrawer.close();
    this.currSelectedAnnotationId = null;
    this.prevDsmLayerVisibility = null;
    this.prevDtmLayerVisibility = null;
    this.errors = null;
    this.dsmTileId = null;
    this.dtmTileId = null;
    this.markerImage = null;

    if (this.volumeApiInterval) {
      clearInterval(this.volumeApiInterval);
    }

    this.availableLayers = null;
    this._container = null;
    this.toggleAllMapLayers = true;
    this.toggleAnnotationLayers = true;
    this.toggleAnnotationColorLayers = true;
    this.toggleAnnotationColorLayers = null;
    this.downloadProgress = 0;
    this.annotationSearchTerm = "";
    this.prevAnnotationSearchTerm = "";
    this.showAll = false;
    this.remarksDescription = "";
    this.editedRemarksDescription = "";
    this.cursorChange = false;
    this.markerLat = null;
    this.markerLng = null;
    this.snapshot = null;
    this.punchCursorChange = false;
    this.punchItemMarkerLat = null;
    this.punchItemMarkerLng = null;
    this.punchItemMarkerDescription = null;
    this.isRemarksDrawMode = false;
    this.isPunchItemDrawMode = false;
    this.remarkResult = null;
    this.deleteElevationProfileDialogResult = null;
    this.deleteVolumeCalculationDialogResult = null;
    this.drawElevationLineMode = false;
    this.drawVolumePolygonMode = false;
    this.selectedRemarkToEdit = null;
    this.volumeEscapeButtonClick = null;
    this.elevationEscapeButtonClick = null;
    this.drawRemarkPolygonMode = false;
    this.polygonRemarkId = null;
    this.polygonRemarkType = null;
    this.averagePolygonRemarkLat = null;
    this.polygonRemarkLatSum = null;
    this.polygonRemarkLngSum = null;
    this.averageploygonRemarkLng = null;
    this.polygonRemarkLatitude = null;
    this.polygonRemarkLongitude = null;
    this.createNewPunchItemPolygonMode = false;
    this.polygonPunchListLatSum = null;
    this.polygonPunchListLngSum = null;
    this.averagePunchListRemarkLat = null;
    this.averagePunchListRemarkLng = null;
    this.polygonPunchListId = null;
    this.polygonPunchListType = null;
    this.polygonPunchListLatitude = null;
    this.polygonPunchListLongitude = null;
    this.markerType = null;
    this.punchItemMarkerType = null;
    this.punchItemMarkerId = null;
    this.drawAnnotationPolygon = false;
    this.punchItemPolygonMarkerIdToDelete = null;
    this.shareLink = null;
    this.videoUpload = false;
    this.currentVideoTimeMS = null;
    this.playTheVideo = null;
    this.tourLng = null;
    this.tourLat = null;
    this.isDroneFlightDataAvailable = false;
    this.flightEnded = false;
    this.flightMarker = null;
    this.flightButtons = null;
    this.showFlightButtons = false;
    this.markerIndex = null;
    this.playFlightMarkerFlag = true;
    this.pauseFlightMarkerFlag = false;
    this.resetFlightMarkerFlag = false;
    this.droneLogDataAvailable = false;
    this.contourLayerColor = null;
    this.boundaryLayerColor = null;
    this.isOpen = false;
    this.isLegendOpen = false;
    this.showProjectProgress && this.projectProgressBar.toggle();
    this.showProjectProgress = false;
    this.showSelfServe && this.selfServe.toggle();
    this.showSelfServe = false;
    this.showProgressBar && this.sideNave.toggle();
    this.showProgressBar = false;
    this.showVolumeCalculationPolygon && this.openVolumePanel();
    // this.showVolumeTool = false;
    this.showElevationLine && this.openElevationProfilePanel();
    // this.showElevationTool = false;
    this.isRemark && this.openRemarkList();
    this.createAerialPunchListItem && this.punchItemListPanel();
    this.droneFlightPath && this.createDroneFlightPath();
    this.droneFlightMode && this.droneFlight();
    this.showPunchListPanel = false;
    this.showPunchPanel = false;
    this.showCreateRemarks = false;
    this.showEditRemarks = false;
    this.tourType = "2D";

    this.tourId = e.value;
    this.tour = this.allTours.find((tour) => tour.tourId == this.tourId);
    // this.setViewPortSize();
    this.allLayers = [];
    this.mapUrls = [...this.tour.mapUrls];
    this.map?.remove();
    await this.getTourData(this.projectId, this.tourId);

    // do not delete below tourId and objectCount declaration, used for eval statement
    const tourId = this.tourId;
    const objectCount = this.tour.objectCount || 1;

    this.pointcloudUrl = this.tour.threeDUrl
      ? this.tour.threeDUrl
      : this.tour.isPointCloudAvailable
      ? eval("`" + this.config.pointcloudUrl + "`")
      : null;

    if (this.tour.lat && this.tour.lng) {
      this.lat = this.tour.lat;
      this.lng = this.tour.lng;
      this.initiate_map();
    } else {
      this.getProjectDetails();
    }

    if (this.tour.legend && this.tour.legend.blobContentId) {
      this.getLegendUrl(this.tour.legend.blobContentId);
      this.isLegendExist = true;
    }
  }

  closeDialogs() {
    this.confirmAlertComponentDialogRef?.close();
    this.annotationComponentDialogRef?.close();
    this.confirmDialogComponentDialogRef?.close();
    this.surfaceVolumeComponentDialogRef?.close();
    this.surfaceElevationComponentDialogRef?.close();
  }

  getProjectLocation() {
    this.projectService.get(this.projectId).subscribe(
      (data) => {
        this.w_lat = data.lat;
        this.w_lng = data.lng;
        this.location = data.location;
      },
      (error) => {
        this.errors = error;
      }
    );
  }
  // get tour data based on tourID

  getTourData(projectId, tourId) {
    return new Promise<void>((resolve, reject) => {
      this.aerialTourService.getAerialTourById(projectId, tourId).subscribe(
        (data) => {
          this.showAll = true;
          this.remarks = data.tour.remarks;
          this.punchItemMarkersList = data.tour.punchItemMarkers;
          this.tourLng = data.tour.lng;
          this.tourLat = data.tour.lat;

          this.droneFlightLogCheck(data);
          this.droneVideoCheck(data);
          this.droneDataCheck();
          this.contourColor(data);
          resolve();
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  contourColor(data) {
    data.tour.mapUrls.forEach((mapUrl) => {
      if (mapUrl.filename === "contour.zip" || mapUrl.key === "CONTOUR") {
        if (mapUrl.shapefileColor) {
          this.contourLayerColor = mapUrl.shapefileColor;
        } else {
          this.contourLayerColor = "#000000";
        }
      } else if (
        mapUrl.filename === "boundary.zip" ||
        mapUrl.key === "BOUNDARY"
      ) {
        if (mapUrl.shapefileColor) {
          this.boundaryLayerColor = mapUrl.shapefileColor;
        } else {
          this.boundaryLayerColor = "#ff0000";
        }
      }
    });
  }

  droneFlightLogCheck(data) {
    if (data?.tour?.droneFlightData?.length !== 0) {
      this.droneFlightData = data.tour.droneFlightData;
    }
  }

  droneVideoCheck(data) {
    if (data?.tour?.droneFlightVideoData?.length !== 0) {
      this.droneVideoData = data.tour.droneFlightVideoData;
    }
  }

  droneDataCheck() {
    if (this.droneFlightData.length !== 0 && this.droneVideoData.length !== 0) {
      this.isDroneFlightDataAvailable = !this.isDroneFlightDataAvailable;
      this.droneLogDataAvailable = !this.droneLogDataAvailable;
    } else if (this.droneFlightData.length !== 0) {
      this.droneLogDataAvailable = !this.droneLogDataAvailable;
    }
  }

  droneFlightPathLayer(flightCoordinates) {
    if (flightCoordinates && flightCoordinates.length !== 0) {
      this.map.addSource("drone_Flight_Path" + "_source", {
        type: "geojson",
        data: {
          type: "FeatureCollection",
          features: [
            {
              type: "Feature",
              geometry: {
                type: "LineString",
                coordinates: flightCoordinates,
              },
              properties: {
                polygon_label: "line.label",
              },
            },
          ],
        },
      });
      this.map.addLayer({
        id: "drone_Flight_Path",
        type: "line",
        source: "drone_Flight_Path" + "_source",
        layout: {
          "line-join": "round",
          "line-cap": "round",
          visibility: "visible",
        },
        paint: {
          "line-color": "#5A5A5A",
          "line-width": 10,
          "line-gap-width": 4,
        },
      });
    }
  }

  flightDataSetUp(flightLogData) {
    if (flightLogData) {
      flightLogData.forEach((obj: any) => {
        const latLng = [];
        latLng[0] = obj.longitude;
        latLng[1] = obj.latitude;

        this.flightPathCoordinates.push(latLng);
      });
    }
  }

  setFlightMarker(data) {
    const el = document.createElement("div");
    el.className = "mapbox-gl-custom-torch";

    this.flightMarker = new mapboxgl.Marker(el)
      .setLngLat({
        lat: data[0]["latitude"],
        lng: data[0]["longitude"],
      })
      .addTo(this.map);
  }

  // Video playing controls

  pauseVideo(event: any) {
    this.playTheVideo = false;
  }

  playVideo(event: any) {
    this.playTheVideo = true;
  }

  videoEnded(event: any) {
    this.playTheVideo = false;
    this.map.setBearing(0);
  }

  videoTimeUpdate(e: any) {
    let previousElement;

    if (this.playTheVideo) {
      this.currentVideoTimeMS = e.target["currentTime"] * 1000;

      let totalLatLngValues =
        this.droneCoordinates[0].el.droneFlightData.length;
      let finalLatLngValues =
        this.droneCoordinates[0].el.droneFlightData.length - 1;

      for (let i = 0; i < totalLatLngValues; i++) {
        const { time, longitude, latitude, heading, pitch, roll } =
          this.droneCoordinates[0].el.droneFlightData[i];

        if (this.currentVideoTimeMS >= time) {
          if (previousElement !== i) {
            this.flightMarker
              .setLngLat([longitude, latitude])
              .getElement().style.transform = `rotate(${roll}deg)`;

            previousElement = i;

            this.map.flyTo({
              essential: true,
              speed: 106,
              bearing: heading,
              pitch: pitch,
            });

            if (i === finalLatLngValues) {
              this.flightEnded = true;
              this.map.setBearing(0);
              this.stopVideo();
            }
          }
        }
      }
    }
  }

  openVideo() {
    this.videoUpload = !this.videoUpload;
  }

  closeVideo() {
    this.createDroneFlightPath();
  }

  stopVideo() {
    this.videoComponent.droneVideo.nativeElement.currentTime = 0;
    this.videoComponent.droneVideo.nativeElement.pause();

    let alert;
    alert = this.ts.instant("exterior.mapbox.messages.reviewFlightLogData");
    this.snackService.warningSnackBar(alert);
  }

  // drone flight log data trimming
  createDroneFlightPath() {
    this.droneFlightPath = !this.droneFlightPath;
    this.videoUpload = !this.videoUpload;
    this.droneLogDataAvailable = !this.droneLogDataAvailable;

    if (!this.droneFlightPath) {
      this.activateElevationClick();
      this.map
        .removeLayer("drone_Flight_Path")
        .removeSource("drone_Flight_Path" + "_source");

      this.flightMarker.remove();
      this.map.setBearing(0);
      this.map.setZoom(this.defaultZoom);
      this.map.setCenter([this.tourLng, this.tourLat]);

      this.map.flyTo({
        center: [this.tourLng, this.tourLat],
        zoom: this.defaultZoom,
        essential: true,
        bearing: 0,
      });
    }

    if (this.droneFlightPath) {
      const data = this.droneFlightData[0].droneFlightData;
      this.deactivateElevationClick();

      this.setFlightMarker(data);
      this.flightDataSetUp(data);
      this.droneFlightPathLayer(this.flightPathCoordinates);
    }

    this.flightPathCoordinates = [];
    this.droneFlightData.forEach((el) => {
      this.droneCoordinates.push({ el });
    });
  }

  droneFlight() {
    this.droneFlightMode = !this.droneFlightMode;
    this.isDroneFlightDataAvailable = !this.isDroneFlightDataAvailable;

    if (!this.droneFlightMode) {
      this.flightButtons = false;
      this.showFlightButtons = false;
      this.resetFlight();
      this.activateElevationClick();

      this.map
        .removeLayer("drone_Flight_Path")
        .removeSource("drone_Flight_Path" + "_source");

      this.flightMarker.remove();
      this.map.setBearing(0);
      this.map.setZoom(this.defaultZoom);
      this.map.setCenter([this.tourLng, this.tourLat]);
      this.map.off("click", this.flyDataOnClick);

      this.map.flyTo({
        center: [this.tourLng, this.tourLat],
        zoom: this.defaultZoom,
        essential: true,
        bearing: 0,
      });
    }

    if (this.droneFlightMode) {
      this.flightButtons = true;
      this.showFlightButtons = true;
      this.deactivateElevationClick();

      const data = this.droneFlightData[0].droneFlightData;
      this.setFlightMarker(data);
      this.flightDataSetUp(data);
      this.droneFlightPathLayer(this.flightPathCoordinates);
    }

    this.flightPathCoordinates = [];

    this.droneFlightData.forEach((el) => {
      this.droneFlyCoordinates.push({ el });
    });

    this.flyData = this.droneFlyCoordinates[0].el.droneFlightData;

    if (this.flyData) {
      this.map.on("click", this.flyDataOnClick);
    }
  }

  flyDataOnClick = (e) => {
    const clickedCoordinates = [e.lngLat.lng, e.lngLat.lat];
    let lngMax = -Infinity;
    let lngMin = Infinity;
    let latMax = -Infinity;
    let latMin = Infinity;

    for (let i = 0; i < this.flyData.length; i++) {
      const coordinate = this.flyData[i];

      lngMax = Math.max(lngMax, coordinate.longitude);
      lngMin = Math.min(lngMin, coordinate.longitude);
      latMax = Math.max(latMax, coordinate.latitude);
      latMin = Math.min(latMin, coordinate.latitude);
    }
    const rangeArray = [
      [lngMin, latMin],
      [lngMax, latMax],
    ];

    const isWithinRange = this.isWithinBoundary(clickedCoordinates, rangeArray);

    if (isWithinRange) {
      const newObj = this.findClosestCoordinate(
        clickedCoordinates,
        this.flyData
      );

      new mapboxgl.Popup({
        offset: 15,
        closeButton: true,
      })
        .setLngLat([e.lngLat.lng, e.lngLat.lat])
        .setHTML(
          `
              <div>
                Tentative Marker Instance : ${newObj.closestIndex}<br>
                longitude : ${newObj.closestCoordinate.longitude}<br>
                latitude : ${newObj.closestCoordinate.latitude}
              </div>
                `
        )
        .addTo(this.map);
    }
  };

  findClosestCoordinate(referenceCoordinate, coordinates) {
    let closestCoordinate = null;
    let closestIndex = -1;
    let closestDiff = Infinity;

    for (let i = 0; i < coordinates.length; i++) {
      let coordinate = coordinates[i];
      let lngDiff = Math.abs(referenceCoordinate[0] - coordinate.longitude);
      let latDiff = Math.abs(referenceCoordinate[1] - coordinate.latitude);
      let diffSum = lngDiff + latDiff;

      if (diffSum < closestDiff) {
        closestCoordinate = coordinate;
        closestDiff = diffSum;
        closestIndex = i;
      }
    }
    return { closestCoordinate, closestIndex };
  }

  isWithinBoundary(point, range) {
    let lng = point[0];
    let lat = point[1];

    let lngMin = Math.min(range[0][0], range[1][0]);
    let lngMax = Math.max(range[0][0], range[1][0]);
    let latMin = Math.min(range[0][1], range[1][1]);
    let latMax = Math.max(range[0][1], range[1][1]);

    return lng >= lngMin && lng <= lngMax && lat >= latMin && lat <= latMax;
  }

  playFlight() {
    this.playFlightMarkerFlag = false;
    this.pauseFlightMarkerFlag = true;
    this.resetFlightMarkerFlag = true;

    if (!this.playFlightMarkerFlag) {
      this.markerIndex = this.markerIndex || 0;
      this.timeoutIds;
      const time = this.flyData[1].time;

      for (let i = this.markerIndex; i < this.flyData.length - 1; i++) {
        const { longitude, latitude, heading, pitch, roll } = this.flyData[i];

        const currentTimeoutId = setTimeout(() => {
          this.markerIndex = i;

          const flightPopup = new mapboxgl.Popup({
            offset: 15,
            closeButton: true,
          }).setHTML(
            `<div>Marker Instance : ${i} <br> Latitude : ${latitude}<br>Longitude : ${longitude}</div>`
          );

          this.flightMarker
            .setLngLat([longitude, latitude])
            .setPopup(flightPopup)
            .getElement().style.transform = `rotate(${roll}deg)`;

          this.map.flyTo({
            center: [longitude, latitude],
            essential: true,
            speed: 100,
            bearing: heading,
            pitch: pitch,
          });
        }, (i - this.markerIndex) * time);

        this.timeoutIds.push(currentTimeoutId);
      }
    }
  }

  pauseFlight() {
    this.playFlightMarkerFlag = true;
    this.pauseFlightMarkerFlag = false;
    this.resetFlightMarkerFlag = true;
    this.timeoutIds.forEach((timeoutId) => clearTimeout(timeoutId));
  }

  resetFlight() {
    this.playFlightMarkerFlag = true;
    this.pauseFlightMarkerFlag = false;
    this.resetFlightMarkerFlag = false;
    this.timeoutIds.forEach((timeoutId) => clearTimeout(timeoutId));
    this.markerIndex = 0;
    this.flightMarker.remove();

    const data = this.droneFlightData[0].droneFlightData;
    this.setFlightMarker(data);
  }

  //punch-list integration

  createNewPunchItemPolygon() {
    this.createNewPunchItemPolygonMode = !this.createNewPunchItemPolygonMode;
    this.mapSnapshot();
    this.showPunchListPanel = false;
    this.draw.changeMode("draw_polygon");
    this.map.getCanvas().style.cursor = "crosshair";
  }

  punchItemPolygonData(e) {
    this.showPunchPanel = true;

    //Create an array of latitudes of polygon
    for (let item of e.features[0].geometry.coordinates[0]) {
      this.polygonPunchListLongitudeArray.push(item[0]);

      this.polygonPunchListLatitudeArray.push(item[1]);

      this.polygonPunchListLatSum = 0;
      this.polygonPunchListLngSum = 0;

      for (let lat of this.polygonPunchListLatitudeArray) {
        this.polygonPunchListLatSum = this.polygonPunchListLatSum + lat;
      }

      for (let lng of this.polygonPunchListLongitudeArray) {
        this.polygonPunchListLngSum = this.polygonPunchListLngSum + lng;
      }
    }
    this.averagePunchListRemarkLat =
      this.polygonPunchListLatSum / this.polygonPunchListLatitudeArray.length;

    this.polygonPunchListLatitudeArray = [];

    this.averagePunchListRemarkLng =
      this.polygonPunchListLngSum / this.polygonPunchListLongitudeArray.length;

    this.polygonPunchListLongitudeArray = [];

    const polygonPunchListId = e.features[0].id;
    this.polygonPunchListId = polygonPunchListId;

    const polygonPunchListCoordinates = e.features[0].geometry.coordinates;
    this.polygonPunchListCoordinates = polygonPunchListCoordinates;

    const PunchListType = "polygon_punchItem";
    this.polygonPunchListType = PunchListType;

    this.polygonPunchListLatitude = this.averagePunchListRemarkLat;

    this.polygonPunchListLongitude = this.averagePunchListRemarkLng;
    this.punchItemMarkerLat = this.polygonPunchListLatitude;
    this.punchItemMarkerLng = this.polygonPunchListLongitude;
    this.markerType = this.polygonPunchListType;
  }

  setPunchItemPolygonMarker(punchListMarkerId) {
    const lat = this.polygonPunchListLatitude;
    const lng = this.polygonPunchListLongitude;

    const el = document.createElement("div");
    el.className = "mapbox-gl-custom-snag";

    const punchItemPopup = new mapboxgl.Popup({
      offset: 20,
      closeButton: false,
    }).setHTML(`<div>${this.punchItemMarkerDescription}</div> `);

    const punchItemMarker = new mapboxgl.Marker(el).setLngLat({
      lat: lat,
      lng: lng,
    });

    const punchItemMarkerEl = punchItemMarker.getElement();
    punchItemMarkerEl.id = "punchItemMarker";

    punchItemMarkerEl.addEventListener("mouseenter", () =>
      punchItemPopup.addTo(this.map)
    );
    punchItemMarkerEl.addEventListener("mouseleave", () =>
      punchItemPopup.remove()
    );

    punchItemMarker.setPopup(punchItemPopup).addTo(this.map);

    const punchItemMarkerId = punchListMarkerId ? punchListMarkerId : uuidv4();

    // adding punch item polygon layer

    const punchItemPolygonMarkerId = this.polygonPunchListId;

    const source = punchItemPolygonMarkerId + "_source";
    this.map.addSource(source, {
      type: "geojson",
      data: {
        type: "FeatureCollection",
        features: [
          {
            type: "Feature",
            geometry: {
              type: "Polygon",
              coordinates: this.polygonPunchListCoordinates,
            },
            properties: {},
          },
        ],
      },
    });
    //layer to visualize the polygon
    this.map.addLayer({
      id: punchItemPolygonMarkerId,
      type: "fill",
      source: source,
      layout: {
        visibility: "visible",
      },
      paint: {
        "fill-color": "#627BC1",
        "fill-opacity": [
          "case",
          ["boolean", ["feature-state", "hover"], false],
          1,
          0.5,
        ],
      },
    });
    //adding border
    this.map.addLayer({
      id: punchItemPolygonMarkerId + "_line",
      type: "line",
      source: source,
      layout: {
        visibility: "visible",
      },
      paint: {
        "line-color": "#FF0000",
        "line-width": 1,
      },
    });

    this.punchMarkers.push({
      punchItemMarker,
      punchItemMarkerId: punchItemMarkerId,
      punchItemPolygonMarkerId,
      type: "polygon_punchItem",
    });

    const punchItemPolygonMarkerDetails = {
      id: punchItemMarkerId,
      punchItemPolygonMarkerId: punchItemPolygonMarkerId,
      latitude: lat,
      longitude: lng,
      type: "polygon_punchItem",
      punchListPolygonCoordinates: this.polygonPunchListCoordinates,
      punchItemMarkerTaskDescription: this.punchItemMarkerDescription,
    };

    this.savePunchItemPolygonMarker(punchItemPolygonMarkerDetails);
    this.map.getCanvas().style.cursor = "grab";
    this.createNewPunchItemPolygonMode = false;
  }

  savePunchItemPolygonMarker(punchItemPolygonMarkerDetails) {
    let alert;

    try {
      this.uiService.show();

      const tourId = this.tourId;
      this.aerialTourService
        .saveAerialTourPolygonPunchItemMarker(
          this.projectId,
          tourId,
          punchItemPolygonMarkerDetails
        )
        .pipe(
          take(1),
          tap((data) => {
            this.showPunchPanel = false;
            this.showPunchListPanel = true;
            this.punchItemMarkersList = data.tour.punchItemMarkers;
          }),
          catchError(() => {
            return empty();
          })
        )
        .subscribe(() => {
          this.uiService.hide();
        });
      alert = this.ts.instant(
        "exterior.list.messages.punchItemSavedSuccessfully"
      );
      this.draw.deleteAll();
      this.snackService.successSnackBar(alert);
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
      alert = this.ts.instant("exterior.list.messages.punchItemSaveFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  closePunchPanel() {
    this.showPunchPanel = false;
    this.showPunchListPanel = true;
  }

  closePunchListPanel() {
    this.showPunchListPanel = false;
  }

  createNewPunchItem() {
    this.mapSnapshot();

    this.isPunchItemDrawMode = true;
    this.punchCursorChange = !this.punchCursorChange;
    if (this.punchCursorChange) {
      this.map.getCanvas().style.cursor = "crosshair";
    } else {
      this.map.getCanvas().style.cursor = "grab";
    }

    this.punchCursorChange = !this.punchCursorChange;
    this.map.on("click", this.addPunchItemMarker);

    if (this.createAerialPunchListItem) {
      this.deactivateElevationClick();
    } else {
      this.activateElevationClick();
    }

    this.showPunchListPanel = false;
  }

  mapSnapshot() {
    const mapcanvas = this.map.getCanvas();
    const img = mapcanvas.toDataURL();
    const filename = this.tour.tourName;

    this.snapshot = this.dataURLtoFile(img, filename);
  }

  dataURLtoFile(dataurl, filename) {
    const arr = dataurl.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  punchItemListPanel() {
    this.createAerialPunchListItem = !this.createAerialPunchListItem;
    if (this.createAerialPunchListItem) {
      this.addPunchItemMarkerOnInitialization();
    } else {
      for (let punchMarker of this.punchMarkers) {
        this.punchMarkers.forEach((punchItemMarker) =>
          punchItemMarker.punchItemMarker.remove()
        );
        if (punchMarker.type === "polygon_punchItem") {
          this.map
            .removeLayer(punchMarker.punchItemPolygonMarkerId)
            .removeLayer(punchMarker.punchItemPolygonMarkerId + "_line")
            .removeSource(punchMarker.punchItemPolygonMarkerId + "_source");
        }
      }
      this.punchMarkers = [];
    }

    //Hide elevation profile pop up
    if (this.createAerialPunchListItem) {
      this.deactivateElevationClick();
    } else {
      this.activateElevationClick();
    }
    this.showPunchListPanel = !this.showPunchListPanel;
    this.showPunchPanel = false;
  }

  addPunchItemMarkerOnInitialization() {
    for (let punchMarker of this.punchItemMarkersList) {
      if (punchMarker.type === "polygon_punchItem") {
        const lat = punchMarker.latitude;
        const lng = punchMarker.longitude;

        const el = document.createElement("div");
        el.className = "mapbox-gl-custom-snag";

        const popup = new mapboxgl.Popup({
          offset: 20,
          closeButton: false,
        }).setHTML(`<div>${punchMarker.punchItemMarkerTaskDescription}</div> `);

        const punchItemMarker = new mapboxgl.Marker(el).setLngLat({
          lat: lat,
          lng: lng,
        });

        const markerEl = punchItemMarker.getElement();
        markerEl.id = "marker";

        markerEl.addEventListener("mouseenter", () => popup.addTo(this.map));
        markerEl.addEventListener("mouseleave", () => popup.remove());

        punchItemMarker.setPopup(popup).addTo(this.map);

        // adding polygon for punch Item

        const polygonPunchItemMarkerId = punchMarker.punchItemPolygonMarkerId;
        const source = polygonPunchItemMarkerId + "_source";
        this.map.addSource(source, {
          type: "geojson",
          data: {
            type: "FeatureCollection",
            features: [
              {
                type: "Feature",
                geometry: {
                  type: "Polygon",
                  coordinates: punchMarker.punchItemPolygonCoordinates,
                },
                properties: {},
              },
            ],
          },
        });

        //layer to visualize the polygon
        this.map.addLayer({
          id: polygonPunchItemMarkerId,
          type: "fill",
          source: source,
          layout: {
            visibility: "visible",
          },
          paint: {
            "fill-color": "#627BC1",
            "fill-opacity": [
              "case",
              ["boolean", ["feature-state", "hover"], false],
              1,
              0.5,
            ],
          },
        });
        //adding border
        this.map.addLayer({
          id: polygonPunchItemMarkerId + "_line",
          type: "line",
          source: source,
          layout: {
            visibility: "visible",
          },
          paint: {
            "line-color": "#FF0000",
            "line-width": 1,
          },
        });

        this.punchMarkers.push({
          punchItemMarker,
          punchItemMarkerId: punchMarker.punchItemMarkerId,
          punchItemPolygonMarkerId: polygonPunchItemMarkerId,
          type: "polygon_punchItem",
        });
      } else {
        const latitude = punchMarker.latitude;
        const longitude = punchMarker.longitude;

        const el = document.createElement("div");
        el.className = "mapbox-gl-custom-snag";

        const punchItemPopup = new mapboxgl.Popup({
          offset: 20,
          closeButton: false,
        }).setHTML(`<div>${punchMarker.punchItemMarkerTaskDescription}</div> `);

        const punchItemMarker = new mapboxgl.Marker(el).setLngLat({
          lat: latitude,
          lng: longitude,
        });

        const punchItemMarkerEl = punchItemMarker.getElement();
        punchItemMarkerEl.id = "punchItemMarker";

        punchItemMarkerEl.addEventListener("mouseenter", () =>
          punchItemPopup.addTo(this.map)
        );
        punchItemMarkerEl.addEventListener("mouseleave", () =>
          punchItemPopup.remove()
        );

        punchItemMarker.setPopup(punchItemPopup).addTo(this.map);

        this.punchMarkers.push({
          punchItemMarker,
          punchItemMarkerId: punchMarker.punchItemMarkerId,
          type: "point_punchItem",
        });
      }
    }
  }

  cancelCreatedPunchItemMarker() {
    this.showPunchListPanel = !this.showPunchListPanel;
    this.punchItemMarkers.map((punchListMarker) => {
      punchListMarker.punchItemMarker.remove();
    });
    this.punchItemMarkers = [];
    this.map.getCanvas().style.cursor = "grab";
    this.showPunchPanel = false;
    this.isPunchItemDrawMode = false;
    this.createNewPunchItemPolygonMode = false;
    this.draw.deleteAll();
  }

  closePunchItemMarkerOnClick() {
    this.map.off("click", this.addPunchItemMarker);
    this.punchItemMarkers.pop();
    this.createAerialPunchListItem = !this.createAerialPunchListItem;
  }

  addPunchItemMarker = (ev) => {
    const el = document.createElement("div");
    el.className = "mapbox-gl-custom-snag";

    const punchItemMarker = new mapboxgl.Marker(el)
      .setLngLat({ lat: ev.lngLat.lat, lng: ev.lngLat.lng })
      .addTo(this.map);

    this.punchItemMarkers.push({ punchItemMarker });

    if (this.punchItemMarkers.length >= 1) {
      this.map.off("click", this.addPunchItemMarker);
    }

    this.showPunchPanel = true;
    this.punchItemMarkerLat = ev.lngLat.lat;
    this.punchItemMarkerLng = ev.lngLat.lng;
    this.markerType = "point_punchItem";
  };

  obtainTaskDescriptionValue(taskDescription) {
    this.punchItemMarkerDescription = taskDescription;
  }

  obtainPunchItemMarkerType(punchItemMarkerType) {
    this.punchItemMarkerType = punchItemMarkerType;
  }

  setPunchItemMarker(punchListMarkerId?: string) {
    if (this.createNewPunchItemPolygonMode) {
      this.setPunchItemPolygonMarker(punchListMarkerId);
      this.createNewPunchItemPolygonMode = false;
    } else {
      //remove existing punchItem markers
      this.punchItemMarkers.map((punchItemMarker) => {
        punchItemMarker.punchItemMarker.remove();
      });
      this.punchItemMarkers = [];

      const lat = this.punchItemMarkerLat;
      const lng = this.punchItemMarkerLng;

      const el = document.createElement("div");
      el.className = "mapbox-gl-custom-snag";

      const punchItemPopup = new mapboxgl.Popup({
        offset: 20,
        closeButton: false,
      }).setHTML(`<div>${this.punchItemMarkerDescription}</div> `);

      const punchItemMarker = new mapboxgl.Marker(el).setLngLat({
        lat: lat,
        lng: lng,
      });

      const punchItemMarkerEl = punchItemMarker.getElement();
      punchItemMarkerEl.id = "punchItemMarker";

      punchItemMarkerEl.addEventListener("mouseenter", () =>
        punchItemPopup.addTo(this.map)
      );
      punchItemMarkerEl.addEventListener("mouseleave", () =>
        punchItemPopup.remove()
      );

      punchItemMarker.setPopup(punchItemPopup).addTo(this.map);

      const punchItemMarkerId = punchListMarkerId
        ? punchListMarkerId
        : uuidv4();

      this.punchMarkers.push({
        punchItemMarker,
        punchItemMarkerId,
        type: "point_punchItem",
      });

      const punchItemMarkerDetails = {
        id: punchItemMarkerId,
        latitude: lat,
        longitude: lng,
        type: "point_punchItem",
        punchItemMarkerTaskDescription: this.punchItemMarkerDescription,
      };

      this.updatePunchItemMarker(punchItemMarkerDetails);
      this.map.getCanvas().style.cursor = "grab";
      this.createAerialPunchListItem = false;
    }
  }

  //update punchList Marker

  updatePunchItemMarker(punchItemMarker) {
    let alert;

    try {
      this.uiService.show();

      const tourId = this.tourId;
      this.aerialTourService
        .updateAerialTourPunchItemMarker(
          this.projectId,
          tourId,
          punchItemMarker
        )
        .pipe(
          take(1),
          tap((data) => {
            this.showPunchPanel = false;
            this.showPunchListPanel = true;
            this.punchItemMarkersList = data.tour.punchItemMarkers;
          }),
          catchError(() => {
            return empty();
          })
        )
        .subscribe(() => {
          this.closePunchItemMarkerOnClick();
          this.uiService.hide();
        });
      alert = this.ts.instant(
        "exterior.list.messages.punchItemSavedSuccessfully"
      );
      this.snackService.successSnackBar(alert);
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
      alert = this.ts.instant("exterior.list.messages.punchItemSaveFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  //edit punchItem Marker Description

  editPunchItemMarker(editedPunchItemMarker) {
    let alert;

    try {
      this.uiService.show();

      this.aerialTourService
        .editAerialTourPunchItemMarker(
          this.projectId,
          this.tourId,
          editedPunchItemMarker
        )
        .pipe(
          take(1),
          tap((data) => {
            this.showPunchPanel = false;
            this.showPunchListPanel = true;
            this.punchItemMarkersList = data.tour.punchItemMarkers;
          }),
          catchError(() => {
            return empty();
          })
        )
        .subscribe(() => {
          this.closePunchItemMarkerOnClick();
          this.uiService.hide();
        });
      alert = this.ts.instant(
        "exterior.list.messages.punchItemSavedSuccessfully"
      );
      this.snackService.successSnackBar(alert);
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
      alert = this.ts.instant("exterior.list.messages.punchItemSaveFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  acceptPunchItemId(punchItemMarkerId) {
    this.removePunchListItem(punchItemMarkerId);
  }

  obtainPunchItemPolygonMarkerId(punchItemPolygonMarkerId) {
    this.punchItemPolygonMarkerIdToDelete = punchItemPolygonMarkerId;
  }

  removePunchListItem(punchItemMarkerId) {
    this.uiService.show();
    const tourId = this.tourId;
    this.aerialTourService
      .removeAerialTourPunchListItem(this.projectId, tourId, punchItemMarkerId)
      .subscribe((data) => {
        this.punchItemMarkersList = data.tour.punchItemMarkers;

        if (this.punchItemMarkerType === "point_punchItem") {
          const removedPunchItemMarker = this.punchMarkers.find(
            (savedPunchMarker) =>
              punchItemMarkerId === savedPunchMarker.punchItemMarkerId
          );
          removedPunchItemMarker.punchItemMarker.remove();
        } else if (this.punchItemMarkerType === "polygon_punchItem") {
          const removedPunchItemMarker = this.punchMarkers.find(
            (savedPunchMarker) =>
              punchItemMarkerId === savedPunchMarker.punchItemMarkerId
          );
          removedPunchItemMarker.punchItemMarker.remove();

          // remove polygon layer

          for (let punchMarker of this.punchMarkers) {
            if (
              punchMarker.type === "polygon_punchItem" &&
              punchMarker.punchItemPolygonMarkerId ===
                this.punchItemPolygonMarkerIdToDelete
            ) {
              this.map
                .removeLayer(punchMarker.punchItemPolygonMarkerId)
                .removeLayer(punchMarker.punchItemPolygonMarkerId + "_line")
                .removeSource(punchMarker.punchItemPolygonMarkerId + "_source");

              const remarkIndex = this.punchMarkers.findIndex(
                (savedRemark) =>
                  punchMarker.punchItemMarkerId ===
                  savedRemark.punchItemMarkerId
              );

              this.punchMarkers.splice(remarkIndex, 1);
              break;
            }
          }
        }

        this.uiService.hide();
      });
  }

  flyToPunchListMarker(punchItemData) {
    const latitude = punchItemData.punchItemMarkerLat;
    const longitude = punchItemData.punchItemMarkerLng;

    this.map.flyTo({
      center: [longitude, latitude],
      zoom: 40,
      essential: true,
    });
  }

  //remarks integration

  openRemarkList() {
    this.isRemark = !this.isRemark;
    if (this.isRemark) {
      this.addRemarkMarkerOnInitialization();
    } else {
      for (let remark of this.remarksMarkers) {
        this.remarksMarkers.forEach((marker) => marker.marker.remove());
        if (remark.type === "polygon_remark") {
          this.map
            .removeLayer(remark.id)
            .removeLayer(remark.id + "_line")
            .removeSource(remark.id + "_source");
        }
      }
      this.remarksMarkers = [];
    }

    //Hide elevation profile pop up
    if (this.isRemark) {
      this.deactivateElevationClick();
    } else {
      this.activateElevationClick();
    }
  }

  drawRemarkPolygon() {
    this.drawRemarkPolygonMode = !this.drawRemarkPolygonMode;
    this.isRemark = false;
    this.map.getCanvas().style.cursor = "crosshair";
    this.draw.changeMode("draw_polygon");
    this.deactivateElevationClick();
  }

  remarkPolygonData(e) {
    this.showCreateRemarks = true;

    //Create an array of latitudes of polygon
    for (let item of e.features[0].geometry.coordinates[0]) {
      this.polygonRemarksLongitudeArray.push(item[0]);

      this.polygonRemarksLatitudeArray.push(item[1]);

      this.polygonRemarkLatSum = 0;
      this.polygonRemarkLngSum = 0;

      for (let lat of this.polygonRemarksLatitudeArray) {
        this.polygonRemarkLatSum = this.polygonRemarkLatSum + lat;
      }

      for (let lng of this.polygonRemarksLongitudeArray) {
        this.polygonRemarkLngSum = this.polygonRemarkLngSum + lng;
      }
    }
    this.averagePolygonRemarkLat =
      this.polygonRemarkLatSum / this.polygonRemarksLatitudeArray.length;

    this.polygonRemarksLatitudeArray = [];

    this.averageploygonRemarkLng =
      this.polygonRemarkLngSum / this.polygonRemarksLongitudeArray.length;

    this.polygonRemarksLongitudeArray = [];

    const polygonRemarkId = e.features[0].id;
    this.polygonRemarkId = polygonRemarkId;

    const polygonRemarkCoordinates = e.features[0].geometry.coordinates;
    this.polygonRemarksCoordinates = polygonRemarkCoordinates;

    const remarkType = "polygon_remark";
    this.polygonRemarkType = remarkType;

    this.polygonRemarkLatitude = this.averagePolygonRemarkLat;

    this.polygonRemarkLongitude = this.averageploygonRemarkLng;
  }

  setRemarkPolygonMarker() {
    const lat = this.polygonRemarkLatitude;
    const lng = this.polygonRemarkLongitude;

    const el = document.createElement("div");
    el.className = "mapbox-gl-custom-marker";

    const popup = new mapboxgl.Popup({
      offset: 20,
      closeButton: false,
    }).setHTML(`<div>${this.remarksDescription}</div> `);

    const marker = new mapboxgl.Marker(el).setLngLat({
      lat: lat,
      lng: lng,
    });

    const markerEl = marker.getElement();
    markerEl.id = "marker";

    markerEl.addEventListener("mouseenter", () => popup.addTo(this.map));
    markerEl.addEventListener("mouseleave", () => popup.remove());

    marker.setPopup(popup).addTo(this.map);

    // adding polygon
    const polygonRemarkId = this.polygonRemarkId;
    const source = polygonRemarkId + "_source";
    this.map.addSource(source, {
      type: "geojson",
      data: {
        type: "FeatureCollection",
        features: [
          {
            type: "Feature",
            geometry: {
              type: "Polygon",
              coordinates: this.polygonRemarksCoordinates,
            },
            properties: {},
          },
        ],
      },
    });
    //layer to visualize the polygon
    this.map.addLayer({
      id: polygonRemarkId,
      type: "fill",
      source: source,
      layout: {
        visibility: "visible",
      },
      paint: {
        "fill-color": "#627BC1",
        "fill-opacity": [
          "case",
          ["boolean", ["feature-state", "hover"], false],
          1,
          0.5,
        ],
      },
    });
    //adding border
    this.map.addLayer({
      id: polygonRemarkId + "_line",
      type: "line",
      source: source,
      layout: {
        visibility: "visible",
      },
      paint: {
        "line-color": "#FF0000",
        "line-width": 1,
      },
    });

    this.remarksMarkers.push({
      marker,
      id: polygonRemarkId,
      type: "polygon_remark",
    });

    const remarkPolygon = {
      remarkId: this.polygonRemarkId,
      remarkCoordinates: this.polygonRemarksCoordinates,
      remarkLatitude: this.polygonRemarkLatitude,
      remarkLongitude: this.polygonRemarkLongitude,
      remarkType: this.polygonRemarkType,
      remarkDescriptionText: this.remarksDescription,
    };
    this.remarksDescription = "";
    this.remarksFormControl.reset();

    this.showCreateRemarks = false;
    this.isRemark = true;

    this.saveRemarkPolygonData(remarkPolygon);
  }

  saveRemarkPolygonData(remarkPolygon) {
    try {
      this.uiService.show();

      const tourId = this.tourId;
      this.aerialTourService
        .saveAerialTourPolygonRemarks(this.projectId, tourId, remarkPolygon)
        .pipe(
          take(1),
          tap((data) => {
            this.remarks = data.tour.remarks;
            this.isRemark = false;
            this.map.getCanvas().style.cursor = "grab";
            const alert = this.ts.instant(
              "exterior.list.messages.polygonRemarkAddedSuccessfully"
            );
            this.draw.deleteAll();
            this.snackService.successSnackBar(alert);
            this.uiService.hide();
          }),
          catchError(() => {
            return empty();
          })
        )
        .subscribe(() => {
          this.closeRemarkMarkerOnClick();
          this.uiService.hide();
        });
    } catch (error) {
      this.uiService.hide();
      const alert = this.ts.instant(
        "exterior.list.messages.polygonRemarkAddingError"
      );
      this.snackService.errorSnackBar(alert);
    }
  }

  addRemarkMarkerOnInitialization() {
    for (let remark of this.remarks) {
      if (remark.type === "polygon_remark") {
        const lat = remark.latitude;
        const lng = remark.longitude;

        const el = document.createElement("div");
        el.className = "mapbox-gl-custom-marker";

        const popup = new mapboxgl.Popup({
          offset: 20,
          closeButton: false,
        }).setHTML(`<div>${remark.text}</div> `);

        const marker = new mapboxgl.Marker(el).setLngLat({
          lat: lat,
          lng: lng,
        });

        const markerEl = marker.getElement();
        markerEl.id = "marker";

        markerEl.addEventListener("mouseenter", () => popup.addTo(this.map));
        markerEl.addEventListener("mouseleave", () => popup.remove());

        marker.setPopup(popup).addTo(this.map);

        // adding polygon
        const polygonRemarkId = remark.remarkId;
        const source = polygonRemarkId + "_source";
        this.map.addSource(source, {
          type: "geojson",
          data: {
            type: "FeatureCollection",
            features: [
              {
                type: "Feature",
                geometry: {
                  type: "Polygon",
                  coordinates: remark.polygonCoordinates,
                },
                properties: {},
              },
            ],
          },
        });

        //layer to visualize the polygon
        this.map.addLayer({
          id: polygonRemarkId,
          type: "fill",
          source: source,
          layout: {
            visibility: "visible",
          },
          paint: {
            "fill-color": "#627BC1",
            "fill-opacity": [
              "case",
              ["boolean", ["feature-state", "hover"], false],
              1,
              0.5,
            ],
          },
        });

        //adding border
        this.map.addLayer({
          id: polygonRemarkId + "_line",
          type: "line",
          source: source,
          layout: {
            visibility: "visible",
          },
          paint: {
            "line-color": "#FF0000",
            "line-width": 1,
          },
        });

        this.remarksMarkers.push({
          marker,
          id: remark.remarkId,
          type: "polygon_remark",
        });
      } else {
        const latitude = remark.latitude;
        const longitude = remark.longitude;
        const popupText = remark.text;

        const popup = new mapboxgl.Popup({
          offset: 20,
          closeButton: false,
        }).setHTML(popupText);

        const el = document.createElement("div");
        el.className = "mapbox-gl-custom-marker";

        const marker = new mapboxgl.Marker(el).setLngLat({
          lat: latitude,
          lng: longitude,
        });

        const markerEl = marker.getElement();
        markerEl.id = "marker";

        markerEl.addEventListener("mouseenter", () => popup.addTo(this.map));
        markerEl.addEventListener("mouseleave", () => popup.remove());

        marker.setPopup(popup).addTo(this.map);

        this.remarksMarkers.push({
          marker,
          id: remark.remarkId,
        });
      }
    }
  }

  remarkMarkerOnClick() {
    this.isRemark = false;
    this.showCreateRemarks = false;
    this.isRemarksDrawMode = true;
    this.cursorChange = !this.cursorChange;

    if (this.cursorChange) {
      this.map.getCanvas().style.cursor = "crosshair";
    } else {
      this.map.getCanvas().style.cursor = "grab";
    }

    this.cursorChange = !this.cursorChange;
    this.map.on("click", this.addRemarkMarker);
  }

  cancelCreatedRemarkMarker() {
    this.showCreateRemarks = !this.showCreateRemarks;
    this.isRemark = !this.isRemark;
    this.createdMarker.map((marker) => {
      marker.marker.remove();
    });
    this.remarksFormControl.reset();
    this.createdMarker = [];
    this.map.getCanvas().style.cursor = "grab";
    this.isRemarksDrawMode = false;
    this.draw.deleteAll();
    if (this.drawRemarkPolygonMode) {
      this.drawRemarkPolygonMode = false;
    }
  }

  closeRemarkMarkerOnClick() {
    if (!this.drawRemarkPolygonMode) {
      this.map.off("click", this.addRemarkMarker);
    }
    this.createdMarker.pop();
    this.isRemark = !this.isRemark;
  }

  addRemarkMarker = (ev) => {
    const el = document.createElement("div");
    el.className = "mapbox-gl-custom-marker";

    const marker = new mapboxgl.Marker(el)
      .setLngLat({ lat: ev.lngLat.lat, lng: ev.lngLat.lng })
      .addTo(this.map);

    this.createdMarker.push({ marker });

    if (this.createdMarker.length >= 1) {
      this.map.off("click", this.addRemarkMarker);
    }

    this.showCreateRemarks = true;
    this.markerLat = ev.lngLat.lat;
    this.markerLng = ev.lngLat.lng;
  };

  setRemarkMarker() {
    if (this.drawRemarkPolygonMode) {
      if (this.remarksFormControl.valid) {
        this.setRemarkPolygonMarker();
        this.drawRemarkPolygonMode = false;
      }
    } else {
      if (this.remarksFormControl.valid) {
        //remove the existing remark markers
        this.createdMarker.map((marker) => {
          marker.marker.remove();
        });
        this.createdMarker = [];

        const lat = this.markerLat;
        const lng = this.markerLng;

        const el = document.createElement("div");
        el.className = "mapbox-gl-custom-marker";

        const popup = new mapboxgl.Popup({
          offset: 20,
          closeButton: false,
        }).setHTML(`<div>${this.remarksDescription}</div> `);

        const marker = new mapboxgl.Marker(el).setLngLat({
          lat: lat,
          lng: lng,
        });

        const markerEl = marker.getElement();
        markerEl.id = "marker";

        markerEl.addEventListener("mouseenter", () => popup.addTo(this.map));
        markerEl.addEventListener("mouseleave", () => popup.remove());

        marker.setPopup(popup).addTo(this.map);

        const remarkId = uuidv4();

        this.remarksMarkers.push({
          marker,
          id: remarkId,
        });

        const remark = {
          id: remarkId,
          latitude: lat,
          longitude: lng,
          type: "point_remark",
          text: this.remarksDescription,
        };
        this.updateRemark(remark);
        this.map.getCanvas().style.cursor = "grab";
      }
    }
  }

  updateRemark(remark) {
    try {
      this.uiService.show();

      const tourId = this.tourId;
      this.aerialTourService
        .updateAerialTourRemarks(this.projectId, tourId, remark)
        .pipe(
          take(1),
          tap((data) => {
            this.showCreateRemarks = false;
            this.isRemarksDrawMode = false;
            this.remarks = data.tour.remarks;
            this.remarksDescription = "";
            this.remarksFormControl.reset();
            const alert = this.ts.instant(
              "exterior.list.messages.remarkAddedSuccessfully"
            );
            this.snackService.successSnackBar(alert);
            this.uiService.hide();
          }),
          catchError(() => {
            return empty();
          })
        )
        .subscribe(() => {
          this.closeRemarkMarkerOnClick();
          this.uiService.hide();
        });
    } catch (error) {
      this.uiService.hide();
      const alert = this.ts.instant("exterior.list.messages.remarkAddingError");
      this.snackService.errorSnackBar(alert);
    }
  }

  removeRemark(remark) {
    const tourId = this.tourId;
    const message = this.ts.instant("dialog.messages.removeRemark");
    const successBtn = this.ts.instant("dialog.deleteBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.confirmAction"),
      message,
      successBtn,
      icon
    );
    this.confirmAlertComponentDialogRef = this.dialog.open(
      ConfirmAlertComponent,
      {
        maxWidth: "400px",
        data: dialogData,
      }
    );

    this.confirmAlertComponentDialogRef
      .afterClosed()
      .subscribe((dialogResult) => {
        this.uiService.show();

        this.remarkResult = dialogResult;
        if (this.remarkResult) {
          this.aerialTourService
            .removeAerialTourRemark(this.projectId, tourId, remark)
            .subscribe(
              (data) => {
                this.remarks = data.tour.remarks;
                const removedMarker = this.remarksMarkers.find(
                  (savedRemark) => remark.remarkId === savedRemark.id
                );
                removedMarker.marker.remove();

                //remove polygon layer

                if (remark.type === "polygon_remark") {
                  this.map
                    .removeLayer(remark.remarkId)
                    .removeLayer(remark.remarkId + "_line")
                    .removeSource(remark.remarkId + "_source");

                  const remarkIndex = this.remarksMarkers.findIndex(
                    (savedRemark) => remark.remarkId === savedRemark.id
                  );

                  this.remarksMarkers.splice(remarkIndex, 1);
                }
                this.uiService.hide();
                const alert = this.ts.instant(
                  "exterior.list.messages.removedRemarkSuccessfully"
                );
                this.snackService.successSnackBar(alert);
              },
              (err) => {
                const alert = this.ts.instant(
                  "exterior.list.messages.failedToRemoveRemark"
                );
                this.snackService.errorSnackBar(alert);

                this.uiService.hide();
                this.errors = err;
              }
            );
        } else {
          this.uiService.hide();
        }
      });
  }

  flyToRemarkMarker(remark) {
    const latitude = remark.latitude;
    const longitude = remark.longitude;

    this.map.flyTo({
      center: [longitude, latitude],
      zoom: 40,
      essential: true,
    });
  }

  editRemark(remark) {
    this.showEditRemarks = true;
    this.isRemark = false;
    this.editedRemarksDescription = remark.text;
    this.selectedRemarkToEdit = remark;
  }

  editTheRemark() {
    const editedRemark = {
      id: this.selectedRemarkToEdit.remarkId,
      latitude: this.selectedRemarkToEdit.latitude,
      longitude: this.selectedRemarkToEdit.longitude,
      type: "point_remark",
      text: this.editedRemarksDescription,
    };

    this.updateAndEditRemark(editedRemark);
  }

  cancelEditRemark() {
    this.isRemark = true;
    this.showEditRemarks = false;
    this.editedRemarksDescription = "";
  }

  updateAndEditRemark(editedRemark) {
    try {
      this.uiService.show();

      const tourId = this.tourId;
      this.aerialTourService
        .editAerialTourRemarks(this.projectId, tourId, editedRemark)
        .pipe(
          take(1),
          tap((data) => {
            this.showCreateRemarks = false;
            this.showEditRemarks = false;
            this.remarks = data.tour.remarks;
            this.remarksDescription = "";
            this.remarksFormControl.reset();
            (this.editedRemarksDescription = ""),
              this.editRemarksFormControl.reset();
            this.uiService.hide();
            const alert = this.ts.instant(
              "exterior.list.messages.remarkEditedSuccessfully"
            );
            this.snackService.successSnackBar(alert);
          }),
          catchError(() => {
            return empty();
          })
        )
        .subscribe(() => {
          this.closeRemarkMarkerOnClick();
          this.uiService.hide();
        });
    } catch (error) {
      this.uiService.hide();
      const alert = this.ts.instant("exterior.list.messages.remarkEditFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  @HostListener("document:keydown.escape", ["$event"]) onKeydownHandler(
    event: KeyboardEvent
  ) {
    if (this.isRemarksDrawMode) {
      this.showCreateRemarks = false;
      this.isRemark = true;
      this.isRemarksDrawMode = false;
      this.createdMarker.map((marker) => {
        marker.marker.remove();
      });
      this.remarksFormControl.reset();
      this.remarksDescription = "";
      this.map.getCanvas().style.cursor = "grab";
      this.map.off("click", this.addRemarkMarker);
    }

    if (this.isPunchItemDrawMode) {
      this.showPunchListPanel = true;
      this.showPunchPanel = false;
      this.isPunchItemDrawMode = false;
      this.punchItemMarkers.map((punchItemMarker) => {
        punchItemMarker.punchItemMarker.remove();
      });
      this.map.getCanvas().style.cursor = "grab";
      this.map.off("click", this.addPunchItemMarker);
    }

    if (this.showEditRemarks) {
      this.showEditRemarks = false;
      this.isRemark = true;
    }

    if (this.showElevationLine) {
      this.elevationEscapeButtonClick = true;
    }

    if (this.drawElevationLineMode) {
      this.showElevationLine = false;
      this.elevationEscapeButtonClick = true;
      this.openElevationProfilePanel();
      this.draw.changeMode("simple_select");
      this.map.getCanvas().style.cursor = "grab";
      this.activateElevationClick();
    }

    if (this.drawVolumePolygonMode) {
      this.showVolumeCalculationPolygon = false;
      this.volumeEscapeButtonClick = true;
      this.openVolumePanel();
      this.draw.changeMode("simple_select");
      this.map.getCanvas().style.cursor = "grab";
      this.activateElevationClick();
    }

    if (this.drawRemarkPolygonMode) {
      this.showCreateRemarks = false;
      this.isRemark = true;
      this.drawAnnotationPolygon = true;
      this.drawRemarkPolygonMode = false;
      this.createdMarker.map((marker) => {
        marker.marker.remove();
      });
      this.draw.changeMode("simple_select");
      this.map.getCanvas().style.cursor = "grab";
      this.draw.deleteAll();
      this.remarksDescription = "";
    }

    if (this.createNewPunchItemPolygonMode) {
      this.showPunchListPanel = true;
      this.showPunchPanel = false;
      this.drawAnnotationPolygon = true;
      this.createNewPunchItemPolygonMode = false;
      this.draw.changeMode("simple_select");
      this.map.getCanvas().style.cursor = "grab";
      this.draw.deleteAll();
    }
  }

  hasSelfServeAccess() {
    this.aerialTourService.selfServeAccess(this.projectId).subscribe(
      (data) => {
        this.hasSSAccess = data.access;
      },
      (error) => {
        this.errors = error;
      }
    );
  }

  async getLookupData(project: Project) {
    let layerType = "layerColor";
    switch (project.type.code) {
      case "PT10008":
        layerType = "solarLayer";
        break;
      case "PT10013":
        layerType = "landsurveyLayer";
        break;
      default:
        layerType = "layerColor";
        break;
    }
    this.aerialTourService
      .getAnnotationTypeFromTour(this.tourId, this.projectId)
      .subscribe(
        (newAnnotationTypeColorData) => {
          this.lookupSvc.getAll(layerType).subscribe((data) => {
            this.colors = data;
            for (let annotationType of newAnnotationTypeColorData.annotationTypes) {
              this.colors.push(annotationType);
              this.colors = _.uniqBy(this.colors, (color) => {
                return color.value;
              });
            }

            this.aerialTourService
              .getAnnotationTypeFromProject(this.tourId, this.projectId)
              .subscribe((data) => {
                if (data.annotationTypes.length !== 0) {
                  data.annotationTypes.forEach((annotationTypeFromProject) => {
                    this.colors.push(annotationTypeFromProject);
                  });
                }
                const filteredAnnotaionTypes = this.filterSameAnnotationType(
                  this.colors
                );
                this.colors = filteredAnnotaionTypes;
              });
          });
        },
        (err) => {
          this.errors = err;
        }
      );
  }

  filterSameAnnotationType(array) {
    const uniqueKeys = {};
    const filteredArray = array.filter((item) => {
      if (!uniqueKeys[item.key]) {
        uniqueKeys[item.key] = true;
        return true;
      }
      return false;
    });
    return filteredArray;
  }

  getLayerData(projectId) {
    this.projectService.get(projectId).subscribe(
      (data) => {
        this.project = data;
        this.projectName = data.projectName;
        this.getLookupData(data);
      },
      (err) => {}
    );
  }

  getBlobAccessToken() {
    let container = this.config.mapoutputsContainer;
    this.storageService.getReadToken(container).subscribe(
      (data) => {
        this.blobStorageAccessToken = data.sasToken.token;
      },
      (err) => {}
    );
  }

  async getLegendUrl(blobContentId: string) {
    let readToken;
    let container = this.config.mediaContainer;
    let blobContainer = this.config.mediaBlobUrl;
    await this.storageService.getReadToken(container).subscribe(
      (data) => {
        readToken = data.sasToken.token;
        this.legendUrl = blobContainer + blobContentId + "?" + readToken;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getProjectDetails() {
    this.projectService.get(this.projectId).subscribe(
      (data) => {
        this.lat = data.lat;
        this.lng = data.lng;
        this.initiate_map();
      },
      (err) => {}
    );
  }

  savedLayers: any[] = [];
  prevSavedLayers: any[] = [];
  savedSources = {};

  saveCustomLayers(styleLoad?: boolean) {
    if (!styleLoad) {
      this.savedLayers = [];
      this.savedSources = {};
    }
    const layerIds = this.map.getStyle().layers.map((layer) => layer.id);

    layerIds.forEach((layerId) => {
      const layer = this.map.getLayer(layerId);
      const index = this.prevSavedLayers.findIndex(({ id }) => id === layerId);
      if (layer && index == -1) {
        const visibility = this.map.getLayoutProperty(layerId, "visibility");
        const isHidden = visibility === "none";

        if (!isHidden) {
          const sourceId: any = (layer as mapboxgl.Layer).source;
          if (sourceId && !this.savedSources[sourceId]) {
            this.savedSources[sourceId] = this.map.getSource(sourceId);
          }
          this.savedLayers.push(layer);
          this.prevSavedLayers.push(layer);
        }
      }
    });
  }

  reAddCustomLayers() {
    try {
      Object.keys(this.savedSources).forEach((sourceId) => {
        const source = this.savedSources[sourceId];
        if (source && !this.map.getSource(sourceId)) {
          this.map.addSource(sourceId, (source as any).serialize());
        }
      });

      let prevId;
      this.savedLayers.reverse();
      this.savedLayers.forEach((layer) => {
        if (layer && !this.map.getLayer(layer.id)) {
          prevId
            ? this.map.addLayer(layer as any)
            : this.map.addLayer(layer as any, prevId);
          prevId = layer.id;
        }
      });
    } catch (err) {
      console.log(err);
    }
  }

  initiate_map() {
    this.map = new mapboxgl.Map({
      container: "mapbox",
      style: this.style,
      zoom: this.defaultZoom,
      minZoom: this.minZoom,
      center: [this.lng, this.lat],
      preserveDrawingBuffer: true,
      pitchWithRotate: false, //prevent rotation from dragging,
      maxBounds: new mapboxgl.LngLatBounds(
        [this.lng - 0.2, this.lat - 0.2],
        [this.lng + 0.2, this.lat + 0.2]
      ), //set maximum bounds on map
    });
    // disable map rotation using right click + drag
    this.map.dragRotate.disable();

    // disable map rotation using touch rotation gesture
    // this.map.touchZoomRotate.disableRotation();

    // // Add map controls
    this.map.addControl(
      new mapboxgl.NavigationControl({ showCompass: false }),
      "bottom-right"
    );

    const styleSwitcherControl = new StyleSwitcherControl(this.styles);
    this.map.addControl(styleSwitcherControl, "top-left");
    styleSwitcherControl.onStyleChange((styleName) => {
      this.uiService.show();
      this.map.setStyle(styleName.url);
      this.map.once("style.load", () => {
        this.onLayerLoad(true);
      });
    });

    this.map.addControl(new mapboxgl.FullscreenControl(), "top-right");

    const scale = new mapboxgl.ScaleControl({
      maxWidth: 100,
      unit: this.measurementSystem,
    });

    this.map.addControl(scale);

    // ruler to measure size
    this.map.addControl(
      new RulerControl({
        units: this.unitOfCalculation,
        labelFormat: (n: number) =>
          `${n.toFixed(2)} ${LengthUnitSymbol[this.unitOfCalculation]}`, //label conversion for scale
        mainColor: "#000000",
        secondaryColor: "#fff",
        fontSize: 10,
        fontHalo: 3,
        textAllowOverlap: true,
        markerNodeSize: 10,
        markerNodeBorderWidth: 2,
      }),
      "top-left"
    );
    this.map.on("ruler.on", () => {
      this.deactivateElevationClick();
    });
    this.map.on("ruler.off", () => {
      this.activateElevationClick();
    });
    document
      .querySelector(".mapboxgl-ctrl-ruler")
      .setAttribute(
        "matTooltip",
        this.ts.instant("exterior.mapbox.labels.ruler")
      );
    document
      .querySelector(".mapboxgl-ctrl-ruler")
      .setAttribute("matTooltipShowDelay", "500");
    document
      .querySelector(".mapboxgl-ctrl-ruler")
      .setAttribute("matTooltipPosition", "right");

    this.map.addControl(new CompassControl({ instant: false }), "bottom-right");
    setTimeout(() => this.map.resize(), 250);

    this.onMapLoad();
  }

  resetView() {
    this.map.flyTo({
      center: [this.lng, this.lat],
      zoom: this.defaultZoom,
      essential: true,
    });
  }

  onMapLoad() {
    this.map.on("load", () => {
      const progressDiv = document.getElementById("load-progress");
      progressDiv.style.display = "block";
      let timer = 15000;
      const tourImages = this.tour.images.length;
      switch (true) {
        case tourImages < 100:
          timer = 10000;
          break;
        case tourImages < 200:
          timer = 12500;
          break;
        case tourImages < 300:
          timer = 15000;
          break;
        case tourImages < 400:
          timer = 17500;
          break;
        case tourImages < 500:
          timer = 20000;
          break;
        case tourImages >= 500:
          timer = 30000;
          break;
        default:
          timer = 15000;
      }

      // this.uiService.showDeteminate(timer / 1000);
      this.uiService.show();
      this.uiService.showOverlay();
      let initialTime = 1000;
      const setProgressPercent = setInterval(() => {
        if (initialTime <= timer) {
          this.downloadProgress = ((initialTime / timer) * 100)
            .toFixed(0)
            .toString();
          initialTime += 1000;
        } else {
          clearInterval(setProgressPercent);
        }
      }, 1000);
      this.map.loadImage("assets/images/gps.png", (error, image) => {
        setTimeout(() => this.map.resize(), 250);
        if (error) {
          console.log(error);
          throw error;
        }
        this.markerImage = image;
        this.map.addImage(`marker-${this.count++}`, this.markerImage);

        //passing map reference to sidebar component
        this.onLayerLoad();

        // area tool
        this.draw = new MapboxDraw({
          displayControlsDefault: false,
          controls: {
            polygon: true,
            trash: true,
          },
        });

        this.map.addControl(this.draw, "top-left");
        document
          .querySelector(".mapbox-gl-draw_polygon")
          .setAttribute(
            "title",
            this.ts.instant("exterior.mapbox.labels.drawPolygon")
          );
        document
          .querySelector(".mapbox-gl-draw_trash")
          .setAttribute(
            "title",
            this.ts.instant("exterior.mapbox.labels.cancelDrawing")
          );

        // load page loader based on number of images

        setTimeout(() => {
          this.uiService.hide();
          this.uiService.hideOverlay();
          progressDiv.style.display = "none";
        }, timer);

        this.map.on("draw.create", (e) => {
          this.polygonDrawn(e);
        });
        this.map.on("draw.delete", (e) => {
          this.deleteArea(e);
        });
      });
    });
  }

  onLayerLoad(styleChanged: boolean = false) {
    const mapOverLayer = {};
    let layerOrder = [];
    const currMapUrls: MapboxLayer[] = [...this.mapUrls];
    for (const url of currMapUrls) {
      if (
        url.appendIndex !== null &&
        url.appendIndex !== undefined &&
        url.appendIndex >= 0
      ) {
        {
          layerOrder.push({
            code: url.key,
            order: url.appendIndex,
          });
        }
      }
    }
    // sorting layers by order
    layerOrder.sort((a, b) => {
      return b.order - a.order;
    });
    const sortedMapUrls = [
      ...layerOrder.map((i: MapboxLayer) =>
        currMapUrls.find((j: MapboxLayer) => j.appendIndex === i.order)
      ),
    ];
    const overlayLayers: MapboxLayer[] = [];
    for (const layer of sortedMapUrls) {
      const layerCopy: MapboxLayer = Object.assign({}, layer);
      if (layerCopy.type == "shapefile") {
        layerCopy.code = "Contour";
        layerCopy.minZoom = this.minZoom;
        layerCopy.maxZoom = 24;
        layerCopy.dataType = "vector";
        layerCopy.sourceLayer = layerCopy.value.split(".")[1];
        layerCopy.url = layerCopy.value;
      } else if (
        layerCopy.type == "orthomosaic" ||
        layerCopy.type == "dsm" ||
        layerCopy.type == "dtm"
      ) {
        layerCopy.code = layerCopy.type;
        layerCopy.minZoom = this.minZoom;
        layerCopy.maxZoom = 24;
        layerCopy.dataType = "raster";
        layerCopy.url = layerCopy.value;
        layerCopy.tilesize = 256;
      } else if (layerCopy.type == "user_tif") {
        layerCopy.code = layerCopy.key;
        layerCopy.minZoom = this.minZoom;
        layerCopy.maxZoom = 24;
        layerCopy.dataType = "raster";
        layerCopy.url = layerCopy.value;
        layerCopy.tilesize = 256;
      } else if (layerCopy.type == "user_zipped_shapefile") {
        layerCopy.code = layerCopy.key;
        layerCopy.minZoom = this.minZoom;
        layerCopy.maxZoom = 24;
        layerCopy.dataType = "vector";
        layerCopy.sourceLayer = layerCopy.value.split(".")[1];
        layerCopy.url = layerCopy.value;
      } else if (layerCopy.type == "user_csv") {
        layerCopy.code = layerCopy.key;
        layerCopy.minZoom = this.minZoom;
        layerCopy.maxZoom = 24;
        layerCopy.dataType = "vector";
        layerCopy.url = layerCopy.value;
        layerCopy.sourceLayer = layerCopy.value.split(".")[1];
        layerCopy.tilesize = 256;
      } else if (layerCopy.type == "user_geojson") {
        layerCopy.code = layerCopy.key;
        layerCopy.minZoom = this.minZoom;
        layerCopy.maxZoom = 24;
        layerCopy.dataType = "vector";
        layerCopy.url = layerCopy.value;
        layerCopy.tilesize = 256;
      } else if (layerCopy.type == "user_kml") {
        layerCopy.code = layerCopy.key;
        layerCopy.minZoom = this.minZoom;
        layerCopy.maxZoom = 24;
        layerCopy.dataType = "vector";
        layerCopy.url = layerCopy.value;
        layerCopy.tilesize = 256;
      }

      overlayLayers.push(layerCopy);
    }
    this.currMapLayers = [...overlayLayers];

    let beforeId: string;
    for (const layer of overlayLayers) {
      if (layer.dataType === "raster") {
        if (layer.code == "dsm") {
          this.dsmTileId = layer.appendIndex + "";
        }
        if (layer.code == "dtm") {
          this.dtmTileId = layer.appendIndex + "";
        }
        this.map.addSource(layer.appendIndex + "", {
          type: layer.dataType,
          url: layer.url,
          tileSize: layer.tilesize,
        });

        if (beforeId) {
          this.map.addLayer(
            {
              id: layer.appendIndex + "",
              type: layer.dataType,
              source: layer.appendIndex + "",
              minzoom: layer.minZoom,
              maxzoom: layer.maxZoom,
            },
            beforeId
          );
        } else {
          this.map.addLayer({
            id: layer.appendIndex + "",
            type: layer.dataType,
            source: layer.appendIndex + "",
            minzoom: layer.minZoom,
            maxzoom: layer.maxZoom,
          });
        }
        beforeId = layer.appendIndex + "";
      } else if (layer.dataType === "vector") {
        if (layer.type.split("_").includes("shapefile")) {
          this.map.addSource(layer.appendIndex + "", {
            type: layer.dataType,
            url: layer.url,
          });
          if (beforeId) {
            if (layer.shapeFileData && layer.shapeFileData.type === "contour") {
              //contour-lines
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-lines",
                  type: "line",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "line-join": "round",
                    "line-cap": "round",
                  },
                  paint: {
                    "line-color": this.contourLayerColor,
                    "line-width": 1,
                  },
                },
                beforeId
              );

              // contour-labels elevation label
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-labels",
                  type: "symbol",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "symbol-placement": "point",
                    "text-anchor": "bottom",
                    "text-field": [
                      "concat",
                      [
                        "to-string",
                        [
                          "*",
                          ["get", "ELEVATION"],
                          LengthMultiplicationFactor[this.unitOfCalculation],
                        ],
                      ],
                      ` ${LengthUnitSymbol[this.unitOfCalculation]}`,
                    ],
                    "text-font": [
                      "literal",
                      ["DIN Pro Italic", "Arial Unicode MS Regular"],
                    ],
                    "text-size": 10,
                    "text-line-height": 1.2,
                    "text-rotation-alignment": "map",
                  },
                  paint: {
                    "text-color": "#000000",
                    "text-halo-color": "#FFFDD0",
                    "text-halo-width": 3,
                    "text-halo-blur": 0.5,
                  },
                },
                `${layer.appendIndex}-lines`
              );
              beforeId = `${layer.appendIndex}-labels`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-lines",
                layer.shapeFileData.columns
              );
            } else if (
              layer.shapeFileData &&
              layer.shapeFileData.type === "stream_flow_simulation"
            ) {
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-lines",
                  type: "line",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "line-join": "round",
                    "line-cap": "butt",
                    "line-round-limit": 0.75,
                  },
                  paint: {
                    "line-color": [
                      "match",
                      ["get", "grid_code"],
                      [1],
                      "#caf0f8",
                      [2],
                      "#90e0ef",
                      [3],
                      "#00b4d8",
                      [4],
                      "#0077b6",
                      [5],
                      "#1f45fc",
                      [6],
                      "#023e8a",
                      "#000000",
                    ],
                    "line-width": ["get", "grid_code"],
                  },
                },
                beforeId
              );
              beforeId = `${layer.appendIndex}-lines`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-lines",
                layer.shapeFileData.columns
              );
            } else if (
              layer.shapeFileData &&
              layer.shapeFileData.type === "boundary"
            ) {
              //contour-lines
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-lines",
                  type: "line",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "line-join": "miter",
                    "line-cap": "butt",
                    "line-miter-limit": 2,
                  },
                  paint: {
                    "line-color": this.boundaryLayerColor,
                    "line-width": 1.2,
                  },
                },
                beforeId
              );
              beforeId = `${layer.appendIndex}-lines`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-lines",
                layer.shapeFileData.columns
              );
            } else if (
              layer.shapeFileData &&
              layer.shapeFileData.type === "other"
            ) {
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-lines",
                  type: "line",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "line-join": "round",
                    "line-cap": "round",
                  },
                  paint: {
                    "line-color": "#000000",
                    "line-width": 1,
                  },
                },
                beforeId
              );
              beforeId = `${layer.appendIndex}-lines`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-lines",
                layer.shapeFileData.columns
              );
            } else if (
              layer.shapeFileData &&
              layer.shapeFileData.type === "points"
            ) {
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-point",
                  type: "symbol",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    "icon-image": "marker-1",
                    "icon-size": 0.3,
                  },
                },
                beforeId
              );
              beforeId = `${layer.appendIndex}-point`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-point",
                layer.shapeFileData.columns
              );
            } else {
              //contour-lines
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-lines",
                  type: "line",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "line-join": "round",
                    "line-cap": "round",
                  },
                  paint: {
                    "line-color": this.contourLayerColor,
                    "line-width": 1,
                  },
                },
                beforeId
              );

              // contour-labels elevation label
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-labels",
                  type: "symbol",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "symbol-placement": "point",
                    "text-anchor": "bottom",
                    "text-field": [
                      "concat",
                      [
                        "to-string",
                        [
                          "*",
                          ["get", "ELEVATION"],
                          LengthMultiplicationFactor[this.unitOfCalculation],
                        ],
                      ],
                      ` ${LengthUnitSymbol[this.unitOfCalculation]}`,
                    ],
                    "text-font": [
                      "literal",
                      ["DIN Pro Italic", "Arial Unicode MS Regular"],
                    ],
                    "text-size": 10,
                    "text-line-height": 1.2,
                    "text-rotation-alignment": "map",
                  },
                  paint: {
                    "text-color": "#000000",
                    "text-halo-color": "#FFFDD0",
                    "text-halo-width": 3,
                    "text-halo-blur": 0.5,
                  },
                },
                `${layer.appendIndex}-lines`
              );
              beforeId = `${layer.appendIndex}-labels`;
            }
          } else {
            if (layer.shapeFileData && layer.shapeFileData.type === "contour") {
              this.map.addLayer({
                id: layer.appendIndex + "-lines",
                type: "line",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                "source-layer": layer.sourceLayer,
                layout: {
                  visibility: "visible",
                  "line-join": "round",
                  "line-cap": "round",
                },
                paint: {
                  "line-color": this.contourLayerColor,
                  "line-width": 1,
                },
              });

              // contour-labels elevation label
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-labels",
                  type: "symbol",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "symbol-placement": "point",
                    "text-anchor": "bottom",
                    "text-field": [
                      "concat",
                      [
                        "to-string",
                        [
                          "*",
                          ["get", "ELEVATION"],
                          LengthMultiplicationFactor[this.unitOfCalculation],
                        ],
                      ],
                      ` ${LengthUnitSymbol[this.unitOfCalculation]}`,
                    ],
                    "text-font": [
                      "literal",
                      ["DIN Pro Italic", "Arial Unicode MS Regular"],
                    ],
                    "text-size": 10,
                    "text-line-height": 1.2,
                    "text-rotation-alignment": "map",
                  },
                  paint: {
                    "text-color": "#000000",
                    "text-halo-color": "#FFFDD0",
                    "text-halo-width": 3,
                    "text-halo-blur": 0.5,
                  },
                },
                `${layer.appendIndex}-lines`
              );
              beforeId = `${layer.appendIndex}-labels`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-lines",
                layer.shapeFileData.columns
              );
            } else if (
              layer.shapeFileData &&
              layer.shapeFileData.type === "stream_flow_simulation"
            ) {
              this.map.addLayer({
                id: layer.appendIndex + "-lines",
                type: "line",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                "source-layer": layer.sourceLayer,
                layout: {
                  visibility: "visible",
                  "line-join": "round",
                  "line-cap": "butt",
                  "line-round-limit": 0.75,
                },
                paint: {
                  "line-color": [
                    "match",
                    ["get", "grid_code"],
                    [1],
                    "#caf0f8",
                    [2],
                    "#90e0ef",
                    [3],
                    "#00b4d8",
                    [4],
                    "#0077b6",
                    [5],
                    "#1f45fc",
                    [6],
                    "#023e8a",
                    "#000000",
                  ],
                  "line-width": ["get", "grid_code"],
                },
              });
              beforeId = `${layer.appendIndex}-lines`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-lines",
                layer.shapeFileData.columns
              );
            } else if (
              layer.shapeFileData &&
              layer.shapeFileData.type === "boundary"
            ) {
              this.map.addLayer({
                id: layer.appendIndex + "-lines",
                type: "line",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                "source-layer": layer.sourceLayer,
                layout: {
                  visibility: "visible",
                  "line-join": "miter",
                  "line-cap": "butt",
                  "line-miter-limit": 2,
                },
                paint: {
                  "line-color": this.boundaryLayerColor,
                  "line-width": 1.2,
                },
              });
              beforeId = `${layer.appendIndex}-lines`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-lines",
                layer.shapeFileData.columns
              );
            } else if (
              layer.shapeFileData &&
              layer.shapeFileData.type === "other"
            ) {
              this.map.addLayer({
                id: layer.appendIndex + "-lines",
                type: "line",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                "source-layer": layer.sourceLayer,
                layout: {
                  visibility: "visible",
                  "line-join": "round",
                  "line-cap": "round",
                },
                paint: {
                  "line-color": "#000000",
                  "line-width": 1,
                },
              });
              beforeId = `${layer.appendIndex}-lines`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-lines",
                layer.shapeFileData.columns
              );
            } else if (
              layer.shapeFileData &&
              layer.shapeFileData.type === "points"
            ) {
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-point",
                  type: "symbol",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    "icon-image": "marker-1",
                    "icon-size": 0.3,
                  },
                },
                beforeId
              );
              beforeId = `${layer.appendIndex}-point`;
              this.loadShapeFilePopupByLayer(
                layer.appendIndex + "-point",
                layer.shapeFileData.columns
              );
            } else {
              this.map.addLayer({
                id: layer.appendIndex + "-lines",
                type: "line",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                "source-layer": layer.sourceLayer,
                layout: {
                  visibility: "visible",
                  "line-join": "round",
                  "line-cap": "round",
                },
                paint: {
                  "line-color": "#000000",
                  "line-width": 1,
                },
              });

              // contour-labels elevation label
              this.map.addLayer(
                {
                  id: layer.appendIndex + "-labels",
                  type: "symbol",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": layer.sourceLayer,
                  layout: {
                    visibility: "visible",
                    "symbol-placement": "point",
                    "text-anchor": "bottom",
                    "text-field": [
                      "concat",
                      [
                        "to-string",
                        [
                          "*",
                          ["get", "ELEVATION"],
                          LengthMultiplicationFactor[this.unitOfCalculation],
                        ],
                      ],
                      ` ${LengthUnitSymbol[this.unitOfCalculation]}`,
                    ],
                    "text-font": [
                      "literal",
                      ["DIN Pro Italic", "Arial Unicode MS Regular"],
                    ],
                    "text-size": 10,
                    "text-line-height": 1.2,
                    "text-rotation-alignment": "map",
                  },
                  paint: {
                    "text-color": "#000000",
                    "text-halo-color": "#FFFDD0",
                    "text-halo-width": 3,
                    "text-halo-blur": 0.5,
                  },
                },
                `${layer.appendIndex}-lines`
              );
              beforeId = `${layer.appendIndex}-labels`;
            }
          }
        } else if (layer.type.split("_").includes("geojson")) {
          this.map.addSource(layer.appendIndex + "", {
            type: "geojson",
            data: layer.geojsonData,
          });
          if (beforeId) {
            this.map.addLayer(
              {
                id: layer.appendIndex + "_point",
                type: "symbol",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                layout: {
                  "icon-image": "marker-1",
                  "icon-size": 0.3,
                },
                filter: ["==", "$type", "Point"],
              },
              beforeId
            );
            beforeId = layer.appendIndex + "_point";
            this.map.addLayer(
              {
                id: layer.appendIndex + "_polygon",
                type: "fill",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                paint: {
                  "fill-color": "#888888",
                  "fill-opacity": 1,
                },
                filter: ["==", "$type", "Polygon"],
              },
              beforeId
            );
            beforeId = layer.appendIndex + "_polygon";
          } else {
            this.map.addLayer({
              id: layer.appendIndex + "_point",
              type: "symbol",
              source: layer.appendIndex + "",
              minzoom: layer.minZoom,
              maxzoom: layer.maxZoom,
              layout: {
                "icon-image": "marker-1",
                "icon-size": 0.3,
              },
              filter: ["==", "$type", "Point"],
            });
            beforeId = layer.appendIndex + "_point";
            this.map.addLayer(
              {
                id: layer.appendIndex + "_polygon",
                type: "fill",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                paint: {
                  "fill-color": "#888888",
                  "fill-outline-color": "#000000",
                  "fill-opacity": 1,
                },
                filter: ["==", "$type", "Polygon"],
              },
              beforeId
            );
            beforeId = layer.appendIndex + "_polygon";
          }
        } else if (layer.type.split("_").includes("csv")) {
          this.map.addSource(layer.appendIndex + "", {
            type: "vector",
            url: layer.url,
          });
          if (beforeId) {
            this.map.addLayer(
              {
                id: layer.appendIndex + "",
                type: "symbol",
                source: layer.appendIndex + "",
                minzoom: layer.minZoom,
                maxzoom: layer.maxZoom,
                "source-layer": layer.sourceLayer,
                layout: {
                  "icon-image": "marker-1",
                  "icon-anchor": "bottom",
                  "icon-size": 0.3,
                  "text-field": ["to-string", ["get", "title"]],
                  "text-anchor": "top",
                  "text-offset": [0, 1],
                  "text-font": [
                    "literal",
                    ["Roboto Medium", "Arial Unicode MS Regular"],
                  ],
                  "text-size": 15,
                },
                paint: {
                  "text-color": "#000000",
                  "text-halo-color": "#FFFFFF",
                  "text-halo-width": 1,
                  "text-halo-blur": 1,
                },
              },
              beforeId
            );
          } else {
            this.map.addLayer({
              id: layer.appendIndex + "",
              type: "symbol",
              source: layer.appendIndex + "",
              minzoom: layer.minZoom,
              maxzoom: layer.maxZoom,
              "source-layer": layer.sourceLayer,
              layout: {
                "icon-image": "marker-1",
                "icon-anchor": "center",
                "icon-size": 0.3,
                "text-field": ["to-string", ["get", "title"]],
                "text-anchor": "top",
                "text-offset": [0, 1],
                "text-font": [
                  "literal",
                  ["Roboto Medium", "Arial Unicode MS Regular"],
                ],
                "text-size": 10,
              },
              paint: {
                "text-color": "#000000",
                "text-halo-color": "#FFFFFF",
                "text-halo-width": 1,
                "text-halo-blur": 1,
              },
            });
          }
          beforeId = layer.appendIndex + "";
        } else if (layer.type.split("_").includes("kml")) {
          this.map.addSource(layer.appendIndex + "", {
            type: "vector",
            url: layer.url,
          });
          for (const sourceLayer of layer.kmlSourceLayers) {
            if (beforeId) {
              if (sourceLayer.geometry === "polygon") {
                this.map.addLayer(
                  {
                    id: sourceLayer["layerId"],
                    type: "fill",
                    source: layer.appendIndex + "",
                    minzoom: layer.minZoom,
                    maxzoom: layer.maxZoom,
                    "source-layer": sourceLayer["source-layer"],
                    layout: {
                      visibility: "visible",
                    },
                    paint: {
                      "fill-color": "#088",
                      "fill-opacity": 1,
                      "fill-outline-color": "#000",
                      "fill-antialias": true,
                    },
                  },
                  beforeId
                );
              } else if (sourceLayer.geometry === "point") {
                this.map.addLayer(
                  {
                    id: sourceLayer["layerId"],
                    type: "symbol",
                    source: layer.appendIndex + "",
                    minzoom: layer.minZoom,
                    maxzoom: layer.maxZoom,
                    "source-layer": sourceLayer["source-layer"],
                    layout: {
                      "icon-image": "marker-1",
                      "icon-size": 0.3,
                      "text-field": ["to-string", ["get", "Name"]],
                      "text-anchor": "top",
                      "text-offset": [0, 1],
                      "text-font": [
                        "literal",
                        ["Roboto Medium", "Arial Unicode MS Regular"],
                      ],
                      "text-size": 10,
                    },
                  },
                  beforeId
                );
              }
            } else {
              if (sourceLayer.geometry === "polygon") {
                this.map.addLayer({
                  id: sourceLayer["layerId"],
                  type: "fill",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": sourceLayer["source-layer"],
                  layout: {
                    visibility: "visible",
                  },
                  paint: {
                    "fill-color": "#088",
                    "fill-opacity": 1,
                    "fill-outline-color": "#000",
                    "fill-antialias": true,
                  },
                });
              } else if (sourceLayer.geometry === "point") {
                this.map.addLayer({
                  id: sourceLayer["layerId"],
                  type: "symbol",
                  source: layer.appendIndex + "",
                  minzoom: layer.minZoom,
                  maxzoom: layer.maxZoom,
                  "source-layer": sourceLayer["source-layer"],
                  layout: {
                    "icon-image": "marker-1",
                    "icon-size": 0.3,
                    "text-field": ["to-string", ["get", "Name"]],
                    "text-anchor": "top",
                    "text-offset": [0, 1],
                    "text-font": [
                      "literal",
                      ["Roboto Medium", "Arial Unicode MS Regular"],
                    ],
                    "text-size": 10,
                  },
                });
              }
            }
            this.loadPopupByLayer(
              sourceLayer["layerId"],
              layer.appendIndex + "",
              sourceLayer["source-layer"]
            );
            beforeId = sourceLayer["layerId"];
          }
        }
      }
      mapOverLayer[layer.appendIndex] = Object.assign({}, layer);
    }

    this.addOpacityControl(mapOverLayer, "layers");
    this.loadElevation();
    styleChanged && this.uiService.hide();
  }

  toggleAllMapLayersDisplay() {
    const container = document.getElementById("layers");
    let visibilityParam;
    if (this.toggleAllMapLayers) {
      for (let i = 0; i < container.children.length; i++) {
        (<HTMLInputElement>container.children[i].children[0]).checked = false;
      }
      visibilityParam = "none";
    } else {
      for (let i = 0; i < container.children.length; i++) {
        (<HTMLInputElement>container.children[i].children[0]).checked = true;
      }
      visibilityParam = "visible";
    }

    for (let layer of this.currMapLayers) {
      const layerId = layer.appendIndex + "";
      if (layer.dataType === "raster") {
        this.map.getLayer(layerId)
          ? this.map.setLayoutProperty(layerId, "visibility", visibilityParam)
          : null;
      } else if (layer.dataType === "vector") {
        if (layer.type === "shapefile") {
          this.map.getLayer(`${layerId}-lines`)
            ? this.map.setLayoutProperty(
                `${layerId}-lines`,
                "visibility",
                visibilityParam
              )
            : null;
          this.map.getLayer(`${layerId}-labels`)
            ? this.map.setLayoutProperty(
                `${layerId}-labels`,
                "visibility",
                visibilityParam
              )
            : null;
        } else if (layer.type === "user_zipped_shapefile") {
          if (layer.shapeFileData.type === "contour") {
            this.map.getLayer(`${layerId}-lines`)
              ? this.map.setLayoutProperty(
                  `${layerId}-lines`,
                  "visibility",
                  visibilityParam
                )
              : null;
            this.map.getLayer(`${layerId}-labels`)
              ? this.map.setLayoutProperty(
                  `${layerId}-labels`,
                  "visibility",
                  visibilityParam
                )
              : null;
          } else if (layer.shapeFileData.type === "points") {
            this.map.getLayer(`${layerId}-point`)
              ? this.map.setLayoutProperty(
                  `${layerId}-point`,
                  "visibility",
                  visibilityParam
                )
              : null;
          } else {
            this.map.getLayer(`${layerId}-lines`)
              ? this.map.setLayoutProperty(
                  `${layerId}-lines`,
                  "visibility",
                  visibilityParam
                )
              : null;
          }
        } else if (layer.type === "user_geojson") {
          this.map.getLayer(`${layerId}_point`)
            ? this.map.setLayoutProperty(
                `${layerId}_point`,
                "visibility",
                visibilityParam
              )
            : null;
          this.map.getLayer(`${layerId}_polygon`)
            ? this.map.setLayoutProperty(
                `${layerId}_polygon`,
                "visibility",
                visibilityParam
              )
            : null;
        } else if (layer.type === "user_kml") {
          for (const laye of layer.kmlSourceLayers) {
            this.map.setLayoutProperty(
              laye.layerId,
              "visibility",
              visibilityParam
            );
          }
        } else {
          this.map.setLayoutProperty(layerId, "visibility", visibilityParam);
        }
      }
    }
    this.toggleAllMapLayers = !this.toggleAllMapLayers;
  }

  loadPopupByLayer(layerId: string, sourceId: string, sourceLayer: string) {
    let hoveredStateId = null;
    const popup = new mapboxgl.Popup({
      closeButton: false,
      closeOnClick: false,
    });
    this.map.on("mousemove", layerId, (e: any) => {
      if (e.features.length > 0) {
        this.map.getCanvas().style.cursor = "Pointer";
        if (hoveredStateId) {
          this.map.setFeatureState(
            {
              source: sourceId,
              id: hoveredStateId,
              sourceLayer: sourceLayer,
            },
            { hover: false }
          );
        }
        hoveredStateId = layerId;
        this.map.setFeatureState(
          {
            source: sourceId,
            id: hoveredStateId,
            sourceLayer: sourceLayer,
          },
          { hover: true }
        );
        const description = e.features[0].properties["Description"];
        const name = e.features[0].properties["Name"];
        popup
          .setLngLat(e.lngLat)
          .setHTML(
            `<span>Name: ${name}</span><br /><span>Description: ${description}</span>`
          )
          .addTo(this.map);
      }
    });
    this.map.on("mouseleave", layerId, () => {
      this.map.getCanvas().style.cursor = "";
      popup.remove();
      if (hoveredStateId) {
        this.map.setFeatureState(
          {
            source: sourceId,
            id: hoveredStateId,
            sourceLayer: sourceLayer,
          },
          { hover: false }
        );
      }
      hoveredStateId = null;
    });
  }

  loadShapeFilePopupByLayer(layerId: string, shapeFileColumnData: any) {
    this.map.on("click", layerId, (e: any) => {
      if (e.features.length > 0) {
        let dataToShow = [];
        for (let column of shapeFileColumnData) {
          dataToShow.push(
            `<span>${column === "grid_code" ? "stream_order" : column} : ${
              e.features[0].properties[column]
            }</span>`
          );
        }
        new mapboxgl.Popup({
          closeButton: true,
          closeOnClick: true,
        })
          .setLngLat(e.lngLat)
          .setHTML(dataToShow.join("<hr>"))
          .addTo(this.map);
      }
    });
    this.map.on("mouseenter", layerId, () => {
      this.deactivateElevationClick();
      this.map.getCanvas().style.cursor = "pointer";
    });
    this.map.on("mouseleave", layerId, () => {
      this.activateElevationClick();
      this.map.getCanvas().style.cursor = "";
    });
  }

  titleCase(str) {
    const splitStr = str.toLowerCase().split(" ");
    for (var i = 0; i < splitStr.length; i++) {
      splitStr[i] =
        splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    return splitStr.join(" ");
  }

  loadElevation() {
    let dsm_blob_url = "";
    let dtm_blob_url = "";
    const currMapURLs = [...this.mapUrls];
    for (const url of currMapURLs) {
      if (
        url.appendIndex !== null &&
        url.appendIndex !== undefined &&
        url.appendIndex < 0
      ) {
        const split_url = url.key.split("_");
        if (split_url.includes("blob") && url.uploadedTo === "blob") {
          if (split_url.includes("dsm")) {
            dsm_blob_url = `${url.value}?${this.blobStorageAccessToken}`;
          }
          if (split_url.includes("dtm") && url.uploadedTo === "blob") {
            dtm_blob_url = `${url.value}?${this.blobStorageAccessToken}`;
          }
        }
      }
    }
    if (dsm_blob_url) {
      this.dsmElevationLayer = L.leafletGeotiff(dsm_blob_url, {
        band: 0,
        name: "DSM Height",
        // renderer: L.LeafletGeotiff.rgb()
      });
    }

    if (dtm_blob_url) {
      this.dtmElevationLayer = L.leafletGeotiff(dtm_blob_url, {
        band: 0,
        name: "DTM Height",
        // renderer: L.LeafletGeotiff.rgb()
      });
    }

    if ((dtm_blob_url || dsm_blob_url) && (this.dsmTileId || this.dtmTileId)) {
      this.activateElevationClick();
    }

    this.map.on("draw.modechange", (e) => {
      if (
        e.mode == "draw_polygon" ||
        e.mode == "direct_select" ||
        e.mode == "draw_line_string"
      ) {
        this.deactivateElevationClick();
      }
      if (e.mode == "simple_select") {
        // this.activateElevationClick();
      }
    });
  }

  activateElevationClick = () => {
    this.map.on("click", this.showElevationActivator);
  };

  showElevationActivator = (e) => {
    this.showElevation(e, this.dtmElevationLayer, this.dsmElevationLayer);
  };

  deactivateElevationClick() {
    this.map.off("click", this.showElevationActivator);
  }
  showElevation(
    e: mapboxgl.MapMouseEvent,
    dtmLeafletElevationLayer: any,
    dsmLeafletElevationLayer: any
  ) {
    let htmlText = `<div>Latitude : ${e.lngLat.lat.toFixed(
      6
    )}<br>Longitude : ${e.lngLat.lng.toFixed(6)}</div>`;
    let dsmText = undefined;
    let dtmText = undefined;
    if (
      this.dsmTileId &&
      this.map.getLayoutProperty(this.dsmTileId, "visibility") == "visible"
    ) {
      const lat = e.lngLat.lat;
      const lng = e.lngLat.lng;

      let dsmElevation;
      if (dsmLeafletElevationLayer) {
        dsmElevation = dsmLeafletElevationLayer.getValueAtLatLng(lat, lng);
      }

      dsmText =
        '<div class="popupHeader">DSM Elevation</div><hr><table><tr><td style="color:#888888; padding-right: 5px">Elevation(m) </td><td>dsmElevation</td><tr></table>';
      if (dsmLeafletElevationLayer && dsmElevation) {
        dsmText = dsmText.replace("dsmElevation", dsmElevation.toFixed(2));
      } else {
        dsmText = dsmText.replace("dsmElevation", "Unavailable");
      }
    }

    if (
      this.dtmTileId &&
      this.map.getLayoutProperty(this.dtmTileId, "visibility") == "visible"
    ) {
      const lat = e.lngLat.lat;
      const lng = e.lngLat.lng;
      let dtmElevation;
      if (dtmLeafletElevationLayer) {
        dtmElevation = dtmLeafletElevationLayer.getValueAtLatLng(lat, lng);
      }

      dtmText = `<div class="popupHeader">DTM Elevation</div><hr><table><tr><td style="color:#888888; padding-right: 5px">Elevation(m) </td><td>dtmElevation</td><tr></table>`;

      if (dsmLeafletElevationLayer && dtmElevation) {
        dtmText = dtmText.replace("dtmElevation", dtmElevation.toFixed(2));
      } else {
        dtmText = dtmText.replace("dtmElevation", "Unavailable");
      }
    }

    new mapboxgl.Popup()
      .setLngLat(e.lngLat)
      .setHTML(_.compact([htmlText, dsmText, dtmText]).join("<hr>"))
      .addTo(this.map);
  }

  polygonDrawn(e: any) {
    if (this.showVolumeTool) {
      this.insertVolumeData(e);
    } else if (this.showElevationTool) {
      this.insertElevationData(e);
    } else if (this.drawRemarkPolygonMode) {
      this.remarkPolygonData(e);
    } else if (this.createNewPunchItemPolygonMode) {
      this.punchItemPolygonData(e);
    } else {
      this.deactivateElevationClick();
      this.drawAnnotationPolygon = !this.drawAnnotationPolygon;
      if (this.drawAnnotationPolygon) {
        this.drawPolygonLayer();
        this.drawAnnotationPolygon = false;
      }
    }
  }

  drawPolygonLayer(polygonId: string = null, polygon: any = {}) {
    const data: any = this.draw.getAll();
    const polygonVertices = data.features[0].geometry.coordinates;
    const { area, perimeter } = this.calculatePolygonStats(data);
    const drawnPolygonId = polygonId ? polygonId : uuidv4();
    const polygon_label = polygon.polygon_label ? polygon.polygon_label : "";
    const polygon_color = polygon.polygon_color ? polygon.polygon_color : "";
    this.draw.deleteAll();
    const annotationObj: MapboxAnnotation = {
      polygonVertices,
      area,
      perimeter,
      drawnPolygonId,
      polygon_label,
      polygon_color,
    };

    this.annotationComponentDialogRef = this.dialog.open(AnnotationComponent, {
      width: "450px",
      disableClose: true,
      data: {
        projectId: this.projectId,
        tourId: this.tourId,
        annotation: annotationObj,
        listType: this.colors,
      },
    });

    this.annotationComponentDialogRef
      .afterClosed()
      .subscribe((dialogResult) => {
        if (dialogResult && dialogResult.newAnnotationTypeColor) {
          this.newAnnotationTypeColor = dialogResult.newAnnotationTypeColor;
        }
        this.getLookupData(this.project);
        this.annotationController("");
        this.activateElevationClick();
      });
  }

  deleteAnnotations(annotationId: string) {
    this.aerialTourService
      .deleteMapboxAnnotations(this.tourId, this.projectId, annotationId)
      .subscribe(
        (data) => {
          this.annotationLayers = data.annotations;
          this.annotationController("", this.annotationLayers);
        },
        (err) => {}
      );
  }

  deleteArea(e: any) {
    this.poylgon_drawn = false;
    this.draw.deleteAll();
  }

  calculatePolygonStats(data: any) {
    const area = `${
      Math.round(
        turf.convertArea(turf.area(data), "meters", this.unitOfCalculation) *
          100
      ) / 100
    } ${AreaUnitSymbol[this.unitOfCalculation]}`;
    const currentFeature = data.features[0];
    const line = turf.polygonToLine(
      turf.polygon(currentFeature.geometry.coordinates)
    );
    const perimeter = `${Math.round(
      turf.length(line, { units: this.unitOfCalculation })
    )} ${LengthUnitSymbol[this.unitOfCalculation]}`;
    return { area, perimeter };
  }

  /**Mapbox Sidebar Functions */

  OnSearch() {
    // if (this.annotationSearchTerm.length <= 2) {
    //   return;
    // }
    if (this.prevAnnotationSearchTerm === this.annotationSearchTerm) {
      return;
    }

    this.initializeCustomLayer();
    this.prevAnnotationSearchTerm = this.annotationSearchTerm;
  }

  OnClear() {
    if (
      this.annotationSearchTerm === "" &&
      this.prevAnnotationSearchTerm === this.annotationSearchTerm
    ) {
      return;
    }
    this.prevAnnotationSearchTerm = this.annotationSearchTerm = "";
    this.initializeCustomLayer();
  }

  initializeCustomLayer() {
    if (this.annotationLayers) {
      this.annotationController(
        this.annotationSearchTerm,
        this.annotationLayers
      );
    } else {
      this.annotationController(this.annotationSearchTerm);
    }
  }

  annotationController(
    searchTerm: string,
    annotationLayers?: MapboxAnnotation[]
  ) {
    this.toggleAnnotationLayers = true;
    this.toggleAnnotationColorLayers = true;
    if (annotationLayers) {
      this.removeAllAnnotationsFromMap(annotationLayers);
      if (searchTerm && searchTerm != "") {
        annotationLayers = annotationLayers.filter((layer) => {
          return (
            layer.polygon_label
              .toString()
              .toLowerCase()
              .indexOf(searchTerm.toLowerCase()) !== -1
          );
        });
      }
      this.addSidebarAnnotationLayersAndDraw(annotationLayers);
      this.annotationLayerByColor(
        annotationLayers,
        this.newAnnotationTypeColor
      );
    } else {
      this.uiService.show();
      let annotationLayersFiltered: MapboxAnnotation[];
      this.aerialTourService
        .getMapboxAnnotations(this.tourId, this.projectId)
        .subscribe(
          (data) => {
            this.annotationLayers = data.annotations;
            annotationLayersFiltered = this.annotationLayers;
            this.removeAllAnnotationsFromMap(annotationLayersFiltered);
            if (searchTerm && searchTerm != "") {
              annotationLayersFiltered = annotationLayersFiltered.filter(
                (layer) => {
                  return (
                    layer.polygon_label
                      .toString()
                      .toLowerCase()
                      .indexOf(searchTerm.toLowerCase()) !== -1
                  );
                }
              );
            }
            this.addSidebarAnnotationLayersAndDraw(annotationLayersFiltered);
            this.annotationLayerByColor(
              annotationLayersFiltered,
              this.newAnnotationTypeColor
            );
            this.uiService.hide();
          },
          (err) => {
            this.annotationLayers = [];
            this.uiService.hide();
          }
        );
    }
  }

  removeAllAnnotationsFromMap(annotationLayers: MapboxAnnotation[]) {
    annotationLayers.forEach((layer: MapboxAnnotation) => {
      if (typeof this.map.getLayer(layer.drawnPolygonId) != "undefined") {
        this.map
          .removeLayer(layer.drawnPolygonId)
          .removeLayer(layer.drawnPolygonId + "_line")
          .removeSource(layer.drawnPolygonId + "_source");
      }
    });
  }

  addSidebarAnnotationLayersAndDraw(annotationLayers: MapboxAnnotation[]) {
    const annotationLayerObj = {};
    annotationLayers.forEach((layer: any) => {
      if (typeof this.map.getLayer(layer.drawnPolygonId) != "undefined") {
        this.map
          .removeLayer(layer.drawnPolygonId)
          .removeLayer(layer.drawnPolygonId + "_line")
          .removeSource(layer.drawnPolygonId + "_source");
      }
      this.drawPolygon(
        layer.polygonVertices,
        layer.drawnPolygonId,
        layer.area,
        layer.perimeter,
        layer.polygon_label,
        layer.polygon_color
      );
      annotationLayerObj[layer.polygon_label] = layer.drawnPolygonId;
    });

    this.addOpacityControl(annotationLayerObj, "annotationLayers", true);
  }

  checkBoxControlAdd(layerObj: any, container: any) {
    const layerKey = Object.keys(layerObj)[0];
    const br = document.createElement("br");
    const checkBox = <HTMLInputElement>(
      (<unknown>document.createElement("input"))
    );
    checkBox.setAttribute("type", "checkbox");
    checkBox.style.cssText = "float:left;cursor:pointer";
    checkBox.id = layerKey;
    layerObj[layerKey].forEach((layerId: any) => {
      if (layerObj.isAnnotation) {
        this.map.setLayoutProperty(layerId, "visibility", "visible");
        checkBox.defaultChecked = this.toggleAnnotationLayers;
      } else {
        const currMapUrl = [
          ...this.mapUrls.filter(({ appendIndex }) => {
            return appendIndex + "" === layerKey;
          }),
        ];
        if (currMapUrl && currMapUrl[0] && currMapUrl[0].disabled) {
          this.map.setLayoutProperty(layerId, "visibility", "none");
          checkBox.defaultChecked = false;
        } else {
          this.map.setLayoutProperty(layerId, "visibility", "visible");
          checkBox.defaultChecked = true;
        }
      }

      container.appendChild(checkBox);
      checkBox.addEventListener("change", (event) => {
        const ckFlag = (<HTMLInputElement>event.target).checked;
        if (ckFlag) {
          this.map.setLayoutProperty(layerId, "visibility", "visible");
        } else {
          this.map.setLayoutProperty(layerId, "visibility", "none");
        }

        if (this.dsmTileId && this.dsmTileId === layerId) {
          this.prevDsmLayerVisibility = this.map.getLayoutProperty(
            this.dsmTileId,
            "visibility"
          );
        }
        if (this.dtmTileId && this.dtmTileId === layerId) {
          this.prevDtmLayerVisibility = this.map.getLayoutProperty(
            this.dtmTileId,
            "visibility"
          );
        }
      });
    });

    const layerName = document.createElement("span");
    if (layerObj.isAnnotation) {
      const annotationNameDiv = document.createElement("div");
      const layerKeyText = document.createTextNode(layerKey);
      annotationNameDiv.appendChild(layerKeyText);
      annotationNameDiv.style.cssText = "float:left;cursor:pointer";
      annotationNameDiv.addEventListener("click", () => {
        const currAnnotation = this.annotationLayers.filter((layer) => {
          return layer.drawnPolygonId === layerObj[layerKey][0];
        })[0];
        const geojsonData = {
          type: "FeatureCollection",
          features: [
            {
              id: 1,
              type: "Feature",
              geometry: {
                type: "Polygon",
                coordinates: currAnnotation.polygonVertices,
              },
              properties: {
                area: currAnnotation.area,
                perimeter: currAnnotation.perimeter,
                polygon_label: currAnnotation.polygon_label,
              },
            },
          ],
        };
        this.saveFileAsGeojson(JSON.stringify(geojsonData), layerKey);
      });
      layerName.appendChild(annotationNameDiv);

      const delIcon = document.createElement("mat-icon");
      delIcon.id = "::img";
      delIcon.style.cssText =
        "float:right;margin-right:0em;color:#413d65;cursor:pointer";
      delIcon.className = "material-icons pull-right";
      delIcon.appendChild(document.createTextNode("delete"));
      delIcon.setAttribute("aria-hidden", "true");
      delIcon.addEventListener("click", () => {
        this.map
          .removeLayer(layerObj[layerKey][0])
          .removeLayer(layerObj[layerKey][1])
          .removeSource(layerObj[layerKey][0] + "_source");

        this.deleteAnnotations(layerObj[layerKey][0]);
      });
      layerName.appendChild(delIcon);

      const editingCompleteIcon = document.createElement("mat-icon");
      editingCompleteIcon.id = "::img";
      editingCompleteIcon.style.cssText =
        "float: right;margin-right:0.3em;color:#413d65;cursor:pointer";
      editingCompleteIcon.className = "material-icons";
      editingCompleteIcon.appendChild(document.createTextNode("done"));
      editingCompleteIcon.setAttribute("aria-hidden", "true");
      const editIcon = document.createElement("mat-icon");
      editIcon.id = "::img";
      editIcon.style.cssText =
        "float: right;margin-right:0.3em;color:#413d65;cursor:pointer";
      editIcon.className = "material-icons pull-right";
      editIcon.appendChild(document.createTextNode("edit"));
      editIcon.setAttribute("aria-hidden", "true");

      editingCompleteIcon.addEventListener("click", () => {
        this.deleteAnnotations(this.currSelectedAnnotationId);
        const currAnnotation = this.annotationLayers.filter((layer) => {
          return layer.drawnPolygonId === this.currSelectedAnnotationId;
        })[0];
        this.drawPolygonLayer(this.currSelectedAnnotationId, currAnnotation);
        this.currSelectedAnnotationId = null;
        this.draw.changeMode("simple_select");
        // layerName.appendChild(editIcon);
      });

      editIcon.addEventListener("click", () => {
        this.map
          .removeLayer(layerObj[layerKey][0])
          .removeLayer(layerObj[layerKey][1])
          .removeSource(layerObj[layerKey][0] + "_source");
        const currAnnotation = this.annotationLayers.filter((layer) => {
          return layer.drawnPolygonId === layerObj[layerKey][0];
        })[0];
        this.currSelectedAnnotationId = currAnnotation.drawnPolygonId;
        this.draw.add({
          type: "FeatureCollection",
          features: [
            {
              id: this.currSelectedAnnotationId,
              type: "Feature",
              geometry: {
                type: "Polygon",
                coordinates: currAnnotation.polygonVertices,
              },
              properties: {
                area: currAnnotation.area,
                perimeter: currAnnotation.perimeter,
                polygon_label: currAnnotation.polygon_label,
              },
            },
          ],
        });
        this.draw.changeMode("direct_select", {
          featureId: this.currSelectedAnnotationId,
        });
        layerName.removeChild(editIcon);
        layerName.appendChild(br);
        layerName.appendChild(editingCompleteIcon);
        layerName.appendChild(br);
      });
      layerName.appendChild(editIcon);
      layerName.appendChild(br);
    } else {
      const name = this.currMapLayers.filter(({ appendIndex }) => {
        return appendIndex + "" === layerKey;
      })[0].code;
      layerName.appendChild(document.createTextNode(this.titleCase(name)));
    }
    container.appendChild(layerName);
  }

  toggleAnnotationDisplay(elementId) {
    const container = document.getElementById(elementId);
    if (this.toggleAnnotationLayers && this.toggleAnnotationColorLayers) {
      for (let i = 0; i < container.children.length; i++) {
        (<HTMLInputElement>container.children[i].children[0]).checked = false;
      }
      this.annotationLayers.forEach((layer: any) => {
        if (typeof this.map.getLayer(layer.drawnPolygonId) != "undefined") {
          this.map.setLayoutProperty(
            layer.drawnPolygonId,
            "visibility",
            "none"
          );
          this.map.setLayoutProperty(
            layer.drawnPolygonId + "_line",
            "visibility",
            "none"
          );
        }
      });
    } else {
      for (let i = 0; i < container.children.length; i++) {
        (<HTMLInputElement>container.children[i].children[0]).checked = true;
      }
      this.annotationLayers.forEach((layer: any) => {
        if (typeof this.map.getLayer(layer.drawnPolygonId) != "undefined") {
          this.map.setLayoutProperty(
            layer.drawnPolygonId,
            "visibility",
            "visible"
          );
          this.map.setLayoutProperty(
            layer.drawnPolygonId + "_line",
            "visibility",
            "visible"
          );
        }
      });
    }
    if (elementId == "annotationLayers") {
      this.toggleAnnotationLayers = !this.toggleAnnotationLayers;
      this.toggleAnnotationColorLayers = !this.toggleAnnotationColorLayers;
    } else if (elementId == "colorLayers") {
      this.toggleAnnotationColorLayers = !this.toggleAnnotationColorLayers;
      this.toggleAnnotationLayers = !this.toggleAnnotationLayers;
    }
  }

  saveFileAsGeojson(data, filename = "default_filename") {
    let blob = new Blob([data], {
      type: "text/plain",
    });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      //if Safari open in new window to save file with random filename.
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".geojson");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  _rangeControlAdd(layerId: string, itemContainer: any) {
    const range = document.createElement("input");
    range.id = "::img";
    range.style.cssText =
      "float: right;margin-right:-1em;color:#413d65;width:100%;margin-top: 17px; margin-left: 6px;";

    range.setAttribute("type", "range");
    range.setAttribute("min", "0");
    range.setAttribute("max", "100");
    range.setAttribute("value", "100");
    itemContainer.appendChild(range);

    range.addEventListener("input", (event) => {
      const rgValue = parseInt((<HTMLInputElement>event.target).value);
      this.map.setPaintProperty(
        layerId,
        "raster-opacity",
        Number(rgValue / 100)
      );
    });
  }

  addOpacityControl(
    availableLayers: any,
    elementId: string,
    isAnnotation?: boolean
  ): void {
    this._container = document.getElementById(elementId);
    if (this._container) {
      if (this._container && this._container.firstChild) {
        while (this._container.firstChild) {
          this._container.removeChild(this._container.lastChild);
        }
      }
      this.availableLayers = availableLayers;
      if (availableLayers !== null) {
        for (const layer of Object.keys(availableLayers)) {
          const layerId = layer;
          const itemContainer = document.createElement("div");

          let obj = {};
          if (isAnnotation) {
            obj[layerId] = [
              availableLayers[layerId],
              availableLayers[layerId] + "_line",
            ];
            obj["isAnnotation"] = true;
          } else {
            // if not annotation, then normal layers

            if (availableLayers[layerId].type === "shapefile") {
              // for contour
              obj[layerId] = [
                `${availableLayers[layerId].appendIndex}-lines`,
                `${availableLayers[layerId].appendIndex}-labels`,
              ];
            } else if (
              availableLayers[layerId].type === "user_zipped_shapefile"
            ) {
              if (availableLayers[layerId].shapeFileData.type === "contour") {
                // for contour
                obj[layerId] = [
                  `${availableLayers[layerId].appendIndex}-lines`,
                  `${availableLayers[layerId].appendIndex}-labels`,
                ];
              } else if (
                availableLayers[layerId].shapeFileData.type === "points"
              ) {
                // for points file
                obj[layerId] = [
                  `${availableLayers[layerId].appendIndex}-point`,
                ];
              } else {
                obj[layerId] = [
                  `${availableLayers[layerId].appendIndex}-lines`,
                ];
              }
            } else if (availableLayers[layerId].type === "user_geojson") {
              // for geojson
              obj[layerId] = [];
              if (
                this.map.getLayer(
                  `${availableLayers[layerId].appendIndex}_point`
                )
              ) {
                obj[layerId].push(
                  `${availableLayers[layerId].appendIndex}_point`
                );
              }
              if (
                this.map.getLayer(
                  `${availableLayers[layerId].appendIndex}_polygon`
                )
              ) {
                obj[layerId].push(
                  `${availableLayers[layerId].appendIndex}_polygon`
                );
              }
            } else if (availableLayers[layerId].type === "user_kml") {
              // for kml
              obj[layerId] = [];
              for (const layer of availableLayers[layerId].kmlSourceLayers) {
                obj[layerId].push(layer.layerId);
              }
            } else {
              obj[layerId] = [availableLayers[layerId].appendIndex];
            }
          }

          itemContainer.id = "::maplayer";
          itemContainer.style.cssText = !isAnnotation
            ? "margin:1em;background-color:white;padding: 19px 50px 44px 15px;"
            : "margin-top:.5em";

          this._container.appendChild(itemContainer);
          this.checkBoxControlAdd(obj, itemContainer);

          if (
            this.opacityControlOption &&
            !obj["isAnnotation"] &&
            ![
              "user_kml",
              "user_geojson",
              "user_csv",
              "user_zipped_shapefile",
              "shapefile",
            ].includes(availableLayers[layerId].type)
          ) {
            this._rangeControlAdd(layerId, itemContainer);
          }
        }
      }
    } else {
      // console.log("no layers");
    }
  }

  drawPolygon(
    points: any,
    drawnPolygonId: string,
    area: string,
    perimeter: string,
    polygon_label: string,
    polygon_color: string
  ) {
    let hoveredStateId = null;
    const popup = new mapboxgl.Popup({
      closeButton: false,
      closeOnClick: false,
    });
    const source = drawnPolygonId + "_source";
    this.map.addSource(source, {
      type: "geojson",
      data: {
        type: "FeatureCollection",
        features: [
          {
            id: 1,
            type: "Feature",
            geometry: {
              type: "Polygon",
              coordinates: points,
            },
            properties: {
              area: area,
              perimeter: perimeter,
              polygon_label: polygon_label,
              description: `<strong>${polygon_label}</strong><br /><strong>Area: </strong>${area}<br /><strong>Perimeter: </strong>${perimeter}`,
            },
          },
        ],
      },
    });

    this.map.addLayer({
      id: drawnPolygonId,
      type: "fill",
      source: source,
      layout: {},
      paint: {
        "fill-color": polygon_color,
        "fill-opacity": [
          "case",
          ["boolean", ["feature-state", "hover"], false],
          this.project.type.code === "PT10008" ? 0.1 : 0.4,
          this.project.type.code === "PT10008" ? 0.2 : 0.5,
        ],
      },
    });
    this.map.addLayer({
      id: drawnPolygonId + "_line",
      type: "line",
      source: source,
      layout: {},
      paint: {
        "line-color": "#627BC1",
        "line-width": 1,
      },
    });
    this.map.on("mousemove", drawnPolygonId, (e: any) => {
      if (e.features.length > 0) {
        this.map.getCanvas().style.cursor = "Pointer";
        if (hoveredStateId !== null) {
          this.map.setFeatureState(
            { source: source, id: hoveredStateId },
            { hover: false }
          );
        }
        hoveredStateId = 1;
        this.map.setFeatureState(
          { source: source, id: hoveredStateId },
          { hover: true }
        );
        const description = e.features[0].properties.description;
        popup.setLngLat(e.lngLat).setHTML(description).addTo(this.map);
      }
    });

    this.map.on("mouseleave", drawnPolygonId, () => {
      this.map.getCanvas().style.cursor = "";
      popup.remove();
      if (hoveredStateId !== null) {
        this.map.setFeatureState(
          { source: source, id: hoveredStateId },
          { hover: false }
        );
      }
      hoveredStateId = null;
    });

    this.map.on("contextmenu", drawnPolygonId, (e) => {
      this.currSelectedAnnotationId = drawnPolygonId;
      this.map
        .removeLayer(drawnPolygonId)
        .removeLayer(drawnPolygonId + "_line")
        .removeSource(drawnPolygonId + "_source");
      const currAnnotation = this.annotationLayers.filter((layer) => {
        return layer.drawnPolygonId === this.currSelectedAnnotationId;
      })[0];
      this.draw.add({
        type: "FeatureCollection",
        features: [
          {
            id: this.currSelectedAnnotationId,
            type: "Feature",
            geometry: {
              type: "Polygon",
              coordinates: currAnnotation.polygonVertices,
            },
            properties: {
              area: currAnnotation.area,
              perimeter: currAnnotation.perimeter,
              polygon_label: currAnnotation.polygon_label,
            },
          },
        ],
      });

      this.deleteAnnotations(this.currSelectedAnnotationId);
      this.drawPolygonLayer(this.currSelectedAnnotationId, currAnnotation);
      this.currSelectedAnnotationId = null;
    });
  }

  annotationLayerByColor(
    annotationLayers: MapboxAnnotation[],
    extraColors?: any
  ) {
    const layerByColor = {};
    this._container = document.getElementById("colorLayers");
    if (this._container) {
      if (this._container.firstChild) {
        while (this._container.firstChild) {
          this._container.removeChild(this._container.lastChild);
        }
      }
      if (extraColors && Array.isArray(extraColors) && extraColors.length > 0) {
        this.colors.push(...extraColors);
      }
      this.colors = _.uniqBy(this.colors, (color) => {
        return color.value;
      });
      this.colors.forEach((color) => {
        const layerIdsWithColor = [];
        for (const annotationLayer of annotationLayers) {
          if (annotationLayer.polygon_color == color.key) {
            layerIdsWithColor.push(annotationLayer.drawnPolygonId);
            layerIdsWithColor.push(annotationLayer.drawnPolygonId + "_line");
          }
        }
        layerByColor[color.value] = layerIdsWithColor;
      });
      // this._container = document.getElementById('colorLayers');
      Object.keys(layerByColor).forEach((layer) => {
        const checkBox = <HTMLInputElement>(
          (<unknown>document.createElement("input"))
        );
        checkBox.setAttribute("type", "checkbox");
        checkBox.id = layer;
        checkBox.defaultChecked = this.toggleAnnotationColorLayers;

        const itemContainer = document.createElement("div");
        itemContainer.id = "::maplayer";
        this._container.appendChild(itemContainer);

        itemContainer.appendChild(checkBox);

        checkBox.addEventListener("change", (event) => {
          const ckFlag = (<HTMLInputElement>event.target).checked;
          if (ckFlag) {
            layerByColor[layer].forEach((layerId: any) => {
              this.map.setLayoutProperty(layerId, "visibility", "visible");
            });
          } else {
            layerByColor[layer].forEach((layerId: any) => {
              this.map.setLayoutProperty(layerId, "visibility", "none");
            });
          }
        });
        const layerName = document.createElement("span");
        layerName.appendChild(document.createTextNode(layer));
        const backgroundColor = this.colors.filter(
          (color: any) => color.value == layer
        )[0].key;
        itemContainer.style.cssText =
          "margin-top:.3em;background-color:" + backgroundColor + ";";
        itemContainer.appendChild(layerName);
        const br = document.createElement("br");
      });
    } else {
      // console.log("no layers");
    }
  }

  captureView() {
    this.uiService.show();
    const node = document.querySelector(".mapboxgl-canvas");

    const props = {
      width: node.clientWidth * 1,
      height: node.clientHeight * 1,
      style: {
        transform: "scale(" + 1 + ")",
        "transform-origin": "top left",
      },
    };

    domtoimage
      .toBlob(node, props)
      .then((file) => {
        window.saveAs(file, this.tour.tourName + ".png");
        this.uiService.hide();
      })
      .catch((error) => {
        // console.log(error);
        this.uiService.hide();
      });
  }

  setViewPortSize() {
    const body = document.body,
      html = document.documentElement;
    const height = Math.max(
      body.scrollHeight,
      body.offsetHeight,
      html.clientHeight,
      html.scrollHeight,
      html.offsetHeight
    );
    const width = Math.max(
      body.scrollWidth,
      body.offsetWidth,
      html.clientWidth,
      html.scrollWidth,
      html.offsetWidth
    );
    document.getElementById("mapbox").style.height = height - 50 + "px";
    document.getElementById("mapbox").style.width = width - 17 + "px";
  }

  async closeDialog(): Promise<void> {
    this.closeDialogs();
    this.dialogRef.close();
  }

  openProgressBar() {
    this.showProgressBar = true;
    this.sideNave.toggle();
  }

  closeProgressBar() {
    this.showProgressBar = false;
    this.sideNave.toggle();
  }

  openSelfServeProgressBar() {
    this.showSelfServe = true;
    this.selfServe.toggle();
  }

  closeSelfServeProgressBar() {
    this.showSelfServe = false;
    this.selfServe.toggle();
  }

  openProjectProgressBar() {
    this.showProjectProgress = true;
    this.projectProgressBar.toggle();
  }

  closeProjectProgressBar() {
    this.showProjectProgress = false;
    this.projectProgressBar.toggle();
  }

  openVolumePanel() {
    this.showVolumeCalculationPolygon = !this.showVolumeCalculationPolygon;

    if (this.showVolumeCalculationPolygon) {
      this.showVolumeTool = true;
      this.uiService.show();
      this.getVolumeList();
      this.volumePanel.toggle();
    } else {
      this.closeVolumeTool();
    }
  }

  closeVolumeTool() {
    this.showVolumeTool = false;
    this.drawVolumePolygonMode = false;
    this.cancelVolumeCalculation();
    if (this.volumeApiInterval) {
      clearInterval(this.volumeApiInterval);
    }
    for (let polygon of this.volumeList) {
      if (typeof this.map.getLayer(polygon.volumeUniqueId) != "undefined") {
        this.map
          .removeLayer(polygon.volumeUniqueId)
          .removeLayer(polygon.volumeUniqueId + "_line")
          .removeSource(polygon.volumeUniqueId + "_source");
      }
    }
    this.volumeList = [];
    this.showVolumeCalculationPolygon = false;
    this.volumePanel.toggle();
  }

  drawAndCalculate() {
    this.drawVolumePolygonMode = true;

    this.draw.changeMode("draw_polygon");
    this.map.getCanvas().style.cursor = "crosshair";
    this.deactivateElevationClick();
    this.volumePanel.toggle();
  }

  cancelVolumeCalculation() {
    this.draw.changeMode("simple_select");
  }

  showVolumePolygons(volumePolygons: MapVolumeData[]) {
    for (let polygon of volumePolygons) {
      let description;
      // if (polygon.isSurfaceElevationRequest) {
      //   description = `<strong>${
      //     polygon.label
      //   }</strong><br /><strong>Cut Volume : </strong>${
      //     polygon.volume.cutVolume + " m<sup>3</sup>"
      //   }<br /><strong>Fill Volume : </strong>${
      //     polygon.volume.fillVolume + " m<sup>3</sup>"
      //   }<br /><strong>Effective Volume : </strong>${
      //     polygon.volume.totalVolume + " m<sup>3</sup>"
      //   }<br />`;
      // } else {
      //   description = `<strong>${
      //     polygon.label
      //   }</strong><br /><strong>Volume : </strong>${
      //     polygon.volume + " m<sup>3</sup>"
      //   }<br />`;
      // }
      let hoveredStateId = null;
      const popup = new mapboxgl.Popup({
        closeButton: false,
        closeOnClick: false,
      });
      const polygonId = polygon.volumeUniqueId;
      const mapLayer = this.map.getLayer(polygonId);
      if (!mapLayer && polygon.status == "completed") {
        const source = polygonId + "_source";
        this.map.addSource(source, {
          type: "geojson",
          data: {
            type: "FeatureCollection",
            features: [
              {
                type: "Feature",
                geometry: {
                  type: "Polygon",
                  coordinates: polygon.polygonGeojson.geometry.coordinates,
                },
                properties: {
                  polygon_label: polygon.label,
                  description: `<strong>${
                    polygon.label
                  }</strong><br /><strong>Volume : </strong>${
                    polygon.volume + " m<sup>3</sup>"
                  }<br />`,
                },
              },
            ],
          },
        });
        this.map.addLayer({
          id: polygonId,
          type: "fill",
          source: source,
          layout: {
            visibility: "visible",
          },
          paint: {
            "fill-color": "#CCE5FF",
            "fill-opacity": [
              "case",
              ["boolean", ["feature-state", "hover"], false],
              0.5,
              0.3,
            ],
          },
        });
        this.map.addLayer({
          id: polygonId + "_line",
          type: "line",
          source: source,
          layout: {
            visibility: "visible",
          },
          paint: {
            "line-color": "#CCE5FF",
            "line-width": 0.5,
          },
        });
        this.map.on("mousemove", polygonId, (e: any) => {
          if (e.features.length > 0) {
            this.map.getCanvas().style.cursor = "Pointer";
            if (hoveredStateId) {
              this.map.setFeatureState(
                { source: source, id: hoveredStateId },
                { hover: false }
              );
            }
            hoveredStateId = 1;
            this.map.setFeatureState(
              { source: source, id: hoveredStateId },
              { hover: true }
            );
            const description = e.features[0].properties.description;
            popup.setLngLat(e.lngLat).setHTML(description).addTo(this.map);
          }
        });

        // When the mouse leaves the state-fill layer, update the feature state of the
        // previously hovered feature.
        this.map.on("mouseleave", polygonId, () => {
          this.map.getCanvas().style.cursor = "";
          popup.remove();
          if (hoveredStateId) {
            this.map.setFeatureState(
              { source: source, id: hoveredStateId },
              { hover: false }
            );
          }
          hoveredStateId = null;
        });
      }
    }
  }

  volumePolygonOpacityControl(event: MatSliderChange, volume) {
    const polygonLayerId = volume.volumeUniqueId;
    const value = event.value;

    this.map.setPaintProperty(polygonLayerId, "fill-opacity", value / 100);
  }

  toggleLayerDisplay(polygon: MapVolumeData) {
    const polygonId = polygon.volumeUniqueId;
    const visibility = this.map.getLayoutProperty(polygonId, "visibility");
    if (visibility === "visible") {
      this.map.setLayoutProperty(polygonId, "visibility", "none");
      this.map.setLayoutProperty(polygonId + "_line", "visibility", "none");
    } else {
      this.map.setLayoutProperty(polygonId, "visibility", "visible");
      this.map.setLayoutProperty(polygonId + "_line", "visibility", "visible");
    }
  }

  deleteVolumeData(volume: MapVolumeData) {
    const message = this.ts.instant("dialog.messages.deleteVolumeCalculation");
    const successBtn = this.ts.instant("dialog.deleteBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.confirmAction"),
      message,
      successBtn,
      icon
    );
    this.confirmAlertComponentDialogRef = this.dialog.open(
      ConfirmAlertComponent,
      {
        maxWidth: "400px",
        data: dialogData,
      }
    );
    this.confirmAlertComponentDialogRef
      .afterClosed()
      .subscribe((dialogResult) => {
        this.deleteVolumeCalculationDialogResult = dialogResult;

        if (this.deleteVolumeCalculationDialogResult) {
          this.uiService.show();

          this.aerialTourService
            .deleteVolumeById(
              this.projectId,
              this.tourId,
              volume.volumeUniqueId
            )
            .subscribe(
              (data) => {
                if (
                  typeof this.map.getLayer(volume.volumeUniqueId) != "undefined"
                ) {
                  this.map
                    .removeLayer(volume.volumeUniqueId)
                    .removeLayer(volume.volumeUniqueId + "_line")
                    .removeSource(volume.volumeUniqueId + "_source");
                }
                this.getVolumeList();
                this.uiService.hide();
                const alert = this.ts.instant(
                  "exterior.mapbox.messages.volumeCalculationDeleteSuccess"
                );
                this.snackService.successSnackBar(alert);
              },
              (err) => {
                this.volumeList = [];
                this.uiService.hide();
                const alert = this.ts.instant(
                  "exterior.mapbox.messages.volumeCalculationDeleteFailure"
                );
                this.snackService.errorSnackBar(alert);
              }
            );
        }
      });
  }

  getVolumeList() {
    let pendingVolume: any;
    this.aerialTourService.getVolumeData(this.projectId, this.tourId).subscribe(
      (data) => {
        this.volumeList = data.volumeList;
        pendingVolume = this.volumeList.filter((d) => d.status !== "completed");
        if (pendingVolume && pendingVolume.length > 0) {
          this.getVolumeData();
        } else {
          if (this.volumeApiInterval) {
            clearInterval(this.volumeApiInterval);
          }
        }
        this.showVolumePolygons(this.volumeList);
        this.uiService.hide();
      },
      (err) => {
        this.volumeList = [];
        this.uiService.hide();
      }
    );
  }

  insertVolumeData(e: any) {
    let volumeData: MapVolumeData = {} as MapVolumeData;
    let alert = "";

    const data: any = this.draw.getAll();

    if (data && volumeData) {
      function isFeature(obj: turf.AllGeoJSON): obj is turf.Feature {
        return obj.type === "Feature";
      }

      turf.featureEach(
        data,
        (currentFeature: turf.AllGeoJSON, featureIndex: number) => {
          if (
            isFeature(currentFeature) &&
            currentFeature.geometry.type === "Polygon"
          ) {
            const polygonFeature = turf.polygon(
              currentFeature.geometry.coordinates as turf.Position[][]
            );
            const pointCollection = [];

            turf.coordEach(polygonFeature, (currentCoord) => {
              pointCollection.push(turf.point(currentCoord));
            });

            volumeData.polygonGeojson = polygonFeature;
            volumeData.pointGeojson = {
              type: "FeatureCollection",
              features: pointCollection,
            };
          }
        }
      );
      volumeData.tourId = this.tourId;
      volumeData.projectId = this.projectId;
      volumeData.label = this.generateUniqueVolumeLabel();
      this.draw.deleteAll();

      if (!this.volumeEscapeButtonClick) {
        this.showVolumeAnalysis(this.projectId, this.tourId, volumeData);
      }
      this.volumeEscapeButtonClick = false;
    }
  }

  showVolumeAnalysis(projectId, tourId, volumeData) {
    let result: any;
    const message = this.ts.instant("exterior.mapbox.messages.surfaceVolume");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    this.confirmDialogComponentDialogRef = this.dialog.open(
      ConfirmDialogComponent,
      {
        maxWidth: "400px",
        data: dialogData,
      }
    );

    this.confirmDialogComponentDialogRef
      .afterClosed()
      .subscribe((dialogResult) => {
        result = dialogResult;
        let alert = "";
        if (result) {
          this.surfaceVolumeComponentDialogRef = this.dialog.open(
            SurfaceVolumeComponent,
            {
              width: "40%",
              disableClose: true,
              data: "",
            }
          );

          this.surfaceVolumeComponentDialogRef
            .afterClosed()
            .subscribe((dialogResult) => {
              if (dialogResult) {
                const volumeParam = dialogResult;
                volumeData.isSurfaceElevationRequest = true;
                volumeData.surfaceElevation = volumeParam;
                this.calcVolume(projectId, tourId, volumeData);
              } else {
                this.activateElevationClick();
                this.volumePanel.toggle();
                this.map.getCanvas().style.cursor = "grab";
              }
            });
        } else {
          volumeData.isSurfaceElevationRequest = false;
          this.calcVolume(projectId, tourId, volumeData);
          this.map.getCanvas().style.cursor = "grab";
        }
      });
  }

  calcVolume(projectId, tourId, volumeData) {
    let alert;
    if (projectId && tourId && volumeData) {
      this.aerialTourService
        .saveVolumeData(this.projectId, this.tourId, volumeData)
        .subscribe(
          (data) => {
            alert = this.ts.instant(
              "exterior.mapbox.messages.requestSubmitted"
            );
            this.snackBarSvc.successSnackBar(alert);
            this.getVolumeList();
            this.activateElevationClick();
            this.map.getCanvas().style.cursor = "grab";
            this.volumePanel.toggle();
          },
          (err) => {
            alert = this.ts.instant("exterior.mapbox.messages.failedToSubmit");
            this.snackBarSvc.successSnackBar(alert);
          }
        );
    }
  }

  generateUniqueVolumeLabel() {
    if (!this.volumeList) {
      this.volumeList = [];
    }
    let maxIndex = 0;
    for (let volume of this.volumeList) {
      const index = parseInt(volume.label.substr(1));
      if (index > maxIndex) {
        maxIndex = index;
      }
    }

    return `V${maxIndex + 1}`;
  }

  getVolumeData() {
    //clear any previously running instance
    if (this.volumeApiInterval) {
      clearInterval(this.volumeApiInterval);
    }
    this.volumeApiInterval = setInterval(() => {
      this.getVolumeList();
    }, 20000); // call after 20 sec
  }

  changeTour(e) {
    this.uiService.show();
    this.tourType = e;
    setTimeout(() => {
      this.uiService.hide();
    }, 3000);
  }

  //elevation profile

  openElevationProfilePanel() {
    this.showElevationLine = !this.showElevationLine;
    if (this.showElevationLine) {
      this.map.setMaxZoom(19);
    }
    if (this.showElevationLine) {
      this.showElevationTool = true;
      this.uiService.show();
      this.getElevationList();
      this.elevationPanel.toggle();
    } else {
      this.closeElevationTool();
      this.map.setMaxZoom(22);
    }
  }

  closeElevationTool() {
    this.showElevationTool = false;
    this.drawElevationLineMode = false;
    this.cancelElevationCalculation();
    this.map.setMaxZoom(22);
    this.removeAllMarkers();
    if (this.volumeApiInterval) {
      clearInterval(this.volumeApiInterval);
    }
    for (let line of this.elevationList) {
      if (
        typeof this.map.getLayer(line.elevationProfileUniqueId) != "undefined"
      ) {
        this.map
          .removeLayer(line.elevationProfileUniqueId)
          .removeSource(line.elevationProfileUniqueId + "_source");
      }
    }
    this.elevationList = [];
    this.showElevationLine = false;
    this.elevationPanel.toggle();
  }

  convertToCSV(objArray, headerList) {
    let array = objArray;
    let str = "";
    let row = "S.No,";
    for (let index in headerList) {
      row += headerList[index] + ",";
    }
    row = row.slice(0, -1);
    str += row + "\r\n";
    for (let i = 0; i < array.length; i++) {
      let line = i + 1 + "";
      for (let index in headerList) {
        let head = headerList[index];
        line += "," + array[i][head];
      }
      str += line + "\r\n";
    }
    return str;
  }

  downloadChartDataCSV(elevation, filename = "Elevation Data") {
    filename = elevation.label + " " + filename;
    let csvData = this.convertToCSV(elevation.elevProfileChartInfo, [
      "latitude",
      "longitude",
      "distance",
      "elevation",
    ]);
    let blob = new Blob(["\ufeff" + csvData], {
      type: "text/csv;charset=utf-8;",
    });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      //if Safari open in new window to save file with random filename.
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  downloadAnnotationDataCSV(annotationArray, filename = "Annotations Data") {
    for (let annotation of annotationArray) {
      const newAnnotationArea = annotation.area.replace("sq m", "");
      annotation["area (sq m)"] = newAnnotationArea;

      const newAnnotationPerimeter = annotation.perimeter.replace("m", "");
      annotation["perimeter (m)"] = newAnnotationPerimeter;
    }

    const anntttpes = this.tour.annotationTypes;

    for (let annotation of annotationArray) {
      const annotationType = anntttpes.find((type) => {
        return type.key.toLowerCase() === annotation.polygon_color;
      });

      if (annotationType) {
        annotation["annotation Type"] = annotationType.value;
      }
    }

    let csvData = this.convertToCSV(annotationArray, [
      "polygon_label",
      "area (sq m)",
      "perimeter (m)",
      "annotation Type",
    ]);
    let blob = new Blob(["\ufeff" + csvData], {
      type: "text/csv;charset=utf-8;",
    });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      //if Safari open in new window to save file with random filename.
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  downloadVolumeCSVDataAllPolygons(filename = "Tour Volume Data") {
    const volumeDataArray = this.volumeList;

    for (let item of volumeDataArray) {
      if (item.isSurfaceElevationRequest) {
        const volumeSplit = item.volume.split("|");

        const volumeCut = volumeSplit[0].trim().replace("Cut:", "");
        const volumeFill = volumeSplit[1].trim().replace("Fill:", "");
        const totalVolume = volumeSplit[2].trim().replace("Total:", "");

        item["Cut (m3)"] = volumeCut;
        item["Fill (m3)"] = volumeFill;
        item["Volume (m3)"] = totalVolume;
      } else {
        item["Cut (m3)"] = 0;
        item["Fill (m3)"] = 0;
        item["Volume (m3)"] = item.volume;
        item["surfaceElevation"] = "Not Set";
      }
    }

    let csvData = this.convertToCSV(volumeDataArray, [
      "label",
      "surfaceElevation",
      "Cut (m3)",
      "Fill (m3)",
      "Volume (m3)",
    ]);
    let blob = new Blob(["\ufeff" + csvData], {
      type: "text/csv;charset=utf-8;",
    });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      //if Safari open in new window to save file with random filename.
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  downloadVolumeCsvData(volume, filename = "Polygon Volume Data") {
    const volumeDataArray = [];
    volumeDataArray.push(volume);

    volumeDataArray.forEach((item) => {
      if (item.isSurfaceElevationRequest) {
        const volumeSplit = item.volume.split("|");

        const volumeCut = volumeSplit[0].replace("Cut:", "");
        const volumeFill = volumeSplit[1].replace("Fill:", "");
        const totalVolume = volumeSplit[2].replace("Total:", "");

        item["Cut (m3)"] = volumeCut;
        item["Fill (m3)"] = volumeFill;
        item["Volume (m3)"] = totalVolume;
      } else {
        item["Cut (m3)"] = 0;
        item["Fill (m3)"] = 0;
        item["Volume (m3)"] = item.volume;
        item["surfaceElevation"] = "Not Set";
      }
    });

    let csvData = this.convertToCSV(volumeDataArray, [
      "label",
      "surfaceElevation",
      "Cut (m3)",
      "Fill (m3)",
      "Volume (m3)",
    ]);
    let blob = new Blob(["\ufeff" + csvData], {
      type: "text/csv;charset=utf-8;",
    });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      //if Safari open in new window to save file with random filename.
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  drawAndGetElevation() {
    this.drawElevationLineMode = true;

    this.draw.changeMode("draw_line_string");
    this.map.getCanvas().style.cursor = "crosshair";
    this.deactivateElevationClick();
    this.elevationPanel.toggle();
    let pointA: turf.Coord;
    let popup: mapboxgl.Popup;
    const mousemoveHandler = (e) => {
      const pointB: turf.Coord = turf.point([e.lngLat.lng, e.lngLat.lat]);
      const distance = turf.distance(pointA, pointB, {
        units: this.unitOfCalculation,
      });
      popup?.remove();
      popup = new mapboxgl.Popup()
        .setLngLat(e.lngLat)
        .setHTML(
          `${distance.toFixed(2)} ${LengthUnitSymbol[this.unitOfCalculation]}`
        );
      popup?.addTo(this.map);
    };
    const clickHandler = (e) => {
      pointA = turf.point([e.lngLat.lng, e.lngLat.lat]);
      this.map.on("mousemove", mousemoveHandler);
    };
    this.map.on("click", clickHandler);
    this.map.on("draw.create", (e) => {
      this.map.off("mousemove", mousemoveHandler);
      popup?.remove() && (popup = null);
      pointA = null;
      this.map.off("click", clickHandler);
    });
  }

  cancelElevationCalculation() {
    this.draw.changeMode("simple_select");
  }

  deleteElevationData(line: ElevationProfileData) {
    const message = this.ts.instant("dialog.messages.deleteElevationProfile");
    const successBtn = this.ts.instant("dialog.deleteBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.confirmAction"),
      message,
      successBtn,
      icon
    );
    this.confirmAlertComponentDialogRef = this.dialog.open(
      ConfirmAlertComponent,
      {
        maxWidth: "400px",
        data: dialogData,
      }
    );
    this.confirmAlertComponentDialogRef
      .afterClosed()
      .subscribe((dialogResult) => {
        this.uiService.show();

        this.deleteElevationProfileDialogResult = dialogResult;

        if (this.deleteElevationProfileDialogResult) {
          this.removeAllMarkers();
          this.aerialTourService
            .deleteElevationProfilesById(
              this.projectId,
              this.tourId,
              line.elevationProfileUniqueId
            )
            .subscribe(
              (data) => {
                if (
                  typeof this.map.getLayer(line.elevationProfileUniqueId) !=
                  "undefined"
                ) {
                  this.map
                    .removeLayer(line.elevationProfileUniqueId)
                    .removeSource(line.elevationProfileUniqueId + "_source");
                }
                this.getElevationList();
                this.uiService.hide();
                const alert = this.ts.instant(
                  "exterior.mapbox.messages.elevationProfileDeleteSuccess"
                );
                this.snackService.successSnackBar(alert);
              },
              (err) => {
                this.elevationList = [];
                this.uiService.hide();
                const alert = this.ts.instant(
                  "exterior.mapbox.messages.elevationProfileDeleteFailure"
                );
                this.snackService.errorSnackBar(alert);
              }
            );
        } else {
          this.uiService.hide();
        }
      });
  }

  toggleElevationLineLayerDisplay(elevation) {
    const lineId = elevation.elevationProfileUniqueId;

    const visibility = this.map.getLayoutProperty(lineId, "visibility");

    if (visibility === "visible") {
      this.map.setLayoutProperty(lineId, "visibility", "none");
      this.removeAllMarkers();
    } else {
      this.map.setLayoutProperty(lineId, "visibility", "visible");
    }
  }

  showElevationProfileLines(elevationLines: ElevationProfileData[]) {
    for (let line of elevationLines) {
      let hoveredStateId = null;
      const popup = new mapboxgl.Popup({
        closeButton: false,
        closeOnClick: false,
      });
      const lineId = line.elevationProfileUniqueId;
      const mapLayer = this.map.getLayer(lineId);
      if (!mapLayer && line.status == "completed") {
        this.map.addSource(line.elevationProfileUniqueId + "_source", {
          type: "geojson",
          data: {
            type: "FeatureCollection",
            features: [
              {
                type: "Feature",
                geometry: {
                  type: "LineString",
                  coordinates: line.lineString.features[0].geometry.coordinates,
                },
                properties: {
                  polygon_label: line.label,
                  description: `<strong>${
                    line.label
                  }</strong><br /><strong>Interval : </strong>${
                    parseFloat(line.resolution) *
                    LengthMultiplicationFactor[this.unitOfCalculation]
                  } ${LengthUnitSymbol[this.unitOfCalculation]}<br />`,
                },
              },
            ],
          },
        });
        this.map.addLayer({
          id: lineId,
          type: "line",
          source: lineId + "_source",
          layout: {
            "line-join": "round",
            "line-cap": "round",
            visibility: "visible",
          },
          paint: {
            "line-color": "#633974",
            "line-width": 4,
          },
        });
        this.map.on("mousemove", lineId, (e: any) => {
          if (e.features.length > 0) {
            this.map.getCanvas().style.cursor = "Pointer";
            if (hoveredStateId) {
              this.map.setFeatureState(
                { source: lineId + "_source", id: hoveredStateId },
                { hover: false }
              );
            }
            hoveredStateId = lineId;
            this.map.setFeatureState(
              { source: lineId + "_source", id: hoveredStateId },
              { hover: true }
            );
            const description = e.features[0].properties.description;
            popup.setLngLat(e.lngLat).setHTML(description).addTo(this.map);
          }
        });

        // When the mouse leaves the state-fill layer, update the feature state of the
        // previously hovered feature.
        this.map.on("mouseleave", lineId, () => {
          this.map.getCanvas().style.cursor = "";
          popup.remove();
          if (hoveredStateId) {
            this.map.setFeatureState(
              { source: lineId + "_source", id: hoveredStateId },
              { hover: false }
            );
          }
          hoveredStateId = null;
        });
      }
    }
  }

  componentToHex(c) {
    const hex = c.toString(16);
    return hex.length == 1 ? "0" + hex : hex;
  }

  rgbToHex(r, g, b) {
    return (
      "#" +
      this.componentToHex(r) +
      this.componentToHex(g) +
      this.componentToHex(b)
    );
  }

  extractRGB(data) {
    const r = parseInt(data.split(":")[0]);
    const g = parseInt(data.split(":")[1]);
    const b = parseInt(data.split(":")[2]);
    return this.rgbToHex(r, g, b);
  }

  getElevationList() {
    let pendingElevation: any;
    this.aerialTourService
      .getElevationProfileData(this.projectId, this.tourId)
      .subscribe(
        (data) => {
          this.elevationList = data.elevationProfileList;

          this.elevationList.forEach((element) => {
            let data =
              element.status === "completed"
                ? element.elevProfileChartInfo.map((data) =>
                    parseFloat(data.elevation)
                  )
                : [];

            element.lineChartData = [{ data: data, label: "Elevation(m)" }];

            element.lineChartLabels =
              element.status === "completed"
                ? element.elevProfileChartInfo.map((data) =>
                    parseInt(data.distance)
                  )
                : [];
          });

          pendingElevation = this.elevationList.filter(
            (d) => d.status !== "completed"
          );
          if (pendingElevation && pendingElevation.length > 0) {
            this.getElevationData();
          } else {
            if (this.volumeApiInterval) {
              clearInterval(this.volumeApiInterval);
            }
          }
          this.showElevationProfileLines(this.elevationList);
          this.uiService.hide();
        },
        (err) => {
          this.elevationList = [];
          this.uiService.hide();
        }
      );
  }

  generateUniqueElevationProfileLabel() {
    if (!this.elevationList) {
      this.elevationList = [];
    }
    let maxIndex = 0;
    for (let elevationProfile of this.elevationList) {
      const index = parseInt(elevationProfile.label.substr(3));
      if (index > maxIndex) {
        maxIndex = index;
      }
    }

    return `EP-${maxIndex + 1}`;
  }

  insertElevationData(e: any) {
    let elevationProfileData: ElevationProfileData = {} as ElevationProfileData;
    let alert = "";

    const data: any = this.draw.getAll();
    if (data) {
      elevationProfileData.lineString = data;
      elevationProfileData.tourId = this.tourId;
      elevationProfileData.projectId = this.projectId;
      elevationProfileData.label = this.generateUniqueElevationProfileLabel();
      this.draw.deleteAll();

      if (!this.elevationEscapeButtonClick) {
        this.showElevationAnalysis(
          this.projectId,
          this.tourId,
          elevationProfileData
        );
      }
      this.elevationEscapeButtonClick = false;
    }
  }

  showElevationAnalysis(
    projectId,
    tourId,
    elevationData: ElevationProfileData
  ) {
    this.surfaceElevationComponentDialogRef = this.dialog.open(
      SurfaceElevationComponent,
      {
        width: "40%",
        disableClose: true,
        data: "",
      }
    );

    this.surfaceElevationComponentDialogRef
      .afterClosed()
      .subscribe((dialogResult) => {
        if (dialogResult) {
          const resolution = dialogResult;
          elevationData.resolution = resolution;
          this.calcElevation(projectId, tourId, elevationData);
          this.activateElevationClick();
        } else {
          this.activateElevationClick();
          this.elevationPanel.toggle();
          this.map.getCanvas().style.cursor = "grab";
        }
      });
  }

  calcElevation(projectId, tourId, elevationData) {
    let alert;
    if (projectId && tourId && elevationData) {
      this.aerialTourService
        .saveElevationProfileData(this.projectId, this.tourId, elevationData)
        .subscribe(
          (data) => {
            alert = this.ts.instant(
              "exterior.mapbox.messages.requestSubmitted"
            );
            this.snackBarSvc.successSnackBar(alert);
            this.elevationPanel.toggle();

            this.getElevationList();
            this.map.getCanvas().style.cursor = "grab";
          },
          (err) => {
            alert = this.ts.instant("exterior.mapbox.messages.failedToSubmit");
            this.snackBarSvc.successSnackBar(alert);
          }
        );
    }
  }

  getElevationData() {
    //clear any previously runing instance
    if (this.volumeApiInterval) {
      clearInterval(this.volumeApiInterval);
    }
    this.volumeApiInterval = setInterval(() => {
      this.getElevationList();
    }, 20000); // call after 20 sec
  }

  ngOnDestroy() {
    if (this.volumeApiInterval) {
      clearInterval(this.volumeApiInterval);
    }

    this.closeDialogs();
  }

  removeAllMarkers() {
    if (this.currentMarkers !== null) {
      for (let i = this.currentMarkers.length - 1; i >= 0; i--) {
        this.currentMarkers[i].remove();
      }
    }
    this.currentMarkers = [];
  }

  onChartHover({ elements, elevation }: ChartHoveredData) {
    if (elements?.length > 0) {
      this.removeAllMarkers();
      const dataX = elements[0].index;
      const lnglat = elevation.elevProfileChartInfo.find(
        (ele) => dataX === parseInt(ele.distance)
      );
      if (lnglat) {
        const el = document.createElement("div");
        el.className = "marker";
        // tmp marker
        var oneMarker = new mapboxgl.Marker()
          .setLngLat({ lat: lnglat.latitude, lng: lnglat.longitude })
          .addTo(this.map);

        // save tmp marker into currentMarkers
        this.currentMarkers.push(oneMarker);
      }
    } else {
      this.removeAllMarkers();
    }
  }

  generateShareLink() {
    const shareInfo: any = {
      clientId: this.localStorage.getClientId(),
      projectId: this.tour.projectId,
      tourId: this.tourId,
    };
    this.projectSvc
      .generateShareLink("exterior", this.tourId, shareInfo)
      .subscribe(
        (data: any) => {
          this.isOpen = true;
          const share = data.share;
          this.shareLink = eval("`" + this.config.shareUrl + "`");
        },
        (error) => {
          this.errors = error;
        }
      );
  }
  copyShareLink() {
    if (!!this.shareLink) {
      this.clipboard.copy(this.shareLink);
      this.snackService.successSnackBar(
        this.ts.instant("general.messages.copyLink")
      );
    }
  }

  getElevationTitle(elevation: ElevationProfileData) {
    const totalLength = this.calculateDistances([
      ...elevation.lineString.features[0].geometry.coordinates,
    ]);
    return `${elevation.label} | Interval : ${
      parseFloat(elevation?.resolution) *
      LengthMultiplicationFactor[this.unitOfCalculation]
    } ${
      LengthUnitSymbol[this.unitOfCalculation]
    } | Total Length : ${totalLength.toFixed(3)} ${
      LengthUnitSymbol[this.unitOfCalculation]
    }`;
  }

  calculateDistances(coords: any[]) {
    let totalDistance = 0;

    for (let i = 0; i < coords.length - 1; i++) {
      const from = turf.point(coords[i]);
      const to = turf.point(coords[i + 1]);
      const distance = turf.distance(from, to, {
        units: this.unitOfCalculation,
      });

      totalDistance += distance;
    }

    return totalDistance;
  }

  getVolumeUnits(volumeString: string) {
    if (volumeString) {
      if (volumeString.toLowerCase().includes("error")) return volumeString;
      if (!isNaN(+volumeString) && !isNaN(parseFloat(volumeString))) {
        return `${(
          parseFloat(volumeString) *
          VolumeMultiplicationFactor[this.unitOfCalculation]
        ).toFixed(10)}`;
      }
      const [
        [cutLabel, curVol],
        [filterLabel, fillVol],
        [totalLabel, totalVol],
      ] = volumeString
        .split("|")
        .map((section) => section.trim().split(":"))
        .map((el) => {
          return [el[0].trim(), el[1].trim()];
        });
      return `${cutLabel}: ${
        parseFloat(curVol) *
        VolumeMultiplicationFactor[this.unitOfCalculation].toFixed(10)
      } | ${filterLabel}: ${
        parseFloat(fillVol) *
        VolumeMultiplicationFactor[this.unitOfCalculation].toFixed(10)
      } | ${totalLabel}: ${
        parseFloat(totalVol) *
        VolumeMultiplicationFactor[this.unitOfCalculation].toFixed(10)
      }`;
    }
    return ``;
  }

  // onUpload(files) {
  //   let alert = "";
  //   if (files.length > 1) {
  //     alert = this.ts.instant(
  //       "exterior.mapbox.messages.requestSubmitted.uploadErrorFileCount"
  //     );
  //     this.snackBarSvc.errorSnackBar(alert);
  //     return;
  //   } else {
  //     this.overlayFile = files[0];
  //   }
  // }

  // uploadCADOverlayData() {
  //   let alert = "";

  //   if (!this.overlayFile) {
  //     alert = this.ts.instant("exterior.mapbox.messages.noFileSelected");
  //     this.snackBarSvc.errorSnackBar(alert);
  //     return;
  //   }

  //   const fileExtension = this.overlayFile.name.split(".").pop();
  //   const fileType = fileExtension === "tif" ? "tif" : "";
  //   try {
  //     this.cadFileName = this.overlayFile.name;
  //     this.overlayProgress = 0;

  //     if (!fileType) {
  //       alert = this.ts.instant("exterior.mapbox.messages.extensionNotAllowed");
  //       this.snackBarSvc.errorSnackBar(alert);
  //       return;
  //     }
  //     this.uiService.show();
  //     this.aerialTourService
  //       .uploadCustomLayers(
  //         this.projectId,
  //         this.tourId,
  //         fileType,
  //         this.overlayFile
  //       )
  //       .subscribe(
  //         (event) => {
  //           if (event.type === HttpEventType.UploadProgress) {
  //             this.overlayProgress = Math.round(
  //               (100 * event.loaded) / event.total
  //             );
  //             // if (this.overlayProgress === 100) {
  //             //   alert = this.ts.instant(
  //             //     "exterior.settings.messages.dataUploaded"
  //             //   );
  //             //   this.snackBarSvc.successSnackBar(alert);
  //             //   // this.isCADOverlay = true;
  //             // }
  //           } else if (event instanceof HttpResponse) {
  //             if (event.body.status === "success") {
  //               alert = this.ts.instant(
  //                 "exterior.mapbox.messages.uploadSuccess"
  //               );
  //               this.snackBarSvc.successSnackBar(alert);
  //             } else {
  //               alert = this.ts.instant(
  //                 "exterior.mapbox.messages.uploadFailed"
  //               );
  //               this.snackBarSvc.errorSnackBar(alert);
  //             }
  //             this.uiService.hide();
  //             this.isCADOverlay = false;
  //           }
  //         },
  //         (err) => {
  //           this.isCADOverlay = true;
  //           alert = this.ts.instant("exterior.mapbox.messages.uploadFailed");
  //           this.snackBarSvc.errorSnackBar(alert + JSON.stringify(err));
  //           this.uiService.hide();
  //         }
  //       );
  //   } catch (error) {
  //     this.isCADOverlay = false;
  //     alert = this.ts.instant(
  //       "exterior.mapbox.messages.requestSubmitted.uploadFailed"
  //     );
  //     this.snackBarSvc.errorSnackBar(alert);
  //   }
  // }
}

@Component({
  selector: "surface-volume",
  templateUrl: "./surface-volume.html",
  styleUrls: ["./mapbox.component.scss"],
})
export class SurfaceVolumeComponent {
  constructor(
    private ts: TranslateService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<SurfaceVolumeComponent>
  ) {}

  dismiss(): void {
    this.dialogRef.close();
  }

  saveVolume() {}
}

@Component({
  selector: "surface-elevation",
  templateUrl: "./surface-elevation.html",
  styleUrls: ["./mapbox.component.scss"],
})
export class SurfaceElevationComponent {
  constructor(
    private ts: TranslateService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<SurfaceElevationComponent>
  ) {}

  dismiss(): void {
    this.dialogRef.close();
  }

  saveVolume() {}
}
