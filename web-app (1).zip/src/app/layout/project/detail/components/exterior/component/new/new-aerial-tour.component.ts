import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  AerialTour,
  AerialTourDialogData,
  AerialTourService,
  UserService,
  User,
  UiService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import * as moment from "moment-timezone";

@Component({
  selector: "new-aerial-tour",
  templateUrl: "./new-aerial-tour.component.html",
  styleUrls: ["./new-aerial-tour.component.scss"],
})
export class NewAerialTourComponent implements OnInit {
  @ViewChild("tourForm") tourForm;
  public breakpoint: number;
  public tourName: string = "";
  public tourDate: Date = new Date();
  public addTourForm: UntypedFormGroup;
  formSubmitAttempt: boolean = false;
  tour: AerialTour = {} as AerialTour;
  errors = {};
  wasFormChanged = false;
  projectId: string;
  user: User;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: AerialTourDialogData,
    private tourService: AerialTourService,
    private snackService: SnackbarService,
    private usrService: UserService,
    private ts: TranslateService,
    private uiService: UiService
  ) {
    this.addTourForm = this.fb.group({
      tourId: null,
      tourName: [
        this.tourName,
        [
          Validators.required,
          Validators.pattern(
            /^[a-zA-ZÀ-ÿ0-9]+[a-zA-ZÀ-ÿ0-9+\-,:;=@&#|'<>^*()%!_\.\/\\ ]*$/
          ),
        ],
      ],
      tourDate: [this.tourDate, [Validators.required]],
      mapType: ["D"],
    });
  }

  public ngOnInit(): void {
    this.setInteriorDetails(this.data.tour);
    this.user = this.usrService.getCurrentUser();
  }

  get f() {
    return this.addTourForm.controls;
  }

  public onInteriorAdd(): void {
    this.formSubmitAttempt = true;
    this.markAsDirty(this.addTourForm);
    this.onSubmit();
  }

  setInteriorDetails(tour: AerialTour) {
    this.projectId = this.data.projectId;
    if (tour && tour.tourId) {
      this.addTourForm.patchValue({
        tourId: tour.tourId,
        tourName: tour.tourName,
        tourDate: tour.tourDate,
        mapType: tour.mapType ? tour.mapType : "D",
      });
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
    this.onReset();
  }

  //tslint:disable-next-line:no-any
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 2;
  }

  private markAsDirty(group: UntypedFormGroup): void {
    group.markAsDirty();
    for (const i in group.controls) {
      group.controls[i].markAsDirty();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  onSubmit() {
    this.submitRequest();
  }

  submitRequest() {
    let alert = "";
    this.formSubmitAttempt = true;

    if (this.addTourForm.valid) {
      this.updateTour(this.addTourForm.value);

      this.uiService.show();
      this.tourService.save(this.projectId, this.tour).subscribe(
        (data) => {
          alert = this.ts.instant("exterior.new.messages.detailsCreated");
          this.snackService.successSnackBar(alert);
          this.dialog.closeAll();
          this.onReset();
          this.uiService.hide();
        },
        (err) => {
          alert = this.ts.instant("exterior.new.messages.detailsSavefailed");
          this.errors = err;
          this.formSubmitAttempt = false;
          this.snackService.errorSnackBar(alert);
          this.dialog.closeAll();
          this.uiService.hide();
        }
      );
    }
  }

  isFutureDate(idate) {
    var today = new Date().setHours(0, 0, 0, 0);
    var tourDate = new Date(idate).setHours(0, 0, 0, 0);

    return tourDate - today >= 0;
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.tourForm.resetForm();
    this.addTourForm.reset();
  }

  updateTour(values: Object) {
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    this.tour.tourId = values["tourId"] ? values["tourId"] : "";
    this.tour.tourName = values["tourName"].trim();
    this.tour.tourDate = moment(values["tourDate"])
      .tz(timeZone)
      .utc()
      .toISOString();
    this.tour.mapType = values["mapType"];
    this.tour.isActive = true;
  }
}
