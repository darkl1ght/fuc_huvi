import { Component, OnInit, Inject, ChangeDetectorRef } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import {
  ClientService,
  ProjectService,
  UserService,
  User,
  StorageService,
  DashboardChart,
  Client,
  UiService,
  MasterDataService,
  AerialTourService,
  Guid,
  SnackbarService,
} from "src/app/core";
import jsPDF from "jspdf";
import "jspdf-autotable";

import html2canvas from "html2canvas";
import { catchError, finalize, map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { AppConstants as Constants } from "src/app/core";
import { MAT_DIALOG_DATA, MatDialog } from "@angular/material/dialog";
import { DatePipe } from "@angular/common";

import { throwError } from "rxjs/internal/observable/throwError";
import { forkJoin } from "rxjs";
import { ChartConfiguration, ChartType, Color } from "chart.js";
@Component({
  selector: "report",
  templateUrl: "./report.component.html",
  styleUrls: ["./report.component.scss"],
})
export class ReportComponent implements OnInit {
  downloadProgress: boolean = false;
  errors: any;
  user: User;
  projectId: string = "";
  projectName: string = "";
  tour: any = [];
  project: any = [];
  client: Client;
  source: any;
  thumbnailContainer: string;
  mediaContainer: string;
  readToken: string;
  mediaBlobUrl: string;
  projectCharts: DashboardChart[] = [];
  chartLegend: boolean = true;
  selfServeProjectCharts: DashboardChart[] = [];
  masterData: any;
  towerList = [];
  isProjectCall: boolean = true;
  barDefaultColor: any = "#9CCC65";

  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    hover: {
      intersect: true,
      mode: "x",
      axis: "x",
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
      x: {
        ticks: {
          autoSkip: true,
          callback: function (value, index) {
            return this.getLabelForValue(index).toString().slice(0, 28);
          },
        },
      },
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: (context) => {
            const {
              dataset,
              datasetIndex,
              dataIndex,
              parsed: { y },
            } = context;
            if (datasetIndex == 0) {
              return `${dataset.label}: ${y}%`;
            } else if (datasetIndex == 1) {
              // for actuals
              const modLabel = `${dataset.label}: ${y}% ${
                dataset["toolTip"] ? dataset["toolTip"][dataIndex] : ""
              }`;
              return modLabel.trim();
            }
          },
        },
      },
    },
  };

  public pieChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: "top",
      },
      colors: { enabled: true },
    },
    aspectRatio: 2,
  };

  public scatterChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      colors: { enabled: true },
      legend: {
        display: true,
        onClick: (click, legendItem, legend) => {
          const datasets = legend.legendItems.map((dataset, index) => {
            return dataset.text;
          });
          const index = datasets.indexOf(legendItem.text);
          if (legend.chart.isDatasetVisible(index)) {
            legend.chart.hide(index);
          } else {
            legend.chart.show(index);
          }
        },
        labels: {
          usePointStyle: true,
          generateLabels: (chart) => {
            let visibility = [];
            for (let i in chart.data.datasets) {
              if (chart.isDatasetVisible(parseInt(i))) {
                visibility.push(false);
              } else {
                visibility.push(true);
              }
            }
            let pointStyle = [];
            chart.data.datasets.forEach((dataset) => {
              pointStyle.push(dataset["pointStyle"]);
            });
            return chart.data.datasets.map((dataset, index) => ({
              text: dataset.label,
              fillStyle: dataset.backgroundColor as Color,
              strokeStyle: dataset.backgroundColor as Color,
              pointStyle: pointStyle[index],
              hidden: visibility[index],
            }));
          },
        },
      },
    },
  };

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    private masterDataSvc: MasterDataService,
    public dialog: MatDialog,
    private userService: UserService,
    private snackService: SnackbarService,
    private projectService: ProjectService,
    private ts: TranslateService,
    public datePipe: DatePipe,
    private clientService: ClientService,
    private storageSvc: StorageService,
    private aerialTourService: AerialTourService,
    private uiService: UiService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private ref: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.tour = this.data.tour;
    if (
      (this.tour.isSelfServe && this.tour.isWBSPublished) ||
      this.tour.charts.length == 0
    ) {
      this.masterDataSvc.getMasterData(this.tour.projectId).subscribe(
        (data) => {
          this.masterData = data.master;
          this.setMasterData(this.masterData);
        },
        (err) => {
          this.errors = err;
        }
      );
    } else {
      for (let tour of this.tour.charts) {
        for (let data of tour.chartData.datasets) {
          data.hoverBackgroundColor = data.backgroundColor;
          data.hoverBorderColor = data.borderColor;
        }
      }

      this.projectCharts = this.tour.charts;
      this.projectCharts.map((chart) => {
        // Handling scatter charts separately due to varying titles
        // on the x and y axis from labels in chartData,
        // requiring different scale options.
        if (chart.chartType === "scatter") {
          chart.chartOptions = JSON.parse(
            JSON.stringify(this.scatterChartOptions)
          );
          chart.chartOptions.scales = {
            y: {
              title: {
                text: chart.chartData.labels[1] || "y-title",
                display: true,
                font: {
                  size: 16,
                  weight: 400,
                },
              },
            },
            x: {
              title: {
                text: chart.chartData.labels[0] || "x-title",
                display: true,
                font: {
                  size: 16,
                  weight: 400,
                },
              },
              type: "linear",
              position: "bottom",
            },
          };
        }
        return chart.chartData.datasets.map((data) => {
          if (chart.chartType === "line" || chart.chartType === "bar") {
            data.hoverBackgroundColor = data.backgroundColor;
            data.hoverBorderColor = data.borderColor;
          }
          data.hoverOffset = 4;
        });
      });
    }
    this.projectId = this.data.projectId;
    this.user = this.userService.getCurrentUser();
    this.projectService.get(this.projectId).subscribe(
      (data) => {
        this.projectName = data.projectName;
        this.project = data;
        this.getClientData(data.clientId);
      },
      (err) => {}
    );

    this.thumbnailContainer = this.config.imageThumbnailContainer;
    this.mediaContainer = this.config.mediaContainer;
    this.mediaBlobUrl = this.config.mediaBlobUrl;
    this.getTokenAndData();
  }

  setMasterData(data) {
    this.selfServeProjectCharts = [];
    this.uiService.show();
    data.workLocation.forEach((location) => {
      if (!location.parentLocationId) {
        this.towerList.push(location);
        this.getChartsByTower(
          this.projectId,
          this.tour.tourId,
          location.locationId,
          location.level1,
          location.orderNo
        );
        if (this.isProjectCall) {
          this.getCharts(
            this.projectId,
            this.tour.tourId,
            location.locationId,
            0
          );
          this.isProjectCall = false;
        }
      }
    });
    this.uiService.hide();
  }

  getCharts(projectId, tourId, towerId, orderNo) {
    this.uiService.show();
    this.aerialTourService
      .getProgressChart(projectId, tourId, towerId)
      .subscribe(
        (response) => {
          let data = response.response;
          // this.isLoaded = true;
          let sCurve: DashboardChart = {} as DashboardChart;
          let sCurveData: ChartConfiguration["data"] = {
            labels: [],
            datasets: [
              {
                label: "",
                backgroundColor: "#42A5F5",
                borderColor: "#1E88E5",
                fill: false,
                data: [],
                pointHoverBackgroundColor: "#42A5F5",
                pointHoverBorderColor: "#1E88E5",
                pointBackgroundColor: "#42A5F5",
                pointBorderColor: "#1E88E5",
              },
              {
                label: "",
                backgroundColor: "#9CCC65",
                borderColor: "#7CB342",
                fill: false,
                data: [],
                pointHoverBackgroundColor: "#9CCC65",
                pointHoverBorderColor: "#7CB342",
                pointBackgroundColor: "#9CCC65",
                pointBorderColor: "#7CB342",
              },
            ],
          };
          if (data.sCurve && data.sCurve.labels.length > 0) {
            sCurve.chartName = this.ts.instant(
              "exterior.mapbox.labels.scurveLabel"
            );
            sCurve.chartType = "line";
            sCurve.chartId = Guid.newGuid();
            sCurve.chartTitle =
              this.ts.instant("exterior.mapbox.labels.scurveLabel") +
              " By Project";

            sCurveData.labels = data.sCurve.labels;
            sCurveData.datasets[0].label = this.ts.instant(
              "exterior.mapbox.labels.plannedLabel"
            );
            sCurveData.datasets[0].data = data.sCurve.planned;
            sCurveData.datasets[1].label = this.ts.instant(
              "exterior.mapbox.labels.actualLabel"
            );
            sCurveData.datasets[1].data = data.sCurve.actual;

            sCurve.data = sCurveData;
            sCurve.orderNo = orderNo;
            this.selfServeProjectCharts.push(sCurve);
          }
          this.sortChart();
          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }
  getChartsByTower(projectId, tourId, towerId, towerName, orderNo) {
    this.uiService.show();
    this.aerialTourService
      .getProgressChartByTower(projectId, tourId, towerId)
      .subscribe(
        (response) => {
          let data = response.response;
          // this.isLoaded = true;
          let sCurve: DashboardChart = {} as DashboardChart;
          let wbsChart: DashboardChart = {} as DashboardChart;
          let sCurveData: ChartConfiguration["data"] = {
            labels: [],
            datasets: [
              {
                label: "",
                backgroundColor: "#42A5F5",
                borderColor: "#1E88E5",
                fill: false,
                data: [],
                pointHoverBackgroundColor: "#42A5F5",
                pointHoverBorderColor: "#1E88E5",
                pointBackgroundColor: "#42A5F5",
                pointBorderColor: "#1E88E5",
              },
              {
                label: "",
                backgroundColor: "#9CCC65",
                borderColor: "#7CB342",
                fill: false,
                data: [],
                pointHoverBackgroundColor: "#9CCC65",
                pointHoverBorderColor: "#7CB342",
                pointBackgroundColor: "#9CCC65",
                pointBorderColor: "#7CB342",
              },
            ],
          };

          let bar = {
            labels: [],
            datasets: [
              {
                label: "",
                backgroundColor: "#42A5F5",
                borderColor: "#1E88E5",
                fill: false,
                data: [],
                hoverBackgroundColor: "#42A5F5",
                hoverBorderColor: "#1E88E5",
              },
              {
                label: "",
                backgroundColor: "#9CCC65",
                borderColor: "#7CB342",
                fill: false,
                data: [],
                toolTip: [],
                hoverBackgroundColor: "#9CCC65",
                hoverBorderColor: "#7CB342",
              },
            ],
          };
          if (data.sCurve && data.sCurve.labels.length > 0) {
            sCurve.chartName = this.ts.instant(
              "exterior.mapbox.labels.scurveLabel"
            );
            sCurve.chartType = "line";
            sCurve.chartId = Guid.newGuid();
            sCurve.chartTitle =
              this.ts.instant("exterior.mapbox.labels.scurveLabel") +
              " - " +
              towerName;
            sCurveData.labels = data.sCurve.labels;
            sCurveData.datasets[0].label = this.ts.instant(
              "exterior.mapbox.labels.plannedLabel"
            );
            sCurveData.datasets[0].data = data.sCurve.planned;
            sCurveData.datasets[1].label = this.ts.instant(
              "exterior.mapbox.labels.actualLabel"
            );
            sCurveData.datasets[1].data = data.sCurve.actual;

            sCurve.data = sCurveData;
            sCurve.orderNo = orderNo;
            this.selfServeProjectCharts.push(sCurve);
          }

          if (data.wbsChart && data.wbsChart.labels.length > 0) {
            wbsChart.chartName = this.ts.instant(
              "exterior.mapbox.labels.wbsLabel"
            );
            wbsChart.chartType = "bar";
            wbsChart.chartId = Guid.newGuid();
            wbsChart.chartTitle =
              this.ts.instant("exterior.mapbox.labels.wbsLabel") +
              " - " +
              towerName;
            bar.labels = data.wbsChart.labels;
            bar.datasets[0].label = this.ts.instant(
              "exterior.mapbox.labels.plannedLabel"
            );
            bar.datasets[0].data = data.wbsChart.planned;
            bar.datasets[1].label = this.ts.instant(
              "exterior.mapbox.labels.actualLabel"
            );

            bar.datasets[1].data = data.wbsChart.actual;

            bar.datasets[1].toolTip = data.wbsChart.toolTip;
            if (this.masterData?.performanceIndex?.exterior) {
              let colorData: any = [];
              bar.datasets[0].data.forEach((item: any, index: any) => {
                let diff = item - bar.datasets[1].data[index];
                if (
                  diff >=
                  this.masterData.performanceIndex.exterior.wbs.value.rangeVal
                ) {
                  colorData.push(
                    this.masterData.performanceIndex.exterior.wbs.color
                  );
                } else {
                  colorData.push(this.barDefaultColor);
                }
              });
              bar.datasets[1].backgroundColor = colorData;
            } else {
              let colorData: any = [];
              for (let dat of bar.datasets[1].data) {
                colorData.push(this.barDefaultColor);
              }
              bar.datasets[1].backgroundColor = colorData;
            }
            wbsChart.data = bar;
            wbsChart.orderNo = orderNo;
            this.selfServeProjectCharts.push(wbsChart);
          }
          this.sortChart();
          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }

  getChartOptions(chartType: ChartType): ChartConfiguration["options"] {
    let options: ChartConfiguration["options"];
    switch (chartType) {
      case "line":
      case "bar":
        options = this.barChartOptions;
        break;
      case "pie":
        options = this.pieChartOptions;
        break;
      case "scatter":
        options = this.scatterChartOptions;
        break;
    }

    return options;
  }

  sortChart() {
    this.selfServeProjectCharts.sort((a, b) => {
      if (a.orderNo == b.orderNo) {
        if (
          a.chartName.toLowerCase() ==
          this.ts.instant("exterior.mapbox.labels.scurveLabel").toLowerCase()
        ) {
          return -1;
        } else {
          return 1;
        }
      } else {
        return a.orderNo > b.orderNo ? 1 : -1;
      }
    });
  }

  async getTokenAndData() {
    await this.storageSvc.getReadToken(this.mediaContainer).subscribe(
      (data) => {
        this.readToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getClientData(clientId) {
    let clientDetailsObservable = this.clientService.getClient(clientId);
    this.source = forkJoin([clientDetailsObservable])
      .pipe(
        map((results) => {
          this.client = results[0].client;
        }),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  async generateReport() {
    let alert = "";
    try {
      this.uiService.show();
      this.downloadProgress = true;
      this.ref.detectChanges();
      const doc = new jsPDF("p", "mm", [297, 210], true);
      this.coverPage(doc);
      this.addCaptureDetail(doc);
      if (
        (this.tour.isSelfServe && this.tour.isWBSPublished) ||
        this.tour.charts.length == 0
      ) {
        await this.addSelfServeChartData(doc);
      } else {
        await this.addChartData(doc);
      }

      doc.save(this.tour.tourName + "_report.pdf");
      alert = this.ts.instant("activity.report.messages.successful");
      this.snackService.successSnackBar(alert);
      this.uiService.hide();
      this.downloadProgress = false;
    } catch (error) {
      this.downloadProgress = false;
      alert = this.ts.instant("activity.report.messages.failed");
      this.snackService.errorSnackBar(alert);
      this.uiService.hide();
    }
  }

  async coverPage(doc) {
    const latest_date = this.datePipe.transform(this.tour.tourDate);

    doc.addImage("assets/images/firstpage.png", "PNG", 0, 0, 210, 297);

    const clientLogo =
      this.mediaBlobUrl + this.client.blobContentId + "?" + this.readToken;
    try {
      const img = new Image();
      img.src = clientLogo;
      doc.addImage(img, "JPG", 90, 20, 30, 30, "", "FAST");
    } catch (err) {}

    doc.setLineWidth(1);
    doc.setDrawColor(41, 63, 112);

    doc.rect(90, 20, 30, 30, "S");
    const text = this.client.clientName.toUpperCase();

    doc.setFontSize(45);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(41, 63, 112);
    doc.text(text, 105, 90, null, null, "center");

    const projectName = this.projectName.toUpperCase();
    let fontSize = 0;
    if (this.projectName.length < 20) {
      fontSize = 45;
    } else {
      fontSize = 35;
    }
    doc.setFontSize(fontSize);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(41, 63, 112);
    doc.text(projectName, 105, 110, null, null, "center");

    const extext = Constants.aerialreport.exteriorReport;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(30);
    doc.setTextColor(41, 63, 112);
    doc.text(extext, 105, 125, null, null, "center");

    doc.setLineWidth(0.21);
    doc.setTextColor(41, 63, 112);
    doc.line(74, 132, 136, 132);

    const preparedOn = Constants.report.preparedOn;
    doc.setFontSize(20);
    doc.setTextColor(41, 63, 112);
    doc.text(118, 160, preparedOn);

    const generatedDate = this.datePipe.transform(new Date());
    doc.setFontSize(20);
    doc.setTextColor(41, 63, 112);
    doc.text(163, 160, generatedDate);

    const capDate = Constants.aerialreport.captureDate + latest_date;
    doc.setFontSize(20);
    doc.setTextColor(41, 63, 112);
    doc.text(100, 170, capDate);

    const str = Constants.report.projectVis;
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text(str, 105, 270, null, null, "center");

    const urlText = Constants.report.available + Constants.report.projectUrl;
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text(urlText, 105, 280, null, null, "center");
  }

  async addSelfServeChartData(doc) {
    for (let chart of this.selfServeProjectCharts) {
      var data = document.getElementById("" + chart.chartId);
      const pdf = await html2canvas(data).then((canvas) => {
        doc.addPage();

        doc.addImage("assets/images/pdfback.png", "PNG", 0, 0, 210, 297);

        const clientLogo =
          this.mediaBlobUrl + this.client.blobContentId + "?" + this.readToken;
        try {
          const img = new Image();
          img.src = clientLogo;
          doc.addImage(img, "JPG", 7, 7, 16, 16, "", "FAST");
        } catch (err) {}

        doc.addImage("assets/images/report-logo.png", "JPEG", 183, 7, 20, 17);

        const contentDataURL = canvas.toDataURL("image/png");

        let text = chart.chartTitle + " Progress";
        doc.setFontSize(16);
        doc.setTextColor(41, 63, 112);
        var lMargin = 105; //left margin in mm
        var rMargin = 105; //right margin in mm
        var pdfInMM = 210;
        var lines = doc.splitTextToSize(text, pdfInMM - lMargin - rMargin);
        if (text.length > 55) {
          var splitTitle = doc.splitTextToSize(text, 110);
          doc.text(40, 30, splitTitle);
        } else {
          doc.text(text, 105, 30, null, null, "center");
        }

        doc.setLineWidth(1.5);
        doc.setDrawColor(41, 63, 112);

        doc.rect(15, 50, 180, 100, "S");

        doc.addImage(contentDataURL, "PNG", 15, 50, 180, 100);
      });
      if (chart.chartType == "line") {
        let towerData = chart.chartTitle.split(" ").slice(3).join(" ");
        towerData = towerData.replace("-", "");
        let graphText =
          Constants.aerialreport.lineChartGraph +
          towerData +
          Constants.aerialreport.timeline;
        doc.setFontSize(10);
        doc.setTextColor(41, 63, 112);
        if (graphText.length > 90) {
          var splitTitle = doc.splitTextToSize(graphText, 110);
          doc.text(105, 160, splitTitle, "center");
        } else {
          doc.text(graphText, 105, 160, null, null, "center");
        }
        const capData =
          chart.data.labels[chart.data.datasets[1].data.length - 1];
        const capPreData =
          chart.data.labels[chart.data.datasets[1].data.length - 2];

        const head = [[towerData, capPreData, capData]];

        const actualData = chart.data.datasets[1].data;

        const plannedData = chart.data.datasets[0].data;
        const actDate = actualData[chart.data.datasets[1].data.length - 1];
        const actPreDate = actualData[chart.data.datasets[1].data.length - 2];
        const planDate = plannedData[chart.data.datasets[1].data.length - 1];
        const planPreDate = plannedData[chart.data.datasets[1].data.length - 2];
        const body = [
          [
            Constants.aerialreport.planned,
            planPreDate == undefined ? "-" : planPreDate + " %",
            planDate == undefined ? "-" : planDate + " %",
          ],
          [
            Constants.aerialreport.actual,
            actPreDate == undefined ? "-" : actPreDate + " %",
            actDate == undefined ? "-" : actDate + " %",
          ],
        ];

        doc.autoTable({
          head: head,
          body: body,
          startY: 165,
          margin: {
            left: 60,
          },
          columnStyles: {
            0: {
              cellWidth: 30,
            },
            1: {
              cellWidth: 30,
            },
            2: {
              cellWidth: 30,
            },
          },
        });
      }
    }
  }

  async addChartData(doc) {
    for (let chart of this.projectCharts) {
      var data = document.getElementById(chart.chartId);
      const pdf = await html2canvas(data).then((canvas) => {
        doc.addPage();

        doc.addImage("assets/images/pdfback.png", "PNG", 0, 0, 210, 297);

        const clientLogo =
          this.mediaBlobUrl + this.client.blobContentId + "?" + this.readToken;
        try {
          const img = new Image();
          img.src = clientLogo;
          doc.addImage(img, "JPG", 7, 7, 16, 16, "", "FAST");
        } catch (err) {}

        doc.addImage("assets/images/report-logo.png", "JPEG", 183, 7, 20, 17);

        const contentDataURL = canvas.toDataURL("image/png");
        let text = chart.chartTitle + " Progress";

        doc.setFontSize(16);
        doc.setTextColor(41, 63, 112);
        var lMargin = 40; //left margin in mm
        var rMargin = 40; //right margin in mm
        var pdfInMM = 210;
        var lines = doc.splitTextToSize(text, pdfInMM - lMargin - rMargin);
        if (text.length > 55) {
          doc.text(lMargin, 30, lines);
        } else {
          doc.text(text, 105, 30, null, null, "center");
        }

        // doc.text(lMargin, 30, lines);
        doc.setLineWidth(1.5);
        doc.setDrawColor(41, 63, 112);

        doc.rect(15, 50, 180, 100, "S");

        doc.addImage(contentDataURL, "PNG", 15, 50, 180, 100);
      });

      if (chart.chartType == "line") {
        let towerData = chart.chartTitle.split(" ").slice(3).join(" ");
        towerData = towerData.replace("-", "");
        let graphText =
          Constants.aerialreport.lineChartGraph +
          towerData +
          Constants.aerialreport.timeline;
        doc.setFontSize(10);
        doc.setTextColor(41, 63, 112);
        doc.text(graphText, 105, 160, null, null, "center");
        const capData =
          chart.chartData.labels[chart.chartData.datasets[0].data.length - 1];
        const capPreData =
          chart.chartData.labels[chart.chartData.datasets[0].data.length - 2];

        const head = [[towerData, capPreData, capData]];

        const actualData = chart.chartData.datasets[0].data;

        const plannedData = chart.chartData.datasets[1].data;
        const actDate = actualData[chart.chartData.datasets[0].data.length - 1];
        const actPreDate =
          actualData[chart.chartData.datasets[0].data.length - 2];
        const planDate =
          plannedData[chart.chartData.datasets[0].data.length - 1];
        const planPreDate =
          plannedData[chart.chartData.datasets[0].data.length - 2];
        const body = [
          [
            Constants.aerialreport.planned,
            planPreDate == undefined ? "-" : planPreDate + " %",
            planDate == undefined ? "-" : planDate + " %",
          ],
          [
            Constants.aerialreport.actual,
            actPreDate == undefined ? "-" : actPreDate + " %",
            actDate == undefined ? "-" : actDate + " %",
          ],
        ];

        doc.autoTable({
          head: head,
          body: body,
          startY: 165,
          margin: {
            left: 60,
          },
          columnStyles: {
            0: {
              columnWidth: 30,
            },
            1: {
              columnWidth: 30,
            },
            2: {
              columnWidth: 30,
            },
          },
        });
      }
    }
  }

  addCaptureDetail(doc) {
    const tourDate = this.datePipe.transform(this.tour.tourDate);
    doc.addPage();

    doc.addImage("assets/images/pdfback.png", "PNG", 0, 0, 210, 297);

    const clientLogo =
      this.mediaBlobUrl + this.client.blobContentId + "?" + this.readToken;
    try {
      const img = new Image();
      img.src = clientLogo;
      doc.addImage(img, "JPG", 7, 7, 16, 16, "", "FAST");
    } catch (err) {}

    doc.addImage("assets/images/report-logo.png", "JPEG", 183, 7, 20, 17);

    let text = Constants.aerialreport.exteriroData;
    doc.setFontSize(18);
    doc.setTextColor(41, 63, 112);

    doc.text(text, 105, 36, null, null, "center");

    doc.setLineWidth(0.21);
    doc.line(74, 38, 136, 38);

    doc.autoTable({
      body: [
        [Constants.aerialreport.location, this.project.location],
        [Constants.aerialreport.type, Constants.aerialreport.typeValue],
        [Constants.aerialreport.droneDateCapture, tourDate],
      ],
      startY: 45,
      tableLineColor: [45, 64, 89],
      tableLineWidth: 0.25,
      lineColor: [45, 64, 89],
      theme: "grid",
      columnStyles: {
        0: {
          cellWidth: 100,
        },
      },
    });
  }

  header(doc, headerText) {
    const fontSize = doc.getFontSize();
    doc.setFontSize(10);
    doc.setTextColor(40);

    doc.text(174, 8, headerText);
    doc.setLineCap(2);
    doc.setFontSize(fontSize);
  }

  async closeDialog(): Promise<void> {
    this.dialog.closeAll();
  }

  getDateString() {
    const date = new Date();
    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, "0");
    const day = `${date.getDate()}`.padStart(2, "0");
    return `${year}${month}${day}`;
  }

  private handleError(error: any) {
    return throwError(error);
  }
}
