import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { BlobServiceClient } from "@azure/storage-blob";
import { TranslateService } from "@ngx-translate/core";
import { Observable } from "rxjs/internal/Observable";
import { take, tap } from "rxjs/operators";
import {
  AerialTourDialogData,
  AerialTourService,
  Guid,
  IUploadProgress,
  StorageService,
  UiService,
  AerialImage,
  AerialTour,
  SnackbarService,
} from "src/app/core";

import * as EXIF from "src/app/core/ExifJs/ExifJs";
import { ExifData } from "src/app/core/models/exifdata.model";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { GoogleMap, MapInfoWindow } from "@angular/google-maps";
import { MatTableDataSource } from "@angular/material/table";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";

@Component({
  selector: "upload-data",
  templateUrl: "./upload-data.component.html",
  styleUrls: ["./upload-data.component.scss"],
})
export class UploadAerialTourDataComponent implements OnInit {
  @ViewChild(GoogleMap, { static: false }) map: GoogleMap;
  @ViewChild(MapInfoWindow, { static: false }) info: MapInfoWindow;
  displayedColumns: string[] = [
    "meta.fileName",
    "meta.dateTaken",
    "meta.createdByName",
  ];
  formSubmitAttempt: boolean = false;
  tour: AerialTour;
  tourId: string = "";
  errors = {};
  wasFormChanged = false;
  projectId: string;
  center: google.maps.LatLngLiteral = { lat: 20, lng: 78 };
  zoom = 15;
  uploadProgress$: Observable<IUploadProgress[]>;
  filesSelected = false;
  missingExif: number = 0;
  totalFilesLoaded: number = 0;
  accessToken: string;
  options: google.maps.MapOptions = {
    disableDoubleClickZoom: true,
    mapTypeId: "hybrid",
    maxZoom: 18,
    minZoom: 2,
    zoomControl: true,
    streetViewControl: false,
    mapTypeControl: false,
    fullscreenControl: false,
    zoomControlOptions: {
      position: google.maps.ControlPosition.RIGHT_BOTTOM,
    },
  };
  markers = [];
  infoContent = "";
  metadata: any;
  totalUpload: number = 0;
  progressCount: number = 0;

  dataSource: any;
  columnHeader: any;

  addOnBlur = false;
  selectable = true;
  removable = true;

  color = "primary";
  mode = "determinate";
  value = 50;

  uploadInProgress: boolean = false;
  progressInfos: any[] = [];

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: AerialTourDialogData,
    private uiService: UiService,
    private tourSvc: AerialTourService,
    private storageSvc: StorageService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  public ngOnInit(): void {
    this.getToken();
    this.tourId = this.data.tourId;
    this.projectId = this.data.projectId;
    this.tour = this.data.tour;
    this.getMetaData();
  }

  onFileChange(event: any): void {
    let alert = "";
    if (
      this.tour.status.code !== "AT10002" &&
      this.tour.status.code !== "AT10003"
    ) {
      this.totalFilesLoaded = 0;
      this.filesSelected = true;
      this.progressInfos = [];
      let i;
      for (i = 0; i < event.length; ++i) {
        const file = event[i];
        const extn = file.name.split(".").pop();
        if (!this.isImage(extn)) {
          this.uiService.hide();
          this.dialog.closeAll();
          alert = this.ts.instant(
            "exterior.upload.messages.extensionNotAllowed"
          );
          this.snackService.errorSnackBar(alert);
          break;
        }
      }
      if (i == event.length) this.uploadFiles(event);
    } else {
      alert = this.ts.instant("exterior.upload.messages.dataUploadError");
      this.snackService.errorSnackBar(alert);
    }
  }

  isImage(ext) {
    switch (ext.toLowerCase()) {
      case "jpg":
      case "jpeg":
      case "png":
        //etc
        return true;
    }
    return false;
  }

  async uploadFiles(files) {
    let alert;
    try {
      this.uploadInProgress = true;
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.accessToken
      );
      const containerClient = blobServiceClient.getContainerClient(
        this.config.aerialTourContainer
      );
      const promises = [];
      let totalLatSum = 0;
      let totalLngSum = 0;
      if (this.tour.lat && this.tour.lng) {
        totalLatSum = parseFloat(this.tour.lat) * this.tour.images.length;
        totalLngSum = parseFloat(this.tour.lng) * this.tour.images.length;
      }
      for (let index = 0; index < files.length; ++index) {
        const file = files[index];
        this.progressInfos[index] = { value: 0, fileName: file.name };
        const exif = await this.getFileExif(file);
        const blockBlobClient = containerClient.getBlockBlobClient(
          this.tourId + "/" + exif.blobRef
        );
        promises.push(
          blockBlobClient.uploadBrowserData(file, {
            blockSize: 4 * 1024 * 1024, // 4MB block size
            concurrency: 20, // 20 concurrency
            onProgress: (ev) => {
              this.progressInfos[index].value = Math.round(
                (100 * ev.loadedBytes) / file.size
              );
              if (ev.loadedBytes === file.size) {
                totalLatSum += parseFloat(exif.lat);
                totalLngSum += parseFloat(exif.lng);
                this.updateMetaData(exif);
                this.totalUpload = this.totalUpload + 1;
                this.progressCount = (this.totalUpload / files.length) * 100;
              }
            },
            blobHTTPHeaders: { blobContentType: file.type },
          })
        );
      }

      await Promise.all(promises);
      this.saveTourCenter(totalLatSum, totalLngSum, files);
    } catch (error) {
      alert = this.ts.instant("exterior.upload.messages.uploadFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  saveTourCenter(totalLatSum: number, totalLngSum: number, files: any) {
    let alert;
    const centerLat = totalLatSum / (files.length + this.tour.images.length);
    const centerLng = totalLngSum / (files.length + this.tour.images.length);
    this.tourSvc
      .saveTourCenter(centerLat, centerLng, this.tourId, this.projectId)
      .subscribe(
        (data) => {
          this.tour = data;
          alert = this.ts.instant("exterior.upload.messages.dataUploaded");
          this.snackService.successSnackBar(alert);
          this.uploadInProgress = false;
          this.resetUpload();
        },
        (err) => {
          alert = this.ts.instant("exterior.upload.messages.uploadFailed");
          this.snackService.errorSnackBar(alert);
        }
      );
  }

  getMetaData() {
    this.uiService.show();
    this.tourSvc
      .getImages(this.projectId, this.tourId)
      .pipe(
        take(1),
        tap(
          (data) => {
            this.metadata = data.images;
            this.dataSource = new MatTableDataSource(data.images);
            if (data["images"] && data["images"].length > 0) {
              this.center = {
                lat: Number(data["images"][0].meta.lat),
                lng: Number(data["images"][0].meta.lng),
              };
              data["images"].forEach((el) => {
                if (el.meta.lat && el.meta.lng) {
                  this.addMarker(el.meta.lat, el.meta.lng, el.imageName);
                }
              });
            }
            this.uiService.hide();
          },
          (error) => {
            this.uiService.hide();
          }
        )
      )
      .subscribe();
  }

  filterTags(array, filter) {
    return array.filter(function (item) {
      return item.toLowerCase().includes(filter.toLowerCase());
    });
  }

  getToken() {
    const container = this.config.aerialTourContainer;
    this.storageSvc.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  private updateMetaData(exif: ExifData) {
    const image: AerialImage = {} as AerialImage;
    image.imageId = exif.fileId;
    image.blobImageId = exif.blobRef;
    image.imageName = exif.fileName;
    image.meta = exif;

    this.tourSvc
      .saveImage(this.projectId, this.tourId, image)
      .subscribe((status) => {
        this.addMarker(exif.lat, exif.lng, exif.fileName);
      });
  }

  async getFileExif(file) {
    const exif: ExifData = {} as ExifData;
    const fileId = Guid.newGuid();

    const meta = await new Promise((resolve) =>
      EXIF.getData(file, function () {
        resolve(EXIF.getAllTags(this));
      })
    );

    const gpsLat = meta["GPSLatitude"];
    const gpsLng = meta["GPSLongitude"];
    const gpsAlt = meta["GPSAltitude"];
    const dateTaken = meta["DateTime"];
    const extn = file.name.split(".").pop();
    exif.blobRef = fileId + "." + extn;
    exif.fileId = fileId;

    exif.dateTaken = dateTaken;
    exif.fileName = file.name;

    if (gpsLat && gpsLat) {
      exif.lat = (
        (
          gpsLat[0].numerator +
          gpsLat[1].numerator / 60 +
          gpsLat[2].numerator / gpsLat[2].denominator / 3600
        ).toFixed(5) * (meta["GPSLatitudeRef"] === "S" ? -1 : 1)
      ).toString(10);
      exif.lng = (
        (
          gpsLng[0].numerator +
          gpsLng[1].numerator / 60 +
          gpsLng[2].numerator / gpsLng[2].denominator / 3600
        ).toFixed(5) * (meta["GPSLongitudeRef"] === "W" ? -1 : 1)
      ).toString(10);
      exif.alt = gpsAlt
        ? (gpsAlt.numerator / gpsAlt.denominator).toFixed(5)
        : "";
    }

    return exif;
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  addMarker(lat, lng, fileName) {
    this.markers.push({
      position: {
        lat: Number(lat),
        lng: Number(lng),
      },
      title: fileName,
      info: fileName,
      options: {
        icon: "assets/images/pin.png",
        animation: google.maps.Animation.DROP,
      },
    });
    this.center = {
      lat: Number(lat),
      lng: Number(lng),
    };
  }

  resetUpload() {
    this.totalUpload = 0;
    this.progressCount = 0;
  }

  tabClick(tab) {
    if (tab.index === 1) {
      this.getMetaData();
    }
  }

  deleteImageData() {
    const message = this.ts.instant(
      "exterior.upload.messages.deleteTourImages"
    );
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      if (dialogResult) {
        const deleteImageButton = document.getElementById("deleteImageData");
        deleteImageButton.innerHTML = this.ts.instant(
          "exterior.upload.labels.deletingImages"
        );

        this.tourSvc
          .deleteImageData(this.projectId, this.tourId)
          .subscribe((data) => {
            deleteImageButton.innerHTML = this.ts.instant(
              "exterior.upload.labels.deleteTourImages"
            );
            if (data) {
              let alert;
              alert = this.ts.instant(
                "exterior.upload.messages.imageDataDeleteSuccess"
              );
              this.snackService.successSnackBar(alert);
              this.dialog.closeAll();
            } else {
              let alert;
              alert = this.ts.instant(
                "exterior.upload.messages.imageDataDeleteFailure"
              );
              this.snackService.errorSnackBar(alert);
            }
          });
      }
    });
  }
}
