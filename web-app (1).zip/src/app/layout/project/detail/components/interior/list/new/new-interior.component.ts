import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  InteriorDialogData,
  InteriorTour,
  UserService,
  User,
  InteriorService,
  UiService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";

@Component({
  selector: "new-interior",
  templateUrl: "./new-interior.component.html",
  styleUrls: ["./new-interior.component.scss"],
})
export class NewInteriorComponent implements OnInit {
  @ViewChild("interiorForm") interiorForm;
  public breakpoint: number;
  public interiorName: string = "";
  public interiorDate: Date = new Date();
  public addInteriorForm: UntypedFormGroup;
  formSubmitAttempt: boolean = false;
  interior: InteriorTour = {} as InteriorTour;
  errors = {};
  wasFormChanged = false;
  projectId: string;
  user: User;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private interiorService: InteriorService,
    private snackService: SnackbarService,
    private usrService: UserService,
    private uiService: UiService,
    private ts: TranslateService
  ) {
    this.addInteriorForm = this.fb.group({
      interiorId: null,
      interiorName: [
        this.interiorName,
        [
          Validators.required,
          Validators.pattern(
            /^[a-zA-ZÀ-ÿ0-9]+[a-zA-ZÀ-ÿ0-9+\-,:;=@&#|'<>^*()%!_\.\/\\ ]*$/
          ),
        ],
      ],
      interiorDate: [this.interiorDate, [Validators.required]],
      mapType: ["D"],
    });
  }

  public ngOnInit(): void {
    this.setInteriorDetails(this.data.interior);
    this.user = this.usrService.getCurrentUser();
  }

  get f() {
    return this.addInteriorForm.controls;
  }

  public onInteriorAdd(): void {
    this.formSubmitAttempt = true;
    this.markAsDirty(this.addInteriorForm);
    this.onSubmit();
  }

  setInteriorDetails(interior: InteriorTour) {
    this.projectId = this.data.projectId;
    if (interior && interior.interiorId) {
      this.addInteriorForm.patchValue({
        interiorId: interior.interiorId,
        interiorName: interior.interiorName,
        interiorDate: interior.interiorDate,
      });
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
    this.onReset();
  }

  //tslint:disable-next-line:no-any
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 2;
  }

  private markAsDirty(group: UntypedFormGroup): void {
    group.markAsDirty();
    for (const i in group.controls) {
      group.controls[i].markAllAsTouched();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  onSubmit() {
    this.submitRequest();
  }

  confirmDialog(): void {
    let result;
    const message = this.ts.instant("interior.newInterior.messages.missingWBS");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      result = dialogResult;
      if (result) {
        this.submitRequest();
      }
    });
  }

  isValidDate() {
    if (this.user.isAdmin) return true;

    if (this.data.interior) {
      var newDate = new Date(this.interior.interiorDate).setHours(0, 0, 0, 0);
      var existingDate = new Date(this.data.interior.interiorDate).setHours(
        0,
        0,
        0,
        0
      );
      if (newDate !== existingDate)
        return this.isFutureDate(this.interior.interiorDate);
      return true;
    } else return this.isFutureDate(this.interior.interiorDate);
  }

  isFutureDate(idate) {
    var today = new Date().setHours(0, 0, 0, 0);
    var tourDate = new Date(idate).setHours(0, 0, 0, 0);
    return tourDate - today >= 0;
  }

  submitRequest() {
    let alert = "";
    this.formSubmitAttempt = true;

    if (this.addInteriorForm.valid) {
      this.uiService.show();
      this.updateInterior(this.addInteriorForm.value);
      if (this.isValidDate()) {
        this.interiorService.save(this.projectId, this.interior).subscribe(
          () => {
            let message = this.data.interior
              ? this.ts.instant("interior.newInterior.messages.interiorUpdated")
              : this.ts.instant(
                  "interior.newInterior.messages.interiorCreated"
                );

            this.snackService.successSnackBar(message);
            this.dialog.closeAll();
            this.onReset();
            this.uiService.hide();
          },
          (err) => {
            alert = this.ts.instant(
              "interior.newInterior.messages.interiorFailed"
            );
            this.errors = err;
            this.formSubmitAttempt = false;
            this.snackService.errorSnackBar(alert);
            this.dialog.closeAll();
            this.uiService.hide();
          }
        );
      } else {
        alert = this.ts.instant("interior.newInterior.messages.tourSavefailed");
        this.formSubmitAttempt = false;
        this.snackService.errorSnackBar(alert);
        this.uiService.hide();
      }
    }
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.interiorForm.resetForm();
    this.addInteriorForm.reset();
  }

  updateInterior(values: Object) {
    this.interior.interiorId = values["interiorId"] ? values["interiorId"] : "";
    this.interior.interiorName = values["interiorName"].trim();
    this.interior.interiorDate = values["interiorDate"];
    this.interior.mapType = values["mapType"];
    this.interior.isActive = true;
  }
}
