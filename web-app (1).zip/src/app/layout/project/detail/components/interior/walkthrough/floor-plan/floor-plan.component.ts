import { Component, OnInit, Inject, Input } from "@angular/core";
import {
  InteriorService,
  StorageService,
  TourImage,
  UiService,
} from "src/app/core";
import "leaflet";
import * as L from "leaflet";
import "leaflet-draw";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import domtoimage from "dom-to-image";
import { BlobServiceClient } from "@azure/storage-blob";
import { Output, EventEmitter } from "@angular/core";

@Component({
  selector: "floor-plan-annotation",
  templateUrl: "./floor-plan.component.html",
  styleUrls: ["./floor-plan.component.scss"],
})
export class FloorPlanAnnotationComponent implements OnInit {
  @Input() tour: any;
  @Input() currentImageId: string;
  @Output() uploadSuccessEvent = new EventEmitter<any>();
  @Output() getFloorPlanSnapshotFile = new EventEmitter<File>();
  floorPlan: L.Map;
  featureGroup: L.FeatureGroup;
  bounds: L.LatLngBounds;
  imageURL: string;
  imageOverlay: L.ImageOverlay;
  imageUrl: string;
  accessToken: string;
  errors: string;

  mediaToken: string;
  fileId: string;

  constructor(
    @Inject(APP_CONFIG) private config: AppConfig,
    private interiorService: InteriorService,
    private uiService: UiService,
    private storageSvc: StorageService
  ) {}

  ngOnInit(): void {
    this.uiService.show();
    this.getToken();
    this.fileId = this.uuidv4() + ".jpg";
    this.featureGroup = new L.FeatureGroup();
    this.featureGroup.setZIndex(0);
    this.getFloorPlanDetails(this.tour);
  }

  async getFloorPlanDetails(image: TourImage) {
    const container = this.config.floorPlanContainer;
    this.interiorService
      .getBlobToken(container, image.floorPlanBlobId)
      .subscribe(
        async (data) => {
          this.accessToken = data.sasToken.token;
          this.imageUrl = data.sasToken.uri;
          this.setFloorMap(image, this.imageUrl);
        },
        (err) => {
          this.errors = err;
          this.uiService.hide();
        }
      );
  }

  setFloorMap(tour: TourImage, imageUrl: string) {
    this.floorPlan = L.map("fpId", {
      crs: L.CRS.Simple,
      minZoom: -5,
      maxBoundsViscosity: 1,
    });

    const img = new Image();
    img.id = "mapImage";
    img.src = imageUrl;
    img.onload = () => {
      const w = img.width;
      const h = img.height;
      const bounds: any = [
        [-10, -10],
        [h, w],
      ];
      L.imageOverlay(imageUrl, bounds, { zIndex: 0 }).addTo(this.floorPlan);
      this.floorPlan.fitBounds(bounds);
      this.floorPlan.setMaxBounds(bounds);
      this.floorPlan.addLayer(this.featureGroup);
      this.uiService.hide();
    };

    this.floorPlan.addLayer(this.featureGroup);
    this.floorPlan.on("load", () => {
      const { geometry } = tour.features?.features.find(
        (feature) => feature.properties.imageId === this.currentImageId
      );
      this.floorPlan.flyTo(
        [geometry.coordinates[1], geometry.coordinates[0]],
        -2
      );
    });
    this.preLoadImageBinding(tour);
  }

  preLoadImageBinding(tour: TourImage) {
    const feature = tour.features?.features.find(
      (feature) => feature.properties.imageId === this.currentImageId
    );
    let markerIdToDisplay: string = this.currentImageId;

    this.addMarker(feature, markerIdToDisplay);
  }

  addMarker({ geometry }, markerId: string) {
    const icon = new L.Icon({
      iconUrl: "assets/images/pin.png",
      iconSize: [18, 24],
    });

    // set lat lng from the coordinates of marker
    let marker: L.Marker = L.marker(
      [geometry.coordinates[1], geometry.coordinates[0]],
      {
        icon: icon,
      }
    );
    marker.feature = {
      type: "Feature",
      properties: {
        imageName: markerId,
        imageId: markerId,
      },
      geometry: null,
      id: L.Util.stamp(marker),
    };

    marker.addTo(this.floorPlan);
  }

  public onSubmit() {
    this.uiService.show();
    if (this.floorPlan.getZoom() == -5) {
      this.downloadImage(2);
    } else {
      let isViewZoomedIn = false;
      this.floorPlan.setView([0, 0], -5);
      this.floorPlan.once("moveend zoomend", () => {
        if (!isViewZoomedIn) {
          this.downloadImage(2);
          isViewZoomedIn = true;
        }
      });
    }
  }

  downloadImage(sizeFactor) {
    this.floorPlan.zoomControl.remove();
    const node = document.getElementById("fpId");
    const props = {
      width: node.clientWidth * sizeFactor,
      height: node.clientHeight * sizeFactor,
      style: {
        transform: "scale(" + sizeFactor + ")",
        "transform-origin": "top left",
      },
    };

    domtoimage
      .toBlob(node, props)
      .then((file) => {
        let files = [file];
        this.uploadFiles(files, this.fileId);
      })
      .catch(() => {});
  }

  async uploadFiles(files, fileId: string) {
    const blobRef = fileId;

    try {
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.mediaToken
      );

      const containerClient = blobServiceClient.getContainerClient(
        this.config.mediaContainer
      );
      const promises = [];
      for (const file of files) {
        const blockBlobClient = containerClient.getBlockBlobClient(blobRef);
        promises.push(blockBlobClient.uploadBrowserData(file));
      }
      await Promise.all(promises);

      let features = {
        type: "FeatureCollection",
        features: this.tour.features.features.filter(
          (feature) => feature.properties.imageId === this.currentImageId
        ),
      };

      this.uploadSuccessEvent.emit({
        fileId,
        features,
      });
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
    }
  }

  getToken() {
    const container = this.config.mediaContainer;
    this.storageSvc.getToken(container).subscribe(
      (data) => {
        this.mediaToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
        this.uiService.hide();
      }
    );
  }

  uuidv4() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c == "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  public onSubmitFromFieldIssue() {
    // this.uiService.show();
    if (this.floorPlan.getZoom() == -5) {
      this.returnImage(1);
    } else {
      this.floorPlan.setView([0, 0], -5);
      this.floorPlan.once("moveend zoomend", () => {
        this.returnImage(1);
      });
    }
  }

  returnImage(sizeFactor: number) {
    this.floorPlan.zoomControl.remove();
    const node = document.getElementById("fpId");
    if (node) {
      const props = {
        width: node.clientWidth * sizeFactor,
        height: node.clientHeight * sizeFactor,
        style: {
          transform: "scale(" + sizeFactor + ")",
          "transform-origin": "top left",
        },
      };

      domtoimage
        .toBlob(node, props)
        .then((blob) => {
          this.getFloorPlanSnapshotFile.emit(
            new File([blob], this.uuidv4() + ".jpeg")
          );
        })
        .catch(() => {});
    } else {
      console.log("err in floorplan Annotation component");
    }
  }
}
