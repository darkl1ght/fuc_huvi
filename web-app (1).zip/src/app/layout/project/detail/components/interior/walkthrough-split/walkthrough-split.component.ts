import {
  Component,
  OnInit,
  Inject,
  HostListener,
  ViewChild,
  ElementRef,
} from "@angular/core";
import "leaflet";
import * as L from "leaflet";
import "leaflet-draw";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from "@angular/material/dialog";
import {
  TourImage,
  InteriorService,
  InteriorImage,
  UiService,
  InteriorTour,
  SnackbarService,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { DatePipe } from "@angular/common";
import { sortTourFeatures } from "../walkthrough/walkthrough-utils";
import {
  SimpleAlertComponent,
  SimpleAlertModel,
} from "src/app/layout/components/simple-alert/simple-alert.component";
import { TranslateService } from "@ngx-translate/core";
import moment from "moment";

const enum Status {
  OFF = 0,
  RESIZE = 1,
  MOVE = 2,
}

declare const pannellum: any;

@Component({
  selector: "walkthrough",
  templateUrl: "./walkthrough-split.component.html",
  styleUrls: ["./walkthrough-split.component.scss"],
})
export class WalkthroughSplitComponent implements OnInit {
  selectedImageHotSpotId: string;
  currentTour: TourImage;
  floorPlan360Images: InteriorImage[] = [];
  imageAccessToken: string;
  accessToken: string;
  projectId: string;

  mapTypeLeft: string = "LMap";
  mapTypeRight: string = "RMap";
  isVideoCaptureMode: boolean = false;

  // svg things
  svgHeight: number = 300;
  svgWidth: number = 300;
  tourList: TourImage[] = [];
  selectedTourId: string;

  //leaflet
  floorPlanMapLeft: L.Map;
  floorPlanMapRight: L.Map;
  featureGroupLeft: L.FeatureGroup;
  featureGroupRight: L.FeatureGroup;
  bounds: L.LatLngBounds;
  imageURL: string;
  imageOverlay: L.ImageOverlay;
  markerLayer: L.Layer;
  polyLineLayer: L.Layer;
  featureGroups: {
    id: string;
    featureGroup: L.FeatureGroup;
    lastVisitedImage: string;
  }[] = [];

  markersLeft: L.Marker[] = [];
  markersRight: L.Marker[] = [];

  localGeojsonData: any;
  prevMarker: L.Marker;
  firstFloorImage: boolean = false;
  lastVisitedImageId: string;
  selectedImageNumberLeft: number = 1;
  selectedImageNumberRight: number = 1;
  timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  // aframe-component
  image_id: string;
  selected_floor_images: any[] = [];
  errors: any;

  //progress bar
  showProgressBar: boolean = true;
  viewerLeft: any;
  viewerRight: any;
  sceneId: string;
  remark: string = "";
  remarkDialogRef: any;
  remarks = [];
  showAll: boolean = true;

  //tourList
  tourListData: TourImage[] = [];
  currentTourId: string = "";
  towerName: string = "";
  isInitlized: boolean = false;
  showDiscussion: boolean = false;
  remarkId: string = "";
  interiorId: string = "";
  towerId: string = "";
  //interior list

  interiorList: InteriorTour[] = [];
  interiorListHavingFloorTours: InteriorTour[] = [];
  selectedInterior: any;
  locationId: string;
  intIdToCompare: string;
  tourListtoCompare: TourImage[] = [];
  tourToCompare: TourImage;
  isEmptyTour: boolean = false;
  dateLeft: string;
  dateRight: string;

  isInteriorViewsLocked: boolean = true;
  rightYawOffset: number = 0;

  x = 0;
  y = 100;
  px = 0;
  py = 0;
  width = 350;
  height = 200;
  draggingCorner = false;
  resizer: Function;

  status: Status;
  fpOpacity: 0.4;
  snapshot: any;
  isPanoramaLoaded: boolean;
  isLastImage: boolean;

  simpleAlertRef: MatDialogRef<SimpleAlertComponent>;

  @ViewChild("secondarySplitView") splitScreenSecondaryView: ElementRef;
  isRightViewerBeingAdjusted: boolean = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    public dialog: MatDialog,
    @Inject(APP_CONFIG) private config: AppConfig,
    private interiorService: InteriorService,
    private uiService: UiService,
    public datepipe: DatePipe,
    private snackService: SnackbarService,
    private ts: TranslateService,
    public dialogRef: MatDialogRef<WalkthroughSplitComponent>
  ) {}

  ngOnInit() {
    this.projectId = this.data.projectId;
    this.towerName = this.data.towerName;
    this.tourListData = this.data.tourListData;
    this.towerId = this.data.towerId;
    this.currentTour = this.data.tour;
    this.currentTourId = this.currentTour.tourId;
    this.interiorId = this.currentTour.interiorId;
    this.locationId = this.currentTour.locationId;
    this.isVideoCaptureMode =
      this.currentTour.videoCaptureDetails !== undefined;

    this.getInteriorData();

    this.getTourData(this.currentTour, "view1");
    this.fpBlobContent(this.currentTour);
  }

  ngOnDestroy(): void {
    this.simpleAlertRef && this.simpleAlertRef.close();
  }

  getInteriorData() {
    this.uiService.show();
    this.interiorService.getAllInteriorTowers(this.projectId).subscribe(
      (data) => {
        this.interiorList = data.interiors;
        this.interiorList.sort((a, b) =>
          b.interiorDate.localeCompare(a.interiorDate)
        );
        this.selectedInterior = this.interiorList.find(
          (x) => x.interiorId === this.interiorId
        );
        this.filterInteriorList();
        this.uiService.hide();
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  filterInteriorList() {
    this.interiorListHavingFloorTours = this.interiorList.filter(
      (interior) =>
        interior.status.code === "VW10003" /* Ready for Visualization */ &&
        interior.floorWalkthough.find(
          (tower) =>
            tower.towerId === this.towerId &&
            tower.publishedCount > 0 &&
            tower.tours.find(
              (floorTour: any) =>
                floorTour.isActive &&
                floorTour.isPublished &&
                floorTour.locationId === this.locationId
            )
        )
    );

    const rightSideInterior = this.interiorListHavingFloorTours.find(
      (interior) =>
        interior.interiorId != this.interiorId &&
        interior.status.code === "VW10003" &&
        interior.floorWalkthough.find(
          (tower) =>
            tower.towerId === this.towerId &&
            tower.publishedCount > 0 &&
            tower.tours.find(
              (floorTour: any) =>
                floorTour.isActive &&
                floorTour.isPublished &&
                floorTour.locationId === this.locationId
            )
        ) &&
        moment
          .tz(interior.interiorDate, this.timeZone)
          .isBefore(
            moment.tz(this.selectedInterior.interiorDate, this.timeZone)
          )
    );
    if (rightSideInterior?.interiorId) {
      this.intIdToCompare = rightSideInterior.interiorId;
      this.getTourList(this.intIdToCompare);
    } else {
      this.intIdToCompare = this.interiorId;
      this.loadSecondViewPort(this.currentTour);
    }
  }

  loadFloorPlanLeft(tour: TourImage, blobUrl: string) {
    try {
      this.uiService.show();
      if (this.floorPlanMapLeft) {
        this.floorPlanMapLeft.remove();
      }

      this.floorPlanMapLeft = L.map("mapL", {
        crs: L.CRS.Simple,
        minZoom: -5,
        maxBoundsViscosity: 1,
      });

      if (
        this.featureGroupLeft &&
        this.floorPlanMapLeft.hasLayer(this.featureGroupLeft)
      ) {
        this.floorPlanMapLeft.removeLayer(this.featureGroupLeft);
      }

      if (tour.features) {
        // Sort the features by their image number
        let { features } = tour.features;
        tour.features.features = sortTourFeatures(features);

        this.featureGroupLeft = L.geoJSON(tour.features);
      }

      const imageUrl = blobUrl;
      const img = new Image();
      img.id = "mapImage";
      img.src = imageUrl;
      img.onload = () => {
        const w = img.width;
        const h = img.height;
        const bounds: any = [
          [-10, -10],
          [h, w],
        ];
        L.imageOverlay(imageUrl, bounds).addTo(this.floorPlanMapLeft);
        this.floorPlanMapLeft.fitBounds(bounds);
        this.floorPlanMapLeft.setMaxBounds(bounds);
        this.floorPlanMapLeft.addLayer(this.featureGroupLeft);
        this.uiService.hide();
      };

      const featureGroupCopy: L.FeatureGroup = this.featureGroupLeft;
      featureGroupCopy.eachLayer((layer: L.Marker) => {
        if (this.featureGroupLeft.hasLayer(layer)) {
          this.featureGroupLeft.removeLayer(layer);
        }
      });

      this.floorPlanMapLeft.addLayer(this.featureGroupLeft);
      this.preLoadImageBinding(tour, this.mapTypeLeft, this.featureGroupLeft);
    } catch (error) {
      this.uiService.hide();
    }
  }

  loadFloorPlanRight(tour: TourImage, blobUrl: string) {
    try {
      this.uiService.show();
      if (this.floorPlanMapRight) {
        this.floorPlanMapRight.remove();
      }

      this.floorPlanMapRight = L.map("mapR", {
        crs: L.CRS.Simple,
        minZoom: -5,
        maxBoundsViscosity: 1,
      });

      // Load the marker selected on the left viewer
      this.floorPlanMapRight.on("load", () => {
        if (this.selectedImageNumberLeft !== 1) {
          let marker: L.Marker = this.markersLeft.find(
            (marker) =>
              marker.feature.properties.imageNumber ===
              this.selectedImageNumberLeft
          );
          marker?.fireEvent("click");
        }
      });

      if (
        this.featureGroupRight &&
        this.floorPlanMapRight.hasLayer(this.featureGroupRight)
      ) {
        this.floorPlanMapRight.removeLayer(this.featureGroupRight);
      }

      if (tour.features) {
        // Sort the features by their image number
        let { features } = tour.features;
        tour.features.features = sortTourFeatures(features);

        this.featureGroupRight = L.geoJSON(tour.features);
      }

      const imageUrl = blobUrl;
      const img = new Image();
      img.id = "mapImage";
      img.src = imageUrl;
      img.onload = () => {
        const w = img.width;
        const h = img.height;
        const bounds: any = [
          [-10, -10],
          [h, w],
        ];
        L.imageOverlay(imageUrl, bounds).addTo(this.floorPlanMapRight);
        this.floorPlanMapRight.fitBounds(bounds);
        this.floorPlanMapRight.setMaxBounds(bounds);
        this.floorPlanMapRight.addLayer(this.featureGroupRight);
        this.uiService.hide();
      };

      const featureGroupCopy: L.FeatureGroup = this.featureGroupRight;
      featureGroupCopy.eachLayer((layer: L.Marker) => {
        if (this.featureGroupRight.hasLayer(layer)) {
          this.featureGroupRight.removeLayer(layer);
        }
      });

      this.floorPlanMapRight.addLayer(this.featureGroupRight);
      this.preLoadImageBinding(tour, this.mapTypeRight, this.featureGroupRight);
    } catch (error) {
      this.uiService.hide();
    }
  }

  getPathCoordinates(data: any) {
    let coordinates = [];
    for (let index in data._layers) {
      const x = data._layers[index]._latlng.lat;
      const y = data._layers[index]._latlng.lng;
      coordinates.push([x, y]);
    }

    return coordinates;
  }

  preLoadImageBinding(tour: TourImage, mapType: string, featureGroup) {
    const currFlrFeatGroup = tour.features
      ? L.geoJSON(tour.features)
      : undefined;
    let imageNumber: number = 0;

    if (currFlrFeatGroup) {
      currFlrFeatGroup.eachLayer((layer: L.Marker) => {
        const latlng: L.LatLng = layer.getLatLng();
        const marker: InteriorImage = {} as InteriorImage;
        marker.imageId = layer.feature.properties.imageId;
        marker.imageName = layer.feature.properties.imageName;
        marker.imageNumber = ++imageNumber;
        this.addMarker(featureGroup, mapType, latlng, marker);
      });

      // Fetch path coordinates and draw a line
      let pathCoordinates = this.getPathCoordinates(currFlrFeatGroup);
      this.polyLineLayer = L.polyline(pathCoordinates, {
        color: "#C0C0C0",
        weight: 5,
        opacity: 0.65,
      }).addTo(featureGroup);
    }
  }

  addMarker(
    featureGroup: any,
    mapType: string,
    latlng: L.LatLng,
    selectedImage: InteriorImage,
    markerLayer?: L.Layer
  ) {
    if (markerLayer) {
      featureGroup.removeLayer(markerLayer);
    }
    const marker: L.Marker = L.marker(latlng, {
      icon:
        selectedImage.imageNumber === 1
          ? this.getMarkerIcon(selectedImage.imageNumber, true)
          : this.getMarkerIcon(selectedImage.imageNumber, false),
      opacity: selectedImage.imageNumber === 1 ? 1 : 0.75,
    });

    marker.feature = {
      type: "Feature",
      properties: {
        imageName: selectedImage.imageName,
        imageId: selectedImage.imageId,
        imageNumber: selectedImage.imageNumber,
      },
      geometry: null,
      id: L.Util.stamp(marker),
    };

    if (
      this.lastVisitedImageId &&
      this.lastVisitedImageId === selectedImage.imageId
    ) {
      marker.setIcon(
        this.getMarkerIcon(marker.feature.properties.imageNumber, true)
      );
    }

    marker
      .on("mouseover", () => {
        if (
          (mapType === this.mapTypeLeft &&
            this.selectedImageNumberLeft !==
              marker.feature.properties.imageNumber) ||
          (mapType === this.mapTypeRight &&
            this.selectedImageNumberRight !==
              marker.feature.properties.imageNumber)
        ) {
          marker.setOpacity(1);
        }
      })
      .on("mouseout", () => {
        if (
          (mapType === this.mapTypeLeft &&
            this.selectedImageNumberLeft !==
              marker.feature.properties.imageNumber) ||
          (mapType === this.mapTypeRight &&
            this.selectedImageNumberRight !==
              marker.feature.properties.imageNumber)
        ) {
          marker.setOpacity(0.75);
        }
      })
      .on("click", () => {
        if (mapType === this.mapTypeLeft) {
          this.selectedImageNumberLeft = marker.feature.properties.imageNumber;
          // Check if the selected marker is the last image
          let { scenes } = this.viewerLeft.getConfig();
          Object.keys(scenes).length === this.selectedImageNumberLeft
            ? (this.isLastImage = true)
            : (this.isLastImage = false);

          this.showSelectedImageL(selectedImage);

          let { lat: markerLeftLat, lng: markerLeftLng } = marker.getLatLng();

          let markerRight = this.markersRight.find(
            (marker) =>
              marker.getLatLng().lat < markerLeftLat + 80 &&
              marker.getLatLng().lat > markerLeftLat - 80 &&
              marker.getLatLng().lng < markerLeftLng + 80 &&
              marker.getLatLng().lng > markerLeftLng - 80
          );

          if (!markerRight && this.isVideoCaptureMode) {
            const message = this.ts.instant(
              "dialog.messages.walkthroughImageNotFound"
            );
            const successBtn = this.ts.instant("dialog.okay");
            const icon = "warning";
            const dialogData = new SimpleAlertModel(
              this.ts.instant("dialog.noImageFound"),
              message,
              successBtn,
              icon,
              this.splitScreenSecondaryView
            );
            this.simpleAlertRef = this.dialog.open(SimpleAlertComponent, {
              maxWidth: "300px",
              data: dialogData,
            });
          }

          this.featureGroupRight.eachLayer((fgLayer: L.Marker) => {
            if (fgLayer !== this.polyLineLayer) {
              if (
                fgLayer &&
                fgLayer.feature &&
                fgLayer.feature.properties &&
                this.isVideoCaptureMode
              ) {
                if (
                  fgLayer.feature.properties.imageNumber ===
                  markerRight.feature.properties.imageNumber
                ) {
                  this.showSelectedImageR(fgLayer.feature.properties);
                  fgLayer.setIcon(
                    this.getMarkerIcon(
                      fgLayer.feature.properties.imageNumber,
                      true
                    )
                  );
                  fgLayer.setOpacity(1);
                } else {
                  fgLayer.setIcon(
                    this.getMarkerIcon(
                      fgLayer.feature.properties.imageNumber,
                      false
                    )
                  );
                  fgLayer.setOpacity(1);
                }
              }
              if (
                fgLayer &&
                fgLayer.feature &&
                fgLayer.feature.properties &&
                !this.isVideoCaptureMode
              ) {
                if (
                  fgLayer.feature.properties.imageNumber ===
                  selectedImage.imageNumber
                ) {
                  this.showSelectedImageR(fgLayer.feature.properties);
                  fgLayer.setIcon(
                    this.getMarkerIcon(
                      fgLayer.feature.properties.imageNumber,
                      true
                    )
                  );
                  fgLayer.setOpacity(1);
                } else {
                  fgLayer.setIcon(
                    this.getMarkerIcon(
                      fgLayer.feature.properties.imageNumber,
                      false
                    )
                  );
                  fgLayer.setOpacity(1);
                }
              }
            }
          });
        } else if (mapType === this.mapTypeRight) {
          this.selectedImageNumberRight = marker.feature.properties.imageNumber;
          this.showSelectedImageR(selectedImage);
        }

        featureGroup.eachLayer((fgLayer: L.Marker) => {
          // Re render layers other than the polyline layer
          if (fgLayer !== this.polyLineLayer) {
            if (fgLayer && fgLayer.feature && fgLayer.feature.properties) {
              fgLayer.setIcon(
                this.getMarkerIcon(
                  fgLayer.feature.properties.imageNumber,
                  false
                )
              );
              fgLayer.setOpacity(0.75);
            }
          }
        });

        marker.setIcon(
          this.getMarkerIcon(
            mapType === this.mapTypeLeft
              ? this.selectedImageNumberLeft
              : this.selectedImageNumberRight,
            true
          )
        );
        marker.setOpacity(1);
      })
      .addTo(featureGroup);

    mapType === this.mapTypeLeft
      ? this.markersLeft.push(marker)
      : this.markersRight.push(marker);
  }

  getMarkerIcon(imageNumber: number, isActiveImage: boolean) {
    if (isActiveImage) {
      return L.divIcon({
        className: "location-pin",
        html: `<div class="location-pin-container-compare"><img class="location-pin-image-active"><span class="location-pin-text-compare">${imageNumber}</span></div>`,
      });
    }
    return L.divIcon({
      className: "location-pin",
      html: `<div class="location-pin-container"><img class="location-pin-image"><span class="location-pin-text">${imageNumber}</span></div>`,
    });
  }

  showSelectedImageL(selectedImage: InteriorImage) {
    this.sceneId = selectedImage.imageId;
    this.viewerLeft.loadScene(
      selectedImage.imageId,
      "same",
      "sameAzimuth",
      "same"
    );
  }

  showSelectedImageR(selectedImage: InteriorImage) {
    this.sceneId = selectedImage.imageId;
    this.viewerRight.loadScene(
      selectedImage.imageId,
      "same",
      "sameAzimuth",
      "same"
    );
  }

  async getTourData(tour: TourImage, elementId: string) {
    const container = this.config.virtualTourContainer;
    await this.interiorService.getReadToken(container).subscribe(
      (data) => {
        this.imageAccessToken = data.sasToken.token;
        this.setBlobUrl(data.sasToken.token, tour, elementId);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  setBlobUrl(token, tour: TourImage, elementId: string) {
    this.floorPlan360Images = [];
    // Image Azure blob folder structure  = WALKTHROUGH-TOUR-ID > IMAGE
    tour.images.forEach((image) => {
      if (image) {
        image.imageBlobUrl =
          this.config.virtualTourBlobUrl +
          tour.tourId +
          "/" +
          image.blobImageId +
          "?" +
          token;
      }
    });

    if (elementId === "view1") {
      this.initializeViewer1(tour.images, elementId);
    } else if (elementId === "view2") {
      this.initializeViewer2(tour.images, elementId);
    }

    this.addViewerRotationListeners();
  }

  async fpBlobContent(tour: TourImage) {
    const container = this.config.floorPlanContainer;
    this.interiorService
      .getBlobToken(container, tour.floorPlanBlobId)
      .subscribe(
        async (data) => {
          const imageUrl = data.sasToken.uri;
          this.loadFloorPlanLeft(tour, imageUrl);
        },
        (err) => {
          this.errors = err;
        }
      );
  }

  closeDialog(): void {
    this.simpleAlertRef && this.simpleAlertRef.close();
    this.dialogRef.close();
  }

  changeInteriorView(e) {
    this.intIdToCompare = e.value;
    this.getTourList(e.value);
  }

  async getTourList(interiorId) {
    if (
      !this.interiorList.find(
        (interior) =>
          interior.interiorId === interiorId &&
          interior.status.code === "VW10003" /* Ready for Visualization */ &&
          interior.floorWalkthough.find(
            (tower) =>
              tower.towerId === this.towerId &&
              tower.publishedCount > 0 &&
              tower.tours.find(
                (floorTour: any) =>
                  floorTour.isActive &&
                  floorTour.isPublished &&
                  floorTour.locationId === this.locationId
              )
          )
      )
    ) {
      //Same flow as changeInteriorView()
      this.intIdToCompare = this.interiorId; //default to same interiorId
      this.snackService.warningSnackBar(
        this.ts.instant(
          "interior.virtualTour.messages.noComparisonFloorTourData"
        )
      );
    }

    this.uiService.show();

    this.interiorService
      .getTowersByInteriorId(this.projectId, this.intIdToCompare)
      .subscribe(
        (data) => {
          this.tourListtoCompare =
            data.tours && data.tours.length > 0 ? data.tours : [];

          this.markersRight = [];

          this.loadSecondView(
            this.tourListtoCompare,
            this.towerId,
            this.locationId
          );

          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }

  loadSecondView(tourListtoCompare, towerId, locationId) {
    let tour: TourImage;
    if (tourListtoCompare && tourListtoCompare.length > 0) {
      let tower = tourListtoCompare.find((x) => x.towerId === towerId);
      if (tower && tower.tours) {
        tour = tower.tours.find((x) => x.locationId === locationId);
      }
    }
    this.loadSecondViewPort(tour);
  }

  loadSecondViewPort(tour: TourImage) {
    if (tour && tour.isPublished) {
      this.isEmptyTour = false;
      this.tourToCompare = tour;
      this.isVideoCaptureMode = tour.videoCaptureDetails !== undefined;
      if (this.viewerRight) this.viewerRight.destroy();
      this.fpBlobContentRight(tour);
      this.getTourData(tour, "view2");
    } else {
      this.isEmptyTour = true;
    }
  }

  initializeViewer1(images: InteriorImage[], elementId) {
    //Reset the lock status
    this.isInteriorViewsLocked = true;

    this.viewerLeft = pannellum.viewer(elementId, {
      scenes: {},
      sceneFadeDuration: 1000,
      author: "Huviair",
      showControls: false,
    });

    this.viewerLeft.setYawBounds([0, 360]);

    images.forEach((image, index) => {
      let imageOffsetFromNorth = image.offsetFromNorth ?? 0;

      this.viewerLeft.addScene(image.imageId, {
        type: "equirectangular",
        panorama: image.imageBlobUrl,
        pitch: 2.3,
        yaw: index === 0 ? -imageOffsetFromNorth : 0,
        hfov: 120,
        hotSpots: [],
        northOffset: imageOffsetFromNorth,
      });
    });

    this.sceneId = images[0].imageId;
    this.viewerLeft.loadScene(this.sceneId);
    this.addViewer1Listener();

    // Handle viewer loading events
    this.viewerLeft.on("load", () => (this.isPanoramaLoaded = true));
    this.viewerLeft.on("error", () => (this.isPanoramaLoaded = false));

    this.viewerLeft.on("scenechange", () => {
      this.isPanoramaLoaded = false;
    });
  }

  initializeViewer2(images: InteriorImage[], elementId) {
    //Reset the lock status
    this.isInteriorViewsLocked = true;

    this.viewerRight = pannellum.viewer(elementId, {
      scenes: {},
      sceneFadeDuration: 1000,
      author: "Huviair",
      showControls: false,
    });

    images.forEach((image, index) => {
      let imageOffsetFromNorth = image.offsetFromNorth ?? 0;

      this.viewerRight.addScene(image.imageId, {
        type: "equirectangular",
        panorama: image.imageBlobUrl,
        pitch: 2.3,
        yaw: index === 0 ? -imageOffsetFromNorth : 0,
        hfov: 120,
        hotSpots: [],
        northOffset: imageOffsetFromNorth,
      });
    });

    this.sceneId = images[0].imageId;
    this.viewerRight.loadScene(this.sceneId);
    this.addViewer2Listener();
  }

  updateViewerRight = () => {
    if (this.viewerLeft) {
      this.rightYawOffset =
        this.viewerRight.getYaw() - this.viewerLeft.getYaw();
    }
  };

  toggleRotationLock() {
    // Toggle lock state
    this.isInteriorViewsLocked = !this.isInteriorViewsLocked;

    if (!this.isInteriorViewsLocked) {
      // Unlocked state: store the current yaw difference between the left and right viewers
      this.rightYawOffset =
        this.viewerRight.getYaw() - this.viewerLeft.getYaw();
      // Remove event listeners to prevent syncing while unlocked
      this.viewerLeft.off("panorama-orientation-changed");
      this.viewerRight.off("panorama-orientation-changed");

      // Add event listeners to allow user to update the right viewer
      this.viewerRight.on(
        "panorama-orientation-changed",
        this.updateViewerRight
      );
      return;
    }

    // Locked state: add event listeners to keep the viewers in sync while locked
    this.viewerLeft.on("panorama-orientation-changed", () => {
      if (this.viewerRight) {
        this.viewerRight.lookAt(
          this.viewerLeft.getPitch(),
          this.viewerLeft.getYaw() + this.rightYawOffset,
          this.viewerLeft.getHfov(),
          false
        );
      }
    });

    this.viewerRight.on("panorama-orientation-changed", () => {
      if (this.viewerLeft) {
        this.viewerLeft.lookAt(
          this.viewerRight.getPitch(),
          this.viewerRight.getYaw() - this.rightYawOffset,
          this.viewerRight.getHfov(),
          false
        );
      }
    });

    // Remove the event listener on the right viewer to prevent updating the yaw offset while locked
    this.viewerRight.off(
      "panorama-orientation-changed",
      this.updateViewerRight
    );
  }

  addViewerRotationListeners() {
    // Sync both viewers' orientation when view is locked
    this.viewerRight?.lookAt(
      this.viewerLeft?.getPitch(),
      this.viewerLeft?.getYaw(),
      this.viewerLeft?.getHfov()
    );

    // Add listeners for both viewers
    this.addViewer1Listener();
    this.addViewer2Listener();
  }

  addViewer2Listener() {
    // Listen for panorama orientation change event, replicate current values into other view
    if (this.viewerRight) {
      this.viewerRight.on("panorama-orientation-changed", () => {
        // Only update left viewer if it's not being adjusted
        if (!this.isRightViewerBeingAdjusted && this.viewerLeft) {
          this.viewerLeft.lookAt(
            this.viewerRight?.getPitch(),
            this.viewerRight?.getYaw(),
            this.viewerRight?.getHfov(),
            false
          );
        }
      });
    }
  }

  addViewer1Listener() {
    if (this.viewerLeft) {
      this.viewerLeft.on("panorama-orientation-changed", () => {
        // Only update right viewer if it's not being adjusted
        if (!this.isRightViewerBeingAdjusted && this.viewerRight) {
          this.viewerRight.lookAt(
            this.viewerLeft.getPitch(),
            this.viewerLeft.getYaw(),
            this.viewerLeft.getHfov(),
            false
          );
        }
      });
    }
  }

  changeTour(e) {
    this.currentTourId = e.value;
    this.getLatestTour(this.projectId, this.currentTourId, "view1");
  }

  getLatestTour(projectId, tourId, elementId) {
    this.interiorService.getTourData(projectId, tourId).subscribe(
      (data) => {
        this.viewerLeft.destroy();

        // Reset the controls
        this.resetViewerControlsData();

        this.currentTour = data.tour;
        this.isVideoCaptureMode =
          this.currentTour.videoCaptureDetails !== undefined;
        this.getTourData(this.currentTour, elementId);
        this.fpBlobContent(this.currentTour);
        this.interiorId = this.currentTour.interiorId;
        this.locationId = this.currentTour.locationId;
        this.filterInteriorList();
        this.refreshSecondView(this.locationId);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  refreshSecondView(locationId) {
    this.getTourList(this.intIdToCompare);
  }

  async fpBlobContentRight(tour: TourImage) {
    const container = this.config.floorPlanContainer;
    this.interiorService
      .getBlobToken(container, tour.floorPlanBlobId)
      .subscribe(
        async (data) => {
          const imageUrl = data.sasToken.uri;
          this.loadFloorPlanRight(tour, imageUrl);
        },
        (err) => {
          this.errors = err;
        }
      );
  }

  bottomRightResize(offsetX: number, offsetY: number) {
    // this.y += offsetY;
    this.width += offsetX;
    this.height += offsetY;
  }

  onCornerClick(event: MouseEvent, resizer?: Function) {
    this.draggingCorner = true;
    this.px = event.clientX;
    this.py = event.clientY;
    this.resizer = resizer;
    this.status = 1;
    event.preventDefault();
    event.stopPropagation();
  }

  @HostListener("document:mousemove", ["$event"])
  onCornerMove(event: MouseEvent) {
    if (!this.draggingCorner) {
      return;
    }
    let offsetX = event.clientX - this.px;
    let offsetY = event.clientY - this.py;

    if (this.status === Status.RESIZE) {
      this.floorPlanMapLeft.invalidateSize();
      this.floorPlanMapRight.invalidateSize();

      this.resizer(offsetX, offsetY);
    } else if (this.status === Status.MOVE) {
      return;
    }
    this.px = event.clientX;
    this.py = event.clientY;
  }

  @HostListener("document:mouseup", ["$event"])
  onCornerRelease() {
    this.draggingCorner = false;
  }

  setStatus(event: MouseEvent, status: number, func?) {
    if (status === 1) {
      this.draggingCorner = true;
      this.px = event.clientX;
      this.py = event.clientY;
      this.resizer = func;
      this.status = 1;
      event.preventDefault();
      event.stopPropagation();
    } else if (status === 2) {
      this.draggingCorner = true;
      this.px = event.clientX;
      this.py = event.clientY;
      this.status = 2;
    }
  }

  onDrag(x, y) {
    this.x = this.x + x;
    this.y = this.y + y;
  }

  // Navigate image on the left side
  navigateImage(direction: string) {
    if (this.viewerLeft) {
      let imageNumber =
        direction === "next"
          ? this.selectedImageNumberLeft + 1
          : this.selectedImageNumberLeft - 1;

      let marker: L.Marker = this.markersLeft.find(
        (marker) => marker.feature.properties.imageNumber === imageNumber
      );
      marker?.fireEvent("click");
    }
  }

  performViewerGestures(type) {
    switch (type) {
      case "pan-up":
        this.viewerLeft?.setPitch(this.viewerLeft.getPitch() + 10);
        break;
      case "pan-down":
        this.viewerLeft?.setPitch(this.viewerLeft.getPitch() - 10);
        break;
      case "pan-left":
        this.viewerLeft?.setYaw(this.viewerLeft.getYaw() - 10);
        break;
      case "pan-right":
        this.viewerLeft?.setYaw(this.viewerLeft.getYaw() + 10);
        break;

      default:
        break;
    }
  }

  resetViewerControlsData() {
    this.selectedImageNumberLeft = 1;
    this.selectedImageNumberRight = 1;
    this.markersLeft = [];
    this.markersRight = [];
    this.isLastImage = false;
  }
}
