import { Component, Inject, Input, OnChanges, OnInit } from "@angular/core";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import {
  DashboardChart,
  InteriorDialogData,
  InteriorService,
  TourImage,
  UiService,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { saveAs } from "file-saver";
import { ChartConfiguration } from "chart.js";

@Component({
  selector: "interior-project-progress-chart",
  templateUrl: "./progress-chart.component.html",
  styleUrls: ["./progress-chart.component.scss"],
})
export class ProgressChartComponent implements OnInit, OnChanges {
  @Input() tour: TourImage;
  @Input() isUnitLevel: boolean;
  projectCharts: DashboardChart[] = [];
  fileData: any;
  dataError: boolean = false;
  projectId: any;
  tourId: any;
  interiorId: string;
  towerId: string;
  floorId: string;
  chartLegend: boolean = true;
  errors: any;
  isLoaded = false;
  barDefaultColor: any = "#9CCC65";
  performanceIndex: any = {};
  // bar chart
  public barChartOptions: ChartConfiguration["options"];

  public sCurveData = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        pointHoverBackgroundColor: "#42A5F5",
        pointHoverBorderColor: "#1E88E5",
        pointBackgroundColor: "#42A5F5",
        pointBorderColor: "#1E88E5",
      },
      {
        label: "",
        backgroundColor: "#9CCC65",
        borderColor: "#7CB342",
        fill: false,
        data: [],
        pointHoverBackgroundColor: "#9CCC65",
        pointHoverBorderColor: "#7CB342",
        pointBackgroundColor: "#9CCC65",
        pointBorderColor: "#7CB342",
      },
    ],
  };

  public bar = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        hoverBackgroundColor: "#42A5F5",
        hoverBorderColor: "#1E88E5",
      },
      {
        label: "",
        backgroundColor: [], //"#9CCC65",
        borderColor: "#7CB342",
        fill: false,
        data: [],
        toolTip: [],
        hoverBackgroundColor: "#9CCC65",
        hoverBorderColor: "#7CB342",
      },
    ],
  };

  public activityBar = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        hoverBackgroundColor: "#42A5F5",
        hoverBorderColor: "#1E88E5",
      },
      {
        label: "",
        backgroundColor: "#9CCC65",
        borderColor: "#7CB342",
        fill: false,
        data: [],
        toolTip: [],
        hoverBackgroundColor: "#9CCC65",
        hoverBorderColor: "#7CB342",
      },
    ],
  };

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private uiService: UiService,
    private interiorService: InteriorService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private ts: TranslateService
  ) {}

  public ngOnInit(): void {
    this.projectId = this.tour.projectId;
    this.tourId = this.tour.tourId;
    this.interiorId = this.tour.interiorId;
    this.towerId = this.tour.towerId;
    this.floorId = this.tour.locationId;

    this.initializeChartOptions();
  }

  initializeChartOptions() {
    this.barChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      hover: {
        intersect: true,
        mode: "x",
        axis: "x",
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            precision: 0,
          },
        },
      },
      plugins: {
        tooltip: {
          callbacks: {
            label: (context) => {
              const {
                dataset,
                datasetIndex,
                dataIndex,
                parsed: { y },
              } = context;
              if (datasetIndex == 0) {
                return `${dataset.label}: ${y}%`;
              } else if (datasetIndex == 1) {
                // for actuals
                const modLabel = `${dataset.label}: ${y}% ${
                  dataset["toolTip"] ? dataset["toolTip"][dataIndex] : ""
                }`;
                return modLabel.trim();
              }
            },
          },
        },
      },
      onClick: (event, elements, chart) => {
        if (elements.length) {
          let dataIndex = elements[0].index;
          // do not delete, for future use
          // https://stackoverflow.com/questions/69093845/how-can-i-get-the-active-label-element-on-click-in-chartjs
          let label: string = chart.data.labels[dataIndex].toString();
          this.getActivityChart(label);
        }
      },
    };
  }

  ngOnChanges(): void {
    this.projectId = this.tour.projectId;
    this.tourId = this.tour.tourId;
    this.interiorId = this.tour.interiorId;
    this.towerId = this.tour.towerId;
    this.floorId = this.tour.locationId;
    this.getCharts(
      this.projectId,
      this.interiorId,
      this.tourId,
      this.towerId,
      this.floorId
    );
  }

  getCharts(projectId, interiorId, tourId, towerId, floorId) {
    this.uiService.show();
    if (this.isUnitLevel) {
      this.interiorService
        .getProgressChartByUnit(projectId, interiorId, tourId, towerId, floorId)
        .subscribe(
          (response) => {
            this.projectCharts = [];
            let data = response.response;
            this.isLoaded = true;

            for (const unitChart of data.unitLevelCharts) {
              if (
                !!unitChart &&
                unitChart.wbsChart &&
                unitChart.wbsChart?.labels.length > 0
              ) {
                let wbsChart: DashboardChart = {} as DashboardChart;
                let bar = {
                  labels: [],
                  datasets: [
                    {
                      label: "",
                      backgroundColor: "#42A5F5",
                      borderColor: "#1E88E5",
                      fill: false,
                      data: [],
                      hoverBackgroundColor: "#42A5F5",
                      hoverBorderColor: "#1E88E5",
                    },
                    {
                      label: "",
                      backgroundColor: "#9CCC65",
                      borderColor: "#7CB342",
                      fill: false,
                      data: [],
                      toolTip: [],
                      hoverBackgroundColor: "#9CCC65",
                      hoverBorderColor: "#7CB342",
                    },
                  ],
                };
                wbsChart.chartName =
                  this.ts.instant("exterior.mapbox.labels.wbsLabel") +
                  " - " +
                  unitChart.unitName;
                wbsChart.chartType = "bar";

                bar.labels = unitChart.wbsChart.labels;
                bar.datasets[0].label = this.ts.instant(
                  "exterior.mapbox.labels.plannedLabel"
                );
                bar.datasets[0].data = unitChart.wbsChart.planned;
                bar.datasets[1].label = this.ts.instant(
                  "exterior.mapbox.labels.actualLabel"
                );

                bar.datasets[1].data = unitChart.wbsChart.actual;

                bar.datasets[1].toolTip = unitChart.wbsChart.toolTip;

                wbsChart.data = bar;
                this.projectCharts.push(wbsChart);
              }
            }

            this.uiService.hide();
          },
          (err) => {
            this.uiService.hide();
            this.errors = err;
          }
        );
    } else {
      this.interiorService
        .getProgressChart(projectId, interiorId, tourId, towerId, floorId)
        .subscribe(
          (response) => {
            this.projectCharts = [];
            let data = response.response;
            this.performanceIndex = data?.performanceIndex?.interior;
            this.isLoaded = true;
            let sCurve: DashboardChart = {} as DashboardChart;

            let wbsChart: DashboardChart = {} as DashboardChart;

            if (data.sCurve && data.sCurve.labels.length > 0) {
              sCurve.chartName = this.ts.instant(
                "interior.virtualTour.labels.scurveLabels"
              );
              sCurve.chartType = "line";

              this.sCurveData.labels = data.sCurve.labels;
              this.sCurveData.datasets[0].label = this.ts.instant(
                "exterior.mapbox.labels.plannedLabel"
              );
              this.sCurveData.datasets[0].data = data.sCurve.planned;
              this.sCurveData.datasets[1].label = this.ts.instant(
                "exterior.mapbox.labels.actualLabel"
              );
              this.sCurveData.datasets[1].data = data.sCurve.actual;

              sCurve.data = this.sCurveData;
              this.projectCharts.push(sCurve);
            }

            if (data.wbsChart && data.wbsChart.labels.length > 0) {
              wbsChart.chartName = this.ts.instant(
                "exterior.mapbox.labels.wbsLabel"
              );
              wbsChart.chartType = "bar";

              this.bar.labels = data.wbsChart.labels;
              this.bar.datasets[0].label = this.ts.instant(
                "exterior.mapbox.labels.plannedLabel"
              );
              this.bar.datasets[0].data = data.wbsChart.planned;
              this.bar.datasets[1].label = this.ts.instant(
                "exterior.mapbox.labels.actualLabel"
              );

              this.bar.datasets[1].data = data.wbsChart.actual;

              this.bar.datasets[1].toolTip = data.wbsChart.toolTip;

              if (data?.performanceIndex?.interior) {
                let colorData: any = [];
                this.bar.datasets[0].data.forEach((item: any, index: any) => {
                  let diff = item - this.bar.datasets[1].data[index];
                  if (
                    diff >= data.performanceIndex.interior.wbs.value.rangeVal
                  ) {
                    colorData.push(data.performanceIndex.interior.wbs.color);
                  } else {
                    colorData.push(this.barDefaultColor);
                  }
                });
                this.bar.datasets[1].backgroundColor = colorData;
              } else {
                let colorData: any = [];
                for (let dat of this.bar.datasets[1].data) {
                  colorData.push(this.barDefaultColor);
                }
                this.bar.datasets[1].backgroundColor = colorData;
              }
              wbsChart.data = this.bar;
              this.projectCharts.push(wbsChart);
            }

            this.uiService.hide();
          },
          (err) => {
            this.uiService.hide();
            this.errors = err;
          }
        );
    }
  }

  downloadChartData() {
    this.uiService.show();
    this.interiorService
      .downloadChartData(this.projectId, this.interiorId, this.towerId)
      .subscribe((file) => {
        const byteArray = new Uint8Array(
          atob(file)
            .split("")
            .map((char) => char.charCodeAt(0))
        );
        var blob = new Blob([byteArray], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8",
        });

        saveAs(blob, `${this.projectId}.xlsx`);
        this.uiService.hide();
      });
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  getActivityChart(activityName: string) {
    this.uiService.show();
    this.interiorService
      .getChartByActivity(
        this.projectId,
        this.interiorId,
        this.tourId,
        this.towerId,
        activityName
      )
      .subscribe(
        (response) => {
          let data = response.response;
          this.isLoaded = true;
          let activityChart: DashboardChart = {} as DashboardChart;

          if (data.wbsChart && data.wbsChart.labels.length > 0) {
            activityChart.chartName = this.ts.instant(
              "exterior.mapbox.labels.activityChart"
            );
            activityChart.chartType = "bar";

            this.activityBar.labels = data.wbsChart.labels;
            this.activityBar.datasets[0].label = this.ts.instant(
              "exterior.mapbox.labels.plannedLabel"
            );
            this.activityBar.datasets[0].data = data.wbsChart.planned;
            this.activityBar.datasets[1].label = this.ts.instant(
              "exterior.mapbox.labels.actualLabel"
            );

            this.activityBar.datasets[1].data = data.wbsChart.actual;
            this.activityBar.datasets[1].toolTip = data.wbsChart.toolTip;

            if (this.performanceIndex) {
              let colorData: any = [];
              this.activityBar.datasets[0].data.forEach(
                (item: any, index: any) => {
                  let diff = item - this.activityBar.datasets[1].data[index];
                  if (diff >= this.performanceIndex.wbs.value.rangeVal) {
                    colorData.push(this.performanceIndex.wbs.color);
                  } else {
                    colorData.push(this.barDefaultColor);
                  }
                }
              );
              this.activityBar.datasets[1].backgroundColor = colorData;
            } else {
              let colorData: any = [];
              for (let dat of this.activityBar.datasets[1].data) {
                colorData.push(this.barDefaultColor);
              }
              this.activityBar.datasets[1].backgroundColor = colorData;
            }

            activityChart.data = this.activityBar;

            this.dialog.open(ActivityChartComponent, {
              width: "40%",
              disableClose: true,
              data: { activityName: activityName, chart: activityChart },
            });
          }

          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }
}

@Component({
  selector: "activity-chart",
  templateUrl: "./activity-chart.component.html",
  styleUrls: ["./progress-chart.component.scss"],
})
export class ActivityChartComponent {
  chartLegend: boolean = true;
  barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: (context) => {
            const {
              dataset,
              parsed: { y },
            } = context;
            return `${dataset.label}: ${y}%`;
          },
        },
      },
    },
  };

  public bar = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        hoverBackgroundColor: "#42A5F5",
        hoverBorderColor: "#1E88E5",
      },
      {
        label: "",
        backgroundColor: "#9CCC65",
        borderColor: "#7CB342",
        fill: false,
        data: [],
        toolTip: [],
        hoverBackgroundColor: "#9CCC65",
        hoverBorderColor: "#7CB342",
      },
    ],
  };
  chart: any;
  activityName: any;

  constructor(
    private ts: TranslateService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ActivityChartComponent>
  ) {
    this.chart = data.chart;
    this.activityName = data.activityName;
  }

  dismiss(): void {
    this.dialogRef.close();
  }
}
