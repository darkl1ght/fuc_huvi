import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import * as _ from "lodash";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { SelectionModel } from "@angular/cdk/collections";

export interface WBSActivity {
  workLocation: string;
  description: string;
  workTrade: string;
  action: any;
}
@Component({
  selector: "new-activity",
  templateUrl: "./activity.component.html",
  styleUrls: ["./activity.component.scss"],
})
export class ActivityComponent implements OnInit {
  dataSource: MatTableDataSource<WBSActivity>;
  activityList: any = [];
  displayedColumns: string[] = ["selected", "description"];
  header: string = "";
  @ViewChild(MatSort) sort: MatSort;
  selection = new SelectionModel<WBSActivity>(true, []);

  constructor(
    public dialogRef: MatDialogRef<ActivityComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any
  ) {
    this.header = this.data.header + " Activities";
    this.dataSource = new MatTableDataSource(this.data.activityData);
    this.dataSource.data.forEach((row: any) => {
      if (row.selected) {
        this.selection.select(row);
      }
    });
  }

  onSubmit() {
    this.dialogRef.close({ data: this.selection.selected });
  }

  public ngOnInit(): void {}

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  applySearchFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  isSticky(id: string) {
    return (["header-1"] || []).indexOf(id) !== -1;
  }
}
