import {
  Component,
  ElementRef,
  EventEmitter,
  Output,
  ViewChild,
} from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { Observable } from "rxjs";
import { map, startWith } from "rxjs/operators";
import {
  IntegrationService,
  LocalStorageService,
  UiService,
  SnackbarService,
} from "src/app/core";
import {
  FileAttachment,
  LinkedProject,
  ProcoreContributingBehavior,
  ProcoreContributingCondition,
  ProcoreHazard,
  ProcoreObservationType,
  ProcoreProjectLocation,
  ProcoreProjectUser,
  ProcoreSpecSection,
  ProcoreTrade,
  UpdateObservationDistributionMembersPayload,
} from "src/app/core/models/integration.model";
import { ENTER, COMMA } from "@angular/cdk/keycodes";
import { MatChipInputEvent } from "@angular/material/chips";
import { TranslateService } from "@ngx-translate/core";
import { v4 as uuidv4 } from "uuid";
@Component({
  selector: "procore-observation-detail",
  templateUrl: "./new-procore-observation.component.html",
  styleUrls: ["./new-procore-observation.component.scss"],
})
export class NewProcoreObservationComponent {
  @Output()
  notifyProcoreObservationDetailClose: EventEmitter<boolean> =
    new EventEmitter();
  @ViewChild("addObservationForm") newObservationForm;
  @ViewChild("tagInput") tagInput: ElementRef;
  observationForm: FormGroup;
  types: ProcoreObservationType[] = [];
  private: boolean = true;
  projectUsers: ProcoreProjectUser[] = [];
  projectLocations: ProcoreProjectLocation[] = [];
  trades: ProcoreTrade[] = [];
  specSections: ProcoreSpecSection[] = [];
  contributingConditions: ProcoreContributingCondition[] = [];
  contributingBehaviors: ProcoreContributingBehavior[] = [];
  hazards: ProcoreHazard[] = [];
  separatorKeysCodes: number[] = [ENTER, COMMA];
  selectedDistributionMembers: ProcoreProjectUser[] = [];
  tagCtrl = new FormControl();
  filteredDistributionMembers: Observable<ProcoreProjectUser[]>;
  attachmentFiles: FileAttachment[] = [];
  constraProjectId: string;
  linkedProject: LinkedProject;

  constructor(
    private fb: FormBuilder,
    private integrationService: IntegrationService,
    private localStorageService: LocalStorageService,
    private snackbarService: SnackbarService,
    private ts: TranslateService,
    private uiService: UiService
  ) {
    this.observationForm = this.fb.group({
      name: ["", [Validators.required]],
      type: ["", [Validators.required]],
      status: ["", [Validators.required]],
      priority: null,
      // number: ["", [Validators.required]],
      trade: null,
      location: null,
      specSection: null,
      assignee: null,
      distribution: null,
      dueDate: null,
      contributingCondition: null,
      contributingBehavior: null,
      hazard: null,
      description: null,
    });

    this.filteredDistributionMembers = this.tagCtrl.valueChanges.pipe(
      startWith(""),
      map((value: string) => this._filter(value))
    );
  }

  ngOnInit() {
    if (!this.integrationService.isProcoreConnected()) {
      this.snackbarService.warningSnackBar(
        this.ts.instant("integration.procore.messages.loginToProcore")
      );
      return;
    }

    this.constraProjectId = this.localStorageService.getProjectId();
    this.uiService.show();
    this.integrationService
      .getProcoreLinkedProject(this.constraProjectId)
      .subscribe({
        next: (data) => {
          this.linkedProject = data.procoreIntegration;

          if (this.linkedProject) {
            this.populateMasterData();
          } else {
            this.snackbarService.warningSnackBar(
              this.ts.instant("integration.procore.messages.projectNotLinked")
            );
          }

          this.uiService.hide();
        },
        error: (err) => {
          this.uiService.hide();
        },
      });
  }

  populateMasterData() {
    const companyId = this.linkedProject.companyId;
    const projectId = this.linkedProject.projectId;

    this.uiService.show();
    this.integrationService
      .getProcoreCompanyObservationTypes(companyId)
      .subscribe({
        next: (data) => {
          this.types = data;
          this.uiService.hide();
        },
        error: (err) => {
          this.uiService.hide();
        },
      });

    this.uiService.show();
    this.integrationService.getProcoreCompanyTrades(companyId).subscribe({
      next: (data) => {
        this.trades = data;
        this.uiService.hide();
      },
      error: (err) => {
        this.uiService.hide();
      },
    });

    this.uiService.show();
    this.integrationService
      .getProcoreCompanyContributingConditions(companyId)
      .subscribe({
        next: (data) => {
          this.contributingConditions = data;
          this.uiService.hide();
        },
        error: (err) => {
          this.uiService.hide();
        },
      });

    this.uiService.show();
    this.integrationService
      .getProcoreCompanyContributingBehaviors(companyId)
      .subscribe({
        next: (data) => {
          this.contributingBehaviors = data;
          this.uiService.hide();
        },
        error: (err) => {
          this.uiService.hide();
        },
      });

    this.uiService.show();
    this.integrationService.getProcoreCompanyHazards(companyId).subscribe({
      next: (data) => {
        this.hazards = data;
        this.uiService.hide();
      },
      error: (err) => {
        this.uiService.hide();
      },
    });

    this.uiService.show();
    this.integrationService
      .getProcoreProjectUsers(this.linkedProject.companyId, projectId)
      .subscribe({
        next: (data) => {
          this.projectUsers = data;
          this.filteredDistributionMembers = this.tagCtrl.valueChanges.pipe(
            startWith(""),
            map((value: string) => this._filter(value))
          );
          this.uiService.hide();
        },
        error: (err) => {
          this.uiService.hide();

          if (err.statusCode === 403) {
            this.snackbarService.warningSnackBar(
              this.ts.instant(
                "integration.procore.messages.permissionDeniedForProjectUsers"
              )
            );
          }
        },
      });

    this.uiService.show();
    this.integrationService
      .getProcoreProjectLocations(this.linkedProject.companyId, projectId)
      .subscribe({
        next: (data) => {
          this.projectLocations = data;
          this.uiService.hide();
        },
        error: (err) => {
          this.uiService.hide();
          if (err.statusCode === 403) {
            this.snackbarService.warningSnackBar(
              this.ts.instant(
                "integration.procore.messages.permissionDeniedForProjectLocations"
              )
            );
          }
        },
      });

    // this.uiService.show();
    // this.integrationService.getProcoreProjectSpecSections(this.linkedProject.companyId, projectId).subscribe({
    //   next: (data) => {
    //     this.specSections = data;
    //     this.uiService.hide();
    //   },
    //   error: (err) => {
    //     this.uiService.hide();
    //   },
    // });
  }

  createObservation() {
    if (!this.integrationService.isProcoreConnected()) {
      this.snackbarService.warningSnackBar(
        this.ts.instant("integration.procore.messages.loginToProcore")
      );
      return;
    }

    if (!this.linkedProject) {
      this.snackbarService.warningSnackBar(
        this.ts.instant("integration.procore.messages.projectNotLinked")
      );
      return;
    }

    if (!this.observationForm.valid) return;

    const formData = new FormData();

    formData.append(
      "observation[name]",
      this.observationForm.value["name"].trim()
    );
    formData.append("observation[type_id]", this.observationForm.value["type"]);
    formData.append(
      "observation[status]",
      this.observationForm.value["status"]
    );
    formData.append("observation[personal]", this.private.toString());

    if (this.observationForm.value["assignee"]) {
      formData.append(
        "observation[assignee_id]",
        this.observationForm.value["assignee"]
      );
    }

    if (this.observationForm.value["priority"]) {
      formData.append(
        "observation[priority]",
        this.observationForm.value["priority"]
      );
    }

    if (this.observationForm.value["dueDate"]) {
      const date = this.observationForm.value["dueDate"];
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const day = String(date.getDate()).padStart(2, "0");
      formData.append("observation[due_date]", `${year}-${month}-${day}`);
    }

    if (this.observationForm.value["location"]) {
      formData.append(
        "observation[location_id]",
        this.observationForm.value["location"]
      );
    }

    if (this.observationForm.value["trade"]) {
      formData.append(
        "observation[trade_id]",
        this.observationForm.value["trade"]
      );
    }

    /*
    if (this.observationForm.value["specSection"]) {
      formData.append(
        "observation[specification_section]",
        this.observationForm.value["specSection"]
      );
    }*/

    if (this.observationForm.value["contributingCondition"]) {
      formData.append(
        "observation[contributing_condition_id]",
        this.observationForm.value["contributingCondition"]
      );
    }

    if (this.observationForm.value["contributingBehavior"]) {
      formData.append(
        "observation[contributing_behavior_id]",
        this.observationForm.value["contributingBehavior"]
      );
    }

    if (this.observationForm.value["hazard"]) {
      formData.append(
        "observation[hazard_id]",
        this.observationForm.value["hazard"]
      );
    }

    if (this.observationForm.value["description"]) {
      formData.append(
        "observation[description]",
        this.observationForm.value["description"]
      );
    }

    formData.append("project_id", this.linkedProject.projectId.toString());

    if (this.attachmentFiles.length > 0) {
      this.attachmentFiles.forEach((item, idx) =>
        formData.append(`attachments[${idx}]`, item.file, item.file.name)
      );
    }

    this.uiService.show();
    this.integrationService
      .addProcoreObservation(this.linkedProject.companyId, formData)
      .subscribe({
        next: (data) => {
          if (this.selectedDistributionMembers.length > 0) {
            if (data.id && data.name && data.type?.id) {
              const payload: UpdateObservationDistributionMembersPayload = {
                project_id: this.linkedProject.projectId,
                observation: {
                  distribution_member_ids: this.selectedDistributionMembers.map(
                    (item) => item.id
                  ),
                },
              };
              //Calling separately as the distribution member list is not picked as expected from the form data
              this.integrationService
                .updateProcoreObservationDistributionMembers(
                  this.linkedProject.companyId,
                  data.id,
                  payload
                )
                .subscribe({
                  next: () => {
                    this.uiService.hide();
                    this.snackbarService.successSnackBar(
                      this.ts.instant(
                        "integration.procore.messages.observationCreated"
                      )
                    );
                    this.notifyProcoreObservationDetailClose.emit();
                  },
                  error: (err) => {
                    this.uiService.hide();

                    if (Array.isArray(err.errors)) {
                      this.snackbarService.errorSnackBar(
                        err.errors.join(" | ")
                      );
                    } else {
                      this.snackbarService.errorSnackBar(
                        this.ts.instant(
                          "integration.procore.messages.failedToAddDistributionMembers"
                        )
                      );
                    }
                  },
                });
            } else {
              this.uiService.hide();
              this.snackbarService.errorSnackBar(
                this.ts.instant(
                  "integration.procore.messages.observationCreationFailed"
                )
              );
            }
          } else {
            this.uiService.hide();
            this.snackbarService.successSnackBar(
              this.ts.instant("integration.procore.messages.observationCreated")
            );
            this.notifyProcoreObservationDetailClose.emit();
          }
        },
        error: (err) => {
          this.uiService.hide();

          if (Array.isArray(err.errors)) {
            this.snackbarService.errorSnackBar(err.errors.join(" | "));
          } else {
            this.snackbarService.errorSnackBar(
              this.ts.instant(
                "integration.procore.messages.observationCreationFailed"
              )
            );
          }
        },
      });
  }

  removeFile(file: FileAttachment) {
    this.attachmentFiles = this.attachmentFiles.filter(
      (item) => item.id !== file.id
    );
  }

  handleFileInput(event: any) {
    Array.from(event.target.files).forEach((file) => {
      this.attachmentFiles.push({
        id: uuidv4(),
        file,
      });
    });
  }

  privateSelect(event: any) {
    this.private = event.checked;
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;

    if (input) {
      input.value = "";
    }
    this.tagCtrl.setValue(null);
  }

  remove(tag: string[], indx: number): void {
    this.selectedDistributionMembers.splice(indx, 1);
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.selectedDistributionMembers.push(
      this.projectUsers.find((item) => item.id === event.option.value)
    );
    this.tagInput.nativeElement.value = "";
    this.tagCtrl.setValue(null);
  }

  private _filter(value: string): ProcoreProjectUser[] {
    return this.projectUsers.filter((user) =>
      user.name
        .toLowerCase()
        .includes(typeof value === "string" ? value.toLowerCase() : "")
    );
  }
}
