import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  Output,
  ViewChild,
  EventEmitter,
  ViewEncapsulation,
} from "@angular/core";
import { LatLng } from "leaflet";
import { Subscription } from "rxjs";
import {
  AecLevel,
  ForgeTokenObject,
  ForgeViewerComponentConfig,
} from "src/app/core/models";
import { ForgeService } from "src/app/core/services";
import { BimDataService } from "src/app/core/services/bim-data.service";
import { BIM_CONSTANTS } from "./bim-viewer-constants";
import "./custom-toolbar.extension";

declare const Autodesk: any;
declare const THREE: any;

@Component({
  selector: "bim-viewer",
  templateUrl: "./bim-viewer.component.html",
  styleUrls: ["./bim-viewer.component.scss"],
  encapsulation: ViewEncapsulation.None,
})
export class BimViewerComponent {
  @ViewChild("viewerContainer") forgeViewerContainer: ElementRef;

  // BIM viewer event emitters
  @Output() forgeModelRootUnLoaded: EventEmitter<void> =
    new EventEmitter<void>();
  @Output() forgeModelRootLoaded: EventEmitter<void> = new EventEmitter<void>();
  @Output() forgeModelGeometryLoaded: EventEmitter<void> =
    new EventEmitter<void>();
  @Output() requiresOrientationUpdate: EventEmitter<void> =
    new EventEmitter<void>();

  forgeObjectURN: string;
  aecLevel: AecLevel;
  transformationScale: number;
  modelOffset: any;
  origin: LatLng;
  forgeAccessToken: string;
  forgeAccessTokenExpiry: any;
  forgeViewerOptions: any;
  forgeViewer: any;
  forgeGlobalOffsetObject: any = undefined;

  errors: any;
  modelRotationZ = 0.0;
  previousAngle: number = 0;

  subscription: Subscription;

  isTranslationInProgress = false;
  isGeometryLoadingComplete = false;

  constructor(
    private forgeService: ForgeService,
    private cdr: ChangeDetectorRef,
    private bimDataService: BimDataService
  ) {}

  ngOnInit(): void {
    this.subscribeToBimData();
  }

  subscribeToBimData() {
    this.subscription = this.bimDataService.data.subscribe((config) => {
      this.updateFloorInModel(config);
      let { type, data } = config.event;
      switch (type) {
        case BIM_CONSTANTS.INITIAL_LOAD:
          if (this.forgeObjectURN) {
            this.initForge(this.forgeObjectURN);
          }
          break;
        case BIM_CONSTANTS.VIEW_POINT_CHANGED:
          this.setLocation(data);
          break;
        case BIM_CONSTANTS.ORIENTATION_CHANGED:
          this.changeCameraRotation(data);
          break;
        case BIM_CONSTANTS.MODEL_FLOOR_CHANGED:
          this.updateFloorInModel(config);
          this.forgeModelRootLoaded.emit();
          break;
        default:
          break;
      }
    });

    this.subscription.add(
      this.bimDataService.isTourLocked.subscribe((isTourLocked) => {
        if (this.forgeViewer) {
          const navigation = this.forgeViewer.navigation;
          if (navigation && isTourLocked)
            navigation.setCameraUpVector(new THREE.Vector3(0, 0, 1));
          this.forgeViewer.setNavigationLock(isTourLocked);

          // Temporary delay to emit event after navigation lock is set
          setTimeout(() => {
            this.requiresOrientationUpdate.emit();
          }, 100);
        }
      })
    );
  }

  updateFloorInModel(updateData: ForgeViewerComponentConfig) {
    this.origin = updateData.origin;
    this.aecLevel = updateData.aecLevel;
    this.transformationScale = updateData.transformationScale;
    this.modelOffset = updateData.modelOffset;
    this.forgeObjectURN = updateData.forgeObjectURN;
  }

  //Autocad Forge Viewer Load functions
  initForge(forgeObjectURN) {
    this.forgeService.getForgeObjectManifest(forgeObjectURN).subscribe(
      (translation) => {
        if (translation.status === "success") {
          this.forgeService.getForgeViewerToken().subscribe(
            (tokenData: ForgeTokenObject) => {
              this.initForgeViewer(tokenData, forgeObjectURN);
            },
            (err) => {
              this.errors = err;
            }
          );
        } else {
          this.isTranslationInProgress = true;
          this.cdr.detectChanges();
        }
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  initForgeViewer(tokenData: ForgeTokenObject, urnId: string) {
    this.forgeAccessToken = tokenData.accessToken;
    this.forgeAccessTokenExpiry = tokenData.expiresIn;
    this.forgeViewerOptions = {
      env: "AutodeskProduction",
      api: "derivativeV2",
      getAccessToken: (onTokenReady: any) => {
        const token = this.forgeAccessToken;
        const timeInSeconds = this.forgeAccessTokenExpiry;
        onTokenReady(token, timeInSeconds);
      },
    };
    this.launchViewer(urnId);
  }

  launchViewer(forgeUrnId: string) {
    // forge viewer load
    this.forgeViewer = new Autodesk.Viewing.GuiViewer3D(
      this.forgeViewerContainer.nativeElement,
      {}
    );

    var startedCode = this.forgeViewer.start();
    if (startedCode > 0) {
      console.error("Failed to create a Viewer: WebGL not supported.");
      return;
    }

    Autodesk.Viewing.Initializer(this.forgeViewerOptions, () => {
      // Prepare the viewer
      this.forgeViewer.setReverseZoomDirection(true);
      this.forgeViewer.setNavigationLockSettings({ fov: true });

      this.loadForgeObjDocument(forgeUrnId);
    });
  }

  loadForgeObjDocument(urnId: string) {
    const documentId = "urn:" + urnId;
    Autodesk.Viewing.Document.load(
      documentId,
      (doc) => {
        const viewables = doc.getRoot().getDefaultGeometry();

        // By default load model at set offset
        this.forgeViewer.loadDocumentNode(doc, viewables, {
          globalOffset: this.modelOffset,
        });
        // load WebVR
        this.forgeViewer.loadExtension("Autodesk.Viewing.WebVR");

        this.forgeViewer.addEventListener(
          Autodesk.Viewing.MODEL_ROOT_LOADED_EVENT,
          () => {
            this.forgeModelRootLoaded.emit();
            this.forgeViewer.loadExtension("Autodesk.Measure");
            this.forgeViewer.loadExtension("Autodesk.ViewerSettings");
            this.forgeViewer
              .loadExtension("Autodesk.ViewCubeUi")
              .then((extension) => extension.setVisible(false));

            // Set the BIM viewer to perspective camera mode by default
            if (this.forgeViewer?.navigation)
              this.forgeViewer?.navigation.toPerspective();
            this.forgeViewer.setNavigationLock(true);
          }
        );
        this.forgeViewer.addEventListener(
          Autodesk.Viewing.VIEWER_UNINITIALIZED,
          () => {
            this.forgeModelRootUnLoaded.emit();
            this.isGeometryLoadingComplete = false;
          }
        );
        this.forgeViewer.addEventListener(
          Autodesk.Viewing.GEOMETRY_LOADED_EVENT,
          () => {
            this.forgeModelGeometryLoaded.emit();
            this.isGeometryLoadingComplete = true;
          }
        );
      },
      (viewerErrorCode, viewerErrorMsg) => {
        console.error(
          "onDocumentLoadFailure() - errorCode:" +
            viewerErrorCode +
            "\n- errorMessage:" +
            viewerErrorMsg
        );
      }
    );
  }

  degreesToRadians(degrees: number): number {
    return (degrees * Math.PI) / 180;
  }

  changeCameraRotation({
    fov: horizontalFieldOfView,
    pitch,
    yaw,
    roll,
    heading,
    floorPlanOrientation,
    bimAngularDeviationFromTrueNorth,
  }) {
    const euler = new THREE.Euler(
      this.degreesToRadians(pitch + 90),
      this.degreesToRadians(roll),
      -this.degreesToRadians(
        yaw + heading + floorPlanOrientation + bimAngularDeviationFromTrueNorth
      ),
      BIM_CONSTANTS.MODEL_ROTATION_ORDER
    );
    let camera = this.forgeViewer?.getCamera();

    if (camera) {
      camera.quaternion.setFromEuler(euler);
      // Convert horizontal field of view to three.js perspective camera fov
      camera.fov =
        (Math.atan(
          Math.tan(((horizontalFieldOfView / 2) * Math.PI) / 180) /
            camera.aspect
        ) *
          2 *
          180) /
        Math.PI;

      this.forgeViewer?.navigation?.setCamera(camera);
    }

    this.forgeViewer?.impl?.sceneUpdated(true);
  }

  setLocation({ location, orientation }) {
    const y = (location.lat - this.origin.lat) * this.transformationScale;
    const x = (location.lng - this.origin.lng) * this.transformationScale;
    const z = this.aecLevel.elevation + this.aecLevel.height / 2;

    const newXCoordinates =
      x *
        Math.cos(
          this.degreesToRadians(orientation.bimAngularDeviationFromTrueNorth)
        ) +
      y *
        Math.sin(
          this.degreesToRadians(orientation.bimAngularDeviationFromTrueNorth)
        );
    const newYCoordinate =
      y *
        Math.cos(
          this.degreesToRadians(orientation.bimAngularDeviationFromTrueNorth)
        ) -
      x *
        Math.sin(
          this.degreesToRadians(orientation.bimAngularDeviationFromTrueNorth)
        );

    const position = new THREE.Vector3(newXCoordinates, newYCoordinate, z);
    const target = new THREE.Vector3(newXCoordinates, newYCoordinate + 0.1, z);

    let navigation = this.forgeViewer?.navigation;
    if (navigation) {
      navigation.setView(position, target);
      navigation.setVerticalFov(120);
      navigation.setCameraUpVector(new THREE.Vector3(0, 0, 1));
      navigation.setPivotPoint(position);
      navigation.setPivotSetFlag(true);
    }
  }

  tearDownViewer() {
    this.forgeViewer && this.forgeViewer.finish();
    this.forgeViewer = null;
    Autodesk.Viewing.shutdown();
  }

  ngOnDestroy(): void {
    if (this.subscription) this.subscription.unsubscribe();
    this.forgeViewer && this.tearDownViewer();
  }
}
