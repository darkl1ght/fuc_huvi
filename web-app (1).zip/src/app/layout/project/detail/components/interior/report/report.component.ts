import { Component, OnInit, Inject, ChangeDetectorRef } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import {
  ClientService,
  ProjectService,
  UserService,
  User,
  StorageService,
  Client,
  UiService,
  InteriorService,
  DashboardChart,
  Guid,
  InteriorTour,
  SnackbarService,
} from "src/app/core";
import jsPDF from "jspdf";
import "jspdf-autotable";

import html2canvas from "html2canvas";
import { catchError, finalize, map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { AppConstants as Constants } from "src/app/core";
import { MAT_DIALOG_DATA, MatDialog } from "@angular/material/dialog";
import { DatePipe } from "@angular/common";

import { throwError } from "rxjs/internal/observable/throwError";
import { forkJoin, Observable } from "rxjs";
import _ from "lodash";
import { ChartConfiguration } from "chart.js";

@Component({
  selector: "report",
  templateUrl: "./report.component.html",
  styleUrls: ["./report.component.scss"],
})
export class ReportComponent implements OnInit {
  downloadProgress: boolean = false;
  errors: any;
  user: User;
  projectId: string = "";
  projectName: string = "";
  tour: InteriorTour;
  project: any = [];
  client: Client;
  source: any;
  thumbnailContainer: string;
  mediaContainer: string;
  readToken: string;
  mediaBlobUrl: string;
  projectCharts: any = [];
  chartLegend: boolean = true;
  chartData: any = [];
  isLoaded = false;

  selfServeProjectCharts = [];
  barDefaultColor: any = "#9CCC65";

  public barChartOptionsInt: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
    },
    hover: {
      intersect: true,
      mode: "x",
      axis: "x",
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: (context) => {
            const {
              dataset,
              datasetIndex,
              dataIndex,
              parsed: { y },
            } = context;
            if (datasetIndex == 0) {
              return `${dataset.label}: ${y}%`;
            } else if (datasetIndex == 1) {
              // for actuals
              const modLabel = `${dataset.label}: ${y}% ${
                dataset["toolTip"] ? dataset["toolTip"][dataIndex] : ""
              }`;
              return modLabel.trim();
            }
          },
        },
      },
    },
  };

  public sCurveData = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        pointHoverBackgroundColor: "#42A5F5",
        pointHoverBorderColor: "#1E88E5",
        pointBackgroundColor: "#42A5F5",
        pointBorderColor: "#1E88E5",
      },
      {
        label: "",
        backgroundColor: "#9CCC65",
        borderColor: "#7CB342",
        fill: false,
        data: [],
        pointHoverBackgroundColor: "#9CCC65",
        pointHoverBorderColor: "#7CB342",
        pointBackgroundColor: "#9CCC65",
        pointBorderColor: "#7CB342",
      },
    ],
  };

  public bar = {
    labels: [],
    datasets: [
      {
        label: "",
        backgroundColor: "#42A5F5",
        borderColor: "#1E88E5",
        fill: false,
        data: [],
        hoverBackgroundColor: "#42A5F5",
        hoverBorderColor: "#1E88E5",
      },
      {
        label: "",
        backgroundColor: "#9CCC65",
        borderColor: "#7CB342",
        fill: false,
        data: [],
        toolTip: [],
        hoverBackgroundColor: "#9CCC65",
        hoverBorderColor: "#7CB342",
      },
    ],
  };
  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    public dialog: MatDialog,
    private userService: UserService,
    private snackService: SnackbarService,
    private projectService: ProjectService,
    private ts: TranslateService,
    private interiorService: InteriorService,
    public datePipe: DatePipe,
    private clientService: ClientService,
    private storageSvc: StorageService,
    private uiService: UiService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private ref: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.tour = this.data.tour;
    this.projectId = this.data.projectId;
    this.user = this.userService.getCurrentUser();

    this.uiService.show();

    this.fetchRequiredDataForInitialisation().subscribe(
      (results: any[]) => {
        this.uiService.hide();
      },
      (error: any) => {
        this.uiService.hide();
      }
    );
  }

  fetchRequiredDataForInitialisation(): Observable<any[]> {
    const request1 = this.projectService.get(this.projectId).pipe(
      map((data) => {
        this.projectName = data.projectName;
        this.project = data;
        this.getClientData(data.clientId);

        this.thumbnailContainer = this.config.imageThumbnailContainer;
        this.mediaContainer = this.config.mediaContainer;
        this.mediaBlobUrl = this.config.mediaBlobUrl;

        this.getTokenAndData();
      })
    );

    const request2 = this.interiorService
      .getTowersByInteriorId(this.tour.projectId, this.tour.interiorId)
      .pipe(
        map((data: any) => {
          this.tour.floorWalkthough = data.tours;

          for (let floor of this.tour.floorWalkthough) {
            for (let tour of floor.tours) {
              if (tour.charts.length != 0 && tour.isPublished == true) {
                for (let data of tour.charts[0].chartData.datasets) {
                  data.hoverBackgroundColor = data.backgroundColor;
                  data.hoverBorderColor = data.borderColor;
                }
                let chartData = tour.charts[0];
                chartData.towerName = floor.towerName;
                chartData.towerId = floor.towerId;
                chartData.tourId = tour.tourId;
                chartData.tourName = tour.tourName;
                this.projectCharts.push(chartData);
              } else if (
                (tour.isSelfServe && tour.isWBSPublished && tour.isPublished) ||
                (this.project.isInteriorWBSPublished &&
                  this.project.isSelfServe)
              ) {
                this.getCharts(this.data.projectId, this.tour.interiorId);
                return;
              }
            }
          }
        })
      );

    return forkJoin([request1, request2]);
  }

  getCharts(projectId, interiorId) {
    this.uiService.show();
    this.interiorService
      .getProgressChartInteriorLevel(projectId, interiorId)
      .subscribe(
        (response) => {
          this.selfServeProjectCharts = [];
          let chartData = response.responseData;
          let performanceIndex = response?.performanceIndex;
          this.isLoaded = true;

          for (let data of chartData) {
            let sCurve: DashboardChart = {} as DashboardChart;
            let wbsChart: DashboardChart = {} as DashboardChart;
            if (data.sCurve && data.sCurve.labels.length > 0) {
              let sCurveData = {
                labels: [],
                datasets: [
                  {
                    label: "",
                    backgroundColor: "#42A5F5",
                    borderColor: "#1E88E5",
                    fill: false,
                    data: [],
                    pointHoverBackgroundColor: "#42A5F5",
                    pointHoverBorderColor: "#1E88E5",
                    pointBackgroundColor: "#42A5F5",
                    pointBorderColor: "#1E88E5",
                  },
                  {
                    label: "",
                    backgroundColor: "#9CCC65",
                    borderColor: "#7CB342",
                    fill: false,
                    data: [],
                    pointHoverBackgroundColor: "#9CCC65",
                    pointHoverBorderColor: "#7CB342",
                    pointBackgroundColor: "#9CCC65",
                    pointBorderColor: "#7CB342",
                  },
                ],
              };
              sCurve.chartName = this.ts.instant(
                "interior.virtualTour.labels.scurveLabels"
              );
              sCurve.chartType = "line";
              sCurve.chartId = Guid.newGuid();
              sCurve.chartTitle = this.ts.instant(
                "interior.virtualTour.labels.scurveLabels"
              );
              sCurve.towerName = data.towerName;
              sCurve.floorName = data.floorName;
              sCurveData.labels = data.sCurve.labels;
              sCurveData.datasets[0].label = this.ts.instant(
                "exterior.mapbox.labels.plannedLabel"
              );
              sCurveData.datasets[0].data = data.sCurve.planned;
              sCurveData.datasets[1].label = this.ts.instant(
                "exterior.mapbox.labels.actualLabel"
              );
              sCurveData.datasets[1].data = data.sCurve.actual;

              sCurve.data = sCurveData;
              if (
                !this.selfServeProjectCharts.some(
                  (item) => item.towerName == data.towerName
                )
              ) {
                this.selfServeProjectCharts.push(sCurve);
              }
            }
            if (data.wbsChart && data.wbsChart.labels.length > 0) {
              let bar = {
                labels: [],
                datasets: [
                  {
                    label: "",
                    backgroundColor: "#42A5F5",
                    borderColor: "#1E88E5",
                    fill: false,
                    data: [],
                    hoverBackgroundColor: "#42A5F5",
                    hoverBorderColor: "#1E88E5",
                  },
                  {
                    label: "",
                    backgroundColor: "#9CCC65",
                    borderColor: "#7CB342",
                    fill: false,
                    data: [],
                    toolTip: [],
                    hoverBackgroundColor: "#9CCC65",
                    hoverBorderColor: "#7CB342",
                  },
                ],
              };
              wbsChart.towerName = data.towerName;
              wbsChart.floorName = data.floorName;
              wbsChart.chartName = this.ts.instant(
                "exterior.mapbox.labels.wbsLabel"
              );
              wbsChart.chartType = "bar";
              wbsChart.chartId = Guid.newGuid();
              wbsChart.chartTitle =
                this.ts.instant("exterior.mapbox.labels.wbsLabel") +
                " - " +
                data.floorName;
              bar.labels = data.wbsChart.labels;
              bar.datasets[0].label = this.ts.instant(
                "exterior.mapbox.labels.plannedLabel"
              );
              bar.datasets[0].data = data.wbsChart.planned;
              bar.datasets[1].label = this.ts.instant(
                "exterior.mapbox.labels.actualLabel"
              );

              bar.datasets[1].data = data.wbsChart.actual;

              bar.datasets[1].toolTip = data.wbsChart.toolTip;

              if (performanceIndex?.interior) {
                let colorData: any = [];
                bar.datasets[0].data.forEach((item: any, index: any) => {
                  let diff = item - bar.datasets[1].data[index];
                  if (diff >= performanceIndex.interior.wbs.value.rangeVal) {
                    colorData.push(performanceIndex.interior.wbs.color);
                  } else {
                    colorData.push(this.barDefaultColor);
                  }
                });
                bar.datasets[1].backgroundColor = colorData;
              } else {
                let colorData: any = [];
                for (let dat of bar.datasets[1].data) {
                  colorData.push(this.barDefaultColor);
                }
                bar.datasets[1].backgroundColor = colorData;
              }
              wbsChart.data = bar;
              this.selfServeProjectCharts.push(wbsChart);
            }
          }
          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }

  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
    },
  };
  getTokenAndData() {
    this.storageSvc.getReadToken(this.mediaContainer).subscribe(
      (data) => {
        this.readToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }
  getClientData(clientId) {
    let clientDetailsObservable = this.clientService.getClient(clientId);
    this.source = forkJoin([clientDetailsObservable])
      .pipe(
        map((results) => {
          this.client = results[0].client;
        }),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  async generateReport() {
    let alert = "";
    try {
      this.downloadProgress = true;
      this.uiService.show();
      this.ref.detectChanges();
      const doc = new jsPDF("p", "mm", [297, 210], true);
      this.coverPage(doc);
      this.addCaptureDetail(doc);

      if (this.selfServeProjectCharts.length != 0) {
        await this.addChartSelfServeData(doc);
      } else if (this.projectCharts.length != 0) {
        await this.addChartData(doc);
      }

      doc.save(this.tour.interiorName + "_report.pdf");
      alert = this.ts.instant("activity.report.messages.successful");
      this.snackService.successSnackBar(alert);
      this.uiService.hide();
      this.downloadProgress = false;
    } catch (error) {
      this.downloadProgress = false;
      alert = this.ts.instant("activity.report.messages.failed");
      this.snackService.errorSnackBar(alert);
      this.uiService.hide();
    }
  }
  coverPage(doc) {
    const latest_date = this.datePipe.transform(this.tour.interiorDate);

    doc.addImage("assets/images/firstpage.png", "PNG", 0, 0, 210, 297);

    const clientLogo =
      this.mediaBlobUrl + this.client.blobContentId + "?" + this.readToken;
    try {
      const img = new Image();
      img.src = clientLogo;
      doc.addImage(img, "JPG", 90, 20, 30, 30, "", "FAST");
    } catch (err) {}

    doc.setLineWidth(1);
    doc.setDrawColor(41, 63, 112);
    doc.rect(90, 20, 30, 30, "S");
    const text = this.client.clientName.toUpperCase();

    doc.setFontSize(45);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(41, 63, 112);
    doc.text(text, 105, 90, null, null, "center");

    const projectName = this.projectName.toUpperCase();
    let fontSize = 0;
    if (this.projectName.length < 20) {
      fontSize = 45;
    } else {
      fontSize = 35;
    }

    doc.setFontSize(fontSize);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(41, 63, 112);
    doc.text(projectName, 105, 110, null, null, "center");

    const extext = Constants.interior.interiorReport;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(30);
    doc.setTextColor(41, 63, 112);
    doc.text(extext, 105, 125, null, null, "center");

    doc.setLineWidth(0.21);
    doc.setTextColor(41, 63, 112);
    doc.line(74, 132, 136, 132);

    const preparedOn = Constants.report.preparedOn;
    doc.setFontSize(20);
    doc.setTextColor(41, 63, 112);
    doc.text(118, 160, preparedOn);

    const generatedDate = this.datePipe.transform(new Date());
    doc.setFontSize(20);
    doc.setTextColor(41, 63, 112);
    doc.text(163, 160, generatedDate);

    const capDate = Constants.aerialreport.captureDate + latest_date;
    doc.setFontSize(20);
    doc.setTextColor(41, 63, 112);
    doc.text(100, 170, capDate);

    const str = Constants.report.projectVis;
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text(str, 105, 270, null, null, "center");

    const urlText = Constants.report.available + Constants.report.projectUrl;
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text(urlText, 105, 280, null, null, "center");
  }
  addBackGroundAndLogos(doc) {
    doc.addPage();
    doc.addImage("assets/images/pdfback.png", "PNG", 0, 0, 210, 297);
    const clientLogo =
      this.mediaBlobUrl + this.client.blobContentId + "?" + this.readToken;
    try {
      const img = new Image();
      img.src = clientLogo;
      doc.addImage(img, "JPG", 7, 7, 16, 16, "", "FAST");
    } catch (err) {}

    doc.addImage("assets/images/report-logo.png", "JPEG", 183, 7, 20, 17);
  }
  async addChartSelfServeData(doc) {
    let towerName = _.uniqBy(this.selfServeProjectCharts, "towerName").map(
      (item) => item.towerName
    );

    for (let tower of towerName) {
      let i = 1;
      this.addBackGroundAndLogos(doc);
      let header = tower + " Progress";
      doc.setFontSize(16);
      doc.setTextColor(41, 63, 112);
      doc.text(header, 105, 25, null, null, "center");

      for (let chart of this.selfServeProjectCharts) {
        if (tower == chart.towerName) {
          let data = document.getElementById(chart.chartId);
          const pdf = await html2canvas(data).then((canvas) => {
            const contentDataURL = canvas.toDataURL("image/png");

            if (i != 1 && !(i % 2 === 0)) {
              this.addBackGroundAndLogos(doc);
            }
            if (i % 2 === 0) {
              let text = chart.chartTitle;
              doc.setFontSize(16);
              doc.setTextColor(41, 63, 112);
              doc.text(text, 105, 173, null, null, "center");
              doc.setLineWidth(1.5);
              doc.setDrawColor(41, 63, 112);
              doc.rect(20, 177, 175, 87, "S");
              doc.addImage(contentDataURL, "PNG", 20, 177, 175, 87);
            } else if (!(i % 2 === 0)) {
              let text = chart.chartTitle;
              doc.setFontSize(16);
              doc.setTextColor(41, 63, 112);
              doc.text(text, 105, 35, null, null, "center");
              doc.setLineWidth(1.5);
              doc.setDrawColor(41, 63, 112);
              doc.rect(20, 40, 175, 90, "S");
              doc.addImage(contentDataURL, "PNG", 20, 40, 175, 90);
            }
          });
          if (chart.chartType == "line") {
            let titleValue: any = "";
            if (i % 2 === 0) {
              titleValue = 257;
            } else {
              titleValue = 136;
            }
            let towerData = chart.chartTitle.split(" ").slice(-2).join(" ");
            let graphText =
              Constants.aerialreport.lineChartGraph +
              towerData +
              Constants.aerialreport.timeline;
            doc.setFontSize(10);
            doc.setTextColor(41, 63, 112);
            doc.text(graphText, 105, titleValue, null, null, "center");

            const capData =
              chart.data.labels[chart.data.datasets[1].data.length - 1];
            const capPreData =
              chart.data.labels[chart.data.datasets[1].data.length - 2];
            const headerData1 = capPreData == undefined ? "-" : capPreData;
            const head = [[towerData, headerData1, capData]];

            const actualData = chart.data.datasets[1].data;

            const plannedData = chart.data.datasets[0].data;
            const actDate = actualData[chart.data.datasets[1].data.length - 1];
            const actPreDate =
              actualData[chart.data.datasets[1].data.length - 2];
            const planDate =
              plannedData[chart.data.datasets[1].data.length - 1];
            const planPreDate =
              plannedData[chart.data.datasets[1].data.length - 2];

            const body = [
              [
                Constants.aerialreport.planned,
                planPreDate == undefined ? "-" : planPreDate + " %",
                planDate == undefined ? "-" : planDate + " %",
              ],
              [
                Constants.aerialreport.actual,
                actPreDate == undefined ? "-" : actPreDate + " %",
                actDate == undefined ? "-" : actDate + " %",
              ],
            ];

            doc.autoTable({
              head: head,
              body: body,
              startY: titleValue + 3,
              margin: {
                left: 60,
              },
              columnStyles: {
                0: {
                  columnWidth: 30,
                },
                1: {
                  columnWidth: 30,
                },
                2: {
                  columnWidth: 30,
                },
              },
            });
          }

          i++;
        }
      }
    }
  }

  async addChartData(doc) {
    let towerName = _.uniqBy(this.projectCharts, "towerName").map(
      (item: any) => item.towerName
    );

    for (let tower of towerName) {
      let i = 1;
      this.addBackGroundAndLogos(doc);
      let header = tower + " Progress";
      doc.setFontSize(16);
      doc.setTextColor(41, 63, 112);
      doc.text(header, 105, 20, null, null, "center");

      for (let chart of this.projectCharts) {
        if (tower == chart.towerName) {
          var data = document.getElementById(chart.chartId);
          const pdf = await html2canvas(data).then((canvas) => {
            const contentDataURL = canvas.toDataURL("image/png");
            if (i != 1 && !(i % 2 === 0)) {
              this.addBackGroundAndLogos(doc);
            }
            if (i % 2 === 0) {
              let title = chart.tourName;
              doc.setFontSize(16);
              doc.setTextColor(41, 63, 112);
              doc.text(title, 105, 160, null, null, "center");
              doc.setLineWidth(1.5);
              doc.setDrawColor(41, 63, 112);
              doc.rect(20, 165, 175, 87, "S");
              doc.addImage(contentDataURL, "PNG", 20, 165, 175, 87);
            } else {
              let title = chart.tourName;
              doc.setFontSize(16);
              doc.setTextColor(41, 63, 112);
              doc.text(title, 105, 33, null, null, "center");
              doc.setLineWidth(1.5);
              doc.setDrawColor(41, 63, 112);
              doc.rect(20, 35, 175, 90, "S");
              doc.addImage(contentDataURL, "PNG", 20, 35, 175, 90);
            }

            if (chart.chartType == "line") {
              let titleValue: any = "";
              if (i % 2 === 0) {
                titleValue = 257;
              } else {
                titleValue = 130;
              }
              let towerData = chart.chartTitle.split(" ").slice(3).join(" ");
              let graphText =
                Constants.aerialreport.lineChartGraph +
                towerData +
                Constants.aerialreport.timeline;
              doc.setFontSize(10);
              doc.setTextColor(41, 63, 112);
              doc.text(graphText, 105, titleValue, null, null, "center");
              let lastActualRecord = chart.chartData.datasets[0].data.length;
              const capData = chart.chartData.labels[lastActualRecord - 1];
              const capPreData = chart.chartData.labels[lastActualRecord - 2];

              const head = [[towerData, capPreData, capData]];

              const actualData = chart.chartData.datasets[0].data;

              const plannedData = chart.chartData.datasets[1].data;

              const actDate = actualData[lastActualRecord - 1];
              const actPreDate = actualData[lastActualRecord - 2];
              const planDate = plannedData[lastActualRecord - 1];
              const planPreDate = plannedData[lastActualRecord - 2];
              const body = [
                [
                  Constants.aerialreport.planned,
                  planPreDate == undefined ? "-" : planPreDate + " %",
                  planDate == undefined ? "-" : planDate + " %",
                ],
                [
                  Constants.aerialreport.actual,
                  actPreDate == undefined ? "-" : actPreDate + " %",
                  actDate == undefined ? "-" : actDate + " %",
                ],
              ];

              doc.autoTable({
                head: head,
                body: body,
                startY: titleValue + 2,
                margin: {
                  left: 60,
                },
                columnStyles: {
                  0: {
                    columnWidth: 30,
                  },
                  1: {
                    columnWidth: 30,
                  },
                  2: {
                    columnWidth: 30,
                  },
                },
              });
            }

            i++;
          });
        }
      }
    }
  }
  addCaptureDetail(doc) {
    const tourDate = this.datePipe.transform(this.tour.interiorDate);
    doc.addPage();

    doc.addImage("assets/images/pdfback.png", "PNG", 0, 0, 210, 297);

    const clientLogo =
      this.mediaBlobUrl + this.client.blobContentId + "?" + this.readToken;
    try {
      const img = new Image();
      img.src = clientLogo;
      doc.addImage(img, "JPG", 7, 7, 16, 16, "", "FAST");
    } catch (err) {}

    doc.addImage("assets/images/report-logo.png", "JPEG", 183, 7, 20, 17);
    let text = Constants.interior.interiorData;
    doc.setFontSize(18);
    doc.setTextColor(41, 63, 112);

    doc.text(text, 105, 36, null, null, "center");
    // doc.text(78, 36, text);

    doc.setLineWidth(0.21);
    doc.line(74, 38, 136, 38);

    doc.autoTable({
      body: [
        [Constants.aerialreport.location, this.project.location],
        [Constants.interior.type, Constants.interior.typeValue],
        [Constants.interior.dateCapture, tourDate],
      ],
      startY: 45,
      tableLineColor: [45, 64, 89],
      tableLineWidth: 0.25,
      lineColor: [45, 64, 89],
      theme: "grid",
      columnStyles: {
        0: {
          cellWidth: 100,
        },
      },
    });
  }

  header(doc, headerText) {
    const fontSize = doc.getFontSize();
    doc.setFontSize(10);
    doc.setTextColor(40);
    doc.text(174, 8, headerText);
    doc.setLineCap(2);
    doc.setFontSize(fontSize);
  }

  async closeDialog(): Promise<void> {
    this.dialog.closeAll();
  }

  getDateString() {
    const date = new Date();
    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, "0");
    const day = `${date.getDate()}`.padStart(2, "0");
    return `${year}${month}${day}`;
  }

  private handleError(error: any) {
    return throwError(error);
  }
}
