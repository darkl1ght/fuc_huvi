import { Component, Inject, Input, OnChanges, OnInit } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MatSliderChange } from "@angular/material/slider";
import { TranslateService } from "@ngx-translate/core";
import {
  AccessControlService,
  AppConstants,
  InteriorDialogData,
  InteriorService,
  TourImage,
  UiService,
  UpdateWbsProgressBulk,
  UpdateWbsProgressIntBulk,
  SnackbarService,
} from "src/app/core";
import moment from "moment";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";

@Component({
  selector: "int-project-progress-component",
  templateUrl: "./progress.component.html",
  styleUrls: ["./progress.component.scss"],
})
export class ProjectProgressComponent implements OnInit, OnChanges {
  @Input() tour: TourImage;
  @Input() isUnitLevel: boolean;
  projectId: any;
  tourId: any;
  interiorId: string;
  towerId: string;
  floorId: string;
  autoTicks = false;
  invert = false;
  max = 100;
  min = 0;
  showTicks = false;
  step = 1;
  thumbLabel = false;
  value = 7;
  vertical = false;
  tickInterval = 1;
  color = "primary";
  isAnyModified: boolean = false;
  isLoaded = false;
  wbsData: any = [];
  wbsDataList: any = [];
  errors: any;
  lowerProgressWarning = this.ts.instant(
    "exterior.list.messages.lowerProgressWarning"
  );
  units: any = [];
  classifications: any = [];
  currentUnitId: string = "";
  isIST: boolean = false;
  selectedClassification: string = "";
  accessSyncWbs: boolean;
  accessUpdateProgress: boolean;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private uiService: UiService,
    private interiorService: InteriorService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private accessControlService: AccessControlService,
    private snackService: SnackbarService,
    private ts: TranslateService
  ) {}

  public ngOnInit(): void {
    this.accessControlService
      .getObjectAccesses([
        AppConstants.accessObjectKeys.VIRTUAL_SYNC_WBS,
        AppConstants.accessObjectKeys.VIRTUAL_UPDATE_PROGRESS,
      ])
      .subscribe({
        next: (data) => {
          const [accessSyncWbs, accessUpdateProgress] = data;
          this.accessSyncWbs = accessSyncWbs.isAllowed;
          this.accessUpdateProgress = accessUpdateProgress.isAllowed;
        },
      });

    this.projectId = this.tour.projectId;
    this.tourId = this.tour.tourId;
    this.interiorId = this.tour.interiorId;
    this.towerId = this.tour.towerId;
    this.floorId = this.tour.locationId;

    this.isIST = new Date().getTimezoneOffset() / 60 == -5.5;
  }

  ngOnChanges(): void {
    this.projectId = this.tour.projectId;
    this.tourId = this.tour.tourId;
    this.interiorId = this.tour.interiorId;
    this.towerId = this.tour.towerId;
    this.floorId = this.tour.locationId;
    this.publishWBSTourData();
  }

  formatDate(date: Date) {
    return moment(date).fromNow();
  }

  getWBSData(projectId, tourId, towerId) {
    this.uiService.show();
    if (this.isUnitLevel) {
      this.interiorService
        .getWBSStatusByUnit(
          projectId,
          this.interiorId,
          tourId,
          towerId,
          this.floorId,
          this.currentUnitId
        )
        .subscribe(
          (data) => {
            this.wbsData = data.wbsData;
            this.wbsDataList = data.wbsData;
            this.isAnyModified = false;
            this.wbsData.forEach((element) => {
              element.prev = element.actual;
              element.actualUpdated = false;
              element.isLowerWarning = false;
            });
            this.isLoaded = true;
            this.uiService.hide();
          },
          (err) => {
            this.errors = err;
          }
        );
    } else {
      this.interiorService
        .getWBSStatus(projectId, this.interiorId, tourId, towerId, this.floorId)
        .subscribe(
          (data) => {
            this.wbsData = data.wbsData;
            this.wbsDataList = data.wbsData;
            this.isAnyModified = false;
            this.wbsData.forEach((element) => {
              element.prev = element.actual;
              element.actualUpdated = false;
              element.isLowerWarning = false;
            });
            this.isLoaded = true;
            this.uiService.hide();
          },
          (err) => {
            this.errors = err;
          }
        );
    }
  }

  geUnitsData(projectId, floorId) {
    this.interiorService.getUnits(projectId, floorId).subscribe(
      async (data: any) => {
        this.units = data.units;
        if (!!this.units && this.units.length > 0) {
          this.currentUnitId = this.units[0].locationId;
          await this.getWBSData(this.projectId, this.tourId, this.towerId);
        }
        if (
          !!data &&
          !!data.classifications &&
          data.classifications.length > 0
        ) {
          this.classifications = data.classifications;
        } else {
          this.classifications = ["Dry", "Wet"];
        }
      },
      (err) => {
        this.errors = err;
      }
    );
  }
  onUnitChange(event: any) {
    this.currentUnitId = event.value;
    this.selectedClassification = "";
    this.getWBSData(this.projectId, this.tourId, this.towerId);
  }
  onClassificationChange(event: any) {
    this.selectedClassification = event.value;
    if (!!this.selectedClassification) {
      const wbsData = this.wbsDataList;
      this.wbsData = wbsData.filter((wbs: any) => {
        return (
          wbs.classification?.toLowerCase() ==
          this.selectedClassification?.toLowerCase()
        );
      });
    } else {
      this.wbsData = this.wbsDataList;
    }
  }
  getSliderTickInterval(): number | "auto" {
    if (this.showTicks) {
      return this.autoTicks ? "auto" : this.tickInterval;
    }

    return 0;
  }

  onInputChange(event: MatSliderChange, wbs) {
    wbs.actualUpdated = true;
    this.isAnyModified = true;
    wbs.actual = event.value;
    this.checkLowerProgressWarning(wbs);
  }

  onActualTextChange(wbs) {
    wbs.actualUpdated = true;
    this.isAnyModified = true;
    this.checkLowerProgressWarning(wbs);
  }

  checkLowerProgressWarning(wbs) {
    if (parseFloat(wbs.actual) < parseFloat(wbs.prev)) {
      if (!wbs.isLowerWarning) {
        wbs.isLowerWarning = true;
        this.snackService.warningSnackBar(this.lowerProgressWarning);
      }
    } else if (parseFloat(wbs.actual) >= parseFloat(wbs.prev)) {
      wbs.isLowerWarning = false;
    }
  }

  updateActualWBSBulk() {
    let payload: UpdateWbsProgressIntBulk;
    let wbsList: UpdateWbsProgressBulk[] = [];
    let isValid: boolean = true;

    this.wbsData.forEach((element) => {
      if (element.actual == undefined) {
        isValid = false;
      }

      element.actual = element.actual > 100 ? 100 : element.actual;
      element.actual = element.actual < 0 ? 0 : element.actual;
      element.comment = element.comment.trim();

      if (element.actualUpdated) {
        wbsList.push({
          wbsId: element.wbsId,
          progress: element.actual,
          comment: element.comment,
        });
      }
    });

    if (!isValid || wbsList.length < 1) return;

    payload = {
      projectId: this.projectId,
      interiorId: this.interiorId,
      tourId: this.tourId,
      towerId: this.towerId,
      floorId: this.floorId,
      wbsList,
    };
    if (this.isUnitLevel) {
      payload.unitId = this.currentUnitId;
    }

    this.uiService.show();
    this.interiorService.updateWBSProgressBulk(payload).subscribe(
      (data) => {
        this.getWBSData(this.projectId, this.tourId, this.towerId);
        this.uiService.hide();
        this.snackService.successSnackBar(
          this.ts.instant(
            "interior.virtualTour.messages.saveAllProjectProgressSuccess"
          )
        );
        this.selectedClassification = "";
      },
      (err) => {
        this.errors = err;
        this.uiService.hide();
      }
    );
  }

  updateActualWBS(wbs) {
    this.uiService.show();
    wbs.actual = wbs.actual > 100 ? 100 : wbs.actual;
    wbs.actual = wbs.actual < 0 ? 0 : wbs.actual;
    wbs.comment = wbs.comment.trim();

    this.interiorService
      .updateWBSProgress(
        this.projectId,
        this.interiorId,
        this.tourId,
        this.towerId,
        this.floorId,
        wbs.wbsId,
        wbs.actual,
        wbs.comment
      )
      .subscribe(
        (data) => {
          this.getWBSData(this.projectId, this.tourId, this.towerId);
          this.uiService.hide();
        },
        (err) => {
          this.errors = err;
          this.uiService.hide();
        }
      );
  }

  restoreData() {
    this.uiService.show();
    if (this.isUnitLevel) {
      this.interiorService
        .restoreWBSBaselineByUnit(
          this.projectId,
          this.interiorId,
          this.tourId,
          this.towerId,
          this.floorId,
          this.currentUnitId
        )
        .subscribe(
          (data) => {
            this.getWBSData(this.projectId, this.tourId, this.towerId);
            this.selectedClassification = "";
            this.uiService.hide();
          },
          (err) => {
            this.errors = err;
          }
        );
    } else {
      this.interiorService
        .restoreWBSBaseline(
          this.projectId,
          this.interiorId,
          this.tourId,
          this.towerId,
          this.floorId
        )
        .subscribe(
          (data) => {
            this.getWBSData(this.projectId, this.tourId, this.towerId);
            this.uiService.hide();
          },
          (err) => {
            this.errors = err;
          }
        );
    }
  }

  publishWBSTourData() {
    this.uiService.show();
    this.interiorService
      .publishWBSTourData(
        this.projectId,
        this.interiorId,
        this.tourId,
        this.towerId,
        this.floorId
      )
      .subscribe(
        async () => {
          if (this.isUnitLevel) {
            await this.geUnitsData(this.projectId, this.floorId);
          } else {
            await this.getWBSData(this.projectId, this.tourId, this.towerId);
          }

          this.uiService.hide();
        },
        (err) => {
          this.errors = err;
        }
      );
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  onCommentChange(wbs): void {
    wbs.actualUpdated = true;
    this.isAnyModified = true;
  }
}
