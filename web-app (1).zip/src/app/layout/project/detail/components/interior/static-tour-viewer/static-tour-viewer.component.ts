import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ChartConfiguration } from "chart.js";
import {
  InteriorDialogData,
  InteriorTour,
  DashboardChart,
  UiService,
} from "src/app/core";

@Component({
  selector: "static-tour-viewer",
  templateUrl: "./static-tour-viewer.component.html",
  styleUrls: ["./static-tour-viewer.component.scss"],
})
export class StaticTourViewerComponent implements OnInit {
  @ViewChild("progressBarPanel") sideNave: any;
  mapUrl: string = "";
  tour: InteriorTour;
  tourId: string;
  tourList: any;
  projectCharts: DashboardChart[] = [];
  chartLegend: boolean = true;
  errors: any;

  // bar chart
  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    hover: {
      intersect: true,
      mode: "x",
      axis: "x",
    },
    scales: {
      y: {
        max: 100,
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
    },
  };

  //progress bar
  showProgressBar: boolean = true;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private uiService: UiService
  ) {}

  public ngOnInit(): void {
    this.tour = this.data.interior;
    this.tourList = this.data.interior.staticMap.urls;
    this.mapUrl = this.data.interior.staticMap.urls[0].tourUrl;
    this.tourId = this.data.interior.staticMap.urls[0].tourId;

    this.setUpProjectCharts(this.data.interior.staticMap.charts);
  }

  changeTour(e) {
    this.uiService.show();
    this.tourId = e.value;
    this.mapUrl = this.tourList.find((x) => x.tourId === this.tourId).tourUrl;
    setTimeout(() => {
      this.uiService.hide();
    }, 3000);
  }

  setUpProjectCharts(charts) {
    this.projectCharts = charts;
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  showProgressChart() {
    this.showProgressBar = true;
    this.sideNave.toggle();
  }

  closeProgressBar() {
    this.showProgressBar = false;
    this.sideNave.toggle();
  }
}
