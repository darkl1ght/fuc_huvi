import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { TourImage, UiService, FloorPlanService } from "src/app/core";

export interface FloorPlanConfigDialogData {
  tour: TourImage;
}

@Component({
  selector: "floor-plan-config",
  templateUrl: "./floor-plan-config.component.html",
  styleUrls: ["./floor-plan-config.component.scss"],
  providers: [FloorPlanService],
})
export class FloorPlanConfigComponent implements OnInit {
  constructor(
    private uiService: UiService,
    public floorPlanService: FloorPlanService,
    @Inject(MAT_DIALOG_DATA) public data: FloorPlanConfigDialogData,
    public dialogRef: MatDialogRef<FloorPlanConfigComponent>
  ) {}

  ngOnInit(): void {
    this.floorPlanService.getTokenAndLoadFloorPlan(this.data.tour);
  }

  saveUpdatedPath() {
    this.uiService.show();

    this.floorPlanService
      .saveNewPath(this.data.tour.projectId, this.data.tour.tourId)
      .subscribe(
        () => {
          this.dialogRef.close({ success: true });
          this.uiService.hide();
        },
        (error) => this.uiService.hide()
      );
  }
}
