import { Component, OnInit, Input, OnChanges } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { ChartConfiguration } from "chart.js";
import {
  InteriorService,
  UiService,
  ProjectChart,
  TourImage,
} from "src/app/core";

@Component({
  selector: "chart-dashboard-component",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"],
})
export class InteriorDashboardComponent implements OnInit, OnChanges {
  @Input() tour: TourImage;

  projectCharts: ProjectChart[] = [];
  chart: ProjectChart = {} as ProjectChart;
  fileData: any;
  dataError: boolean = false;
  interiorId: string = "";
  projectId: string;
  tourId: string;
  chartLegend: boolean = true;
  errors: any;

  // bar chart
  public barChartOptions: ChartConfiguration["options"] = {
    responsive: true,
    maintainAspectRatio: false,
    hover: {
      intersect: true,
      mode: "x",
      axis: "x",
    },
    scales: {
      y: {
        // max: 100,
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
    },
  };

  constructor(
    public dialog: MatDialog,
    private uiService: UiService,
    private interiorService: InteriorService
  ) {}

  public ngOnInit(): void {}

  ngOnChanges(): void {
    this.getInteriorCharts();
  }

  getInteriorCharts() {
    this.uiService.show();
    this.interiorService
      .getCharts(this.tour.projectId, this.tour.interiorId, this.tour.tourId)
      .subscribe(
        (data) => {
          this.projectCharts =
            data.charts && data.charts.length > 0 ? data.charts : [];
          this.projectCharts.map((chart) =>
            chart.chartData.datasets.map((data) => {
              data.hoverBackgroundColor = data.backgroundColor;
              data.hoverBorderColor = data.borderColor;
            })
          );
          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
