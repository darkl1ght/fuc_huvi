import { EventEmitter } from "@angular/core";
import * as L from "leaflet";
import "leaflet";

export class PathConfigButton extends L.Control {
  constructor(
    options?: L.ControlOptions,
    private onClickEmitter?: EventEmitter<any>
  ) {
    super(options);
  }

  onAdd(map: L.Map) {
    const container = L.DomUtil.create(
      "div",
      "leaflet-bar leaflet-control leaflet-control-custom"
    );

    container.style.backgroundColor = "white";
    container.style.backgroundImage = "url(assets/images/edit.png)";
    container.style.backgroundSize = "30px 30px";
    container.style.width = "30px";
    container.style.height = "30px";
    container.title = "Toggle edit modes";

    container.onmouseover = function () {
      container.style.backgroundColor = "#F5F5F5";
    };
    container.onmouseout = function () {
      container.style.backgroundColor = "white";
    };
    container.onclick = () => {
      if (this.onClickEmitter) {
        this.onClickEmitter.emit();
      }
    };
    return container;
  }

  onRemove(map: L.Map) {
    // Nothing to do here
  }
}
