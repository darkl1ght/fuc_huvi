import { Component, OnInit, Input, OnChanges } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import {
  User,
  UserService,
  ProjectUserService,
  ProjectUser,
  RemarkComment,
  InteriorService,
} from "src/app/core";
import { map, catchError, finalize } from "rxjs/operators";
import { throwError } from "rxjs";

@Component({
  selector: "remark-discussion",
  templateUrl: "./remark-discussion.component.html",
  styleUrls: ["./remark-discussion.component.scss"],
})
export class RemarkDiscussionComponent implements OnInit, OnChanges {
  @Input() interiorId: string;
  @Input() tourId: string;
  @Input() remarkId: string;
  @Input() projectId: string;
  comment: string;
  members: ProjectUser[] = [];
  comments: RemarkComment[] = [];
  mentionItems: any[] = [];
  allowDropUp: boolean = false;
  user: User;
  errors: any;

  constructor(
    public dialog: MatDialog,
    private intSvc: InteriorService,
    private userSvc: UserService,
    private projectUserSvc: ProjectUserService
  ) {}

  public ngOnInit(): void {
    this.getComments();
    this.user = this.userSvc.getCurrentUser();
  }

  ngOnChanges() {
    this.getComments();
    if (this.projectId) {
      this.getProjectUserData(this.projectId);
    }
  }

  addComment() {
    if (this.comment) {
      this.intSvc
        .addRemarkComments(this.projectId,this.interiorId, this.tourId, this.remarkId, this.comment)
        .pipe(
          map((data) => {
            if (data === "success") {
              this.comment = "";
              this.getComments();
            }
          }),
          catchError(this.handleError),
          finalize(() => {})
        )
        .subscribe();
    }
  }

  getComments() {
    this.intSvc
      .getRemarkComment(this.projectId, this.tourId, this.remarkId)
      .pipe(
        map((data) => {
          this.comments = data.remark.comments;
          this.comments = this.sortComments(data.remark.comments);
        }),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  deleteComment(comment) {
    this.intSvc
      .deleteRemarkComment(this.projectId, this.tourId,this.remarkId, comment.commentId)
      .pipe(
        map((data) => {
          if (data.status === "success") {
            this.getComments();
          }
        }),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  getProjectUserData(projectId) {
    this.projectUserSvc.getAll(projectId).subscribe(
      (data) => {
        this.members = data.users;
        this.setMentionData(this.members);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  setMentionData(users: ProjectUser[]) {
    users.forEach((element) => {
      this.mentionItems.push({
        tag:
          element.firstName +
          " " +
          element.lastName +
          " [" +
          element.role.desc +
          "]",
        display: element.email,
      });
    });
  }

  sortComments(comments) {
    if (comments) {
      comments.sort(function (a, b) {
        return +new Date(a.createdAt) - +new Date(b.createdAt);
      });
    }

    return comments;
  }

  private handleError(error: any) {
    return throwError(error);
  }

  itemMentioned(tag) {
    return tag.display;
  }
}
