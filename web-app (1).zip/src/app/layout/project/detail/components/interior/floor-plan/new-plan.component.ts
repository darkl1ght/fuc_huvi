import { Component, OnInit, Inject } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  Guid,
  UiService,
  StorageService,
  InteriorService,
  User,
  UserService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";
import { take, tap } from "rxjs/operators";
import "leaflet";
import * as L from "leaflet";
import "leaflet-draw";

@Component({
  selector: "new-plan",
  templateUrl: "./new-plan.component.html",
  styleUrls: ["./new-plan.component.scss"],
})
export class NewFloorPlanComponent implements OnInit {
  public planName: string = "";
  errors = {};
  projectId: string;
  tourId: string;
  accessToken: string;
  readToken: string;
  filesSelected: boolean = false;
  updateChild: boolean = false;
  floorPlanUrl: string;
  blobContentId: string;
  showPlan: boolean = false;
  map: L.Map;
  featureGroup: L.FeatureGroup;
  currentUser: User;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private interiorService: InteriorService,
    private snackService: SnackbarService,
    private storageService: StorageService,
    private userService: UserService,
    private uiService: UiService,
    private ts: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  public ngOnInit(): void {
    this.currentUser = this.userService.getCurrentUser();

    this.getToken();
    this.projectId = this.data.projectId;
    this.tourId = this.data.tourId;
    this.blobContentId = this.data.blobContentId;

    if (this.blobContentId) {
      this.showPlan = true;
      this.getFloorPlanUrl(this.blobContentId);
    }
  }

  onFileChange(event: any): void {
    let alert = "";
    if (this.tourId && event.length > 1) {
      alert = this.ts.instant(
        "masterData.location.floorPlan.messages.uploadErrorFileCount"
      );
      this.snackService.errorSnackBar(alert);
      return;
    }
    this.filesSelected = true;
    this.uploadFiles(event);
  }

  async uploadFiles(files) {
    let alert;
    try {
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.accessToken
      );
      const containerClient = blobServiceClient.getContainerClient(
        this.config.floorPlanContainer
      );
      const promises = [];
      this.uiService.show();
      for (const file of files) {
        let fileName = file.name;
        let fileId = Guid.newGuid();
        let extn = file.name.split(".").pop();
        let docId = fileId + "." + extn;

        const blockBlobClient = containerClient.getBlockBlobClient(docId);
        promises.push(blockBlobClient.uploadBrowserData(file));
        this.updateFileData(docId);
      }

      await Promise.all(promises);
      alert = this.ts.instant(
        "masterData.location.floorPlan.messages.uploadSuccess"
      );
      this.snackService.successSnackBar(alert);
      this.closeDialog();
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
      alert = this.ts.instant(
        "masterData.location.floorPlan.messages.uploadFailed"
      );
      this.snackService.errorSnackBar(alert);
    }
  }

  getToken() {
    let container = this.config.floorPlanContainer;
    this.storageService.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  private updateFileData(blobContentId: string) {
    this.interiorService
      .uploadFloorPlan(this.projectId, this.tourId, blobContentId)
      .pipe(
        take(1),
        tap((data) => {
          return;
        })
      )
      .subscribe();
  }

  async getFloorPlanUrl(blobContentId: string) {
    let readToken;
    let container = this.config.floorPlanContainer;
    let blobContainer = this.config.floorPlanBlobContainer;
    await this.interiorService.getReadToken(container).subscribe(
      (data) => {
        readToken = data.sasToken.token;
        this.floorPlanUrl = blobContainer + blobContentId + "?" + readToken;
        this.loadFloorPlan(this.floorPlanUrl);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  loadFloorPlan(imageUrl) {
    this.uiService.show();
    let featureLayer: any;
    this.map = L.map("map", {
      crs: L.CRS.Simple,
      minZoom: -5,
      maxBoundsViscosity: 1,
    });

    const img = new Image();
    img.id = "mapImage";
    img.src = imageUrl;
    img.onload = () => {
      const w = img.width;
      const h = img.height;
      const bounds: any = [
        [-10, -10],
        [h, w],
      ];
      L.imageOverlay(imageUrl, bounds).addTo(this.map);
      this.map.fitBounds(bounds);
      this.map.setMaxBounds(bounds);
      this.uiService.hide();
    };
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
