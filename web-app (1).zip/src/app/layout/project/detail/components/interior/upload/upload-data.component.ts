import {
  Component,
  OnInit,
  ViewChild,
  Inject,
  ElementRef,
  ChangeDetectorRef,
} from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
  FormControl,
} from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";

import {
  LookUpService,
  Guid,
  UiService,
  TourImage,
  InteriorDialogData,
  InteriorService,
  InteriorImage,
  SnackbarService,
  Lookup,
} from "src/app/core";
import { ActivatedRoute, Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { tap, take } from "rxjs/operators";
import { BlobStorageService } from "src/app/core/storage/blob-storage.service";

import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";
import { MatAutocomplete } from "@angular/material/autocomplete";

@Component({
  selector: "upload-data",
  templateUrl: "./upload-data.component.html",
  styleUrls: ["./upload-data.component.scss"],
})
export class UploadDataComponent implements OnInit {
  isLinear = true;
  tourFormGroup: UntypedFormGroup;
  floorPlanFormGroup: UntypedFormGroup;
  floorPlanFile: File;
  fileName: string;
  interiorId: string = "";
  errors = {};
  wasFormChanged = false;
  projectId: string;
  accessToken: string;
  virtualAccessToken: string;
  tourId: string;
  eventType: string;
  progressInfos: any[] = [];
  uploadInProgress: boolean = false;

  @ViewChild("tagInput") tagInput: ElementRef;
  @ViewChild("auto") matAutocomplete: MatAutocomplete;

  constructor(
    private _formBuilder: UntypedFormBuilder,
    private cd: ChangeDetectorRef,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private lookupSvc: LookUpService,
    private uiService: UiService,
    private interiorService: InteriorService,
    private route: ActivatedRoute,
    private snackService: SnackbarService,
    private router: Router,
    private ts: TranslateService,
    private blobStorage: BlobStorageService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  public ngOnInit(): void {
    this.tourFormGroup = this._formBuilder.group({
      tourName: ["", Validators.required],
    });
    this.floorPlanFormGroup = this._formBuilder.group({
      plan: ["", Validators.required],
    });

    this.getToken();
    this.projectId = this.data.projectId;
    this.interiorId = this.data.interiorId;
    this.tourId = this.data.tourId;
    this.eventType = this.data.eventType;
    this.getVirtualTourToken();
  }

  selectFloorPlan(event, field) {
    const file = event.target.files[0];
    this.floorPlanFile = file;
    this.fileName = file.name;
  }

  submitTour() {
    let tourName: string;
    if (
      this.tourFormGroup.valid &&
      this.floorPlanFormGroup.valid &&
      this.floorPlanFile
    ) {
      tourName = this.tourFormGroup.value["tourName"];
      this.uploadFloorPlan(this.floorPlanFile, tourName);
    }
  }

  async uploadFloorPlan(file, tour) {
    try {
      const extn = file.name.split(".").pop();
      const blobRef = Guid.newGuid() + "." + extn;

      this.uiService.show();
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.accessToken
      );
      const containerClient = blobServiceClient.getContainerClient(
        this.config.floorPlanContainer
      );
      const promises = [];
      const blockBlobClient = containerClient.getBlockBlobClient(blobRef);
      promises.push(blockBlobClient.uploadBrowserData(file));
      this.createTour(blobRef, tour);
      await Promise.all(promises);
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
    }
  }

  createTour(blobRef, tourName) {
    const tourImage: TourImage = {} as TourImage;
    tourImage.floorPlanBlobId = blobRef;
    tourImage.tourName = tourName;
    tourImage.interiorId = this.interiorId;
    this.interiorService
      .createNewTour(this.projectId, this.interiorId, tourImage)
      .subscribe((data) => {
        this.tourId = data.tour.tourId;
      });
  }

  onFileChange(event: any): void {
    this.progressInfos = [];
    let i;
    for (i = 0; i < event.length; ++i) {
      const file = event[i];
      this.progressInfos[i] = { value: 0, fileName: file.name };
      const extn = file.name.split(".").pop();
      if (!this.isImage(extn)) {
        this.uiService.hide();
        this.dialog.closeAll();
        const alert = this.ts.instant(
          "interior.uploadData.messages.extensionNotAllowed"
        );
        this.snackService.errorSnackBar(alert);
        break;
      }
    }
    if (i == event.length) this.uploadFiles(event);
  }

  isImage(ext) {
    switch (ext.toLowerCase()) {
      case "jpg":
      case "jpeg":
      case "png":
        //etc
        return true;
    }
    return false;
  }

  async uploadFiles(files) {
    let alert;

    try {
      this.uploadInProgress = true;
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.virtualAccessToken
      );
      const containerClient = blobServiceClient.getContainerClient(
        this.config.virtualTourContainer
      );
      const promises = [];
      for (let index = 0; index < files.length; ++index) {
        const file = files[index];
        this.progressInfos[index] = { value: 0, fileName: file.name };
        const extn = file.name.split(".").pop();
        const imageId = Guid.newGuid();
        const blobRef = imageId + "." + extn;
        const image: InteriorImage = {} as InteriorImage;
        image.imageId = imageId;
        image.blobImageId = blobRef;
        image.imageName = file.name;

        const blockBlobClient = containerClient.getBlockBlobClient(
          this.tourId + "/" + blobRef
        );
        promises.push(
          blockBlobClient.uploadBrowserData(file, {
            blockSize: 4 * 1024 * 1024, // 4MB block size
            concurrency: 20, // 20 concurrency
            onProgress: (ev) => {
              this.progressInfos[index].value = Math.round(
                (100 * ev.loadedBytes) / file.size
              );
              if (ev.loadedBytes === file.size) {
                this.uploadImage(image);
              }
            },
            blobHTTPHeaders: { blobContentType: file.type },
          })
        );
      }
      await Promise.all(promises);
      alert = this.ts.instant("interior.uploadData.messages.uploadSuccess");
      this.snackService.successSnackBar(alert);
      this.uploadInProgress = false;
    } catch (error) {
      alert = this.ts.instant("interior.uploadData.messages.uploadFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  uploadImage(image: InteriorImage) {
    this.interiorService
      .postImage(this.projectId, this.interiorId, this.tourId, image)
      .pipe(
        take(1),
        tap((data) => {
          if (data === "success") {
          }
        })
      )
      .subscribe();
  }

  getToken() {
    const container = this.config.floorPlanContainer;
    this.interiorService.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getVirtualTourToken() {
    const container = this.config.virtualTourContainer;
    this.interiorService.getToken(container).subscribe(
      (data) => {
        this.virtualAccessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
