import { Component, OnInit } from "@angular/core";

@Component({
  selector: "floor-plan",
  templateUrl: "./floor-plan.component.html",
  styleUrls: ["./floor-plan.component.scss"],
})
export class FloorPlanComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
