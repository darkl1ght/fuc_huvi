import {
  Component,
  OnInit,
  ViewChild,
  Inject,
  ElementRef,
} from "@angular/core";
import { FormControl } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  InteriorService,
  InteriorTagPayload,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { COMMA, ENTER } from "@angular/cdk/keycodes";
import { MatChipInputEvent } from "@angular/material/chips";

@Component({
  selector: "interior-tag",
  templateUrl: "./interior-tag.component.html",
  styleUrls: ["./interior-tag.component.scss"],
})
export class InteriorTagComponent implements OnInit {
  @ViewChild("tagInput") tagInput: ElementRef<HTMLInputElement>;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  tagCtrl = new FormControl();
  tagList: string[] = [];
  isDataSaved: boolean = false;
  projectId: string;
  interiorId: string;

  constructor(
    public dialogRef: MatDialogRef<InteriorTagComponent>,
    private interiorService: InteriorService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  public ngOnInit(): void {
    this.tagList = this.data.interior.tagList
      ? JSON.parse(JSON.stringify(this.data.interior.tagList))
      : [];
    this.projectId = this.data.projectId;
    this.interiorId = this.data.interior.interiorId;
  }

  saveInteriorTag() {
    let alert = "";
    let interiorTagPayload: InteriorTagPayload;
    interiorTagPayload = {
      tagList: this.tagList,
    };
    this.interiorService
      .updateInteriorTags(this.projectId, this.interiorId, interiorTagPayload)
      .subscribe({
        next: () => {
          this.isDataSaved = true;
          alert = this.ts.instant("interior.list.messages.tourDetailsSaved");
          this.snackService.successSnackBar(alert);
        },
        error: () => {
          alert = this.ts.instant("interior.list.messages.failedToSave");
          this.snackService.successSnackBar(alert);
        },
      });
  }

  closeDialog(): void {
    this.dialogRef.close(this.isDataSaved);
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    if ((value || "").trim()) {
      this.tagList.push(value.trim());
    }

    if (input) {
      input.value = "";
    }

    this.tagCtrl.setValue(null);
    this.saveInteriorTag();
  }

  remove(item: string): void {
    const index = this.tagList.indexOf(item);

    if (index >= 0) {
      this.tagList.splice(index, 1);
    }

    this.saveInteriorTag();
  }
  saveTag() {
    const value = this.tagInput.nativeElement.value.trim();

    if ((value || "").trim()) {
      this.tagList.push(value.trim());
    }

    this.tagCtrl.setValue(null);
    this.saveInteriorTag();
  }
}
