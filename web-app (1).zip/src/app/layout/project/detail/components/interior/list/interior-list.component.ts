import {
  ChangeDetectorRef,
  Component,
  Inject,
  OnInit,
  ViewChild,
} from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import {
  UiService,
  InteriorTour,
  InteriorService,
  UserService,
  User,
  TourImage,
  LocalStorageService,
  ShareService,
  ProjectUser,
  ProjectService,
  AccessControlService,
  AppConstants,
  EquirectangularImageViewerService,
  FieldIssueService,
  SnackbarService,
  MasterDataService,
} from "src/app/core";
import { NewInteriorComponent } from "./new/new-interior.component";
import { MatSort } from "@angular/material/sort";
import { ActivatedRoute } from "@angular/router";
import { MatPaginator } from "@angular/material/paginator";
import { TranslateService } from "@ngx-translate/core";
import { StaticMapComponent } from "../static-map/static-map.component";
import { UpdateTowerComponent } from "./update-tour/update-tower/update-tower.component";
import { NewChartComponent } from "../new-chart/new-chart.component";
import { WalkthroughComponent } from "../walkthrough/walkthrough.component";
import { NewFloorPlanComponent } from "../floor-plan/new-plan.component";
import { UpdateTourComponent } from "./update-tour/update-tour.component";
import {
  ConfirmAlertComponent,
  ConfirmAlertModel,
} from "src/app/layout/components/confirm-alert/confirm-alert.component";
import { ReportComponent } from "../report/report.component";
import { WalkthroughSplitComponent } from "../walkthrough-split/walkthrough-split.component";
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import { bimSvgIcon } from "../walkthrough/walkthrough-utils";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { Clipboard } from "@angular/cdk/clipboard";
import { switchMap } from "rxjs/operators";
import { Subscription } from "rxjs";
import { UploadEquirectangularImageComponent } from "../upload-equirectangular-image/upload-equirectangular-image.component";
import { InteriorTagComponent } from "../tag/interior-tag.component";
import { UploadApartmentSnapshotsComponent } from "../upload-apartment-snapshots/upload-apartment-snapshots.component";

@Component({
  selector: "new-interior",
  templateUrl: "./interior-list.component.html",
  styleUrls: ["./interior-list.component.scss"],
})
export class InteriorListComponent implements OnInit {
  @ViewChild("trigger") trigger;
  result: string = "";
  projectId: string;
  dataSource: any;
  interiorList: InteriorTour[] = [];
  filteredInteriorList: InteriorTour[] = [];

  subscription: Subscription;

  @ViewChild(MatSort) sort: MatSort;
  errors = {};
  @ViewChild(MatPaginator) paginator: MatPaginator;
  showDiscussionPanel: boolean = false;
  interiorId: string;
  user: User;
  walkthroughData: [];
  panelOpenState: boolean = false;
  isVirtualTourSearchOpen = false;
  isInteriorsLoaded: boolean = false;
  projectUsers: ProjectUser[] = [];
  isOpen: boolean = false;
  shareLink: string = null;
  accessCreateTour: boolean;
  accessEditTour: boolean;
  accessDeleteTour: boolean;
  accessEditTourTower: boolean;
  accessEditTourFloor: boolean;
  accessDeleteWalkthrough: boolean;
  accessSendNotification: boolean;
  equirectangularImageExists: boolean = false;
  isUnitLevel: boolean = false;
  apartmentDetailsExist: boolean = false;
  excludeCaptureDateForInterior: boolean = false;

  constructor(
    public dialog: MatDialog,
    @Inject(APP_CONFIG) private config: AppConfig,
    private route: ActivatedRoute,
    private uiService: UiService,
    private interiorService: InteriorService,
    private ts: TranslateService,
    private userService: UserService,
    private snackService: SnackbarService,
    private shareService: ShareService,
    private accessControlService: AccessControlService,
    private localStorage: LocalStorageService,
    iconRegistry: MatIconRegistry,
    private projectSvc: ProjectService,
    private fieldIssueService: FieldIssueService,
    private clipboard: Clipboard,
    sanitizer: DomSanitizer,
    private changeDetectorRef: ChangeDetectorRef,
    private equirectangularImageService: EquirectangularImageViewerService,
    private masterdataService: MasterDataService
  ) {
    this.projectId =
      this.route.parent.parent.parent.snapshot.paramMap.get("projectId");
    iconRegistry.addSvgIconLiteral(
      "svgIcon",
      sanitizer.bypassSecurityTrustHtml(bimSvgIcon)
    );
  }

  ngOnInit() {
    this.accessControlService
      .getObjectAccesses([
        AppConstants.accessObjectKeys.VIRTUAL_CREATE_TOUR,
        AppConstants.accessObjectKeys.VIRTUAL_EDIT_TOUR,
        AppConstants.accessObjectKeys.VIRTUAL_DELETE_TOUR,
        AppConstants.accessObjectKeys.VIRTUAL_EDIT_TOUR_TOWER,
        AppConstants.accessObjectKeys.VIRTUAL_EDIT_TOUR_FLOOR,
        AppConstants.accessObjectKeys.VIRTUAL_DELETE_WALKTHROUGH,
        AppConstants.accessObjectKeys.VIRTUAL_SEND_NOTIFICATION,
      ])
      .subscribe({
        next: (data) => {
          const [
            accessCreateTour,
            accessEditTour,
            accessDeleteTour,
            accessEditTourTower,
            accessEditTourFloor,
            accessDeleteWalkthrough,
            accessSendNotification,
          ] = data;
          this.accessCreateTour = accessCreateTour.isAllowed;
          this.accessEditTour = accessEditTour.isAllowed;
          this.accessEditTourTower = accessEditTourTower.isAllowed;
          this.accessEditTourFloor = accessEditTourFloor.isAllowed;
          this.accessDeleteTour = accessDeleteTour.isAllowed;
          this.accessDeleteWalkthrough = accessDeleteWalkthrough.isAllowed;
          this.accessSendNotification = accessSendNotification.isAllowed;
        },
      });

    this.route.parent.parent.parent.params.subscribe((params) => {
      this.projectId = params["projectId"];
      this.getInteriorData();
      this.getProjectUserList();
    });
    this.user = this.userService.getCurrentUser();
  }

  getProjectUserList() {
    this.projectSvc.get(this.projectId).subscribe(
      (data) => {
        this.projectUsers = data.users;
        this.isUnitLevel = data.isUnitLevel;
        this.excludeCaptureDateForInterior = data.excludeCaptureDateForInterior;
      },
      (error) => {
        this.errors = error;
      }
    );
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(NewInteriorComponent, {
      width: "450px",
      disableClose: true,
      data: { projectId: this.projectId, interior: undefined },
    });

    dialogRef.afterClosed().subscribe(() => {
      this.getInteriorData();
    });
  }

  toggleInteriorSearchInput() {
    this.isVirtualTourSearchOpen = !this.isVirtualTourSearchOpen;
  }

  mapSettings(interior: InteriorTour) {
    const dialogRef = this.dialog.open(StaticMapComponent, {
      panelClass: "full-screen-dialog",
      disableClose: true,
      data: { projectId: this.projectId, interior: interior },
    });

    dialogRef.afterClosed().subscribe(() => {
      this.getInteriorData();
    });
  }

  updateDialog(interior: InteriorTour): void {
    const dialogRef = this.dialog.open(NewInteriorComponent, {
      width: "450px",
      disableClose: true,
      data: { projectId: this.projectId, interior: interior },
    });

    dialogRef.afterClosed().subscribe(() => {
      this.getInteriorData();
    });
  }

  getInteriorData() {
    this.uiService.show();

    this.interiorService.getAllInteriorTowers(this.projectId).subscribe(
      (data) => {
        this.isInteriorsLoaded = true;
        this.interiorList = data.interiors;
        this.equirectangularImageCheck();
        this.filteredInteriorList = [...this.interiorList];

        this.filteredInteriorList.forEach((interior) => {
          interior.floorWalkthough = interior.floorWalkthough.map(
            (walkthrough) => {
              // add "isLoadingTours" attribute to each walkthrough object
              return {
                ...walkthrough,
                isLoadingTours: false,
              };
            }
          );
        });

        this.uiService.hide();
        const fieldIssueObject = this.fieldIssueService.getFieldIssueObject();
        //code to view shared info
        const shareId = this.localStorage.getShareId();
        if (!!shareId || !!fieldIssueObject) {
          const sharedObject = !!fieldIssueObject
            ? fieldIssueObject
            : this.shareService.getShareObject();
          if (sharedObject.tillVirtualTourList) {
            this.localStorage.removeShareId();
            this.shareService.setShareObject(null);
          } else {
            const interiorShared = this.filteredInteriorList.find(
              (interior) => interior.interiorId == sharedObject.interiorId
            );
            const towerShared = interiorShared.floorWalkthough.find(
              (walkthough) => walkthough.towerId == sharedObject.towerId
            );

            this.uiService.show();
            this.interiorService
              .getWalkthroughForTower(
                this.projectId,
                towerShared.interiorId,
                towerShared.towerId
              )
              .subscribe(({ tours }) => {
                towerShared.tours = tours;
                const tourShared = towerShared.tours.find(
                  (tour) => tour.tourId == sharedObject.tourId
                );
                this.localStorage.removeShareId();
                this.shareService.setShareObject(null);
                this.visitWalkthrough(
                  tourShared,
                  towerShared,
                  false,
                  sharedObject.imageId
                );
                this.uiService.hide();
              });
          }
        }
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  equirectangularImageCheck() {
    this.interiorList.forEach((interior) => {
      const interiorId = interior.interiorId;
      this.equirectangularImageService
        .getImageData(interiorId, this.projectId)
        .subscribe((data) => {
          if (data["EquirectangularImageData"].length !== 0) {
            const imageData = data["EquirectangularImageData"][0].imageData;
            if (imageData.length !== 0) {
              this.equirectangularImageExists = true;
            }
          }
        });
    });
  }

  checkApartmentDetails(walkthrough, tour) {
    this.masterdataService
      .getWorkLocation(this.projectId)
      .subscribe((workLocationData) => {
        const parentLocationId = tour.locationId;
        let floorApartmentExists;
        workLocationData.location.forEach((location) => {
          if (location.parentLocationId === parentLocationId) {
            if (location.level3) {
              floorApartmentExists = true;
            }
          }
        });
        if (tour.floorPlanBlobId && floorApartmentExists) {
          this.apartmentDetailsExist = true;
        } else {
          this.apartmentDetailsExist = false;
        }
      });
  }

  confirmDialog(interior: InteriorTour): void {
    const successBtn = this.ts.instant("dialog.deleteBtn");
    const icon = "warning";
    const message = this.ts.instant("dialog.messages.removeInterior");
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.virtualTourDeleteTitle"),
      message,
      successBtn,
      icon
    );
    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.uiService.show();

        this.interiorService
          .destroy(this.projectId, interior.interiorId)
          .subscribe(
            () => {
              this.uiService.hide();
              const alert = this.ts.instant(
                "interior.list.messages.tourDeleteSuccess"
              );
              this.snackService.successSnackBar(alert);
              this.getInteriorData();
            },
            (err) => {
              this.uiService.hide();
              const alert = this.ts.instant(
                "interior.list.messages.tourDeleteFail"
              );
              this.snackService.errorSnackBar(alert);
              this.errors = err;
            }
          );
      }
    });
  }

  viewCompareBIM(tower: any) {
    this.uiService.show();

    this.interiorService
      .getWalkthroughForTower(this.projectId, tower.interiorId, tower.towerId)
      .subscribe(({ tours }) => {
        this.uiService.hide();

        tower.tours = tours;
        let towerList = tower.tours.filter((t) => t.isPublished);
        this.visitWalkthrough(towerList[0], tower, true);
      });
  }

  visitWalkthrough(
    walkthrough: TourImage,
    tower: InteriorTour,
    showBimByDefault: boolean,
    sharedImageId: string = null
  ) {
    if (walkthrough.isPublished && walkthrough.images.length > 0) {
      let towerList = tower.tours.filter((t) => t.isPublished && t.isActive);

      const dialogRef = this.dialog.open(WalkthroughComponent, {
        panelClass: "full-screen-dialog",
        disableClose: true,
        data: {
          tourListData: towerList,
          tour: walkthrough,
          towerName: tower.towerName,
          projectId: this.projectId,
          interiorId: tower.interiorId,
          interiors: this.interiorList,
          towerId: tower.towerId,
          bim: tower.bim,
          showBimByDefault,
          imageId: sharedImageId,
          excludeCaptureDateForInterior: this.excludeCaptureDateForInterior,
        },
      });

      dialogRef.afterClosed().subscribe(() => {
        this.getInteriorData();
      });
    }
  }

  updateTower(tower) {
    if (tower) {
      let remarkDialogRef: any;
      remarkDialogRef = this.dialog.open(UpdateTowerComponent, {
        width: "450px",
        disableClose: true,
        data: {
          projectId: this.projectId,
          towerId: tower.towerId,
          interiorId: tower.interiorId,
          towerName: tower.towerName,
          captureDate: tower.captureDate,
        },
      });

      remarkDialogRef.afterClosed().subscribe(({ reloadRequired = false }) => {
        if (reloadRequired) this.getInteriorData();
      });
    }
  }

  uploadProgressCharts(tower) {
    const dialogRef = this.dialog.open(NewChartComponent, {
      width: "50%",
      disableClose: true,
      data: {
        projectId: this.projectId,
        interiorId: tower.interiorId,
        towerId: tower.towerId,
      },
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getInteriorData();
    });
  }

  applyFilter(filterValue: string) {
    if (filterValue !== "") {
      this.filteredInteriorList = this.interiorList.filter(
        (interior) =>
          interior.interiorName
            .toLowerCase()
            .includes(filterValue.trim().toLowerCase()) ||
          interior.tagList?.find((item) =>
            item.toLowerCase().includes(filterValue.trim().toLowerCase())
          )
      );
    } else {
      this.filteredInteriorList = this.interiorList;
    }
  }

  getStatusOfTheTour(statusCode: string) {
    switch (statusCode) {
      case "VW10001":
        return "Waiting for data";
      case "VW10003":
        return "Ready for visualization";
      default:
        break;
    }
  }

  getFloorCount(interiorTour: InteriorTour, field: string) {
    return interiorTour
      ? interiorTour.floorWalkthough
          .map((item) => item[field])
          .reduce((prev, next) => prev + next, 0)
      : 0;
  }

  getWalkthroughCountForTour(interiorTour: InteriorTour) {
    const publishedCount = this.getFloorCount(interiorTour, "publishedCount");
    const totalCount = this.getFloorCount(interiorTour, "totalCount");

    return `${publishedCount} of ${totalCount} published`;
  }

  uploadFloorPlan(walkthrough: any, tour: TourImage) {
    const dialogRef = this.dialog.open(NewFloorPlanComponent, {
      width: "600px",
      disableClose: true,
      data: {
        projectId: tour.projectId,
        tourId: tour.tourId,
        blobContentId: tour.floorPlanBlobId,
      },
    });

    dialogRef.afterClosed().subscribe(() => {
      this.fetchToursDataOnExpand(walkthrough);
    });
  }

  uploadChart(walkthrough: any, tour: TourImage) {
    const dialogRef = this.dialog.open(NewChartComponent, {
      width: "50%",
      disableClose: true,
      data: {
        projectId: tour.projectId,
        interiorId: tour.interiorId,
        tourId: tour.tourId,
      },
    });

    dialogRef.afterClosed().subscribe(() => {
      this.fetchToursDataOnExpand(walkthrough);
    });
  }

  updateTourDetails(tower, tour) {
    if (tower && tour) {
      let remarkDialogRef: any;
      remarkDialogRef = this.dialog.open(UpdateTourComponent, {
        width: "450px",
        disableClose: true,
        data: {
          projectId: this.projectId,
          tourId: tour.tourId,
          interiorId: tower.interiorId,
          tourName: tour.tourName,
        },
      });

      remarkDialogRef.afterClosed().subscribe(() => {
        this.fetchToursDataOnExpand(tower);
      });
    }
  }

  deleteTour(walkthrough: any, tour: TourImage) {
    const successBtn = this.ts.instant("dialog.deleteBtn");
    const icon = "warning";
    const message = this.ts.instant("dialog.messages.removeWalkthrough");
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.walkthroughDeleteTitle"),
      message,
      successBtn,
      icon
    );
    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.interiorService
          .removeTour(this.projectId, tour.interiorId, tour.tourId)
          .subscribe(
            () => {
              let alert = this.ts.instant(
                "interior.tourList.messages.walkthroughDeleteSuccess"
              );
              this.snackService.successSnackBar(alert);
              this.fetchToursDataOnExpand(walkthrough);
            },
            (err) => {
              let alert = this.ts.instant(
                "interior.tourList.messages.walkthroughDeleteFail"
              );
              this.snackService.successSnackBar(alert);
              this.errors = err;
            }
          );
      }
    });
  }

  generateShareLink(tour) {
    const shareInfo: any = {
      clientId: this.localStorage.getClientId(),
      projectId: this.projectId,
      interiorId: tour.interiorId,
      towerId: tour.towerId,
      tourId: tour.tourId,
    };
    this.projectSvc
      .generateShareLink("interior", tour.tourId, shareInfo)
      .subscribe(
        (data: any) => {
          this.isOpen = true;
          const share = data.share;
          this.shareLink = eval("`" + this.config.shareUrl + "`");
        },
        (error) => {
          this.errors = error;
        }
      );
  }

  copyShareLink() {
    if (!!this.shareLink) {
      this.clipboard.copy(this.shareLink);
      this.snackService.successSnackBar(
        this.ts.instant("general.messages.copyLink")
      );
    }
  }

  publishPlannedData(walkthrough, tour) {
    this.interiorService
      .publishWBSTourData(
        this.projectId,
        tour.interiorId,
        tour.tourId,
        tour.towerId,
        tour.locationId
      )
      .subscribe(
        () => {
          let alert = this.ts.instant(
            "interior.list.messages.dataPublishedSuccessfully"
          );
          this.snackService.successSnackBar(alert);
          this.fetchToursDataOnExpand(walkthrough);
        },
        (err) => {
          let alert = this.ts.instant(
            "interior.list.messages.failedToPublishData"
          );
          this.snackService.successSnackBar(alert);
          this.errors = err;
        }
      );
  }

  splitScreenView(tower) {
    this.uiService.show();

    this.interiorService
      .getWalkthroughForTower(this.projectId, tower.interiorId, tower.towerId)
      .subscribe(({ tours }) => {
        this.uiService.hide();

        tower.tours = tours;

        let towerList: TourImage[];
        if (tower.tours && tower.tours.length > 0) {
          towerList = tower.tours.filter((t) => t.isPublished);
          if (towerList.length > 0) {
            const dialogRef = this.dialog.open(WalkthroughSplitComponent, {
              panelClass: "full-screen-dialog",
              disableClose: true,
              data: {
                tourListData: towerList,
                tour: towerList[0],
                towerName: tower.towerName,
                towerId: tower.towerId,
                projectId: this.projectId,
              },
            });
            dialogRef.afterClosed().subscribe(() => this.getInteriorData());
          }
        }
      });
  }

  reportDialog(interiorTour: InteriorTour): void {
    const dialogRef = this.dialog.open(ReportComponent, {
      width: "90%",
      height: "88%",
      disableClose: true,
      data: { tour: { ...interiorTour }, projectId: this.projectId },
    });

    dialogRef.afterClosed().subscribe(() => {});
  }

  isUserProjectAdmin() {
    let user = this.projectUsers.find((user) => user.email === this.user.email);
    return user && user.role.code === "Project Admin" ? true : false;
  }

  clearWalkthroughData(walkthrough: any) {
    walkthrough.tours = [];
    if (this.subscription) this.subscription.unsubscribe();
  }

  fetchToursDataOnExpand(walkthrough: any) {
    walkthrough.isLoadingTours = true;
    walkthrough.tours = [];

    this.subscription = this.interiorService
      .getWalkthroughForTower(
        this.projectId,
        walkthrough.interiorId,
        walkthrough.towerId
      )
      .pipe(
        switchMap((response: any) => {
          walkthrough.tours = response.tours;
          this.changeDetectorRef.detectChanges();

          walkthrough.isLoadingTours = false;
          return this.interiorService.getTourProcessingStats(
            this.projectId,
            walkthrough.interiorId,
            walkthrough.towerId
          );
        })
      )
      .subscribe(({ data }) => {
        walkthrough.tours = walkthrough.tours.reduce((acc, tour) => {
          const processingStat = data.find(
            (stats) => stats.tourId === tour.tourId
          );
          if (processingStat) {
            acc.push({
              ...tour,
              isProcessing: !processingStat.isProcessingComplete,
            });
          } else {
            acc.push(tour);
          }
          return acc;
        }, []);
        this.changeDetectorRef.detectChanges();
      });
  }

  getShareLinkObservable(interiorTour) {
    const shareInfo: any = {
      clientId: this.localStorage.getClientId(),
      projectId: this.projectId,
      interiorId: interiorTour.interiorId,
      tillVirtualTourList: true,
    };
    return this.projectSvc.generateShareLink(
      "interior",
      this.projectId, // sharing projectId as the ObjectId to be saved for share URL
      shareInfo
    );
  }

  sendEmailNotification(interiorTour: InteriorTour) {
    const message = this.ts.instant("dialog.messages.emailNotifyUsers");
    const successBtn = this.ts.instant("dialog.notifyBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.emailNotifyTitle"),
      message,
      successBtn,
      icon
    );

    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        const shareLinkObs = this.getShareLinkObservable(interiorTour);
        shareLinkObs.subscribe(
          (data: any) => {
            const share = data.share;
            this.shareLink = eval("`" + this.config.shareUrl + "`");
            const floorPublishedCount = this.getFloorCount(
              this.interiorList.find(
                ({ interiorId }) => interiorId == interiorTour.interiorId
              ),
              "publishedCount"
            );
            this.interiorService
              .emailNotifyUsers(
                this.projectId,
                interiorTour.interiorId,
                this.shareLink,
                floorPublishedCount
              )
              .subscribe(
                (data) => {
                  const alert = this.ts.instant(
                    "exterior.list.messages.notifiedUsersSuccesfully"
                  );
                  this.snackService.successSnackBar(alert);
                },
                (err) => {
                  const alert = this.ts.instant(
                    "exterior.list.messages.notifingUsersFailed"
                  );
                  this.snackService.errorSnackBar(alert);
                  this.errors = err;
                }
              );
          },
          (error) => {
            this.errors = error;
          }
        );
      }
    });
  }

  openEquirectangularViewer(interiorTour) {
    const interiorId = interiorTour.interiorId;
    this.equirectangularImageService
      .getImageData(interiorId, this.projectId)
      .subscribe((data) => {
        if (data?.["EquirectangularImageData"]?.length !== 0) {
          this.equirectangularImageService.open360ImageViewer(
            this.projectId,
            interiorId
          );
          const url = `https://viewer.huviair.com:444/${interiorId}/${this.projectId}/viewer`;
          window.open(url, "_blank");
        } else if (
          data?.["EquirectangularImageData"]?.imageData?.length !== 0 ||
          !data?.["EquirectangularImageData"]
        ) {
          let alert;
          alert = this.ts.instant("interior.list.messages.noImageData");
          this.snackService.errorSnackBar(alert);
        }
      });
  }

  uploadEquirectangularImage(walkthrough, tour) {
    const dialogRef = this.dialog.open(UploadEquirectangularImageComponent, {
      width: "40%",
      panelClass: "modal-round-corner",
      disableClose: true,
      data: {
        tour: tour,
        projectId: this.projectId,
        walkthroughData: walkthrough,
      },
    });

    dialogRef.afterClosed().subscribe(() => {
      this.getInteriorData();
      this.fetchToursDataOnExpand(walkthrough);
    });
  }

  uploadApartmentSnapshots(walkthrough, tour) {
    const dialogRef = this.dialog.open(UploadApartmentSnapshotsComponent, {
      width: "40%",
      panelClass: "modal-round-corner",
      disableClose: true,
      data: {
        tour: tour,
        projectId: this.projectId,
        walkthroughData: walkthrough,
      },
    });

    dialogRef.afterClosed().subscribe(() => {
      this.fetchToursDataOnExpand(walkthrough);
    });
  }

  tagInterior(interior: InteriorTour) {
    const dialogRef = this.dialog.open(InteriorTagComponent, {
      width: "45%",
      disableClose: true,
      data: { projectId: this.projectId, interior: interior },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((data) => {
      this.getInteriorData();
    });
  }
}
