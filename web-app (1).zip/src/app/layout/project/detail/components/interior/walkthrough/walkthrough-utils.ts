import { ConnectionPositionPair } from "@angular/cdk/overlay";
import { chain } from "lodash";

export const bimSvgIcon = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
<g id="surface1">
<path style="fill-rule:nonzero;fill:rgb(33.72549%,35.686275%,40%);fill-opacity:1;stroke-width:1;stroke-linecap:butt;stroke-linejoin:miter;stroke:rgb(78.431373%,76.078431%,76.078431%);stroke-opacity:1;stroke-miterlimit:4;" d="M 9.99349 0.504557 L 90.00651 0.504557 C 95.247396 0.504557 99.495443 4.752604 99.495443 9.99349 L 99.495443 90.00651 C 99.495443 95.247396 95.247396 99.495443 90.00651 99.495443 L 9.99349 99.495443 C 4.752604 99.495443 0.504557 95.247396 0.504557 90.00651 L 0.504557 9.99349 C 0.504557 4.752604 4.752604 0.504557 9.99349 0.504557 Z M 9.99349 0.504557 " transform="matrix(0.24,0,0,0.24,0,0)"/>
<path style=" stroke:none;fill-rule:nonzero;fill:rgb(85.098039%,85.098039%,85.098039%);fill-opacity:1;" d="M 16.078125 0 L 21.601562 0 C 22.925781 0 24 1.074219 24 2.398438 L 24 7.199219 L 18.480469 7.199219 C 17.15625 7.199219 16.078125 6.125 16.078125 4.800781 Z M 16.078125 0 "/>
<path style="fill-rule:nonzero;fill:rgb(0%,0%,0%);fill-opacity:0.101961;stroke-width:1;stroke-linecap:butt;stroke-linejoin:miter;stroke:rgb(78.431373%,76.078431%,76.078431%);stroke-opacity:1;stroke-miterlimit:4;" d="M 9.99349 0.504557 L 90.00651 0.504557 C 95.247396 0.504557 99.495443 4.752604 99.495443 9.99349 L 99.495443 90.00651 C 99.495443 95.247396 95.247396 99.495443 90.00651 99.495443 L 9.99349 99.495443 C 4.752604 99.495443 0.504557 95.247396 0.504557 90.00651 L 0.504557 9.99349 C 0.504557 4.752604 4.752604 0.504557 9.99349 0.504557 Z M 9.99349 0.504557 " transform="matrix(0.24,0,0,0.24,0,0)"/>
<path style="fill:none;stroke-width:3;stroke-linecap:round;stroke-linejoin:miter;stroke:rgb(100%,100%,100%);stroke-opacity:1;stroke-miterlimit:4;" d="M 21.500651 17.496745 L 50.504557 17.496745 " transform="matrix(0.24,0,0,0.24,0,0)"/>
<path style="fill:none;stroke-width:3;stroke-linecap:round;stroke-linejoin:miter;stroke:rgb(100%,100%,100%);stroke-opacity:1;stroke-miterlimit:4;" d="M 21.500651 35.498047 L 50.504557 35.498047 " transform="matrix(0.24,0,0,0.24,0,0)"/>
<path style="fill:none;stroke-width:3;stroke-linecap:round;stroke-linejoin:miter;stroke:rgb(100%,100%,100%);stroke-opacity:1;stroke-miterlimit:4;" d="M 21.500651 55.501302 L 78.499349 55.501302 " transform="matrix(0.24,0,0,0.24,0,0)"/>
<path style=" stroke:none;fill-rule:nonzero;fill:rgb(100%,100%,100%);fill-opacity:1;" d="M 8.085938 19.046875 C 8.320312 19.097656 8.507812 19.214844 8.648438 19.398438 C 8.792969 19.578125 8.863281 19.785156 8.863281 20.019531 C 8.863281 20.359375 8.742188 20.625 8.503906 20.828125 C 8.269531 21.023438 7.941406 21.121094 7.519531 21.121094 L 5.636719 21.121094 L 5.636719 17.078125 L 7.457031 17.078125 C 7.867188 17.078125 8.1875 17.171875 8.417969 17.359375 C 8.652344 17.546875 8.769531 17.800781 8.769531 18.125 C 8.769531 18.363281 8.707031 18.5625 8.582031 18.71875 C 8.457031 18.875 8.292969 18.984375 8.085938 19.046875 Z M 6.621094 18.710938 L 7.265625 18.710938 C 7.429688 18.710938 7.550781 18.679688 7.636719 18.609375 C 7.722656 18.535156 7.769531 18.429688 7.769531 18.292969 C 7.769531 18.152344 7.722656 18.046875 7.636719 17.976562 C 7.550781 17.902344 7.429688 17.867188 7.265625 17.867188 L 6.621094 17.867188 Z M 7.347656 20.324219 C 7.511719 20.324219 7.640625 20.289062 7.726562 20.214844 C 7.820312 20.140625 7.867188 20.03125 7.867188 19.886719 C 7.867188 19.746094 7.816406 19.632812 7.722656 19.554688 C 7.628906 19.472656 7.5 19.433594 7.335938 19.433594 L 6.621094 19.433594 L 6.621094 20.324219 Z M 11.640625 17.078125 L 11.640625 21.121094 L 10.65625 21.121094 L 10.65625 17.078125 Z M 18.152344 17.078125 L 18.152344 21.121094 L 17.167969 21.121094 L 17.167969 18.695312 L 16.265625 21.121094 L 15.46875 21.121094 L 14.558594 18.6875 L 14.558594 21.121094 L 13.574219 21.121094 L 13.574219 17.078125 L 14.738281 17.078125 L 15.871094 19.875 L 16.996094 17.078125 Z M 18.152344 17.078125 "/>
</g></svg>`;

export const linkIcon = `<svg class="svg" width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
<path d="M5.525 13.657l2.652-2.652.707.707-2.652 2.652c-1.269 1.27-3.327 1.27-4.596 0-1.27-1.27-1.27-3.327 0-4.596l2.652-2.652.707.707-2.652 2.652c-.879.879-.879 2.303 0 3.182.879.879 2.303.879 3.182 0zm6.187-4.773l-.707-.707 2.652-2.652c.879-.879.879-2.303 0-3.182-.879-.879-2.303-.879-3.182 0L7.823 4.995l-.707-.707 2.652-2.652c1.269-1.27 3.327-1.27 4.596 0 1.27 1.27 1.27 3.327 0 4.596l-2.652 2.652zm-5.45 1.62l4.242-4.242-.766-.766-4.242 4.242.766.766z" fill-rule="nonzero" fill-opacity="1" fill="#000" stroke="none"></path>
</svg>`;

export const editPathIcon = `<?xml version="1.0" standalone="no"?> <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN"
 "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd"> <svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="64.000000pt" height="64.000000pt" viewBox="0 0 64.000000 64.000000"
 preserveAspectRatio="xMidYMid meet">
<g transform="translate(0.000000,64.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M455 629 c-87 -25 -120 -131 -71 -228 31 -63 73 -118 98 -132 16 -9
26 -4 57 30 21 22 50 66 65 97 52 106 20 208 -73 234 -41 11 -36 11 -76 -1z
m83 -123 c4 -33 -13 -56 -42 -56 -30 0 -46 18 -46 52 0 54 82 57 88 4z"/>
<path d="M272 278 c-21 -21 -13 -40 60 -136 56 -74 68 -96 57 -103 -8 -5 -61
-9 -117 -9 -78 0 -103 -3 -100 -12 3 -9 35 -14 104 -16 105 -2 146 9 152 41 2
11 -26 57 -67 111 -39 51 -71 96 -71 99 0 4 20 7 44 7 49 0 76 7 76 21 0 14
-124 11 -138 -3z"/>
<path d="M35 214 c-24 -22 -27 -31 -23 -73 6 -57 52 -131 83 -131 26 0 74 68
82 114 8 51 -4 84 -37 101 -42 22 -73 19 -105 -11z m80 -64 c0 -16 -6 -26 -18
-28 -19 -4 -32 20 -23 44 9 25 41 13 41 -16z"/>
</g>
</svg>
`;
export const fieldIssueIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="25" height="23" viewBox="0 0 25 23" fill="none">
<path d="M10.8603 0.62485C11.7659 -0.208285 13.2341 -0.208282 14.1397 0.624851L24.3208 9.99148C25.2264 10.8246 25.2264 12.1754 24.3208 13.0085L14.1397 22.3752C13.2341 23.2083 11.7659 23.2083 10.8603 22.3751L0.679185 13.0085C-0.226396 12.1754 -0.226394 10.8246 0.679186 9.99148L10.8603 0.62485ZM13.0466 1.63053C12.7447 1.35282 12.2553 1.35282 11.9534 1.63053L1.77232 10.9972C1.47046 11.2749 1.47046 11.7251 1.77232 12.0028L11.9534 21.3695C12.2553 21.6472 12.7447 21.6472 13.0466 21.3695L23.2277 12.0028C23.5295 11.7251 23.5295 11.2749 23.2277 10.9972L13.0466 1.63053Z" fill="#2D4059"/>
<path d="M10.9399 15.8125C10.9399 15.0186 11.6395 14.375 12.5024 14.375C13.3654 14.375 14.0649 15.0186 14.0649 15.8125C14.0649 16.6064 13.3654 17.25 12.5024 17.25C11.6395 17.25 10.9399 16.6064 10.9399 15.8125Z" fill="#2D4059"/>
<path d="M11.093 7.18037C11.0097 6.41453 11.6634 5.75 12.5 5.75C13.3366 5.75 13.9903 6.41453 13.907 7.18037L13.359 12.2223C13.3149 12.6283 12.9435 12.9375 12.5 12.9375C12.0565 12.9375 11.6851 12.6283 11.641 12.2223L11.093 7.18037Z" fill="#2D4059"/>
</svg>`;

export const filterIcon = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 15C4.13401 15 1 11.866 1 8C1 4.13401 4.13401 1 8 1C11.866 1 15 4.13401 15 8C15 11.866 11.866 15 8 15ZM8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z" fill="black"/>
<path d="M7 11.5C7 11.2239 7.22386 11 7.5 11H8.5C8.77614 11 9 11.2239 9 11.5C9 11.7761 8.77614 12 8.5 12H7.5C7.22386 12 7 11.7761 7 11.5Z" fill="black"/><path d="M5 8.5C5 8.22386 5.22386 8 5.5 8H10.5C10.7761 8 11 8.22386 11 8.5C11 8.77614 10.7761 9 10.5 9H5.5C5.22386 9 5 8.77614 5 8.5Z" fill="black"/>
<path d="M3 5.5C3 5.22386 3.22386 5 3.5 5H12.5C12.7761 5 13 5.22386 13 5.5C13 5.77614 12.7761 6 12.5 6H3.5C3.22386 6 3 5.77614 3 5.5Z" fill="black"/>
</svg>`;

export const filterAppliedIcon = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16ZM3.5 5H12.5C12.7761 5 13 5.22386 13 5.5C13 5.77614 12.7761 6 12.5 6H3.5C3.22386 6 3 5.77614 3 5.5C3 5.22386 3.22386 5 3.5 5ZM5 8.5C5 8.22386 5.22386 8 5.5 8H10.5C10.7761 8 11 8.22386 11 8.5C11 8.77614 10.7761 9 10.5 9H5.5C5.22386 9 5 8.77614 5 8.5ZM7 11.5C7 11.2239 7.22386 11 7.5 11H8.5C8.77614 11 9 11.2239 9 11.5C9 11.7761 8.77614 12 8.5 12H7.5C7.22386 12 7 11.7761 7 11.5Z" fill="black"/>
</svg>`;

export const cdkConnectionPairs: ConnectionPositionPair[] = [
  {
    offsetX: -14,
    originX: "start",
    originY: "top",
    overlayX: "end",
    overlayY: "top",
    panelClass: null,
  },
];

export const cdkConnectionPairsProjectProgress: ConnectionPositionPair[] = [
  {
    offsetX: -14,
    offsetY: -22.5,
    originX: "start",
    originY: "top",
    overlayX: "end",
    overlayY: "top",
    panelClass: null,
  },
];

export const cdkConnectionPairsFieldIssueList: ConnectionPositionPair[] =
  cdkConnectionPairsProjectProgress;

export const cdkConnectionPairsFieldIssueDetails: ConnectionPositionPair[] = [
  {
    offsetX: -14,
    offsetY: -22.5,
    originX: "start",
    originY: "top",
    overlayX: "end",
    overlayY: "top",
    panelClass: null,
  },
];

export const cdkConnectionPairsProcoreObservationDetails: ConnectionPositionPair[] =
  [
    {
      offsetX: -14,
      offsetY: -22.5,
      originX: "start",
      originY: "top",
      overlayX: "end",
      overlayY: "top",
      panelClass: null,
    },
  ];

export const cdkConnectionPairsPunchList: ConnectionPositionPair[] = [
  {
    offsetX: -14,
    offsetY: -22.5,
    originX: "start",
    originY: "top",
    overlayX: "end",
    overlayY: "top",
    panelClass: null,
  },
];

export function uuidv4() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c == "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export function sortTourFeatures(features) {
  return chain(features)
    .uniqBy("properties.imageNumber")
    .orderBy(({ properties }) => properties.imageNumber, ["asc"])
    .value();
}

export function prepareCanvasAndDraw(
  width: number,
  height: number,
  image: CanvasImageSource,
  textToDraw: string
) {
  let percentOfCanvasHeightToDraw = 5;
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");

  canvas.width = width;
  canvas.height = height;

  context.drawImage(image, 0, 0);

  context.font = "30px Poppins";

  // Get width of the text to draw
  var textWidth = context.measureText(textToDraw).width;

  context.fillRect(
    0,
    height - height * (percentOfCanvasHeightToDraw / 100),
    textWidth + 40,
    height * (percentOfCanvasHeightToDraw / 100)
  );

  context.fillStyle = "white";
  context.fillText(
    textToDraw,
    20,
    height - height * (percentOfCanvasHeightToDraw / 240)
  );

  return canvas;
}

export const cdkConnectionPairsImageEditor: ConnectionPositionPair[] = [
  {
    offsetX: -24,
    offsetY: -10,
    originX: "start",
    originY: "top",
    overlayX: "end",
    overlayY: "top",
    panelClass: null,
  },
];

export class ImageEnhancementProps {
  constructor(public brightness: number, public sharpness: number) {}

  public get brightnessValue(): string {
    return `${this.brightness}%`;
  }
  public get sharpnessValue(): string {
    return `${this.sharpness}%`;
  }
  public resetValues() {
    this.brightness = 100;
    this.sharpness = 100;
  }
}
