import { DatePipe } from "@angular/common";
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ConfirmDialogModule } from "src/app/layout/components/confirm-dialog/confirm-dialog.module";
import { SharedModule } from "src/app/shared";
import { InteriorRoutingModule } from "./interior-routing.module";
import { InteriorComponent } from "./interior.component";
import { NewInteriorComponent } from "./list/new/new-interior.component";
import { InteriorListComponent } from "./list/interior-list.component";
import { UploadDataComponent } from "./upload/upload-data.component";
import { NewChartComponent } from "./new-chart/new-chart.component";
import { InteriorDashboardComponent } from "./dashboard/dashboard.component";
import { StaticMapComponent } from "./static-map/static-map.component";
import { StaticTourViewerComponent } from "./static-tour-viewer/static-tour-viewer.component";
import { WalkthroughComponent } from "./walkthrough/walkthrough.component";
import { NewFloorPlanComponent } from "./floor-plan/new-plan.component";
import { RemarkDiscussionComponent } from "./discussion/remark-discussion.component";
import { WalkthroughSplitComponent } from "./walkthrough-split/walkthrough-split.component";
import { PanViewerComponent } from "./walkthrough-split/pan-viewer/pan-viewer.component";
import { FloorPlanComponent } from "./walkthrough-split/floor-plan/floor-plan.component";
import { NewTaskComponent } from "./walkthrough/new-task/new-task.component";
import { ResizableDraggableComponent } from "./walkthrough/resizable-draggable/resizable-draggable.component";
import { FloorPlanAnnotationComponent } from "./walkthrough/floor-plan/floor-plan.component";
import { UpdateTowerComponent } from "./list/update-tour/update-tower/update-tower.component";
import { UpdateTourComponent } from "./list/update-tour/update-tour.component";
import {
  ActivityChartComponent,
  ProgressChartComponent,
} from "./progress-chart/progress-chart.component";
import { ProjectProgressComponent } from "./progress/progress.component";
import { BimViewerComponent } from "./bim-viewer/bim-viewer.component";
import { ReportComponent } from "./report/report.component";
import { SimpleAlertModule } from "src/app/layout/components/simple-alert/simple-alert.module";
import { DatetimeLocalePipe } from "src/app/shared/pipe/datetime-locale.pipe";
import { FieldIssueListComponent } from "./walkthrough/field-issue-list/field-issue-list.component";
import { FieldIssueDetailComponent } from "./walkthrough/field-issue-detail/field-issue-detail.component";
import { ActivityComponent } from "./walkthrough/activity/activity.component";
import { FloorPlanConfigComponent } from "./walkthrough/floor-plan-config/floor-plan-config.component";
import { NewProcoreObservationComponent } from "./walkthrough/new-procore-observation/new-procore-observation.component";
import { OnlyNumberModule } from "src/app/shared/directive/onlynumber.module";
import { UploadEquirectangularImageComponent } from "./upload-equirectangular-image/upload-equirectangular-image.component";
import { InteriorTagComponent } from "./tag/interior-tag.component";
import { UploadApartmentSnapshotsComponent } from './upload-apartment-snapshots/upload-apartment-snapshots.component';
@NgModule({
  imports: [
    InteriorRoutingModule,
    SharedModule,
    ConfirmDialogModule,
    SimpleAlertModule,
    OnlyNumberModule,
  ],
  declarations: [
    InteriorComponent,
    UploadDataComponent,
    NewChartComponent,
    InteriorDashboardComponent,
    InteriorListComponent,
    NewInteriorComponent,
    StaticMapComponent,
    StaticTourViewerComponent,
    WalkthroughComponent,
    NewFloorPlanComponent,
    RemarkDiscussionComponent,
    WalkthroughSplitComponent,
    PanViewerComponent,
    FloorPlanComponent,
    NewTaskComponent,
    ResizableDraggableComponent,
    FloorPlanAnnotationComponent,
    UpdateTowerComponent,
    UpdateTourComponent,
    ProgressChartComponent,
    ProjectProgressComponent,
    BimViewerComponent,
    ReportComponent,
    ActivityChartComponent,
    FieldIssueListComponent,
    FieldIssueDetailComponent,
    NewProcoreObservationComponent,
    ActivityComponent,
    FloorPlanConfigComponent,
    UploadEquirectangularImageComponent,
    InteriorTagComponent,
    UploadApartmentSnapshotsComponent,
  ],
  providers: [
    { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} },
    DatePipe,
    DatetimeLocalePipe,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [FieldIssueDetailComponent],
})
export class InteriorModule {}
