import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";

import {
  InteriorDialogData,
  UserService,
  User,
  ProjectChart,
  StaticUrl,
  InteriorService,
  SnackbarService,
  Lookup,
} from "src/app/core";
import { ActivatedRoute, Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";
import * as XLSX from "xlsx";
type AOA = any[][];

@Component({
  selector: "static-map",
  templateUrl: "./static-map.component.html",
  styleUrls: ["./static-map.component.scss"],
})
export class StaticMapComponent implements OnInit {
  @ViewChild("uploadCharts") uploadCharts: any;
  showUploadCharts: boolean = false;
  tourName: string;
  tourUrl: string;
  displayedColumns: string[] = ["tourName", "tourUrl", "action"];
  dataSource = [];
  tour: StaticUrl = {} as StaticUrl;
  projectId: string = "";
  interiorId: string = "";
  result: string = "";
  errors: any;
  fileData: any;
  dataError: boolean = false;
  uploadedFiles: any[] = [];
  projectCharts: ProjectChart[] = [];
  chart: ProjectChart = {} as ProjectChart;
  charts: any = [];
  uploadChartForm: UntypedFormGroup;
  selectedFile: string;
  currentUser: User;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private interiorService: InteriorService,
    private route: ActivatedRoute,
    private snackService: SnackbarService,
    private usrService: UserService,
    private ts: TranslateService
  ) {
    this.currentUser = this.usrService.getCurrentUser();
    this.uploadChartForm = this.fb.group({
      layer: [""],
    });
  }

  public ngOnInit(): void {
    this.projectId = this.data.projectId;
    this.interiorId = this.data.interior.interiorId;
    this.getTourData(this.data.interior);
  }

  getTourData(interior) {
    this.dataSource = interior.staticMap.urls ? interior.staticMap.urls : [];
    this.charts = interior.staticMap.charts ? interior.staticMap.charts : [];
  }

  saveTourData() {
    let alert: string = "";
    if (this.tourName.trim() && this.tourUrl.trim()) {
      this.tour.tourName = this.tourName.trim();
      this.tour.tourUrl = this.tourUrl.trim();

      this.interiorService
        .saveStaticTourUrl(this.projectId, this.interiorId, this.tour)
        .subscribe(
          (data) => {
            alert = this.ts.instant("interior.staticMap.messages.tourAdded");
            this.snackService.successSnackBar(alert);
            this.getTourData(data);
            this.onReset();
          },
          (err) => {
            alert = this.ts.instant(
              "interior.staticMap.messages.dataSaveFailed"
            );
            this.snackService.errorSnackBar(alert);
          }
        );
    } else {
      alert = this.ts.instant("interior.staticMap.messages.tourDataMissing");
      this.snackService.successSnackBar(alert);
    }
  }

  deleteTourUrl(tour): void {
    const message = this.ts.instant("dialog.messages.removeStaticTour");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.interiorService
          .removeStaticUrl(this.projectId, this.interiorId, tour.tourId)
          .subscribe(
            (data) => {
              this.getTourData(data.interior);
            },
            (err) => {
              this.errors = err;
            }
          );
      }
    });
  }

  onReset() {
    this.tourName = "";
    this.tourUrl = "";
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  uploadNewCharts() {
    this.showUploadCharts = true;
    this.uploadCharts.toggle();
  }

  closeUploadCharts() {
    this.showUploadCharts = false;
    this.uploadCharts.toggle();
  }

  onChartUpload(files) {
    let alert;
    if (!this.isExcelFile(files[0])) {
      alert = this.ts.instant("interior.staticMap.messages.invalidFile");
      this.snackService.errorSnackBar(alert);
      return;
    }
    this.selectedFile = files[0].name;
    this.uploadedFiles.push(files[0]);
    const target: DataTransfer = <DataTransfer>files;
    if (files.length !== 1) throw new Error("Cannot use multiple files");
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: "binary" });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.fileData = <AOA>XLSX.utils.sheet_to_json(ws, {
        header: ["ChartTitle", "ChartType", "ChartData"],
      });
    };
    reader.readAsBinaryString(files[0]);
  }

  uploadData() {
    let alert;
    let charts: ProjectChart[] = [];
    this.fileData.forEach(async (row) => {
      try {
        if (row["ChartData"] !== "Chart Data") {
          let chart: ProjectChart = {} as ProjectChart;
          chart.chartTitle = row["ChartTitle"];
          chart.chartType = row["ChartType"];
          chart.chartData = JSON.parse(row["ChartData"]);
          charts.push(chart);
        }
      } catch (e) {
        this.dataError = true;
        alert = this.ts.instant("interior.staticMap.messages.dataSaveFailed");
        this.snackService.errorSnackBar(alert);
      }
    });

    this.saveChartData(charts);
  }

  saveChartData(charts) {
    let alert;
    if (charts.length === 0) {
      alert = this.ts.instant("interior.staticMap.messages.dataSaveFailed");
      this.snackService.errorSnackBar(alert);
    } else {
      this.interiorService
        .saveStaticTourChart(this.projectId, this.interiorId, charts)
        .subscribe(
          (value) => {
            alert = this.ts.instant(
              "interior.staticMap.messages.uploadSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.getTourData(value);
          },
          (error) => {
            alert = this.ts.instant(
              "interior.staticMap.messages.dataSaveFailed"
            );
            this.snackService.errorSnackBar(alert);
          },
          () => {}
        );
    }
  }

  deleteChart(element: ProjectChart) {
    const message = this.ts.instant("dialog.messages.removeChart");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.interiorService
          .removeStaticChart(this.projectId, this.interiorId, element.chartId)
          .subscribe(
            (data) => {
              this.getTourData(data.interior);
            },
            (err) => {
              this.errors = err;
            }
          );
      }
    });
  }

  isExcelFile(file: File) {
    let fileName = file.name.split(".").pop();
    return fileName === "xls" || fileName === "xlsx" ? true : false;
  }

  publishTour() {
    let alert = "";
    this.interiorService
      .publishStaticTour(this.projectId, this.interiorId)
      .subscribe(
        (value) => {
          alert = this.ts.instant(
            "interior.staticMap.messages.tourPublishSuccessful"
          );
          this.snackService.successSnackBar(alert);
          this.closeDialog();
        },
        (error) => {
          alert = this.ts.instant(
            "interior.staticMap.messages.tourPublishFail"
          );
          this.snackService.errorSnackBar(alert);
          this.closeDialog();
        },
        () => {}
      );
  }
}
