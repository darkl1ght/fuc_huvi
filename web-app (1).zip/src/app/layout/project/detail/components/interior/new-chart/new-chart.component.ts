import { Component, Inject, OnInit } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import {
  InteriorDialogData,
  InteriorService,
  UiService,
  ProjectChart,
  SnackbarService,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import * as XLSX from "xlsx";
type AOA = any[][];

@Component({
  selector: "new-chart",
  templateUrl: "./new-chart.component.html",
  styleUrls: ["./new-chart.component.scss"],
})
export class NewChartComponent implements OnInit {
  uploadedFiles: any[] = [];
  projectCharts: ProjectChart[] = [];
  chart: ProjectChart = {} as ProjectChart;
  fileData: any;
  dataError: boolean = false;
  interiorId: string = "";
  projectId: string;
  tourId: string;
  towerId: string;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private uiService: UiService,
    private interiorService: InteriorService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  public ngOnInit(): void {
    this.projectId = this.data.projectId;
    this.interiorId = this.data.interiorId;
    this.tourId = this.data.tourId;
    this.towerId = this.data.towerId;
  }

  onUpload(files) {
    let alert;
    if (!this.isExcelFile(files[0])) {
      alert = this.ts.instant("interior.newChart.messages.invalidFile");
      this.snackService.errorSnackBar(alert);
      return;
    }

    this.uploadedFiles.push(files[0]);
    const target: DataTransfer = <DataTransfer>files;
    if (files.length !== 1) throw new Error("Cannot use multiple files");
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: "binary" });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.fileData = <AOA>XLSX.utils.sheet_to_json(ws, {
        header: ["ChartTitle", "ChartType", "ChartData"],
      });
    };
    reader.readAsBinaryString(files[0]);
  }

  uploadData() {
    let alert;
    let charts: ProjectChart[] = [];
    this.fileData.forEach(async (row) => {
      try {
        if (row["ChartData"] !== "Chart Data") {
          let chart: ProjectChart = {} as ProjectChart;
          chart.chartTitle = row["ChartTitle"];
          chart.chartType = row["ChartType"];
          chart.chartData = JSON.parse(row["ChartData"]);
          charts.push(chart);
        }
      } catch (e) {
        this.dataError = true;
        alert = this.ts.instant("interior.newChart.messages.uploadFailed");
        this.snackService.errorSnackBar(alert);
        this.uiService.hide();
      }
    });

    if (this.tourId) {
      this.saveChartData(charts, false);
    } else if (this.towerId) {
      this.saveChartDataByTower(charts, false);
    }
  }

  saveChartData(charts, remove: boolean) {
    let alert;
    this.uiService.show();
    if (charts.length === 0 && !remove) {
      alert = this.ts.instant("interior.newChart.messages.uploadFailed");
      this.snackService.errorSnackBar(alert);
      this.uiService.hide();
    } else {
      this.interiorService
        .uploadChart(this.projectId, this.interiorId, this.tourId, charts)
        .subscribe(
          (value) => {
            this.uiService.hide();
            alert = this.ts.instant("interior.newChart.messages.uploadSuccess");
            this.snackService.successSnackBar(alert);
            this.dialog.closeAll();
          },
          (error) => {
            this.uiService.hide();
            alert = this.ts.instant("interior.newChart.messages.uploadFailed");
            this.snackService.errorSnackBar(alert);
          },
          () => {}
        );
    }
  }

  saveChartDataByTower(charts, removechart: boolean) {
    let alert;
    this.uiService.show();
    if (charts.length === 0 && !removechart) {
      alert = this.ts.instant("interior.newChart.messages.uploadFailed");
      this.snackService.errorSnackBar(alert);
      this.uiService.hide();
    } else {
      this.interiorService
        .uploadChartByTower(
          this.projectId,
          this.interiorId,
          this.towerId,
          charts
        )
        .subscribe(
          (value) => {
            this.uiService.hide();
            alert = this.ts.instant("interior.newChart.messages.uploadSuccess");
            this.snackService.successSnackBar(alert);
            this.dialog.closeAll();
          },
          (error) => {
            this.uiService.hide();
            alert = this.ts.instant("interior.newChart.messages.uploadFailed");
            this.snackService.errorSnackBar(alert);
          },
          () => {}
        );
    }
  }

  clearChart() {
    let charts = [];
    if (this.tourId) {
      this.saveChartData(charts, true);
    } else if (this.towerId) {
      this.saveChartDataByTower(charts, true);
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  isExcelFile(file: File) {
    let fileName = file.name.split(".").pop();
    return fileName === "xls" || fileName === "xlsx" ? true : false;
  }
}
