import {
  Component,
  OnInit,
  ViewChild,
  Input,
  Output,
  EventEmitter,
  Inject,
} from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import {
  Lookup,
  LookUpService,
  MasterDataService,
  PunchItem,
  PunchListService,
  PunchListData,
  UiService,
  TourImage,
  Guid,
  StorageService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";
import { MatDialog } from "@angular/material/dialog";
import { FloorPlanAnnotationComponent } from "../floor-plan/floor-plan.component";
import { v4 as uuidv4 } from "uuid";
@Component({
  selector: "new-task",
  templateUrl: "./new-task.component.html",
  styleUrls: ["./new-task.component.scss"],
})
export class NewTaskComponent implements OnInit {
  @ViewChild("newTaskForm") newTaskForm;
  @ViewChild(FloorPlanAnnotationComponent)
  floorPlanComponent: FloorPlanAnnotationComponent;
  @Output() notifyClose: EventEmitter<boolean> = new EventEmitter();
  @Input() projectId: string;
  @Input() tour: TourImage;
  @Input() towerName: string;
  @Input() files: any;
  @Input() currentImageId: string;
  public breakpoint: number;
  public addTaskForm: UntypedFormGroup;
  workPackage = [];
  level1Location = [];
  level2Location = [];
  level3Location = [];
  level4Location = [];
  stage1Approver = [];
  stage2Approver = [];
  priorityList: Lookup[] = [];
  formSubmitAttempt: boolean = false;
  punchListData: PunchListData = {} as PunchListData;
  errors = {};
  wasFormChanged = false;
  masterData: any;
  selectedLocations: string[] = [];
  punchGroupId: string;
  formSubmitted: boolean;

  workPackageId: string;
  dueDate: string;
  level1Approvers: string[] = [];
  level2Approvers: string[] = [];
  accessToken: string;

  validImageExtensions: string[] = ["jpg", "jpeg", "gif", "png"];
  acceptMimeTypes: string = "image/jpeg, image/gif, image/png";
  punchItemAttachmentFiles: FileAttachment[] = [];

  constructor(
    private fb: UntypedFormBuilder,
    private lookupSvc: LookUpService,
    private masterDataSvc: MasterDataService,
    private snackService: SnackbarService,
    private punchListService: PunchListService,
    private uiService: UiService,
    private ts: TranslateService,
    public dialog: MatDialog,
    @Inject(APP_CONFIG) private config: AppConfig,
    private storageSvc: StorageService
  ) {
    this.addTaskForm = this.fb.group({
      punchId: null,
      description: ["", [Validators.required]],
      ramark: ["", null],
      taskPriority: ["", [Validators.required]],
      workPackage: ["", [Validators.required]],
      dueDate: ["", [Validators.required]],
      level1Approver: [this.level1Approvers, [Validators.required]],
      level2Approver: [this.level2Approvers, [Validators.required]],
      isNonConformity: [true, ""],
    });
  }

  public ngOnInit(): void {
    this.getToken();
    this.getLookupData();
    this.getMasterData();
  }

  getLookupData() {
    this.lookupSvc.getAll("taskPriority").subscribe(
      (data) => {
        this.priorityList = data;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getMasterData() {
    this.masterDataSvc.getMasterData(this.projectId).subscribe(
      (data) => {
        this.masterData = data.master;
        this.setMasterData(this.masterData);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  changeWorkPackage(event) {
    this.stage1Approver = [];
    this.stage2Approver = [];
    if (event) {
      this.workPackage.forEach((wp) => {
        if (wp.tradeId === event.value) {
          this.stage1Approver = this.stage1Approver.concat(wp.level1);
          this.stage2Approver = this.stage2Approver.concat(wp.level2);
        }
      });
    }
  }

  get f() {
    return this.addTaskForm.controls;
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  //tslint:disable-next-line:no-any
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 2;
  }

  setMasterData(data) {
    data.workPackage.forEach((wp) => {
      if (
        wp.level1 &&
        wp.level1.length > 0 &&
        wp.level2 &&
        wp.level2.length > 0
      ) {
        this.workPackage.push(wp);
      }
    });
    data.workLocation.forEach((location) => {
      if (!location.parentLocationId) {
        this.level1Location.push(location);
      }
    });
  }

  submitTask(features, floorPlanFileId) {
    this.formSubmitAttempt = true;
    if (this.addTaskForm.valid) {
      const fileId = Guid.newGuid();

      this.uploadFiles(
        this.files,
        fileId,
        features,
        floorPlanFileId,
        this.punchItemAttachmentFiles
      );
    }
  }

  submitPunchData(mediaList, layer, floorPlanSnapshot) {
    this.uiService.show();
    let alert = "";

    this.updatePunchData(
      this.addTaskForm.value,
      mediaList,
      layer,
      floorPlanSnapshot
    );
    this.punchListService
      .bulkUploadPunchItem(this.projectId, this.punchListData)
      .subscribe(
        () => {
          this.uiService.hide();
          alert = this.ts.instant("task.new.messages.punchDataSaveSuccess");
          this.snackService.successSnackBar(alert);
          this.closeDialog(true);
          this.formSubmitted = false;
        },
        () => {
          this.uiService.hide();
          alert = this.ts.instant("task.new.messages.punchDataSaveFailed");
          this.snackService.errorSnackBar(alert);
          this.formSubmitted = false;
        },
        () => {}
      );
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.newTaskForm.resetForm();
    this.addTaskForm.reset();
  }

  updatePunchData(values: Object, mediaList, layer, floorPlanSnapshotId) {
    let task: PunchItem = {} as PunchItem;
    this.punchListData.workPackageId = values["workPackage"].trim();
    this.punchListData.dueDate = values["dueDate"];

    this.punchListData.stage1Approver = values["level1Approver"];
    this.punchListData.stage2Approver = values["level2Approver"];

    this.punchListData.locations = [
      this.tour.locationId ? this.tour.locationId : this.tour.towerId,
    ];

    task.taskDescription = values["description"];
    task.remark = values["ramark"];
    task.isNonConformity = values["isNonConformity"] ? true : false;
    task.taskPriority = {
      code: this.priorityList.find((x) => x.key === values["taskPriority"]).key,
      desc: this.priorityList.find((x) => x.key === values["taskPriority"])
        .value,
    };

    task.features = layer;
    task.mediaList = mediaList;
    task.latestSnapshotBlobId = floorPlanSnapshotId;

    this.punchListData.punchItems = [task];
  }

  closeDialog(refresh: boolean) {
    this.onReset();
    this.notifyClose.emit(refresh);
  }

  async uploadFiles(
    files,
    fileId: string,
    features,
    floorPlanFileId,
    attachmentFiles: FileAttachment[]
  ) {
    const extn = "jpeg";
    const blobRef = fileId + "." + extn;

    try {
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.accessToken
      );

      const containerClient = blobServiceClient.getContainerClient(
        this.config.mediaContainer
      );
      const promises = [];
      for (const file of files) {
        const blockBlobClient = containerClient.getBlockBlobClient(blobRef);
        promises.push(blockBlobClient.uploadBrowserData(file));
      }
      if (!!attachmentFiles && attachmentFiles.length > 0) {
        for (let index = 0; index < attachmentFiles.length; index++) {
          const file = attachmentFiles[index];
          const blobReference = this.getBlobReference(file);
          const blockBlobClient =
            containerClient.getBlockBlobClient(blobReference);
          promises.push(blockBlobClient.uploadBrowserData(file.file));
        }
      }
      await Promise.all(promises);
      this.saveItem(
        fileId,
        blobRef,
        features,
        floorPlanFileId,
        attachmentFiles
      );
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
    }
  }

  saveItem(
    fileId: string,
    blobRef: string,
    layerData,
    latestSnapshotBlobId,
    attachmentFiles: FileAttachment[]
  ) {
    let mediaList = [
      {
        mediaId: fileId,
        blobReference: blobRef,
        fileName: blobRef,
        features: null,
        mediaCreateDate: null,
        state: "created",
      },
    ];
    if (!!attachmentFiles && attachmentFiles.length > 0) {
      for (const file of this.punchItemAttachmentFiles) {
        mediaList.push({
          mediaId: file.id,
          blobReference: this.getBlobReference(file),
          fileName: file?.file?.name,
          features: null,
          mediaCreateDate: null,
          state: "created",
        });
      }
    }
    this.submitPunchData(mediaList, layerData, latestSnapshotBlobId);
  }
  getBlobReference(file: FileAttachment) {
    if (file.file.name.includes(".")) {
      const extension = file.file.name.split(".").pop();
      return `${file.id}.${extension}`;
    } else {
      return file.id;
    }
  }

  savePunchList($event) {
    this.uiService.show();
    this.submitTask($event.features, $event.fileId);
  }

  onSubmit() {
    this.formSubmitAttempt = true;
    if (this.addTaskForm.valid) {
      this.formSubmitted = true;
      this.floorPlanComponent.onSubmit();
    }
  }

  getToken() {
    const container = this.config.mediaContainer;
    this.storageSvc.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  handleFileInput(event: any, type: string) {
    let isValidFile: boolean = true;
    Array.from(event.target.files).forEach((file) => {
      if (this.isValidImageExtension(file)) {
        if (type.toLowerCase() == "punchitemfiles") {
          this.punchItemAttachmentFiles.push({
            id: uuidv4(),
            file,
          });
        }
      } else {
        isValidFile = false;
      }
    });
    if (!isValidFile) {
      this.snackService.warningSnackBar(
        this.ts.instant("task.detail.messages.attachValidFiles", {
          extensions: this.validImageExtensions.join(", "),
        })
      );
    }
  }
  isValidImageExtension(file: any): boolean {
    if (file.name.includes(".")) {
      const extension: string = file.name.split(".").pop();
      return this.validImageExtensions.includes(extension.toLowerCase());
    } else {
      return false;
    }
  }
  removePunchItemFile(file: FileAttachment) {
    this.punchItemAttachmentFiles = this.punchItemAttachmentFiles.filter(
      (item) => item.id !== file.id
    );
  }
}

export interface FileAttachment {
  id: string;
  file: any;
}
