export const BIM_CONSTANTS = {
  INITIAL_LOAD: "initialLoad",
  VIEW_POINT_CHANGED: "viewPointChanged",
  ORIENTATION_CHANGED: "rotationChanged",
  MODEL_FLOOR_CHANGED: "modelFloorChanged",
  MODEL_ROTATION_ORDER: "ZYX",
};
