import {
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from "@angular/core";
import {
  FormArray,
  FormControl,
  FormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import { Observable, Subscription } from "rxjs";
import {
  FI,
  FIAttachment,
  FIComponentData,
  FIDPCloseAction,
  FIDisucussion,
  FieldIssueService,
  LookUpService,
  MasterDataService,
  PanellumHotspot,
  ProjectUser,
  ProjectUserService,
  StorageService,
  TourImage,
  UiService,
  UserService,
  WBSService,
  LocalStorageService,
  ContentDataService,
  IMetadata,
  UploadFilePayload,
  CreateFolderPayload,
  User,
  Person,
  SnackbarService,
} from "src/app/core";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { COMMA, ENTER } from "@angular/cdk/keycodes";
import { MatChipInputEvent } from "@angular/material/chips";
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import { linkIcon, uuidv4 } from "../walkthrough-utils";
import { MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { map, startWith } from "rxjs/operators";
import * as moment from "moment-timezone";
import { MentionConfig } from "angular-mentions";
import _ from "lodash";
import { ActivityComponent } from "../activity/activity.component";
import { MatMenuTrigger } from "@angular/material/menu";
import { FloorPlanAnnotationComponent } from "../floor-plan/floor-plan.component";
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from "@angular/material-moment-adapter";
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from "@angular/material/core";
import * as markerjs2 from "markerjs2";
import * as mjslive from "markerjs-live";

export enum Status {
  STATUS1 = "FIS10001",
  STATUS2 = "FIS10002",
  STATUS3 = "FIS10003",
  STATUS4 = "FIS10004",
}
export enum Priority {
  PRIORITY1 = "FIP10001",
  PRIORITY2 = "FIP10002",
  PRIORITY3 = "FIP10003",
}
import _moment from "moment";
const mom = _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: "DD MMM YYYY",
  },
  display: {
    dateInput: "DD MMM YYYY",
    monthYearLabel: "MMM YYYY",
    dateA11yLabel: "LL",
    monthYearA11yLabel: "MMMM YYYY",
  },
};
@Component({
  selector: "field-issue-detail",
  templateUrl: "./field-issue-detail.component.html",
  styleUrls: ["./field-issue-detail.component.scss"],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class FieldIssueDetailComponent implements OnInit, OnDestroy {
  @Output()
  notifyFieldIssueDetailClose: EventEmitter<FIDPCloseAction> =
    new EventEmitter();
  @ViewChild("matTrigger") trigger: MatMenuTrigger;
  @ViewChild(FloorPlanAnnotationComponent)
  floorplanAnnotationComponent: FloorPlanAnnotationComponent;
  timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  currUser: User;
  fieldIssueInputData: FIComponentData;
  subscription: Subscription;
  viewer: any;
  projectId: string;
  issueId: string;
  tour: TourImage;
  tourId: string;
  towerId: string;
  floorId: string;
  interiorId: string;
  tourName: string;
  towerName: string;
  dueDate: Date;
  hotspot: PanellumHotspot;
  description: string;
  floorplanId: string;
  wbsLinks: any[];
  issueNumber: number;

  fieldIssueFormGroup: FormGroup;
  statusDropDown: { value?: string; key: string }[] = [];
  wasFormChanged: boolean = false;

  errors: any;
  watchLists: string[] = [];
  personMappedWatchList: Person[] = [];
  filteredWatchList: Observable<Person[]>;
  allProjectMembers: Person[] = [];
  @ViewChild("watchListInput", { static: false })
  watchListInput: ElementRef<HTMLInputElement>;
  dueDateSubs: Subscription;
  statusSubs: Subscription;

  assigneeArray: Person[] = [];
  priorityArray: { value?: string; key: string }[] = [];
  workTradeArray: any[] = [];

  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  addOnBlur: boolean = true;
  attachments: FIAttachment[] = [];

  currentDiscussionNgModel: string = "";
  isFormSubmitted: boolean = false;
  currentImageId: any;

  // angular mention
  mentionItems: any[] = [];
  mentionConfiguration: MentionConfig = {
    mentionSelect: (item) => {
      return item.display;
    },
    mentionFilter: (searchString: string, items: any[]): any[] => {
      return items.filter((item) =>
        item.tag.toLowerCase().includes(searchString)
      );
    },
    maxItems: 5,
    labelKey: "tag",
    dropUp: false,
    disableSort: true,
    triggerChar: "@",
    allowSpace: true,
  };

  snapshot: any;
  accessToken: string;

  selectedWBSActivityList: any[] = [];
  allWBSActivitiesList: any[] = [];
  preSelectedWBSLinks: any[] = [];

  snapshotUrl: string;
  floorplanWithMarker: File | any;
  existingFieldIssue: boolean = false;

  companyId: string;
  cabinetId: string;
  cabinetMetadata: IMetadata[] = [];
  readonly filenamePattern = /^[\w.()-]+[\w(). -]*$/;
  floorLevelFolderId: string;
  issueLevelFolderId: string;
  fieldIssueFolderRefId: string;
  timer: any;
  newDiscussion: FIDisucussion;
  // updatedDiscussionArray: FIDisucussion[] = [];
  sortedDiscussion: FIDisucussion[] = [];
  StatusColors = {
    [Status.STATUS1]: "#FF0000",
    [Status.STATUS2]: "#FFA500",
    [Status.STATUS3]: "#008000",
    [Status.STATUS4]: "#FFFF00",
  };
  statusColor: string;
  selectedStatus: string;
  tagFocusState: boolean;
  newDiscussionFocusState: boolean = false;

  //markerJS
  maState: markerjs2.MarkerAreaState;
  markerArea: markerjs2.MarkerArea;
  markerView: mjslive.MarkerView;
  constructor(
    private fb: UntypedFormBuilder,
    private lookupSvc: LookUpService,
    private masterDataSvc: MasterDataService,
    private userService: UserService,
    private wbsService: WBSService,
    private uiService: UiService,
    private ts: TranslateService,
    public dialog: MatDialog,
    @Inject(APP_CONFIG) private config: AppConfig,
    private storageSvc: StorageService,
    private fieldIssueService: FieldIssueService,
    private projectUserSvc: ProjectUserService,
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer,
    private snackService: SnackbarService,
    private localStorage: LocalStorageService,
    private contentDataService: ContentDataService
  ) {
    this.companyId = this.localStorage.getClientId();
    this.projectId = this.localStorage.getProjectId();
    this.currUser = this.userService.getCurrentUser();
    iconRegistry.addSvgIconLiteral(
      "linkIcon",
      sanitizer.bypassSecurityTrustHtml(linkIcon)
    );
    this.fieldIssueFormGroup = this.fb.group({
      tags: [[]],
      wbsLinks: [[]],
      discussion: this.fb.array([]),
      attachments: [[]],
      hotspot: [{}],
      issueNumber: new FormControl(""),
      issueId: new FormControl(),
      tourId: new FormControl(""),
      projectId: new FormControl(""),
      floorId: new FormControl(""),
      interiorId: new FormControl(""),
      towerId: new FormControl(""),
      watchList: new FormControl([]),
      status: new FormControl(""),
      dueDate: new FormControl(mom()),
      assignee: new FormControl(""),
      priority: new FormControl(""),
      workTrade: new FormControl(""),
      description: new FormControl(
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^(?=.*\\S)[\\s\\S]+$"),
        ])
      ),
    });

    this.filteredWatchList = this.f.watchList.valueChanges.pipe(
      startWith(<any>null),
      map((person: string | any | null) =>
        person ? this._filter(person) : this.allProjectMembers.slice()
      )
    );

    this.dueDateSubs = this.f.dueDate.valueChanges.subscribe((data) => {
      this.wasFormChanged = true;
    });

    this.statusSubs = this.f.status.valueChanges.subscribe((data) => {
      if (data) {
        this.selectedStatus = this.statusDropDown.find(
          ({ key }) => key == data
        ).value;
        this.statusColor = this.StatusColors[data];
        this.wasFormChanged = true;
      }
    });

    const promise1 = this.getStatusValues();
    const promise2 = this.getPriorityValues();
    const promise3 = this.getProjectUserData(this.projectId);
    const promise4 = this.getProjectFolder();
    const promise5 = this.getMasterData();
    Promise.all([promise1, promise2, promise3, promise4, promise5])
      .then((result: any) => {
        //promise1 result
        this.statusDropDown = result[0];
        //promise2 result
        this.priorityArray = result[1];

        //promise3 result
        this.assigneeArray = result[2].users;
        this.setAllWatchListDropdown(result[2].users);
        this.setMentionData(result[2].users);

        //promise4 result
        this.cabinetId = result[3].cabinet.id;
        this.cabinetMetadata = result[3].cabinet.metadata;
        this.floorLevelFolderId =
          this.localStorage.getItem("floorLevelFolderId");

        //promise5 result
        result[4]?.master?.workPackage.forEach((wp) => {
          if (
            wp.level1 &&
            wp.level1.length > 0 &&
            wp.level2 &&
            wp.level2.length > 0
          ) {
            this.workTradeArray.push(wp);
          }
        });
      })
      .then(() => {
        this.subscribeToFieldIssueData();
      });
  }

  ngOnInit(): void {}

  formChanged() {
    this.wasFormChanged = true;
    this.isFormSubmitted = false;
  }

  setSnapshotSrcValue(file: File | Blob) {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.snapshotUrl = reader.result as string;
    };
  }

  subscribeToFieldIssueData() {
    this.subscription = this.fieldIssueService.data.subscribe(
      (componentInputData) => {
        this.fieldIssueInputData = componentInputData;
        let { eventType } = componentInputData;
        switch (eventType) {
          case "new_issue":
            this.uiService.show();
            const newInputData = componentInputData.data;
            this.tour = newInputData.tour;
            this.tourId = this.tour.tourId;
            this.tourName = this.tour.tourName;
            this.towerId = newInputData.towerId;
            this.towerName = newInputData.towerName;
            this.hotspot = newInputData.hotspot;
            this.snapshot = newInputData.snapshot;
            this.floorId = this.tour.locationId;
            this.interiorId = this.tour.interiorId;
            this.viewer = newInputData.viewer;
            this.currentImageId = this.viewer.getScene();

            this.setSnapshotSrcValue(this.snapshot[0]);
            this.fieldIssueFormGroup.patchValue({
              status: Status.STATUS1,
              priority: Priority.PRIORITY2,
              assignee: this.currUser.email,
              projectId: this.projectId,
              tourId: this.tourId,
              interiorId: this.interiorId,
              floorId: this.floorId,
              towerId: this.towerId,
              towerName: this.towerName,
              tourName: this.tourName,
              issueId: uuidv4(),
            });
            this.statusColor = this.StatusColors[Status.STATUS1];
            this.selectedStatus = this.statusDropDown.find(
              ({ key }) => key == Status.STATUS1
            ).value;

            this.getWBSData(this.projectId, this.towerId, this.floorId);
            setTimeout(
              () => this.floorplanAnnotationComponent.onSubmitFromFieldIssue(),
              1500
            );
            this.uiService.hide();
            break;
          case "existing_issue":
            this.uiService.show();
            this.existingFieldIssue = true;
            const inputData = componentInputData.data;
            this.issueId = inputData.issueId;
            this.tour = inputData.tour;
            this.tourId = this.tour.tourId;
            this.tourName = this.tour.tourName;
            this.towerId = inputData.towerId;
            this.towerName = inputData.towerName;
            this.hotspot = inputData.hotspot;
            this.snapshot = inputData.snapshot;
            this.floorId = this.tour.locationId;
            this.interiorId = this.tour.interiorId;
            this.snapshotUrl = inputData.snapshotImage?.downloadUrl || "";
            this.currentImageId = inputData.currentImageId;
            this.preSelectedWBSLinks = inputData.wbsLinks;
            this.getWBSData(this.projectId, this.towerId, this.floorId);
            this.issueNumber = inputData.issueNumber;
            this.watchLists = inputData.watchList;
            this.personMappedWatchList = this.allProjectMembers.filter(
              ({ email }) => this.watchLists.includes(email)
            );
            this.sortedDiscussion = inputData.discussion.sort(
              (a, b) =>
                new Date(b.createdAt).getTime() -
                new Date(a.createdAt).getTime()
            );
            this.fieldIssueFolderRefId = inputData.fieldIssueRefId;
            for (let attachment of inputData.attachments) {
              attachment.isNew = false;
              this.attachments.push(attachment);
            }
            this.fieldIssueFormGroup.patchValue({
              issueNumber: this.issueNumber,
              issueId: inputData.issueId,
              status: inputData.status,
              priority: inputData.priority,
              projectId: this.projectId,
              tourId: this.tourId,
              interiorId: this.interiorId,
              floorId: this.floorId,
              towerId: this.towerId,
              towerName: this.towerName,
              tourName: this.tourName,
              tags: [...inputData.tags],
              description: inputData.description,
              workTrade: inputData.workTrade,
              assignee: inputData.assignee,
              hotspot: inputData.hotspot,
              dueDate: new Date(moment.utc(inputData.dueDate).toString()),
            });
            this.setDiscussion();
            this.statusColor = this.StatusColors[inputData.status];
            this.selectedStatus = this.statusDropDown.find(
              ({ key }) => key == inputData.status
            ).value;
            this.fieldIssueFormGroup.controls["issueNumber"].disable();
            //markerjs annotate snapshot
            this.maState = this.fieldIssueInputData.data.maState;
            this.showMarkerView(false);
            this.uiService.hide();
        }
      }
    );
  }

  setDiscussion() {
    this.getDiscussionFormData.clear();
    for (const dis of this.sortedDiscussion) {
      const grp = this.fb.group({
        content: [dis.content],
        from: [dis.from],
        createdAt: [dis.createdAt],
        updatedAt: [dis.updatedAt],
        isEdited: [dis.isEdited],
        isEditedByUser: [dis.isEditedByUser],
        discussionId: [dis.discussionId],
        mention: [dis.mention],
        isDeleted: [dis.isDeleted],
      });
      this.getDiscussionFormData.push(grp);
    }
  }

  getMasterData() {
    return new Promise((res, rej) => {
      this.masterDataSvc.getMasterData(this.projectId).subscribe(
        (data) => {
          data.master = {
            workPackage: this.sortUsingFieldName(
              data?.master?.workPackage || [],
              "tradeName"
            ),
          };
          res(data);
        },
        (err) => {
          this.errors = err;
        }
      );
    });
  }

  getProjectFolder() {
    return new Promise((res, rej) => {
      this.contentDataService
        .getProjectFolder(this.companyId, this.projectId, "interior")
        .subscribe({
          next: (data) => {
            res(data);
          },
          error: () => {
            this.snackService.errorSnackBar(
              this.ts.instant("library.messages.fetchFailed")
            );
          },
        });
    });
  }

  getStatusValues() {
    return new Promise((res, rej) => {
      this.lookupSvc.getAll("fieldIssueStatus").subscribe(
        (data) => {
          res(data);
        },
        (err) => {
          this.errors = err;
        }
      );
    });
  }

  getPriorityValues() {
    return new Promise((res, rej) => {
      this.lookupSvc.getAll("fieldIssuePriority").subscribe(
        (data) => {
          res(data);
        },
        (err) => {
          this.errors = err;
        }
      );
    });
  }

  get f() {
    return this.fieldIssueFormGroup.controls;
  }

  get fv() {
    return this.fieldIssueFormGroup.value;
  }

  get getDiscussionFormData(): FormArray {
    return this.fieldIssueFormGroup.get("discussion") as FormArray;
  }

  sortUsingFieldName(arr: any[], fieldName: string) {
    return arr.sort((a, b) =>
      a[fieldName].toLowerCase() < b[fieldName].toLowerCase()
        ? -1
        : a[fieldName].toLowerCase() > b[fieldName].toLowerCase()
        ? 1
        : 0
    );
  }

  getProjectUserData(projectId: string) {
    return new Promise((res, rej) => {
      this.projectUserSvc.getAll(projectId).subscribe(
        (data) => {
          data.users = this.sortUsingFieldName(data.users, "firstName");
          res(data);
        },
        (err) => {
          this.errors = err;
        }
      );
    });
  }

  get tagList() {
    return this.fieldIssueFormGroup.get("tags");
  }

  addTag(event: MatChipInputEvent): void {
    const value = (event.value || "").trim();

    if (value) {
      this.tagList.setValue([...this.tagList.value, value]);
      this.tagList.updateValueAndValidity();
    }

    // Clear the input value
    event.chipInput!.clear();
  }

  removeTag(item: string): void {
    const index = this.tagList.value.indexOf(item);

    if (index >= 0) {
      this.tagList.value.splice(index, 1);
      this.tagList.updateValueAndValidity();
    }
  }

  // watchList mat-chip
  setAllWatchListDropdown(users: ProjectUser[]) {
    users.forEach((element) => {
      const { firstName, lastName, email } = element;
      this.allProjectMembers.push({ firstName, lastName, email });
    });
  }

  removePersonFromWatchList(personEmail: string): void {
    this.watchLists = this.watchLists.filter((email) => email !== personEmail);
    this.personMappedWatchList = this.personMappedWatchList.filter(
      ({ email }) => email !== personEmail
    );
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.personMappedWatchList.push(
      this.allProjectMembers.find(({ email }) => email === event.option.value)
    );
    this.watchLists.push(
      this.allProjectMembers.find(({ email }) => email === event.option.value)
        .email
    );
    this.watchLists = [..._.uniq(this.watchLists)];
    this.watchListInput.nativeElement.value = "";
    this.f.watchList.setValue(null);
  }

  private _filter(value: string): Person[] {
    const filterValue = value.toLowerCase();

    return this.allProjectMembers.filter(
      (person) =>
        person.firstName.toLowerCase().includes(filterValue) ||
        person.lastName.toLowerCase().includes(filterValue) ||
        person.email.toLowerCase().includes(filterValue)
    );
  }

  onAttachmentUpload(files: File[]) {
    this.trigger.closeMenu();
    const currFile = files[0];
    for (let file of this.attachments) {
      if (file.name == currFile.name && file.size == currFile.size) {
        return;
      }
    }
    this.attachments.push({
      name: currFile.name,
      file: currFile,
      type: currFile.type,
      size: currFile.size,
      isNew: true,
    });
  }

  removeAttachment(name: string) {
    this.attachments = this.attachments.filter((ele) => ele.name != name);
  }

  async updateDiscussion(
    index: number,
    isEdited: boolean,
    saveContent?: boolean
  ) {
    let setDiscussionFlag = true;
    const modifiedDis = this.getDiscussionFormData.controls[index];
    let disId = modifiedDis.get("discussionId").value;
    for (let dis of this.sortedDiscussion) {
      if (dis.discussionId == disId) {
        dis.isEdited = isEdited;
        if (saveContent) {
          const comment = modifiedDis.get("content").value;
          dis.content = comment;
          const mentionedPeople = this.getMentionedPeople(comment);

          dis.mention = [];
          dis.mention.push(...mentionedPeople);
          modifiedDis.get("mention").setValue([]);
          modifiedDis.get("mention").value.push(...mentionedPeople);
          setDiscussionFlag = false;
          await this.postComment(comment, false, disId);

          // this.updatedDiscussionArray.push(modifiedDis.value);
        }
        break;
      }
    }

    setDiscussionFlag && this.setDiscussion();
  }

  deleteDiscussion(index: number) {
    this.uiService.show();
    const { discussionId } = this.sortedDiscussion.splice(index, 1)[0];
    this.fieldIssueService
      .deleteDiscussion(
        this.projectId,
        this.tourId,
        this.towerId,
        this.floorId,
        this.issueId,
        discussionId
      )
      .subscribe(({ discussion: updatedDiscussion }) => {
        this.sortedDiscussion = updatedDiscussion.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        this.uiService.hide();
        this.setDiscussion();
      });
  }

  getMentionedPeople(comment: string): string[] {
    let mentionedPeople: string[] = [];
    comment.replace(/@([a-zA-Z0-9]+_[a-zA-Z0-9]+)/g, (match, key) => {
      const person = this.assigneeArray.find(
        (p) =>
          p.firstName.toLowerCase() + "_" + p.lastName.toLowerCase() ===
          key.toLowerCase()
      );
      if (person) {
        mentionedPeople.push(person.email);
      }
      return match;
    });

    return _.uniq(mentionedPeople);
  }

  getNameFromProjectTeam(personEmail) {
    const person = this.allProjectMembers.find(
      ({ email }) => email == personEmail
    );
    return `${person.firstName} ${person.lastName}`;
  }

  setMentionData(users: ProjectUser[]) {
    users.forEach((element) => {
      this.mentionItems.push({
        tag: `${element.firstName} ${element.lastName} [${element.role.desc}]`,
        display: `@${element.firstName}_${element.lastName} `,
        email: element.email,
      });
    });
    this.mentionConfiguration.items = this.mentionItems;
    this.mentionConfiguration = Object.assign({}, this.mentionConfiguration);
  }

  isSubmitDisabled() {
    return this.isFormSubmitted && this.fieldIssueFormGroup.valid;
  }

  openSelectActivityDialog(): void {
    const dialogRef = this.dialog.open(ActivityComponent, {
      width: "60vw",
      height: "70vh",
      disableClose: true,
      data: {
        activityData: [...this.allWBSActivitiesList],
        header: `${this.towerName}-${this.tourName}`,
      },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      if (dialogResult?.data) {
        this.selectedWBSActivityList = [];
        for (let item of dialogResult.data) {
          for (let wbsItem of this.allWBSActivitiesList) {
            if (wbsItem.wbsId == item.wbsId) {
              wbsItem.selected = true;
              break;
            }
          }
          this.selectedWBSActivityList.push(item);
        }
      }
    });
  }

  getWBSData(projectId: string, towerId: string, floorId: string) {
    this.wbsService.getInteriorWBS(projectId, towerId, floorId).subscribe(
      (data) => {
        if (data?.wbs?.length > 0) {
          const wbsData = Object.assign(<any[]>[], data.wbs);
          for (let element of wbsData) {
            if (
              this.existingFieldIssue &&
              this.preSelectedWBSLinks.includes(element.wbsId)
            ) {
              this.selectedWBSActivityList.push(element);
              element.selected = true;
            } else {
              element.selected = false;
            }
          }
          this.allWBSActivitiesList = [...wbsData];
        }
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  floorplanImageSnapshot(file: File) {
    this.floorplanWithMarker = file;
  }

  removeActivity(wbsActivity: any) {
    this.selectedWBSActivityList = Object.assign(
      [],
      this.selectedWBSActivityList.filter(
        (wbsActivityEle) => wbsActivityEle.wbsId !== wbsActivity.wbsId
      )
    );
    for (let wbsAct of this.allWBSActivitiesList) {
      if (wbsActivity.wbsId == wbsAct.wbsId) {
        wbsAct.selected = false;
        break;
      }
    }
  }

  generateFileObjectId(fileName) {
    const fileObjectId = uuidv4();

    if (fileName.includes(".")) {
      return fileObjectId + "." + fileName.split(".").pop();
    } else {
      return fileObjectId;
    }
  }

  getMetadataByTypeAndValue(label: string, value: string): IMetadata {
    return {
      metadataId: this.cabinetMetadata.find(
        (item) => item.label.toLowerCase() === label.toLowerCase()
      ).metadataId,
      metadataType: this.cabinetMetadata.find(
        (item) => item.label.toLowerCase() === label.toLowerCase()
      ).metadataType,
      value,
      label,
    };
  }

  getFloorIdIssueIdMetadata = () => {
    return [
      this.getMetadataByTypeAndValue("IssueId", this.fv.issueId),
      this.getMetadataByTypeAndValue("FloorId", this.floorId),
    ];
  };

  bulkUploadFiles(parentFolderRefId: string) {
    const fileData = [];
    for (let item of this.attachments) {
      // checking isNew for new files only
      // so that for existing field issue,
      // existing files are not re-uploaded
      if (item.isNew) {
        item.uploadFileType = "attachment";
        fileData.push(item);
      }
    }
    !this.existingFieldIssue &&
      ((this.floorplanWithMarker.uploadFileType = "floorplanLocation"),
      fileData.push(this.floorplanWithMarker));

    const uploadFilesReq: UploadFilePayload[] = [];
    let uploadFilePayLoad: UploadFilePayload;

    for (const file of fileData) {
      uploadFilePayLoad = {
        cabinetRefId: this.cabinetId,
        parentFolderRefId: parentFolderRefId,
        name: file.name,
        description: `Field Issue ${file.uploadFileType}`,
        fileObjectId: this.generateFileObjectId(file.name),
        fileSize: file.size.toString(),
        metadata: [...this.getFloorIdIssueIdMetadata()],
        fileContent: file.file,
      };

      if (file.uploadFileType == "floorplanLocation") {
        uploadFilePayLoad.metadata.push(
          this.getMetadataByTypeAndValue("Type", "FloorplanLocation")
        );
      }

      if (file.uploadFileType == "attachment") {
        uploadFilePayLoad.metadata.push(
          this.getMetadataByTypeAndValue("Type", "Attachment")
        );
      }

      file.fileObjectId = uploadFilePayLoad.fileObjectId; //save for reference
      uploadFilesReq.push(uploadFilePayLoad);
    }

    this.contentDataService.uploadFiles(uploadFilesReq);
  }

  createIssueLevelFolder(parentFolderRefId: string): Promise<any> {
    const createFolderPayload: CreateFolderPayload = {
      name: this.fv.issueId,
      description: "Field Issue Folder",
      cabinetRefId: this.cabinetId,
      parentFolderRefId: parentFolderRefId,
      projectId: this.projectId,
      additionalInfo: `floorId:${this.fv.floorId}`,
      status: true,
    };

    return this.contentDataService
      .createFolder(createFolderPayload)
      .toPromise();
  }

  async saveFieldIssue() {
    !this.existingFieldIssue &&
      this.currentDiscussionNgModel?.trim() !== "" &&
      ((this.newDiscussion = this.getCurrentDiscussionObject(
        this.currentDiscussionNgModel.trim()
      )),
      this.getDiscussionFormData.value.push(this.newDiscussion));
    if (this.fieldIssueFormGroup.valid) {
      this.isFormSubmitted = true;
      this.uiService.show();
      if (this.existingFieldIssue) {
        await this.uploadAttachmentsUpdateFieldIssue();
      } else {
        await this.createContentFolderUploadFileAndFI();
      }
    }
  }

  async createContentFolderUploadFileAndFI() {
    await this.createIssueLevelFolder(this.floorLevelFolderId)
      .then(async (data) => {
        this.issueLevelFolderId = data.id;
        return this.issueLevelFolderId;
      })
      .then(async (issueLevelFolderId) => {
        return new Promise((res, rej) => {
          const file = this.snapshot[0];
          file.uploadFileType = "Snapshot";
          const snapshotFilePayload = {
            cabinetRefId: this.cabinetId,
            parentFolderRefId: issueLevelFolderId,
            name: file.name,
            description: `Field Issue ${file.uploadFileType}`,
            fileObjectId: this.generateFileObjectId(file.name),
            fileSize: file.size.toString(),
            fileContent: file,
            metadata: [
              ...this.getFloorIdIssueIdMetadata(),
              this.getMetadataByTypeAndValue("Type", file.uploadFileType),
            ],
          };

          this.uploadFilesToCloudStorage(snapshotFilePayload)
            .then((uploadResponse) => {
              res(uploadResponse);
            })
            .catch((err) => {
              rej(err);
            });
        });
      })
      .then((_) => {
        this.createFieldIssue(_);
      })
      .then(() => {
        this.bulkUploadFiles(this.issueLevelFolderId);
      })
      .catch((err) => (this.errors = err));
  }

  getFieldIssueObject(): FI {
    let selectedAssignee;
    const returnFI: FI = {
      ...this.fv,
      dueDate: moment.tz(this.fv.dueDate, this.timeZone).utc().toISOString(),
      hotspot: this.hotspot,
      discussion: this.getDiscussionFormData.value,
      watchList: this.watchLists,
      wbsLinks: this.selectedWBSActivityList.map((ele) => ele.wbsId),
      currentImageId: this.currentImageId,
    };
    this.fv.status &&
      (returnFI.status = this.statusDropDown.find(
        (status) => status.key == this.fv.status
      )?.key);
    this.fv.priority &&
      (returnFI.priority = this.priorityArray.find(
        (priority) => priority.key == this.fv.priority
      )?.key);
    this.fv.assignee &&
      ((selectedAssignee = this.assigneeArray.find(
        (user) => user.email.toLowerCase() == this.fv.assignee.toLowerCase()
      )),
      (returnFI.assignee = selectedAssignee?.email));
    !this.existingFieldIssue &&
      this.newDiscussion &&
      (returnFI.newDiscussion = this.newDiscussion);
    // this.updatedDiscussionArray?.length > 0 &&
    //   (returnFI.updatedDiscussion = this.updatedDiscussionArray);
    return returnFI;
  }

  createFieldIssue(uploadedFileObject: any) {
    let alert;
    const fieldIssue = this.getFieldIssueObject();
    delete fieldIssue.viewer;
    this.fieldIssueService
      .updateFI(this.projectId, this.tourId, fieldIssue, "create", {
        uploadedFileObject,
      })
      .subscribe(
        (response) => {
          if (response?.status == "success") {
            this.uiService.hide();
            alert = this.ts.instant(
              "interior.virtualTour.fieldIssue.messages.fieldIssueSaveSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.notifyFieldIssueDetailClose.emit({
              refresh: true,
              removeHotspot: true,
              setOriginalBound: true,
              type: "close_with_save",
            });
          }
        },
        (err) => {
          this.uiService.hide();
          alert = this.ts.instant(
            "interior.virtualTour.fieldIssue.messages.fieldIssueSaveError"
          );
          this.snackService.errorSnackBar(alert);
        }
      );
  }

  uploadFilesToCloudStorage = (fileData: any) => {
    let self = this;
    return new Promise((resolve, reject) => {
      let uploadUrl: string = "";
      let stepOneReq = {
        cabinetRefId: fileData.cabinetRefId,
        parentFolderRefId: fileData.parentFolderRefId,
        name: fileData.name,
        description: fileData.description,
        tagList: fileData.tagList,
        fileObjectId: fileData.fileObjectId,
        fileSize: fileData.fileSize,
        metadata: fileData.metadata,
      };

      let stepThreeReq = {
        cabinetRefId: fileData.cabinetRefId,
        parentFolderRefId: fileData.parentFolderRefId,
        files: [{ fileObjectId: fileData.fileObjectId }],
      };
      self.contentDataService
        .uploadFile(stepOneReq)
        .subscribe((stepOneData: any) => {
          if (!!stepOneData.signedUrl && stepOneData.signedUrl.length > 0) {
            uploadUrl = stepOneData.signedUrl;
            self.contentDataService
              .uploadFileS3(uploadUrl, fileData.fileContent)
              .subscribe(
                (stepTwoData: any) => {
                  self.contentDataService
                    .updateFileStatus(stepThreeReq)
                    .subscribe((stepThreeData: any) => {
                      let dataSuccess = {
                        status: true,
                        fileObjectId: stepThreeData[0].fileObjectId,
                        viewUrl: stepThreeData[0].viewUrl,
                      };
                      resolve(dataSuccess);
                      this.contentDataService.refreshFiles(false);
                    });
                },
                (error: any) => {
                  let dataFailure = {
                    status: false,
                    description: "Request has failed",
                    fileObjectId: fileData.fileObjectId,
                  };
                  resolve(dataFailure);
                }
              );
          } else {
            let dataFailure = {
              status: false,
              description: "Request has failed",
              fileObjectId: fileData.fileObjectId,
            };
            resolve(dataFailure);
          }
        });
    });
  };

  getModifiedFieldsForEmailNotification(updatedFIData: FI) {
    const inputFIData = this.fieldIssueInputData.data;
    const modifiedFields = [];
    if (inputFIData.status != updatedFIData.status) {
      modifiedFields.push({
        fieldName: "status",
        prevValue: this.statusDropDown.find(
          (ele) => ele.key == inputFIData.status
        ).value,
        newValue: this.statusDropDown.find(
          (ele) => ele.key == updatedFIData.status
        ).value,
      });
    }
    if (inputFIData.assignee != updatedFIData.assignee) {
      modifiedFields.push({
        fieldName: "assignee",
        prevValue: inputFIData.assignee,
        newValue: updatedFIData.assignee,
      });
    }
    if (
      !moment
        .tz(inputFIData.dueDate, this.timeZone)
        .isSame(moment.tz(updatedFIData.dueDate, this.timeZone))
    ) {
      modifiedFields.push({
        fieldName: "dueDate",
        prevValue: moment
          .tz(inputFIData.dueDate, this.timeZone)
          .utc()
          .toISOString(),
        newValue: moment
          .tz(updatedFIData.dueDate, this.timeZone)
          .utc()
          .toISOString(),
        timezone: this.timeZone,
      });
    }
    if (inputFIData.priority != updatedFIData.priority) {
      modifiedFields.push({
        fieldName: "priority",
        prevValue: this.priorityArray.find(
          (ele) => ele.key == inputFIData.priority
        ).value,
        newValue: this.priorityArray.find(
          (ele) => ele.key == updatedFIData.priority
        ).value,
      });
    }
    if (inputFIData.workTrade != updatedFIData.workTrade) {
      modifiedFields.push({
        fieldName: "workTrade",
        prevValue: this.workTradeArray.find(
          (ele) => ele.tradeId == inputFIData.workTrade
        )?.tradeName,
        newValue: this.workTradeArray.find(
          (ele) => ele.tradeId == updatedFIData.workTrade
        )?.tradeName,
      });
    }
    if (inputFIData.description != updatedFIData.description) {
      modifiedFields.push({
        fieldName: "description",
        prevValue: inputFIData.description,
        newValue: updatedFIData.description,
      });
    }
    return modifiedFields;
  }

  async uploadAttachmentsUpdateFieldIssue() {
    let alert;
    this.bulkUploadFiles(this.fieldIssueFolderRefId);
    const fieldIssue = this.getFieldIssueObject();
    delete fieldIssue.viewer;
    const modifiedFields =
      this.getModifiedFieldsForEmailNotification(fieldIssue);
    this.fieldIssueService
      .updateFI(this.projectId, this.tourId, fieldIssue, "update", {
        modifiedFields,
      })
      .subscribe(
        (response) => {
          if (response?.status == "success") {
            this.uiService.hide();
            alert = this.ts.instant(
              "interior.virtualTour.fieldIssue.messages.fieldIssueUpdateSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.notifyFieldIssueDetailClose.emit({
              refresh: true,
              removeHotspot: false,
              setOriginalBound: false,
              type: "close_with_save",
            });
          }
        },
        (err) => {
          this.uiService.hide();
          alert = this.ts.instant(
            "interior.virtualTour.fieldIssue.messages.fieldIssueUpdateError"
          );
          this.snackService.errorSnackBar(alert);
          this.notifyFieldIssueDetailClose.emit({
            refresh: true,
            removeHotspot: false,
            setOriginalBound: false,
            type: "close_without_save",
          });
        }
      );
    this.uiService.hide();
  }

  getDiscussionDateSince(time) {
    return moment.tz(time, this.timeZone).fromNow();
  }

  getCurrentDiscussionObject(
    content: string,
    discussionId: string = null
  ): FIDisucussion {
    const mention = [...this.getMentionedPeople(content)];
    if (discussionId) {
      const discussion: FIDisucussion = this.sortedDiscussion.find(
        (discuss) => {
          return discuss.discussionId === discussionId;
        }
      );
      discussion.updatedAt = moment().tz(this.timeZone).utc().toISOString();
      discussion.content = content;
      discussion.mention = mention;
      discussion.isEditedByUser = true;
      return discussion;
    }
    return {
      discussionId: uuidv4(),
      from: this.currUser.email,
      createdAt: moment().tz(this.timeZone).utc().toISOString(),
      updatedAt: moment().tz(this.timeZone).utc().toISOString(),
      content,
      mention,
      isEditedByUser: false,
      isDeleted: false,
    };
  }

  async postComment(
    content: string,
    isNew: boolean = false,
    discussionId: string = null
  ) {
    if (content.trim()) {
      const discussion = this.getCurrentDiscussionObject(content, discussionId);
      this.uiService.show();
      delete discussion.isEdited;
      this.fieldIssueService
        .updateDiscussion(
          this.projectId,
          this.tourId,
          this.towerId,
          this.floorId,
          this.issueId,
          discussion,
          isNew
        )
        .subscribe(({ discussion: updatedDiscussion }) => {
          // reset the field for next use
          isNew && this.clearComment();
          this.sortedDiscussion = updatedDiscussion.sort(
            (a, b) =>
              new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
          this.uiService.hide();
          this.setDiscussion();
        });
    } else {
      return;
    }
  }

  clearComment() {
    this.currentDiscussionNgModel = "";
    this.newDiscussionFocusState = false;
  }

  async openSnapshot(target) {
    const snapshotEl = document.getElementById("snapshot");
    this.markerArea && this.markerArea.close();
    this.markerView && this.markerView.close();
    this.markerArea = new markerjs2.MarkerArea(snapshotEl);
    this.markerArea.settings.displayMode = "popup";
    this.markerArea.renderAtNaturalSize = true;
    //document.querySelector('[title="Powered by marker.js"]')?.remove();
    this.markerArea.addEventListener("render", async (event) => {
      this.maState = event.state;
      // this.snapshotUrl = event.dataUrl;
      //saved it to db
      if (this.existingFieldIssue) {
        this.uiService.show();
        this.fieldIssueService
          .saveSnapshotMarkerAnnotation(
            this.projectId,
            this.tourId,
            this.fieldIssueInputData.data.issueId,
            this.maState
          )
          .subscribe((data) => {
            this.uiService.hide();
            this.maState = data.maState;
            this.showMarkerView(true);
          });
      }
    });

    this.markerArea.show();
    this.maState && this.markerArea.restoreState(this.maState);
    this.markerArea.addEventListener("close", async (e) => {
      this.showMarkerView(true);
    });
  }

  showMarkerView(snapshotAlreadyLoaded: boolean) {
    if (this.maState?.markers) {
      const snapshotEl = document.getElementById("snapshot");
      this.markerView && this.markerView.close();
      snapshotAlreadyLoaded
        ? ((this.markerView = new mjslive.MarkerView(snapshotEl)),
          (this.markerView.targetRoot = snapshotEl.parentElement),
          this.markerView.show(this.maState as mjslive.MarkerAreaState))
        : snapshotEl.addEventListener("load", (ev) => {
            this.markerView = new mjslive.MarkerView(snapshotEl);
            this.markerView.targetRoot = snapshotEl.parentElement;
            this.markerView.show(this.maState as mjslive.MarkerAreaState);
          });
    }
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
    this.dueDateSubs?.unsubscribe();
    this.statusSubs?.unsubscribe();
    this.markerView?.close();
    this.markerArea?.close();
    this.fieldIssueService.setFieldIssueObject(null);
  }
}
