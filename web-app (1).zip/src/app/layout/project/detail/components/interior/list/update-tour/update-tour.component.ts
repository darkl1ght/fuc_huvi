import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  InteriorDialogData,
  UserService,
  User,
  InteriorService,
  UiService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "update-tower",
  templateUrl: "./update-tour.component.html",
  styleUrls: ["./update-tour.component.scss"],
})
export class UpdateTourComponent implements OnInit {
  @ViewChild("interiorForm") interiorForm;
  public breakpoint: number;
  public tourName: string = "";
  public updateInteriorForm: UntypedFormGroup;
  formSubmitAttempt: boolean = false;
  errors = {};
  wasFormChanged = false;
  projectId: string;
  user: User;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private interiorService: InteriorService,
    private snackService: SnackbarService,
    private usrService: UserService,
    private uiService: UiService,
    private ts: TranslateService
  ) {
    this.updateInteriorForm = this.fb.group({
      interiorId: null,
      tourId: null,
      tourName: [
        this.tourName,
        [
          Validators.required,
          Validators.pattern(
            /^[a-zA-ZÀ-ÿ0-9]+[a-zA-ZÀ-ÿ0-9+\-,:;=@&#|'<>^*()%!_\.\/\\ ]*$/
          ),
        ],
      ],
    });
  }

  public ngOnInit(): void {
    this.setInteriorDetails(this.data);
    this.user = this.usrService.getCurrentUser();
  }

  get f() {
    return this.updateInteriorForm.controls;
  }

  public onInteriorAdd(): void {
    this.formSubmitAttempt = true;
    this.markAsDirty(this.updateInteriorForm);
    this.onSubmit();
  }

  setInteriorDetails(tour) {
    this.projectId = this.data.projectId;
    this.tourName = tour.tourName;
    if (tour) {
      this.updateInteriorForm.patchValue({
        interiorId: tour.interiorId,
        tourId: tour.tourId,
        tourName: tour.tourName,
      });
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
    this.onReset();
  }

  //tslint:disable-next-line:no-any
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 2;
  }

  private markAsDirty(group: UntypedFormGroup): void {
    group.markAsDirty();
    for (const i in group.controls) {
      group.controls[i].markAsDirty();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  onSubmit() {
    let alert = "";
    let data = this.updateInteriorForm.value;
    this.formSubmitAttempt = true;
    if (this.updateInteriorForm.valid) {
      this.uiService.show();

      this.interiorService
        .overrideTourData(
          this.projectId,
          data.interiorId,
          data.tourId,
          data.tourName
        )
        .subscribe(
          () => {
            alert = this.ts.instant("interior.list.messages.tourDetailsSaved");
            this.snackService.successSnackBar(alert);
            this.dialog.closeAll();
            this.onReset();
            this.uiService.hide();
          },
          (err) => {
            alert = this.ts.instant("interior.list.messages.failedToSave");
            this.errors = err;
            this.formSubmitAttempt = false;
            this.snackService.errorSnackBar(alert);
            this.dialog.closeAll();
            this.uiService.hide();
          }
        );
    }
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.interiorForm.resetForm();
    this.updateInteriorForm.reset();
  }
}
