import { OverlayModule } from "@angular/cdk/overlay";
import {
  Component,
  EventEmitter,
  Inject,
  OnDestroy,
  Output,
} from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";
import { Subscription } from "rxjs";
import {
  ContentDataService,
  FI,
  FIComponentData,
  FieldIssueService,
  IMetadata,
  LocalStorageService,
  LookUpService,
  MasterDataService,
  OriginalPanellumPositionParameters,
  PanellumHotspot,
  UiService,
  UserService,
  SnackbarService,
} from "src/app/core";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { v4 as uuidv4 } from "uuid";
import * as moment from "moment-timezone";
import { FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { filterIcon, filterAppliedIcon } from "../walkthrough-utils";
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";

export enum Status {
  STATUS1 = "FIS10001",
  STATUS2 = "FIS10002",
  STATUS3 = "FIS10003",
  STATUS4 = "FIS10004",
}

@Component({
  selector: "field-issue-list",
  templateUrl: "./field-issue-list.component.html",
  styleUrls: ["./field-issue-list.component.scss"],
})
export class FieldIssueListComponent implements OnDestroy {
  @Output() notifyClose: EventEmitter<{
    refresh: boolean;
    type: string;
    fi?: any;
  }> = new EventEmitter();
  origPitchBounds: any;
  origYawBounds: any;
  origHfovBounds: any;
  currentHotSpotId: string;
  currentHotSpotConfig: PanellumHotspot;
  viewer: any;
  hasFirstClickHappened: boolean = false;
  projectId: string;
  companyId: string;
  fieldIssueInputData: FIComponentData;
  fieldIssueListLength: number = 0;
  allFieldIssues: FI[];
  filteredFieldIssues: FI[];
  subscription: Subscription;
  cabinetId: string;
  cabinetMetadata: string;

  statusCheckboxValues: any[] = [];
  priorityCheckboxValues: any[] = [];
  workTradeArray: any[] = [];
  datesArray: any[] = [];
  isFilterOpen: boolean = false;
  filterForm: FormGroup;
  filterPanelPosition: OverlayModule[] = [
    {
      offsetX: 5,
      offsetY: 10,
      originX: "start",
      originY: "top",
      overlayX: "end",
      overlayY: "top",
      panelClass: null,
    },
  ];
  errors: any;
  timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  selectedStatusCheckboxes: any[] = [];
  selectedPriorityCheckboxes: any[] = [];
  selectedWorkTradeCheckboxes: any[] = [];
  filterChips: any[] = [];
  projectFolderId: string;
  fieldIssueHotspots: PanellumHotspot[] = [];
  startDate: any;
  endDate: any;
  isFilterSet: boolean = false;
  originalEmptySearchFI: FI[] = [];

  StatusColors = {
    [Status.STATUS1]: "#FF0000",
    [Status.STATUS2]: "#FFA500",
    [Status.STATUS3]: "#008000",
    [Status.STATUS4]: "#FFFF00",
  };
  searchText: string = "";

  constructor(
    private lookupSvc: LookUpService,
    private masterDataSvc: MasterDataService,
    private snackService: SnackbarService,
    private uiService: UiService,
    private ts: TranslateService,
    public dialog: MatDialog,
    @Inject(APP_CONFIG) private config: AppConfig,
    private userService: UserService,
    private localStorage: LocalStorageService,
    private fieldIssueService: FieldIssueService,
    private contentDataService: ContentDataService,
    private formBuilder: FormBuilder,
    private iconRegistry: MatIconRegistry,
    private sanitizer: DomSanitizer
  ) {
    iconRegistry.addSvgIconLiteral(
      "filterIcon",
      sanitizer.bypassSecurityTrustHtml(filterIcon)
    );
    iconRegistry.addSvgIconLiteral(
      "filterAppliedIcon",
      sanitizer.bypassSecurityTrustHtml(filterAppliedIcon)
    );
  }

  public ngOnInit(): void {
    this.uiService.show();
    this.filterForm = this.formBuilder.group({
      status: this.formBuilder.control([]),
      priority: this.formBuilder.control([]),
      workTrade: this.formBuilder.control([]),
      startDate: new FormControl<Date | null>(null),
      endDate: new FormControl<Date | null>(null),
    });

    this.companyId = this.localStorage.getClientId();
    this.projectId = this.localStorage.getProjectId();
    this.getStatusValues();
    this.getPriorityValues();
    this.getMasterData(this.projectId);
    this.contentDataService
      .getProjectFolder(this.companyId, this.projectId, "interior")
      .subscribe({
        next: (data) => {
          this.cabinetId = data.cabinet.id;
          this.cabinetMetadata = data.cabinet.metadata;
          this.projectFolderId = data.folder.id;
          this.uiService.hide();
          this.subscribeToFieldIssueData();
        },
        error: () => {
          this.snackService.errorSnackBar(
            this.ts.instant("library.messages.fetchFailed")
          );
        },
      });
  }

  subscribeToFieldIssueData() {
    this.subscription = this.fieldIssueService.data.subscribe(
      (componentInputData) => {
        this.fieldIssueInputData = componentInputData;
        this.viewer = componentInputData.data.viewer;
        let { eventType } = componentInputData;
        switch (eventType) {
          case "field_capture_mode_on":
            this.changePannellumInteractionToGetFieldIssueLocation();
            break;
          case "cancel":
            this.turnOffPannellumEvent(this.fieldIssueService.originalPosition);
            this.fieldIssueService.firstClickAction(false);
            this.getFieldIssues(componentInputData.data);
            break;
          case "after_save":
            this.getFieldIssues(componentInputData.data);
            break;
          case "initiate":
            this.getFieldIssues(componentInputData.data);
            break;
          case "view_field_issue":
            this.getFieldIssues(componentInputData.data);
            break;
        }
      }
    );
  }

  getFieldIssues(componentInputData: FI) {
    this.uiService.show();
    let { projectId, towerId, tourId, floorId } = componentInputData;
    this.fieldIssueService
      .getFIList(projectId, tourId, towerId, floorId)
      .subscribe(
        (data) => {
          this.fieldIssueListLength = data.fieldIssues.length;
          this.allFieldIssues = data.fieldIssues;
          for (let issue of this.allFieldIssues) {
            const date = moment
              .tz(issue.dueDate, this.timeZone)
              .utc(true)
              .format("YYYY-MM-DD");
            if (this.datesArray.indexOf(date) == -1) {
              this.datesArray.push(
                moment
                  .tz(issue.dueDate, this.timeZone)
                  .utc(true)
                  .format("YYYY-MM-DD")
              );
            }
            if (this.viewer?.getScene() === issue.currentImageId) {
              this.fieldIssueHotspots.push({
                ...issue.hotspot,
                tooltip: issue.issueNumber.toString(),
              });
            }
            issue.statusColor = this.StatusColors[issue.status];
          }

          this.loadHotspots();
          this.contentDataService
            .getFieldIssuesFolderContents(
              this.projectFolderId,
              componentInputData.floorId
            )
            .subscribe(
              (fiFiles) => {
                for (let fieldIssue of this.allFieldIssues) {
                  for (let item of fiFiles.fieldIssueFolders) {
                    if (item.folder.name == fieldIssue.issueId) {
                      // appending fieldIssueRefId for existing field issue so user
                      // can upload new files in same field issue folder
                      fieldIssue.fieldIssueRefId = item.folder.id;
                      for (let file of item.files) {
                        const metadataType: string = file.metadata
                          .find(
                            (metadata: IMetadata) => metadata.label == "Type"
                          )
                          .value.toLowerCase();
                        if (metadataType == "snapshot") {
                          fieldIssue.snapshotImage = {
                            name: file.name,
                            size: file.fileSize,
                            fileObjectId: file.fileObjectId,
                            downloadUrl: file.downloadUrl,
                            viewUrl: file.viewUrl,
                            uploadFileType: "snapshot",
                          };
                        } else if (metadataType == "floorplanlocation") {
                          fieldIssue.floorplanImage = {
                            name: file.name,
                            size: file.fileSize,
                            fileObjectId: file.fileObjectId,
                            downloadUrl: file.downloadUrl,
                            viewUrl: file.viewUrl,
                            uploadFileType: "floorplanLocation",
                          };
                        } else {
                          fieldIssue.attachments.push({
                            name: file.name,
                            size: file.fileSize,
                            fileObjectId: file.fileObjectId,
                            downloadUrl: file.downloadUrl,
                            viewUrl: file.viewUrl,
                            uploadFileType: "attachment",
                          });
                        }
                      }
                    }
                  }
                }
                this.filteredFieldIssues = [...this.allFieldIssues];
                this.originalEmptySearchFI = [...this.allFieldIssues];
                const filterFormValue = this.localStorage.getItem(
                  `${this.userService.getCurrentUser().id}_field_issue_filter`
                );
                filterFormValue &&
                  (this.filterForm.patchValue({
                    ...filterFormValue,
                  }),
                  this.applyFilterOnFI());
                const fieldIssueObject =
                  this.fieldIssueService.getFieldIssueObject();
                if (!!fieldIssueObject) {
                  const fieldIssueToView = this.allFieldIssues.find(
                    (fieldIssue) =>
                      fieldIssue.issueId == fieldIssueObject.issueId
                  );
                  if (fieldIssueToView) {
                    this.openFI(fieldIssueToView);
                  }
                }
                this.uiService.hide();
              },
              (err) => (this.errors = err)
            );
        },
        (err) => {
          this.errors = err;
        }
      );
  }

  applySearchFilter(event) {
    const filterValue = (event.target as HTMLInputElement).value.toLowerCase();
    if (filterValue) {
      this.filteredFieldIssues = this.filteredFieldIssues.filter((fi) => {
        return (
          fi.description.toLowerCase().includes(filterValue) ||
          fi.tags.join(" ").toLowerCase().includes(filterValue) ||
          fi.issueNumber.toString() == filterValue
        );
      });
    } else {
      this.filteredFieldIssues = this.originalEmptySearchFI;
    }
  }

  closeFieldIssueListPanel(refresh: boolean, type: string, fi?: FI) {
    this.notifyClose.emit({ refresh, fi, type });
  }

  freezePannellumScreen = (pitch: number, yaw: number) => {
    this.viewer.setPitchBounds([pitch, pitch]);
    this.viewer.setYawBounds([yaw, yaw]);
  };

  defreezePannellumScreen = (
    originalPitchBounds: any,
    originalYawBounds: any
  ) => {
    this.viewer.setPitchBounds(originalPitchBounds);
    this.viewer.setYawBounds(originalYawBounds);
  };

  saveViewerPositionInfoToService = () => {
    this.fieldIssueService.originalPosition = {
      origPitchBounds: this.origPitchBounds,
      origYawBounds: this.origYawBounds,
      origHfovBounds: this.origHfovBounds,
    };
  };

  changePannellumInteractionToGetFieldIssueLocation = () => {
    this.origPitchBounds = this.viewer.getPitchBounds();
    this.origYawBounds = this.viewer.getYawBounds();
    this.origHfovBounds = this.viewer.getHfovBounds();
    this.saveViewerPositionInfoToService();
    this.viewer.setHfovBounds([this.viewer.getHfov(), this.viewer.getHfov()]);
    this.freezePannellumScreen(this.origPitchBounds, this.origYawBounds);
    this.viewer.on("mouseup", this.updateHotSpotOnViewer);
    this.closeFieldIssueListPanel(false, "field_issue_capture_mode");
  };

  updateHotSpotOnViewer = (ev) => {
    if (this.currentHotSpotId) {
      this.viewer.removeHotSpot(this.currentHotSpotId);
    }
    this.fieldIssueService.isFirstClick
      .subscribe((data) => {
        if (!data) {
          this.fieldIssueService.firstClickAction(true);
        }
      })
      .unsubscribe();

    const [pitch, yaw] = this.viewer.mouseEventToCoords(ev);
    this.defreezePannellumScreen(this.origPitchBounds, this.origYawBounds);
    this.currentHotSpotId = uuidv4();
    this.currentHotSpotConfig = {
      id: this.currentHotSpotId,
      pitch,
      yaw,
      type: "info",
      cssClass: "custom-hotspot",
    };
    this.fieldIssueService.lastAddedHostspot = this.currentHotSpotConfig;
    this.viewer.addHotSpot(this.currentHotSpotConfig);
    this.viewer.lookAt(
      pitch,
      yaw,
      this.origHfovBounds,
      100, // animation time in ms
      ({ pitch, yaw }) => {
        this.freezePannellumScreen(pitch, yaw);
      },
      { pitch, yaw }
    );
  };

  turnOffPannellumEvent(
    oPPP: OriginalPanellumPositionParameters //oPPP is original panellum position parameters
  ) {
    this.fieldIssueService.lastAddedHostspot &&
      this.viewer.removeHotSpot(this.fieldIssueService.lastAddedHostspot.id);
    this.viewer.off("mouseup");
    this.viewer.setPitchBounds(oPPP.origPitchBounds);
    this.viewer.setYawBounds(oPPP.origYawBounds);
    this.viewer.setHfovBounds(oPPP.origHfovBounds);
  }

  getStatusValues() {
    this.lookupSvc.getAll("fieldIssueStatus").subscribe(
      (data: any[]) => {
        this.statusCheckboxValues = data;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getPriorityValues() {
    this.lookupSvc.getAll("fieldIssuePriority").subscribe(
      (data: any[]) => {
        this.priorityCheckboxValues = data;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getMasterData(projectId) {
    this.masterDataSvc.getMasterData(projectId).subscribe(
      (data) => {
        data?.master?.workPackage.forEach((wp) => {
          if (
            wp.level1 &&
            wp.level1.length > 0 &&
            wp.level2 &&
            wp.level2.length > 0
          ) {
            this.workTradeArray.push(wp);
          }
        });
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  applyFilterOnFI(fromChipDeletion = false) {
    this.uiService.show();
    this.filterChips = [];
    if (this.searchText == "") {
      this.filteredFieldIssues = [...this.allFieldIssues];
    }
    this.selectedStatusCheckboxes = this.filterForm.get("status").value;
    this.selectedPriorityCheckboxes = this.filterForm.get("priority").value;
    this.selectedWorkTradeCheckboxes = this.filterForm.get("workTrade").value;
    if (
      (this.selectedStatusCheckboxes.length !== 0 ||
        this.selectedPriorityCheckboxes.length !== 0 ||
        this.selectedWorkTradeCheckboxes.length !== 0 ||
        this.filterForm.value.startDate ||
        this.filterForm.value.endDate) &&
      !fromChipDeletion
    ) {
      this.isFilterSet = true;
    } else if (
      this.selectedStatusCheckboxes.length == 0 &&
      this.selectedPriorityCheckboxes.length == 0 &&
      this.selectedWorkTradeCheckboxes.length == 0 &&
      !this.filterForm.value.startDate &&
      !this.filterForm.value.endDate &&
      fromChipDeletion
    ) {
      this.isFilterSet = false;
    }
    if (this.selectedStatusCheckboxes?.length > 0) {
      for (let selectedStatus of this.selectedStatusCheckboxes) {
        const selectedStatusValue = this.statusCheckboxValues.find(
          (ele) => ele.key == selectedStatus
        );
        this.filterChips.push({
          keyValue: `Status: ${selectedStatusValue.value}`,
        });
      }
      this.filteredFieldIssues = this.filteredFieldIssues.filter((fi) => {
        return this.selectedStatusCheckboxes.includes(fi.status);
      });
    }
    if (this.selectedPriorityCheckboxes?.length > 0) {
      for (let selectedPriority of this.selectedPriorityCheckboxes) {
        const selectedPriorityValue = this.priorityCheckboxValues.find(
          (ele) => ele.key == selectedPriority
        );
        this.filterChips.push({
          keyValue: `Priority: ${selectedPriorityValue.value}`,
        });
      }
      this.filteredFieldIssues = this.filteredFieldIssues.filter((fi) => {
        return this.selectedPriorityCheckboxes.includes(fi.priority);
      });
    }
    if (this.selectedWorkTradeCheckboxes?.length > 0) {
      for (let selectedWorkTrade of this.selectedWorkTradeCheckboxes) {
        const selectedWorkTradeValue = this.workTradeArray.find(
          (ele) => ele.tradeId == selectedWorkTrade
        );
        this.filterChips.push({
          keyValue: `Work Trade: ${selectedWorkTradeValue.tradeName}`,
        });
      }
      this.filteredFieldIssues = this.filteredFieldIssues.filter((fi) => {
        return this.selectedWorkTradeCheckboxes.includes(fi.workTrade);
      });
    }
    if (this.filterForm.value.startDate && this.filterForm.value.endDate) {
      this.filterChips.push({
        keyValue: `Date Range: ${moment
          .tz(this.filterForm.value.startDate, this.timeZone)
          .format("DD MMM YYYY")} - ${moment
          .tz(this.filterForm.value.endDate, this.timeZone)
          .format("DD MMM YYYY")}`,
      });
      this.filteredFieldIssues = this.filteredFieldIssues.filter((fi) => {
        const fiDueDate = moment.tz(fi.dueDate, this.timeZone);
        return (
          fiDueDate.isSameOrAfter(
            moment.tz(this.filterForm.value.startDate, this.timeZone)
          ) &&
          fiDueDate.isSameOrBefore(
            moment.tz(this.filterForm.value.endDate, this.timeZone)
          )
        );
      });
    }
    this.originalEmptySearchFI = [...this.filteredFieldIssues];
    this.localStorage.setItem(
      `${this.userService.getCurrentUser().id}_field_issue_filter`,
      this.filterForm.value
    );
    this.uiService.hide();
    this.closeFilter();
  }

  get filterFormV() {
    return this.filterForm.controls;
  }

  closeFilter() {
    this.isFilterOpen = false;
  }

  resetFilterForm() {
    this.isFilterSet = false;
    this.selectedPriorityCheckboxes = [];
    this.selectedStatusCheckboxes = [];
    this.selectedWorkTradeCheckboxes = [];
    this.filterForm.get("status").setValue(this.selectedStatusCheckboxes);
    this.filterForm.get("priority").setValue(this.selectedPriorityCheckboxes);
    this.filterForm.get("workTrade").setValue(this.selectedWorkTradeCheckboxes);
    this.filterForm.get("startDate").setValue(null);
    this.filterForm.get("endDate").setValue(null);
    if (this.searchText == "") {
      this.originalEmptySearchFI = [...this.allFieldIssues];
    }
    return;
  }

  toggleSelection(value: string, type: string): void {
    if (type == "status") {
      const index = this.selectedStatusCheckboxes.indexOf(value);
      if (index >= 0) {
        this.selectedStatusCheckboxes.splice(index, 1);
      } else {
        this.selectedStatusCheckboxes.push(value);
      }
      this.filterForm.get("status").setValue(this.selectedStatusCheckboxes);
    } else if (type == "priority") {
      const index = this.selectedPriorityCheckboxes.indexOf(value);
      if (index >= 0) {
        this.selectedPriorityCheckboxes.splice(index, 1);
      } else {
        this.selectedPriorityCheckboxes.push(value);
      }
      this.filterForm.get("priority").setValue(this.selectedPriorityCheckboxes);
    } else if (type == "workTrade") {
      const index = this.selectedWorkTradeCheckboxes.indexOf(value);
      if (index >= 0) {
        this.selectedWorkTradeCheckboxes.splice(index, 1);
      } else {
        this.selectedWorkTradeCheckboxes.push(value);
      }
      this.filterForm
        .get("workTrade")
        .setValue(this.selectedWorkTradeCheckboxes);
    }
  }

  loadHotspots = () => {
    if (this.viewer) {
      for (let hotspot of this.fieldIssueHotspots) {
        // filter scene id from here for current scene
        this.viewer.addHotSpot({
          ...hotspot,
          text: hotspot.tooltip,
          cssClass: "custom-hotspot",
          createTooltipFunc: this.customHotspotTooltipFunc,
          createTooltipArgs: [hotspot.tooltip],
        });
      }
    }
  };

  customHotspotTooltipFunc = (hotSpotDiv: HTMLDivElement, args: string) => {
    hotSpotDiv.classList.add("custom-tooltip");
    var span = document.createElement("span");
    span.innerHTML = args[0];
    hotSpotDiv.appendChild(span);
    span.style.width = span.scrollWidth - 20 + "px";
    span.style.marginLeft =
      -(span.scrollWidth - hotSpotDiv.offsetWidth) / 2 + "px";
    span.style.marginTop = -span.scrollHeight - 12 + "px";
  };

  openFI(fi: FI) {
    this.ngOnDestroy();
    this.closeFieldIssueListPanel(true, "open_existing_issue", fi);
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
    for (let hotspot of this.fieldIssueHotspots) {
      this.viewer?.removeHotSpot(hotspot.id);
    }
  }

  removeSpecifiedFilter(chip: string) {
    const [filterCategory, filterValue] = chip
      .split(":")
      .map((ele) => ele.trim().toLowerCase());
    switch (filterCategory) {
      case "status":
        {
          const selectedStatusValue = this.statusCheckboxValues.find(
            (ele) => ele.value.toLowerCase() == filterValue
          );
          const index = this.selectedStatusCheckboxes.indexOf(
            selectedStatusValue.key
          );
          if (index >= 0) {
            this.selectedStatusCheckboxes.splice(index, 1);
          }
          this.filterForm.get("status").setValue(this.selectedStatusCheckboxes);
        }
        break;
      case "priority":
        {
          const selectedPriorityValue = this.priorityCheckboxValues.find(
            (ele) => ele.value.toLowerCase() == filterValue
          );
          const index = this.selectedPriorityCheckboxes.indexOf(
            selectedPriorityValue?.key
          );
          if (index >= 0) {
            this.selectedPriorityCheckboxes.splice(index, 1);
          }
          this.filterForm
            .get("priority")
            .setValue(this.selectedPriorityCheckboxes);
        }
        break;
      case "work trade":
        {
          const selectedWorkTradeValue = this.workTradeArray.find(
            (ele) => ele.tradeName.toLowerCase() == filterValue
          );
          const index = this.selectedWorkTradeCheckboxes.indexOf(
            selectedWorkTradeValue?.tradeId
          );
          if (index >= 0) {
            this.selectedWorkTradeCheckboxes.splice(index, 1);
          }
          this.filterForm
            .get("workTrade")
            .setValue(this.selectedWorkTradeCheckboxes);
        }
        break;
      case "date range":
        {
          this.filterForm.get("startDate").setValue(null);
          this.filterForm.get("endDate").setValue(null);
        }
        break;
    }
    this.applyFilterOnFI(true);
  }
}
