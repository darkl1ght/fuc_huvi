import {
  Component,
  OnInit,
  ChangeDetectorRef,
  Inject,
  ViewChild,
  TemplateRef,
  AfterViewInit,
  HostListener,
  OnDestroy,
} from "@angular/core";
import "leaflet";
import * as L from "leaflet";
import "leaflet-polylinedecorator";
import "leaflet-draw";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from "@angular/material/dialog";
import {
  TourImage,
  InteriorService,
  InteriorImage,
  UiService,
  StorageService,
  ProjectMedia,
  ProjectService,
  ExifData,
  Guid,
  MediaService,
  MediaMetaData,
  Project,
  InteriorTour,
  UserService,
  User,
  ForgeObject,
  BIM,
  ForgeViewerComponentConfig,
  ProjectUser,
  LocalStorageService,
  FieldIssueService,
  OriginalPanellumPositionParameters,
  FIDPCloseAction,
  ContentDataService,
  CreateFolderPayload,
  IMetadata,
  FolderTree,
  FI,
  AccessControlService,
  IntegrationService,
  WalkthroughVideoService,
  BimDataService,
  SnackbarService,
  BIMSyncModel,
  LinkedProject,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { TranslateService } from "@ngx-translate/core";
import { BlobServiceClient } from "@azure/storage-blob";
import { catchError, tap, take } from "rxjs/operators";
import { empty, Subscription } from "rxjs";
import * as moment from "moment-timezone";
import { FloorPlanAnnotationComponent } from "./floor-plan/floor-plan.component";
import { OverlayModule } from "@angular/cdk/overlay";
import { UntypedFormControl, Validators } from "@angular/forms";
import { DomSanitizer } from "@angular/platform-browser";
import { MatIconRegistry } from "@angular/material/icon";
import { Clipboard } from "@angular/cdk/clipboard";
import {
  bimSvgIcon,
  cdkConnectionPairs,
  cdkConnectionPairsProjectProgress,
  cdkConnectionPairsFieldIssueList,
  sortTourFeatures,
  uuidv4,
  prepareCanvasAndDraw,
  cdkConnectionPairsFieldIssueDetails,
  cdkConnectionPairsProcoreObservationDetails,
  editPathIcon,
  fieldIssueIcon,
  cdkConnectionPairsPunchList,
  cdkConnectionPairsImageEditor,
  ImageEnhancementProps,
} from "./walkthrough-utils";
import { BimViewerComponent } from "../bim-viewer/bim-viewer.component";
import { BIM_CONSTANTS } from "../bim-viewer/bim-viewer-constants";
import { DatetimeLocalePipe } from "src/app/shared/pipe/datetime-locale.pipe";
import html2canvas from "html2canvas";
import { FloorPlanConfigComponent } from "./floor-plan-config/floor-plan-config.component";
import { WalkthroughSplitComponent } from "../walkthrough-split/walkthrough-split.component";

declare const window: any;
declare const pannellum: any;

const enum Status {
  OFF = 0,
  RESIZE = 1,
  MOVE = 2,
}

@Component({
  selector: "walkthrough",
  templateUrl: "./walkthrough.component.html",
  styleUrls: ["./walkthrough.component.scss"],
})
export class WalkthroughComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild("trigger") trigger;
  @ViewChild("progressBarPanel") sideNave: any;
  @ViewChild("remarkDialog") remarkPanel: TemplateRef<any>;
  @ViewChild("discussionChat") discussionChat: any;
  @ViewChild("punchListSideBar") punchSideNav: any;
  @ViewChild("fieldIssueListSidebar") fieldIssueListSideNav: any;
  showPunchPanel: boolean = false;
  showFieldIssueListPanel: boolean = false;
  @ViewChild("selfSeveDashboard") selfServe: any;
  @ViewChild("projectprogressBarPanel") projectProgressBar;
  @ViewChild("forgeViewer", { static: false }) forgeViewer: BimViewerComponent;
  showSelfServe: Boolean = false;
  showProjectProgress: boolean = false;

  isTourLocked: boolean = true;

  selected: string = "currentScene";
  showCreateRemarks: boolean = false;
  remarksDescription: string;
  remarksFormControl = new UntypedFormControl("", [Validators.required]);

  selectedImageHotSpotId: string;
  interiorTour: InteriorTour;
  filteredInteriorList: InteriorTour[] = [];
  currentTour: TourImage;
  imageAccessToken: string;
  accessToken: string;
  projectId: string;

  // svg things
  svgHeight: number = 300;
  svgWidth: number = 300;
  tourList: TourImage[] = [];
  selectedTourId: string;

  //leaflet
  floorPlanMap: L.Map;
  featureGroup: L.FeatureGroup;
  bounds: L.LatLngBounds;
  imageURL: string;
  imageOverlay: L.ImageOverlay;
  markerLayer: L.Layer;
  polyLineLayer: L.Layer;
  featureGroups: {
    id: string;
    featureGroup: L.FeatureGroup;
    lastVisitedImage: string;
  }[] = [];
  markers: L.Marker[] = [];
  prevMarker: L.Marker;
  firstFloorImage: boolean = false;
  lastVisitedImageId: string;
  selectedImageNumber: number = 1;

  errors: any;

  //progress bar
  showProgressBar: boolean = true;
  viewer: any;
  sceneId: string;
  remark: string = "";
  remarkDialogRef: any;
  remarks = [];
  showAll: boolean = false;
  isUnitLevel: boolean = false;

  //tourList
  tourListData: TourImage[] = [];
  currentTourId: string = "";
  towerName: string = "";
  showDiscussion: boolean = false;
  remarkId: string = "";
  interiorId: string = "";
  isRemark: boolean = false;
  isOpen: boolean = false;
  shareLink: string = null;
  isCompareOverlayOpen: boolean = false;
  showBimViewer: boolean = false;
  forgeObject: ForgeObject = null;
  selectedState: Number;
  bim: BIM;
  forgeModelOffset: any;
  forgeViewerConfig: ForgeViewerComponentConfig;
  forgeViewerViewPointQueue: any = [];

  x = 0;
  y = 100;
  px = 0;
  py = 0;
  width = 350;
  height = 200;
  draggingCorner = false;
  resizer: Function;
  status: Status;
  fpOpacity: 0.4;
  snapshot: any;

  publishedTowers: TourImage[] = [];
  currentTowerId: string;
  project: Project;
  currentUser: User;
  currentFloorPlanOrientation: Number;
  bimAngularDeviationFromTrueNorth: Number;
  isPanoramaLoaded: Boolean = false;
  isLastImage: Boolean = false;
  isSplitLockButtonEnabled: Boolean = false;

  isWBSStatus: Boolean = false;
  selfServeAcces: Boolean = false;

  actionPanelPositionPairs: OverlayModule[] = cdkConnectionPairs;
  actionPanelPositionPairsForProjectProgress: OverlayModule[] =
    cdkConnectionPairsProjectProgress;
  actionPanelPositionPairsForFieldIssue: OverlayModule[] =
    cdkConnectionPairsFieldIssueList;
  actionPanelPositionPairsForFieldIssueDetail: OverlayModule[] =
    cdkConnectionPairsFieldIssueDetails;
  actionPanelPositionPairsForProcoreObservationDetail: OverlayModule[] =
    cdkConnectionPairsProcoreObservationDetails;
  actionPanelPositionPairsForPunchList: OverlayModule[] =
    cdkConnectionPairsPunchList;

  lat: number;
  lng: number;
  location: string = "";
  projectUsers: ProjectUser[] = [];

  isProjectProgressUpdatePanelVisible: boolean = false;
  isProjectProgressDashboardPanelVisible: boolean = false;
  isFieldIssueListPanelVisible: boolean = false;
  isFieldIssueDetailPanelVisible: boolean = false;
  isProcoreObservationDetailPanelVisible: boolean = false;
  isPunchListPanelVisible: boolean = false;
  showCreateFieldIssueButtons: boolean = false;
  isNextButtonDisabled: boolean = true;
  firstFIClickSubs: Subscription;
  refreshFalseRemoveHotspotTrue: FIDPCloseAction = {
    refresh: false,
    removeHotspot: true,
    setOriginalBound: true,
    type: "close_without_save",
  };
  fiDetailPanelHeading: string;

  cabinetId: string;
  companyId: string;
  cabinetMetadata: IMetadata;
  floorLevelFolderId: string;
  folderTree: FolderTree;
  hidePanoramaControls: boolean = false;

  contentDataProjectFolderId!: string;
  linkedProject: LinkedProject;

  //delete Image
  deleteImageInfo: string = null;
  displayDeleteImagePanel: boolean = false;

  actionPanelPositionPairsForImageEditor: OverlayModule[] =
    cdkConnectionPairsImageEditor;

  imageEnhancementProps: ImageEnhancementProps;
  isImageEditorPanelVisible: boolean = false;

  walkthroughSplitComponentRef: MatDialogRef<WalkthroughSplitComponent>;
  floorPlanAnnotationComponentRef: MatDialogRef<FloorPlanAnnotationComponent>;
  floorPlanConfigComponentRef: MatDialogRef<FloorPlanConfigComponent>;

  excludeCaptureDateForInterior: boolean = false;

  constructor(
    private userService: UserService,
    @Inject(MAT_DIALOG_DATA) private data: any,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<WalkthroughComponent>,
    private clipboard: Clipboard,
    private storageSvc: StorageService,
    private snackService: SnackbarService,
    private mediaService: MediaService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private interiorService: InteriorService,
    private bimDataService: BimDataService,
    private uiService: UiService,
    private ts: TranslateService,
    private cdr: ChangeDetectorRef,
    private accessControlService: AccessControlService,
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer,
    private integrationService: IntegrationService,
    private projectSvc: ProjectService,
    private dateTimeLocalPipe: DatetimeLocalePipe,
    private localStorage: LocalStorageService,
    private fieldIssueService: FieldIssueService,
    private contentDataService: ContentDataService,
    public walkthroughVideoService: WalkthroughVideoService
  ) {
    iconRegistry.addSvgIconLiteral(
      "svgIcon",
      sanitizer.bypassSecurityTrustHtml(bimSvgIcon)
    );
    iconRegistry.addSvgIconLiteral(
      "editPath",
      sanitizer.bypassSecurityTrustHtml(editPathIcon)
    );
    iconRegistry.addSvgIconLiteral(
      "field-issue",
      sanitizer.bypassSecurityTrustHtml(fieldIssueIcon)
    );
  }

  ngOnInit() {
    this.currentUser = this.userService.getCurrentUser();
    this.currentTowerId = this.data.towerId;
    this.projectId = this.data.projectId;
    this.towerName = this.data.towerName;
    this.tourListData = this.data.tourListData;
    this.bim = this.data.bim;

    this.currentTour = this.data.tour;
    this.currentTourId = this.currentTour.tourId;
    this.excludeCaptureDateForInterior =
      this.data.excludeCaptureDateForInterior;
    this.forgeObject = this.bim?.forgeObject ? this.bim?.forgeObject : null;
    this.forgeModelOffset = this.bim?.forgeObject ? this.bim?.offset : null;
    this.filteredInteriorList = this.data.interiors.filter(
      (interior) =>
        !!interior.floorWalkthough?.find((tower) => tower.publishedCount > 0)
    );
    this.interiorId = this.currentTour.interiorId;
    this.currentFloorPlanOrientation = this.currentTour.floorPlanOrientation;
    this.bimAngularDeviationFromTrueNorth =
      this.currentTour.bimAngularDeviationFromTrueNorth ?? 0;
    this.setForgeViewerConfig(
      this.currentTour,
      this.forgeObject,
      this.forgeModelOffset
    );
    this.fpBlobContent(this.currentTour, this.data.imageId);
    this.getTourData(this.currentTour, this.data.imageId);

    this.getToken();

    this.getTourList();

    this.getTourWBSStatus(this.currentTour);

    this.getInteriorData(this.projectId, this.interiorId);

    this.showBimViewer = this.bim?.forgeObject && this.data.showBimByDefault;

    // Load BIM viewer by default
    if (this.showBimViewer) {
      this.setBimEvent(BIM_CONSTANTS.INITIAL_LOAD);
    }

    if (this.projectId) {
      if (!this.lat || !this.lng || !this.location) {
        this.getProjectLocation();
      }
    }
    this.checkSelfServeAccess();
    this.companyId = this.localStorage.getClientId();
    this.projectId = this.localStorage.getProjectId();
    this.contentDataService
      .getProjectFolder(this.companyId, this.projectId, "interior")
      .subscribe({
        next: (data) => {
          this.uiService.show();
          this.cabinetId = data.cabinet.id;
          this.cabinetMetadata = data.cabinet.metadata;
          this.contentDataProjectFolderId = data.folder.id;
          this.createFloorLevelFolder(
            this.contentDataProjectFolderId,
            this.currentTour
          );
        },
        error: () => {
          this.snackService.errorSnackBar(
            this.ts.instant("library.messages.fetchFailed")
          );
        },
      });
    this.data.imageId = null;

    this.integrationService.getProcoreLinkedProject(this.projectId).subscribe({
      next: (data) => {
        this.linkedProject = data.procoreIntegration;
      },
    });
  }

  onInteriorChange(e: any) {
    this.closeDialogs();
    this.forgeViewerViewPointQueue = [];
    this.remarks = [];
    this.markers = [];
    this.isProjectProgressUpdatePanelVisible = false;
    this.isProjectProgressDashboardPanelVisible = false;
    this.showProgressBar = false;
    this.isPunchListPanelVisible = false;
    this.isFieldIssueListPanelVisible = false;
    this.isFieldIssueDetailPanelVisible = false;
    this.hidePanoramaControls = false;
    this.showCreateFieldIssueButtons = false;

    //Remove the marker if in between adding a field issue
    if (this.fieldIssueService?.lastAddedHostspot?.id) {
      this.viewer?.removeHotSpot(this.fieldIssueService.lastAddedHostspot.id);
    }

    this.interiorId = e.value;
    let isTowerFound: boolean = true;
    let isFloorTourFound: boolean = true;

    //Pick first tower if current tower is not found in the selected interior
    let pickedTower = this.filteredInteriorList
      .find((interior) => interior.interiorId == this.interiorId)
      .floorWalkthough?.find(
        (tower) =>
          tower.publishedCount > 0 && tower.towerId == this.currentTowerId
      );

    if (pickedTower) {
      isTowerFound = true;
    } else {
      isTowerFound = false;
      pickedTower = this.filteredInteriorList
        .find((interior) => interior.interiorId == this.interiorId)
        .floorWalkthough.find((floor) => floor.publishedCount > 0);
    }

    this.towerName = pickedTower.towerName;
    this.currentTowerId = pickedTower.towerId;
    this.bim = pickedTower.bim;
    this.forgeObject = this.bim?.forgeObject;
    this.forgeModelOffset = this.bim?.offset;

    //get the floor tours
    this.uiService.show();
    this.interiorService
      .getWalkthroughForTower(
        this.projectId,
        this.interiorId,
        this.currentTowerId
      )
      .subscribe({
        next: (data) => {
          this.tourListData = data.tours.filter(
            (floor: any) => floor.isPublished && floor.isActive
          );

          //Pick first location if current floor is not found
          let pickedFloorTour = data.tours.find(
            (floor: any) =>
              floor.locationId == this.currentTour.locationId &&
              floor.isPublished &&
              floor.isActive &&
              floor.images.length > 0
          );

          if (pickedFloorTour) {
            isFloorTourFound = true;
            this.currentTour = pickedFloorTour;
          } else {
            isFloorTourFound = false;
            this.currentTour = data.tours.find(
              (floor: any) =>
                floor.isPublished && floor.isActive && floor.images.length > 0
            );
          }

          if (!isTowerFound) {
            this.snackService.warningSnackBar(
              this.ts.instant("interior.virtualTour.messages.noTowerData")
            );
          } else if (!isFloorTourFound) {
            this.snackService.warningSnackBar(
              this.ts.instant("interior.virtualTour.messages.noFloorTourData")
            );
          }

          this.currentTourId = this.currentTour?.tourId;
          this.currentFloorPlanOrientation =
            this.currentTour?.floorPlanOrientation;
          this.bimAngularDeviationFromTrueNorth =
            this.currentTour?.bimAngularDeviationFromTrueNorth ?? 0;
          this.setForgeViewerConfig(
            this.currentTour,
            this.forgeObject,
            this.forgeModelOffset
          );
          this.fpBlobContent(this.currentTour, null);
          this.getTourData(this.currentTour, null);
          this.getTourList();
          this.getTourWBSStatus(this.currentTour);
          this.getInteriorData(this.projectId, this.interiorId);
          this.showBimViewer =
            this.bim?.forgeObject && this.data.showBimByDefault;

          // Load BIM viewer by default
          if (this.showBimViewer) {
            this.setBimEvent(BIM_CONSTANTS.INITIAL_LOAD);
          }

          this.contentDataService
            .getProjectFolder(this.companyId, this.projectId, "interior")
            .subscribe({
              next: (data) => {
                this.uiService.show();
                this.cabinetId = data.cabinet.id;
                this.cabinetMetadata = data.cabinet.metadata;
                this.contentDataProjectFolderId = data.folder.id;
                this.createFloorLevelFolder(
                  this.contentDataProjectFolderId,
                  this.currentTour
                );
              },
              error: () => {
                this.snackService.errorSnackBar(
                  this.ts.instant("library.messages.fetchFailed")
                );
              },
            });
          this.data.imageId = null;
          this.uiService.hide();
        },
        error: () => {
          this.uiService.hide();
        },
      });
  }

  splitScreenView() {
    if (this.tourListData.length > 0) {
      this.walkthroughSplitComponentRef = this.dialog.open(
        WalkthroughSplitComponent,
        {
          panelClass: "full-screen-dialog",
          disableClose: true,
          data: {
            tourListData: this.tourListData,
            tour: this.tourListData.find(
              (floor) => floor.locationId == this.currentTour.locationId
            ),
            towerName: this.towerName,
            towerId: this.currentTowerId,
            projectId: this.projectId,
          },
        }
      );
    }
  }

  createFloorLevelFolder(projectFolderId, currentTour: TourImage) {
    const createFolderPayload: CreateFolderPayload = {
      name: currentTour.locationId,
      description: "Floor Folder",
      cabinetRefId: this.cabinetId,
      parentFolderRefId: projectFolderId,
      projectId: this.projectId,
      additionalInfo: `tourId:${currentTour.tourId}`,
      status: true,
    };

    this.contentDataService.createFolder(createFolderPayload).subscribe({
      next: (data) => {
        if (data.message?.split(":")[0] == "10001") {
          // folder already exists
          this.contentDataService
            .getProjectFolderTree(this.companyId, this.projectId, "interior")
            .subscribe({
              next: (folderTree) => {
                this.folderTree = folderTree;
                for (let folder of folderTree.subFolders) {
                  if (folder.name == currentTour.locationId) {
                    this.floorLevelFolderId = folder.id;
                    this.localStorage.setItem(
                      "floorLevelFolderId",
                      JSON.stringify(this.floorLevelFolderId)
                    );
                  }
                }
                const fieldIssueObject =
                  this.fieldIssueService.getFieldIssueObject();
                if (!!fieldIssueObject) {
                  this.openFieldIssueListPanel("view_field_issue");
                }
              },
            });
          this.uiService.hide();
        } else {
          this.floorLevelFolderId = data.id;
          this.localStorage.setItem(
            "floorLevelFolderId",
            JSON.stringify(this.floorLevelFolderId)
          );
          const fieldIssueObject = this.fieldIssueService.getFieldIssueObject();
          if (!!fieldIssueObject) {
            this.openFieldIssueListPanel("view_field_issue");
          }
          this.uiService.hide();
        }
      },
      error: () => {
        this.uiService.hide();
      },
    });
  }

  // Used to pass data to the data service
  setBimEvent(type: string, eventData?: any) {
    if (BIM_CONSTANTS.INITIAL_LOAD === type)
      this.forgeViewer && this.forgeViewer.tearDownViewer();
    this.bimDataService.sendData(type, eventData, this.forgeViewerConfig);
  }

  ngOnChanges(): void {
    if (this.projectId) {
      if (!this.lat || !this.lng || !this.location) {
        this.getProjectLocation();
      }
    }
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  getProjectLocation() {
    this.projectSvc.get(this.projectId).subscribe(
      (data) => {
        this.lat = data.lat;
        this.lng = data.lng;
        this.location = data.location;
        this.projectUsers = data.users;
        this.isUnitLevel = data.isUnitLevel;
      },
      (error) => {
        this.errors = error;
      }
    );
  }

  generateShareLink() {
    const shareInfo: any = {
      clientId: this.localStorage.getClientId(),
      projectId: this.currentTour.projectId,
      interiorId: this.currentTour.interiorId,
      towerId: this.currentTour.towerId,
      tourId: this.currentTour.tourId,
      imageId: this.sceneId,
    };
    const objectId = shareInfo.tourId + "_" + shareInfo.imageId;
    this.projectSvc
      .generateShareLink("interior", objectId, shareInfo)
      .subscribe(
        (data: any) => {
          this.isOpen = true;
          const share = data.share;
          this.shareLink = eval("`" + this.config.shareUrl + "`");
        },
        (error) => {
          this.errors = error;
        }
      );
  }
  copyShareLink() {
    if (!!this.shareLink) {
      this.clipboard.copy(this.shareLink);
      this.snackService.successSnackBar(
        this.ts.instant("general.messages.copyLink")
      );
    }
  }

  getTourWBSStatus(currentTour) {
    this.isWBSStatus = false;
    this.interiorService
      .getTourWBSStatus(
        this.projectId,
        currentTour.tourId,
        currentTour.towerId,
        currentTour.locationId
      )
      .subscribe(
        (data) => {
          this.isWBSStatus = data.status;
        },
        () => {}
      );
  }

  checkSelfServeAccess() {
    this.interiorService.checkSelfServeAccess(this.projectId).subscribe(
      (data) => {
        this.selfServeAcces = data.access;
      },
      () => {}
    );
  }

  getInteriorData(projectId, interiorId) {
    this.interiorService.getInteriorById(projectId, interiorId).subscribe(
      (data) => {
        this.interiorTour = data.data;
      },
      () => {}
    );
  }

  async getTourList() {
    this.uiService.show();
    let tourByTower: TourImage[] = [];
    this.interiorService
      .getTourDetails(this.projectId, this.interiorId)
      .subscribe(
        (data) => {
          tourByTower = data.tours && data.tours.length > 0 ? data.tours : [];
          this.publishedTowers = [];

          for (let i = 0; i < tourByTower.length; i++) {
            const published = tourByTower[i]["tours"].some(
              (x) => x.isPublished === true
            );
            if (published) {
              this.publishedTowers.push(tourByTower[i]);
            }
          }

          this.uiService.hide();
        },
        (err) => {
          this.uiService.hide();
          this.errors = err;
        }
      );
  }

  changeTower(e) {
    this.resetWalkthroughVideoService();
    this.currentTowerId = e.value;
    this.getLatestTourByTower(this.projectId, this.currentTowerId);

    //close progress bar
    this.closeProjectProgressBar();
  }

  resetViewerControlsData() {
    this.selectedImageNumber = 1;
    this.isLastImage = false;
  }

  getLatestTourByTower(projectId, towerId) {
    this.isSplitLockButtonEnabled = false;

    const selectedTower: any = this.publishedTowers.find(
      (x) => x.towerId === towerId
    );

    this.towerName = selectedTower.towerName;
    this.tourListData = selectedTower.tours.filter(
      (t) => t.isPublished && t.isActive
    );
    this.currentTour = this.tourListData[0];

    this.currentFloorPlanOrientation =
      this.tourListData[0].floorPlanOrientation;

    this.bimAngularDeviationFromTrueNorth =
      this.tourListData[0].bimAngularDeviationFromTrueNorth ?? 0;

    if (this.showBimViewer) {
      this.showBimViewer = selectedTower && selectedTower.bim?.forgeObject;

      if (this.showBimViewer) {
        // Update the forge viewer details
        this.forgeObject = selectedTower.bim.forgeObject;
        this.forgeModelOffset = selectedTower.bim.offset;
        this.setForgeViewerConfig(
          this.currentTour,
          this.forgeObject,
          this.forgeModelOffset
        );

        // Trigger initial load event
        this.setBimEvent(BIM_CONSTANTS.INITIAL_LOAD);
      }
    } else {
      const doesBIMExist = selectedTower && selectedTower.bim?.forgeObject;
      if (doesBIMExist) {
        this.forgeObject = selectedTower.bim.forgeObject;
        this.forgeModelOffset = selectedTower.bim.offset;
        this.setForgeViewerConfig(
          this.currentTour,
          this.forgeObject,
          this.forgeModelOffset
        );

        // Trigger initial load event
        this.setBimEvent(BIM_CONSTANTS.INITIAL_LOAD);
      }
    }

    this.resetViewerControlsData();

    this.currentTourId = this.currentTour.tourId;

    //get wbs status of the tour
    this.getTourWBSStatus(this.currentTour);

    this.interiorService.getTourData(projectId, this.currentTourId).subscribe(
      (data) => {
        this.viewer.off();
        this.viewer.destroy();

        this.currentTour = data.tour;
        this.createFloorLevelFolder(
          this.contentDataProjectFolderId,
          this.currentTour
        );
        this.getTourData(this.currentTour);
        this.fpBlobContent(this.currentTour);
        this.interiorId = this.currentTour.interiorId;
        this.getToken();
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  loadFloorPlan(
    tour: TourImage,
    blobUrl: string,
    sharedImageId: string = null
  ) {
    try {
      this.uiService.show();

      this.markers.length = 0;

      if (this.floorPlanMap) {
        this.floorPlanMap.remove();
      }

      this.floorPlanMap = L.map("mapid", {
        crs: L.CRS.Simple,
        minZoom: -5,
        maxBoundsViscosity: 1,
      });

      if (this.featureGroup && this.floorPlanMap.hasLayer(this.featureGroup)) {
        this.floorPlanMap.removeLayer(this.featureGroup);
      }

      if (tour.features) {
        // Sort the features by their image number
        let { features } = tour.features;
        tour.features.features = sortTourFeatures(features);

        this.featureGroup = L.geoJSON(tour.features);
      }

      const imageUrl = blobUrl;
      const img = new Image();
      img.id = "mapImage";
      img.src = imageUrl;
      img.onload = () => {
        const w = img.width;
        const h = img.height;
        const bounds: any = [
          [-10, -10],
          [h, w],
        ];
        L.imageOverlay(imageUrl, bounds).addTo(this.floorPlanMap);
        this.floorPlanMap.fitBounds(bounds);
        this.floorPlanMap.setMaxBounds(bounds);
        this.floorPlanMap.addLayer(this.featureGroup);
        this.uiService.hide();
      };

      const featureGroupCopy: L.FeatureGroup = this.featureGroup;
      featureGroupCopy.eachLayer((layer: L.Marker) => {
        if (this.featureGroup.hasLayer(layer)) {
          this.featureGroup.removeLayer(layer);
        }
      });

      this.floorPlanMap.addLayer(this.featureGroup);
      this.preLoadImageBinding(tour, sharedImageId);
    } catch (error) {
      this.uiService.hide();
    }
  }

  getPathCoordinates(data: any) {
    let coordinates = [];
    for (let index in data._layers) {
      const x = data._layers[index]._latlng.lat;
      const y = data._layers[index]._latlng.lng;
      coordinates.push([x, y]);
    }

    return coordinates;
  }

  preLoadImageBinding(tour: TourImage, sharedImageId: string = null) {
    const currFlrFeatGroup = tour.features
      ? L.geoJSON(tour.features)
      : undefined;
    let imageNumber: number = 0;

    if (currFlrFeatGroup) {
      currFlrFeatGroup.eachLayer((layer: L.Marker) => {
        const latlng: L.LatLng = layer.getLatLng();
        const marker: InteriorImage = {} as InteriorImage;
        marker.imageId = layer.feature.properties.imageId;
        marker.imageName = layer.feature.properties.imageName;
        marker.imageNumber = ++imageNumber;
        this.addMarker(latlng, marker, null, sharedImageId);
      });

      // Fetch path coordinates and draw a line
      let pathCoordinates = this.getPathCoordinates(currFlrFeatGroup);
      this.polyLineLayer = L.polyline(pathCoordinates, {
        color: "#C0C0C0",
        weight: 5,
        opacity: 0.65,
      }).addTo(this.featureGroup);
    }
  }

  addMarker(
    latlng: L.LatLng,
    selectedImage: InteriorImage,
    markerLayer?: L.Layer,
    sharedImageId: string = null
  ) {
    if (markerLayer) {
      this.featureGroup.removeLayer(markerLayer);
    }
    const marker: L.Marker = L.marker(latlng, {
      icon: !!sharedImageId
        ? sharedImageId == selectedImage.imageId
          ? this.getMarkerIcon(selectedImage.imageNumber, true)
          : this.getMarkerIcon(selectedImage.imageNumber, false)
        : selectedImage.imageNumber === 1
        ? this.getMarkerIcon(selectedImage.imageNumber, true)
        : this.getMarkerIcon(selectedImage.imageNumber, false),
      opacity: selectedImage.imageNumber === 1 ? 1 : 0.75,
      //@ts-ignore
      // rotationAngle:
      //   selectedImage.imageNumber === 1 ? this.currentFloorPlanOrientation : 0,
    });

    if (selectedImage.imageNumber === 1) {
      this.forgeViewerViewPointQueue.push(latlng);
    }

    marker.feature = {
      type: "Feature",
      properties: {
        imageName: selectedImage.imageName,
        imageId: selectedImage.imageId,
        imageNumber: selectedImage.imageNumber,
      },
      geometry: null,
      id: L.Util.stamp(marker),
    };

    if (
      this.lastVisitedImageId &&
      this.lastVisitedImageId === selectedImage.imageId
    ) {
      marker.setIcon(
        this.getMarkerIcon(marker.feature.properties.imageNumber, true)
      );
    }

    marker
      .on("click", () => {
        this.selectedImageNumber = marker.feature.properties.imageNumber;

        // Check if the selected marker is the last image
        let { scenes } = this.viewer.getConfig();
        Object.keys(scenes).length === this.selectedImageNumber
          ? (this.isLastImage = true)
          : (this.isLastImage = false);

        //@ts-ignore
        marker.setRotationOrigin("59px 62px");
        this.isFieldIssueListPanelVisible = false;
        this.showSelectedImage(selectedImage);
        this.forgeViewerViewPointQueue.push(latlng);

        if (this.showBimViewer) {
          this.setBIMViewPointChanged(latlng);
        }

        this.featureGroup.eachLayer((fgLayer: L.Marker) => {
          // Re render layers other than the polyline layer
          if (fgLayer !== this.polyLineLayer) {
            //@ts-ignore
            //fgLayer.setRotationAngle(0);
            fgLayer.setIcon(
              this.getMarkerIcon(fgLayer.feature.properties.imageNumber, false)
            );
          }
        });

        marker.setIcon(this.getMarkerIcon(this.selectedImageNumber, true));
        marker.setOpacity(1);
      })
      .addTo(this.featureGroup);

    this.markers.push(marker);
  }

  getMarkerIcon(imageNumber: number, isActiveImage: boolean) {
    let activeImageTorch = "assets/images/interior-torch.png";

    if (isActiveImage && this.currentFloorPlanOrientation !== undefined) {
      // return L.icon({
      //   iconUrl: activeImageTorch,
      //   iconSize: [120, 71], // size of the icon
      //   iconAnchor: [59, 62], // point of the icon which will correspond to marker's location
      // });
      return L.divIcon({
        className: "location-pin",
        html: `<div class="location-pin-container-compare"><img class="location-pin-image-active"><span class="location-pin-text-compare">${imageNumber}</span></div>`,
      });
    } else if (isActiveImage) {
      return L.divIcon({
        className: "location-pin",
        html: `<div class="location-pin-container-compare"><img class="location-pin-image-active"><span class="location-pin-text-compare">${imageNumber}</span></div>`,
      });
    } else {
      return L.divIcon({
        className: "location-pin",
        html: `<div class="location-pin-container"><img class="location-pin-image" /><span class="location-pin-text">${imageNumber}</span></div>`,
      });
    }
  }

  showSelectedImage(selectedImage: InteriorImage) {
    this.sceneId = selectedImage.imageId;
    this.viewer.loadScene(selectedImage.imageId, "same", "sameAzimuth", "same");
  }

  async getTourData(tour: TourImage, sharedImageId: string = null) {
    const container = this.config.virtualTourContainer;
    await this.interiorService.getReadToken(container).subscribe(
      (data) => {
        this.imageAccessToken = data.sasToken.token;
        this.remarks = tour.remarks;
        this.setBlobUrl(data.sasToken.token, tour, sharedImageId);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  setBlobUrl(token, tour: TourImage, sharedImageId: string = null) {
    // Image Azure blob folder structure  = WALKTHROUGH-TOUR-ID > IMAGE
    tour.images.forEach((image) => {
      if (image) {
        image.imageBlobUrl =
          this.config.virtualTourBlobUrl +
          tour.tourId +
          "/" +
          image.blobImageId +
          "?" +
          token;
      }
    });

    this.initializeViewer(tour.images, sharedImageId);
  }

  async fpBlobContent(tour: TourImage, sharedImageId: string = null) {
    const container = this.config.floorPlanContainer;
    this.interiorService
      .getBlobToken(container, tour.floorPlanBlobId)
      .subscribe(
        async (data) => {
          const imageUrl = data.sasToken.uri;
          this.loadFloorPlan(tour, imageUrl, sharedImageId);
        },
        (err) => {
          this.errors = err;
        }
      );
  }

  closeDialog(): void {
    this.closeDialogs();
    this.dialogRef.close();
  }

  takeSnap() {
    try {
      this.uiService.show();

      this.viewer
        .getRenderer()
        .render(
          (this.viewer.getPitch() / 180) * Math.PI,
          (this.viewer.getYaw() / 180) * Math.PI,
          (this.viewer.getHfov() / 180) * Math.PI,
          { returnImage: true }
        );

      const imageCanvas = this.viewer.getRenderer().getCanvas();

      if (!this.excludeCaptureDateForInterior) {
        let tourPublishDate = this.currentTour.tourPublishDate
          ? this.currentTour.tourPublishDate
          : this.currentTour.updatedAt;

        let formattedDate = `Captured on - ${this.dateTimeLocalPipe.transform(
          tourPublishDate
        )}`;

        let newCanvas = prepareCanvasAndDraw(
          imageCanvas.width,
          imageCanvas.height,
          imageCanvas,
          formattedDate
        );
        window.saveAs(
          newCanvas.toDataURL(),
          `${this.towerName} - ${this.currentTour.tourName}.jpeg`
        );
      } else {
        window.saveAs(
          imageCanvas.toDataURL(),
          `${this.towerName} - ${this.currentTour.tourName}.jpeg`
        );
      }

      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
    }
  }

  showProgressChart() {
    this.showProgressBar = true;
    this.sideNave.toggle();
  }

  closeProgressBar() {
    this.showProgressBar = false;
    this.sideNave.toggle();
  }

  showDiscussionChat(remark) {
    this.remarkId = remark.remarkId;
    this.showDiscussion = true;
    this.discussionChat.toggle();
  }

  closeDiscussion() {
    this.remarkId = "";
    this.showDiscussion = false;
    this.discussionChat.toggle();
  }

  dataURLtoFile(dataurl, filename) {
    const arr = dataurl.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  async uploadFiles(files) {
    let alert;
    try {
      this.uiService.show();
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.accessToken
      );
      const containerClient = blobServiceClient.getContainerClient(
        this.config.mediaContainer
      );
      const promises = [];
      for (const file of files) {
        const extn = "jpeg";
        const metaData = await this.getFileExif(file);
        const blockBlobClient = containerClient.getBlockBlobClient(
          metaData.blobRef
        );
        promises.push(blockBlobClient.uploadBrowserData(file));
        this.updateMetaData(metaData, extn);
      }
      await Promise.all(promises);
      alert = this.ts.instant("interior.virtualTour.messages.savedToMedia");
      this.snackService.successSnackBar(alert);
      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
      alert = this.ts.instant("interior.virtualTour.messages.failedToSave");
      this.snackService.errorSnackBar(alert);
    }
  }

  async getFileExif(file) {
    const metaData: ExifData = {} as ExifData;
    const fileId = Guid.newGuid();
    const extn = "jpeg";
    metaData.blobRef = fileId + "." + extn;
    metaData.fileId = fileId;

    metaData.dateTaken = new Date().toString();
    metaData.fileName = file.name;
    metaData.fileSize = file.size;
    return metaData;
  }

  private updateMetaData(metaData: ExifData, extn: string) {
    const media: ProjectMedia = {} as ProjectMedia;
    media.mediaId = metaData.fileId;
    media.blobContentId = metaData.blobRef;
    media.fileDate = metaData.dateTaken;
    media.mediaName = metaData.fileName;
    media.projectId = this.projectId;
    media.mediaType = { code: "MT10001", desc: "Image" };
    media.meta = this.getMetaData(metaData);

    this.mediaService
      .saveMedia(this.projectId, media)
      .pipe(
        take(1),
        tap((data) => {}),
        catchError(() => {
          return empty();
        })
      )
      .subscribe();
  }

  getToken() {
    const container = this.config.mediaContainer;
    this.storageSvc.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  getMetaData(exif: ExifData) {
    const meta: MediaMetaData = {} as MediaMetaData;
    meta.lat = exif.lat;
    meta.lng = exif.lng;
    meta.alt = exif.alt;
    meta.dateTaken = exif.dateTaken
      ? exif.dateTaken
      : moment(moment.utc()).format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
    meta.fileName = exif.fileName;
    meta.fileSize = exif.fileSize;
    return meta;
  }

  setHotSpot() {
    if (this.remarksFormControl.valid) {
      const currentPitch = this.viewer.getPitch();
      const currentYaw = this.viewer.getYaw();
      const currentHfov = this.viewer.getHfov();
      const remarkId = uuidv4();
      const remark = {
        id: remarkId,
        hfov: currentHfov,
        pitch: currentPitch,
        yaw: currentYaw,
        type: "info",
        text: this.remarksDescription,
      };
      this.updateRemark(remark);
    }
  }

  showCreateRemark() {
    this.showCreateRemarks = !this.showCreateRemarks;
  }

  private updateRemark(remark) {
    this.uiService.show();

    let interiorId = this.currentTour.interiorId;
    let tourId = this.currentTour.tourId;
    this.interiorService
      .updateRemark(this.projectId, interiorId, tourId, remark, this.sceneId)
      .pipe(
        take(1),
        tap((data) => {
          this.showCreateRemarks = false;
          this.remarksDescription = "";
          this.remarks = data.tour.remarks;
          this.viewer.addHotSpot(remark, this.sceneId);
        }),
        catchError(() => {
          return empty();
        })
      )
      .subscribe(() => this.uiService.hide());
  }

  removeRemark(remark) {
    this.uiService.show();

    this.viewer.loadScene(remark.sceneId);
    let interiorId = this.currentTour.interiorId;
    let tourId = this.currentTour.tourId;
    this.interiorService
      .removeRemark(this.projectId, interiorId, tourId, remark)
      .pipe(
        take(1),
        tap((data) => {
          this.sceneId = remark.sceneId;
          this.remarks = data.tour.remarks;
          this.viewer.removeHotSpot(remark.hotspot.id, remark.sceneId);
          this.uiService.hide();
        }),
        catchError(() => {
          return empty();
        })
      )
      .subscribe();
  }

  initializeViewer(images: InteriorImage[], sharedImageId: string = null) {
    this.viewer = pannellum.viewer("panorama", {
      scenes: {},
      sceneFadeDuration: 1000,
      author: "Huviair",
      showControls: false,
    });

    images.forEach((image, index) => {
      let hotspotList = this.currentTour.remarks.filter(
        (r) => r.sceneId === image.imageId
      );
      let hotspots = [];
      for (let i = 0; i < hotspotList.length; i++) {
        hotspots.push(hotspotList[i].hotspot);
      }

      this.viewer.setYawBounds([0, 360]);

      let imageOffsetFromNorth = image.offsetFromNorth ?? 0;

      this.viewer.addScene(image.imageId, {
        panorama: image.imageBlobUrl,
        pitch: -2,
        yaw: index === 0 ? -imageOffsetFromNorth : 0,
        hfov: 120,
        hotSpots: hotspots,
        northOffset: imageOffsetFromNorth,
      });
    });

    this.sceneId = !!sharedImageId ? sharedImageId : images[0].imageId;
    if (!!sharedImageId) {
      this.viewer.loadScene(this.sceneId, "same", "sameAzimuth", "same");
    } else {
      this.viewer.loadScene(this.sceneId);
    }
    // Events - for rotating the marker accordingly
    this.viewer.on("scenechange", (sceneId) => {
      this.isPanoramaLoaded = false;
      this.walkthroughVideoService.setImageLoading(true);

      if (this.currentFloorPlanOrientation !== undefined) {
        this.rotateSelectedMarker(sceneId);
      }
    });

    this.turnOnPanoramaOrientationListener();

    this.viewer.on(
      "panorama-orientation-changed",
      this.addMarkerRotationListener
    );

    this.viewer.on("load", () => {
      this.isPanoramaLoaded = true;
      this.walkthroughVideoService.setImageLoading(false);
    });
    this.viewer.on("error", () => (this.isPanoramaLoaded = false));
  }

  addMarkerRotationListener = () => {
    if (this.currentFloorPlanOrientation !== undefined) {
      this.rotateSelectedMarker();
    }
  };

  onPanoramaOrientationChanged = () => {
    // Pass event to BIM on orientation change of the panorame
    this.forgeViewer && this.triggerOrientationUpdated();
  };

  rotateSelectedMarker(sceneId?) {
    let { scene } = this.viewer.getConfig();
    let marker: L.Marker = this.markers.find((marker) =>
      sceneId
        ? marker.feature.properties.imageId === sceneId
        : marker.feature.properties.imageId === scene
    );

    //@ts-ignore
    // marker?.setRotationAngle(
    //   this.viewer.getYaw() +
    //     this.viewer.getNorthOffset() +
    //     this.currentFloorPlanOrientation
    // );
  }

  highlightRemark(remark) {
    if (remark) {
      if (this.sceneId === remark.sceneId) {
        this.viewer.lookAt(
          remark.hotspot.pitch,
          remark.hotspot.yaw,
          remark.hotspot.hfov
        );
      } else {
        this.sceneId = remark.sceneId;

        // Simulate an onCLick to reflect on the floor plan
        let marker: L.Marker = this.markers.find(
          (marker) => marker.feature.properties.imageId === this.sceneId
        );
        marker.fireEvent("click");

        this.viewer.loadScene(
          remark.sceneId,
          remark.hotspot.pitch,
          remark.hotspot.yaw,
          remark.hotspot.hfov
        );
      }
    }
  }

  onRemarkChange(val: string) {
    this.showAll = val === "allScenes" ? true : false;
  }

  navigateImage(direction: string) {
    if (!this.viewer) {
      return;
    }

    let imageNumber;
    switch (direction) {
      case "first":
        imageNumber = 1;
        break;
      case "next":
        imageNumber = this.selectedImageNumber + 1;
        break;
      case "previous":
        imageNumber = this.selectedImageNumber - 1;
        break;
      case "last":
        imageNumber = this.markers.length;
        break;
      default:
        break;
    }

    const marker: L.Marker = this.markers.find(
      (marker) => marker.feature.properties.imageNumber === imageNumber
    );
    marker.fireEvent("click");
  }

  zoomPanorama(type) {
    if (type === "in") {
      this.viewer.setHfov(this.viewer.getHfov() - 10);
    } else {
      this.viewer.setHfov(this.viewer.getHfov() + 10);
    }
  }

  //helper function to generate range of numbers
  range = (from, to, step) =>
    [...Array(Math.floor((to - from) / step) + 1)].map(
      (_, i) => from + i * step
    );
  deleteImages() {
    let imagesToDelete: any[] = [];
    const imageNumbers: any[] = !!this.deleteImageInfo
      ? this.deleteImageInfo.trim().length > 0
        ? this.deleteImageInfo.trim().split(",")
        : []
      : [];
    if (imageNumbers.length > 0) {
      imageNumbers.forEach((imgNumber) => {
        if (imgNumber.trim().length > 0) {
          if (!isNaN(imgNumber.trim())) {
            imagesToDelete.push(parseInt(imgNumber.trim()));
          } else if (
            imgNumber.trim().includes("-") &&
            imgNumber.trim().split("-").length == 2
          ) {
            const numberRange = imgNumber.trim().split("-");
            if (!isNaN(numberRange[0]) && !isNaN(numberRange[1])) {
              const startRange =
                parseInt(numberRange[0]) > parseInt(numberRange[1])
                  ? parseInt(numberRange[1])
                  : parseInt(numberRange[0]);
              const endRange =
                parseInt(numberRange[0]) > parseInt(numberRange[1])
                  ? parseInt(numberRange[0])
                  : parseInt(numberRange[1]);
              const numbers = this.range(startRange, endRange, 1);
              imagesToDelete = [...new Set([...imagesToDelete, ...numbers])];
            }
          }
        }
      });
    }
    if (imagesToDelete.length > 0) {
      this.interiorService
        .deleteInteriorImages(
          this.projectId,
          this.currentTourId,
          imagesToDelete
        )
        .subscribe(
          (data) => {
            this.resetWalkthroughVideoService();
            this.getLatestTour(this.projectId, this.currentTourId);
            this.closeProjectProgressBar();
            var alert = this.ts.instant(
              "interior.virtualTour.messages.imagesDeletedSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.closeDeletePanel();
          },
          (err) => {
            this.errors = err;
            var alert = this.ts.instant(
              "interior.virtualTour.messages.failedToSave"
            );
            this.snackService.errorSnackBar(alert);
          }
        );
    } else {
      var alert = this.ts.instant(
        "interior.virtualTour.messages.noImagesToDelete"
      );
      this.snackService.errorSnackBar(alert);
    }
  }
  displayDeleteImagesPanel() {
    this.deleteImageInfo = null;
    this.displayDeleteImagePanel = true;
  }
  closeDeletePanel() {
    this.deleteImageInfo = null;
    this.displayDeleteImagePanel = false;
  }

  toggleFullScreen() {
    this.viewer.toggleFullscreen();
  }

  changeTour(e) {
    this.resetWalkthroughVideoService();
    this.currentTourId = e.value;
    this.getLatestTour(this.projectId, this.currentTourId);
    this.closeProjectProgressBar();
  }

  turnOnPanoramaOrientationListener() {
    this.viewer &&
      this.viewer.on(
        "panorama-orientation-changed",
        this.onPanoramaOrientationChanged
      );
  }

  turnOffPanoramaOrientationListener() {
    this.viewer &&
      this.viewer.off(
        "panorama-orientation-changed",
        this.onPanoramaOrientationChanged
      );
  }

  getLatestTour(projectId, tourId) {
    this.uiService.show();
    this.interiorService.getTourData(projectId, tourId).subscribe(
      (data) => {
        this.uiService.hide();

        this.currentTour = data.tour;
        this.createFloorLevelFolder(
          this.contentDataProjectFolderId,
          this.currentTour
        );

        //get wbs status of the tour
        this.getTourWBSStatus(this.currentTour);

        this.viewer.off();

        this.viewer.destroy();

        this.currentFloorPlanOrientation =
          this.currentTour.floorPlanOrientation;
        this.setForgeViewerConfig(
          this.currentTour,
          this.forgeObject,
          this.forgeModelOffset
        );
        // Trigger floor change event
        this.setBimEvent(BIM_CONSTANTS.MODEL_FLOOR_CHANGED);

        // Reset the button controls data
        this.resetViewerControlsData();

        this.getTourData(this.currentTour);
        this.fpBlobContent(this.currentTour);

        this.interiorId = this.currentTour.interiorId;
        this.getToken();
      },
      (err) => {
        this.errors = err;
        this.uiService.hide();
      }
    );
  }

  createSnag() {
    this.floorPlanAnnotationComponentRef = this.dialog.open(
      FloorPlanAnnotationComponent,
      {
        width: "50%",
        disableClose: true,
        data: this.currentTour,
      }
    );
  }

  createNewSnag() {
    try {
      this.uiService.show();
      const fileName = this.currentTour.tourName;
      const screenshot: any = this.viewer
        .getRenderer()
        .render(
          (this.viewer.getPitch() / 180) * Math.PI,
          (this.viewer.getYaw() / 180) * Math.PI,
          (this.viewer.getHfov() / 180) * Math.PI,
          { returnImage: true }
        );

      this.snapshot = [this.dataURLtoFile(screenshot, fileName)];
      // this.showPunchPanel = true;
      // this.punchSideNav.toggle();
      this.isPunchListPanelVisible = true;

      this.uiService.hide();
    } catch (error) {
      this.uiService.hide();
    }
  }

  updateProjectProgressReport() {
    this.showProjectProgress = false;
    this.projectProgressBar.toggle();
    this.getLatestTour(this.projectId, this.currentTourId);
  }

  openSelfServeProgressBar() {
    // this.showSelfServe = true;
    // this.selfServe.toggle();
    this.isProjectProgressUpdatePanelVisible = false;
    this.isProjectProgressDashboardPanelVisible =
      !this.isProjectProgressDashboardPanelVisible;
  }

  closeSelfServeProgressBar() {
    // this.showSelfServe = false;
    // this.selfServe.toggle();
    this.isProjectProgressDashboardPanelVisible = false;
  }

  openProjectProgressBar() {
    // this.showProjectProgress = true;
    // this.projectProgressBar.toggle();
    this.isProjectProgressDashboardPanelVisible = false;
    this.isProjectProgressUpdatePanelVisible =
      !this.isProjectProgressUpdatePanelVisible;
  }

  closeProjectProgressBar() {
    // this.showProjectProgress = false;
    // this.projectProgressBar.toggle();
    this.isProjectProgressUpdatePanelVisible = false;
  }

  getLatestFieldIssueConfig() {
    return {
      towerName: this.towerName,
      tour: this.currentTour,
      towerId: this.currentTowerId,
      viewer: this.viewer,
      projectId: this.projectId,
      tourId: this.currentTour.tourId,
      floorId: this.currentTour.locationId,
    };
  }

  openFieldIssueListPanel(event: string) {
    this.hidePanoramaControls = true;
    this.fieldIssueService.setData(event, {
      ...this.getLatestFieldIssueConfig(),
    });
    this.isProjectProgressDashboardPanelVisible = false;
    this.isProjectProgressUpdatePanelVisible = false;
    this.isFieldIssueListPanelVisible = !this.isFieldIssueListPanelVisible;
  }

  closePunchPanel() {
    // this.showPunchPanel = false;
    // this.punchSideNav.toggle();
    this.isPunchListPanelVisible = false;
  }

  cancelFieldIssueCaptureMode() {
    this.showCreateFieldIssueButtons = false;
    this.openFieldIssueListPanel("cancel");
  }

  toggleRemarkListPanel() {
    this.isProjectProgressDashboardPanelVisible = false;
    this.isProjectProgressUpdatePanelVisible = false;
    this.isFieldIssueListPanelVisible = false;
    this.isRemark = !this.isRemark;
  }

  bottomRightResize(offsetX: number, offsetY: number) {
    // this.y += offsetY;
    this.width += offsetX;
    this.height += offsetY;
  }

  onCornerClick(event: MouseEvent, resizer?: Function) {
    this.draggingCorner = true;
    this.px = event.clientX;
    this.py = event.clientY;
    this.resizer = resizer;
    this.status = 1;
    event.preventDefault();
    event.stopPropagation();
  }

  @HostListener("document:mousemove", ["$event"])
  onCornerMove(event: MouseEvent) {
    if (!this.draggingCorner) {
      return;
    }

    let offsetX = event.clientX - this.px;
    let offsetY = event.clientY - this.py;

    if (this.status === Status.RESIZE) {
      this.floorPlanMap.invalidateSize();
      this.resizer(offsetX, offsetY);
    } else if (this.status === Status.MOVE) {
      return;
    }

    this.px = event.clientX;
    this.py = event.clientY;
  }

  @HostListener("document:mouseup", ["$event"])
  onCornerRelease() {
    this.draggingCorner = false;
  }

  setStatus(event: MouseEvent, status: number, func?) {
    if (status === 1) {
      this.draggingCorner = true;
      this.px = event.clientX;
      this.py = event.clientY;
      this.resizer = func;
      this.status = 1;
      event.preventDefault();
      event.stopPropagation();
    } else if (status === 2) {
      this.draggingCorner = true;
      this.px = event.clientX;
      this.py = event.clientY;
      this.status = 2;
    }
  }

  onDrag(x, y) {
    this.x = this.x + x;
    this.y = this.y + y;
  }

  performCompareOperation() {
    this.forgeViewer && this.forgeViewer.tearDownViewer();
    this.showBimViewer = !this.showBimViewer;

    // Load BIM on click
    if (this.showBimViewer) this.setBimEvent(BIM_CONSTANTS.INITIAL_LOAD);

    if (!this.showBimViewer) this.isSplitLockButtonEnabled = false;

    this.isCompareOverlayOpen = !this.isCompareOverlayOpen;
  }

  filteredRemarksCount() {
    return this.remarks.filter((remark) => remark.sceneId === this.sceneId)
      .length;
  }

  // Triggered after parent BIM has loaded
  forgeModelRootLoaded() {
    let lastViewPoint;
    if (this.forgeViewer && this.forgeViewerViewPointQueue.length > 0) {
      lastViewPoint = this.forgeViewerViewPointQueue.pop();

      this.setBIMViewPointChanged(lastViewPoint);

      this.isSplitLockButtonEnabled = true;

      this.forgeViewerViewPointQueue = [lastViewPoint];
    }
  }

  triggerOrientationUpdated() {
    this.setBimEvent(
      BIM_CONSTANTS.ORIENTATION_CHANGED,
      new BIMSyncModel(
        this.viewer,
        this.currentFloorPlanOrientation,
        this.bimAngularDeviationFromTrueNorth
      )
    );
  }

  forgeModelGeometryLoaded() {
    // Safety removal of listener
    this.turnOffPanoramaOrientationListener();

    this.turnOnPanoramaOrientationListener();
    this.triggerOrientationUpdated();
  }
  // Triggered after parent BIM has un-loaded
  forgeModelRootUnLoaded() {
    this.turnOffPanoramaOrientationListener();
  }

  setBIMViewPointChanged(viewPointLocationOnFloorPlan: L.LatLng) {
    let data = {
      location: viewPointLocationOnFloorPlan,
      orientation: new BIMSyncModel(
        this.viewer,
        this.currentFloorPlanOrientation,
        this.bimAngularDeviationFromTrueNorth
      ),
    };

    // Change view point and trigger rotation change
    this.setBimEvent(BIM_CONSTANTS.VIEW_POINT_CHANGED, data);
  }

  setForgeViewerConfig(
    currentTour: TourImage,
    forgeObject: ForgeObject,
    bimModelOffset: any
  ) {
    //testing a default value of 0.01 here
    const bimTransformationScale = currentTour.transformationScale ?? 0.1;
    const currentAECLevel = currentTour.aecLevel ?? null;

    this.forgeViewerConfig = {
      forgeObjectURN: forgeObject?.urn,
      modelOffset: bimModelOffset,
      origin: currentTour.origin,
      transformationScale: bimTransformationScale,
      aecLevel: currentAECLevel,
    };
  }

  toggleTourLock() {
    this.isTourLocked = !this.isTourLocked;
    if (!this.isTourLocked && this.viewer)
      this.turnOffPanoramaOrientationListener();

    if (this.isTourLocked) this.turnOnPanoramaOrientationListener();

    this.bimDataService.setTourLocked(this.isTourLocked);
  }

  isUserProjectAdmin() {
    let user = this.projectUsers.find(
      (user) => user.email === this.currentUser.email
    );
    return user && user.role.code === "Project Admin" ? true : false;
  }

  openFloorPlanConfig() {
    this.floorPlanConfigComponentRef = this.dialog.open(
      FloorPlanConfigComponent,
      {
        data: {
          tour: this.currentTour,
        },
      }
    );
    this.floorPlanConfigComponentRef.afterClosed().subscribe((dialogResult) => {
      if (dialogResult) {
        let alert = this.ts.instant(
          "interior.virtualTour.messages.savedVirtualTourPath"
        );
        this.snackService.successSnackBar(alert);
        this.changeTour({ value: this.currentTour.tourId });
      }
    });
  }

  resetWalkthroughVideoService() {
    // Unsubscribe from all subscriptions
    this.walkthroughVideoService.reset();
  }

  ngOnDestroy(): void {
    this.resetWalkthroughVideoService();
    // Unregister listeners and clean up
    if (this.viewer) {
      this.viewer.off();
      this.viewer.destroy();
    }

    this.firstFIClickSubs?.unsubscribe();
    this.localStorage.removeItem("floorLevelFolderId");
    this.closeDialogs();
  }

  closeDialogs() {
    this.walkthroughSplitComponentRef?.close();
    this.floorPlanAnnotationComponentRef?.close();
    this.floorPlanConfigComponentRef?.close();
  }

  changePannellumInteractionToGetFieldIssueLocation() {
    this.hidePanoramaControls = true;
    this.fieldIssueService.setData("field_capture_mode_on", {
      ...this.getLatestFieldIssueConfig(),
    });
  }

  closeFieldIssueListPanel(event: any) {
    if (event.type == "open_existing_issue" && event.refresh && event.fi) {
      const fi: FI = event.fi;
      this.fiDetailPanelHeading = `Field Issue #${fi.issueNumber}`;
      this.fieldIssueService.setData("existing_issue", {
        ...fi,
        towerName: this.towerName,
        tour: this.currentTour,
        viewer: this.viewer,
      });
      this.isFieldIssueListPanelVisible = false;
      this.isFieldIssueDetailPanelVisible = true;
    } else if (event.type == "field_issue_capture_mode") {
      this.isFieldIssueListPanelVisible = false;
      this.firstFIClickSubs = this.fieldIssueService.isFirstClick.subscribe(
        (data) => {
          this.isNextButtonDisabled = !data;
        }
      );
      this.hidePanoramaControls = true;
      this.showCreateFieldIssueButtons = true;
    } else if (event.type == "close_panel") {
      this.isFieldIssueListPanelVisible = false;
      this.hidePanoramaControls = false;
    }
  }

  createNewFieldIssue() {
    this.showCreateFieldIssueButtons = false;
    this.isFieldIssueListPanelVisible = false;
    this.fiDetailPanelHeading = "New Field Issue";
    this.fieldIssueService.firstClickAction(false);
    this.viewer.off("mouseup");
    try {
      this.uiService.show();
      const fileName = this.currentTour.tourName + ".jpeg";
      this.viewer
        .getRenderer()
        .render(
          (this.viewer.getPitch() * Math.PI) / 180,
          (this.viewer.getYaw() * Math.PI) / 180,
          (this.viewer.getHfov() * Math.PI) / 180,
          { returnImage: "ImageBitmap" }
        )
        .then((img) => {
          const canvas = document.createElement("canvas");
          canvas.width = img.width;
          canvas.height = img.height;
          canvas.getContext("2d").drawImage(img, 0, 0);
          html2canvas(document.querySelector(".pnlm-ui"), {
            canvas: canvas,
            backgroundColor: "rgba(0, 0, 0, 0)",
            logging: false,
          }).then((canvas) => {
            this.snapshot = [this.dataURLtoFile(canvas.toDataURL(), fileName)];
            this.fieldIssueService.setData("new_issue", {
              snapshot: this.snapshot,
              hotspot: this.fieldIssueService.lastAddedHostspot,
              ...this.getLatestFieldIssueConfig(),
            });

            this.uiService.hide();
            this.isFieldIssueDetailPanelVisible = true;
          });
        });
    } catch (error) {
      this.uiService.hide();
    }
  }

  closeFieldIssueDetailPanel(panelCloseActions: FIDPCloseAction) {
    this.isFieldIssueDetailPanelVisible = false;
    if (panelCloseActions?.setOriginalBound && this.viewer)
      this.setViewerOriginalBounds(this.fieldIssueService.originalPosition);
    if (panelCloseActions?.refresh) {
      this.interiorService
        .getTourData(this.projectId, this.currentTour.tourId)
        .subscribe((data) => {
          this.currentTour.lastFieldIssueNumber =
            data.tour.lastFieldIssueNumber;
        });
      this.openFieldIssueListPanel("after_save");
    }
    if (
      panelCloseActions?.removeHotspot &&
      this.fieldIssueService?.lastAddedHostspot.id
    ) {
      this.viewer?.removeHotSpot(this.fieldIssueService.lastAddedHostspot.id);
    }
    if (panelCloseActions?.type == "close_without_save")
      this.hidePanoramaControls = false;
  }

  createProcoreObservation() {
    this.isProcoreObservationDetailPanelVisible = true;
  }

  closeProcoreObservationDetailPanel() {
    this.isProcoreObservationDetailPanelVisible = false;
  }

  setViewerOriginalBounds(
    oPPP: OriginalPanellumPositionParameters //oPPP is original panellum position parameters
  ) {
    if (oPPP) {
      this.viewer.setPitchBounds(oPPP.origPitchBounds);
      this.viewer.setYawBounds(oPPP.origYawBounds);
      this.viewer.setHfovBounds(oPPP.origHfovBounds);
    }
  }

  updateImageProps($event: ImageEnhancementProps) {
    this.imageEnhancementProps = $event;
  }

  toggleImageEditor() {
    this.isImageEditorPanelVisible = !this.isImageEditorPanelVisible;
  }
}
