import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import {
  InteriorDialogData,
  UserService,
  User,
  InteriorService,
  UiService,
  SnackbarService,
} from "src/app/core";
import { ActivatedRoute, Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "update-tower",
  templateUrl: "./update-tower.component.html",
  styleUrls: ["./update-tower.component.scss"],
})
export class UpdateTowerComponent implements OnInit {
  @ViewChild("interiorForm") interiorForm;
  public breakpoint: number;
  public towerName: string = "";
  public captureDate: Date = new Date();
  public updateInteriorForm: UntypedFormGroup;
  formSubmitAttempt: boolean = false;
  errors = {};
  wasFormChanged = false;
  projectId: string;
  user: User;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<UpdateTowerComponent>,
    @Inject(MAT_DIALOG_DATA) private data: InteriorDialogData,
    private interiorService: InteriorService,
    private route: ActivatedRoute,
    private snackService: SnackbarService,
    private usrService: UserService,
    private uiService: UiService,
    private router: Router,
    private ts: TranslateService
  ) {
    this.updateInteriorForm = this.fb.group({
      interiorId: null,
      towerId: null,
      towerName: [
        this.towerName,
        [
          Validators.required,
          Validators.pattern(
            /^[a-zA-ZÀ-ÿ0-9]+[a-zA-ZÀ-ÿ0-9+\-,:;=@&#|'<>^*()%!_\.\/\\ ]*$/
          ),
        ],
      ],
      captureDate: [this.captureDate, null],
    });
  }

  public ngOnInit(): void {
    this.setInteriorDetails(this.data);
    this.user = this.usrService.getCurrentUser();
  }

  get f() {
    return this.updateInteriorForm.controls;
  }

  public onInteriorAdd(): void {
    this.formSubmitAttempt = true;
    this.markAsDirty(this.updateInteriorForm);
    this.onSubmit();
  }

  setInteriorDetails(tour) {
    this.projectId = this.data.projectId;
    this.towerName = tour.towerName;
    if (tour) {
      this.updateInteriorForm.patchValue({
        interiorId: tour.interiorId,
        towerId: tour.towerId,
        towerName: tour.towerName,
        captureDate: tour.captureDate,
      });
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
    this.onReset();
  }

  //tslint:disable-next-line:no-any
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 2;
  }

  private markAsDirty(group: UntypedFormGroup): void {
    group.markAsDirty();
    for (const i in group.controls) {
      group.controls[i].markAsDirty();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  onSubmit() {
    let alert = "";
    let data = this.updateInteriorForm.value;
    let towerUpdate: { captureDate: ""; towerName: "" };
    this.formSubmitAttempt = true;

    if (this.updateInteriorForm.valid) {
      this.uiService.show();

      this.interiorService
        .overrideTowerData(
          this.projectId,
          data.interiorId,
          data.towerId,
          data.towerName,
          data.captureDate
        )
        .subscribe(
          (data) => {
            alert = this.ts.instant("interior.list.messages.towerDetailsSaved");
            this.snackService.successSnackBar(alert);
            this.dialogRef.close({ reloadRequired: true });
            this.onReset();
            this.uiService.hide();
          },
          (err) => {
            alert = this.ts.instant("interior.list.messages.failedToSave");
            this.errors = err;
            this.formSubmitAttempt = false;
            this.snackService.errorSnackBar(alert);
            this.dialog.closeAll();
            this.uiService.hide();
          }
        );
    }
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.interiorForm.resetForm();
    this.updateInteriorForm.reset();
  }
}
