import { Component, Inject, ViewChild } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialog } from "@angular/material/dialog";
import { MatTabGroup } from "@angular/material/tabs";
import {
  SnackbarService,
  MasterDataService,
  EquirectangularImageViewerService,
  ProjectService,
  ClientService,
  LocalStorageService,
  InteriorService,
  UiService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import { uuidv4 } from "../walkthrough/walkthrough-utils";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import "leaflet";
import * as L from "leaflet";
import "leaflet-draw";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";

@Component({
  selector: "upload-apartment-snapshots",
  templateUrl: "./upload-apartment-snapshots.component.html",
  styleUrls: ["./upload-apartment-snapshots.component.scss"],
})
export class UploadApartmentSnapshotsComponent {
  @ViewChild("tabGroup") tab: MatTabGroup;
  apartmentArray = [];
  apartmentInteriorArray = [];
  floorName: any;
  selectedApartment: string;
  apartmentInteriorName: string;
  snapshotDetailsForm: UntypedFormGroup;
  projectId: any;
  clientId: any;
  interiorId: any;
  parentLocationId: any;
  workLocationData: [];
  uploadedFile: any;
  fileExtensionAllowed: boolean = false;
  clientName: string;
  projectName: string;
  interiorName: any;
  selectedApartmentName: any;
  showFloorPlan: boolean = false;
  blobContentId: any;
  floorPlanUrl: string;
  errors: {};
  map: L.Map;
  featureGroup: L.FeatureGroup;
  locationMarkerIcon: L.Icon<L.IconOptions>;
  floorPlanMarker: L.Marker<any>;
  mapInitialized: boolean = false;
  floorPlanMarkerLat: number;
  floorPlanMarkerLng: number;
  floorPlanMarkerAdded: boolean = false;
  apartmentInteriorImageExists: boolean = false;
  apartmentInteriorFloorPlanLocationExists: boolean = false;
  apartmentInteriorData: any;
  floorPlanDetails: any;
  updatingApartmentInteriorImage: boolean = false;
  enableSubmitButton: boolean = false;
  viewApartment: boolean = false;
  moveToUploadTab: boolean = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public dialogData: any,
    @Inject(APP_CONFIG) private config: AppConfig,
    private dialog: MatDialog,
    private snackService: SnackbarService,
    private ts: TranslateService,
    private fb: UntypedFormBuilder,
    private masterDataService: MasterDataService,
    private EquirectangularImageViewerService: EquirectangularImageViewerService,
    private projectService: ProjectService,
    private clientService: ClientService,
    private localStorageService: LocalStorageService,
    private interiorService: InteriorService,
    private uiService: UiService
  ) {
    this.snapshotDetailsForm = this.fb.group({
      apartmentName: ["", Validators.required],
      interiorName: ["", Validators.required],
    });
  }
  ngOnInit() {
    this.floorName = this.dialogData.tour.tourName;
    this.parentLocationId = this.dialogData.tour.locationId;
    this.projectId = this.dialogData.projectId;
    this.interiorId = this.dialogData.tour.interiorId;
    this.clientId = this.localStorageService.getClientId();
    this.obtainInteriorDataDetails();
    this.getTourWorkLocationData();
    this.blobContentId = this.dialogData.tour.floorPlanBlobId;

    if (this.blobContentId) {
      this.showFloorPlan = true;
    }
  }

  get f() {
    return this.snapshotDetailsForm.controls;
  }

  closeDialog() {
    this.dialog.closeAll();
  }

  generateFileObjectId(fileName) {
    const fileObjectId = uuidv4();

    if (fileName.includes(".")) {
      return fileObjectId + "." + fileName.split(".").pop();
    } else {
      return fileObjectId;
    }
  }

  obtainInteriorDataDetails() {
    this.clientService.getClient(this.clientId).subscribe((data) => {
      this.clientName = data.client.clientName;
    });

    this.projectService.get(this.projectId).subscribe((data) => {
      this.projectName = data.projectName;
    });

    this.interiorService
      .getInteriorById(this.projectId, this.interiorId)
      .subscribe((data) => {
        this.interiorName = data.data.interiorName;
      });
  }

  getTourWorkLocationData() {
    this.masterDataService
      .getWorkLocation(this.projectId)
      .subscribe((workLocationData) => {
        this.workLocationData = workLocationData;
        workLocationData.location.forEach((location) => {
          if (location.parentLocationId === this.parentLocationId) {
            if (location.level3) {
              const floorApartment = location;
              this.apartmentArray.push(floorApartment);
            }
          }
        });
      });
  }

  checkIfApartmentViewDataExists() {
    this.uiService.show();
    this.EquirectangularImageViewerService.getImageData(
      this.interiorId,
      this.projectId
    ).subscribe((data) => {
      const EquirectangularImageData = data["EquirectangularImageData"];

      if (EquirectangularImageData.length !== 0) {
        const allApartmentInteriorData = EquirectangularImageData[0].imageData;

        if (allApartmentInteriorData.length !== 0) {
          for (let apartmentInteriorData of allApartmentInteriorData) {
            if (
              apartmentInteriorData.apartmentInteriorName &&
              apartmentInteriorData.floorPlanDetails &&
              apartmentInteriorData.floorName === this.floorName &&
              apartmentInteriorData.apartmentName === this.selectedApartmentName
            ) {
              this.viewApartment = true;
              break;
            } else {
              this.viewApartment = false;
            }
          }
          this.uiService.hide();
        }
      } else {
        this.viewApartment = false;
        this.uiService.hide();
      }
    });
  }

  openApartmentInteriorsView() {
    if (this.viewApartment) {
      const url = `https://viewer.huviair.com:444/${this.interiorId}/${this.projectId}/${this.selectedApartmentName}/apartmentViewer`;
      window.open(url, "_blank");
    }
  }

  locationMarker() {
    const customIconPath = "../../../../../../../../assets/images/pin.png";

    this.locationMarkerIcon = L.icon({
      iconUrl: customIconPath,
      iconSize: [32, 32],
    });
  }

  chosenApartment(apartment) {
    const apartmentId = apartment.locationId;
    this.selectedApartmentName = apartment.level3;

    if (this.apartmentInteriorArray.length !== 0) {
      this.apartmentInteriorArray = [];
    }

    this.setApartmentInteriorData(apartmentId);
    this.checkIfApartmentViewDataExists();
  }

  setApartmentInteriorData(apartmentId) {
    this.workLocationData["location"].forEach((location) => {
      if (location.parentLocationId === apartmentId && location.level4) {
        const apartmentInteriorName = location.level4;
        if (apartmentInteriorName) {
          this.apartmentInteriorArray.push(apartmentInteriorName);
        }
      }
    });
  }

  selectedApartmentInterior(apartmentInteriorName) {
    this.apartmentInteriorName = apartmentInteriorName;
  }

  onTabChange($event) {
    const selectedTabIndex = this.tab.selectedIndex;

    if (this.snapshotDetailsForm.invalid) {
      this.tab.selectedIndex = selectedTabIndex - 1;
      Object.values(this.snapshotDetailsForm.controls).forEach((control) => {
        control.markAsTouched();
      });
      return;
    } else if (selectedTabIndex === 1) {
      this.tab.selectedIndex = 1;
      this.moveToUploadTab = true;
      if (this.floorPlanMarker) {
        this.map.removeLayer(this.floorPlanMarker);
        this.map.off("click", () => {});
        this.enableSubmitButton = false;
      }

      if (this.showFloorPlan) {
        this.getFloorPlanUrl(this.blobContentId);
      } else {
        let alert;
        alert = this.ts.instant("interior.list.labels.viewApartment");
        this.snackService.errorSnackBar(alert);
      }
    } else if (selectedTabIndex === 0) {
      this.tab.selectedIndex = 0;
      this.apartmentInteriorImageExists = false;
      this.apartmentInteriorFloorPlanLocationExists = false;
      this.moveToUploadTab = false;

      if (this.floorPlanMarker) {
        this.map.removeLayer(this.floorPlanMarker);
        this.map.off("click", () => {});
      }

      if (this.selectedApartmentName) {
        this.checkIfApartmentViewDataExists();
      }
    } else {
      if (this.floorPlanMarker) {
        this.map.removeLayer(this.floorPlanMarker);
        this.map.off("click", () => {});
      }
      if (!this.moveToUploadTab) {
        this.tab.selectedIndex = 0;
      }
    }
  }

  floorPlanTab() {
    if (this.snapshotDetailsForm.valid) {
      const tabIndex = this.tab.selectedIndex;
      const newIndex = (tabIndex + 1) % this.tab._tabs.length;
      this.tab.selectedIndex = newIndex;
    } else if (this.snapshotDetailsForm.invalid) {
      Object.values(this.snapshotDetailsForm.controls).forEach((control) => {
        control.markAsTouched();
      });
      return;
    }
  }

  apartmentInteriorSnapshotTab() {
    if (this.floorPlanMarker) {
      const tabIndex = this.tab.selectedIndex;
      const newIndex = (tabIndex + 1) % this.tab._tabs.length;
      this.tab.selectedIndex = newIndex;

      let alert;
      alert = this.ts.instant(
        "interior.list.labels.savedApartmentInteriorLocation"
      );
      this.snackService.successSnackBar(alert);
    }
  }

  onFileChange($event) {
    this.uploadedFile = $event.target.files[0];

    if (this.uploadedFile) {
      const fileUploadedName = document.getElementById("fileUploadedName");

      fileUploadedName.innerHTML = this.uploadedFile.name;

      const fileExtension = this.uploadedFile.name.split(".").pop();

      if (
        fileExtension === "jpg" ||
        fileExtension === "jpeg" ||
        fileExtension === "png" ||
        fileExtension === "JPG" ||
        fileExtension === "JPEG" ||
        fileExtension === "PNG"
      ) {
        this.fileExtensionAllowed = true;
        if (this.apartmentInteriorImageExists) {
          this.updatingApartmentInteriorImage = true;
        }
      } else {
        let alert;
        alert = this.ts.instant(
          "exterior.settings.messages.extensionNotAllowed"
        );
        this.snackService.errorSnackBar(alert);
      }
    }
  }

  uploadInteriorSnapshot() {
    if (this.uploadedFile && this.fileExtensionAllowed) {
      this.uiService.show();

      const tower = this.dialogData.walkthroughData.towerName;
      const floor = this.dialogData.tour.tourName;
      const fileName = this.uploadedFile.name;
      const fileObjectId = this.generateFileObjectId(fileName);

      if (!this.updatingApartmentInteriorImage) {
        this.floorPlanDetails = {
          floorPlanBlobId: this.blobContentId,
          floorPlanMarkerLatitude: this.floorPlanMarkerLat,
          floorPlanMarkerLongitude: this.floorPlanMarkerLng,
        };
      }

      const imageDataObject = {
        towerName: tower,
        floorName: floor,
        fileObjectId: fileObjectId,
        apartmentName: this.selectedApartmentName,
        apartmentInteriorName: this.apartmentInteriorName,
        floorPlanDetails: this.floorPlanDetails,
      };

      this.EquirectangularImageViewerService.upload360Image(
        this.projectId,
        this.interiorId,
        this.clientName,
        this.projectName,
        this.interiorName,
        tower,
        imageDataObject,
        this.uploadedFile
      ).subscribe((response) => {
        if (response) {
          this.updatingApartmentInteriorImage = false;
          let alert;
          alert = this.ts.instant(
            "interior.list.labels.apartmentInteriorSnapshotUploadSuccess"
          );
          this.snackService.successSnackBar(alert);
          this.uiService.hide();
          this.dialog.closeAll();
        } else {
          let alert;
          alert = this.ts.instant(
            "interior.list.labels.apartmentInteriorSnapshotUploadFailed"
          );
          this.snackService.errorSnackBar(alert);
        }
      });
    }
  }

  async getFloorPlanUrl(blobContentId: string) {
    let readToken;
    let container = this.config.floorPlanContainer;
    let blobContainer = this.config.floorPlanBlobContainer;
    await this.interiorService.getReadToken(container).subscribe(
      (data) => {
        readToken = data.sasToken.token;
        this.floorPlanUrl = blobContainer + blobContentId + "?" + readToken;

        this.checkIfApartmentInteriorDataExists().finally(() => {
          this.loadFloorPlan(this.floorPlanUrl);
        });
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  checkIfApartmentInteriorDataExists() {
    return new Promise<void>((resolve, reject) => {
      this.EquirectangularImageViewerService.getImageData(
        this.interiorId,
        this.projectId
      ).subscribe((data) => {
        const equirectangularImageData = data["EquirectangularImageData"];

        if (equirectangularImageData.length !== 0) {
          const equirectangularImageData =
            data["EquirectangularImageData"][0].imageData;
          let foundValidApartmentInteriorData = false;

          equirectangularImageData.forEach((imageData) => {
            if (imageData.apartmentInteriorName) {
              if (
                imageData.apartmentName === this.selectedApartmentName &&
                imageData.apartmentInteriorName ===
                  this.apartmentInteriorName &&
                imageData.floorPlanDetails
              ) {
                this.apartmentInteriorData = imageData;

                this.apartmentInteriorImageExists = true;
                this.apartmentInteriorFloorPlanLocationExists = true;
                foundValidApartmentInteriorData = true;
              }
            }
          });

          if (foundValidApartmentInteriorData) {
            resolve();
          } else {
            reject(
              new Error("interior.list.labels.apartmentInteriorDataNotFound")
            );
          }
        } else {
          if (this.showFloorPlan) {
            this.apartmentInteriorFloorPlanLocationExists = false;
            resolve();
          } else {
            reject(
              new Error("interior.list.labels.apartmentInteriorDataNotFound")
            );
          }
        }
      });
    });
  }

  loadFloorPlan(imageUrl) {
    this.uiService.show();

    if (!this.mapInitialized) {
      this.map = L.map("Map", {
        crs: L.CRS.Simple,
        minZoom: -5,
        maxBoundsViscosity: 1,
      });
    }

    this.mapInitialized = true;

    const img = new Image();

    img.id = "mapImage";
    img.src = imageUrl;
    img.onload = () => {
      const w = img.width;
      const h = img.height;
      const bounds: any = [
        [-10, -10],
        [h, w],
      ];
      L.imageOverlay(imageUrl, bounds).addTo(this.map);
      this.map.fitBounds(bounds);
      this.map.setMaxBounds(bounds);
    };
    this.uiService.hide();
    if (!this.apartmentInteriorFloorPlanLocationExists) {
      this.addFloorPlanMarker();
    } else {
      this.updateFloorPlanMarker();
    }
  }

  addFloorPlanMarker() {
    this.floorPlanMarkerAdded = true;
    this.map.on("click", ($event) => {
      this.floorPlanMarkerLat = $event.latlng.lat;
      this.floorPlanMarkerLng = $event.latlng.lng;

      this.locationMarker();

      if (this.floorPlanMarker) {
        this.map.removeLayer(this.floorPlanMarker);
      }

      this.floorPlanMarker = L.marker($event.latlng, {
        icon: this.locationMarkerIcon,
      }).addTo(this.map);
      this.enableSubmitButton = true;
    });
  }

  updateFloorPlanMarker() {
    if (this.apartmentInteriorFloorPlanLocationExists) {
      const latlng = {
        lat: this.apartmentInteriorData["floorPlanDetails"]
          .floorPlanMarkerLatitude,
        lng: this.apartmentInteriorData["floorPlanDetails"]
          .floorPlanMarkerLongitude,
      };

      this.locationMarker();

      this.floorPlanMarker = L.marker(latlng, {
        icon: this.locationMarkerIcon,
      }).addTo(this.map);
      this.floorPlanMarkerAdded = false;
    }
  }

  saveUpdatedFloorPlanMarkerLocation() {
    if (this.floorPlanMarkerAdded && this.floorPlanMarker) {
      const updatedFloorPlanMarketLocationObject = {
        latitude: this.floorPlanMarkerLat,
        longitude: this.floorPlanMarkerLng,
        apartmentName: this.selectedApartmentName,
        apartmentInteriorName: this.apartmentInteriorName,
      };

      this.EquirectangularImageViewerService.updateApartmentInteriorFloorPlanLocation(
        this.projectId,
        this.interiorId,
        updatedFloorPlanMarketLocationObject
      ).subscribe((response) => {
        if (response) {
          this.floorPlanMarkerAdded = false;
          this.apartmentInteriorSnapshotTab();

          let alert;
          alert = this.ts.instant(
            "interior.list.labels.apartmentInteriorLocationUpdateSuccess"
          );
          this.snackService.successSnackBar(alert);
        } else {
          let alert;
          alert = this.ts.instant(
            "interior.list.labels.apartmentInteriorLocationUpdateFailed"
          );
          this.snackService.successSnackBar(alert);
        }
      });
    }
  }

  updateApartmentInteriorImage() {
    const updatingImagedata = this.apartmentInteriorData;
    const updatingImageId = updatingImagedata.fileObjectId;
    this.floorPlanDetails = updatingImagedata.floorPlanDetails;

    this.EquirectangularImageViewerService.delete360Image(
      this.interiorId,
      this.projectId,
      updatingImageId
    ).subscribe((data) => {
      if (data) {
        this.updatingApartmentInteriorImage = true;
        this.uploadInteriorSnapshot();
      }
    });
  }

  deleteApartmentInteriorImage() {
    const message = this.ts.instant("interior.list.labels.deleteImage");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "600px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      let result = dialogResult;
      if (result) {
        this.uiService.show();

        const deleteImagedata = this.apartmentInteriorData;
        const deleteImageId = deleteImagedata.fileObjectId;

        this.EquirectangularImageViewerService.delete360Image(
          this.interiorId,
          this.projectId,
          deleteImageId
        ).subscribe((data) => {
          if (data) {
            this.apartmentInteriorImageExists = false;
            this.apartmentInteriorFloorPlanLocationExists = false;
            this.uiService.hide();

            const alert = this.ts.instant(
              "interior.list.labels.imageDeleteSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.checkIfApartmentInteriorDataExists().finally(() => {
              this.map.removeLayer(this.floorPlanMarker);
              this.map.off("click", () => {});
              this.apartmentInteriorImageExists = false;
              this.apartmentInteriorFloorPlanLocationExists = false;
            });
          } else {
            const alert = this.ts.instant(
              "interior.list.labels.imageDeleteFailed"
            );
            this.snackService.errorSnackBar(alert);
          }
        });
      }
    });
  }
}
