import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { InteriorComponent } from "./interior.component";
import { InteriorListComponent } from "./list/interior-list.component";

const routes: Routes = [
  {
    path: "",
    component: InteriorComponent,

    children: [
      {
        path: "",
        redirectTo: "list",
        pathMatch: "prefix",
      },
      {
        path: "list",
        component: InteriorListComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InteriorRoutingModule {}
