import { Component, Inject, Input, OnInit } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import {
  InteriorImage,
  InteriorService,
  StorageService,
  TourImage,
  UiService,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
declare const pannellum: any;

@Component({
  selector: "interior-pan-viewer",
  templateUrl: "./pan-viewer.component.html",
  styleUrls: ["./pan-viewer.component.scss"],
})
export class PanViewerComponent implements OnInit {
  @Input() selectedImage: InteriorImage;
  @Input() tour: TourImage;
  floorPlan360Images: InteriorImage[] = [];
  imageAccessToken: string;
  accessToken: string;
  projectId: string;
  viewer: any;
  sceneId: string;
  errors: any;

  constructor(
    private storageSvc: StorageService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private interiorService: InteriorService,
    private uiService: UiService,
    private ts: TranslateService
  ) {}

  ngOnInit() {
    if (this.tour) {
      this.setTourData(this.tour);
    }
  }

  showSelectedImage(selectedImage: InteriorImage) {
    this.sceneId = selectedImage.imageId;
    this.viewer.loadScene(selectedImage.imageId);
  }

  ngOnChanges(): void {
    if (this.selectedImage) {
      this.showSelectedImage(this.selectedImage);
    }
  }

  async setTourData(tour: TourImage) {
    const container = this.config.virtualTourContainer;
    await this.interiorService.getReadToken(container).subscribe(
      (data) => {
        this.imageAccessToken = data.sasToken.token;
        this.setBlobUrl(data.sasToken.token, tour);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  setBlobUrl(token, tour: TourImage) {
    this.floorPlan360Images = [];
    // Image Azure blob folder structure  = WALKTHROUGH-TOUR-ID > IMAGE
    tour.images.forEach((image) => {
      if (image) {
        image.imageBlobUrl =
          this.config.virtualTourBlobUrl +
          tour.tourId +
          "/" +
          image.blobImageId +
          "?" +
          token;
      }
    });

    this.initializeViewer(tour.images);
  }

  initializeViewer(images: InteriorImage[]) {
    this.viewer = pannellum.viewer("panorama", {
      scenes: {},
      sceneFadeDuration: 1000,
      author: "Huviair",
    });

    images.forEach((x) => {
      let hotspotList = this.tour.remarks.filter(
        (r) => r.sceneId === x.imageId
      );
      let hotspots = [];
      for (let i = 0; i < hotspotList.length; i++) {
        hotspots.push(hotspotList[i].hotspot);
      }

      this.viewer.addScene(x.imageId, {
        type: "equirectangular",
        panorama: x.imageBlobUrl,
        autoLoad: true,
        pitch: 2.3,
        yaw: -135.4,
        hfov: 120,
        hotSpots: hotspots,
      });
    });

    this.sceneId = images[0].imageId;
    this.viewer.loadScene(this.sceneId);
  }
}
