import { AfterViewInit, Component, Inject, ViewChild } from "@angular/core";
import { MatTabsModule, MatTabGroup } from "@angular/material/tabs";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { v4 as uuidv4 } from "uuid";
import {
  InteriorService,
  LocalStorageService,
  UiService,
  EquirectangularImageViewerService,
  ProjectService,
  ClientService,
  MasterDataService,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";
import { HttpResponse } from "@angular/common/http";

@Component({
  selector: "upload-equirectangular-image",
  templateUrl: "./upload-equirectangular-image.component.html",
  styleUrls: ["./upload-equirectangular-image.component.scss"],
})
export class UploadEquirectangularImageComponent {
  @ViewChild(MatTabGroup) tabGroup: MatTabGroup;
  uploadedFile: any;
  fileExtensionAllowed: boolean;
  clientId: any;
  projectId: string;
  interiorId: any;
  floorImageExists: boolean = false;

  imageData: any;
  tower: any;
  floor: any;
  isUpdateButtonDisabled: boolean = true;
  isImagePresent: any;
  isFloor360Image: boolean = false;
  isFloor360ImagePresent: any;
  floor360ImageExists: boolean = false;
  uploadTowerName: any;
  removeFloor360Image: boolean = false;
  removeClientLogo: boolean = false;
  imageDeleteObject: any;
  uploadClientImage: boolean = false;
  clientImageExists: boolean = false;
  isClientImagePresent: any;
  isUpdateFloor360ImageButtonDisabled: boolean = true;
  isLogoUpdateButtonDisabled: boolean = true;
  clientImage: any;
  imageDataObject: any;
  projectName: any;
  interiorName: any;
  clientName: any;
  activeTab: any;
  isFloorLevelUploadButtonDisabled: boolean = true;
  isFloorLevel360UploadButtonDisabled: boolean = true;
  isClientLogoUploadButtonDisabled: boolean = true;
  floorLevelImageUpload: boolean = false;
  updateFloorLevelImage: boolean = false;
  floor360ImageUpdate: boolean = false;
  clientLogoUpdate: boolean = false;
  removeFloorLevelImage: boolean = false;
  tourData: any;
  floorOrderArray = [];
  floorNames = [];
  apartmentName: any;
  workLocationList = [];
  workLocationList1 = [];
  workLocationList2 = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public dialogData: any,
    public dialog: MatDialog,
    private snackService: SnackbarService,
    private projectService: ProjectService,
    private interiorService: InteriorService,
    private clientService: ClientService,
    private ts: TranslateService,
    private localStorage: LocalStorageService,
    private uiService: UiService,
    private equirectangularImageService: EquirectangularImageViewerService,
    private masterDataService: MasterDataService
  ) {}

  ngOnInit() {
    this.clientId = this.localStorage.getClientId();
    this.projectId = this.dialogData.projectId;
    this.interiorId = this.dialogData.tour.interiorId;
    this.tourData = this.dialogData.walkthroughData.tours;
    this.getInteriorDetails();
    this.getImageViewerData();
  }

  ngAfterViewInit() {
    const selectedTab = this.tabGroup.selectedIndex;
    this.activeTab = this.tabGroup._tabs.toArray()[selectedTab].textLabel;
  }

  closeDialog() {
    this.floorOrderArray = [];
    this.dialog.closeAll();
  }

  getInteriorDetails() {
    this.tower = this.dialogData.walkthroughData.towerName;
    this.floor = this.dialogData.tour.tourName;

    this.clientService.getClient(this.clientId).subscribe((data) => {
      this.clientName = data.client.clientName;
    });

    this.projectService.get(this.projectId).subscribe((data) => {
      this.projectName = data.projectName;
    });

    this.interiorService
      .getInteriorById(this.projectId, this.interiorId)
      .subscribe((data) => {
        this.interiorName = data.data.interiorName;
      });

    this.masterDataService.getWorkLocation(this.projectId).subscribe((data) => {
      this.workLocationList = data.location;
      this.workLocationList.forEach((location) => {
        if (!location.parentLocationId) {
          this.workLocationList1.push(location);
        }
      });
      this.workLocationList.forEach((item) => {
        if (
          item.parentLocationId === this.workLocationList1[0].locationId &&
          !item.level3 &&
          !item.level4
        ) {
          this.workLocationList2.push(item);
        }
      });
      let isOrderNoExist = this.workLocationList2.find((item) => item.orderNo);
      if (isOrderNoExist) {
        this.workLocationList2.sort((a, b) => (a.orderNo < b.orderNo ? -1 : 1));
      } else {
        this.workLocationList2.sort((a, b) => {
          if (a.level2 > b.level2) {
            return 1;
          }
          if (a.level2 < b.level2) {
            return -1;
          }
          return 0;
        });
      }
      this.workLocationList2.forEach((item) => {
        this.floorNames.push(item.level2);
      });
      this.floorOrderArray = this.floorNames;
    });
  }

  getImageViewerData() {
    this.uiService.show();
    this.equirectangularImageService
      .getImageData(this.interiorId, this.projectId)
      .subscribe((data) => {
        if (data["EquirectangularImageData"].length !== 0) {
          this.imageData = data["EquirectangularImageData"][0].imageData;
          this.uiService.hide();
          this.dataSetup();
        } else {
          this.uiService.hide();
        }
      });
  }

  dataSetup() {
    this.uiService.hide();
    const equirectangularImageData = this.imageData;

    if (equirectangularImageData.length !== 0) {
      this.isImagePresent = this.getImagePresence(this.tower, this.floor);
      this.isFloor360ImagePresent = this.getImagePresence(
        "360 View",
        this.floor
      );

      this.isClientImagePresent = equirectangularImageData.some(
        (item) => item.imageType
      );

      this.floorImageExists = this.isImagePresent;
      this.floor360ImageExists = this.isFloor360ImagePresent;
      this.clientImageExists = this.isClientImagePresent;
    }
  }

  getImagePresence(towerName, floorName) {
    return this.imageData.some(
      (item) => item.towerName === towerName && item.floorName === floorName
    );
  }

  onTabChange($event) {
    this.activeTab = $event.tab.textLabel;
  }

  onFileChange($event) {
    this.uploadedFile = $event.target.files[0];

    if (this.uploadedFile) {
      if (this.activeTab === "Apartment level Image") {
        this.isFloorLevelUploadButtonDisabled = false;
      } else if (this.activeTab === "Floor Level 360 Image") {
        this.isFloorLevel360UploadButtonDisabled = false;
      } else if (this.activeTab === "Client Logo") {
        this.isClientLogoUploadButtonDisabled = false;
      }

      const fileUploadedName = document.getElementById("fileUploadedName");

      fileUploadedName.innerHTML = this.uploadedFile.name;

      const fileExtension = this.uploadedFile.name.split(".").pop();

      if (
        fileExtension === "jpg" ||
        fileExtension === "jpeg" ||
        fileExtension === "png"
      ) {
        this.fileExtensionAllowed = true;
      } else {
        let alert;
        alert = this.ts.instant(
          "exterior.settings.messages.extensionNotAllowed"
        );
        this.snackService.errorSnackBar(alert);
      }
      this.enableUpdateButtons();
    }
  }

  enableUpdateButtons() {
    if (this.activeTab === "Apartment level Image" && this.isImagePresent) {
      this.isUpdateButtonDisabled = false;
    }
    if (
      this.activeTab === "Floor Level 360 Image" &&
      this.isFloor360ImagePresent
    ) {
      this.isUpdateFloor360ImageButtonDisabled = false;
    }
    if (this.activeTab === "Client Logo" && this.isClientImagePresent) {
      this.isLogoUpdateButtonDisabled = false;
    }
  }

  generateFileObjectId(fileName) {
    const fileObjectId = uuidv4();

    if (fileName.includes(".")) {
      return fileObjectId + "." + fileName.split(".").pop();
    } else {
      return fileObjectId;
    }
  }

  onSubmit() {
    this.uiService.show();

    if (this.fileExtensionAllowed) {
      const fileName = this.uploadedFile.name;
      const fileObjectId = this.generateFileObjectId(fileName);
      this.apartmentName = this.dialogData.walkthroughData.towerName;

      if (this.floorLevelImageUpload) {
        this.uploadTowerName = this.dialogData.walkthroughData.towerName;
        this.floorLevelImageUpload = false;
      } else if (this.uploadClientImage) {
        this.clientImage = "Client Logo";
      } else if (this.isFloor360Image) {
        this.uploadTowerName = "360 View";
        this.isFloor360Image = false;
      }

      if (this.uploadClientImage) {
        this.imageDataObject = {
          imageType: this.clientImage,
          floorName: this.dialogData.tour.tourName,
          fileObjectId: fileObjectId,
          apartmentName: this.apartmentName,
        };
        this.uploadClientImage = false;
      } else {
        this.imageDataObject = {
          towerName: this.uploadTowerName,
          floorName: this.dialogData.tour.tourName,
          floorOrder: this.floorOrderArray,
          fileObjectId: fileObjectId,
          apartmentName: this.apartmentName,
        };
      }

      this.equirectangularImageService
        .upload360Image(
          this.projectId,
          this.interiorId,
          this.clientName,
          this.projectName,
          this.interiorName,
          this.tower,
          this.imageDataObject,
          this.uploadedFile
        )
        .subscribe((response: HttpResponse<any>) => {
          if (response) {
            this.getImageViewerData();
            this.uiService.hide();

            if (
              this.updateFloorLevelImage ||
              this.clientLogoUpdate ||
              this.floor360ImageUpdate
            ) {
              this.isUpdateButtonDisabled = true;
              this.isUpdateFloor360ImageButtonDisabled = true;
              this.isLogoUpdateButtonDisabled = true;
            }

            const alert = this.ts.instant(
              "interior.list.labels.imageUploadSuccess"
            );
            this.snackService.successSnackBar(alert);
          }
        });
    } else {
      let alert;
      alert = this.ts.instant("interior.list.labels.imageUploadFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  uploadFloorLevelImage() {
    this.floorLevelImageUpload = true;
    this.isUpdateButtonDisabled = true;
    this.isUpdateFloor360ImageButtonDisabled = true;
    this.isLogoUpdateButtonDisabled = true;
    if (this.floorLevelImageUpload) {
      this.onSubmit();
    }
  }

  floor360ImageUpload() {
    this.isFloor360Image = true;
    this.isLogoUpdateButtonDisabled = true;
    this.isUpdateButtonDisabled = true;
    this.isUpdateFloor360ImageButtonDisabled = true;
    if (this.isFloor360Image) {
      this.onSubmit();
    }
  }

  uploadClientLogo() {
    this.uploadClientImage = true;
    this.isLogoUpdateButtonDisabled = true;
    this.isUpdateButtonDisabled = true;
    this.isUpdateFloor360ImageButtonDisabled = true;
    if (this.uploadClientImage) {
      this.onSubmit();
    }
  }

  onUpdate(fileObjectId) {
    this.uiService.show();
    const deleteImageId = fileObjectId;

    this.equirectangularImageService
      .delete360Image(this.interiorId, this.projectId, deleteImageId)
      .subscribe((data) => {
        if (data) {
          this.onSubmit();
        }
      });
  }

  updateFloorImage() {
    const imageObject = this.imageData.find(
      (item) => item.towerName === this.tower && item.floorName === this.floor
    );
    this.floorLevelImageUpload = true;
    this.updateFloorLevelImage = true;

    const deleteImageId = imageObject.fileObjectId;
    this.onUpdate(deleteImageId);
  }

  updateFloor360Image() {
    this.isFloor360Image = true;
    this.floor360ImageUpdate = true;

    const imageObject = this.imageData.find(
      (item) => item.towerName === "360 View" && item.floorName === this.floor
    );

    const deleteImageId = imageObject.fileObjectId;
    this.onUpdate(deleteImageId);
  }

  updateClientLogo() {
    this.uploadClientImage = true;
    this.clientLogoUpdate = true;

    const imageObject = this.imageData.find(
      (item) => item.imageType === "Client Logo"
    );

    const deleteImageId = imageObject.fileObjectId;
    this.onUpdate(deleteImageId);
  }

  deleteFloorLevelImage() {
    this.removeFloorLevelImage = true;
    this.deleteEquirectangularImage();
  }

  deleteFloor360Image() {
    this.removeFloor360Image = true;
    this.deleteEquirectangularImage();
  }

  deleteClientLogo() {
    this.removeClientLogo = true;
    this.deleteEquirectangularImage();
  }

  deleteEquirectangularImage() {
    const message = this.ts.instant("interior.list.labels.deleteImage");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "600px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      let result = dialogResult;
      if (result) {
        this.uiService.show();
        if (this.removeFloor360Image) {
          this.imageDeleteObject = this.imageData.find(
            (item) =>
              item.towerName === "360 View" && item.floorName === this.floor
          );
          this.removeFloor360Image = false;
          this.isFloorLevel360UploadButtonDisabled = true;
          this.floor360ImageExists = false;
        } else if (this.removeClientLogo) {
          this.imageDeleteObject = this.imageData.find(
            (item) => item.imageType === "Client Logo"
          );
          this.isClientLogoUploadButtonDisabled = true;
          this.clientImageExists = false;
          this.removeClientLogo = false;
        } else if (this.removeFloorLevelImage) {
          this.imageDeleteObject = this.imageData.find(
            (item) =>
              item.towerName === this.tower && item.floorName === this.floor
          );
          this.isFloorLevelUploadButtonDisabled = true;
          this.floorImageExists = false;
          this.removeFloorLevelImage = false;
        }
        const deleteImageId = this.imageDeleteObject.fileObjectId;

        this.equirectangularImageService
          .delete360Image(this.interiorId, this.projectId, deleteImageId)
          .subscribe((data) => {
            if (data) {
              this.uiService.hide();

              const alert = this.ts.instant(
                "interior.list.labels.imageDeleteSuccess"
              );
              this.snackService.successSnackBar(alert);
              this.getImageViewerData();
            } else {
              const alert = this.ts.instant(
                "interior.list.labels.imageDeleteFailed"
              );
              this.snackService.errorSnackBar(alert);
            }
          });
      }
    });
  }
}
