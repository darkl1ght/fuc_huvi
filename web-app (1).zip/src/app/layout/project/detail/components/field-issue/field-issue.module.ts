import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FlexLayoutModule } from "@angular/flex-layout";
import { TranslateModule } from "@ngx-translate/core";
import { SharedModule } from "src/app/shared";
import { FieldIssueRoutingModule } from "./field-issue-routing.module";
import { FieldIssueComponent } from "./field-issue.component";
import { InteriorModule } from "../interior/interior.module";

@NgModule({
  imports: [
    CommonModule,
    FieldIssueRoutingModule,
    SharedModule,
    InteriorModule,
    FlexLayoutModule,
    TranslateModule,
  ],
  declarations: [FieldIssueComponent],
})
export class FieldIssueModule {}
