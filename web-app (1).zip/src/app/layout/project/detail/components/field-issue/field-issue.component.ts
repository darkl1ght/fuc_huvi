import {
  Component,
  EventEmitter,
  Inject,
  OnInit,
  Output,
  ViewChild,
} from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { Observable, throwError } from "rxjs";
import { catchError, finalize, map } from "rxjs/operators";
import { DatePipe } from "@angular/common";

import {
  FieldIssueFilter,
  FieldIssueService,
  IMetadata,
  LocalStorageService,
  MasterDataService,
  UiService,
  SnackbarService,
  ExportData,
  ExcelService,
  LookUpService,
} from "src/app/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";

import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import { fieldIssueIcon } from "../interior/walkthrough/walkthrough-utils";
import moment from "moment";
import { saveAs } from "file-saver";
import { ConnectionPositionPair } from "@angular/cdk/overlay";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { MatSelectChange } from "@angular/material/select";
export enum Status {
  STATUS1 = "FIS10001",
  STATUS2 = "FIS10002",
  STATUS3 = "FIS10003",
  STATUS4 = "FIS10004",
}
@Component({
  selector: "field-issue",
  templateUrl: "./field-issue.component.html",
  styleUrls: ["./field-issue.component.scss"],
})
export class FieldIssueComponent implements OnInit {
  dataSource: any;
  searchText = "";
  value = "";
  dateObj = new Date();
  source: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  result: string = "";
  obs: any[] = [];
  obsNoFilter: any[] = [];
  errors = {};
  isShowingFieldIssueInput: boolean = false;

  fieldIssueDS: Observable<any>;
  fiDetailPanelHeading: string;
  towerId: string;
  floorId: string;
  masterData: any;
  towerList = [];
  floorList = [];
  projectId: string;
  clientId: string;
  @Output() notifyClose: EventEmitter<{
    refresh: boolean;
    type: string;
    fi?: any;
  }> = new EventEmitter();

  isFieldIssueDetailPanelVisible: boolean = false;
  @ViewChild("trigger") trigger;
  showFilter: boolean = false;
  filterToBe: FieldIssueFilter = {};
  filterApplied: FieldIssueFilter = {};
  filterCreatedDateOperator: string;
  statusList: any = [];
  priorityList: any = [];
  filterCreatedDate: Date;
  readonly dateOperator: DateOperator = {
    ON: "on",
    BETWEEN: "between",
  };
  readonly ALL_TOWERS: string = "All";
  readonly ALL_FLOORS: string = "All";
  validImageExtensions: string[] = ["jpg", "jpeg", "gif", "png"];

  l1l2Mapping = {};

  public actionPanelPositionPairsForFIDetail: ConnectionPositionPair[] = [
    {
      offsetX: 14,
      offsetY: 22.5,
      originX: "center",
      originY: "top",
      overlayX: "center",
      overlayY: "top",
      panelClass: null,
    },
  ];

  StatusColors = {
    [Status.STATUS1]: "#FF0000",
    [Status.STATUS2]: "#FFA500",
    [Status.STATUS3]: "#008000",
    [Status.STATUS4]: "#FFFF00",
  };
  constructor(
    public dialog: MatDialog,
    private uiSvc: UiService,
    private localStorage: LocalStorageService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private router: Router,
    private fieldIssueService: FieldIssueService,
    private snackService: SnackbarService,
    private lookUpService: LookUpService,
    private masterDataSvc: MasterDataService,
    private snackbarService: SnackbarService,
    private ts: TranslateService,
    iconRegistry: MatIconRegistry,
    public datePipe: DatePipe,
    private excelService: ExcelService,
    sanitizer: DomSanitizer
  ) {
    iconRegistry.addSvgIconLiteral(
      "field-issue",
      sanitizer.bypassSecurityTrustHtml(fieldIssueIcon)
    );
  }

  ngOnInit() {
    this.clientId = this.localStorage.getClientId();
    this.projectId = this.localStorage.getProjectId();
    this.getMasterData();
    this.getLookupData();
    this.towerId = this.ALL_TOWERS;
    this.floorId = this.ALL_FLOORS;
    this.getFieldIssueData(this.towerId);
  }

  downloadReport(fieldIssue: any) {
    this.uiSvc.show();
    this.fieldIssueService
      .downloadPDFReport(this.projectId, fieldIssue.issueId, {
        snapshotImageUrl: fieldIssue.snapshotImage?.downloadUrl,
        floorPlanBlobId: fieldIssue.tour.floorPlanBlobId,
        location: fieldIssue.location,
        attachments: fieldIssue.attachments
          ?.filter((item) => this.isValidImageExtension(item))
          .map((item) => item.downloadUrl),
      })
      .subscribe({
        next: (file) => {
          this.uiSvc.hide();
          const byteArray = new Uint8Array(
            atob(file)
              .split("")
              .map((char) => char.charCodeAt(0))
          );
          var blob = new Blob([byteArray], {
            type: "application/pdf;charset=utf-8",
          });
          saveAs(blob, `${fieldIssue.issueId}.pdf`);
        },
        error: (err) => {
          this.uiSvc.hide();
        },
      });
  }
  isValidImageExtension(file: any): boolean {
    if (file.name.includes(".")) {
      const extension: string = file.name.split(".").pop();
      return this.validImageExtensions.includes(extension.toLowerCase());
    } else {
      return false;
    }
  }

  getLookupData() {
    this.lookUpService.getAll("fieldIssueStatus").subscribe(
      (data) => {
        this.statusList = data;
      },
      (err) => {
        this.errors = err;
      }
    );
    this.lookUpService.getAll("fieldIssuePriority").subscribe(
      (data) => {
        this.priorityList = data;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  loadTable() {
    this.dataSource = new MatTableDataSource(this.obs);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.fieldIssueDS = this.dataSource.connect();
  }

  toggleFieldIssueFilterInput() {
    this.isShowingFieldIssueInput = !this.isShowingFieldIssueInput;
  }

  ngOnDestroy() {
    if (this.source) {
      this.source = null;
    }
    this.isFieldIssueDetailPanelVisible = false;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  toggleFilter() {
    if (this.showFilter) {
      this.filterApplied = {};
      this.applyFilterToData();
      this.loadTable();
    }

    this.showFilter = !this.showFilter;
  }

  dateFilterOperatorChanged(e: MatSelectChange) {
    this.filterToBe.createdDateFilterOperator = e.value;
  }

  filterCreatedDateChanged(e: MatDatepickerInputEvent<Date>) {
    this.filterToBe.createdDateFilter = e.value;
  }

  filterCreatedDateRangeStartChanged(e: MatDatepickerInputEvent<Date>) {
    this.filterToBe.createdDateFilterRangeStartDate = e.value;
  }

  filterCreatedDateRangeEndChanged(e: MatDatepickerInputEvent<Date>) {
    this.filterToBe.createdDateFilterRangeEndDate = e.value;
  }

  filterCancelClicked() {
    this.showFilter = false;
    this.filterApplied = {};
    this.applyFilterToData();
    this.loadTable();
  }

  filterClearClicked() {
    this.filterCreatedDateOperator = null;
    this.filterCreatedDate = null;
    this.filterToBe = {};
    this.filterApplied = {};
    this.applyFilterToData();
    this.loadTable();
  }

  filterApply() {
    if (!this.validateFilter()) {
      this.snackbarService.warningSnackBar(
        this.ts.instant("fieldIssue.messages.enterValidFilter")
      );
      return;
    }

    this.filterApplied = { ...this.filterToBe, isFilterApplied: true };

    this.applyFilterToData();
    this.loadTable();
  }

  applyFilterToData() {
    if (this.filterApplied.isFilterApplied) {
      if (
        this.filterApplied.createdDateFilterOperator == this.dateOperator.ON
      ) {
        this.obs = this.obsNoFilter.filter((item) => {
          return (
            new Date(new Date(item.createdAt).toDateString()).getTime() ==
            this.filterApplied.createdDateFilter.getTime()
          );
        });
      } else if (
        this.filterApplied.createdDateFilterOperator ==
        this.dateOperator.BETWEEN
      ) {
        this.obs = this.obsNoFilter.filter((item) => {
          return (
            this.filterApplied.createdDateFilterRangeStartDate.getTime() <=
              new Date(new Date(item.createdAt).toDateString()).getTime() &&
            new Date(new Date(item.createdAt).toDateString()).getTime() <=
              this.filterApplied.createdDateFilterRangeEndDate.getTime()
          );
        });
      }
    } else {
      this.obs = this.obsNoFilter;
    }
  }

  validateFilter() {
    if (
      !this.filterToBe.createdDateFilterOperator ||
      (this.filterToBe.createdDateFilterOperator == this.dateOperator.ON &&
        !this.filterToBe.createdDateFilter) ||
      (this.filterToBe.createdDateFilterOperator == this.dateOperator.BETWEEN &&
        (!this.filterToBe.createdDateFilterRangeStartDate ||
          !this.filterToBe.createdDateFilterRangeEndDate))
    ) {
      return false;
    }
    return true;
  }

  private handleError(error: any) {
    return throwError(error);
  }

  getMasterData() {
    this.masterDataSvc.getMasterData(this.projectId).subscribe(
      (data) => {
        this.masterData = data.master;
        this.setMasterData(this.masterData);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  setMasterData(data) {
    this.towerList.push({
      level1: this.ALL_TOWERS,
      locationId: this.ALL_TOWERS,
    });
    data.workLocation.forEach((location) => {
      if (!location.parentLocationId) {
        this.towerList.push(location);
        this.l1l2Mapping[location.locationId] = [
          { level2: this.ALL_FLOORS, locationId: this.ALL_FLOORS },
        ];
      }
    });
    data.workLocation.forEach((location) => {
      if (
        location.parentLocationId &&
        !location.level3 &&
        !location.level4 &&
        Array.isArray(this.l1l2Mapping[location.parentLocationId])
      ) {
        this.l1l2Mapping[location.parentLocationId].push(location);
      }
    });
  }

  getFieldIssueData(towerId: string, floorId: string = "none") {
    this.uiSvc.show();
    this.source = this.fieldIssueService
      .getFIListByTower(this.projectId, towerId, floorId)
      .pipe(
        map(
          (data) => {
            const fieldIssueList = [];

            if (!!data && !!data.fieldIssues && data.fieldIssues.length > 0) {
              const fieldIssueListData = data.fieldIssues;
              const fieldIssueIds = data.fieldIssues.map((fieldIssue) => {
                return fieldIssue.issueId;
              });
              this.fieldIssueService
                .getFilesByFieldIssueList(
                  this.clientId,
                  this.projectId,
                  "interior",
                  fieldIssueIds
                )
                .subscribe((fiFiles: any) => {
                  const fieldIssueFilesNFolders: any[] =
                    fiFiles?.data?.resFieldIssueFiles;
                  fieldIssueListData.forEach((fieldIssue: any) => {
                    const statusColor = this.StatusColors[fieldIssue.status];
                    const currentDate = moment();
                    const dueDate = moment(fieldIssue.dueDate);
                    const numberOfDays: number = dueDate.diff(
                      currentDate,
                      "days"
                    );
                    let fiDueDate = fieldIssue.dueDate;
                    if (numberOfDays > 0) {
                      fiDueDate = eval(
                        "`" +
                          this.ts.instant("fieldIssue.labels.DueInDays") +
                          "`"
                      );
                    } else {
                      fiDueDate =
                        this.ts.instant("fieldIssue.labels.pastDueDate") +
                        dueDate.format("DD MMM YYYY");
                    }

                    for (let item of fieldIssueFilesNFolders) {
                      if (item.folder.name == fieldIssue.issueId) {
                        // appending fieldIssueRefId for existing field issue so user
                        // can upload new files in same field issue folder
                        fieldIssue.fieldIssueRefId = item.folder.id;
                        for (let file of item.files) {
                          const metadataType: string = file.metadata
                            .find(
                              (metadata: IMetadata) => metadata.label == "Type"
                            )
                            .value.toLowerCase();
                          if (metadataType == "snapshot") {
                            fieldIssue.snapshotImage = {
                              name: file.name,
                              size: file.fileSize,
                              fileObjectId: file.fileObjectId,
                              downloadUrl: file.downloadUrl,
                              viewUrl: file.viewUrl,
                              uploadFileType: "snapshot",
                            };
                          } else if (metadataType == "floorplanlocation") {
                            fieldIssue.floorplanImage = {
                              name: file.name,
                              size: file.fileSize,
                              fileObjectId: file.fileObjectId,
                              downloadUrl: file.downloadUrl,
                              viewUrl: file.viewUrl,
                              uploadFileType: "floorplanLocation",
                            };
                          } else {
                            fieldIssue.attachments.push({
                              name: file.name,
                              size: file.fileSize,
                              fileObjectId: file.fileObjectId,
                              downloadUrl: file.downloadUrl,
                              viewUrl: file.viewUrl,
                              uploadFileType: "attachment",
                            });
                          }
                        }
                      }
                    }
                    fieldIssueList.push({
                      ...fieldIssue,
                      statusColor: statusColor,
                      fiDueDate: fiDueDate,
                    });
                  });

                  this.uiSvc.hide();
                  this.assignData(fieldIssueList);
                });
            } else {
              this.uiSvc.hide();
              this.assignData(fieldIssueList);
            }
          },
          (err) => {
            this.uiSvc.hide();
          }
        ),
        catchError(this.handleError),
        finalize(() => {})
      )
      .subscribe();
  }

  assignData(fieldIssueList: any[]) {
    this.obsNoFilter = fieldIssueList;
    this.obs = fieldIssueList;
    this.applyFilterToData();
    this.loadTable();
  }

  selectTower(towerId: string) {
    this.towerId = towerId;
    if (this.towerId == this.ALL_TOWERS) {
      this.floorList = [];
      this.floorId = "none";
    } else {
      this.floorList = this.l1l2Mapping[towerId];
      this.floorId = this.ALL_FLOORS;
    }
    this.getFieldIssueData(this.towerId, this.floorId);
  }

  selectFloor(floorId: string) {
    this.floorId = floorId;
    if (this.towerId && this.floorId)
      this.getFieldIssueData(this.towerId, this.floorId);
  }

  viewInVirtualTour(fi: any) {
    const fieldIssueObj = {
      clientId: this.clientId,
      projectId: this.projectId,
      interiorId: fi.interiorId,
      tourId: fi.tourId,
      towerId: fi.towerId,
      issueId: fi.issueId,
    };
    this.fieldIssueService.setFieldIssueObject(fieldIssueObj);
    const navigateUrl = `/project/detail/${this.projectId}/interior/list`;
    this.router.navigateByUrl(navigateUrl);
  }

  openFI(fiInfo: any) {
    this.fiDetailPanelHeading = fiInfo.issueNumber;
    this.fieldIssueService.setData("existing_issue", {
      ...this.getLatestFieldIssueConfig(fiInfo),
    });
    this.isFieldIssueDetailPanelVisible = true;
  }

  closeFieldIssueDetailPanel(event: any) {
    this.getFieldIssueData(this.towerId);
    this.isFieldIssueDetailPanelVisible = false;
  }

  getLatestFieldIssueConfig(fiInfo: any) {
    return {
      ...fiInfo,
      towerName: fiInfo.towerName,
      tour: fiInfo.tour,
      towerId: fiInfo.towerId,
      viewer: null,
      projectId: this.projectId,
      tourId: fiInfo.tourId,
      floorId: fiInfo.floorId,
    };
  }

  exportGridData() {
    this.uiSvc.show();
    if (this.obs.length > 0) {
      const list: ExportData[] = [];
      for (const item of this.obs) {
        const row: ExportData = {} as ExportData;
        const createdDate = this.datePipe.transform(item.createdAt);
        const dueDate = item.dueDate
          ? this.datePipe.transform(item.dueDate)
          : "";
        row["Issue No"] = item.issueNumber;
        row["Work Location"] = item?.location;
        let workTrade = this.masterData.workPackage.find(
          (dat) => dat.tradeId == item?.workTrade
        );
        row["Work Trade"] = workTrade?.tradeName;

        row["Description"] = item.description;
        let priority = this.priorityList.find(
          (cvData) => cvData.key == item.priority
        );
        row["Priority"] = priority?.value;
        row["Due Date"] = dueDate;
        let status = this.statusList.find(
          (cvData) => cvData.key == item.status
        );
        row.Status = status?.value;
        row["Assignee"] = item.assignee;
        row["Created By"] = item.createdBy;
        row["Created Date"] = createdDate;
        list.push(row);
      }

      this.excelService.exportAsExcelFile(list, `FieldIssue-ALL`);
      this.uiSvc.hide();
    } else {
      this.uiSvc.hide();
      const alert = this.ts.instant("task.list.messages.noPunchItemsFound");
      this.snackService.errorSnackBar(alert);
    }
  }
}

export interface DateOperator {
  ON: string;
  BETWEEN: string;
}
