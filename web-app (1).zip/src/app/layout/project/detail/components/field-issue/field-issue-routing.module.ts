import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { FieldIssueComponent } from "./field-issue.component";

const routes: Routes = [
  {
    path: "",
    component: FieldIssueComponent,
    children: [
      {
        path: "",
        redirectTo: "list",
        pathMatch: "full",
      },
      {
        pathMatch: "prefix",
        path: "list",
        component: FieldIssueComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FieldIssueRoutingModule {}
