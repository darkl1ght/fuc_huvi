import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  AfterViewInit,
  Inject,
} from "@angular/core";
import videojs from "video.js";
import "@videojs/http-streaming";
import { Device, DeviceDialogData } from "src/app/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Component({
  selector: "app-hlsplayer",
  templateUrl: "./hlsplayer.component.html",
  styleUrls: ["./hlsplayer.component.scss"],
})
export class HLSPlayerComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild("video", { static: true }) element;

  player: any;
  myPlayer: any;
  playerUrl: string;
  device: Device;

  constructor(
    public dialog: MatDialog,
    @Inject(APP_CONFIG) private config: AppConfig,
    @Inject(MAT_DIALOG_DATA) private data: DeviceDialogData
  ) {}

  ngOnInit(): void {
    this.device = this.data.device;
    this.playerUrl = this.config.playerUrl.replace(
      "{player}",
      this.device.deviceId
    );
    this.setLiveStreamingUrl(this.playerUrl);
  }

  setLiveStreamingUrl(playerUrl) {
    this.player = videojs(this.element.nativeElement);
    this.player.src([
      {
        type: "application/x-mpegURL",
        src: playerUrl,
      },
    ]);
    this.player.play();
  }

  ngOnDestroy() {
    if (this.player) {
      this.player.dispose();
    }
  }

  async closeDialog(): Promise<void> {
    this.dialog.closeAll();
  }

  ngAfterViewInit() {}
}
