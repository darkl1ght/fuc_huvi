import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import { VgHlsDirective } from "@videogular/ngx-videogular/streaming";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { DeviceDialogData, Device } from "src/app/core";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Component({
  selector: "app-blank-page",
  templateUrl: "./live-stream-panorama.html",
  styleUrls: ["./live-stream-panorama.scss"],
})
export class LiveStreamPanorama implements OnInit {
  hlsBitrates = [];
  @ViewChild(VgHlsDirective, { static: true }) vgHls: VgHlsDirective;
  playerUrl: string = "";
  device: Device;

  constructor(
    public dialog: MatDialog,
    @Inject(APP_CONFIG) private config: AppConfig,
    @Inject(MAT_DIALOG_DATA) private data: DeviceDialogData
  ) {}

  ngOnInit() {
    this.device = this.data.device;
    this.playerUrl = this.config.playerUrl.replace(
      "{player}",
      this.device.deviceId
    );
  }

  async closeDialog(): Promise<void> {
    this.dialog.closeAll();
  }
}
