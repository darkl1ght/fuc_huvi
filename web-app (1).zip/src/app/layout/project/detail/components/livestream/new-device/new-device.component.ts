import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import {
  UntypedFormGroup,
  UntypedFormBuilder,
  Validators,
} from "@angular/forms";

import {
  Device,
  DeviceDialogData,
  LookUpService,
  LiveStreamService,
  SnackbarService,
  Lookup,
} from "src/app/core";
import { MAT_DIALOG_DATA, MatDialog } from "@angular/material/dialog";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "app-new-device",
  templateUrl: "./new-device.component.html",
  styleUrls: ["./new-device.component.scss"],
})
export class NewDeviceComponent implements OnInit {
  @ViewChild("deviceForm") deviceForm;
  public breakpoint: number;
  public deviceName: string = "";
  public addDeviceForm: UntypedFormGroup;
  deviceTypeList: Lookup[] = [];
  formSubmitAttempt: boolean = false;
  device: Device = {} as Device;
  errors = {};
  wasFormChanged = false;
  projectId: string;
  disableBtn: boolean = false;

  constructor(
    private fb: UntypedFormBuilder,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: DeviceDialogData,
    private lookupSvc: LookUpService,
    private livestreamSvc: LiveStreamService,
    private snackService: SnackbarService,
    private ts: TranslateService
  ) {
    this.addDeviceForm = this.fb.group({
      deviceId: null,
      deviceName: [
        this.deviceName,
        [
          Validators.required,
          Validators.pattern(
            /^[a-zA-ZÀ-ÿ0-9]+[a-zA-ZÀ-ÿ0-9+\-,:;=@&#|'<>^*()%!_\.\/\\ ]*$/
          ),
        ],
      ],
      record: [true, null],
      deviceType: ["", [Validators.required]],
    });
  }

  public ngOnInit(): void {
    this.getLookupData();
    this.setActivityDetails(this.data.device);
  }

  get f() {
    return this.addDeviceForm.controls;
  }

  public onDeviceAdd(): void {
    this.formSubmitAttempt = true;
    this.markAsDirty(this.addDeviceForm);
    this.onSubmit();
  }

  setActivityDetails(device: Device) {
    this.projectId = this.data.projectId;
    if (device && device.deviceId) {
      this.addDeviceForm.patchValue({
        deviceId: device.deviceId,
        deviceName: device.deviceName,
        deviceType: device.deviceType["code"],
        record: device.recording,
      });
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
    this.onReset();
  }

  changeDeviceType(e) {
    this.deviceType.setValue(e.value, {
      onlySelf: true,
    });
  }

  get deviceType() {
    return this.addDeviceForm.get("deviceType");
  }

  //tslint:disable-next-line:no-any
  public onResize(event: any): void {
    this.breakpoint = event.target.innerWidth <= 600 ? 1 : 2;
  }

  private markAsDirty(group: UntypedFormGroup): void {
    group.markAsDirty();
    for (const i in group.controls) {
      group.controls[i].markAsDirty();
    }
  }

  formChanged() {
    this.wasFormChanged = true;
  }

  getLookupData() {
    this.lookupSvc.getAll("deviceType").subscribe(
      (data) => {
        this.deviceTypeList = data;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  onSubmit() {
    let alert = "";
    this.formSubmitAttempt = true;
    if (this.addDeviceForm.valid) {
      this.disableBtn = true;
      this.updateDevice(this.addDeviceForm.value);
      this.livestreamSvc.save(this.projectId, this.device).subscribe(
        (data) => {
          alert = this.ts.instant(
            "liveStream.newDevice.messages.newDeviceCreated"
          );
          this.snackService.successSnackBar(alert);
          this.dialog.closeAll();
          this.onReset();
          this.disableBtn = false;
        },
        (err) => {
          alert = this.ts.instant(
            "liveStream.newDevice.messages.deviceCreationFailed"
          );
          this.errors = err;
          this.formSubmitAttempt = false;
          this.snackService.errorSnackBar(alert);
          this.dialog.closeAll();
        }
      );
    }
  }

  onReset() {
    this.formSubmitAttempt = false;
    this.deviceForm.resetForm();
    this.addDeviceForm.reset();
  }

  updateDevice(values: Object) {
    this.device.deviceId = values["deviceId"] ? values["deviceId"] : "";
    this.device.deviceName = values["deviceName"].trim();
    this.device.recording = values["record"];
    this.device.isActive = true;
    this.device.deviceType = {
      code: this.deviceTypeList.find((x) => x.key === values["deviceType"]).key,
      desc: this.deviceTypeList.find((x) => x.key === values["deviceType"])
        .value,
    };
  }
}
