import { Component, OnInit, ViewChild, ChangeDetectorRef } from "@angular/core";
import { Observable } from "rxjs";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import {
  LiveStreamService,
  UiService,
  Device,
  UserService,
  User,
  SnackbarService,
} from "src/app/core";
import { ActivatedRoute } from "@angular/router";
import { MatDialog } from "@angular/material/dialog";
import { NewDeviceComponent } from "../new-device/new-device.component";
import {
  ConfirmDialogModel,
  ConfirmDialogComponent,
} from "src/app/layout/components/confirm-dialog/confirm-dialog.component";
import { TranslateService } from "@ngx-translate/core";
import { LiveStreamPanorama } from "../pano-player/live-stream-panorama";
import { HLSPlayerComponent } from "../livestream-player/hlsplayer.component";

@Component({
  selector: "app-device-list",
  templateUrl: "./device-list.component.html",
  styleUrls: ["./device-list.component.scss"],
})
export class DeviceListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>();
  projectId: string = "";
  errors: any;
  result: string = "";
  devices: Device[] = [];
  currentUser: User;

  constructor(
    private changeDetectorRef: ChangeDetectorRef,
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private uiService: UiService,
    private ts: TranslateService,
    private snackService: SnackbarService,
    private liveStreamSvc: LiveStreamService,
    private userService: UserService
  ) {
    this.currentUser = this.userService.getCurrentUser();
  }

  ngOnInit() {
    this.changeDetectorRef.detectChanges();
    this.projectId =
      this.route.parent.parent.parent.snapshot.paramMap.get("projectId");
    this.getDeviceList();
  }

  ngOnDestroy() {
    if (this.dataSource) {
      this.dataSource.disconnect();
    }
  }

  openPlayer(device: Device) {
    if (device.upTime > 0) {
      if (device.deviceType["code"] === "DT10002") {
        this.openPanoramaStreaming(device);
      } else {
        this.openHLSStreaming(device);
      }
    }
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(NewDeviceComponent, {
      width: "450px",
      disableClose: true,
      data: { projectId: this.projectId, device: undefined },
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getDeviceList();
    });
  }

  openHLSStreaming(device: Device): void {
    const dialogRef = this.dialog.open(HLSPlayerComponent, {
      width: "70%",
      disableClose: true,
      data: { projectId: this.projectId, device: device },
    });
  }

  openPanoramaStreaming(device: Device): void {
    const dialogRef = this.dialog.open(LiveStreamPanorama, {
      width: "70%",
      disableClose: true,
      data: { projectId: this.projectId, device: device },
    });
  }

  getDeviceList() {
    this.uiService.show();
    this.liveStreamSvc.getDevice(this.projectId).subscribe(
      (data) => {
        this.devices = data.devices;
        this.dataSource = new MatTableDataSource(this.devices);
        this.dataSource.paginator = this.paginator;
        this.obs = this.dataSource.connect();
        this.uiService.hide();
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  deleteDevice(device: Device) {
    const message = this.ts.instant("dialog.messages.removeDevice");
    const dialogData = new ConfirmDialogModel(
      this.ts.instant("dialog.confirmAction"),
      message
    );
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.liveStreamSvc.destroy(this.projectId, device.deviceId).subscribe(
          (data) => {
            let alert = this.ts.instant(
              "liveStream.device.messages.deviceDeleteSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.getDeviceList();
          },
          (err) => {
            this.errors = err;
          }
        );
      }
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
