import { Component, OnInit, ViewChild, ChangeDetectorRef } from "@angular/core";

@Component({
  selector: "app-livestream",
  templateUrl: "./livestream.component.html",
  styleUrls: ["./livestream.component.scss"],
})
export class LiveStreamComponent implements OnInit {
  constructor() {}

  ngOnInit() {}

  ngOnDestroy() {}
}
