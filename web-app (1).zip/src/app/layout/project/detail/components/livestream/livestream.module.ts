import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { SharedModule } from "src/app/shared";
import { DeviceListComponent } from "./device-list/device-list.component";
import { LiveStreamRoutingModule } from "./livestream-routing.module";
import { LiveStreamComponent } from "./livestream.component";
import { NewDeviceComponent } from "./new-device/new-device.component";
import { LiveStreamPanorama } from "./pano-player/live-stream-panorama";
import { HLSPlayerComponent } from "./livestream-player/hlsplayer.component";
import { VgCoreModule } from "@videogular/ngx-videogular/core";
import { VgControlsModule } from "@videogular/ngx-videogular/controls";
import { VgOverlayPlayModule } from "@videogular/ngx-videogular/overlay-play";
import { VgBufferingModule } from "@videogular/ngx-videogular/buffering";
import { VgStreamingModule } from "@videogular/ngx-videogular/streaming";

@NgModule({
  imports: [
    LiveStreamRoutingModule,
    SharedModule,
    VgCoreModule,
    VgControlsModule,
    VgOverlayPlayModule,
    VgBufferingModule,
    VgStreamingModule,
  ],
  declarations: [
    DeviceListComponent,
    NewDeviceComponent,
    HLSPlayerComponent,
    LiveStreamPanorama,
    LiveStreamComponent,
  ],
  providers: [
    { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} },
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class LiveStreamModule {}
