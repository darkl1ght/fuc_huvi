import { Component, ViewChild, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import * as _ from "lodash";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { ITask } from "src/app/core";

@Component({
  selector: "task-list",
  templateUrl: "./task-list.component.html",
  styleUrls: ["./task-list.component.scss"],
})
export class TaskListComponent {
  dataSource: MatTableDataSource<ITask>;
  displayedColumns: string[] = ["icon", "description"];
  heading: string = "";
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    public dialogRef: MatDialogRef<TaskListComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any
  ) {
    this.heading = this.data.heading;
    this.dataSource = new MatTableDataSource(this.data.taskList);
    this.dataSource.sortingDataAccessor = (
      item: any,
      property: string
    ): string => {
      switch (property) {
        case "description":
          return item.description.toLowerCase();
        default:
          return item[property];
      }
    };
  }

  public ngOnInit(): void {}

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  applySearchFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  isSticky(id: string) {
    return (["header-1"] || []).indexOf(id) !== -1;
  }
}
