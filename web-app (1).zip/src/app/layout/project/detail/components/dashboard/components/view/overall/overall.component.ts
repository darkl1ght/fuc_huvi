import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  Inject,
  Input,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import {
  trigger,
  state,
  style,
  animate,
  transition,
} from "@angular/animations";
import {
  CdkDropList,
  CdkDragEnter,
  moveItemInArray,
} from "@angular/cdk/drag-drop";

import { allOverallCards, dragSvgIcon } from "../dashboard.card.data";
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import {
  DashboardService,
  LocalStorageService,
  MasterDataService,
  ProjectService,
  UiService,
  User,
  UserService,
  DashboardCard,
  SnackbarService,
  WorkLocation,
  InteriorService,
  InteriorImage,
} from "src/app/core";
import { Subscription, of } from "rxjs";
import { map, mergeMap } from "rxjs/operators";
import { TranslateService } from "@ngx-translate/core";
import * as mapboxgl from "mapbox-gl";
import { environment } from "src/environments/environment";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
declare const pannellum: any;

@Component({
  selector: "d-overall",
  templateUrl: "./overall.component.html",
  styleUrls: ["./overall.component.scss"],
  animations: [
    trigger("slideInOut", [
      state(
        "in",
        style({
          transform: "translate3d(0, 0, 0)",
        })
      ),
      state(
        "out",
        style({
          transform: "translate3d(0, 0, 0)",
        })
      ),
      transition("in => out", animate("400ms ease-in-out")),
      transition("out => in", animate("400ms ease-in-out")),
    ]),
  ],
})
export class DOverallComponent implements AfterViewInit, OnInit, OnDestroy {
  @Input() loadDefaultCards: boolean;
  @ViewChildren(CdkDropList) dropsQuery: QueryList<CdkDropList>;

  currUser: User;

  drops: CdkDropList[];
  allCards: DashboardCard[] = [];
  enabledCards: DashboardCard[] = [] as DashboardCard[];
  disabledCards: DashboardCard[] = [] as DashboardCard[];
  editModeOn: boolean = false;

  showEditButton: boolean = false;
  projectId!: string;
  errors: any = null;

  towerList: { towerName: string; towerId: string }[] = [];
  isDayCardContentLoading: boolean = false;
  selectedTowerForDaysToSelectCard: string;
  dayToCompleteCardContent: string;
  showInteriorToggle: boolean = true;
  exteriorDataAvailable: boolean = false;
  interiorDataAvailable: boolean = false;
  daysToCompleteInteriorDays: string = "0";
  daysToCompleteExteriorDays: string = "0";
  showExteriorProgress: boolean = false;
  showInteriorProgress: boolean = false;
  daysToCompleteCardResponseCode: string = "";
  daysToCompleteExteriorPProgress: number = 0;
  daysToCompleteInteriorPProgress: number = 0;
  daysToCompleteExteriorAProgress: number = 0;
  daysToCompleteInteriorAProgress: number = 0;
  slideInOutState: string = "in";

  dashboardSubscription: Subscription;
  editModeSubs: Subscription;
  toggleCardSubs: Subscription;
  allTaskStatusColors: any = {};
  fieldIssueStatusColors: {
    open: string;
    resolved: string;
    verified: string;
    archived: string;
  };
  rfiStatusColors: { pending: string; approved: string; new: string };
  punchlistStatusColors: {
    accepted: string;
    pending_verification: string;
    not_accepted: string;
    conditionally_accepted: string;
  };
  itemOrderChanged: boolean = false;
  map: mapboxgl.Map = null;
  lat: number;
  lng: number;
  defaultZoom: number = 16;
  minZoom: number = 13;
  style = "mapbox://styles/mapbox/streets-v12";

  tourLabel: string;
  tourType: string;
  tourDate: any;
  viewer: any;

  constructor(
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer,
    private masterDataSvc: MasterDataService,
    private localStorageSvc: LocalStorageService,
    private dashboardSvc: DashboardService,
    private userService: UserService,
    private projectSvc: ProjectService,
    private uiSvc: UiService,
    private ts: TranslateService,
    private cdr: ChangeDetectorRef,
    private snackbarSvc: SnackbarService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private interiorService: InteriorService
  ) {
    this.currUser = this.userService.getCurrentUser();
    this.projectId = this.localStorageSvc.getProjectId();
    iconRegistry.addSvgIconLiteral(
      "dragSvgIcon",
      sanitizer.bypassSecurityTrustHtml(dragSvgIcon)
    );
  }

  ngAfterViewInit() {
    this.dropsQuery.changes.subscribe(() => {
      this.drops = this.dropsQuery.toArray();
      this.cdr.detectChanges();
    });
    this.setAllCards();
  }

  ngOnInit() {
    this.editModeSubs = this.dashboardSvc.isEditMode$.subscribe((data) => {
      this.editModeOn = data;
      if (this.itemOrderChanged && !this.editModeOn) {
        this.saveOverallCardOrder();
      }
    });

    this.toggleCardSubs = this.dashboardSvc.cardToToggle$.subscribe(
      (cardFromWidget) => {
        if (cardFromWidget?.id) {
          let matchedCard = this.allCards.find(
            ({ id }) => id == cardFromWidget.id
          );
          this.toggleCard(matchedCard);
        }
      }
    );
    this.projectDetails();
  }

  projectDetails() {
    this.projectSvc.get(this.projectId).subscribe({
      next: ({ lat, lng }) => {
        this.lat = lat;
        this.lng = lng;
      },
      error: (err) => {},
    });
  }

  setAllCards() {
    if (!this.loadDefaultCards) {
      this.uiSvc.show();
      this.projectSvc.get(this.projectId).subscribe(({ users }) => {
        if (users?.length > 0) {
          const userInProjectUser = users.find(
            ({ email, isBlocked, isActive }) =>
              email === this.currUser.email && !isBlocked && isActive
          );
          if (userInProjectUser) {
            this.allCards = [...userInProjectUser.dashboard.overall];
            this.filterCards();
            this.loadCardsData();
          } else {
            // edge case
            // when user access has been revoked from project
            let alert = this.ts.instant(
              "dashboard.overall.messages.noUserAccess"
            );
            this.snackbarSvc.errorSnackBar(alert);
          }
        }
        this.uiSvc.hide();
      });
    } else {
      this.allCards = [...allOverallCards];
      this.filterCards();
      this.loadCardsData();
    }
  }

  filterCards() {
    this.enabledCards = this.allCards
      .filter(({ enabled }) => enabled)
      .map((card) => ({ ...card, isLoading: true }))
      .sort((a, b) => a.order - b.order);
    this.disabledCards = this.allCards.filter(({ enabled }) => !enabled);
  }

  entered($event: CdkDragEnter) {
    moveItemInArray(this.enabledCards, $event.item.data, $event.container.data);
    this.changeItemOrder();
  }

  changeItemOrder() {
    this.enabledCards.map((card, index) => (card.order = index));
    this.itemOrderChanged = true;
  }

  toggleCard(card: DashboardCard) {
    if (card) {
      card.enabled = !card.enabled;
      this.filterCards();
      this.changeItemOrder();
      this.loadCardsData();
      this.saveOverallCardOrder();
    }
  }

  loadCardsData() {
    this.dashboardSubscription?.unsubscribe();
    const observables = [];
    for (let card of this.enabledCards) {
      switch (card.type) {
        case "d3-donut":
          if (card.id == 5) {
            observables.push(
              this.dashboardSvc
                .getD3DonutTasksChart(this.projectId, "all")
                .pipe(map((data) => ({ card, data })))
            );
          } else if (card.id == 6) {
            observables.push(
              this.dashboardSvc
                .getD3TaskChartAssigned(
                  this.projectId,
                  "rfi",
                  card.type.split("-").pop(),
                  "all"
                )
                .pipe(map((data) => ({ card, data })))
            );
          } else if (card.id == 3) {
            observables.push(
              this.dashboardSvc
                .getD3TaskChartAssigned(
                  this.projectId,
                  "fieldissue",
                  card.type.split("-").pop(),
                  "all"
                )
                .pipe(map((data) => ({ card, data })))
            );
          }
          break;
        case "d3-pie":
          if (card.id == 3) {
            observables.push(
              this.dashboardSvc
                .getD3TaskChartAssigned(
                  this.projectId,
                  "fieldissue",
                  card.type.split("-").pop(),
                  "all"
                )
                .pipe(map((data) => ({ card, data })))
            );
          }
          break;
        case "d3-bar":
          if (card.id == 2) {
            observables.push(
              this.dashboardSvc
                .getD3TaskChartAssigned(
                  this.projectId,
                  "punchlist",
                  "bar",
                  "all"
                )
                .pipe(map((data) => ({ card, data })))
            );
          }
          break;
        case "coming-soon":
          observables.push(of({}).pipe(map((data) => ({ card, data }))));
          break;
        case "exterior-interior-latest":
          observables.push(
            this.dashboardSvc
              .getLatestAerialInteriorTour(this.projectId)
              .pipe(map((data) => ({ card, data })))
          );
          break;
        case "days-to-complete":
          observables.push(
            this.masterDataSvc
              .getMasterData(this.projectId)
              .pipe(map((data) => ({ card, data })))
          );
          break;
      }
    }
    const dashboardData$ = of(...observables).pipe(mergeMap((obs) => obs));

    this.dashboardSubscription = dashboardData$.subscribe({
      next: ({ data, card }: { data: any; card: DashboardCard }) => {
        // Update the corresponding card on the dashboard with the received data
        switch (card.type) {
          case "days-to-complete":
            this.daysToCompleteCard(data, card);
            break;
          case "d3-donut":
            this.loadDonutCard(data, card);
            break;
          case "d3-pie":
            // loading donut card as input data for both is same
            this.loadDonutCard(data, card);
            break;
          case "d3-bar":
            this.loadBarCard(data, card);
            break;
          case "coming-soon":
            setTimeout(() => {
              this.stopCardLoading(card);
            }, 2000);
            break;
          case "exterior-interior-latest":
            this.loadAerialInteriorCard(data, card);
            break;
        }
      },
      error: (error) => {
        this.errors =
          "Uh oh! There was a problem loading this Card. Please refresh the page and try again.";
      },
    });
  }

  daysToCompleteCard(data: any, card: DashboardCard) {
    this.towerList = [];
    if (data.master?.workLocation) {
      data.master.workLocation
        .sort((a, b) => a.orderNo - b.orderNo)
        .forEach((location: WorkLocation) => {
          if (!location.parentLocationId) {
            this.towerList.push({
              towerId: location.locationId,
              towerName: location.level1,
            });
          }
        });
      this.stopCardLoading(card);
      if (this.towerList.length > 0) {
        this.isDayCardContentLoading = true;
        this.selectedTowerForDaysToSelectCard = this.towerList[0].towerId;
        this.getDaysToCompleteForTower(this.selectedTowerForDaysToSelectCard);
      } else {
        this.dayToCompleteCardContent = this.ts.instant(
          "dashboard.overall.messages.noTowers"
        );
      }
    } else {
      this.errors = "Error while loading daysToCompleteCard";
      this.stopCardLoading(card);
      this.dayToCompleteCardContent = this.ts.instant(
        "dashboard.overall.messages.noTowers"
      );
    }
  }

  loadDonutCard(data: any, card: DashboardCard) {
    let colors;
    if (card.id === 5) {
      this.allTaskStatusColors = {
        pending: "#FFA825",
        completed: "#7AC142",
        overdue: "#FF0000",
      };
    } else if (card.id === 3) {
      this.fieldIssueStatusColors = {
        open: "#FF0000",
        resolved: "#FFA500",
        verified: "#008000",
        archived: "#F8F801",
      };
    } else {
      this.rfiStatusColors = {
        pending: "#FFA825",
        approved: "#7AC142",
        new: "#FF0000",
      };
    }
    if (card.id == 5) {
      colors = this.allTaskStatusColors;
    } else if (card.id == 6) {
      colors = this.rfiStatusColors;
    } else if (card.id == 3) {
      colors = this.fieldIssueStatusColors;
    }
    let mappedLabels = [];
    for (let ele of data) {
      if (ele.count) {
        mappedLabels.push({
          title: this.ts.instant(`dashboard.labels.${ele.label.toLowerCase()}`),
          color: colors[ele.label.toLowerCase()],
          count: ele.count,
        });
      }
    }
    const donutCard = this.enabledCards.find(({ id }) => id === card.id);
    if (donutCard) {
      if (mappedLabels.length) {
        donutCard._temp = {
          labels: mappedLabels,
          chartData: mappedLabels,
          noDataFound: false,
        };
      } else {
        donutCard._temp = { noDataFound: true };
      }
      donutCard && this.stopCardLoading(card);
    }
  }

  getChartId(card: any): string {
    return `chart_${card.id}_${card._temp?.chartType}`;
  }

  loadBarCard(data: any, card: DashboardCard) {
    let colors = (this.punchlistStatusColors = {
      accepted: "#7AC142",
      pending_verification: "#F8F801",
      not_accepted: "#FF0000",
      conditionally_accepted: "#FF8800",
    });

    let mappedLabels = [];
    for (let ele of data) {
      if (ele.value) {
        mappedLabels.push({
          name: this.ts.instant(`dashboard.labels.${ele.name.toLowerCase()}`),
          color: colors[ele.name.toLowerCase()],
          value: ele.value,
        });
      }
    }
    const barCard = this.enabledCards.find(({ id }) => id === card.id);
    if (barCard) {
      if (mappedLabels.length) {
        barCard._temp = {
          labels: mappedLabels,
          chartData: mappedLabels,
          noDataFound: false,
        };
      } else {
        barCard._temp = { noDataFound: true };
      }
      barCard && this.stopCardLoading(card);
    }
  }

  onTowerChange(ev: any) {
    this.isDayCardContentLoading = true;
    this.selectedTowerForDaysToSelectCard = ev.value;
    this.getDaysToCompleteForTower(ev.value as string);
  }

  getDaysToCompleteForTower(towerId: string): void {
    this.dashboardSvc.getDaysToComplete(this.projectId, towerId).subscribe({
      next: (data) => {
        const { statusCode } = data;
        this.daysToCompleteCardResponseCode = statusCode;
        switch (statusCode) {
          case "CS404":
            this.dayToCompleteCardContent = this.ts.instant(
              "dashboard.overall.messages.noDataFound"
            );
            break;
          case "CS200":
            const { exterior, interior } = data;
            if (!!interior) {
              this.showInteriorToggle = true;
              this.slideInOutState = "in";
            } else {
              this.showInteriorToggle = false;
              this.slideInOutState = "out";
            }
            if (!!interior) {
              this.interiorDataAvailable = true;
              const { daysToComplete, progress } = interior;
              if ((daysToComplete ?? false) && !progress) {
                this.daysToCompleteInteriorDays = this.ts.instant(
                  "dashboard.overall.messages.noDataFound"
                );
                this.showInteriorProgress = false;
              } else {
                this.daysToCompleteInteriorDays = daysToComplete;
                if (progress?.actual && progress?.planned) {
                  this.showInteriorProgress = true;
                  this.daysToCompleteInteriorAProgress = parseFloat(
                    progress.actual
                  );
                  this.daysToCompleteInteriorPProgress = parseFloat(
                    progress.planned
                  );
                } else {
                  this.showInteriorProgress = false;
                }
              }
            }
            if (!!exterior) {
              this.exteriorDataAvailable = true;
              const { daysToComplete, progress } = exterior;
              if ((daysToComplete ?? false) && !progress) {
                this.daysToCompleteExteriorDays = this.ts.instant(
                  "dashboard.overall.messages.noDataFound"
                );
                this.showExteriorProgress = false;
              } else {
                this.daysToCompleteExteriorDays = daysToComplete;
                if (progress?.actual && progress?.planned) {
                  this.showExteriorProgress = true;
                  this.daysToCompleteExteriorAProgress = parseFloat(
                    progress.actual
                  );
                  this.daysToCompleteExteriorPProgress = parseFloat(
                    progress.planned
                  );
                } else {
                  this.showExteriorProgress = false;
                }
              }
            }
            break;
        }
        this.isDayCardContentLoading = false;
      },
      error: (err) => {
        this.errors = err;
      },
    });
  }

  toggleView() {
    this.showInteriorToggle = !this.showInteriorToggle;
    this.slideInOutState = this.slideInOutState === "out" ? "in" : "out";
  }

  stopCardLoading(card: DashboardCard) {
    card.isLoading &&
      (this.enabledCards.find(({ id }) => card.id === id)!.isLoading = false);
  }

  loadAerialInteriorCard(data: any, card: DashboardCard) {
    const aerialIntCard = this.enabledCards.find(({ id }) => id === card.id);
    if (aerialIntCard) {
      const { statusCode, tourType } = data;
      aerialIntCard._temp = {};
      aerialIntCard._temp.statusCode = statusCode;
      if (statusCode === "CS200") {
        const { tourName, center, tourDate } = data;
        aerialIntCard._temp.tourType = tourType;
        if (tourType === "aerial") {
          aerialIntCard._temp.tourLabel = tourName;
          // do not remove setTimeout
          setTimeout(() => {
            this.loadMapboxMap(center as mapboxgl.LngLatLike);
          }, 0);
        } else if (tourType === "interior") {
          const { towerName, image, tourId } = data;
          aerialIntCard._temp.tourLabel = `${towerName} of ${tourName}`;
          aerialIntCard._temp.image = image;
          if (image) {
            // load pannellum viewer
            this.getSasToken(tourId, image);
          }
        }
        aerialIntCard._temp.tourDate = tourDate;
      } else if (statusCode === "CS404") {
        aerialIntCard._temp.noCardText = this.ts.instant(
          "dashboard.overall.labels.noToursFound"
        );
      }
      this.stopCardLoading(card);
      this.cdr.detectChanges();
    }
  }

  loadMapboxMap(center: mapboxgl.LngLatLike) {
    Object.getOwnPropertyDescriptor(mapboxgl, "accessToken").set(
      environment.mapboxAccessToken
    );
    this.map = new mapboxgl.Map({
      container: "map",
      center,
      minZoom: 6,
      zoom: this.defaultZoom,
      style: this.style,
    });
    const mapRef = this.map;

    this.map.dragRotate.disable();

    const size = 200;

    const pulsingDot = {
      width: size,
      height: size,
      data: new Uint8Array(size * size * 4),

      // When the layer is added to the map,
      // get the rendering context for the map canvas.
      onAdd: function () {
        const canvas = document.createElement("canvas");
        canvas.width = this.width;
        canvas.height = this.height;
        this.context = canvas.getContext("2d");
      },

      // Call once before every frame where the icon will be used.
      render: function () {
        const duration = 1000;
        const t = (performance.now() % duration) / duration;

        const radius = (size / 2) * 0.3;
        const outerRadius = (size / 2) * 0.7 * t + radius;
        const context = this.context;

        // Draw the outer circle.
        context.clearRect(0, 0, this.width, this.height);
        context.beginPath();
        context.arc(
          this.width / 2,
          this.height / 2,
          outerRadius,
          0,
          Math.PI * 2
        );
        context.fillStyle = `rgba(255, 200, 200, ${1 - t})`;
        context.fill();

        // Draw the inner circle.
        context.beginPath();
        context.arc(this.width / 2, this.height / 2, radius, 0, Math.PI * 2);
        context.fillStyle = "rgba(255, 100, 100, 1)";
        context.strokeStyle = "white";
        context.lineWidth = 2 + 4 * (1 - t);
        context.fill();
        context.stroke();

        // Update this image's data with data from the canvas.
        this.data = context.getImageData(0, 0, this.width, this.height).data;

        // Continuously repaint the map, resulting
        // in the smooth animation of the dot.
        mapRef.triggerRepaint();

        // Return `true` to let the map know that the image was updated.
        return true;
      },
    };

    this.map.on("load", () => {
      this.map.resize();
      this.map.addImage("pulsing-dot", pulsingDot, { pixelRatio: 2 });

      this.map.addSource("dot-point", {
        type: "geojson",
        data: {
          type: "FeatureCollection",
          features: [
            {
              type: "Feature",
              geometry: {
                type: "Point",
                coordinates: center as [number, number],
              },
              properties: null,
            },
          ],
        },
      });
      this.map.addLayer({
        id: "layer-with-pulsing-dot",
        type: "symbol",
        source: "dot-point",
        layout: {
          "icon-image": "pulsing-dot",
        },
      });
      this.map.on("click", "layer-with-pulsing-dot", (e) => {
        this.map.flyTo({
          center,
          zoom: this.defaultZoom,
          essential: true,
          bearing: 0,
        });
      });
      this.map.on("mouseenter", "layer-with-pulsing-dot", (e) => {
        this.map.getCanvas().style.cursor = "pointer";
      });
      this.map.on("mouseleave", "layer-with-pulsing-dot", (e) => {
        this.map.getCanvas().style.cursor = "";
      });
    });
  }

  async getSasToken(tourId: string, image: InteriorImage) {
    const { virtualTourContainer: container, virtualTourBlobUrl } = this.config;
    this.interiorService.getReadToken(container).subscribe(
      ({ sasToken: { token } }) => {
        image.imageBlobUrl =
          virtualTourBlobUrl + tourId + "/" + image.blobImageId + "?" + token;
        this.initializePannellumViewer(image);
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  initializePannellumViewer(image: InteriorImage) {
    this.viewer = pannellum.viewer("panorama", {
      scenes: {},
      sceneFadeDuration: 1000,
      author: "Huviair",
      showControls: false,
    });

    this.viewer.setYawBounds([0, 360]);

    let imageOffsetFromNorth = image.offsetFromNorth ?? 0;

    this.viewer.addScene(image.imageId, {
      panorama: image.imageBlobUrl,
      pitch: -2,
      yaw: -imageOffsetFromNorth,
      hfov: 120,
      northOffset: imageOffsetFromNorth,
    });
    this.viewer.loadScene(image.imageId);
  }

  saveOverallCardOrder() {
    this.uiSvc.show();
    const enabledCardCopy: DashboardCard[] = JSON.parse(
      JSON.stringify([...this.enabledCards])
    );

    const allOverallCards = [];
    for (let card of enabledCardCopy) {
      const cardCopy = { ...card };
      delete cardCopy.isLoading;
      delete cardCopy._temp;
      allOverallCards.push(cardCopy);
    }
    allOverallCards.push(...this.disabledCards);
    this.dashboardSvc
      .saveCardViewForProjectUser(this.projectId, {
        dashboard: { overall: allOverallCards },
      })
      .subscribe({
        next: ({ status }) => {
          if (status == "success") {
            this.itemOrderChanged = false;
          }
          this.uiSvc.hide();
        },
        error: (err) => {
          let alert = this.ts.instant(
            "dashboard.overall.messages.cardOrderSavingFailed"
          );
          this.snackbarSvc.errorSnackBar(alert);
          this.uiSvc.hide();
        },
      });
  }

  ngOnDestroy(): void {
    this.dashboardSvc.toggleCard(null);
    this.editModeSubs.unsubscribe();
    this.toggleCardSubs.unsubscribe();
    this.dashboardSubscription.unsubscribe();
  }
}
