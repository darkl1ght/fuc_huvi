import { Component, OnInit, ViewChild } from "@angular/core";
import {
  DashboardService,
  LocalStorageService,
  ProjectService,
  UiService,
  User,
  UserService,
  SnackbarService,
} from "src/app/core";
import { allMeCards, allOverallCards } from "./dashboard.card.data";
import { TranslateService } from "@ngx-translate/core";
import { ConnectionPositionPair } from "@angular/cdk/overlay";

@Component({
  selector: "d-view",
  templateUrl: "./view.component.html",
  styleUrls: ["./view.component.scss"],
})
export class ViewComponent implements OnInit {
  @ViewChild("trigger") trigger;

  showDashboardFilter: boolean = false;
  isUserProjectMember: boolean = false;
  currUser!: User;
  projectId!: string;
  filterString: string = "";
  isEditing: boolean = false;
  loadDefaultCards: boolean = true;
  isLoadingComplete: boolean = false;

  isWidgetsPanelVisible: boolean = false;
  cdkConnectionPairsWidgetsList: ConnectionPositionPair[] = [
    {
      offsetX: -14,
      offsetY: -22.5,
      originX: "start",
      originY: "top",
      overlayX: "end",
      overlayY: "top",
      panelClass: null,
    },
  ];

  constructor(
    private userService: UserService,
    private localStorageSvc: LocalStorageService,
    private projectSvc: ProjectService,
    private uiSvc: UiService,
    private dashboardSvc: DashboardService,
    private ts: TranslateService,
    private snackbarSvc: SnackbarService
  ) {
    this.currUser = this.userService.getCurrentUser();
    this.projectId = this.localStorageSvc.getProjectId();
  }

  ngOnInit(): void {
    this.dashboardSvc.setEditMode(false);
    this.uiSvc.show();
    this.projectSvc.get(this.projectId).subscribe((data) => {
      if (data?.users?.length > 0) {
        const userInProjectUser = data.users.find(
          ({ email, isBlocked, isActive }) =>
            email === this.currUser.email && !isBlocked && isActive
        );
        if (userInProjectUser) {
          this.isUserProjectMember = true;
          if (!userInProjectUser.dashboard) {
            this.saveDefaultDashboardCardsToProjectUser();
          } else {
            this.loadDefaultCards = false;
            this.isLoadingComplete = true;
            this.uiSvc.hide();
          }
        } else {
          this.isLoadingComplete = true;
          this.uiSvc.hide();
        }
      } else {
        this.isLoadingComplete = true;
        this.uiSvc.hide();
      }
    });
  }

  toggleProjectsFilterInput() {
    if (this.isEditing) return;
    this.showDashboardFilter = !this.showDashboardFilter;
  }

  applyFilter(filterValue: string) {
    return;
  }

  editMode() {
    this.isEditing = !this.isEditing;
    this.dashboardSvc.setEditMode(this.isEditing);
  }

  saveDefaultDashboardCardsToProjectUser() {
    let alert: string;
    this.dashboardSvc
      .saveCardViewForProjectUser(this.projectId, {
        dashboard: { overall: allOverallCards, me: allMeCards },
      })
      .subscribe({
        next: (data) => {
          if (data.status == "success") {
            this.isLoadingComplete = true;
          }
          this.uiSvc.hide();
        },
        error: (err) => {
          alert = this.ts.instant("dashboard.messages.defaultCardSavingFailed");
          this.snackbarSvc.errorSnackBar(alert);
          this.uiSvc.hide();
        },
      });
  }

  openWidgetOverlay() {
    this.isWidgetsPanelVisible = !this.isWidgetsPanelVisible;
  }
}
