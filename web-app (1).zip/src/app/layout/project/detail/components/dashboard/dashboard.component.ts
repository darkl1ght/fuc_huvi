import { Component, OnInit } from "@angular/core";
import { Project } from "src/app/core";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"],
})
export class DashboardComponent implements OnInit {
  project: Project = {} as Project;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.parent.data.subscribe((data) => {
      this.project = data.project;
    });

    // this.route.parent.data.subscribe((data: { project: Project }) => {
    //   if (data.project) {
    //     this.project = data.project;
    //   }
    // });
  }
}
