import { DashboardCard } from "src/app/core";

export const allOverallCards: DashboardCard[] = [
  {
    id: 1,
    label: "dashboard.overall.labels.completionTimeForTower",
    cols: 1,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "days-to-complete",
    order: 0,
    description: "dashboard.overall.messages.completionTimeVirtualTower",
    heading: null,
    category: "description",
  },
  {
    id: 2,
    label: "dashboard.overall.labels.punchlistItems",
    heading: "dashboard.overall.labels.punchlistItems",
    cols: 2,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "d3-bar",
    order: 2,
    description: "dashboard.overall.messages.punchlistItems",
    category: "bar_chart",
  },
  {
    id: 3,
    label: "dashboard.overall.labels.fieldIssueItems",
    heading: "dashboard.overall.labels.fieldIssueItems",
    cols: 1,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "d3-donut",
    order: 3,
    description: "dashboard.overall.messages.fieldIssueItems",
    category: "donut_chart",
  },
  {
    id: 4,
    label: "dashboard.overall.labels.latestAerialInterior",
    cols: 2,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "exterior-interior-latest",
    order: 1,
    description: "dashboard.overall.messages.latestAerialInterior",
    heading: null,
    category: "description",
  },
  {
    id: 5,
    label: "dashboard.overall.labels.allTasks",
    heading: "dashboard.overall.labels.allTasks",
    cols: 1,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "d3-donut",
    order: 4,
    description: "dashboard.overall.messages.allTaskCount",
    category: "donut_chart",
  },
  {
    id: 6,
    label: "dashboard.overall.labels.wirItems",
    heading: "dashboard.overall.labels.wirItems",
    cols: 1,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "d3-donut",
    order: 5,
    description: "dashboard.overall.messages.wirItems",
    category: "donut_chart",
  },
];

export const allMeCards: DashboardCard[] = [
  {
    id: 1,
    label: "dashboard.me.labels.allTaskCount",
    heading: "dashboard.me.labels.myTasks",
    cols: 1,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "d3-donut",
    order: 0,
    description: "dashboard.me.messages.allTaskCount",
    category: "donut_chart",
  },
  {
    id: 2,
    label: "dashboard.me.labels.myTasksList",
    heading: "dashboard.me.labels.myTasksList",
    options: {
      listType: { rfi: true, fieldIssue: true, punchlist: true },
      displayedColumns: ["icon", "description"],
    },
    cols: 2,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "task-list",
    order: 1,
    description: "dashboard.me.messages.myTasksList",
    category: "format_list_bulleted",
  },
  {
    id: 3,
    label: "dashboard.me.labels.myInspections",
    heading: "dashboard.me.labels.myInspections",
    options: {
      listType: { rfi: true },
      displayedColumns: ["icon", "description"],
    },
    cols: 2,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "task-list",
    order: 2,
    description: "dashboard.me.messages.myInspections",
    category: "format_list_bulleted",
  },
  {
    id: 4,
    label: "dashboard.me.labels.myFieldIssues",
    heading: "dashboard.me.labels.myFieldIssues",
    options: {
      listType: { fieldIssue: true },
      displayedColumns: ["icon", "description"],
    },
    cols: 2,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "task-list",
    order: 3,
    description: "dashboard.me.messages.myFieldIssues",
    category: "format_list_bulleted",
  },
  {
    id: 5,
    label: "dashboard.me.labels.myPunchlist",
    heading: "dashboard.me.labels.myPunchlist",
    options: {
      listType: { punchlist: true },
      displayedColumns: ["icon", "description"],
    },
    cols: 2,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "task-list",
    order: 4,
    description: "dashboard.me.messages.myPunchlist",
    category: "format_list_bulleted",
  },
  {
    id: 6,
    label: "dashboard.me.labels.wirItems",
    heading: "dashboard.me.labels.wirItems",
    cols: 1,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "d3-donut",
    order: 5,
    description: "dashboard.me.messages.wirItems",
    category: "donut_chart",
  },
  {
    id: 7,
    label: "dashboard.me.labels.fieldIssueItems",
    heading: "dashboard.me.labels.fieldIssueItems",
    cols: 1,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "d3-donut",
    order: 6,
    description: "dashboard.me.messages.fieldIssueItems",
    category: "donut_chart",
  },
  {
    id: 8,
    label: "dashboard.me.labels.punchlistItems",
    heading: "dashboard.me.labels.punchlistItems",
    cols: 2,
    rows: 2,
    backgroundColor: "#fff",
    enabled: true,
    type: "d3-bar",
    order: 7,
    description: "dashboard.me.messages.punchlistItems",
    category: "bar_chart",
  },
];

export const dragSvgIcon = `<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 96 960 960" width="24">
<path d="M480 976 310 806l57-57 73 73V616l-205-1 73 73-58 58L80 576l169-169 57 57-72 72h206V330l-73 73-57-57 170-170 170 170-57 57-73-73v206l205 1-73-73 58-58 170 170-170 170-57-57 73-73H520l-1 205 73-73 58 58-170 170Z"/>
</svg>`;

export const fieldIssueIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="25" height="23" viewBox="0 0 25 23" fill="none">
<path d="M10.8603 0.62485C11.7659 -0.208285 13.2341 -0.208282 14.1397 0.624851L24.3208 9.99148C25.2264 10.8246 25.2264 12.1754 24.3208 13.0085L14.1397 22.3752C13.2341 23.2083 11.7659 23.2083 10.8603 22.3751L0.679185 13.0085C-0.226396 12.1754 -0.226394 10.8246 0.679186 9.99148L10.8603 0.62485ZM13.0466 1.63053C12.7447 1.35282 12.2553 1.35282 11.9534 1.63053L1.77232 10.9972C1.47046 11.2749 1.47046 11.7251 1.77232 12.0028L11.9534 21.3695C12.2553 21.6472 12.7447 21.6472 13.0466 21.3695L23.2277 12.0028C23.5295 11.7251 23.5295 11.2749 23.2277 10.9972L13.0466 1.63053Z" fill="#2D4059"/>
<path d="M10.9399 15.8125C10.9399 15.0186 11.6395 14.375 12.5024 14.375C13.3654 14.375 14.0649 15.0186 14.0649 15.8125C14.0649 16.6064 13.3654 17.25 12.5024 17.25C11.6395 17.25 10.9399 16.6064 10.9399 15.8125Z" fill="#2D4059"/>
<path d="M11.093 7.18037C11.0097 6.41453 11.6634 5.75 12.5 5.75C13.3366 5.75 13.9903 6.41453 13.907 7.18037L13.359 12.2223C13.3149 12.6283 12.9435 12.9375 12.5 12.9375C12.0565 12.9375 11.6851 12.6283 11.641 12.2223L11.093 7.18037Z" fill="#2D4059"/>
</svg>`;

export const rfiIcon = `<svg width="20" height="12" viewBox="0 0 20 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="0.5" y="0.5" width="19" height="11" rx="2.5" fill="white" stroke="#7D7D7D"/>
<path d="M7.552 9L6.224 6.72H5.344V9H4.616V3.424H6.416C6.83733 3.424 7.192 3.496 7.48 3.64C7.77333 3.784 7.992 3.97867 8.136 4.224C8.28 4.46933 8.352 4.74933 8.352 5.064C8.352 5.448 8.24 5.78667 8.016 6.08C7.79733 6.37333 7.46667 6.568 7.024 6.664L8.424 9H7.552ZM5.344 6.136H6.416C6.81067 6.136 7.10667 6.04 7.304 5.848C7.50133 5.65067 7.6 5.38933 7.6 5.064C7.6 4.73333 7.50133 4.47733 7.304 4.296C7.112 4.11467 6.816 4.024 6.416 4.024H5.344V6.136ZM12.5152 3.424V4.016H10.0912V5.896H12.0592V6.488H10.0912V9H9.36319V3.424H12.5152ZM14.0024 3.424V9H13.2744V3.424H14.0024Z" fill="#7D7D7D"/>
</svg>`;

export const punchlistIcon = `<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
<path d="M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q65 0 123 19t107 53l-58 59q-38-24-81-37.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160q133 0 226.5-93.5T800-480q0-18-2-36t-6-35l65-65q11 32 17 66t6 70q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm-56-216L254-466l56-56 114 114 400-401 56 56-456 457Z"/>
</svg>`;
