import { Component, Input, OnInit, AfterViewInit } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import {
  DashboardCard,
  DashboardService,
  LocalStorageService,
  ProjectService,
  SnackbarService,
  UiService,
  UserService,
} from "src/app/core";

@Component({
  selector: "app-widget-list",
  templateUrl: "./widget-list.component.html",
  styleUrls: ["./widget-list.component.scss"],
})
export class WidgetListComponent implements OnInit, AfterViewInit {
  @Input() selectedTab!: number;

  currUser: any;
  projectId: any;
  widgets: DashboardCard[] = [];

  constructor(
    private uiSvc: UiService,
    private ts: TranslateService,
    private snackbarSvc: SnackbarService,
    private userService: UserService,
    private projectSvc: ProjectService,
    private localStorageSvc: LocalStorageService,
    private dashboardSvc: DashboardService
  ) {
    this.currUser = this.userService.getCurrentUser();
    this.projectId = this.localStorageSvc.getProjectId();
  }

  ngOnInit() {}

  ngAfterViewInit(): void {
    this.getProjectDetails();
  }

  toggleWidget(card: DashboardCard) {
    this.dashboardSvc.toggleCard(structuredClone(card));
    card.enabled = !card.enabled;
  }

  getProjectDetails() {
    this.uiSvc.show();
    this.projectSvc.get(this.projectId).subscribe(({ users }) => {
      if (users?.length > 0) {
        const userInProjectUser = users.find(
          ({ email, isBlocked, isActive }) =>
            email === this.currUser.email && !isBlocked && isActive
        );
        if (userInProjectUser) {
          if (this.selectedTab === 0) {
            this.widgets = [...userInProjectUser.dashboard.overall];
          } else if (this.selectedTab === 1) {
            this.widgets = [...userInProjectUser.dashboard.me];
          }
        } else {
          // edge case
          // when user access has been revoked from project
          let alert = this.ts.instant(
            "dashboard.overall.messages.noUserAccess"
          );
          this.snackbarSvc.errorSnackBar(alert);
        }
      }
      this.uiSvc.hide();
    });
  }
}
