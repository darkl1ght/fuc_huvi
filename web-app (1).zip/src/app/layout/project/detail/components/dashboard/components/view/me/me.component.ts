import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  Input,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChildren,
} from "@angular/core";
import {
  CdkDropList,
  CdkDragEnter,
  moveItemInArray,
} from "@angular/cdk/drag-drop";

import {
  allMeCards,
  dragSvgIcon,
  fieldIssueIcon,
  punchlistIcon,
  rfiIcon,
} from "../dashboard.card.data";
import { MatIcon, MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import {
  DashboardService,
  LocalStorageService,
  ProjectService,
  UiService,
  User,
  UserService,
  DashboardCard,
  SnackbarService,
  ITask,
} from "src/app/core";
import { Subscription, of } from "rxjs";
import { map, mergeMap } from "rxjs/operators";
import { TranslateService } from "@ngx-translate/core";
import { MatDialog } from "@angular/material/dialog";
import { TaskListComponent } from "./task-list/task-list.component";

@Component({
  selector: "d-me",
  templateUrl: "./me.component.html",
  styleUrls: ["./me.component.scss"],
})
export class DMeComponent implements AfterViewInit, OnInit, OnDestroy {
  @Input() loadDefaultCards: boolean;
  @ViewChildren(CdkDropList) dropsQuery: QueryList<CdkDropList>;

  currUser: User;

  drops: CdkDropList[];
  allCards: DashboardCard[] = [];
  enabledCards: DashboardCard[] = [] as DashboardCard[];
  disabledCards: DashboardCard[] = [] as DashboardCard[];
  editModeOn: boolean = false;

  showEditButton: boolean = false;
  projectId!: string;
  errors: any = null;
  towerList: { towerName: string; towerId: string }[] = [];
  isDayCardContentLoading: boolean = false;
  selectedTowerForDaysToSelectCard: string;
  dayToCompleteCardContent: string = "";
  dayToCompleteCardResponseCode: string = "";
  dayToCompletePercentageCardContent: number = 0;
  dashboardSubscription: Subscription;
  editModeSubs: Subscription;
  toggleCardSubs: Subscription;
  allTaskStatusColors: any = {};
  itemOrderChanged: boolean = false;

  tourLabel: string;
  tourType: string;
  tourDate: any;
  fieldIssueStatusColors: {
    open: string;
    resolved: string;
    verified: string;
    archived: string;
  };
  rfiStatusColors: { pending: string; approved: string; new: string };
  punchlistStatusColors: {
    accepted: string;
    pending_verification: string;
    not_accepted: string;
    conditionally_accepted: string;
  };

  constructor(
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer,
    private localStorageSvc: LocalStorageService,
    private dashboardSvc: DashboardService,
    private userService: UserService,
    private projectSvc: ProjectService,
    private uiSvc: UiService,
    private ts: TranslateService,
    private cdr: ChangeDetectorRef,
    private snackbarSvc: SnackbarService,
    public dialog: MatDialog
  ) {
    this.currUser = this.userService.getCurrentUser();
    this.projectId = this.localStorageSvc.getProjectId();
    this.addSvgIcons(iconRegistry, sanitizer);
  }

  ngAfterViewInit() {
    this.dropsQuery.changes.subscribe(() => {
      this.drops = this.dropsQuery.toArray();
      this.cdr.detectChanges();
    });
  }

  ngOnInit() {
    this.editModeSubs = this.dashboardSvc.isEditMode$.subscribe((data) => {
      this.editModeOn = data;
      if (this.itemOrderChanged && !this.editModeOn) {
        this.saveMeCardOrder();
      }
    });
    this.toggleCardSubs = this.dashboardSvc.cardToToggle$.subscribe(
      (cardFromWidget) => {
        if (cardFromWidget?.id) {
          let matchedCard = this.allCards.find(
            ({ id }) => id == cardFromWidget.id
          );
          this.toggleCard(matchedCard);
        }
      }
    );
    this.setAllCards();
  }

  toggleCard(card: DashboardCard) {
    if (card) {
      card.enabled = !card.enabled;
      this.filterCards();
      this.changeItemOrder();
      this.loadCardsData();
      this.saveMeCardOrder();
    }
  }

  addSvgIcons(iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
    iconRegistry.addSvgIconLiteral(
      "dragSvgIcon",
      sanitizer.bypassSecurityTrustHtml(dragSvgIcon)
    );
    iconRegistry.addSvgIconLiteral(
      "fieldIssue",
      sanitizer.bypassSecurityTrustHtml(fieldIssueIcon)
    );
    iconRegistry.addSvgIconLiteral(
      "rfi",
      sanitizer.bypassSecurityTrustHtml(rfiIcon)
    );
    iconRegistry.addSvgIconLiteral(
      "punchlist",
      sanitizer.bypassSecurityTrustHtml(punchlistIcon)
    );
  }

  setAllCards() {
    if (!this.loadDefaultCards) {
      this.uiSvc.show();
      this.projectSvc.get(this.projectId).subscribe((data) => {
        if (data?.users?.length > 0) {
          const userInProjectUser = data.users.find(
            ({ email, isBlocked, isActive }) =>
              email === this.currUser.email && !isBlocked && isActive
          );
          if (userInProjectUser) {
            this.allCards = [...userInProjectUser.dashboard.me];
            this.filterCards();
            this.loadCardsData();
          } else {
            // edge case
            // when user access has been revoked from project
            let alert = this.ts.instant("dashboard.me.messages.noUserAccess");
            this.snackbarSvc.errorSnackBar(alert);
          }
        }
        this.uiSvc.hide();
      });
    } else {
      this.allCards = [...allMeCards];
      this.filterCards();
      this.loadCardsData();
    }
  }

  filterCards() {
    this.enabledCards = this.allCards
      .filter(({ enabled }) => enabled)
      .map((card) => ({ ...card, isLoading: true }))
      .sort((a, b) => a.order - b.order);
    this.disabledCards = this.allCards.filter(({ enabled }) => !enabled);
  }

  entered($event: CdkDragEnter) {
    moveItemInArray(this.enabledCards, $event.item.data, $event.container.data);
    this.changeItemOrder();
  }

  changeItemOrder() {
    this.enabledCards.map((card, index) => (card.order = index));
    this.itemOrderChanged = true;
  }

  loadCardsData() {
    this.dashboardSubscription?.unsubscribe();
    const observables = [];
    for (let card of this.enabledCards) {
      switch (card.type) {
        case "d3-donut":
          if (card.id == 1) {
            observables.push(
              this.dashboardSvc
                .getD3DonutTasksChart(this.projectId, "user")
                .pipe(map((data) => ({ card, data })))
            );
          } else if (card.id == 6) {
            observables.push(
              this.dashboardSvc
                .getD3TaskChartAssigned(
                  this.projectId,
                  "rfi",
                  card.type.split("-").pop(),
                  "user"
                )
                .pipe(map((data) => ({ card, data })))
            );
          } else if (card.id == 7) {
            observables.push(
              this.dashboardSvc
                .getD3TaskChartAssigned(
                  this.projectId,
                  "fieldissue",
                  card.category.split("_")[0],
                  "user"
                )
                .pipe(map((data) => ({ card, data })))
            );
          }
          break;
        case "task-list":
          observables.push(
            this.dashboardSvc
              .getAllTasksList(this.projectId, card.options.listType)
              .pipe(map((data) => ({ card, data })))
          );
          break;
        case "d3-pie":
          if (card.id == 7) {
            observables.push(
              this.dashboardSvc
                .getD3TaskChartAssigned(
                  this.projectId,
                  "fieldissue",
                  card.type.split("-").pop(),
                  "user"
                )
                .pipe(map((data) => ({ card, data })))
            );
          }
          break;
        case "d3-bar":
          if (card.id == 8) {
            observables.push(
              this.dashboardSvc
                .getD3TaskChartAssigned(
                  this.projectId,
                  "punchlist",
                  card.type.split("-").pop(),
                  "user"
                )
                .pipe(map((data) => ({ card, data })))
            );
          }
          break;
      }
    }
    const dashboardData$ = of(...observables).pipe(mergeMap((obs) => obs));

    this.dashboardSubscription = dashboardData$.subscribe({
      next: ({ data, card }: { data: any; card: DashboardCard }) => {
        // Update the corresponding card on the dashboard with the received data
        switch (card.type) {
          case "d3-donut":
            this.loadDonutCard(data, card);
            break;
          case "d3-bar":
            this.loadBarCard(data, card);
            break;
          case "d3-pie":
            this.loadDonutCard(data, card);
            break;
          case "task-list":
            this.loadListCard(data, card);
            break;
        }
      },
      error: (error) => {
        this.errors =
          "Uh oh! There was a problem loading this Card. Please refresh the page and try again.";
      },
    });
  }

  stopCardLoading(card: DashboardCard) {
    card.isLoading &&
      (this.enabledCards.find(({ id }) => card.id === id)!.isLoading = false);
  }

  saveMeCardOrder() {
    this.uiSvc.show();
    const enabledCardCopy: DashboardCard[] = JSON.parse(
      JSON.stringify(this.enabledCards)
    );

    const allMeCards = [];
    for (let card of enabledCardCopy) {
      const cardCopy = { ...card };
      delete cardCopy.isLoading;
      delete cardCopy._temp;
      allMeCards.push(cardCopy);
    }
    allMeCards.push(...this.disabledCards);
    this.dashboardSvc
      .saveCardViewForProjectUser(this.projectId, {
        dashboard: { me: allMeCards },
      })
      .subscribe({
        next: (data) => {
          if (data.status == "success") {
            this.itemOrderChanged = false;
          }
          this.uiSvc.hide();
        },
        error: (err) => {
          let alert = this.ts.instant(
            "dashboard.me.messages.cardOrderSavingFailed"
          );
          this.snackbarSvc.errorSnackBar(alert);
          this.uiSvc.hide();
        },
      });
  }

  loadDonutCard(data: any, card: DashboardCard) {
    let colors;
    if (card.id === 1) {
      this.allTaskStatusColors = {
        pending: "#FFA825",
        completed: "#7AC142",
        overdue: "#FF0000",
      };
    } else if (card.id === 7) {
      this.fieldIssueStatusColors = {
        open: "#FF0000",
        resolved: "#FFA500",
        verified: "#008000",
        archived: "#F8F801",
      };
    } else if (card.id === 6) {
      this.rfiStatusColors = {
        pending: "#FFA825",
        approved: "#7AC142",
        new: "#FF0000",
      };
    }
    if (card.id == 1) {
      colors = this.allTaskStatusColors;
    } else if (card.id == 6) {
      colors = this.rfiStatusColors;
    } else if (card.id == 7) {
      colors = this.fieldIssueStatusColors;
    }

    let mappedLabels = [];
    for (let ele of data) {
      if (ele.count) {
        mappedLabels.push({
          title: this.ts.instant(`dashboard.labels.${ele.label.toLowerCase()}`),
          color: colors[ele.label.toLowerCase()],
          count: ele.count,
        });
      }
    }
    const donutCard = this.enabledCards.find(({ id }) => id === card.id);
    if (donutCard) {
      if (mappedLabels.length) {
        donutCard._temp = {
          labels: mappedLabels,
          chartData: mappedLabels,
          noDataFound: false,
        };
      } else {
        donutCard._temp = {
          noDataFound: true,
        };
      }

      this.stopCardLoading(card);
    }
  }

  loadBarCard(data: any, card: DashboardCard) {
    let colors = (this.punchlistStatusColors = {
      accepted: "#7AC142",
      pending_verification: "#F8F801",
      not_accepted: "#FF0000",
      conditionally_accepted: "#FF8800",
    });

    let mappedLabels = [];
    for (let ele of data) {
      if (ele.value) {
        mappedLabels.push({
          name: this.ts.instant(`dashboard.labels.${ele.name.toLowerCase()}`),
          color: colors[ele.name.toLowerCase()],
          value: ele.value,
        });
      }
    }
    const barCard = this.enabledCards.find(({ id }) => id === card.id);
    if (barCard) {
      if (mappedLabels.length) {
        barCard._temp = {
          labels: mappedLabels,
          chartData: mappedLabels,
          noDataFound: false,
        };
      } else {
        barCard._temp = { noDataFound: true };
      }
      barCard && this.stopCardLoading(card);
    }
  }

  loadListCard(
    data: { rfiList?: ITask[]; fieldIssueList?: ITask[]; punchlist?: ITask[] },
    card: DashboardCard
  ) {
    const taskCard = this.enabledCards.find(({ id }) => id === card.id);
    if (taskCard) {
      taskCard._temp = {};
      const taskList: ITask[] = [];
      if (taskCard.options?.listType?.rfi && data.rfiList?.length > 0) {
        const iconMappedRfi = [
          ...data.rfiList.map((el) => ({ ...el, type: "rfi" })),
        ];
        taskList.push(...iconMappedRfi);
      }
      if (
        taskCard.options?.listType?.fieldIssue &&
        data.fieldIssueList?.length > 0
      ) {
        const iconMappedFieldIssue = [
          ...data.fieldIssueList.map((el) => ({
            ...el,
            type: "fieldIssue",
          })),
        ];
        taskList.push(...iconMappedFieldIssue);
      }
      if (taskCard.options?.listType?.punchlist && data.punchlist?.length > 0) {
        const iconMappedPunchlist = [
          ...data.punchlist.map((el) => ({
            ...el,
            type: "punchlist",
          })),
        ];
        taskList.push(...iconMappedPunchlist);
      }

      if (taskList.length > 0) {
        taskCard._temp = {
          dataSource: taskList.slice(0, 4),
          list: taskList,
        };
      } else {
        taskCard._temp = {
          noItemsFound: this.ts.instant("dashboard.me.messages.noDataFound"),
        };
      }
      this.stopCardLoading(card);
    }
  }

  showAllTasks(heading: string, taskList: ITask[]) {
    this.dialog.open(TaskListComponent, {
      width: "55%",
      data: {
        heading,
        taskList,
      },
    });
  }

  getChartId(card: any): string {
    return `chart_${card.id}_${card._temp?.chartType}`;
  }

  ngOnDestroy(): void {
    this.dashboardSvc.toggleCard(null);
    this.editModeSubs.unsubscribe();
    this.dashboardSubscription.unsubscribe();
    this.toggleCardSubs.unsubscribe();
  }
}
