import { NgModule } from "@angular/core";
import { SharedModule } from "src/app/shared";
import { DashboardComponent } from "./dashboard.component";
import { DashboardRoutingModule } from "./dashboard-routing.module";
import { ViewComponent } from "./components/view/view.component";
import { DOverallComponent } from "./components/view/overall/overall.component";
import { DMeComponent } from "./components/view/me/me.component";
import { TaskListComponent } from './components/view/me/task-list/task-list.component';
import { WidgetListComponent } from './components/view/widget-list/widget-list.component';

@NgModule({
  declarations: [
    ViewComponent,
    DashboardComponent,
    DOverallComponent,
    DMeComponent,
    TaskListComponent,
    WidgetListComponent,
  ],
  imports: [DashboardRoutingModule, SharedModule],
})
export class DashboardModule {}
