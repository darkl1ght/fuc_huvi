import { NgModule } from "@angular/core";
import { SharedModule } from "src/app/shared";
import { DocumentRoutingModule } from "./document-routing.module";
import { NewDocumentComponent } from "./components/new/new-document.component";
import { DocumentListComponent } from "./components/list/document-list.component";
import { DocumentComponent } from "./document.component";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { DocumentHistoryComponent } from "./components/history/document-history.component";
import { DocumentTagComponent } from "./components/tag/document-tag.component";
import { PdfViewerModule } from "ng2-pdf-viewer";
import { DocumentViewerComponent } from "./components/viewer/viewer.component";

@NgModule({
  imports: [DocumentRoutingModule, SharedModule, PdfViewerModule],
  declarations: [
    NewDocumentComponent,
    DocumentListComponent,
    DocumentHistoryComponent,
    DocumentTagComponent,
    DocumentViewerComponent,
    DocumentComponent,
  ],
  providers: [
    { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} },
  ],
})
export class DocumentModule {}
