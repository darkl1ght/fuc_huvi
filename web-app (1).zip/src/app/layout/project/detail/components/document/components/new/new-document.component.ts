import { Component, OnInit, Inject } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  DocumentService,
  DocumentDialogData,
  Document,
  Guid,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";
import { take, tap } from "rxjs/operators";

@Component({
  selector: "new-activity",
  templateUrl: "./new-document.component.html",
  styleUrls: ["./new-document.component.scss"],
})
export class NewDocumentComponent implements OnInit {
  public documentName: string = "";
  public documentDate: Date = new Date();
  document: Document = {} as Document;
  errors = {};
  projectId: string;
  accessToken: string;
  filesSelected: boolean = false;
  uploadInProgress: boolean = false;
  progressInfos: any[] = [];

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: DocumentDialogData,
    private docService: DocumentService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  public ngOnInit(): void {
    this.getToken();
    this.document = this.data.document;
    this.projectId = this.data.projectId;
  }

  onFileChange(event: any): void {
    let alert = "";
    if (this.document && this.document.documentId && event.length > 1) {
      alert = this.ts.instant("document.new.messages.uploadErrorFileCount");
      this.snackService.errorSnackBar(alert);
      return;
    }
    this.progressInfos = [];
    this.filesSelected = true;
    let i;
    for (i = 0; i < event.length; ++i) {
      const file = event[i];
      this.progressInfos[i] = { value: 0, fileName: file.name };
      const extn = file.name.split(".").pop();
      if (this.isNotDocument(extn)) {
        this.dialog.closeAll();
        const alert = this.ts.instant(
          "document.new.messages.extensionNotAllowed"
        );
        this.snackService.errorSnackBar(alert);
        break;
      }
    }
    if (i == event.length) this.uploadFiles(event);
  }

  isNotDocument(extn: string) {
    switch (extn) {
      case "exe":
      case "msi":
      case "hta":
      case "cpl":
      case "jar":
      case "bat":
      case "cmd":
      case "js":
        return true;
    }
    return false;
  }

  isDocument(extn: string) {
    switch (extn) {
      // documents
      case "docx":
      case "xlsx":
      case "pdf":
      case "doc":
      case "xls":
      case "xls":
      case "txt":
      case "odt":
      case "ppt":
      case "pptx":
      case "rtf":
      // images
      case "jpg":
      case "jpeg":
      case "gif":
      case "bmp":
      case "tif":
      case "tiff":
      case "png":
      // videos
      case "m4v":
      case "avi":
      case "mpg":
      case "mpeg":
      case "mp4":
      case "flv":
      case "f4v":
      case "mov":
      // misc
      case "kml":
      case "xml":
      case "geojson":
      case "csv":
      // zipped
      case "zip":
      case "rar":
        return true;
    }
    return false;
  }

  async uploadFiles(files) {
    let alert;
    this.uploadInProgress = true;
    try {
      const blobServiceClient = new BlobServiceClient(
        this.config.blobUrl + "/?" + this.accessToken
      );
      const containerClient = blobServiceClient.getContainerClient(
        this.config.documentContainer
      );
      const promises = [];
      for (let index = 0; index < files.length; ++index) {
        const file = files[index];
        this.progressInfos[index] = { value: 0, fileName: file.name };

        const fileName = file.name;
        const extn = file.name.split(".").pop();
        const docId = Guid.newGuid() + "." + extn;
        let _size = file.size;
        const fSExt = new Array("Bytes", "KB", "MB", "GB");
        let i = 0;
        while (_size > 900) {
          _size /= 1024;
          i++;
        }
        const documentSize = Math.round(_size * 100) / 100 + " " + fSExt[i];

        const blockBlobClient = containerClient.getBlockBlobClient(docId);
        promises.push(
          blockBlobClient.uploadBrowserData(file, {
            blockSize: 4 * 1024 * 1024, // 4MB block size
            concurrency: 20, // 20 concurrency
            onProgress: (ev) => {
              this.progressInfos[index].value = Math.round(
                (100 * ev.loadedBytes) / file.size
              );
              if (ev.loadedBytes === file.size) {
                this.updateDocumentDetail(docId, fileName, documentSize);
              }
            },
            blobHTTPHeaders: { blobContentType: file.type },
          })
        );
      }

      await Promise.all(promises);
      alert = this.ts.instant("document.new.messages.uploadSuccess");
      this.snackService.successSnackBar(alert);
      this.uploadInProgress = false;
      this.closeDialog();
    } catch (error) {
      alert = this.ts.instant("document.new.messages.uploadFailed");
      this.snackService.errorSnackBar(alert);
    }
  }

  getToken() {
    const container = this.config.documentContainer;
    this.docService.getToken(container).subscribe(
      (data) => {
        this.accessToken = data.sasToken.token;
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  private updateDocumentDetail(
    docBlobId: string,
    docName: string,
    size: string
  ) {
    const doc: Document = {} as Document;

    if (this.document && this.document.documentId) {
      doc.documentId = this.document.documentId;
    }
    doc.blobDocId = docBlobId;
    doc.name = docName;
    doc.size = size;

    this.docService
      .save(this.projectId, doc)
      .pipe(
        take(1),
        tap((data) => {
          return;
        })
      )
      .subscribe();
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
