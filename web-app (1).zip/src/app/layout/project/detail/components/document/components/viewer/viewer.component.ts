import { Component, OnInit, Inject } from "@angular/core";
import {
  UiService,
  DocumentService,
  Document,
  SnackbarService,
} from "src/app/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";
import { TranslateService } from "@ngx-translate/core";
const FileSaver = require("file-saver");

@Component({
  selector: "app-viewer",
  templateUrl: "./viewer.component.html",
  styleUrls: ["./viewer.component.scss"],
})
export class DocumentViewerComponent implements OnInit {
  url: string;
  accessToken: string;
  errors: any;
  document: Document;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private docService: DocumentService,
    private uiService: UiService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private ts: TranslateService,
    private snackService: SnackbarService
  ) {}

  ngOnInit(): void {
    this.uiService.show();
    this.url = this.data.url;
    this.document = this.data.doc;
  }

  async downloadBlobContent() {
    this.uiService.show();
    const container = this.config.documentContainer;
    this.docService.getBlobToken(container, this.document.blobDocId).subscribe(
      async (data) => {
        this.accessToken = data.sasToken.token;
        const blobServiceClient = new BlobServiceClient(
          this.config.blobUrl + "/?" + this.accessToken
        );
        const containerClient = blobServiceClient.getContainerClient(
          this.config.documentContainer
        );
        const blockBlobClient = containerClient.getBlockBlobClient(
          this.document.blobDocId
        );
        const downloadBlockBlobResponse = await blockBlobClient.download(0);
        const downloaded = await downloadBlockBlobResponse.blobBody;
        FileSaver.saveAs(downloaded, this.document.name);
        this.uiService.hide();
        const alert = this.ts.instant(
          "document.viewer.messages.downloadSuccess"
        );
        this.snackService.successSnackBar(alert);
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
        const alert = this.ts.instant("document.viewer.messages.downloadFail");
        this.snackService.errorSnackBar(alert);
      }
    );
  }

  pageRendered() {
    this.uiService.hide();
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
