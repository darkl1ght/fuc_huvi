import {
  Component,
  OnInit,
  ViewChild,
  Inject,
  ElementRef,
} from "@angular/core";
import { UntypedFormControl } from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  LookUpService,
  DocumentService,
  DocumentDialogData,
  Document,
  SnackbarService,
  Lookup,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { COMMA, ENTER } from "@angular/cdk/keycodes";
import { Observable } from "rxjs/internal/Observable";
import { startWith, map, take, tap, catchError } from "rxjs/operators";
import { MatChipInputEvent } from "@angular/material/chips";
import {
  MatAutocompleteSelectedEvent,
  MatAutocomplete,
} from "@angular/material/autocomplete";
import { empty } from "rxjs";

@Component({
  selector: "document-tag",
  templateUrl: "./document-tag.component.html",
  styleUrls: ["./document-tag.component.scss"],
})
export class DocumentTagComponent implements OnInit {
  document: Document = {} as Document;
  history = [];
  errors = {};
  dataSource: any;
  columnHeader: any;
  projectId: string;
  accessToken: string;
  documentTags: Lookup[] = [];

  visible = true;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  tagCtrl = new UntypedFormControl();
  filteredTags: Observable<string[]>;
  tags: string[] = [];
  allTags: string[] = [];

  @ViewChild("tagInput") tagInput: ElementRef<HTMLInputElement>;
  @ViewChild("auto") matAutocomplete: MatAutocomplete;

  constructor(
    public dialog: MatDialog,
    private lookupSvc: LookUpService,
    @Inject(MAT_DIALOG_DATA) private data: DocumentDialogData,
    private docService: DocumentService,
    private snackService: SnackbarService,
    private ts: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  public ngOnInit(): void {
    this.document = this.data.document;
    this.projectId = this.data.projectId;
    this.setUpTagData(this.document);

    this.filteredTags = this.tagCtrl.valueChanges.pipe(
      startWith(null),
      map((fruit: string | null) =>
        fruit ? this._filter(fruit) : this.allTags.slice()
      )
    );
  }

  setUpTagData(document: Document) {
    document.tagList.forEach((tag) => {
      this.tags.push(tag);
    });
    this.lookupSvc.getAll("documentTag").subscribe(
      (data) => {
        data.forEach((lookup) => {
          this.allTags.push(lookup.value);
        });
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  saveDocumentTag() {
    let alert = "";
    const doc: Document = {} as Document;
    doc.tagList = this.tags;
    doc.documentId = this.document.documentId;

    this.docService
      .save(this.projectId, doc)
      .pipe(
        take(1),
        tap((data) => {
          alert = this.ts.instant("document.tag.messages.success");
          this.snackService.successSnackBar(alert);
        }),
        catchError((err, caught) => {
          alert = this.ts.instant("document.tag.messages.failed");
          this.snackService.successSnackBar(alert);
          return empty();
        })
      )
      .subscribe();
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || "").trim()) {
      this.tags.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = "";
    }

    this.tagCtrl.setValue(null);
    this.saveDocumentTag();
  }

  remove(fruit: string): void {
    const index = this.tags.indexOf(fruit);

    if (index >= 0) {
      this.tags.splice(index, 1);
    }

    this.saveDocumentTag();
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.tags.push(event.option.viewValue);
    this.tagInput.nativeElement.value = "";
    this.tagCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allTags.filter(
      (tag) => tag.toLowerCase().indexOf(filterValue) === 0
    );
  }
}
