import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import {
  Document,
  DocumentService,
  UiService,
  User,
  UserService,
  SnackbarService,
} from "src/app/core";
import { NewDocumentComponent } from "../new/new-document.component";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { ActivatedRoute } from "@angular/router";
import { MatPaginator } from "@angular/material/paginator";
import {
  ConfirmAlertComponent,
  ConfirmAlertModel,
} from "src/app/layout/components/confirm-alert/confirm-alert.component";
import { DocumentHistoryComponent } from "../history/document-history.component";
import { DocumentTagComponent } from "../tag/document-tag.component";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";
import { DocumentViewerComponent } from "../viewer/viewer.component";
import { TranslateService } from "@ngx-translate/core";
const FileSaver = require("file-saver");

@Component({
  selector: "new-document",
  templateUrl: "./document-list.component.html",
  styleUrls: ["./document-list.component.scss"],
})
export class DocumentListComponent implements OnInit {
  @ViewChild("discussionBar") sideNave: any;
  result: string = "";
  accessToken: string = "";
  projectId: string;
  dataSource: any;
  documents: Document[] = [];
  displayedColumns: string[] = [
    "name",
    "size",
    "updatedAt",
    "updatedBy",
    "action",
  ];
  @ViewChild(MatSort) sort: MatSort;
  errors = {};
  @ViewChild(MatPaginator) paginator: MatPaginator;
  currentUser: User;
  isDocumentListSearchOpen = false;
  isLoaded: boolean = false;
  hoveredRow = null;
  constructor(
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private uiService: UiService,
    private docService: DocumentService,
    private ts: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private snackService: SnackbarService,
    private userService: UserService
  ) {
    this.currentUser = this.userService.getCurrentUser();
    this.projectId =
      this.route.parent.parent.parent.snapshot.paramMap.get("projectId");
  }

  ngOnInit() {
    this.getDocumentData();
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(NewDocumentComponent, {
      width: "40%",
      disableClose: true,
      data: { projectId: this.projectId, document: undefined },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getDocumentData();
    });
  }

  updateDialog(document: Document): void {
    const dialogRef = this.dialog.open(NewDocumentComponent, {
      width: "450px",
      disableClose: true,
      data: { projectId: this.projectId, document: document },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getDocumentData();
    });
  }

  docHistory(document: Document): void {
    const dialogRef = this.dialog.open(DocumentHistoryComponent, {
      width: "55%",
      disableClose: true,
      data: { projectId: this.projectId, document: document },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getDocumentData();
    });
  }

  openDocTag(document: Document): void {
    const dialogRef = this.dialog.open(DocumentTagComponent, {
      width: "45%",
      position: { top: "4em" },
      disableClose: true,
      data: { projectId: this.projectId, document: document },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getDocumentData();
    });
  }

  openDocUpload(document: Document): void {
    const dialogRef = this.dialog.open(NewDocumentComponent, {
      width: "45%",
      position: { top: "4em" },
      disableClose: true,
      data: { projectId: this.projectId, document: document },
      panelClass: "dialog-box",
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.getDocumentData();
    });
  }

  getDocumentData() {
    this.uiService.show();
    this.docService.getDocuments(this.projectId).subscribe(
      (data) => {
        this.documents = data.documents;
        this.dataSource = new MatTableDataSource(this.documents);
        this.sortingDataAccessor(this.dataSource);
        this.dataSource.filterPredicate = (data, filter: string) => {
          return (
            data.name.toLocaleLowerCase().includes(filter) ||
            this.filterTags(data.tagList, filter).length > 0
          );
        };
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.isLoaded = true;
        this.uiService.hide();
      },
      (err) => {
        this.errors = err;
      }
    );
  }

  filterTags(array, filter) {
    if (array) {
      return array.filter(function (item) {
        return item.toLowerCase().includes(filter.toLowerCase());
      });
    } else {
      return false;
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  async downloadBlobContent(document) {
    this.uiService.show();
    const container = this.config.documentContainer;
    this.docService.getBlobToken(container, document.blobDocId).subscribe(
      async (data) => {
        this.accessToken = data.sasToken.token;
        const blobServiceClient = new BlobServiceClient(
          this.config.blobUrl + "/?" + this.accessToken
        );
        const containerClient = blobServiceClient.getContainerClient(
          this.config.documentContainer
        );
        const blockBlobClient = containerClient.getBlockBlobClient(
          document.blobDocId
        );
        const downloadBlockBlobResponse = await blockBlobClient.download(0);
        const downloaded = await downloadBlockBlobResponse.blobBody;
        FileSaver.saveAs(downloaded, document.name);
        this.uiService.hide();
        const alert = this.ts.instant("document.list.messages.downloadSuccess");
        this.snackService.successSnackBar(alert);
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
        const alert = this.ts.instant("document.list.messages.downloadFail");
        this.snackService.errorSnackBar(alert);
      }
    );
  }

  confirmDialog(document: Document): void {
    const message = this.ts.instant("dialog.messages.removeDocument");
    const successBtn = this.ts.instant("dialog.deleteBtn");
    const icon = "warning";
    const dialogData = new ConfirmAlertModel(
      this.ts.instant("dialog.confirmAction"),
      message,
      successBtn,
      icon
    );
    const dialogRef = this.dialog.open(ConfirmAlertComponent, {
      maxWidth: "400px",
      data: dialogData,
    });

    dialogRef.afterClosed().subscribe((dialogResult) => {
      this.result = dialogResult;
      if (this.result) {
        this.docService.destroy(this.projectId, document.documentId).subscribe(
          (data) => {
            const alert = this.ts.instant(
              "document.list.messages.removeSuccess"
            );
            this.snackService.successSnackBar(alert);
            this.getDocumentData();
          },
          (err) => {
            const alert = this.ts.instant(
              "document.list.messages.removeFailed"
            );
            this.snackService.errorSnackBar(alert);
            this.errors = err;
          }
        );
      }
    });
  }

  openDocument(document: Document) {
    let docUrl = "";
    const container = this.config.documentContainer;
    this.docService.getReadToken(container).subscribe(
      async (data) => {
        this.accessToken = data.sasToken.token;
        docUrl =
          this.config.blobUrl +
          "/" +
          container +
          "/" +
          document.blobDocId +
          "?" +
          this.accessToken;
        if (this.getExt(document.blobDocId) === "pdf") {
          this.openViewer(docUrl, document);
        } else {
          this.downloadBlobContent(document);
        }
      },
      (err) => {
        this.uiService.hide();
        this.errors = err;
      }
    );
  }

  openViewer(url, document): void {
    const dialogRef = this.dialog.open(DocumentViewerComponent, {
      width: "60%",
      position: { top: ".5em" },
      disableClose: true,
      data: { url: url, doc: document },
    });
  }

  sortingDataAccessor(dataSource) {
    dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        default:
          return item[property];
      }
    };
  }

  getExt(filename) {
    const dot_pos = filename.lastIndexOf(".");
    if (dot_pos == -1) {
      return "";
    }
    return filename.substr(dot_pos + 1).toLowerCase();
  }

  openDiscussion() {
    this.sideNave.toggle();
  }

  closeDiscussion() {
    this.sideNave.toggle();
  }

  toggleDocListSearchInput() {
    this.isDocumentListSearchOpen = !this.isDocumentListSearchOpen;
  }
}
