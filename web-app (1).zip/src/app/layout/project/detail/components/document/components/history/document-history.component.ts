import { Component, OnInit, ViewChild, Inject } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  DocumentService,
  DocumentDialogData,
  Document,
  SnackbarService,
} from "src/app/core";
import { TranslateService } from "@ngx-translate/core";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { BlobServiceClient } from "@azure/storage-blob";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { MatPaginator } from "@angular/material/paginator";
const FileSaver = require("file-saver");

@Component({
  selector: "document-history",
  templateUrl: "./document-history.component.html",
  styleUrls: ["./document-history.component.scss"],
})
export class DocumentHistoryComponent implements OnInit {
  public documentName: string = "";
  document: Document = {} as Document;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns: string[] = [
    "name",
    "size",
    "updatedAt",
    "lastUpdated",
    "action",
  ];
  history = [];
  errors = {};
  dataSource: any;
  columnHeader: any;
  projectId: string;
  accessToken: string;

  constructor(
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) private data: DocumentDialogData,
    private docService: DocumentService,
    private ts: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private snackService: SnackbarService
  ) {}

  public ngOnInit(): void {
    this.document = this.data.document;
    this.projectId = this.data.projectId;
    this.getDocuments(this.document);
  }

  async downloadBlobContent(document) {
    const container = this.config.documentContainer;
    this.docService.getBlobToken(container, document.blobDocId).subscribe(
      async (data) => {
        this.accessToken = data.sasToken.token;
        const blobServiceClient = new BlobServiceClient(
          this.config.blobUrl + "/?" + this.accessToken
        );
        const containerClient = blobServiceClient.getContainerClient(
          this.config.documentContainer
        );
        const blockBlobClient = containerClient.getBlockBlobClient(
          document.blobDocId
        );
        const downloadBlockBlobResponse = await blockBlobClient.download(0);
        const downloaded = await downloadBlockBlobResponse.blobBody;
        FileSaver.saveAs(downloaded, document.name);
        const alert = this.ts.instant(
          "document.history.messages.downloadSuccess"
        );
        this.snackService.successSnackBar(alert);
      },
      (err) => {
        this.errors = err;
        const alert = this.ts.instant("document.history.messages.downloadFail");
        this.snackService.errorSnackBar(alert);
      }
    );
  }

  getDocuments(document: Document) {
    //latest version  of the document
    this.history.push({
      blobDocId: document.blobDocId,
      name: document.name,
      size: document.size,
      lastUpdated: document.updatedBy,
      updatedAt: document.updatedAt,
    });

    this.document.history.forEach((version) => {
      this.history.push({
        blobDocId: version.blobDocId,
        name: version.name,
        size: version.size,
        lastUpdated: version.lastUpdated,
        updatedAt: version.updatedAt,
      });
    });

    this.dataSource = new MatTableDataSource(this.history);
    this.sortingDataAccessor(this.dataSource);
    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });

    this.columnHeader = {
      name: this.ts.instant("document.history.labels.name"),
      size: this.ts.instant("document.history.labels.size"),
      lastUpdated: this.ts.instant("document.history.labels.lastUpdated"),
      lastUpdatedBy: this.ts.instant("document.history.labels.lastUpdatedBy"),
    };
  }

  sortingDataAccessor(dataSource) {
    dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case "status.desc":
          return item.status ? item.status.desc : "";
        default:
          return item[property];
      }
    };
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }
}
