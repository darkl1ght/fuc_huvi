import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CallbackComponent } from "./callback/callback.component";
import { LayoutComponent } from "./layout.component";
import { AuthGuard, AdminGuard } from "../core";
import { ProfileComponent } from "./profile/profile.component";

const routes: Routes = [
  {
    path: "",
    component: LayoutComponent,
    children: [
      {
        pathMatch: "prefix",
        path: "",
        redirectTo: "project",
      },
      {
        path: "client",
        loadChildren: () =>
          import("./client/client.module").then((m) => m.ClientModule),
        canActivate: [AdminGuard],
      },
      {
        path: "project",
        loadChildren: () =>
          import("./project/project.module").then((m) => m.ProjectModule),
        canActivate: [AuthGuard],
      },
      {
        path: "profile",
        component: ProfileComponent,
        canActivate: [AuthGuard],
      },
      {
        path: "reports",
        loadChildren: () =>
          import("./report/report.module").then((m) => m.ReportModule),
        canActivate: [AdminGuard],
      },
      {
        path: "callback",
        component: CallbackComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LayoutRoutingModule {}
