import { isPlatformBrowser } from "@angular/common";
import { Component, Inject, OnInit, PLATFORM_ID } from "@angular/core";
import { NavigationEnd, Router } from "@angular/router";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { User, UserService } from "../core";
import { BreakpointObserver, Breakpoints } from "@angular/cdk/layout";
import { TranslateService } from "@ngx-translate/core";
import { SnackbarService } from "../core/snackbar/snackbar.service";
import { Platform } from "@angular/cdk/platform";
declare const ga: Function;

@Component({
  selector: "app-layout",
  templateUrl: "./layout.component.html",
  styleUrls: ["./layout.component.scss"],
})
export class LayoutComponent implements OnInit {
  private user: User;
  showHeader: boolean = true;
  showAppHeader: boolean = false;

  constructor(
    private userService: UserService,
    private _router: Router,
    @Inject(APP_CONFIG) private config: AppConfig,
    @Inject(PLATFORM_ID) private platformId: Object,
    private responsive: BreakpointObserver,
    private translate: TranslateService,
    private snackService: SnackbarService,
    private platform: Platform
  ) {
    this.responsive
      .observe([
        Breakpoints.Handset,
        Breakpoints.HandsetLandscape,
        Breakpoints.HandsetPortrait,
        Breakpoints.XSmall,
      ])
      .subscribe((result) => {
        if (result.matches) {
          this.snackService.openSnackBarWithErrorCustomDuration(
            !!this.platform.IOS
              ? this.translate.instant("general.messages.mobileDevice") +
                  this.translate.instant("general.messages.iOSMobileAppLink")
              : this.translate.instant("general.messages.mobileDevice") +
                  this.translate.instant(
                    "general.messages.androidMobileAppLink"
                  ),
            280000000
          );
        }
      });
    this.user = this.userService.getCurrentUser();

    this._router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        if (
          event.urlAfterRedirects.indexOf("/project/settings/") >= 0 ||
          event.urlAfterRedirects.indexOf("/project/report/") >= 0
        ) {
          this.showAppHeader = false;
        } else {
          this.showAppHeader = true;
        }
      }
    });
  }

  ngOnInit() {
    if (
      window !== window.top &&
      !this.config.topbarHideOverride.find((item) =>
        window.top.location.origin.includes(item)
      )
    ) {
      this.showHeader = false;
    }
  }
}
