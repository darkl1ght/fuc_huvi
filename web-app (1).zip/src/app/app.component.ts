import { Component, OnInit } from "@angular/core";

import {
  LocalStorageService,
  ProjectService,
  ShareService,
  User,
  UserService,
} from "./core";
import { TranslateService } from "@ngx-translate/core";
import { NavigationEnd, Router } from "@angular/router";
import { DataLayerService } from "./core/services/data-layer.service";
import { map } from "rxjs/internal/operators/map";
import { catchError } from "rxjs/internal/operators/catchError";
import { finalize } from "rxjs/internal/operators/finalize";
import { throwError } from "rxjs/internal/observable/throwError";
import { SnackbarService } from "./core/snackbar/snackbar.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
})
export class AppComponent implements OnInit {
  private currentRoute: string;
  private user: User;

  constructor(
    private userService: UserService,
    private projectSvc: ProjectService,
    private translate: TranslateService,
    private _router: Router,
    private localStorage: LocalStorageService,
    private shareService: ShareService,
    private _dataLayerService: DataLayerService,
    private snackService: SnackbarService
  ) {
    translate.setDefaultLang("en");
    this._router.events.subscribe((event) => {
      // subscribe to router events
      if (event instanceof NavigationEnd) {
        const shareId = this.localStorage.getShareId();
        if (!!shareId) {
          this.projectSvc
            .getShareInfo(shareId)
            .pipe(
              map(
                (data: any) => {
                  const shareInfo = data?.share;
                  if (!!shareInfo && shareInfo.isActive) {
                    const navigateUrl = this.getNavigationUrl(
                      shareInfo.moduleName,
                      shareInfo.shareInfo
                    );

                    if (!!navigateUrl) {
                      this.shareService.refreshToolbar(true);
                      this._router.navigateByUrl(navigateUrl);
                    } else {
                      this.localStorage.removeShareId();
                      this.shareService.setShareObject(null);
                      const alert = this.translate.instant(
                        "auth.messages.unauthorizedShareUrlMsg"
                      );
                      this.snackService.openSnackBarWithErrorCustomDuration(
                        alert,
                        280000000
                      );
                    }
                  } else {
                    this.localStorage.removeShareId();
                    this.shareService.setShareObject(null);
                    const alert = this.translate.instant(
                      "auth.messages.unauthorizedShareUrlMsg"
                    );
                    this.snackService.openSnackBarWithErrorCustomDuration(
                      alert,
                      280000000
                    );
                  }
                },
                (err: any) => {
                  console.log(err);
                }
              ),
              catchError(this.handleError),
              finalize(() => {})
            )
            .subscribe();
          //if our event is of our interest
          this._dataLayerService.logPageView(event.url); //call our dataLayer service's page view method to ping home with the url value.
        } else {
          //if our event is of our interest
          this._dataLayerService.logPageView(event.url); //call our dataLayer service's page view method to ping home with the url value.
        }
      }
    });
  }
  private handleError(error: any) {
    return throwError(error);
  }
  private getParameterByName(name: string, url?: string) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
  }

  private getNavigationUrl(moduleName: string, shareInfo: any) {
    const shareObject = !!shareInfo ? shareInfo : null;
    let navigateUrl = null;
    if (!!shareObject) {
      this.shareService.setShareObject(shareObject);
      const projectId = shareInfo.projectId;

      switch (moduleName.toLowerCase()) {
        case "interior":
          this.localStorage.setClientId(shareObject.clientId);
          this.localStorage.setProjectId(shareObject.projectId);
          navigateUrl = `/project/detail/${projectId}/interior/list`;
          break;

        case "media":
          this.localStorage.setClientId(shareObject.clientId);
          this.localStorage.setProjectId(shareObject.projectId);
          navigateUrl = `/project/detail/${projectId}/smartmedia/list`;
          break;

        case "library":
          this.localStorage.setClientId(shareObject.clientId);
          this.localStorage.setProjectId(shareObject.projectId);
          navigateUrl = `/project/detail/${projectId}/document/list`;
          break;

        case "exterior":
          this.localStorage.setClientId(shareObject.clientId);
          this.localStorage.setProjectId(shareObject.projectId);
          navigateUrl = `/project/detail/${projectId}/exterior/list`;
          break;
      }
    }
    return navigateUrl;
  }
  ngOnInit() {
    this.userService.populate();
  }
}
