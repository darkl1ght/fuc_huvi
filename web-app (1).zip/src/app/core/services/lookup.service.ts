import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { Lookup } from "../models/lookup.model";

@Injectable()
export class LookUpService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getAll(type): Observable<Lookup[]> {
    return this.apiService.get(this.config.lookup + type).pipe(
      map((data) => {
        return data["lookups"];
      })
    );
  }

  getPunchListIds(projectId): Observable<string[]> {
    return this.apiService
      .get(eval("`" + this.config.getPunchListIds + "`"))
      .pipe(
        map((data) => {
          return data["punchListId"];
        })
      );
  }
}
