import { Injectable } from "@angular/core";
import { UiService } from "./progress-bar.service";
import { ProjectService } from "./project.service";
import { LocalStorageService } from "./local-storage.service";
import { MatDialog } from "@angular/material/dialog";
import { ContractExpiryWidgetComponent } from "src/app/layout/project/detail/components/contract-expiry-widget/contract-expiry-widget.component";
import {
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  CanActivate,
} from "@angular/router";
import moment from "moment";

@Injectable({
  providedIn: "root",
})
export class ContractExpiryService implements CanActivate {
  projectId: any;

  constructor(
    private uiService: UiService,
    private dialog: MatDialog,
    private projectService: ProjectService,
    private localStorageService: LocalStorageService
  ) {}

  ngOnInit() {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    this.projectId = this.localStorageService.getProjectId();

    this.projectService.get(this.projectId).subscribe((projectDetails) => {
      const isCompleted = projectDetails.isCompleted;
      const contractEndDate = projectDetails.contractEndDate;
      const contractEndDateTemp = moment(contractEndDate);
      const today = moment().startOf("day");
      const dayDiff = contractEndDateTemp.diff(today, "day");

      if (dayDiff < 0 && !isCompleted) {
        this.openContractExpiryWidget();
      }
    });
    return true;
  }

  openContractExpiryWidget() {
    this.uiService.show();
    const dialogRef = this.dialog.open(ContractExpiryWidgetComponent, {
      maxWidth: "400px",
      height: "250px",
      panelClass: "modal-round-corner",
      disableClose: true,
      data: {},
    });

    dialogRef.afterClosed().subscribe(() => {
      this.uiService.hide();
    });
  }
}
