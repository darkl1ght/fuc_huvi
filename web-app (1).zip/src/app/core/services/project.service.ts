import { ProjectUsers } from "src/app/core";
import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { Project } from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class ProjectService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getProjects(): Observable<{ projects: Project[]; projectCount: number }> {
    return this.apiService.get(this.config.queryProjects);
  }

  createProjectAccess() {
    return this.apiService.get(this.config.createProjectAccess);
  }

  customLogoCheck() {
    return this.apiService.get(this.config.customLogoCheck);
  }

  getProjectsByClientId(clientId: string): Observable<{
    projects: Project[];
    projectCount: number;
  }> {
    return this.apiService.get(
      eval("`" + this.config.getProjectsByClientId + "`")
    );
  }

  get(projectId): Observable<Project> {
    return this.apiService
      .get(this.config.getProject + projectId)
      .pipe(map((data) => data.project));
  }

  getProjectUsers(projectId: string): Observable<ProjectUsers> {
    return this.apiService
      .get(eval("`" + this.config.getProjectUsers + "`"))
      .pipe(map((data) => data));
  }

  destroy(projectId) {
    return this.apiService.delete(this.config.deleteProject + projectId);
  }

  save(project): Observable<Project> {
    // If we're updating an existing project
    if (project.projectId) {
      return this.apiService
        .put(this.config.createProject + project.projectId, {
          project: project,
        })
        .pipe(map((data) => data.project));

      // Otherwise, create a new project
    } else {
      return this.apiService
        .post(this.config.createProject, { project: project })
        .pipe(map((data) => data.project));
    }
  }

  createProjectByClientId(project, clientId: string): Observable<Project> {
    if (project.projectId) {
      return this.apiService
        .put(this.config.createProject + project.projectId, {
          project: project,
        })
        .pipe(map((data) => data.project));
    } else {
      return this.apiService
        .post(eval("`" + this.config.createProjectByClientId + "`"), {
          project: project,
        })
        .pipe(map((data) => data.project));
    }
  }
  generateShareLink(
    moduleName: string,
    objectId: string,
    shareInfo: any
  ): Observable<{
    data: any;
  }> {
    return this.apiService
      .post(this.config.generateShareLink, {
        moduleName: moduleName,
        objectId: objectId,
        shareInfo: shareInfo,
      })
      .pipe(map((data) => data));
  }
  getShareInfo(shareId: string): Observable<{
    data: any;
  }> {
    return this.apiService.get(eval("`" + this.config.getShareInfo + "`"));
  }
}
