import { Inject, Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { delay, map } from "rxjs/operators";

import { ApiService } from "./api.service";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { DashboardCard } from "../models";

@Injectable({
  providedIn: "root",
})
export class DashboardService {
  private isEditMode = new BehaviorSubject(false);
  public isEditMode$ = this.isEditMode.asObservable();

  private cardToToggle = new BehaviorSubject({} as DashboardCard);
  public cardToToggle$ = this.cardToToggle.asObservable();

  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  setEditMode(value: boolean) {
    this.isEditMode.next(value);
  }

  toggleCard(card: DashboardCard | null) {
    this.cardToToggle.next(card);
  }

  saveCardViewForProjectUser(
    projectId: string,
    dashboardCards: {
      dashboard: { overall?: DashboardCard[]; me?: DashboardCard[] };
    }
  ): Observable<any> {
    if (projectId) {
      return this.apiService
        .put(
          eval("`" + this.config.updateCardViewProjectUser + "`"),
          dashboardCards
        )
        .pipe(map((data) => data));
    }
  }

  getDaysToComplete(projectId: string, towerId: string): Observable<any> {
    if (projectId && towerId) {
      return this.apiService
        .get(eval("`" + this.config.daysToComplete + "`"))
        .pipe(map((data) => data));
    }
  }

  getD3DonutTasksChart(
    projectId: string,
    assigned: "user" | "all"
  ): Observable<any> {
    if (projectId && assigned) {
      return this.apiService
        .get(eval("`" + this.config.d3DonutAllTasksChart + "`"))
        .pipe(map((data) => data));
    }
  }

  getD3TaskChartAssigned(
    projectId: string,
    taskType: "punchlist" | "rfi" | "fieldissue",
    chartType: string,
    assigned: "user" | "all"
  ): Observable<any> {
    if (projectId && taskType && chartType && assigned) {
      return this.apiService
        .get(eval("`" + this.config.taskStatusCountAssignedChart + "`"))
        .pipe(map((data) => data));
    }
  }

  getLatestAerialInteriorTour(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService
        .get(eval("`" + this.config.latestAerialInteriorTour + "`"))
        .pipe(map((data) => data));
    }
  }

  getAllTasksList(projectId: string, taskObj: any): Observable<any> {
    if (projectId) {
      return this.apiService
        .post(eval("`" + this.config.allTasksList + "`"), { taskObj })
        .pipe(map((data) => data));
    }
  }
}
