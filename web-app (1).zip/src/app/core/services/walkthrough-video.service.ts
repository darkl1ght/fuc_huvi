import { Injectable, OnDestroy } from "@angular/core";
import { BehaviorSubject, Observable, Subject, Subscription } from "rxjs";
import { filter, take } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class WalkthroughVideoService implements OnDestroy {
  public videoPlaySpeeds: number[] = [0.5, 1.0, 2.0, 4.0];

  public selectedSpeed: number = this.videoPlaySpeeds[1];

  public isImageLoading = new Subject<boolean>();

  constructor() {}

  private isPlayingMode = new BehaviorSubject<boolean>(false);
  private timeoutId: any;

  get isPlayingMode$(): Observable<boolean> {
    return this.isPlayingMode.asObservable();
  }

  setPlaying(isPlaying: boolean) {
    this.isPlayingMode.next(isPlaying);
  }

  get isImageLoading$(): Observable<boolean> {
    return this.isImageLoading.asObservable();
  }

  setImageLoading(isLoading: boolean) {
    this.isImageLoading.next(isLoading);
  }

  stopVideo() {
    this.setPlaying(false);
    clearTimeout(this.timeoutId);
  }

  async waitUntilImageLoaded(): Promise<void> {
    let subscription: Subscription = new Subscription();

    return new Promise<void>((resolve) => {
      subscription = this.isImageLoading$
        .pipe(filter((isLoading) => !isLoading))
        .subscribe(() => {
          subscription.unsubscribe(); // Unsubscribe to prevent memory leaks
          resolve();
        });
    });
  }

  onPlayPauseButtonClick(
    markers: any,
    sceneId: string,
    isVideoCapture: boolean
  ) {
    this.isPlayingMode$.pipe(take(1)).subscribe((isPlaying) => {
      if (isPlaying) {
        this.stopVideo();
      } else {
        this.playWalkthrough(markers, sceneId, isVideoCapture);
      }
    });
  }

  async playWalkthrough(
    markers: any,
    sceneId: string,
    isVideoCapture: boolean
  ) {
    this.setPlaying(true);

    let isFirstImageFired = false;
    let currentPosition = -1;

    let selectedSpeed = this.selectedSpeed;

    if (!isVideoCapture && this.selectedSpeed < 1.0) selectedSpeed = 1.0;

    const skipEvery = isVideoCapture
      ? selectedSpeed * 2
      : selectedSpeed === 1.0
      ? 0
      : selectedSpeed * 0.5;

    // Find the first marker that matches the sceneId
    for (let i = 0; i < markers.length; i++) {
      if (markers[i].feature.properties.imageId === sceneId) {
        currentPosition = i;
        break;
      }
    }

    if (currentPosition === -1) {
      // No marker matches the sceneId
      return;
    }

    // Calculate the next marker based on the current position and speed
    let nextPosition = currentPosition + skipEvery + 1;

    if (nextPosition >= markers.length) {
      // The currentPosition is out of bounds, set it to the last index of the markers array
      nextPosition = markers.length - 1;
    }

    let shouldStopVideo = false;

    while (nextPosition < markers.length && !shouldStopVideo) {
      if (markers[nextPosition].feature.properties.imageId !== sceneId) {
        // Fire the marker event
        if (!isFirstImageFired) {
          markers[nextPosition].fireEvent("click");
          isFirstImageFired = true;
        } else {
          await this.waitUntilImageLoaded();

          // Once the image is loaded, start the timeout
          await new Promise<void>((resolve) => {
            this.timeoutId = setTimeout(() => {
              if (!this.isPlayingMode.getValue()) {
                // Stop playing if isPlayingMode is set to false
                shouldStopVideo = true;
                resolve();
                return;
              }

              if (nextPosition >= markers.length - 1) {
                // Stop playing if this is the last marker
                shouldStopVideo = true;
                this.stopVideo();
              } else {
                // Calculate the next marker based on the current position and speed
                nextPosition += skipEvery + 1;
                if (nextPosition >= markers.length) {
                  // Next position exceeds the length of the markers array,
                  // set it to the last index of the markers array
                  nextPosition = markers.length - 1;
                }
                markers[nextPosition].fireEvent("click");
              }
              resolve();
            }, 1500);
          });
        }
      } else {
        nextPosition++;
        if (nextPosition >= markers.length) {
          // This is the last marker, stop the video
          shouldStopVideo = true;
          this.stopVideo();
        }
      }
    }
  }
  reset() {
    this.selectedSpeed = this.videoPlaySpeeds[1];
    clearTimeout(this.timeoutId);
    this.setImageLoading(false);
    this.setPlaying(false);
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.isPlayingMode.unsubscribe();
    clearTimeout(this.timeoutId);
  }
}
