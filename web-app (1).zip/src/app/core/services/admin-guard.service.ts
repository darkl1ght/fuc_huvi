import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router } from "@angular/router";
import { first } from "rxjs/operators";
import { UserService } from "./user.service";

@Injectable()
export class AdminGuard implements CanActivate {
  constructor(private userService: UserService, public router: Router) {}
  canActivate(route: ActivatedRouteSnapshot): boolean {
    let user = this.userService.getCurrentUser();
    let isAuthenticated = false;
    this.userService.isAuthenticated.pipe(first()).subscribe(
      (data) => {
        isAuthenticated = data;
      },
      (error) => {
        isAuthenticated = false;
      }
    );

    if (!isAuthenticated || !user.isAdmin) {
      this.router.navigate(["login"]);
      return false;
    }
    return true;
  }
}
