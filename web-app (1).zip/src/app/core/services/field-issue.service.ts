import { Inject, Injectable } from "@angular/core";
import { map } from "rxjs/operators";
import { BehaviorSubject, Observable } from "rxjs";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import {
  FIComponentData,
  PanellumHotspot,
  OriginalPanellumPositionParameters,
  FI,
  FIDisucussion,
} from "../models";
import { ApiService } from "./api.service";
@Injectable({
  providedIn: "root",
})
export class FieldIssueService {
  private dataSource: BehaviorSubject<FIComponentData> =
    new BehaviorSubject<FIComponentData>(null);

  private fieldIssueModeDataSource: BehaviorSubject<Boolean> =
    new BehaviorSubject<Boolean>(true);

  private firstClickDataSource: BehaviorSubject<boolean> =
    new BehaviorSubject<boolean>(false);

  data: Observable<FIComponentData> = this.dataSource.asObservable();

  fieldIssueMode: Observable<Boolean> =
    this.fieldIssueModeDataSource.asObservable();

  isFirstClick: Observable<Boolean> = this.firstClickDataSource.asObservable();

  firstClickAction(setFirstClickEvent) {
    this.firstClickDataSource.next(setFirstClickEvent);
  }

  originalPosition: OriginalPanellumPositionParameters;
  lastAddedHostspot: PanellumHotspot;
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  setData(eventType: string, eventData: any) {
    const updatedData: FIComponentData = {
      eventType: eventType,
      data: eventData,
    };
    this.dataSource.next(updatedData);
  }

  setFieldIssueCaptureMode(isActive: boolean) {
    this.fieldIssueModeDataSource.next(isActive);
  }

  /**
   * Create or Update Field Issue
   * @param fieldIssue
   * @param projectId
   * @returns
   */
  updateFI(
    projectId: string,
    tourId: string,
    fieldIssue: FI,
    reqType: string,
    options: { modifiedFields?: any[]; uploadedFileObject?: any }
  ): Observable<any> {
    if (projectId && tourId) {
      if (reqType == "create") {
        return this.apiService
          .post(eval("`" + this.config.fieldIssueCreate + "`"), {
            fieldIssue,
            uploadedFileObject: options.uploadedFileObject,
          })
          .pipe(map((data) => data));
      } else if (reqType == "update") {
        return this.apiService
          .put(eval("`" + this.config.fieldIssueUpdate + "`"), {
            fieldIssue,
            modifiedFields: options.modifiedFields,
          })
          .pipe(map((data) => data));
      }
    }
  }

  /**
   * Returns Field Issue List for specified parameters
   * @param projectId
   * @param tourId
   * @param towerId
   * @param floorId
   * @returns Field Issue List
   */
  getFIList(
    projectId: string,
    tourId: string,
    towerId: string,
    floorId: string
  ): Observable<any> {
    if (projectId && tourId && towerId && floorId) {
      return this.apiService
        .get(eval("`" + this.config.fieldIssueList + "`"))
        .pipe(map((data) => data));
    }
  }

  /**
   * Create new or Update existing Discussion(s) in Field Issue
   * @param projectId
   * @param tourId
   * @param towerId
   * @param floorId
   * @param issueId
   * @param discussion
   * @returns updated field issue discussions
   */
  updateDiscussion(
    projectId: string,
    tourId: string,
    towerId: string,
    floorId: string,
    issueId: string,
    discussion: FIDisucussion,
    isNew: boolean
  ): Observable<{ discussion: FIDisucussion[] }> {
    const discussionId = discussion.discussionId;
    if (projectId && tourId && towerId && floorId && issueId && discussionId) {
      return this.apiService
        .put(eval("`" + this.config.updateFieldIssueDiscussion + "`"), {
          discussion,
          isNew,
        })
        .pipe(map((data) => data));
    }
  }

  /**
   * @param projectId
   * @param tourId
   * @param issueId
   * @param markerAnnotationState
   * @returns saved marker annotation for snapshot image
   */
  saveSnapshotMarkerAnnotation(
    projectId: string,
    tourId: string,
    issueId: string,
    markerAnnotationState: any
  ): Observable<any> {
    if (projectId && tourId && issueId) {
      return this.apiService
        .post(eval("`" + this.config.saveFISnapshotMarkerAnnotation + "`"), {
          maState: markerAnnotationState,
        })
        .pipe(map((data) => data));
    }
  }

  /**
   * Soft Deletes existing Discussion(s) in Field Issue
   * @param projectId
   * @param tourId
   * @param towerId
   * @param floorId
   * @param issueId
   * @param discussionId
   * @returns updated field issue discussions
   */
  deleteDiscussion(
    projectId: string,
    tourId: string,
    towerId: string,
    floorId: string,
    issueId: string,
    discussionId: string
  ): Observable<{ discussion: FIDisucussion[] }> {
    if (projectId && tourId && towerId && floorId && issueId && discussionId) {
      return this.apiService
        .delete(eval("`" + this.config.updateFieldIssueDiscussion + "`"))
        .pipe(map((data) => data));
    }
  }

  /**
   * Returns Field Issue List for specified parameters
   * @param projectId
   * @param towerId
   * @returns Field Issue List
   */
  getFIListByTower(
    projectId: string,
    towerId: string,
    floorId: string
  ): Observable<any> {
    if (projectId && towerId && floorId) {
      return this.apiService
        .get(eval("`" + this.config.fieldIssueListByTowerFloor + "`"))
        .pipe(map((data) => data));
    }
  }

  /**
   * Returns Field Issue report
   * @param projectId
   * @param issueId
   * @returns Field Issue report
   */
  downloadPDFReport(
    projectId: string,
    issueId: string,
    body: Object
  ): Observable<any> {
    if (projectId && issueId) {
      return this.apiService
        .getFileAsTextWithBody(
          eval("`" + this.config.fieldIssueReport + "`"),
          body
        )
        .pipe(map((data) => data));
    }
  }

  /**
   * Returns Field Issue List for specified parameters
   * @param clientId
   * @param projectId
   * @param moduleName
   * @returns Field Issue List
   */
  getFilesByFieldIssueList(
    clientId: string,
    projectId: string,
    moduleName: string,
    fieldIssueIds: any[]
  ): Observable<any> {
    if (clientId && projectId && moduleName && fieldIssueIds) {
      return this.apiService
        .put(eval("`" + this.config.filesByFieldIssueList + "`"), {
          fieldIssueIds,
        })
        .pipe(map((data) => data));
    }
  }

  fieldIssueObject: any = null;
  getFieldIssueObject(): any {
    return this.fieldIssueObject;
  }
  setFieldIssueObject(fieldIssueObject): void {
    this.fieldIssueObject = fieldIssueObject;
  }
}
