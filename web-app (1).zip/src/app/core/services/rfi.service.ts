import { Injectable, Inject } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable({
  providedIn: "root",
})
export class RfiService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getNextRfiNo(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(eval("`" + this.config.getNextRfiNo + "`"));
    }
  }
  getAllRfi(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(eval("`" + this.config.getAllRfi + "`"));
    }
  }

  saveRfi(rfiId: string, projectId: string, rfi): Observable<any> {
    if (projectId && rfiId) {
      return this.apiService
        .put(eval("`" + this.config.updateRfi + "`"), {
          rfi: rfi,
        })
        .pipe(map((data) => data));
    } else {
      return this.apiService
        .post(eval("`" + this.config.saveRfi + "`"), {
          rfi: rfi,
        })
        .pipe(map((data) => data));
    }
  }
  updateRfiReviewer(projectId: string, rfiId: string, type: string, rfi) {
    if (projectId && rfiId) {
      return this.apiService
        .put(eval("`" + this.config.updateRfiReviewer + "`"), {
          rfi: rfi,
        })
        .pipe(map((data) => data));
    }
  }

  deleteRfi(projectId, rfiId) {
    return this.apiService.delete(eval("`" + this.config.deleteRfi + "`"));
  }

  updateRfiAssessmentImages(
    projectId: string,
    rfiId: string,
    questionId: string,
    rfi
  ) {
    if (projectId && rfiId) {
      return this.apiService
        .put(eval("`" + this.config.updateRfiAssessmentImages + "`"), {
          rfi: rfi,
        })
        .pipe(map((data) => data));
    }
  }

  deleteRfiAssessmentImage(
    projectId: string,
    rfiId: string,
    questionId,
    imageId: string
  ) {
    if (projectId && rfiId && questionId && imageId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteRfiAssessmentImage + "`")
      );
    }
  }

  /**
   * @param projectId
   * @param rfiId
   * @param markerAnnotationState
   * @returns saved marker annotation for snapshot image
   */
  saveSnapshotMarkerAnnotation(
    projectId: string,
    rfiId: string,
    questionId: string,
    blobContentId: string,
    markerAnnotationState: any
  ): Observable<any> {
    if (projectId && rfiId) {
      return this.apiService
        .post(eval("`" + this.config.saveRFISnapshotMarkerAnnotation + "`"), {
          maState: markerAnnotationState,
        })
        .pipe(map((data) => data));
    }
  }

  downloadPDFReport(projectId, rfiId): Observable<any> {
    if (projectId && rfiId) {
      return this.apiService
        .getFileAsText(eval("`" + this.config.rfiDownloadPdfReport + "`"))
        .pipe(map((data) => data));
    }
  }
}
