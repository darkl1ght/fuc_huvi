import { Injectable, Inject } from "@angular/core";
import { HttpEvent } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { ApiService } from "./api.service";
import { catchError, map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class EquirectangularImageViewerService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getImageData(
    interiorId: string,
    projectId: string
  ): Observable<HttpEvent<any>> {
    if (interiorId && projectId) {
      return this.apiService.get(eval("`" + this.config.get360ImageData + "`"));
    }
  }

  upload360Image(
    projectId: string,
    interiorId: string,
    clientName: string,
    projectName: string,
    interiorName: string,
    towerName: string,
    imageData: any,
    file: File
  ): Observable<HttpEvent<any>> {
    if (projectId && interiorId) {
      const formData = new FormData();
      formData.append("file", file, file.name);
      formData.append("projectId", projectId);
      formData.append("interiorId", interiorId);
      formData.append("clientName", clientName);
      formData.append("projectName", projectName);
      formData.append("interiorName", interiorName);
      formData.append("towerName", towerName);
      formData.append("imageData", JSON.stringify(imageData));

      let postUrl = eval("`" + this.config.upload360Image + "`");
      return this.apiService
        .postFileImageData(postUrl, formData)
        .pipe(map((data) => data));
    }
  }

  delete360Image(
    interiorId: string,
    projectId: string,
    fileObjectId: string
  ): Observable<any> {
    if (projectId && fileObjectId && interiorId) {
      const url = eval("`" + this.config.delete360Image + "`");
      return this.apiService.delete(url).pipe(
        map((response) => {
          return response;
        }),
        catchError((error) => {
          return throwError(error);
        })
      );
    } else {
      return throwError("Invalid parameters");
    }
  }

  open360ImageViewer(
    projectId: string,
    interiorId: string
  ): Observable<HttpEvent<any>> {
    if (projectId && interiorId) {
      return this.apiService.get(eval("`" + this.config.open360Viewer + "`"));
    }
  }

  openApartmentImageViewer(
    projectId: string,
    interiorId: string,
    apartmentName: any
  ): Observable<HttpEvent<any>> {
    if (projectId && interiorId) {
      return this.apiService.get(
        eval("`" + this.config.openApartmentImageViewer + "`")
      );
    }
  }

  updateApartmentInteriorFloorPlanLocation(
    projectId: string,
    interiorId: string,
    apartmentInteriorMarkerLocation: any
  ): Observable<HttpEvent<any>> {
    if (projectId && interiorId) {
      return this.apiService
        .put(
          eval(
            "`" + this.config.updateApartmentInteriorFloorPlanLocation + "`"
          ),
          {
            apartmentInteriorMarkerLocation: apartmentInteriorMarkerLocation,
          }
        )
        .pipe(map((data) => data));
    }
  }
}
