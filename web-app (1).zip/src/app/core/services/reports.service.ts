import { Injectable, Inject } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { ContractReport, Reports } from "../models";

@Injectable({
  providedIn: "root",
})
export class ReportService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  fetchAerialCaptures(payload: Reports): Observable<any> {
    if (payload) {
      return this.apiService
        .post(this.config.fetchAerialCaptures, payload)
        .pipe(map((data) => data.data));
    }
  }

  fetchCaptureMetrics(payload: Reports): Observable<any> {
    if (payload) {
      return this.apiService
        .post(this.config.fetchCaptureMetrics, payload)
        .pipe(map((data) => data.data));
    }
  }

  fetchContractDates(payload: ContractReport): Observable<any> {
    if (payload) {
      return this.apiService
        .post(this.config.fetchContractDates, payload)
        .pipe(map((data) => data));
    }
  }

  getClientsByUser(): Observable<any> {
    return this.apiService
      .get(this.config.getClientsByUser)
      .pipe(map((data) => data));
  }

  getProjectsByUser(): Observable<any> {
    return this.apiService
      .get(this.config.getProjectsByUser)
      .pipe(map((data) => data));
  }

  fetchVirtualCaptures(payload: Reports): Observable<any> {
    if (payload) {
      return this.apiService
        .post(this.config.fetchVirtualCaptures, payload)
        .pipe(map((data) => data.data));
    }
  }

  fetchFieldIsuues(payload: Reports): Observable<any> {
    if (payload) {
      return this.apiService
        .post(this.config.fetchFieldIssues, payload)
        .pipe(map((data) => data.data));
    }
  }

  fetchWirs(payload: Reports): Observable<any> {
    if (payload) {
      return this.apiService
        .post(this.config.fetchWirs, payload)
        .pipe(map((data) => data.data));
    }
  }

  fetchPunchLists(payload: Reports): Observable<any> {
    if (payload) {
      return this.apiService
        .post(this.config.fetchPunchLists, payload)
        .pipe(map((data) => data.data));
    }
  }
}
