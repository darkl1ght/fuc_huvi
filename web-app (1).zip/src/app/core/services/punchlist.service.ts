import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { PunchListConfig } from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { PunchItem, PunchListData } from "../models/punchlist.model";

@Injectable()
export class PunchListService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getPunchItemsPaginationAndSorting(
    config: PunchListConfig,
    pageParams: any,
    sortParams: any,
    searchTerm: string
  ): Observable<{
    punchItems: PunchItem[];
    itemCount: number;
  }> {
    const projectId = config.projectId;
    return this.apiService.post(
      eval("`" + this.config.getPunchListPaginationSorting + config.type + "`"),
      {
        config: config,
        pageParams: pageParams,
        sortParams: sortParams,
        searchTerm: searchTerm,
      }
    );
  }

  getAllPunchItems(config: PunchListConfig): Observable<{
    punchItems: PunchItem[];
    itemCount: number;
  }> {
    const projectId = config.projectId;
    return this.apiService.post(
      eval("`" + this.config.getPunchList + config.type + "`"),
      { config: config }
    );
  }

  getPunchItemsList(
    projectId,
    tourId
  ): Observable<{
    punchListData: PunchItem[];
    itemCount: number;
  }> {
    return this.apiService.get(eval("`" + this.config.getPunchListData + "`"));
  }

  get(projectId, taskId): Observable<PunchItem> {
    return this.apiService
      .get(eval("`" + this.config.getPunchItem + "`"))
      .pipe(map((data) => data.project));
  }

  getPunchSeq(projectId, punchListId): Observable<number> {
    return this.apiService
      .get(eval("`" + this.config.getPunchSequence + "`"))
      .pipe(map((data) => data.totalRecords));
  }

  destroy(projectId, taskId) {
    return this.apiService.delete(
      eval("`" + this.config.removePunchItem + "`")
    );
  }

  deleteOnsiteSnag(projectId, taskId) {
    return this.apiService.delete(
      eval("`" + this.config.removeOnsiteSnag + "`")
    );
  }

  save(
    taskId: string,
    projectId: string,
    punchItem: PunchItem
  ): Observable<PunchItem> {
    // If we're updating an existing project
    if (punchItem.taskId) {
      return this.apiService
        .put(eval("`" + this.config.updatePunchItem + "`"), {
          punchItem: punchItem,
        })
        .pipe(map((data) => data.punchItem));
      // Otherwise, create a new project
    } else {
      return this.apiService
        .post(eval("`" + this.config.addPunchItem + "`"), {
          punchItem: punchItem,
        })
        .pipe(map((data) => data.punchItem));
    }
  }

  savePunchItemAnnotation(
    taskId: string,
    projectId: string,
    mediaId: string,
    maState: any
  ): Observable<PunchItem> {
    return this.apiService
      .post(eval("`" + this.config.savePunchItemAnnotation + "`"), {
        maState,
        mediaId,
      })
      .pipe(map((data) => data));
  }

  reAssignUser(users, projectId, taskId): Observable<any> {
    // If we're updating an existing project
    if (projectId && taskId) {
      return this.apiService
        .put(eval("`" + this.config.reassignPunchItem + "`"), {
          users: users,
        })
        .pipe(map((data) => data.status));
    }
  }

  shareReport(users, setSignature, projectId, taskId): Observable<any> {
    // If we're updating an existing project
    if (projectId && taskId) {
      return this.apiService
        .post(eval("`" + this.config.shareReport + "`"), {
          users: users,
          addSignature: setSignature,
        })
        .pipe(map((data) => data.status));
    }
  }

  downloadPDFReport(projectId, taskId): Observable<any> {
    if (projectId && taskId) {
      return this.apiService
        .getFileAsText(eval("`" + this.config.downloadPDFReport + "`"))
        .pipe(map((data) => data));
    }
  }

  bulkUploadPunchItem(projectId, punchList: PunchListData): Observable<any> {
    return this.apiService
      .post(eval("`" + this.config.bulkUploadPunch + "`"), {
        punchList: punchList,
      })
      .pipe(map((data) => data));
  }

  bulkUploadAerialPunchItem(
    projectId,
    punchList: PunchListData
  ): Observable<any> {
    return this.apiService
      .post(eval("`" + this.config.addAerialTourSnag + "`"), {
        punchList: punchList,
      })
      .pipe(map((data) => data));
  }

  updateLevel1Status(taskStatus, projectId, taskId): Observable<PunchItem> {
    // If we're updating an existing project
    if (projectId && taskId) {
      return this.apiService
        .put(eval("`" + this.config.level1StatusUpdate + "`"), {
          taskStatus: taskStatus,
        })
        .pipe(map((data) => data.punchItem));
    }
  }

  updateLevel2Status(taskStatus, projectId, taskId): Observable<PunchItem> {
    // If we're updating an existing project
    if (projectId && taskId) {
      return this.apiService
        .put(eval("`" + this.config.level2StatusUpdate + "`"), {
          taskStatus: taskStatus,
        })
        .pipe(map((data) => data.punchItem));
    }
  }

  postPunchListComment(
    projectId: string,
    taskId: string,
    comment: string
  ): Observable<string> {
    if (taskId) {
      return this.apiService
        .post(eval("`" + this.config.postPunchListComment + "`"), {
          comment: comment,
        })
        .pipe(map((data) => data.status));
    }
  }

  deletePunchListComment(
    projectId: string,
    taskId: string,
    commentId: string
  ): Observable<any> {
    if (projectId && taskId && commentId) {
      return this.apiService.delete(
        eval("`" + this.config.deletePunchComment + "`")
      );
    }
  }

  getPunchListComment(projectId, taskId) {
    return this.apiService.get(
      eval("`" + this.config.getPunchListComment + "`")
    );
  }

  removePunchListMedia(projectId, taskId, mediaId) {
    return this.apiService.delete(
      eval("`" + this.config.deletePunchListMedia + "`")
    );
  }

  getDashboardByWorkPackage(projectId, type): Observable<any> {
    return this.apiService
      .get(eval("`" + this.config.punchListDashboardWorkPackage + "`"))
      .pipe(map((data) => data.data));
  }

  getDashboardByLocation(projectId, type): Observable<any> {
    return this.apiService
      .get(eval("`" + this.config.punchListDashboardLocation + "`"))
      .pipe(map((data) => data.data));
  }

  getDashboardByStatus(projectId, type): Observable<any> {
    return this.apiService
      .get(eval("`" + this.config.punchListDashboardStatus + "`"))
      .pipe(map((data) => data.data));
  }

  getDashboardByPriority(projectId, type): Observable<any> {
    return this.apiService
      .get(eval("`" + this.config.punchListDashboardPriority + "`"))
      .pipe(map((data) => data.data));
  }

  getDashboardByConformityStatus(projectId, type): Observable<any> {
    return this.apiService
      .get(eval("`" + this.config.punchListDashboardConformity + "`"))
      .pipe(map((data) => data.data));
  }

  getDashboardByConformityOverdue(projectId, type): Observable<any> {
    return this.apiService
      .get(eval("`" + this.config.punchListDashboardOverdue + "`"))
      .pipe(map((data) => data.data));
  }
}
