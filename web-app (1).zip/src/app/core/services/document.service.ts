import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { Document } from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class DocumentService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getDocuments(projectId): Observable<{ documents: Document[] }> {
    return this.apiService.get(eval("`" + this.config.getDocuments + "`"));
  }

  destroy(projectId, documentId) {
    return this.apiService.delete(eval("`" + this.config.deleteDocument + "`"));
  }

  save(pId: string, document: Document): Observable<Document> {
    let projectId = pId;
    if (document.documentId) {
      let documentId = document.documentId;
      return this.apiService
        .put(eval("`" + this.config.updateDocument + "`"), {
          document: document,
        })
        .pipe(map((data) => data.document));
      // Otherwise, create a new project
    } else {
      return this.apiService
        .post(eval("`" + this.config.createDocument + "`"), {
          document: document,
        })
        .pipe(map((data) => data.document));
    }
  }

  getBlobToken(container: string, blobName: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getBlobToken + "`"));
    }
  }

  getToken(container: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getToken + "`"));
    }
  }

  getReadToken(container: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getReadToken + "`"));
    }
  }
}
