import { Document } from "src/app/core";
import { Title } from "@angular/platform-browser";
import { Injectable } from "@angular/core";
import { WindowReferenceService } from "./window-reference.service";

@Injectable({
  providedIn: "root",
})
export class DataLayerService {
  private window;

  constructor(private _windowRef: WindowReferenceService) {
    this.window = _windowRef.nativeWindow; // intialise the window to what we get from our window service
  }

  private pingHome(obj) {
    if (obj) this.window.dataLayer.push(obj);
  }

  //list of all our dataLayer methods

  logPageView(url) {
    let customPageName = "";
    if (url.includes("client")) {
      customPageName = "Constra-Client";
    } else if (url.includes("/schedule")) {
      customPageName = "Constra-Wbs";
    } else if (url.includes("location")) {
      customPageName = "Constra-WorkLocation";
    } else if (url.includes("exterior")) {
      customPageName = "Constra-Aerial";
    } else if (url.includes("interior")) {
      customPageName = "Constra-Virtual";
    } else if (url.includes("task")) {
      customPageName = "Constra-Punchlist";
    } else if (url.includes("media")) {
      customPageName = "Constra-Media";
    } else if (url.includes("document")) {
      customPageName = "Constra-Docs";
    } else if (url.includes("/workpackage")) {
      customPageName = "Constra-WorkTrade";
    } else if (url.includes("login")) {
      customPageName = "Constra-login";
    } else if (url.includes("forgot")) {
      customPageName = "Constra-forgot";
    } else if (url.includes("interior")) {
      customPageName = "Constra-Virtual";
    } else if (url.includes("rfi")) {
      customPageName = "Constra-WIR";
    } else if (url.includes("inspectionchecklist")) {
      customPageName = "Constra-InspectionChecklist";
    } else if (url.includes("workflow")) {
      customPageName = "Constra-Workflow";
    } else if (url.includes("userroles")) {
      customPageName = "Constra-UserRoles";
    } else if (url.includes("dashboard")) {
      customPageName = "Constra-Dashboard";
    } else if (url.includes("fieldIssue")) {
      customPageName = "Constra-FieldIssue";
    } else if (url.includes("capturemetrics")) {
      customPageName = "Constra-Reports-CaptureMetrics";
    } else if (url.includes("contractdates")) {
      customPageName = "Constra-Reports-ContractDates";
    } else if (url.includes("capturestats")) {
      customPageName = "Constra-Reports-CaptureStatistics";
    } else if (url.includes("adoptionstats")) {
      customPageName = "Constra-Reports-adoptionStatistics";
    }

    //keep the more generic route at the end
    else if (url.includes("/report")) {
      customPageName = "Constra-Reports-CaptureStatistics";
    } else if (url.includes("/team")) {
      customPageName = "Constra-Team";
    } else if (url.includes("/settings/")) {
      customPageName = "Constra-WorkTrade";
    } else if (
      url.includes("/project/map") ||
      url.includes("/project/create") ||
      url === "/project"
    ) {
      customPageName = "Constra-Project";
    }

    //To handle close of settings popup and redirected to aerial, url will not have aerial yet it should be aerial
    else if (url.includes("/detail/")) {
      customPageName = "Constra-Aerial";
    } else customPageName = url;

    const hit = {
      event: "content-view",
      pageName: url,
      page_title: customPageName,
      dlcustomPageName: customPageName,
      dluserID: localStorage.getItem("userId"),
    };
    this.pingHome(hit);
  }

  logEvent(event, category, action, label) {
    const hit = {
      event: event,
      category: category,
      action: action,
      label: label,
    };
    this.pingHome(hit);
  }

  logCustomDimensionTest(value) {
    const hit = {
      event: "custom-dimension",
      value: value,
    };
    this.pingHome(hit);
  }

  // .. add more custom methods as needed by your app.
}
