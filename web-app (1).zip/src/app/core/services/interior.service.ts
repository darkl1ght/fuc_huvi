import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import {
  TourImage,
  InteriorTour,
  InteriorImage,
  UpdateWbsProgressIntBulk,
  InteriorTagPayload,
} from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class InteriorService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getInteriorList(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(eval("`" + this.config.getInteriorList + "`"));
    }
  }

  getAllInteriorTowers(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(
        eval("`" + this.config.getAllInteriorTowers + "`")
      );
    }
  }

  destroy(projectId: string, interiorId: string) {
    if (projectId && interiorId) {
      return this.apiService.delete(
        eval("`" + this.config.removeInterior + "`")
      );
    }
  }

  save(projectId: string, interior: InteriorTour): Observable<InteriorTour> {
    if (projectId) {
      let interiorId = interior.interiorId;
      if (interiorId) {
        return this.apiService
          .put(eval("`" + this.config.updateInterior + "`"), {
            interior,
          })
          .pipe(map((data) => data.interior));
      } else {
        return this.apiService
          .post(eval("`" + this.config.postNewInterior + "`"), {
            interior,
          })
          .pipe(map((data) => data.interior));
      }
    }
  }

  publishInteriorStatus(
    projectId: string,
    interiorId: string
  ): Observable<InteriorTour> {
    if (projectId && interiorId) {
      return this.apiService
        .put(eval("`" + this.config.postInteriorStatus + "`"))
        .pipe(map((data) => data.status));
    }
  }

  createNewTour(
    projectId: string,
    interiorId: string,
    tour: TourImage
  ): Observable<any> {
    if (interiorId && projectId) {
      return this.apiService
        .post(eval("`" + this.config.postNewTour + "`"), { tour })
        .pipe(map((data) => data));
    }
  }

  removeTour(projectId: string, interiorId: string, tourId: string) {
    if (interiorId && projectId && tourId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteInteriorTour + "`")
      );
    }
  }

  getTourDetails(projectId, interiorId) {
    if (interiorId && projectId) {
      return this.apiService.get(eval("`" + this.config.getInteriorData + "`"));
    }
  }

  getToken(container: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getToken + "`"));
    }
  }

  postImage(
    projectId: string,
    interiorId: string,
    tourId: string,
    image: InteriorImage
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .post(eval("`" + this.config.postInteriorImage + "`"), { image })
        .pipe(map((data) => data));
    }
  }

  updateTourFeature(
    projectId: string,
    interiorId: string,
    tourId: string,
    feature: any
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateTourFeature + "`"), {
          feature: feature,
        })
        .pipe(map((data) => data));
    }
  }

  updateImageLinkage(
    projectId: string,
    interiorId: string,
    tourId: string,
    linkage: any
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateImageLinkage + "`"), {
          linkage: linkage,
        })
        .pipe(map((data) => data));
    }
  }

  addNewLegend(projectId, tourId, legend): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.uploadLegend + "`"), {
          legend: legend,
        })
        .pipe(map((data) => data));
    }
  }

  publishTour(
    projectId: string,
    interiorId: string,
    tourId: string
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.publishTour + "`"))
        .pipe(map((data) => data));
    }
  }

  removeImageMapping(
    projectId: string,
    interiorId: string,
    tourId: string,
    linkage: any
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.removeImageLinkage + "`"), {
          linkage: linkage,
        })
        .pipe(map((data) => data));
    }
  }

  getReadToken(container: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getReadToken + "`"));
    }
  }

  getBlobToken(container: string, blobName: string): Observable<any> {
    if (container && blobName) {
      return this.apiService.get(eval("`" + this.config.getBlobToken + "`"));
    }
  }

  uploadChart(
    projectId: string,
    interiorId: string,
    tourId: string,
    charts: any
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.addNewChart + "`"), { charts: charts })
        .pipe(map((data) => data));
    }
  }

  uploadChartByTower(
    projectId: string,
    interiorId: string,
    towerId: string,
    charts: any
  ): Observable<any> {
    if (interiorId && projectId && towerId) {
      return this.apiService
        .put(eval("`" + this.config.addNewChartByTower + "`"), {
          charts,
        })
        .pipe(map((data) => data));
    }
  }

  deleteChart(
    projectId: string,
    interiorId: string,
    tourId: string,
    chart: any
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.deleteChart + "`"), { chart: chart })
        .pipe(map((data) => data));
    }
  }

  getCharts(
    projectId: string,
    interiorId: string,
    tourId: string
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .get(eval("`" + this.config.getCharts + "`"))
        .pipe(map((data) => data));
    }
  }

  removeStaticUrl(projectId: string, interiorId: string, tourId: string) {
    if (interiorId && projectId && tourId) {
      return this.apiService.delete(
        eval("`" + this.config.removeStaticTourData + "`")
      );
    }
  }

  saveStaticTourUrl(
    projectId: string,
    interiorId: string,
    tour: any
  ): Observable<InteriorTour> {
    if (interiorId && projectId) {
      return this.apiService
        .put(eval("`" + this.config.addStaticUrl + "`"), {
          tour,
        })
        .pipe(map((data) => data.interior));
    }
  }

  removeStaticChart(projectId, interiorId, chartId) {
    if (interiorId && projectId && chartId) {
      return this.apiService.delete(
        eval("`" + this.config.removeStaticTourChart + "`")
      );
    }
  }

  saveStaticTourChart(
    projectId: string,
    interiorId: string,
    charts: any
  ): Observable<InteriorTour> {
    if (interiorId && projectId) {
      return this.apiService
        .put(eval("`" + this.config.addStaticChart + "`"), {
          charts,
        })
        .pipe(map((data) => data.interior));
    }
  }

  publishStaticTour(projectId: string, interiorId: string): Observable<any> {
    if (interiorId && projectId) {
      return this.apiService
        .put(eval("`" + this.config.publishStaticInteriorChart + "`"))
        .pipe(map((data) => data));
    }
  }

  updateRemark(
    projectId: string,
    interiorId: string,
    tourId: string,
    remark: any,
    sceneId: string
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateRemark + "`"), {
          hotspot: remark,
          sceneId: sceneId,
        })
        .pipe(map((data) => data));
    }
  }

  removeRemark(
    projectId: string,
    interiorId: string,
    tourId: string,
    remark: any
  ): Observable<any> {
    if (interiorId && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.removeRemark + "`"), { remark })
        .pipe(map((data) => data));
    }
  }

  uploadFloorPlan(
    projectId: string,
    tourId: string,
    blobContentId: string
  ): Observable<any> {
    if (tourId && projectId) {
      return this.apiService
        .put(eval("`" + this.config.updateFloorPlan + "`"), {
          blobContentId,
        })
        .pipe(map((data) => data));
    }
  }

  getTourData(projectId: string, tourId: string) {
    if (tourId && projectId) {
      return this.apiService.get(eval("`" + this.config.getTourById + "`"));
    }
  }

  deleteRemarkComment(
    projectId: string,
    tourId: string,
    remarkId: string,
    commentId: string
  ) {
    if (commentId && tourId && projectId && remarkId) {
      return this.apiService
        .delete(eval("`" + this.config.removeRemarkComment + "`"))
        .pipe(map((data) => data));
    }
  }

  addRemarkComments(
    projectId: string,
    interiorId: string,
    tourId: string,
    remarkId: string,
    comment: string
  ) {
    if (tourId && projectId && interiorId && remarkId && comment.trim()) {
      return this.apiService
        .post(eval("`" + this.config.addRemarkComment + "`"), {
          comment,
        })
        .pipe(map((data) => data.status));
    }
  }

  getRemarkComment(
    projectId: string,
    tourId: string,
    remarkId: string
  ): Observable<any> {
    if (tourId && projectId && remarkId) {
      return this.apiService.get(
        eval("`" + this.config.getRemarkComments + "`")
      );
    }
  }

  resyncData(projectId: string, interiorId: string): Observable<any> {
    if (projectId && interiorId) {
      return this.apiService.put(eval("`" + this.config.syncMasterData + "`"));
    }
  }

  overrideTowerData(
    projectId: string,
    interiorId: string,
    towerId: string,
    towerName: any,
    captureDate: any
  ): Observable<any> {
    if (projectId && interiorId && towerId) {
      return this.apiService
        .put(eval("`" + this.config.overrideTowerData + "`"), {
          interior: {
            towerName,
            captureDate,
          },
        })
        .pipe(map((data) => data));
    }
  }

  overrideTourData(
    projectId: string,
    interiorId: string,
    tourId: string,
    tourName: any
  ): Observable<any> {
    if (projectId && tourId && interiorId) {
      return this.apiService
        .put(eval("`" + this.config.overrideTourData + "`"), {
          tour: {
            tourName,
          },
        })
        .pipe(map((data) => data));
    }
  }

  getInteriorById(
    projectId: string,
    interiorId: string
  ): Observable<{
    tours: any[];
    data: any;
  }> {
    if (projectId && interiorId) {
      return this.apiService.get(eval("`" + this.config.getInteriorById + "`"));
    }
  }

  getWBSStatus(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string
  ): Observable<{ wbsData: any }> {
    if (projectId && tourId && interiorId && towerId && floorId) {
      return this.apiService.get(eval("`" + this.config.getTourWBSInt + "`"));
    }
  }

  getWBSStatusByUnit(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string,
    unitId: string
  ): Observable<{ wbsData: any }> {
    if (projectId && tourId && interiorId && towerId && floorId && unitId) {
      return this.apiService.get(
        eval("`" + this.config.getTourWBSIntByUnit + "`")
      );
    }
  }

  updateWBSProgressBulk(payload: UpdateWbsProgressIntBulk): Observable<any> {
    if (payload) {
      return this.apiService
        .put(this.config.updateTourProgressStatusIntBulk, payload)
        .pipe(map((data) => data));
    }
  }

  updateWBSProgress(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string,
    wbsId: string,
    progress: any,
    comment: string
  ): Observable<any> {
    if (projectId && interiorId && tourId && towerId && floorId && wbsId) {
      return this.apiService
        .put(eval("`" + this.config.updateTourProgressStatusInt + "`"), {
          wbsProgress: {
            progress,
            comment,
          },
        })
        .pipe(map((data) => data));
    }
  }

  restoreWBSBaseline(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string
  ): Observable<any> {
    if (projectId && interiorId && tourId && towerId && floorId) {
      return this.apiService
        .put(eval("`" + this.config.restoreWBSBaseline + "`"))
        .pipe(map((data) => data));
    }
  }

  restoreWBSBaselineByUnit(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string,
    unitId: string
  ): Observable<any> {
    if (projectId && interiorId && tourId && towerId && floorId && unitId) {
      return this.apiService
        .put(eval("`" + this.config.restoreWBSBaselineByUnit + "`"))
        .pipe(map((data) => data));
    }
  }

  getProgressChart(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string
  ): Observable<any> {
    if (interiorId && tourId && projectId && towerId && floorId) {
      return this.apiService
        .get(eval("`" + this.config.getProgressChartInt + "`"))
        .pipe(map((data) => data));
    }
  }
  getProgressChartByUnit(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string
  ): Observable<any> {
    if (interiorId && tourId && projectId && towerId && floorId) {
      return this.apiService
        .get(eval("`" + this.config.getProgressChartIntByUnit + "`"))
        .pipe(map((data) => data));
    }
  }

  getProgressChartInteriorLevel(
    projectId: string,
    interiorId: string
  ): Observable<any> {
    if (interiorId && projectId) {
      return this.apiService
        .get(eval("`" + this.config.getProgressChartIntLevel + "`"))
        .pipe(map((data) => data));
    }
  }
  syncWBSMasterData(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string
  ): Observable<{ status: Boolean }> {
    if (interiorId && tourId && projectId && towerId && floorId) {
      return this.apiService.get(
        eval("`" + this.config.syncWBSMasterDataInt + "`")
      );
    }
  }

  publishWBSTourData(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    floorId: string
  ): Observable<{ status: Boolean }> {
    if (interiorId && tourId && projectId && towerId && floorId) {
      return this.apiService.get(
        eval("`" + this.config.publishWBSTourDataInt + "`")
      );
    }
  }

  checkSelfServeAccess(projectId: string): Observable<{ access: Boolean }> {
    if (projectId) {
      return this.apiService.get(
        eval("`" + this.config.selfServeAcceessInterior + "`")
      );
    }
  }

  getTourWBSStatus(
    projectId: string,
    tourId: string,
    towerId: string,
    floorId: string
  ): Observable<{ status: Boolean }> {
    if (tourId && projectId && towerId && floorId) {
      return this.apiService.get(
        eval("`" + this.config.getTourWBSStatus + "`")
      );
    }
  }

  downloadChartData(projectId, interiorId, towerId): Observable<any> {
    if (projectId) {
      return this.apiService
        .getFileAsText(eval("`" + this.config.downloadInteriorChartData + "`"))
        .pipe(map((data) => data));
    }
  }

  getChartByActivity(
    projectId: string,
    interiorId: string,
    tourId: string,
    towerId: string,
    activityName: string
  ): Observable<any> {
    if (projectId && interiorId && tourId && towerId && activityName) {
      return this.apiService
        .post(eval("`" + this.config.chartByActivity + "`"), {
          query: activityName,
        })
        .pipe(map((data) => data));
    }
  }

  getTourProcessingStats(
    projectId: String,
    interiorId: String,
    towerId: String
  ) {
    if (interiorId && projectId && towerId) {
      return this.apiService.get(
        eval("`" + this.config.getTourProcessingStats + "`")
      );
    }
  }

  getWalkthroughForTower(
    projectId: String,
    interiorId: String,
    towerId: String
  ) {
    if (interiorId && projectId && towerId) {
      return this.apiService.get(
        eval("`" + this.config.getWalkthroughsByTower + "`")
      );
    }
  }

  updatePath(
    projectId: String,
    tourId: String,
    captureStartPoint: { x: number; y: number },
    captureEndPoint: { x: number; y: number }
  ) {
    if (projectId && tourId) {
      return this.apiService.put(
        eval("`" + this.config.updateVirtualTourPath + "`"),
        {
          captureStartPoint,
          captureEndPoint,
        }
      );
    }
  }

  deleteInteriorImages(
    projectId: String,
    tourId: String,
    imageNumbers: number[]
  ) {
    if (projectId && tourId) {
      return this.apiService.put(
        eval("`" + this.config.deleteVirtualTourImages + "`"),
        {
          imageNumbers,
        }
      );
    }
  }

  getUnits(projectId: string, floorId: string): Observable<{ units: any }> {
    if (projectId && floorId) {
      return this.apiService.get(eval("`" + this.config.getUnitsInt + "`"));
    }
  }

  updateCoordinates(
    projectId: String,
    tourId: String,
    coordinates: any,
    captureStartPoint?: { x: number; y: number },
    captureEndPoint?: { x: number; y: number }
  ) {
    if (projectId && tourId) {
      return this.apiService.put(
        eval("`" + this.config.updateVirtualTourCoordinates + "`"),
        {
          updatedCoordinates: coordinates,
          captureStartPoint,
          captureEndPoint,
        }
      );
    }
  }

  emailNotifyUsers(
    projectId: string,
    interiorId: string,
    shareLink: string,
    floorPublishedCount: number
  ): Observable<any> {
    if (interiorId && projectId) {
      return this.apiService
        .post(eval("`" + this.config.emailNotifyUsersVirtualTour + "`"), {
          shareLink,
          floorPublishedCount,
        })
        .pipe(map((data) => data));
    }
  }

  getTowersByInteriorId(
    projectId: string,
    interiorId: string
  ): Observable<{
    tours: any[];
    data: any;
  }> {
    if (projectId && interiorId) {
      return this.apiService.get(
        eval("`" + this.config.getTowersByInteriorId + "`")
      );
    }
  }

  updateInteriorTags(
    projectId: string,
    interiorId: string,
    payload: InteriorTagPayload
  ): Observable<any> {
    if (projectId && interiorId) {
      return this.apiService
        .put(eval("`" + this.config.updateTagsInt + "`"), payload)
        .pipe(map((data) => data));
    }
  }
}
