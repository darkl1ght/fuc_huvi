import { Injectable, Inject } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { AecLevel, WorkPackage } from "../models/master-data.model";
import { FloorPlanMeasurement } from "src/app/layout/project/settings/components/location/bim-calibration/floor-plan-calibrate/leaflet-utils";

@Injectable()
export class MasterDataService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  private refreshWeatherSub = new Subject<string>();
  refreshWeather$ = this.refreshWeatherSub.asObservable();

  sendRefreshWeather(id) {
    this.refreshWeatherSub.next(id);
  }

  getMasterData(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(eval("`" + this.config.getMasterData + "`"));
    }
  }

  getWorkPackageData(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(eval("`" + this.config.getWorkPackage + "`"));
    }
  }

  removeWorkPackage(projectId: string, tradeId: string): Observable<any> {
    if (projectId && tradeId) {
      return this.apiService
        .delete(eval("`" + this.config.removeWorkPackage + "`"))
        .pipe(map((data) => data));
    }
  }

  getWeatherOneCall_1_0(lat: string, lon: string): Observable<any> {
    return this.apiService.get(eval("`" + this.config.getOpenWeatherAPI + "`"));
  }

  removeFloorPlan(projectId: string, locationId: string): Observable<any> {
    if (projectId && locationId) {
      return this.apiService
        .put(eval("`" + this.config.removeDrawing + "`"))
        .pipe(map((data) => data));
    }
  }

  updateLocation(
    projectId: string,
    locationId: string,
    location: any
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService
        .put(eval("`" + this.config.updateLocationName + "`"), {
          location: location,
        })
        .pipe(map((data) => data));
    }
  }

  updateLocationOrder(
    projectId: string,
    level: any,
    location: any
  ): Observable<any> {
    if (projectId && level) {
      return this.apiService
        .put(eval("`" + this.config.updateLocationOrder + "`"), {
          location: location,
        })
        .pipe(map((data) => data));
    }
  }

  getReadToken(container: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getReadToken + "`"));
    }
  }

  saveWorkPackage(
    projectId: string,
    tradeId: string,
    workPackage: WorkPackage
  ): Observable<any> {
    if (projectId && tradeId) {
      return this.apiService
        .put(eval("`" + this.config.updateWorkPackage + "`"), {
          workPackage: workPackage,
        })
        .pipe(map((data) => data));
    } else {
      return this.apiService
        .post(eval("`" + this.config.addWorkPackage + "`"), {
          workPackage: workPackage,
        })
        .pipe(map((data) => data));
    }
  }

  getWorkLocation(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(eval("`" + this.config.getWorkLocation + "`"));
    }
  }

  addNewWorkLocation(projectId: string, location): Observable<any> {
    if (projectId && location) {
      return this.apiService
        .post(eval("`" + this.config.saveWorkLocation + "`"), {
          location: location,
        })
        .pipe(map((data) => data));
    }
  }

  addUpdateFloorPlanDetails(
    projectId: string,
    locationId: string,
    drawing: any,
    updateChild: boolean,
    isApplyToAll: boolean = false
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService
        .put(eval("`" + this.config.uploadWorkLocation + "`"), {
          drawing: { reference: drawing, updateChild: updateChild },
          isApplyToAll: isApplyToAll,
        })
        .pipe(map((data) => data));
    }
  }

  deleteLocation(projectId: string, locationId: string): Observable<any> {
    if (projectId && locationId) {
      return this.apiService
        .delete(eval("`" + this.config.deleteWorkLocation + "`"))
        .pipe(map((data) => data));
    }
  }

  bulkUploadLocation(projectId: string, location: any): Observable<any> {
    if (projectId && location) {
      return this.apiService
        .put(eval("`" + this.config.bulkUploadLocation + "`"), {
          location: location,
        })
        .pipe(map((data) => data));
    }
  }

  bulkUploadWorkPackage(projectId, workPackages): Observable<any> {
    if (projectId && workPackages) {
      return this.apiService
        .put(eval("`" + this.config.bulkUploadWorkPackage + "`"), {
          workPackages: workPackages,
        })
        .pipe(map((data) => data));
    }
  }

  saveBIMOffset(
    projectId: string,
    locationId: string,
    x: number,
    y: number,
    z: number
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService.post(eval("`" + this.config.saveBIMOffset + "`"), {
        offset: { x, y, z },
      });
    }
  }

  saveBIMAecFloorInfo(
    projectId: string,
    locationId: string,
    floorLevelAecData: AecLevel[]
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService.post(
        eval("`" + this.config.saveBIMAecLevelInfo + "`"),
        {
          floorLevelAecData,
        }
      );
    }
  }

  saveFloorplanConfigDetails(
    projectId: string,
    level2LocationId: string,
    parentLocationId: string,
    floorPlanConfig: FloorPlanMeasurement
  ): Observable<any> {
    if (projectId && level2LocationId && parentLocationId) {
      return this.apiService.post(
        eval("`" + this.config.saveFloorplanConfig + "`"),
        {
          ...floorPlanConfig,
        }
      );
    }
  }

  deleteFloorplanMarker(
    projectId: string,
    locationId: string,
    markerPositionLabel: string
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteFloorplanMarkerLocation + "`"),
        {
          markerPositionLabel,
        }
      );
    }
  }

  saveLevel2AECFloorname(
    projectId: string,
    matchedFloorNames: any
  ): Observable<any> {
    if (projectId) {
      return this.apiService.post(
        eval("`" + this.config.saveLevel2AECLevel + "`"),
        {
          matchedFloorNames,
        }
      );
    }
  }

  saveBIMModelBound(
    projectId: string,
    locationId: string,
    modelBoundLength: number
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService.post(
        eval("`" + this.config.saveBIMModelBound + "`"),
        {
          distance: modelBoundLength,
        }
      );
    }
  }

  saveBIMAngularDeviationFromTrueNorth(
    projectId: string,
    locationId: string,
    bimAngularDeviationFromTrueNorth: number
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService.post(
        eval("`" + this.config.saveBIMAngularDeviationFromTrueNorth + "`"),
        {
          bimAngularDeviationFromTrueNorth,
        }
      );
    }
  }

  calculateTransformationScale(
    projectId: string,
    locationId: string
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService.post(
        eval("`" + this.config.calculateTransformationScale + "`")
      );
    }
  }
}
