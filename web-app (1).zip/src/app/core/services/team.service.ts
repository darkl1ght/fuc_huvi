import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";

import { ApiService } from "./api.service";
import { ProjectUser, ProjectUsers } from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class ProjectUserService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  add(projectId: string, payload): Observable<ProjectUser> {
    if (projectId) {
      if (payload.memberId) {
        let userId = payload.memberId;
        return this.apiService
          .put(eval("`" + this.config.updateProjectUser + "`"), {
            user: payload,
          })
          .pipe(map((data) => data.user));
        // Otherwise, create a new user
      } else {
        return this.apiService
          .post(eval("`" + this.config.createProjectUser + "`"), {
            user: payload,
          })
          .pipe(map((data) => data.users));
      }
    }
  }

  getAll(projectId: string): Observable<{ users: ProjectUser[] }> {
    if (projectId) {
      return this.apiService
        .get(eval("`" + this.config.getProjectUser + "`"))
        .pipe(map((data) => data));
    }
  }

  destroy(projectId: string, userId: string) {
    if (projectId && userId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteProjectUser + "`")
      );
    }
  }

  blockUnblockUser(
    projectId: string,
    memberId: string,
    isBlocked: boolean
  ): Observable<string> {
    if (projectId && memberId) {
      return this.apiService
        .put(eval("`" + this.config.blockUnblockProjectUser + "`"), {
          isBlocked: isBlocked,
          memberId: memberId,
        })
        .pipe(map((data) => data.status));
    }
  }

  updateSignature(
    projectId: string,
    userId: string,
    signature
  ): Observable<string> {
    if (projectId && userId) {
      return this.apiService.put(
        eval("`" + this.config.uploadSignature + "`"),
        {
          signature: signature,
        }
      );
    }
  }

  getReadToken(container: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getReadToken + "`"));
    }
  }
  downloadTeam(projectId): Observable<any> {
    if (projectId) {
      return this.apiService
        .getFileAsText(eval("`" + this.config.downloadTeamTemplate + "`"))
        .pipe(map((data) => data));
    }
  }

  bulkUploadTeams(
    projectId: string,
    users: ProjectUsers
  ): Observable<ProjectUser> {
    return this.apiService
      .post(eval("`" + this.config.bulkUploadTeams + "`"), { teams: users })
      .pipe(map((data) => data.users));
  }
}
