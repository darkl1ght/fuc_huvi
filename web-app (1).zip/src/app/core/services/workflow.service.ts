import { Injectable, Inject } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { AecLevel, WorkPackage } from "../models/master-data.model";
import { FloorPlanMeasurement } from "src/app/layout/project/settings/components/location/bim-calibration/floor-plan-calibrate/leaflet-utils";

@Injectable({
  providedIn: "root",
})
export class WorkFlowService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getWorkFlow(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(eval("`" + this.config.getWorkFlowData + "`"));
    }
  }
  getWorkFlowRfi(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(
        eval("`" + this.config.getWorkFlowRFIData + "`")
      );
    }
  }

  saveWorkFlow(projectId: string, workFlow): Observable<any> {
    if (projectId && workFlow) {
      return this.apiService
        .post(eval("`" + this.config.saveWorkFlow + "`"), {
          workFlow: workFlow,
        })
        .pipe(map((data) => data));
    }
  }

  deleteWorkFlow(
    projectId: string,
    type: string,
    workFlowId: string
  ): Observable<any> {
    if (projectId && workFlowId && type) {
      return this.apiService
        .delete(eval("`" + this.config.deleteWorkFlow + "`"))
        .pipe(map((data) => data));
    }
  }
}
