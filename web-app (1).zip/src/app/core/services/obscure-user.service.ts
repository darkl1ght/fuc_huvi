import { Injectable, Inject } from "@angular/core";
import { Observable, BehaviorSubject } from "rxjs";

import { ApiService } from "./api.service";
import { JwtService } from "./jwt.service";
import { distinctUntilChanged, map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { ObscureUser, User } from "../models";

@Injectable()
export class ObscureUserService {
  private currentUserSubject = new BehaviorSubject<User>({} as User);
  public currentUser = this.currentUserSubject
    .asObservable()
    .pipe(distinctUntilChanged());

  private isAuthenticatedSubject = new BehaviorSubject<boolean>(false);
  public isAuthenticated = this.isAuthenticatedSubject.asObservable();

  constructor(
    private apiService: ApiService,
    private jwtService: JwtService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  add(payload, projectId): Observable<{ user: ObscureUser }> {
    return this.apiService
      .post(eval("`" + this.config.createObscureUser + "`"), {
        user: payload,
      })
      .pipe(map((data) => data));
  }
}
