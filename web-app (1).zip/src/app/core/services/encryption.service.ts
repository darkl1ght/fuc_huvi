import { Inject, Injectable } from "@angular/core";
import * as CryptoJS from "crypto-js";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
@Injectable({
  providedIn: "root",
})
export class EncryptionService {
  constructor(@Inject(APP_CONFIG) private config: AppConfig) {}

  private keyConstruct: string = this.config.encryptionKeyPrefix;
  //The  method is use for encrypt the value.
  encrypt(key: string, value: string) {
    let encrypted: any = value;

    const compoundKey = this.keyConstruct + key; //appending base keyConstruct+key to make it more complex

    encrypted = CryptoJS.AES.encrypt(
      CryptoJS.enc.Utf8.parse(value),
      compoundKey
    );

    return encrypted.toString();
  }

  //The  method is use for decrypt the value.
  decrypt(key: string, value: any) {
    let decryptedString = value;
    if (!!value) {
      const compoundKey = this.keyConstruct + key; //appending base keyConstruct+key to make it more complex

      const decrypted = CryptoJS.AES.decrypt(
        value.replaceAll('"', ""),
        compoundKey
      );

      if (decrypted) {
        try {
          decryptedString = decrypted.toString(CryptoJS.enc.Utf8);
          if (decryptedString.length > 0) {
            return decryptedString;
          } else {
            return "error while decryption";
          }
        } catch (e) {
          return e;
        }
      }
    }
    return decryptedString;
  }
}
