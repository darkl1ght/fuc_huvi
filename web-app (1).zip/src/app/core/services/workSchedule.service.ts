import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { JwtService } from "./jwt.service";
import { WBSData, WorkSchedule } from "../models";

@Injectable()
export class WorkScheduleService {
  constructor(
    private apiService: ApiService,
    private jwtTokenSvc: JwtService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  downloadSchedule(projectId): Observable<any> {
    if (projectId) {
      return this.apiService
        .getFileAsText(eval("`" + this.config.downloadWorkSchedule + "`"))
        .pipe(map((data) => data));
    }
  }

  uploadWorkSchedule(
    projectId: string,
    schedule: WorkSchedule
  ): Observable<any> {
    return this.apiService
      .post(eval("`" + this.config.uploaddWorkSchedule + "`"), {
        wbs: schedule,
      })
      .pipe(map((data) => data));
  }

  deleteIntWBSLineItem(projectId, towerId, floorId, wbsId): Observable<any> {
    return this.apiService.delete(
      eval("`" + this.config.deleteIntWBSLineItem + "`")
    );
  }

  deleteExtWBSLineItem(projectId, towerId, wbsId): Observable<any> {
    return this.apiService.delete(
      eval("`" + this.config.deleteExtWBSLineItem + "`")
    );
  }

  updateInteriorWBSLineItem(
    projectId: string,
    wbsData: WBSData,
    towerId: string,
    floorId: string,
    isRecalculate: boolean = false
  ): Observable<any> {
    if (wbsData.wbsId) {
      let wbsId = wbsData.wbsId;
      return this.apiService
        .put(eval("`" + this.config.updateIntWBSLineItem + "`"), {
          wbs: wbsData,
          isRecalculate: isRecalculate,
        })
        .pipe(map((data) => data));
    } else {
      return this.apiService
        .post(eval("`" + this.config.createIntWBSLineItem + "`"), {
          wbs: wbsData,
        })
        .pipe(map((data) => data));
    }
  }

  updateExteriorWBSLineItem(
    projectId: string,
    wbsData: WBSData,
    towerId: string
  ): Observable<any> {
    if (wbsData.wbsId) {
      let wbsId = wbsData.wbsId;
      return this.apiService
        .put(eval("`" + this.config.updateExtWBSLineItem + "`"), {
          wbs: wbsData,
        })
        .pipe(map((data) => data));
    } else {
      return this.apiService
        .post(eval("`" + this.config.createExtWBSLineItem + "`"), {
          wbs: wbsData,
        })
        .pipe(map((data) => data));
    }
  }

  updatePerformanceIndex(
    projectId: string,
    type: string,
    performanceIndex: any
  ): Observable<any> {
    return this.apiService
      .put(eval("`" + this.config.updatePerformanceIndex + "`"), {
        performanceIndex: performanceIndex,
      })
      .pipe(map((data) => data));
  }
}
