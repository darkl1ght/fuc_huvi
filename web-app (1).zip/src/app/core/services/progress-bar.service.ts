import { ComponentRef, Injectable } from "@angular/core";
import { DynamicMessageComponent } from "src/app/layout/components/dynamic-message/dynamic-message.component";
//cdk
import { Overlay, OverlayRef } from "@angular/cdk/overlay";
import { ComponentPortal } from "@angular/cdk/portal";
import { MatProgressSpinner } from "@angular/material/progress-spinner";

//rxjs
import { Observable, of, Subject } from "rxjs";
import { scan, map, distinctUntilChanged } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class UiService {
  private spinnerOverlayRef: OverlayRef;
  private spin$: Subject<number> = new Subject();
  private spin2$: Observable<number>;
  private ref: ComponentRef<MatProgressSpinner>;
  private overlayRef: OverlayRef;

  constructor(private overlay: Overlay) {
    this.spinnerOverlayRef = this.overlay.create({
      hasBackdrop: true,
      positionStrategy: this.overlay
        .position()
        .global()
        .centerHorizontally()
        .centerVertically(),
    });

    this.spin$
      .asObservable()
      .pipe(
        scan((acc, next) => {
          if (!next) return 0;
          return acc + next >= 0 ? acc + next : 0;
        }, 0),
        map((val) => val > 0),
        distinctUntilChanged()
      )
      .subscribe((res) => {
        if (res) {
          let ref = this.spinnerOverlayRef.attach(
            new ComponentPortal(MatProgressSpinner)
          );
          ref.instance.mode = "indeterminate";
        } else if (this.spinnerOverlayRef.hasAttached()) {
          this.spinnerOverlayRef.detach();
        }
      });
  }
  show() {
    this.spin$.next(1);
  }
  hide() {
    this.spin$.next(-1);
  }
  reset() {
    this.spin$.next(0);
  }

  showDeteminate(time) {
    const array = new Array(time + 1).fill(1);
    this.spin2$ = of(...array);
    this.spin2$
      .pipe(
        scan((total, n) => total + n),
        // map((total) => total),
        distinctUntilChanged()
      )
      .subscribe((res) => {
        if (!this.spinnerOverlayRef.hasAttached()) {
          this.ref = this.spinnerOverlayRef.attach(
            new ComponentPortal(MatProgressSpinner)
          );
          this.ref.instance.mode = "determinate";
        }
        if (res <= time) {
          setTimeout(() => {}, 1000);
          this.ref.instance.value = (res / time) * 100;
        } else if (this.spinnerOverlayRef.hasAttached()) {
          this.spinnerOverlayRef.detach();
        }
      });
  }
  hideDeteminate() {}

  showOverlay() {
    if (!this.overlayRef) {
      this.overlayRef = this.overlay.create({
        hasBackdrop: true,
        positionStrategy: this.overlay
          .position()
          .global()
          .centerHorizontally()
          .centerVertically(),
      });
    }
    const messagePortal = new ComponentPortal(DynamicMessageComponent);
    this.overlayRef.attach(messagePortal);
  }

  hideOverlay() {
    if (!!this.overlayRef) {
      this.overlayRef.detach();
    }
  }
}
