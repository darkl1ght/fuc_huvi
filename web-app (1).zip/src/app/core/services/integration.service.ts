import { Inject, Injectable } from "@angular/core";
import * as CryptoJS from "crypto-js";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { ApiService } from "./api.service";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import {
  ProcoreTokenExchangePayload,
  ProcoreCompany,
  ProcoreProject,
  ProcoreToken,
  ProcoreObservationType,
  ProcoreProjectUser,
  ProcoreProjectLocation,
  ProcoreTrade,
  ProcoreSpecSection,
  ProcoreContributingCondition,
  ProcoreContributingBehavior,
  ProcoreHazard,
  LinkedProject,
  UpdateObservationDistributionMembersPayload,
} from "../models/integration.model";

@Injectable({
  providedIn: "root",
})
export class IntegrationService {
  readonly PROCORE_ACCESS_TOKEN: string = "procore_access";
  readonly PROCORE_REFRESH_TOKEN: string = "procore_refresh";
  readonly PROCORE_AUTH_STATE: string = "auth_state";
  readonly PROCORE_AUTH_CODE_VERIFIER: string = "auth_code_verifier";

  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  procoreLogin() {
    const state = this.randomStr(40);
    const codeVerifier = this.randomStr(128);
    this.setProcoreAuthState(state);
    this.setProcoreAuthCodeVerifier(codeVerifier);
    const codeVerifierHash = CryptoJS.SHA256(codeVerifier).toString(
      CryptoJS.enc.Base64
    );
    const codeChallenge = codeVerifierHash
      .replace(/=/g, "")
      .replace(/\+/g, "-")
      .replace(/\//g, "_");
    const redirectUri = encodeURIComponent(
      `${this.config.procoreRedirectUri}?goback=${window.location.href}`
    );

    const params = [
      `response_type=code`,
      `state=${state}`,
      `client_id=${this.config.procoreClientId}`,
      `code_challenge=${codeChallenge}`,
      `code_challenge_method=S256`,
      `redirect_uri=${redirectUri}`,
    ];

    let url = `${this.config.procoreLoginUrl}?${params.join("&")}`;
    window.location.href = url;
  }

  setProcoreAuthState(token: string) {
    window.localStorage.setItem(this.PROCORE_AUTH_STATE, token);
  }

  getProcoreAuthState(): string {
    return window.localStorage.getItem(this.PROCORE_AUTH_STATE);
  }

  setProcoreAuthCodeVerifier(token: string) {
    window.localStorage.setItem(this.PROCORE_AUTH_CODE_VERIFIER, token);
  }

  getProcoreAuthCodeVerifier(): string {
    return window.localStorage.getItem(this.PROCORE_AUTH_CODE_VERIFIER);
  }

  setProcoreAccessToken(token: string) {
    window.localStorage.setItem(this.PROCORE_ACCESS_TOKEN, token);
  }

  setProcoreRefreshToken(token: string) {
    window.localStorage.setItem(this.PROCORE_REFRESH_TOKEN, token);
  }

  getProcoreAccessToken(): string {
    return window.localStorage.getItem(this.PROCORE_ACCESS_TOKEN);
  }

  getProcoreRefreshToken() {
    return window.localStorage.getItem(this.PROCORE_REFRESH_TOKEN);
  }

  getProcoreTokens() {
    return [this.getProcoreAccessToken(), this.getProcoreRefreshToken()];
  }

  isProcoreConnected() {
    return this.getProcoreAccessToken() && this.getProcoreRefreshToken();
  }

  removeProcoreTokens() {
    window.localStorage.removeItem(this.PROCORE_ACCESS_TOKEN);
    window.localStorage.removeItem(this.PROCORE_REFRESH_TOKEN);
  }

  procoreTokenExchange(
    payload: ProcoreTokenExchangePayload
  ): Observable<ProcoreToken> {
    if (payload) {
      return this.apiService.post(this.config.procoreTokenExchange, payload);
    }
  }

  refreshProcoreToken(): Observable<ProcoreToken> {
    const access_token = this.getProcoreAccessToken();
    const refresh_token = this.getProcoreRefreshToken();

    if (access_token && refresh_token) {
      return this.apiService
        .post(this.config.procoreTokenRefresh, { access_token, refresh_token })
        .pipe(
          map((data) => {
            this.setProcoreAccessToken(data.access_token);
            this.setProcoreRefreshToken(data.refresh_token);
            return data;
          })
        );
    }
  }

  getProcoreCompanies(): Observable<ProcoreCompany[]> {
    return this.apiService.get(this.config.getProcoreCompanies);
  }

  procoreLinkProject(
    projectId: string,
    linkedProject: LinkedProject
  ): Observable<any> {
    if (projectId && linkedProject) {
      return this.apiService.post(
        eval("`" + this.config.procoreLinkProject + "`"),
        {
          linkedProject,
        }
      );
    }
  }

  getProcoreLinkedProject(
    projectId: string
  ): Observable<{ procoreIntegration: LinkedProject }> {
    if (projectId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreLinkedProject + "`")
      );
    }
  }

  getProcoreProjectUsers(
    companyId: number,
    projectId: number
  ): Observable<ProcoreProjectUser[]> {
    if (companyId && projectId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreProjectUsers + "`")
      );
    }
  }

  getProcoreProjectLocations(
    companyId: number,
    projectId: number
  ): Observable<ProcoreProjectLocation[]> {
    if (companyId && projectId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreProjectLocations + "`")
      );
    }
  }

  getProcoreCompanyTrades(companyId: number): Observable<ProcoreTrade[]> {
    if (companyId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreCompanyTrades + "`")
      );
    }
  }

  getProcoreProjectSpecSections(
    companyId: number,
    projectId: number
  ): Observable<ProcoreSpecSection[]> {
    if (companyId && projectId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreProjectSpecSections + "`")
      );
    }
  }

  addProcoreObservation(
    companyId: number,
    formData: FormData
  ): Observable<any> {
    if (formData) {
      const options = {
        headers: {
          "Procore-Company-Id": companyId.toString(),
        },
      };

      return this.apiService.postFile(
        this.config.addProcoreObservation,
        formData,
        options
      );
    }
  }

  updateProcoreObservationDistributionMembers(
    companyId: number,
    observationId: number,
    payload: UpdateObservationDistributionMembersPayload
  ): Observable<any> {
    if (payload) {
      const options = {
        headers: {
          "Procore-Company-Id": companyId.toString(),
          "Content-Type": "application/json",
        },
      };

      return this.apiService.patch(
        eval(
          "`" + this.config.updateProcoreObservationDistributionMembers + "`"
        ),
        payload,
        options
      );
    }
  }

  private randomStr(length: number) {
    let rnd = "";
    const chars =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const charsLength = chars.length;

    for (let i = 0; i < length; i++) {
      rnd += chars.charAt(Math.floor(Math.random() * charsLength));
    }

    return rnd;
  }

  getProcoreCompanyObservationTypes(
    companyId: number
  ): Observable<ProcoreObservationType[]> {
    if (companyId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreCompanyObservationTypes + "`")
      );
    }
  }

  getProcoreCompanyContributingConditions(
    companyId: number
  ): Observable<ProcoreContributingCondition[]> {
    if (companyId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreCompanyContributingConditions + "`")
      );
    }
  }

  getProcoreCompanyContributingBehaviors(
    companyId: number
  ): Observable<ProcoreContributingBehavior[]> {
    if (companyId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreCompanyContributingBehaviors + "`")
      );
    }
  }

  getProcoreCompanyHazards(companyId: number): Observable<ProcoreHazard[]> {
    if (companyId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreCompanyHazards + "`")
      );
    }
  }

  getProcoreCompanyProjects(companyId: number): Observable<ProcoreProject[]> {
    if (companyId) {
      return this.apiService.get(
        eval("`" + this.config.getProcoreCompanyProjects + "`")
      );
    }
  }
}
