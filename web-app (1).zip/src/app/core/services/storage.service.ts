import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class StorageService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getBlobToken(container: string, blobName: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getBlobToken + "`"));
    }
  }

  getToken(container: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getToken + "`"));
    }
  }

  getReadToken(container: string): Observable<any> {
    if (container) {
      return this.apiService.get(eval("`" + this.config.getReadToken + "`"));
    }
  }
}
