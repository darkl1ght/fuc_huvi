import { Injectable } from "@angular/core";
import {
  ActivatedRoute,
  ActivatedRouteSnapshot,
  CanActivate,
  NavigationEnd,
  Params,
  Router,
  RouterStateSnapshot,
} from "@angular/router";

import { UserService } from "./user.service";
import { filter, first, map, take, tap } from "rxjs/operators";
import { Observable } from "rxjs/internal/Observable";
import { LocalStorageService } from "./local-storage.service";

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private localStorage: LocalStorageService
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let isAuthenticated = false;

    this.activatedRoute.queryParams.subscribe((params: Params) => {
      if (!!params && !!params["share"]) {
        const shareId = this.getParameterByName("share");
        if (!!shareId) {
          this.localStorage.setShareId(shareId);
        }
      } else if (!!params && !!params["returnUrl"]) {
        const url = params["returnUrl"];
        const returnUrlSubString = url.substring(url.indexOf("?"));
        if (returnUrlSubString.includes("share")) {
          const queryParams = new URLSearchParams(returnUrlSubString);
          const shareId = queryParams.get("share");
          if (!!shareId) {
            this.localStorage.setShareId(shareId);
          }
        }
      }
    });
    this.userService.isAuthenticated.pipe(first()).subscribe(
      (data) => {
        isAuthenticated = data;
      },
      (error) => {
        isAuthenticated = false;
      }
    );

    if (isAuthenticated) {
      return true;
    }

    //browser refresh handle

    if (!isAuthenticated && this.userService.hasToken()) {
      return true;
    }

    // not logged in so redirect to login page with the return url
    this.router.navigate(["/login"], { queryParams: { returnUrl: state.url } });
    return false;
  }

  private getParameterByName(name: string, url?: string) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
  }
}
