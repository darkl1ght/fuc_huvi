import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router } from "@angular/router";
import { LocalStorageService } from "./local-storage.service";
import { UserService } from "./user.service";

@Injectable()
export class RoleGuard implements CanActivate {
  constructor(
    private userService: UserService,
    public router: Router,
    private localStorage: LocalStorageService
  ) {}
  canActivate(route: ActivatedRouteSnapshot): boolean {
    const user = this.userService.getCurrentUser();
    const currentUserRole = this.localStorage.getUserRole();
    let isAuthenticated = this.userService.getIsAuthenticated();
    let proceed = false;

    if (isAuthenticated) {
      if (user.isAdmin) {
        proceed = true;
      } else {
        //Use one of either blocked or allowed only
        if (route.data?.roles?.blocked?.length > 0) {
          if (route.data.roles.blocked.includes(currentUserRole)) {
            proceed = false;
          } else {
            proceed = true;
          }
        } else if (route.data?.roles?.allowed?.length > 0) {
          if (route.data.roles.allowed.includes(currentUserRole)) {
            proceed = true;
          } else {
            proceed = false;
          }
        } else {
          proceed = false;
        }
      }
    } else {
      proceed = false;
    }

    if (!proceed) {
      this.router.navigate(["login"]);
    }

    return proceed;
  }
}
