import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { Client } from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class ClientService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getClients(): Observable<{ clients: Client[] }> {
    return this.apiService.get(eval("`" + this.config.getClients + "`"));
  }

  getClient(clientId): Observable<{ client: Client }> {
    return this.apiService.get(eval("`" + this.config.getClient + "`"));
  }

  removeClient(clientId: string) {
    return this.apiService.delete(eval("`" + this.config.removeClient + "`"));
  }

  saveClient(client: Client): Observable<Client> {
    if (client.clientId) {
      let clientId = client.clientId;
      return this.apiService
        .put(eval("`" + this.config.updateClient + "`"), {
          client: client,
        })
        .pipe(map((data) => data.client));
    } else {
      return this.apiService
        .post(eval("`" + this.config.createClient + "`"), {
          client: client,
        })
        .pipe(map((data) => data.client));
    }
  }
}
