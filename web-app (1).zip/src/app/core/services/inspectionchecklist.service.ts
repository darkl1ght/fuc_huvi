import { Injectable, Inject } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable({
  providedIn: "root",
})
export class InspectionCheckListService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getAllInspectionCheckList(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.get(
        eval("`" + this.config.getAllInspectionCheckList + "`")
      );
    }
  }

  saveInspectionCheckList(
    projectId: string,
    inspectionCheckList
  ): Observable<any> {
    if (inspectionCheckList.inspectionId) {
      let inspectionId = inspectionCheckList.inspectionId;
      return this.apiService
        .put(eval("`" + this.config.updateInspectionCheckList + "`"), {
          inspectionCheckList: inspectionCheckList,
        })
        .pipe(map((data) => data.project));
    } else {
      return this.apiService
        .post(eval("`" + this.config.saveInspectionCheckList + "`"), {
          inspectionCheckList: inspectionCheckList,
        })
        .pipe(map((data) => data));
    }
  }

  deleteInspectionCheckList(projectId, inspectionId) {
    return this.apiService.delete(
      eval("`" + this.config.deleteInspectionCheckList + "`")
    );
  }
}
