import { Injectable, Inject } from "@angular/core";
import { HttpEvent, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { HttpHeaders } from "@azure/core-http";

@Injectable()
export class ForgeService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getForgeViewerToken(): Observable<any> {
    return this.apiService.get(eval("`" + this.config.getForgeAuthToken + "`"));
  }

  getForgeBucket(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService.post(eval("`" + this.config.getForgeBucket + "`"));
    }
  }

  uploadObjectToForge(
    projectId: string,
    locationId: string,
    file: File,
    updateChild: boolean
  ): Observable<HttpEvent<any>> {
    if (projectId && locationId) {
      let postUrl = eval("`" + this.config.uploadForgeObject + "`");
      const formData: FormData = new FormData();
      formData.append("file", file, file.name);
      formData.append("updateChild", updateChild ? "yes" : "no");
      return this.apiService.postFile(postUrl, formData, {
        reportProgress: true,
        observe: "events",
      });
    }
  }

  deleteForgeObject(
    projectId: string,
    locationId: string,
    updateChildLocations: boolean
  ): Observable<any> {
    if (projectId && locationId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteForgeObject + "`"),
        { updateChildLocations: updateChildLocations ? "yes" : "no" }
      );
    }
  }

  getForgeObjectManifest(urn: string): Observable<any> {
    if (urn) {
      return this.apiService.get(
        eval("`" + this.config.getForgeObjectManifest + "`")
      );
    }
  }
}
