import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class LiveStreamService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getDevice(projectId: string): Observable<any> {
    return this.apiService.get(eval("`" + this.config.getDeviceList + "`"));
  }

  destroy(projectId: string, deviceId: string) {
    return this.apiService.delete(eval("`" + this.config.deleteDevice + "`"));
  }

  save(projectId: string, device: any): Observable<string> {
    return this.apiService
      .post(eval("`" + this.config.saveDeviceList + "`"), { device: device })
      .pipe(map((data) => data.project));
  }
}
