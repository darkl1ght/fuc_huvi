import { Inject, Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { EncryptionService } from "./encryption.service";

@Injectable({
  providedIn: "root",
})
export class LocalStorageService {
  localStorage: Storage;
  clientKey: string = "client";
  projectKey: string = "project";
  accessMappingKey: string = "accessMapping";
  shareKey: string = "share";
  libFolderKey: string = "libFolderId";
  mediaFolderKey: string = "mediaFolderId";
  weatherKey: string = "weather";
  changes$ = new Subject();

  constructor(
    @Inject(APP_CONFIG) private config: AppConfig,
    private encryptionService: EncryptionService
  ) {
    this.localStorage = window.localStorage;
  }

  setItem(key: string, value: any): void {
    if (this.config.enableEncryption) {
      var encryptedValue = this.encryptionService.encrypt(
        key,
        JSON.stringify(value)
      );
      this.localStorage.setItem(key, JSON.stringify(encryptedValue));
    } else {
      this.localStorage.setItem(key, JSON.stringify(value));
    }
  }

  getItem(key: string): any {
    try {
      const item = this.localStorage.getItem(key);
      if (this.config.enableEncryption) {
        const decryptedValue = JSON.parse(
          this.encryptionService.decrypt(key, item)
        );
        if (typeof decryptedValue == "string") {
          return JSON.parse(decryptedValue).replaceAll('"', "");
        } else {
          return decryptedValue;
        }
      } else {
        return JSON.parse(item);
      }
    } catch (e) {
      return null;
    }
  }

  removeItem(key: string): any {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      return null;
    }
  }

  getClientId(): any {
    if (this.isLocalStorageSupported) {
      return this.getItem(this.clientKey);
    }
    return null;
  }

  setClientId(value: any): boolean {
    let key: string = this.clientKey;
    if (this.isLocalStorageSupported) {
      this.setItem(key, JSON.stringify(value));
      this.changes$.next({
        type: "set",
        key,
        value,
      });
      return true;
    }
    return false;
  }

  removeClient(): boolean {
    let key: string = this.clientKey;
    if (this.isLocalStorageSupported) {
      this.removeItem(this.clientKey);
      this.changes$.next({
        type: "remove",
        key,
      });
      return true;
    }

    return false;
  }

  getShareId(): any {
    if (this.isLocalStorageSupported) {
      return this.getItem(this.shareKey);
    }
    return null;
  }

  setShareId(value: any): boolean {
    let key: string = this.shareKey;
    if (this.isLocalStorageSupported) {
      this.setItem(key, JSON.stringify(value));
      this.changes$.next({
        type: "set",
        key,
        value,
      });
      return true;
    }
    return false;
  }

  removeShareId(): boolean {
    let key: string = this.shareKey;
    if (this.isLocalStorageSupported) {
      this.removeItem(key);
      this.changes$.next({
        type: "remove",
        key,
      });
      return true;
    }

    return false;
  }

  getProjectId(): any {
    if (this.isLocalStorageSupported) {
      return this.getItem(this.projectKey);
    }
    return null;
  }

  setProjectId(value: any): boolean {
    let key: string = this.projectKey;
    if (this.isLocalStorageSupported) {
      this.setItem(key, JSON.stringify(value));
      this.changes$.next({
        type: "set",
        key,
        value,
      });
      return true;
    }
    return false;
  }

  removeProjectId(): boolean {
    let key: string = this.projectKey;
    if (this.isLocalStorageSupported) {
      this.removeItem(key);
      this.changes$.next({
        type: "remove",
        key,
      });
      return true;
    }

    return false;
  }

  getAccessMapping(): any {
    if (this.isLocalStorageSupported) {
      return this.getItem(this.accessMappingKey);
    }
    return null;
  }
  getUserRole(): string {
    if (this.isLocalStorageSupported) {
      return this.getItem(this.accessMappingKey)?.role;
    }
    return null;
  }
  setAccessMapping(value: any): boolean {
    let key: string = this.accessMappingKey;
    if (this.isLocalStorageSupported) {
      this.setItem(key, value);
      this.changes$.next({
        type: "set",
        key,
        value,
      });
      return true;
    }
    return false;
  }
  removeAccessMapping(): boolean {
    let key: string = this.accessMappingKey;
    if (this.isLocalStorageSupported) {
      this.removeItem(key);
      this.changes$.next({
        type: "remove",
        key,
      });
      return true;
    }
    return false;
  }

  getLibraryFolderId(): any {
    if (this.isLocalStorageSupported) {
      return this.getItem(this.libFolderKey);
    }
    return null;
  }

  setMediaFolderId(value: any): boolean {
    let key: string = this.mediaFolderKey;
    if (this.isLocalStorageSupported) {
      this.setItem(key, JSON.stringify(value));
      this.changes$.next({
        type: "set",
        key,
        value,
      });
      return true;
    }
    return false;
  }

  setLibraryFolderId(value: any): boolean {
    let key: string = this.libFolderKey;
    if (this.isLocalStorageSupported) {
      this.setItem(key, JSON.stringify(value));
      this.changes$.next({
        type: "set",
        key,
        value,
      });
      return true;
    }
    return false;
  }

  removeLibraryFolderId(): boolean {
    let key: string = this.libFolderKey;
    if (this.isLocalStorageSupported) {
      this.removeItem(key);
      this.changes$.next({
        type: "remove",
        key,
      });
      return true;
    }

    return false;
  }

  getWeather(lat: string, lng: string): any {
    if (this.isLocalStorageSupported) {
      this.clearExpiredWeather();
      const data: any[] = this.getItem(this.weatherKey);

      if (data && data.length > 0) {
        const filteredData: any[] = data.filter((item) => {
          return (
            parseFloat(item.lat).toFixed(3) == parseFloat(lat).toFixed(3) &&
            parseFloat(item.lon).toFixed(3) == parseFloat(lng).toFixed(3)
          );
        });

        if (filteredData && filteredData.length > 0) {
          return filteredData[0];
        }
      }
    }
    return null;
  }

  private clearExpiredWeather(): any {
    if (this.isLocalStorageSupported) {
      const weather = this.getItem(this.weatherKey);

      if (weather) {
        const currentTime = new Date().getTime() / 1000;
        const filteredWeather = weather.filter(
          (item: any) =>
            item.current.dt >
            currentTime -
              parseInt(this.config.weatherDataLocalStorageExpiryDuration)
        );
        this.setItem(this.weatherKey, filteredWeather);
      }
    }
  }

  setWeather(value: any): boolean {
    let key: string = this.weatherKey;

    if (this.isLocalStorageSupported) {
      const weather: any[] = this.getItem(this.weatherKey);

      if (weather) {
        weather.push(value);
        this.setItem(this.weatherKey, weather);
      } else {
        const toStore: any[] = [];
        toStore.push(value);
        this.setItem(this.weatherKey, toStore);
      }

      this.changes$.next({
        type: "set",
        key,
        value,
      });
      return true;
    }
    return false;
  }

  removeWeather(): boolean {
    let key: string = this.weatherKey;

    if (this.isLocalStorageSupported) {
      this.removeItem(this.weatherKey);
      this.changes$.next({
        type: "remove",
        key,
      });
      return true;
    }

    return false;
  }

  get isLocalStorageSupported(): boolean {
    return !!this.localStorage;
  }
}
