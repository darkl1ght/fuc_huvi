import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { ForgeViewerComponentConfig } from "../models";

@Injectable({
  providedIn: "root",
})
export class BimDataService {
  private dataSource: BehaviorSubject<ForgeViewerComponentConfig> =
    new BehaviorSubject<ForgeViewerComponentConfig>(null);

  private isTourLockedDataSource: BehaviorSubject<Boolean> =
    new BehaviorSubject<Boolean>(true);

  data: Observable<ForgeViewerComponentConfig> = this.dataSource.asObservable();
  isTourLocked: Observable<Boolean> =
    this.isTourLockedDataSource.asObservable();

  constructor() {}

  sendData(
    eventType: string,
    eventData: any,
    data: ForgeViewerComponentConfig
  ) {
    const updatedData: ForgeViewerComponentConfig = {
      ...data,
      event: {
        type: eventType,
        data: eventData,
      },
    };
    this.dataSource.next(updatedData);
  }

  setTourLocked(isLocked: boolean) {
    this.isTourLockedDataSource.next(isLocked);
  }
}
