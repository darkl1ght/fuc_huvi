import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class ShareService {
  constructor() {}
  private refreshToolbarSub = new Subject<boolean>();
  refreshToolbar$ = this.refreshToolbarSub.asObservable();
  shareObject: any = null;
  getShareObject(): any {
    return this.shareObject;
  }
  setShareObject(shareObject): void {
    this.shareObject = shareObject;
  }
  refreshToolbar(refresh: boolean) {
    this.refreshToolbarSub.next(refresh);
  }
}
