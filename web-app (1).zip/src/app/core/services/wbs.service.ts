import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";

import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { JwtService } from "./jwt.service";
import { ProjectWBS } from "../models";

@Injectable()
export class WBSService {
  constructor(
    private apiService: ApiService,
    private jwtTokenSvc: JwtService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  saveWBS(
    projectId: string,
    wbsData: ProjectWBS,
    wbsType: string
  ): Observable<any> {
    if (projectId && wbsType)
      return this.apiService
        .post(eval("`" + this.config.uploadWBS + "`"), {
          wbs: { wbs: wbsData },
        })
        .pipe(map((data) => data));
  }

  getWBS(
    projectId: string,
    wbsType: string,
    towerId: string
  ): Observable<{ wbs: ProjectWBS[] }> {
    if (projectId && wbsType && towerId)
      return this.apiService.get(eval("`" + this.config.getWBS + "`"));
  }

  getWBSPublishStatus(projectId: string, wbsType: string): Observable<any> {
    if (projectId && wbsType)
      return this.apiService.get(
        eval("`" + this.config.getWBSPublishStatus + "`")
      );
  }

  publishExteriorWBS(projectId: string, wbsType: string) {
    if (projectId && wbsType)
      return this.apiService
        .put(eval("`" + this.config.publishExteriorWBS + "`"))
        .pipe(map((data) => data.status));
  }

  publishInteriorWBS(projectId: string, wbsType: string) {
    if (projectId && wbsType)
      return this.apiService
        .put(eval("`" + this.config.publishInteriorWBS + "`"))
        .pipe(map((data) => data.status));
  }

  getInteriorWBS(
    projectId: string,
    towerId: string,
    floorId: string,
    wbsType: string = "int"
  ): Observable<{ wbs: ProjectWBS[] }> {
    if (projectId && wbsType && towerId && floorId)
      return this.apiService.get(eval("`" + this.config.getInteriorWBS + "`"));
  }

  deletetInteriorWBS(
    projectId: string,
    wbsType: string,
    towerId: string,
    floorId: string
  ): Observable<any> {
    if (projectId && wbsType && towerId && floorId)
      return this.apiService.delete(
        eval("`" + this.config.deleteInteriorWBS + "`")
      );
  }

  deleteExteriorWBS(
    projectId: string,
    wbsType: string,
    towerId: string
  ): Observable<any> {
    if (projectId && wbsType && towerId)
      return this.apiService.delete(
        eval("`" + this.config.deleteExteriorWBS + "`")
      );
  }

  createDoc(file: File, projectId: string): Observable<any> {
    return Observable.create((observer) => {
      let formData: FormData = new FormData(),
        xhr: XMLHttpRequest = new XMLHttpRequest();
      xhr.onreadystatechange = () => {
        if (xhr.readyState === 4) {
          if (xhr.status === 200) {
            observer.next(JSON.parse(xhr.response));
            observer.complete();
          } else {
            observer.error(xhr.response);
          }
        }
      };

      xhr.open("POST", eval("`" + this.config.uploadWBS + "`"), true);
      xhr.setRequestHeader(
        "Authorization",
        "Bearer " + this.jwtTokenSvc.getToken()
      );
      formData.append("file", file, file.name);
      formData.append("projectId", projectId.toString());

      xhr.send(formData);
    });
  }

  getAllInteriorWBS(projectId): Observable<{ wbs: ProjectWBS[] }> {
    return this.apiService.get(eval("`" + this.config.getAllInteriorWBS + "`"));
  }

  getAllInteriorWBSByTowerIdAndFloorId(
    projectId,
    towerId,
    floorId
  ): Observable<{ wbs: ProjectWBS[] }> {
    return this.apiService.get(
      eval("`" + this.config.getAllInteriorWBSByTowerAndFloor + "`")
    );
  }

  recalculateInteriorWeightage(projectId, towerId): Observable<any> {
    if (projectId && towerId) {
      return this.apiService
        .put(eval("`" + this.config.recalculateInteriorWeightage + "`"))
        .pipe(map((data) => data.status));
    }
  }
}
