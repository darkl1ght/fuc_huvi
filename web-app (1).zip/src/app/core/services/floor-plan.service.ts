import { EventEmitter, Inject, Injectable } from "@angular/core";
import * as L from "leaflet";
import "leaflet";
import "leaflet-polylinedecorator";
import "@geoman-io/leaflet-geoman-free";
import { AppConfig, APP_CONFIG } from "src/config/app-config.module";
import { TourImage, UiService, InteriorService } from "src/app/core";
import { BehaviorSubject, Observable } from "rxjs";
const math = require("mathjs");
import * as turf from "@turf/turf";
import { PathConfigButton } from "src/app/layout/project/detail/components/interior/walkthrough/floor-plan-config/path-config-button";

@Injectable({
  providedIn: "root",
})
export class FloorPlanService {
  floorPlanMap: L.Map;
  polylineLayer: L.Polyline;
  simplifiedPolyline: L.Polyline;
  arrowLayerGroup: L.LayerGroup;

  pathConfigButtonClickEmitter = new EventEmitter();

  private requiresSave = new BehaviorSubject<boolean>(false);
  private isStartOrEndPointUpdated: boolean = false;

  private updatedStartPoint: { x: number; y: number };
  private updatedEndPoint: { x: number; y: number };

  private originalCoordinates: any;
  private exportedCoordinates: any;
  private updatedCoordinates: any;
  private startPointMarker: L.Marker;
  private endPointMarker: L.Marker;
  private isStartEndPointUpdateMode: boolean = false;

  constructor(
    private uiService: UiService,
    private interiorService: InteriorService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getTokenAndLoadFloorPlan(tour: TourImage) {
    const container = this.config.floorPlanContainer;
    this.interiorService
      .getBlobToken(container, tour.floorPlanBlobId)
      .subscribe(
        (data) => {
          this.uiService.hide();
          const imageUrl = data.sasToken.uri;
          this.loadFloorPlan(imageUrl, tour);
        },
        (err) => {}
      );
  }

  loadFloorPlan(blobUrl: string, tour: TourImage) {
    this.uiService.show();

    try {
      this.floorPlanMap = L.map("floor-plan", {
        crs: L.CRS.Simple,
        minZoom: -5,
        maxBoundsViscosity: 1,
      });

      this.floorPlanMap.pm.addControls({
        position: "topleft",
        drawCircle: false,
        drawControls: false,
        cutPolygon: false,
        removalMode: false,
        rotateMode: false,
        preventMarkerRemoval: true,
        hideMiddleMarkers: true,
        dragMode: false,
        editMode: false,
      });

      // Disable the global edit mode
      this.floorPlanMap.pm.setGlobalOptions({ editable: false });
      if (!!tour.videoCaptureDetails) {
        new PathConfigButton(
          { position: "topleft" },
          this.pathConfigButtonClickEmitter
        ).addTo(this.floorPlanMap);

        this.pathConfigButtonClickEmitter.subscribe(() => {
          this.isStartEndPointUpdateMode = !this.isStartEndPointUpdateMode;
          if (this.isStartEndPointUpdateMode) {
            this.cleanUpEditPolylineMode();
            this.addMarkers(tour.videoCaptureDetails, tour.features);
          } else {
            this.cleanUpStartEndPointPolylineMode();
            this.drawPolyLineFromCoordinates(tour.features);
          }
        });
      }
      const imageUrl = blobUrl;
      const img = new Image();
      img.id = "mapImage";
      img.src = imageUrl;
      img.onload = () => {
        const w = img.width;
        const h = img.height;
        const bounds: any = [
          [-10, -10],
          [h, w],
        ];
        L.imageOverlay(imageUrl, bounds).addTo(this.floorPlanMap);
        this.floorPlanMap.fitBounds(bounds);
        this.floorPlanMap.setMaxBounds(bounds);

        this.drawPolyLineFromCoordinates(tour.features);

        this.uiService.hide();
      };
    } catch (error) {
      this.uiService.hide();
    }
  }

  addMarkers(
    { captureStartPoint, captureEndPoint, exportedCoordinates }: any,
    features: any
  ) {
    this.exportedCoordinates = exportedCoordinates;

    this.updatedStartPoint = captureStartPoint;
    this.updatedEndPoint = captureEndPoint;

    this.addDragListeners();
    this.calculateCoordinatesAndDrawPolyline(exportedCoordinates);
  }

  addDragListeners() {
    if (
      this.startPointMarker &&
      this.floorPlanMap.hasLayer(this.startPointMarker)
    ) {
      this.floorPlanMap.removeLayer(this.startPointMarker);
    }
    if (
      this.endPointMarker &&
      this.floorPlanMap.hasLayer(this.endPointMarker)
    ) {
      this.floorPlanMap.removeLayer(this.endPointMarker);
    }
    let icon = L.icon({
      iconUrl: "assets/images/pin.png",
      iconSize: [32, 32],
    });
    this.startPointMarker = L.marker(
      [this.updatedStartPoint.y, this.updatedStartPoint.x],
      { draggable: true, icon }
    ).addTo(this.floorPlanMap);

    this.endPointMarker = L.marker(
      [this.updatedEndPoint.y, this.updatedEndPoint.x],
      {
        draggable: true,
        icon,
      }
    ).addTo(this.floorPlanMap);

    // bind a popup to the marker
    this.startPointMarker
      .bindTooltip("Start point", { permanent: true, direction: "bottom" })
      .openTooltip();
    this.endPointMarker
      .bindTooltip("End point", { permanent: true, direction: "bottom" })
      .openTooltip();

    this.startPointMarker.on("dragend", (event) => {
      if (this.updatedCoordinates != null) this.updatedCoordinates = null;

      const marker = event.target;
      const position = marker.getLatLng();
      this.updatedStartPoint = {
        x: position.lng,
        y: position.lat,
      };

      this.calculateCoordinatesAndDrawPolyline(this.exportedCoordinates);
      this.setRequiresSave(true);
      this.isStartOrEndPointUpdated = true;
    });

    this.endPointMarker.on("dragend", (event) => {
      if (this.updatedCoordinates != null) this.updatedCoordinates = null;

      const marker = event.target;
      const position = marker.getLatLng();

      this.updatedEndPoint = {
        x: position.lng,
        y: position.lat,
      };

      this.calculateCoordinatesAndDrawPolyline(this.exportedCoordinates);
      this.setRequiresSave(true);
      this.isStartOrEndPointUpdated = true;
    });
  }

  cleanUpEditPolylineMode() {
    this.updatedCoordinates = null;
    this.floorPlanMap.removeLayer(this.arrowLayerGroup);
    this.floorPlanMap.removeLayer(this.simplifiedPolyline);
  }

  cleanUpStartEndPointPolylineMode() {
    this.floorPlanMap.removeLayer(this.startPointMarker);
    this.floorPlanMap.removeLayer(this.endPointMarker);
    this.floorPlanMap.removeLayer(this.polylineLayer);
  }

  drawPolyLineFromCoordinates(data) {
    this.arrowLayerGroup = L.layerGroup().addTo(this.floorPlanMap);
    let features = data.features;
    let coordinates = [];
    for (var i = 0; i < features.length; i++) {
      coordinates.push([
        features[i].geometry.coordinates[1],
        features[i].geometry.coordinates[0],
      ]);
    }

    this.originalCoordinates = coordinates;
    this.polylineLayer = L.polyline(coordinates, {
      color: "#800080",
      weight: 5,
      opacity: 0.65,
    });

    this.polylineLayer.addTo(this.floorPlanMap);

    // Convert the Leaflet polyline to a GeoJSON LineString
    var lineString = turf.lineString(
      this.polylineLayer.getLatLngs().map((latLng) => [latLng.lng, latLng.lat])
    );

    // Convert the lineString  to a Leaflet polyline
    this.simplifiedPolyline = L.polyline(
      lineString.geometry.coordinates.map((coord) => [coord[1], coord[0]]),
      { color: "red" }
    ).addTo(this.floorPlanMap);

    this.floorPlanMap.removeLayer(this.polylineLayer);

    this.simplifiedPolyline.pm.enable();

    // Add arrows to the map
    //@ts-ignore
    L.polylineDecorator(this.simplifiedPolyline, {
      patterns: [
        {
          offset: "0%",
          repeat: 30,
          //@ts-ignore
          symbol: L.Symbol.arrowHead({
            pixelSize: 10,
            polygon: false,
            pathOptions: { stroke: true },
          }),
        },
      ],
    }).addTo(this.arrowLayerGroup);

    this.arrowLayerGroup.pm.setOptions({ allowEditing: false });

    // listen to when a layer is changed in Edit Mode
    this.simplifiedPolyline.on("pm:edit", (e: any) => {
      this.updatedCoordinates = null;
      this.setRequiresSave(true);
      this.updatedCoordinates = e.target._latlngs;

      this.arrowLayerGroup.clearLayers();

      // Update arrows in edit mode
      //@ts-ignore
      L.polylineDecorator(this.updatedCoordinates, {
        patterns: [
          {
            offset: "0%",
            repeat: 50,
            //@ts-ignore
            symbol: L.Symbol.arrowHead({
              pixelSize: 10,
              polygon: false,
              pathOptions: { stroke: true },
            }),
          },
        ],
      }).addTo(this.arrowLayerGroup);

      let originalPolylineLength = this.getOriginalPolyLineLength();

      let editedPolylineCoords = this.simplifiedPolyline
        .getLatLngs()
        .map((latlng) => [latlng.lng, latlng.lat]);

      let editedPolylineLength =
        this.getEditedPolyLineLength(editedPolylineCoords);

      this.updatedCoordinates = this.originalCoordinates.map((coord, index) => {
        if (index === 0) {
          return editedPolylineCoords[0];
        } else if (index === this.originalCoordinates.length - 1) {
          return editedPolylineCoords[editedPolylineCoords.length - 1];
        } else {
          let distanceAlongOriginal = this.originalCoordinates
            .slice(0, index)
            .reduce(
              (acc, coord, index) =>
                acc +
                this.getDistance(coord, this.originalCoordinates[index + 1]),
              0
            );

          let ratio = distanceAlongOriginal / originalPolylineLength;
          let distanceAlongEdited = ratio * editedPolylineLength;

          let remainingDistance = distanceAlongEdited;
          for (let i = 0; i < editedPolylineCoords.length - 1; i++) {
            let segmentLength = this.getDistance(
              editedPolylineCoords[i],
              editedPolylineCoords[i + 1]
            );
            if (remainingDistance <= segmentLength) {
              let fraction = remainingDistance / segmentLength;
              return this.interpolate(
                editedPolylineCoords[i],
                editedPolylineCoords[i + 1],
                fraction
              );
            }
            remainingDistance -= segmentLength;
          }
        }
      });
    });

    this.floorPlanMap.on("pm:globaleditmodetoggled", (e) => {
      if (!e.enabled) this.addDragListeners();
    });

    let self = this; // to access the current scope instead of leaflet scope
    let coordinatesToMap = this.polylineLayer.getLatLngs();

    this.floorPlanMap.eachLayer(function (layer) {
      if (layer instanceof L.Marker) {
        if (self.floorPlanMap.getBounds().contains(layer.getLatLng())) {
          var isCoordinateMatched = coordinatesToMap?.findIndex(
            (co) =>
              co.lat == layer.getLatLng().lat && co.lng == layer.getLatLng().lng
          );
          if (isCoordinateMatched != -1) {
            layer.setIcon(self.getMarkerIcon(isCoordinateMatched + 1));
          }
        }
      }
    });
  }

  calculateCoordinatesAndDrawPolyline(exportedCoordinates) {
    // Remove existing layer if any
    if (this.polylineLayer) this.floorPlanMap.removeLayer(this.polylineLayer);

    // Agisoft coordinate system
    let { x: x1, y: y1 } = {
      x: exportedCoordinates[0]["X-Coordinate"],
      y: exportedCoordinates[0]["Y-Coordinate"],
    };
    let { x: x2, y: y2 } = {
      x: exportedCoordinates[exportedCoordinates.length - 1]["X-Coordinate"],
      y: exportedCoordinates[exportedCoordinates.length - 1]["Y-Coordinate"],
    };

    // Floor plan coordinate system
    let { x: x1n, y: y1n } = {
      x: this.updatedStartPoint.x,
      y: this.updatedStartPoint.y,
    };
    let { x: x2n, y: y2n } = {
      x: this.updatedEndPoint.x,
      y: this.updatedEndPoint.y,
    };

    let matrix1 = math.matrix([
      [x1, y1, 1, 0],
      [-y1, x1, 0, 1],
      [x2, y2, 1, 0],
      [-y2, x2, 0, 1],
    ]);

    let matrix2 = math.matrix([x1n, y1n, x2n, y2n]);

    // a,b,c,d values from the linear equations (ax+by+c) (bx-ay+d)
    let newMatrix = math.multiply(math.inv(matrix1), matrix2);

    let a = newMatrix.get([0]);
    let b = newMatrix.get([1]);
    let c = newMatrix.get([2]);
    let d = newMatrix.get([3]);

    let imageFeatures = [];

    exportedCoordinates.forEach((point, index) => {
      let x = a * point["X-Coordinate"] + b * point["Y-Coordinate"] + c;
      let y = b * point["X-Coordinate"] - a * point["Y-Coordinate"] + d;

      imageFeatures.push([y, x]);
    });

    this.polylineLayer = L.polyline(imageFeatures, {
      color: "#800080",
      weight: 5,
      opacity: 0.65,
    });

    this.polylineLayer.addTo(this.floorPlanMap);
  }

  saveNewPath(projectId: string, tourId: string) {
    if (this.updatedCoordinates != null) {
      if (this.isStartOrEndPointUpdated) {
        return this.interiorService.updateCoordinates(
          projectId,
          tourId,
          this.updatedCoordinates,
          this.updatedStartPoint,
          this.updatedEndPoint
        );
      } else {
        return this.interiorService.updateCoordinates(
          projectId,
          tourId,
          this.updatedCoordinates
        );
      }
    } else {
      return this.interiorService.updatePath(
        projectId,
        tourId,
        this.updatedStartPoint,
        this.updatedEndPoint
      );
    }
  }

  getOriginalPolyLineLength() {
    return this.originalCoordinates
      .slice(0, -1)
      .reduce(
        (acc, coord, index) =>
          acc + this.getDistance(coord, this.originalCoordinates[index + 1]),
        0
      );
  }

  getEditedPolyLineLength(editedPolylineCoords) {
    return editedPolylineCoords
      .slice(0, -1)
      .reduce(
        (acc, coord, index) =>
          acc + this.getDistance(coord, editedPolylineCoords[index + 1]),
        0
      );
  }

  getDistance(pointA, pointB) {
    return Math.sqrt(
      Math.pow(pointA[0] - pointB[0], 2) + Math.pow(pointA[1] - pointB[1], 2)
    );
  }

  interpolate(pointA, pointB, fraction) {
    return [
      pointA[0] + (pointB[0] - pointA[0]) * fraction,
      pointA[1] + (pointB[1] - pointA[1]) * fraction,
    ];
  }

  get requiresSave$(): Observable<boolean> {
    return this.requiresSave.asObservable();
  }

  setRequiresSave(requiresSave: boolean) {
    this.requiresSave.next(requiresSave);
  }

  getMarkerIcon(imageNumber: number) {
    return L.divIcon({
      className: "location-path-pin",
      html: `<div class="location-path-pin-container"><img class="location-path-pin-image" /><span class="location-path-pin-text">${imageNumber}</span></div>`,
    });
  }
}
