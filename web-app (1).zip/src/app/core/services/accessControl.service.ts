import { ProjectService, UserService } from "src/app/core";
import { LocalStorageService } from "./local-storage.service";
import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import {
  AccessMapping,
  AccessPoint,
  AccessMappings,
  ProjectRole,
  AccessMappingLocalStorage,
} from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable({
  providedIn: "root",
})
export class AccessControlService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private userService: UserService,
    private projectService: ProjectService,
    private localStorage: LocalStorageService
  ) {}

  getProjectRoles(): Observable<ProjectRole[]> {
    return this.apiService
      .get(eval("`" + this.config.getProjectRoles + "`"))
      .pipe(map((data) => data));
  }

  saveUserRole(
    projectId: string,
    payload: AccessMapping
  ): Observable<{
    data: any;
  }> {
    if (projectId) {
      return this.apiService
        .post(eval("`" + this.config.createProjectRole + "`"), payload)
        .pipe(map((data) => data));
    }
  }

  editUserRole(
    projectId: string,
    role: any,
    payload: AccessMappings
  ): Observable<{
    data: any;
  }> {
    if (projectId && role) {
      return this.apiService
        .put(eval("`" + this.config.editProjectRole + "`"), payload)
        .pipe(map((data) => data));
    }
  }

  getAccessMapping(role: any): Observable<AccessMapping> {
    if (role) {
      return this.apiService
        .get(eval("`" + this.config.getAccessMapping + "`"))
        .pipe(map((data) => data));
    }
  }

  getObjectAccesses(accessKeys: string[]): Observable<AccessPoint[]> {
    return new Observable<AccessPoint[]>((observer) => {
      const projectIdLocalStorage = this.localStorage.getProjectId();
      const accessMappingLocalStorage: AccessMappingLocalStorage =
        this.localStorage.getAccessMapping();

      if (
        !accessMappingLocalStorage ||
        accessMappingLocalStorage.projectId != projectIdLocalStorage
      ) {
        const currentUser = this.userService.getCurrentUser();

        if (currentUser.isAdmin) {
          const role = "Super Admin";
          this.getAccessMapping(role).subscribe({
            next: (accessMapping) => {
              const dataLocalStorage: AccessMappingLocalStorage = {
                ...accessMapping,
                projectId: projectIdLocalStorage,
              };
              this.localStorage.setAccessMapping(dataLocalStorage);
              observer.next(this.getObjectAccessesFinal(accessKeys));
              observer.complete();
            },
            error: () => {
              observer.next(this.getObjectAccessesFinal(accessKeys));
              observer.complete();
            },
          });
        } else {
          this.projectService.getProjectUsers(projectIdLocalStorage).subscribe({
            next: (data) => {
              const role = data.users.find(
                (item) =>
                  item.email.toLowerCase() == currentUser.email.toLowerCase()
              )?.role?.code;

              if (role) {
                this.getAccessMapping(role).subscribe({
                  next: (accessMapping) => {
                    const dataLocalStorage: AccessMappingLocalStorage = {
                      ...accessMapping,
                      projectId: projectIdLocalStorage,
                    };
                    this.localStorage.setAccessMapping(dataLocalStorage);
                    observer.next(this.getObjectAccessesFinal(accessKeys));
                    observer.complete();
                  },
                  error: () => {
                    observer.next(this.getObjectAccessesFinal(accessKeys));
                    observer.complete();
                  },
                });
              } else {
                this.getObjectAccessesFinal(accessKeys);
              }
            },
            error: () => {
              observer.next(this.getObjectAccessesFinal(accessKeys));
              observer.complete();
            },
          });
        }
      } else {
        observer.next(this.getObjectAccessesFinal(accessKeys));
        observer.complete();
      }
    });
  }

  getObjectAccessesFinal(accessKeys: string[]): AccessPoint[] {
    const accessDefault: AccessPoint = {
      isAllowed: false,
      isRedacted: true,
    };
    let results: AccessPoint[] = accessKeys.map((item) => ({
      ...accessDefault,
    }));
    const accessMappingLocalStorage: AccessMappingLocalStorage =
      this.localStorage.getAccessMapping();

    if (accessMappingLocalStorage) {
      results = accessKeys.map((key) => {
        const accessObject = accessMappingLocalStorage.accessMapping.find(
          (item) => item.objectKey == key
        );

        return accessObject
          ? {
              isAllowed: accessObject.isAllowed,
              isRedacted: accessObject.isRedacted,
            }
          : { ...accessDefault };
      });
    }

    return results;
  }
}
