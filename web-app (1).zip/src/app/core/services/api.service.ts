import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";

@Injectable()
export class ApiService {
  constructor(private http: HttpClient) {}

  private formatErrors(error: any) {
    return throwError(error.error);
  }

  get(path: string, params: HttpParams = new HttpParams()): Observable<any> {
    return this.http.get(path, { params }).pipe(catchError(this.formatErrors));
  }

  getFile(path: string, headers = {}): Observable<any> {
    return this.http
      .get(path, { headers: headers, responseType: "blob" })
      .pipe(catchError(this.formatErrors));
  }

  getFileAsText(path: string, headers = {}): Observable<any> {
    return this.http
      .get(path, { headers: headers, responseType: "text" })
      .pipe(catchError(this.formatErrors));
  }

  getFileAsTextWithBody(
    path: string,
    body: Object = {},
    headers = {}
  ): Observable<any> {
    return this.http
      .put(path, JSON.stringify(body), {
        headers: headers,
        responseType: "text",
      })
      .pipe(catchError(this.formatErrors));
  }

  put(path: string, body: Object = {}): Observable<any> {
    return this.http
      .put(path, JSON.stringify(body))
      .pipe(catchError(this.formatErrors));
  }

  patch(
    path: string,
    body: Object = {},
    options: Object = {}
  ): Observable<any> {
    return this.http
      .patch(path, JSON.stringify(body), options)
      .pipe(catchError(this.formatErrors));
  }

  putFile(
    path: string,
    file: Object = {},
    options: Object = {}
  ): Observable<any> {
    return this.http
      .put(path, file, options)
      .pipe(catchError(this.formatErrors));
  }

  post(path: string, body: Object = {}): Observable<any> {
    return this.http
      .post(path, JSON.stringify(body))
      .pipe(catchError(this.formatErrors));
  }

  postFileImageData(path: string, formData): Observable<any> {
    return this.http.post(path, formData).pipe(catchError(this.formatErrors));
  }

  postFile(path: string, formData, options): Observable<any> {
    return this.http
      .post(path, formData, options)
      .pipe(catchError(this.formatErrors));
  }

  delete(path, body: Object = {}): Observable<any> {
    return this.http
      .delete(path, { body: body })
      .pipe(catchError(this.formatErrors));
  }
}
