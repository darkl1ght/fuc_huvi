import { Injectable, Inject } from "@angular/core";
import { HttpEvent } from "@angular/common/http";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import {
  AerialTour,
  AerialImage,
  MapboxAnnotation,
  ProjectChart,
  MapVolumeData,
  ElevationProfileData,
  UpdateWbsProgressBulk,
  AerialTagPayload,
} from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class AerialTourService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getTours(projectId: string): Observable<{ tours: AerialTour[] }> {
    if (projectId) {
      return this.apiService.get(eval("`" + this.config.getProjectTour + "`"));
    }
  }

  selfServeAccess(projectId: string): Observable<{ access: boolean }> {
    if (projectId) {
      return this.apiService.get(
        eval("`" + this.config.selfServeAcceess + "`")
      );
    }
  }

  getProjectWBSStatus(projectId: string): Observable<{ status: Boolean }> {
    if (projectId) {
      return this.apiService.get(
        eval("`" + this.config.getProjectWBSStatus + "`")
      );
    }
  }

  destroy(projectId: string, tourId: string) {
    if (projectId && tourId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteProjectTour + "`")
      );
    }
  }

  save(projectId: string, tour: AerialTour): Observable<AerialTour> {
    if (projectId) {
      const { tourId } = tour;
      if (tourId) {
        return this.apiService
          .put(eval("`" + this.config.updateTour + "`"), { tour: tour })
          .pipe(map((data) => data.tour));
      } else {
        return this.apiService
          .post(eval("`" + this.config.createTour + "`"), { tour: tour })
          .pipe(map((data) => data.tour));
      }
    }
  }

  processData(projectId: string, tourId: string): Observable<AerialTour> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateTourStatus + "`"))
        .pipe(map((data) => data));
    }
  }

  saveImage(
    projectId: string,
    tourId: string,
    image: AerialImage
  ): Observable<string> {
    if (projectId && tourId) {
      return this.apiService
        .post(eval("`" + this.config.addTourImage + "`"), { image: image })
        .pipe(map((data) => data.project));
    }
  }

  saveTourCenter(lat: number, lng: number, tourId: string, projectId: string) {
    if (projectId && tourId) {
      return this.apiService
        .post(eval("`" + this.config.addTourCenter + "`"), { lat, lng })
        .pipe(map((data) => data.tour));
    }
  }

  getImages(projectId: string, tourId: string): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.get(eval("`" + this.config.getTourImage + "`"));
    }
  }

  fetchTourURLs(projectId: string, tourId: string): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.get(
        eval("`" + this.config.saveOrGetMapboxURLs + "`")
      );
    }
  }

  saveTourURLs(
    projectId: string,
    tourId: string,
    mapUrls: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.post(
        eval("`" + this.config.saveOrGetMapboxURLs + "`"),
        { mapUrls: mapUrls }
      );
    }
  }

  saveMapboxAnnotations(
    projectId: string,
    tourId: string,
    annotationLayer: MapboxAnnotation
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.post(
        eval("`" + this.config.updateMapboxAnnotations + "`"),
        { annotation: annotationLayer }
      );
    }
  }

  saveNewAnnotationTypeToTour(
    tourId: string,
    projectId: string,
    newAnnotationType: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .post(eval("`" + this.config.addNewAnnoatationTypeToTour + "`"), {
          newAnnotationType: newAnnotationType,
        })
        .pipe(map((data) => data));
    }
  }

  saveNewAnnotationTypeToProject(
    tourId: string,
    projectId: string,
    newAnnotationType: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .post(eval("`" + this.config.addNewAnnotationTypeToProject + "`"), {
          newAnnotationType: newAnnotationType,
        })
        .pipe(map((data) => data));
    }
  }

  saveNewAnnotationTypeToAllProjects(
    tourId: string,
    projectId: string,
    newAnnotationType: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .post(eval("`" + this.config.addNewAnnotationTypeToAllProjects + "`"), {
          newAnnotationType: newAnnotationType,
        })
        .pipe(map((data) => data));
    }
  }

  getAnnotationTypeFromTour(
    tourId: string,
    projectId: string
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .get(eval("`" + this.config.getNewAnnoatationTypeFromTour + "`"))
        .pipe(map((data) => data));
    }
  }

  getAnnotationTypeFromProject(
    tourId: string,
    projectId: string
  ): Observable<any> {
    if (tourId && projectId) {
      return this.apiService
        .get(eval("`" + this.config.getNewAnnotationTypeFromProject + "`"))
        .pipe(map((data) => data));
    }
  }

  deleteMapboxAnnotations(
    tourId: string,
    projectId: string,
    annotationId: string
  ): Observable<any> {
    if (projectId && tourId && annotationId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteMapboxAnnotations + "`")
      );
    }
  }

  getMapboxAnnotations(tourId: string, projectId: string): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.get(
        eval("`" + this.config.updateMapboxAnnotations + "`")
      );
    }
  }

  getMapboxAnnotationsTypes(): Observable<any> {
    return this.apiService.get(
      eval("`" + this.config.fetchMapboxAnnotationTypes + "`")
    );
  }

  getProcessingStatus(projectId: string, tourId: string): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.get(
        eval("`" + this.config.getMapProcessingStatus + "`")
      );
    }
  }

  getMapOutput(projectId: string, tourId: string): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.get(eval("`" + this.config.getMapOutput + "`"));
    }
  }

  removeLayer(
    projectId: string,
    tourId: string,
    layerId: number
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteMapLayer + "`")
      );
    }
  }

  deleteElevationFilesFromBlob(
    projectId: string,
    tourId: string,
    container: string,
    filename: string
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteElevationFiles + "`")
      );
    }
  }

  uploadCustomLayers(
    projectId: string,
    tourId: string,
    fileType: string,
    file: File
  ): Observable<HttpEvent<any>> {
    if (projectId && tourId && fileType) {
      let postUrl = eval("`" + this.config.uploadCustomLayer + "`");
      const formData: FormData = new FormData();
      formData.append("file", file, file.name);

      return this.apiService.postFile(postUrl, formData, {
        reportProgress: true,
        observe: "events",
      });
    }
  }

  uploadElevationFiles(
    projectId: string,
    tourId: string,
    container: string,
    file: File
  ): Observable<HttpEvent<any>> {
    if (projectId && tourId) {
      let postUrl = eval("`" + this.config.uploadElevationFiles + "`");
      const formData: FormData = new FormData();
      formData.append("file", file, file.name);

      return this.apiService.postFile(postUrl, formData, {
        reportProgress: true,
        observe: "events",
      });
    }
  }

  postProcessingParams(
    projectId: string,
    tourId: string,
    params: any,
    tourCategory: string
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.post(
        eval("`" + this.config.postProcessingParam + "`"),
        { params, tourCategory }
      );
    }
  }

  getProcessingParams(projectId: string, tourId: string): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.get(eval("`" + this.config.processingParam + "`"));
    }
  }

  uploadChart(projectId: string, tourId: string, charts: any): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateTourChart + "`"), { charts: charts })
        .pipe(map((data) => data));
    }
  }

  deleteChart(
    projectId: string,
    tourId: string,
    chart: ProjectChart
  ): Observable<any> {
    if (tourId && projectId) {
      return this.apiService
        .put(eval("`" + this.config.removeTourChart + "`"), { chart: chart })
        .pipe(map((data) => data));
    }
  }

  getCharts(projectId: string, tourId: string): Observable<any> {
    if (tourId && projectId) {
      return this.apiService
        .get(eval("`" + this.config.getTourChart + "`"))
        .pipe(map((data) => data));
    }
  }

  removeStaticUrl(projectId: string, tourId: string, staticTourId: string) {
    if (tourId && projectId && staticTourId) {
      return this.apiService.delete(
        eval("`" + this.config.removeStaticAerialTourData + "`")
      );
    }
  }

  saveStaticTourUrl(
    projectId: string,
    tourId: string,
    tour: any
  ): Observable<AerialTour> {
    if (tourId && projectId) {
      return this.apiService
        .put(eval("`" + this.config.addStaticAerialUrl + "`"), {
          tour: tour,
        })
        .pipe(map((data) => data.tour));
    }
  }

  removeStaticChart(projectId, tourId, chartId) {
    return this.apiService.delete(
      eval("`" + this.config.removeStaticAerialTourChart + "`")
    );
  }

  saveStaticTourChart(
    projectId: string,
    tourId: string,
    charts: any
  ): Observable<AerialTour> {
    if (tourId && projectId) {
      return this.apiService
        .put(eval("`" + this.config.addStaticAerialChart + "`"), {
          charts: charts,
        })
        .pipe(map((data) => data.tour));
    }
  }

  publishStaticTour(projectId: string, tourId: string): Observable<any> {
    if (tourId && projectId) {
      return this.apiService
        .put(eval("`" + this.config.publishStaticAerialTour + "`"))
        .pipe(map((data) => data));
    }
  }

  saveVolumeData(projectId, tourId, volData: MapVolumeData) {
    if (volData) {
      return this.apiService
        .post(eval("`" + this.config.saveVolumeData + "`"), { volData })
        .pipe(map((data) => data));
    }
  }

  getVolumeData(projectId: string, tourId: string): Observable<any> {
    return this.apiService.get(eval("`" + this.config.getVolumeData + "`"));
  }

  deleteVolumeById(projectId, tourId, volumeId) {
    return this.apiService.delete(
      eval("`" + this.config.deleteVolumeData + "`")
    );
  }

  saveElevationProfileData(
    projectId,
    tourId,
    elevationProfile: ElevationProfileData
  ) {
    if (elevationProfile) {
      return this.apiService
        .post(eval("`" + this.config.saveElevationData + "`"), {
          elevationProfile,
        })
        .pipe(map((data) => data));
    }
  }

  getElevationProfileData(projectId: string, tourId: string): Observable<any> {
    return this.apiService.get(eval("`" + this.config.getElevationData + "`"));
  }

  deleteElevationProfilesById(projectId, tourId, elevationProfileId) {
    return this.apiService.delete(
      eval("`" + this.config.deleteElevationData + "`")
    );
  }

  updateThreeD(
    projectId: string,
    tourId: string,
    url: string
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.threeDUrl + "`"), { mapUrl: url })
        .pipe(map((data) => data));
    }
  }

  updatePointCloudObjectCount(
    projectId: string,
    tourId: string,
    objectCount: number
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updatePointCloudObjectCount + "`"), {
          objectCount,
        })
        .pipe(map((data) => data));
    }
  }

  getWBSStatus(projectId, tourId, towerId): Observable<{ wbsData: any }> {
    return this.apiService.get(eval("`" + this.config.getTourWBS + "`"));
  }

  updateWBSProgress(
    projectId: string,
    tourId: string,
    wbsId: string,
    progress,
    comment: string
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateTourProgressStatus + "`"), {
          wbsProgress: {
            progress: progress,
            comment: comment,
          },
        })
        .pipe(map((data) => data));
    }
  }

  updateWBSProgressBulk(
    projectId: string,
    tourId: string,
    payload: UpdateWbsProgressBulk[]
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateTourProgressStatusBulk + "`"), {
          wbsProgress: payload,
        })
        .pipe(map((data) => data));
    }
  }

  getProgressChart(
    projectId: string,
    tourId: string,
    towerId: string
  ): Observable<any> {
    if (tourId && projectId && towerId) {
      return this.apiService
        .get(eval("`" + this.config.getProgressChart + "`"))
        .pipe(map((data) => data));
    }
  }

  getProgressChartByTower(
    projectId: string,
    tourId: string,
    towerId: string
  ): Observable<any> {
    if (tourId && projectId && towerId) {
      return this.apiService
        .get(eval("`" + this.config.getProgressChartByTower + "`"))
        .pipe(map((data) => data));
    }
  }

  notifyUsers(projectId: string, tourId: string): Observable<any> {
    if (tourId && projectId) {
      return this.apiService
        .post(eval("`" + this.config.notifyUsersAerialTour + "`"))
        .pipe(map((data) => data));
    }
  }

  emailNotifyUsers(
    projectId: string,
    tourId: string,
    shareLink: string
  ): Observable<any> {
    if (tourId && projectId) {
      return this.apiService
        .post(eval("`" + this.config.emailNotifyUsersAerialTour + "`"), {
          shareLink,
        })
        .pipe(map((data) => data));
    }
  }

  syncWBSMasterData(
    projectId: string,
    tourId: string
  ): Observable<{ status: Boolean }> {
    if (tourId && projectId) {
      return this.apiService.get(
        eval("`" + this.config.syncWBSMasterData + "`")
      );
    }
  }

  getReport(clientId: string): Observable<any> {
    return this.apiService
      .post(eval("`" + this.config.getReport + "`"), {})
      .pipe(map((data) => data));
  }

  publishWBSTourData(projectId, tourId): Observable<{ status: Boolean }> {
    return this.apiService.get(
      eval("`" + this.config.publishWBSTourData + "`")
    );
  }

  getAerialTourById(projectId: string, tourId: string) {
    if (tourId && projectId) {
      return this.apiService.get(
        eval("`" + this.config.getAerialTourById + "`")
      );
    }
  }

  updateAerialTourRemarks(
    projectId: string,
    tourId: string,
    remark: any
  ): Observable<{
    tour: any;
  }> {
    if (remark && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateAerialTourRemark + "`"), {
          remark: remark,
        })
        .pipe(map((data) => data));
    }
  }

  editAerialTourRemarks(
    projectId: string,
    tourId: string,
    editedRemark: any
  ): Observable<{
    tour: any;
  }> {
    if (editedRemark && tourId) {
      return this.apiService
        .put(eval("`" + this.config.editAerialTourRemark + "`"), {
          editedRemark: editedRemark,
        })
        .pipe(map((data) => data));
    }
  }

  // polygon remarks

  saveAerialTourPolygonRemarks(
    projectId: string,
    tourId: string,
    polygonRemark: any
  ): Observable<{
    tour: any;
  }> {
    if (polygonRemark && tourId) {
      return this.apiService
        .post(eval("`" + this.config.saveAerialTourPolygonRemark + "`"), {
          polygonRemark: polygonRemark,
        })
        .pipe(map((data) => data));
    }
  }

  updateAerialTourPunchItemMarker(
    projectId: string,
    tourId: string,
    punchItemMarker: any
  ): Observable<{
    tour: any;
  }> {
    if (punchItemMarker && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateAerialTourPunchItemMarker + "`"), {
          punchItemMarker: punchItemMarker,
        })
        .pipe(map((data) => data));
    }
  }

  editAerialTourPunchItemMarker(
    projectId: string,
    tourId: string,
    editedPunchItemMarker: any
  ): Observable<{
    tour: any;
  }> {
    if (editedPunchItemMarker && projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.editAerialTourPunchItemMarker + "`"), {
          editedPunchItemMarker: editedPunchItemMarker,
        })
        .pipe(map((data) => data));
    }
  }

  saveAerialTourPolygonPunchItemMarker(
    projectId: string,
    tourId: string,
    punchItemMarker: any
  ): Observable<{
    tour: any;
  }> {
    if (punchItemMarker && tourId) {
      return this.apiService
        .put(
          eval("`" + this.config.saveAerialTourPolygonPunchItemMarker + "`"),
          {
            punchItemMarker: punchItemMarker,
          }
        )
        .pipe(map((data) => data));
    }
  }

  removeAerialTourRemark(
    projectId: string,
    tourId: string,
    remark: any
  ): Observable<any> {
    if (remark && projectId) {
      return this.apiService
        .put(eval("`" + this.config.removeAerialTourRemark + "`"), {
          remark: remark,
        })
        .pipe(map((data) => data));
    }
  }

  removeAerialTourPunchListItem(
    projectId: string,
    tourId: string,
    punchMarkerId: any
  ): Observable<any> {
    if (punchMarkerId && projectId) {
      return this.apiService
        .delete(eval("`" + this.config.removeAerialTourPunchListItem + "`"))
        .pipe(map((data) => data));
    }
  }

  downloadChartData(projectId: string): Observable<any> {
    if (projectId) {
      return this.apiService
        .getFileAsText(eval("`" + this.config.downloadExtChartData + "`"))
        .pipe(map((data) => data));
    }
  }

  restoreWBSBaseline(
    projectId: string,
    tourId: string,
    towerId: string
  ): Observable<any> {
    if (projectId && tourId && towerId) {
      return this.apiService
        .put(eval("`" + this.config.restoreExtWBSBaseline + "`"))
        .pipe(map((data) => data));
    }
  }

  updateAerialTourLatLng(
    projectId: string,
    tourId: string,
    latLngValues: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateAerialTourLatLng + "`"), {
          latLngValues: latLngValues,
        })
        .pipe(map((data) => data));
    }
  }

  updateMapboxLayerOrder(
    projectId: string,
    tourId: string,
    newMapboxLayerArray: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateMapboxLayerOrder + "`"), {
          newMapURLs: newMapboxLayerArray,
        })
        .pipe(map((data) => data));
    }
  }

  saveDroneFlightData(
    projectId: string,
    tourId: string,
    droneFlightData: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.saveDroneFlightData + "`"), {
          droneFlightData: droneFlightData,
        })
        .pipe(map((data) => data));
    }
  }

  saveDroneFlightVideoData(
    projectId: string,
    tourId: string,
    droneFlightVideoData: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.saveDroneFlightVideoData + "`"), {
          droneFlightVideoData: droneFlightVideoData,
        })
        .pipe(map((data) => data));
    }
  }

  deleteDroneFlightLogData(
    projectId: string,
    tourId: string,
    droneFlightLogId: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .delete(eval("`" + this.config.deleteAerialTourDroneFlightData + "`"), {
          droneFlightLogId: droneFlightLogId,
        })
        .pipe(map((data) => data));
    }
  }

  deleteDroneFlightVideoData(
    projectId: string,
    tourId: string,
    fileObjectId: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .delete(
          eval("`" + this.config.deleteAerialTourDroneFlightVideoData + "`"),
          {
            fileObjectId: fileObjectId,
          }
        )
        .pipe(map((data) => data));
    }
  }

  saveShapefileColorData(
    projectId: string,
    tourId: string,
    shapeFileData: any
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.saveShapefileColor + "`"), {
          shapeFileData: shapeFileData,
        })
        .pipe(map((data) => data));
    }
  }

  deleteImageData(projectId: string, tourId: string): Observable<any> {
    if (projectId && tourId) {
      return this.apiService.delete(
        eval("`" + this.config.deleteAerialTourImageData + "`")
      );
    }
  }

  updateAerialTags(
    projectId: string,
    tourId: string,
    payload: AerialTagPayload
  ): Observable<any> {
    if (projectId && tourId) {
      return this.apiService
        .put(eval("`" + this.config.updateAerialTags + "`"), payload)
        .pipe(map((data) => data));
    }
  }

  changeTourStatus(projectId: string, tourId: string, status: string) {
    if (projectId && tourId && status) {
      return this.apiService
        .get(eval("`" + this.config.changeTourStatus + "`"))
        .pipe(map((data) => data));
    }
  }
}
