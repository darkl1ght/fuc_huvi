import { Injectable } from "@angular/core";
import { BehaviorSubject, Subject } from "rxjs";

@Injectable()
export class SharedService {
  change = new Subject<number>();
  projectId$ = new BehaviorSubject<any>("");

  constructor() {}

  emitValue(value: number) {
    this.change.next(value);
  }

  setProjectId(projectId) {
    this.projectId$.next(projectId);
  }

  getProjectId() {
    return this.projectId$.asObservable();
  }
}
