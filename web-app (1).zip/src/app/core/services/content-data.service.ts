import { Injectable, Inject } from "@angular/core";
import { BehaviorSubject, Observable, Subject } from "rxjs";

import { ApiService } from "./api.service";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import {
  BulkFilePayload,
  BulkFileUpdatePayload,
  BulkFileUpdateResponse,
  BulkFileUploadPayload,
  Cabinet,
  CreateConstraCompanyPayload,
  CreateFolderPayload,
  UpdateFolderPayload,
  CreateProjectFolderPayload,
  FileUpdateStatusResponse,
  FolderTree,
  PresignedURLResponse,
  FolderContents,
  DeleteFileBulk,
  DeleteFolder,
  DeleteFolderBulk,
  UploadFilePayload,
  FileGrid,
  FileEditPayload,
  FileVersionUploadUrlPayload,
  CreateFileVersionUploadUrlResponse,
  UpdateFileVersionPayload,
  UpdateFileVersionResponse,
  FileDownloadUrlResponse,
  PaginatePayload,
  RecordCountStatus,
  FileTagPayload,
  SaveAnnotationNFeaturesPayload,
  FileAnnotation,
  UpdateFeaturesPayload,
  FileComment,
  AddFileCommentPayload,
  IFile,
  UpdateMediaBulkPayload,
  Folder,
} from "src/app/core";

@Injectable()
export class ContentDataService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}
  private openAddFilesPanelSub = new Subject<boolean>();
  private openUploadVersionPanelSub = new Subject<FileGrid>();
  private currentFolderIdSub = new Subject<string>();
  private recordCountStatusSub = new Subject<RecordCountStatus>();
  private refreshFilesSub = new Subject<boolean>();
  private refreshMediaSub = new Subject<boolean>();
  private thumbnailViewSub = new Subject<boolean>();
  private selectAllToParentSub = new Subject<boolean>();
  private selectAllToChildSub = new Subject<boolean>();
  private indeterminateToParentSub = new Subject<boolean>();
  private menuGoToFolderSub = new Subject<FolderTree>();
  private projectFolderTreeToParentSub = new BehaviorSubject<FolderTree>(null);
  private projectFolderTreeToChildSub = new BehaviorSubject<FolderTree>(null);
  private uploadFilesSub = new BehaviorSubject<UploadFilePayload[]>([]);
  private deleteBulkSub = new Subject<boolean>();
  private downloadBulkSub = new Subject<boolean>();
  private editFileSub = new Subject<FileGrid>();
  private libraryFilterSub = new Subject<string>();
  private anySelectedSub = new Subject<boolean>();
  private onLogoutSub = new Subject<boolean>();
  private updateBulkSub = new Subject<boolean>();

  openAddFilesPanel$ = this.openAddFilesPanelSub.asObservable();
  openUploadVersionPanel$ = this.openUploadVersionPanelSub.asObservable();
  currentFolderId$ = this.currentFolderIdSub.asObservable();
  recordCountStatus$ = this.recordCountStatusSub.asObservable();
  refreshFiles$ = this.refreshFilesSub.asObservable();
  thumbnailView$ = this.thumbnailViewSub.asObservable();
  selectAllToParent$ = this.selectAllToParentSub.asObservable();
  selectAllToChild$ = this.selectAllToChildSub.asObservable();
  indeterminateToParent$ = this.indeterminateToParentSub.asObservable();
  menuGoToFolder$ = this.menuGoToFolderSub.asObservable();
  projectFolderTreeToParent$ = this.projectFolderTreeToParentSub.asObservable();
  projectFolderTreeToChild$ = this.projectFolderTreeToChildSub.asObservable();

  refreshMedia$ = this.refreshMediaSub.asObservable();
  deleteBulk$ = this.deleteBulkSub.asObservable();
  updateBulk$ = this.updateBulkSub.asObservable();
  downloadBulk$ = this.downloadBulkSub.asObservable();
  uploadFiles$ = this.uploadFilesSub.asObservable();
  editFileSub$ = this.editFileSub.asObservable();
  libraryFilter$ = this.libraryFilterSub.asObservable();
  anySelected$ = this.anySelectedSub.asObservable();
  onLogoutSub$ = this.onLogoutSub.asObservable();

  openAddFilesPanel() {
    this.openAddFilesPanelSub.next(true);
  }

  openUploadVersionPanel(file: FileGrid) {
    this.openUploadVersionPanelSub.next(file);
  }

  sendCurrentFolderId(folderId: string) {
    this.currentFolderIdSub.next(folderId);
  }

  sendRecordCountStatus(status: RecordCountStatus) {
    this.recordCountStatusSub.next(status);
  }

  refreshFiles(showSpinner: boolean) {
    this.refreshFilesSub.next(showSpinner);
  }

  toggleThumbnailView(isThumbnailView: boolean) {
    this.thumbnailViewSub.next(isThumbnailView);
  }

  sendSelectAllToParent(isSelectAll: boolean) {
    this.selectAllToParentSub.next(isSelectAll);
  }

  sendSelectAllToChild(isSelectAll: boolean) {
    this.selectAllToChildSub.next(isSelectAll);
  }

  sendIndeterminateToParent(isIndeterminate: boolean) {
    this.indeterminateToParentSub.next(isIndeterminate);
  }

  refreshMedia() {
    this.refreshMediaSub.next(true);
  }

  menuGoToFolder(folder: FolderTree) {
    this.menuGoToFolderSub.next(folder);
  }

  sendProjectFolderTreeToParent(folderTree: FolderTree) {
    this.projectFolderTreeToParentSub.next(folderTree);
  }

  sendProjectFolderTreeToChild(folderTree: FolderTree) {
    this.projectFolderTreeToChildSub.next(folderTree);
  }
  sendDeleteBulk() {
    this.deleteBulkSub.next(true);
  }

  sendDownloadBulk() {
    this.downloadBulkSub.next(true);
  }

  updateMediaBulk() {
    this.updateBulkSub.next(true);
  }

  uploadFiles(fileObj: UploadFilePayload[]) {
    this.uploadFilesSub.next(fileObj);
  }
  onLogout() {
    this.onLogoutSub.next(true);
  }
  uploadFilesUnsubscribe() {
    this.uploadFilesSub.unsubscribe();
  }
  sendEditFile(file: FileGrid) {
    this.editFileSub.next(file);
  }

  sendLibraryFilter(filterValue: string) {
    this.libraryFilterSub.next(filterValue);
  }

  sendAnySelected(isAnySelected: boolean) {
    this.anySelectedSub.next(isAnySelected);
  }

  getCabinet(companyId: string, moduleName: string): Observable<Cabinet> {
    if (companyId && moduleName) {
      return this.apiService
        .get(eval("`" + this.config.getCabinet + "`"))
        .pipe(map((data) => data.data));
    }
  }

  getPresignedURL(
    payload: BulkFileUploadPayload
  ): Observable<PresignedURLResponse> {
    return this.apiService
      .post(eval("`" + this.config.getPresignedURL + "`"), {
        ...payload,
      })
      .pipe(map((data) => data.data));
  }

  updateFileStatus(
    payload: BulkFileUpdatePayload
  ): Observable<FileUpdateStatusResponse[]> {
    return this.apiService
      .put(eval("`" + this.config.updateFileStatus + "`"), {
        ...payload,
      })
      .pipe(map((data) => data.data));
  }

  createFolder(payload: CreateFolderPayload): Observable<any> {
    return this.apiService
      .post(eval("`" + this.config.createFolder + "`"), {
        ...payload,
      })
      .pipe(map((data) => data.data));
  }

  updateFolder(
    folderId: string,
    payload: UpdateFolderPayload
  ): Observable<any> {
    return this.apiService
      .put(eval("`" + this.config.updateFolder + "`"), {
        ...payload,
      })
      .pipe(map((data) => data.data));
  }

  createProjectFolder(payload: CreateProjectFolderPayload): Observable<any> {
    if (payload.companyId && payload.projectId) {
      return this.apiService
        .post(eval("`" + this.config.createProjectFolder + "`"), {
          ...payload,
        })
        .pipe(map((data) => data.data));
    }
  }

  getProjectFolder(
    companyId: string,
    projectId: string,
    moduleName: string
  ): Observable<any> {
    if (companyId && projectId && moduleName) {
      return this.apiService
        .get(eval("`" + this.config.getProjectFolder + "`"))
        .pipe(map((data) => data.data));
    }
  }

  createConstraCompany(payload: CreateConstraCompanyPayload): Observable<any> {
    if (payload.companyId && payload.companyName) {
      return this.apiService
        .post(eval("`" + this.config.createConstraCompany + "`"), {
          ...payload,
        })
        .pipe(map((data) => data.data));
    }
  }

  uploadFile(payload): Observable<any> {
    if (payload) {
      return this.apiService
        .post(eval("`" + this.config.createFile + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  uploadFileBulk(
    payload: BulkFilePayload
  ): Observable<BulkFileUpdateResponse[]> {
    if (payload) {
      return this.apiService
        .post(eval("`" + this.config.uploadFileBulk + "`"), payload)
        .pipe(map((response) => response.data.files));
    }
  }

  updateFile(payload: FileEditPayload): Observable<any> {
    if (payload) {
      return this.apiService
        .put(eval("`" + this.config.updateFile + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  updateFileName(payload: FileEditPayload): Observable<any> {
    if (payload) {
      return this.apiService
        .put(eval("`" + this.config.updateFileName + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  uploadFileS3(uploadUrl, file, options = {}): Observable<any> {
    if (uploadUrl && file) {
      return this.apiService.putFile(uploadUrl, file, options);
    }
  }

  getFolderContents(parentFolderRefId: string): Observable<FolderContents> {
    if (parentFolderRefId) {
      return this.apiService
        .get(eval("`" + this.config.getFolderContents + "`"))
        .pipe(map((response) => response.data));
    }
  }

  deleteFileById(
    fileId: string,
    isSoftDelete: boolean = true
  ): Observable<any> {
    if (fileId) {
      return this.apiService
        .delete(eval("`" + this.config.deleteFileById + "`"))
        .pipe(map((response) => response.data));
    }
  }

  deleteFileByObjectId(
    fileObjectId: string,
    isSoftDelete: boolean = true
  ): Observable<any> {
    if (fileObjectId) {
      return this.apiService
        .delete(eval("`" + this.config.deleteFileByObjectId + "`"))
        .pipe(map((response) => response.data));
    }
  }

  deleteFileBulk(payload: DeleteFileBulk): Observable<any> {
    if (payload && payload.files.length > 0) {
      return this.apiService
        .put(eval("`" + this.config.deleteFileBulk + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  deleteFolder(folderId: string, payload: DeleteFolder): Observable<any> {
    if (folderId) {
      return this.apiService
        .put(eval("`" + this.config.deleteFolder + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  deleteFolderBulk(payload: DeleteFolderBulk): Observable<any> {
    if (payload && payload.folders.length > 0) {
      return this.apiService
        .put(eval("`" + this.config.deleteFolderBulk + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  getFolderTree(parentFolderRefId: string): Observable<FolderTree> {
    if (parentFolderRefId) {
      return this.apiService
        .get(eval("`" + this.config.getFolderTree + "`"))
        .pipe(map((response) => response.data));
    }
  }

  getProjectFolderTree(
    companyId: string,
    projectId: string,
    moduleName: string
  ): Observable<FolderTree> {
    if (companyId && projectId && moduleName) {
      return this.apiService
        .get(eval("`" + this.config.getProjectFolderTree + "`"))
        .pipe(map((data) => data.data));
    }
  }

  createFileVersionUploadUrl(
    payload: FileVersionUploadUrlPayload
  ): Observable<CreateFileVersionUploadUrlResponse> {
    return this.apiService
      .post(this.config.createFileVersionUploadUrl, {
        ...payload,
      })
      .pipe(map((response) => response.data));
  }

  updateFileVersion(
    payload: UpdateFileVersionPayload
  ): Observable<UpdateFileVersionResponse> {
    return this.apiService
      .put(this.config.updateFileVersion, { ...payload })
      .pipe(map((response) => response.data));
  }

  getFileDownloadUrl(
    fileId: string,
    fileObjectId: string,
    fileName: string
  ): Observable<FileDownloadUrlResponse> {
    if (fileId && fileObjectId && fileName) {
      return this.apiService
        .get(eval("`" + this.config.getFileDownloadUrl + "`"))
        .pipe(map((data) => data.data));
    }
  }

  getFilesByPagination(
    parentFolderRefId: string,
    payload: PaginatePayload
  ): Observable<FolderContents> {
    if (parentFolderRefId) {
      return this.apiService
        .put(eval("`" + this.config.getFilesByPagination + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  updateFiletags(payload: FileTagPayload): Observable<any> {
    if (payload) {
      return this.apiService
        .put(this.config.updateFiletags, payload)
        .pipe(map((response) => response.data));
    }
  }

  getAnnotations(fileId: string): Observable<FileAnnotation[]> {
    if (fileId) {
      return this.apiService
        .get(eval("`" + this.config.getFileAnnotations + "`"))
        .pipe(map((response) => response.data));
    }
  }

  getFileById(fileId: string): Observable<IFile> {
    if (fileId) {
      return this.apiService
        .get(eval("`" + this.config.getFileById + "`"))
        .pipe(map((response) => response.data));
    }
  }

  getFileByObjectId(fileObjectId: string): Observable<IFile> {
    if (fileObjectId) {
      return this.apiService
        .get(eval("`" + this.config.getFileByObjectId + "`"))
        .pipe(map((response) => response.data));
    }
  }

  saveAnnotationNFeatures(
    payload: SaveAnnotationNFeaturesPayload
  ): Observable<any> {
    if (payload) {
      if (payload.annotation.annotationId) {
        return this.apiService
          .put(this.config.updateAnnotationNFeatures, { ...payload })
          .pipe(map((response) => response.data));
      } else {
        return this.apiService
          .post(this.config.createAnnotationNFeatures, { ...payload })
          .pipe(map((response) => response.data));
      }
    }
  }

  removeAnnotation(fileId: string, annotationId: string): Observable<any> {
    if (fileId && annotationId) {
      return this.apiService
        .delete(eval("`" + this.config.removeFileAnnotation + "`"))
        .pipe(map((response) => response.data));
    }
  }

  updateFeatures(
    fileId: string,
    payload: UpdateFeaturesPayload
  ): Observable<any> {
    if (payload) {
      return this.apiService
        .put(eval("`" + this.config.updateFeatures + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  getComments(fileId: string): Observable<FileComment[]> {
    if (fileId) {
      return this.apiService
        .get(eval("`" + this.config.getFileComments + "`"))
        .pipe(map((response) => response.data));
    }
  }

  getFileContent(url: string): Observable<any> {
    if (url) {
      return this.apiService.getFile(url);
    }
  }

  getFolder(folderId: string): Observable<Folder> {
    if (folderId) {
      return this.apiService
        .get(eval("`" + this.config.getFolder + "`"))
        .pipe(map((response) => response.data));
    }
  }

  addComment(fileId: string, payload: AddFileCommentPayload): Observable<any> {
    if (fileId && payload) {
      return this.apiService
        .post(eval("`" + this.config.addFileComment + "`"), { ...payload })
        .pipe(map((response) => response.data));
    }
  }

  deleteComment(fileId: string, commentId: string): Observable<any> {
    if (fileId && commentId) {
      return this.apiService
        .delete(eval("`" + this.config.removeFileComment + "`"))
        .pipe(map((response) => response.data));
    }
  }

  updateMediaInBulk(payload: UpdateMediaBulkPayload): Observable<any> {
    if (payload) {
      return this.apiService
        .put(eval("`" + this.config.updateMediaInBulk + "`"), payload)
        .pipe(map((response) => response.data));
    }
  }

  getFieldIssuesFolderContents(
    projectFolderId: string,
    floorId: string
  ): Observable<any> {
    if (projectFolderId && floorId) {
      return this.apiService
        .get(eval("`" + this.config.getFieldIssuesFolderContents + "`"))
        .pipe(map((response) => response.data));
    }
  }
}
