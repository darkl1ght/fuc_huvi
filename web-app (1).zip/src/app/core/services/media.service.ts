import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { ProjectAlbum, ProjectMedia, MediaAnnotation } from "../models";
import { map } from "rxjs/operators";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";

@Injectable()
export class MediaService {
  constructor(
    private apiService: ApiService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  getAlbum(projectId): Observable<any> {
    return this.apiService.get(eval("`" + this.config.getAlbum + "`"));
  }

  removeAlbum(projectId, albumId) {
    return this.apiService.delete(eval("`" + this.config.deleteAlbum + "`"));
  }

  saveAlbum(projectId: string, album: ProjectAlbum): Observable<string> {
    let albumId;
    if (album.albumId) {
      albumId = album.albumId;
      return this.apiService
        .put(eval("`" + this.config.updateAlbum + "`"), { album: album })
        .pipe(map((data) => data.status));
    } else {
      return this.apiService
        .post(eval("`" + this.config.addNewAlbum + "`"), { album: album })
        .pipe(map((data) => data.status));
    }
  }

  getMediaList(projectId, albumId): Observable<any> {
    return this.apiService.get(eval("`" + this.config.getMediaList + "`"));
  }

  saveMedia(pId: string, media: ProjectMedia): Observable<string> {
    let projectId = pId;
    return this.apiService
      .post(eval("`" + this.config.addNewMedia + "`"), { media: media })
      .pipe(map((data) => data.status));
  }

  removeMedia(projectId, albumId, mediaId) {
    return this.apiService.delete(eval("`" + this.config.deleteMedia + "`"));
  }

  removeMediaBulk(projectId, albumId, mediaIds) {
    return this.apiService
      .put(eval("`" + this.config.deleteMediaBulk + "`"), {
        mediaIds: mediaIds,
      })
      .pipe(map((data) => data.status));
  }

  deleteComment(projectId: string, mediaId: string, commentId) {
    if (commentId) {
      return this.apiService
        .put(eval("`" + this.config.removeMediaComment + "`"), {
          commentId: commentId,
        })
        .pipe(map((data) => data));
    }
  }

  addMediaComments(projectId: string, mediaId: string, comment: string) {
    if (mediaId && comment.trim()) {
      return this.apiService
        .post(eval("`" + this.config.addMediaComment + "`"), {
          comment: comment,
        })
        .pipe(map((data) => data.status));
    }
  }

  getMediaComment(projectId, mediaId): Observable<any> {
    return this.apiService.get(eval("`" + this.config.getMediaComments + "`"));
  }

  updateMediaContent(projectId: string, albumId: string, detail: any) {
    if (detail) {
      return this.apiService
        .put(eval("`" + this.config.updateMedia + "`"), { detail: detail })
        .pipe(map((data) => data.status));
    }
  }

  getAnnotations(projectId, mediaId): Observable<any> {
    return this.apiService.get(
      eval("`" + this.config.getMediaAnnotation + "`")
    );
  }

  removeAnnotation(projectId, mediaId, annotationId): Observable<any> {
    return this.apiService
      .put(eval("`" + this.config.removeAnnotation + "`"), {
        annotationId: annotationId,
      })
      .pipe(map((data) => data.status));
  }

  save(
    projectId: string,
    mediaId: string,
    annotation: MediaAnnotation,
    features: any
  ): Observable<any> {
    if (annotation.annotationId) {
      let annotationId = annotation.annotationId;
      return this.apiService
        .put(eval("`" + this.config.updateMediaAnnotation + "`"), {
          annotation: annotation,
          features: features,
        })
        .pipe(map((data) => data.annotationId));
      // Otherwise, create a new project
    } else {
      return this.apiService
        .post(eval("`" + this.config.newMediaAnnotation + "`"), {
          annotation: annotation,
          features: features,
        })
        .pipe(map((data) => data.annotationId));
    }
  }

  updateFeatureLayer(
    projectId: string,
    mediaId: string,
    feature: any
  ): Observable<string> {
    if (feature) {
      return this.apiService
        .put(eval("`" + this.config.updateMediaFeatures + "`"), {
          feature: feature,
        })
        .pipe(map((data) => data.status));
    }
  }

  notifyUsers(projectId, albumId): Observable<any> {
    return this.apiService
      .post(eval("`" + this.config.notifyMediaDetails + "`"), { albumId })
      .pipe(map((data) => data.status));
  }
}
