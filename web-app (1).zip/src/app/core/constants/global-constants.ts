export const AppConstants = {
  annotation_action: {
    create: "create",
    edit: "edit",
    view: "view",
  },
  aerialreport: {
    exteriroData: "Exterior Data Capture",

    captureDate: "Data Capture Date: ",
    lineChartGraph:
      "This graph shows the planned vs actual work completed for ",
    timeline: " over the timeline",
    droneDateCapture: "Date of Capture:",
    type: "Type of Analysis:",
    typeValue: "Drone data analysis on HUVIAiR cloud platform",

    location: "Location:",
    planned: "Planned %",
    actual: "Actual %",
    exteriorReport: "Exterior Progress Report",
  },
  interior: {
    interiorReport: " Interior Progress Report",
    interiorData: "Interior Data Capture",
    type: "Type of Analysis:",
    typeValue: "Interior 360 data analysis on HUVIAiR cloud platform",
    dateCapture: "Date of Data Capture:",
    workBreakDown: "Work BreakDown Graph",
  },
  report: {
    presentedBy: "Presented by HUVIAiR Constra",
    projectUrl: " https://constra.huviair.com/",
    projectVis: "The complete project visualization and analytics is",
    available: " available on ",
    reportHeader: "Inspection report",
    reportCoverPage: "Inspection Report",
    preparedBy: "Prepared By:",
    preparedOn: "Prepared On: ",
    inspectionStatistics: "Inspection Statistics",
    totalImages: "Total Images",
    totalAnnotations: "Total Annotations",
    openAnnotations: "Open Annotations",
    resolvedAnnotations: "Resolved Annotations",
    annotationsByType: "Annotations by type: ",
    annotationsBySeverity: "Annotations by severity: ",
    index: "Index",
  },
  punchList: {
    punchListReport: " PunchList Report",
    punchList_All: { key: "all", desc: "All List" },
    punchList_Open: { key: "open", desc: "Open List" },
    punchList_assigned: { key: "assigned", desc: "My Assigned" },
    punchList_overdue: { key: "overdue", desc: "Overdue List" },
    punchList_completed: { key: "completed", desc: "Completed List" },
    punchList_onsite: { key: "onsite", desc: "Onsite Snag" },
  },

  punchListChart: {
    chart_workPackage: { chartName: "Items by Work Package", chartType: "bar" },
    chart_workLocation: {
      chartName: "Item by Work Location",
      chartType: "bar",
    },
    chart_status: { chartName: "Items by Status", chartType: "donut" },
    chart_priority: { chartName: "Items by Priority", chartType: "donut" },
    chart_conformity: {
      chartName: "Items by Conformity Status",
      chartType: "pie",
    },
    chart_overdue: { chartName: "Items by Overdue", chartType: "pie" },
  },
  custom_layers: {
    allowed_files: {
      // shp: "shp",
      tif: "tif",
      zip: "zip",
      geojson: "geojson",
      kml: "kml",
      kmz: "kmz",
      csv: "csv",
      tiff: "tif",
    },
  },
  smartMedia: {
    metadata: {
      latitude: "Latitude",
      longitude: "Longitude",
      altitude: "Altitude",
      dateTaken: "DateTaken",
      isOutput: "IsOutput",
      isMailObject: "IsMailObject",
      is360Media: "Is360Media",
      mediaTypeCode: "MediaTypeCode",
      videoSourceType: "VideoSourceType",
      videoSourceId: "VideoSourceId",
      isPublished: "IsPublished",
    },
  },
  library: {
    metadata: {
      category: "Category",
      otherReason: "Other Reason",
    },
  },
  accessObjectKeys: {
    //Teams
    TEAMS_ADD_USER: "TEAMS_ADD_USER",
    TEAMS_EDIT_USER: "TEAMS_EDIT_USER",
    TEAMS_DELETE_USER: "TEAMS_DELETE_USER",
    TEAMS_RESET_PASSWORD: "TEAMS_RESET_PASSWORD",
    TEAMS_BLOCK_USER: "TEAMS_BLOCK_USER",

    //Aerial
    AERIAL_SYNC_WBS: "AERIAL_SYNC_WBS",
    AERIAL_UPDATE_PROGRESS: "AERIAL_UPDATE_PROGRESS",
    AERIAL_CREATE_TOUR: "AERIAL_CREATE_TOUR",
    AERIAL_EDIT_TOUR: "AERIAL_EDIT_TOUR",
    AERIAL_DELETE_TOUR: "AERIAL_DELETE_TOUR",
    AERIAL_SEND_NOTIFICATION: "AERIAL_SEND_NOTIFICATION",

    //Virtual
    VIRTUAL_SYNC_WBS: "VIRTUAL_SYNC_WBS",
    VIRTUAL_UPDATE_PROGRESS: "VIRTUAL_UPDATE_PROGRESS",
    VIRTUAL_CREATE_TOUR: "VIRTUAL_CREATE_TOUR",
    VIRTUAL_EDIT_TOUR: "VIRTUAL_EDIT_TOUR",
    VIRTUAL_EDIT_TOUR_TOWER: "VIRTUAL_EDIT_TOUR_TOWER",
    VIRTUAL_EDIT_TOUR_FLOOR: "VIRTUAL_EDIT_TOUR_FLOOR",
    VIRTUAL_DELETE_TOUR: "VIRTUAL_DELETE_TOUR",
    VIRTUAL_DELETE_WALKTHROUGH: "VIRTUAL_DELETE_WALKTHROUGH",
    VIRTUAL_SEND_NOTIFICATION: "VIRTUAL_SEND_NOTIFICATION",

    //Work Schedule
    WORK_SCHEDULE_EXTERIOR_ADD: "WORK_SCHEDULE_EXTERIOR_ADD",
    WORK_SCHEDULE_EXTERIOR_EDIT: "WORK_SCHEDULE_EXTERIOR_EDIT",
    WORK_SCHEDULE_EXTERIOR_DELETE: "WORK_SCHEDULE_EXTERIOR_DELETE",
    WORK_SCHEDULE_INTERIOR_ADD: "WORK_SCHEDULE_INTERIOR_ADD",
    WORK_SCHEDULE_INTERIOR_EDIT: "WORK_SCHEDULE_INTERIOR_EDIT",
    WORK_SCHEDULE_INTERIOR_DELETE: "WORK_SCHEDULE_INTERIOR_DELETE",
    WORK_SCHEDULE_BULK_UPLOAD: "WORK_SCHEDULE_BULK_UPLOAD",
    WORK_SCHEDULE_INTERIOR_CALCULATE_WEIGHTAGE:
      "WORK_SCHEDULE_INTERIOR_CALCULATE_WEIGHTAGE",

    //Work Location
    WORK_LOCATION_ADD: "WORK_LOCATION_ADD",
    WORK_LOCATION_EDIT: "WORK_LOCATION_EDIT",
    WORK_LOCATION_DELETE: "WORK_LOCATION_DELETE",
    WORK_LOCATION_BULK_UPLOAD: "WORK_LOCATION_BULK_UPLOAD",
    WORK_LOCATION_UPLOAD_FLOOR_PLAN: "WORK_LOCATION_UPLOAD_FLOOR_PLAN",
    WORK_LOCATION_UPLOAD_BIM_MODEL: "WORK_LOCATION_UPLOAD_BIM_MODEL",
    WORK_LOCATION_DELETE_FLOOR_PLAN: "WORK_LOCATION_DELETE_FLOOR_PLAN",

    //Work Trade
    WORK_TRADE_ADD: "WORK_TRADE_ADD",
    WORK_TRADE_EDIT: "WORK_TRADE_EDIT",
    WORK_TRADE_DELETE: "WORK_TRADE_DELETE",
    WORK_TRADE_BULK_UPLOAD: "WORK_TRADE_BULK_UPLOAD",
  },
  snagReport: {
    reportHeader: "Punchlist report",
    reportCoverPage: "Punchlist Report",
    preparedBy: "Prepared By:",
    preparedOn: "Prepared On:",
    punchListSummary: "Punchlist Summary",
  },
  WBS_FORMAT: {
    XER: "xer",
    MPP: "mpp",
  },
};
