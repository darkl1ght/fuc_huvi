import { SnackbarService } from "src/app/core/snackbar/snackbar.service";
import { Inject, Injectable } from "@angular/core";
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpErrorResponse,
} from "@angular/common/http";
import { BehaviorSubject, Observable, throwError } from "rxjs";
import { APP_CONFIG, AppConfig } from "src/config/app-config.module";
import { IntegrationService, JwtService } from "../services";
import { catchError, filter, switchMap, take } from "rxjs/operators";
import { TranslateService } from "@ngx-translate/core";

@Injectable()
export class HttpTokenInterceptor implements HttpInterceptor {
  tokenExclude: string[];
  private procoreRefreshingInProgress: boolean;
  private procoreAccessTokenSubject: BehaviorSubject<string> =
    new BehaviorSubject<string>(null);

  constructor(
    private jwtService: JwtService,
    @Inject(APP_CONFIG) private config: AppConfig,
    private integrationService: IntegrationService,
    private snackbarService: SnackbarService,
    private ts: TranslateService
  ) {
    this.tokenExclude = this.config.tokenExclude;
  }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(this.addAuthorizationHeader(req)).pipe(
      catchError((err) => {
        if (
          req.url.includes(this.config.procoreBaseUrl) &&
          err instanceof HttpErrorResponse &&
          err.status === 401
        ) {
          const [procoreAccessToken, procoreRefreshToken] =
            this.integrationService.getProcoreTokens();

          if (procoreAccessToken && procoreRefreshToken) {
            return this.refreshProcoreToken(req, next);
          } else {
            this.showLoginToProcoreWarning();
            return throwError(err);
          }
        } else if (
          req.url.includes("/integration/procore/refreshprocoretoken") &&
          err instanceof HttpErrorResponse &&
          err.status === 403 &&
          err.error?.statusCode === 401
        ) {
          this.showLoginToProcoreWarning();
          return throwError(err);
        } else if (
          req.url.includes("/integration/procore/") &&
          err instanceof HttpErrorResponse &&
          err.status === 403 &&
          err.error?.statusCode === 401
        ) {
          const [procoreAccessToken, procoreRefreshToken] =
            this.integrationService.getProcoreTokens();

          if (procoreAccessToken && procoreRefreshToken) {
            return this.refreshProcoreToken(req, next);
          } else {
            this.showLoginToProcoreWarning();
            return throwError(err);
          }
        }

        return throwError(err);
      })
    );
  }

  private addAuthorizationHeader(req: HttpRequest<any>): HttpRequest<any> {
    if (this.tokenExclude.find((item) => req.url.includes(item))) {
      return req;
    }

    if (req.url.indexOf("blob.core.windows.net") > -1) {
      return req;
    } else if (req.url.indexOf("api.openweathermap.org") > 0) {
      const headersConfigWeather = {
        "Content-Type": "text/plain",
        Accept: "application/json",
      };
      return req.clone({ setHeaders: headersConfigWeather });
    } else if (req.url.includes(this.config.procoreBaseUrl)) {
      const procoreAccessToken =
        this.integrationService.getProcoreAccessToken();

      if (procoreAccessToken) {
        const headersConfigProcore = {
          Authorization: `Bearer ${procoreAccessToken}`,
        };
        return req.clone({ setHeaders: headersConfigProcore });
      } else {
        this.showLoginToProcoreWarning();
      }
    } else {
      const headersConfig =
        req.url.indexOf("mapboxupload") > 0 ||
        (req.url.indexOf("forge") > 0 && req.url.indexOf("upload") > 0) ||
        req.url.indexOf("elevation-file-upload") > 0 ||
        req.url.indexOf("upload360ViewerImage") > 0
          ? {}
          : {
              "Content-Type": "application/json",
              Accept: "application/json",
            };
      const token = this.jwtService.getToken();

      if (token) {
        headersConfig["Authorization"] = `Token ${token}`;
      }

      if (
        req.url.includes("/integration/procore/") &&
        !req.url.includes("/integration/procore/procoretokenexchange")
      ) {
        const procoreAccessToken =
          this.integrationService.getProcoreAccessToken();

        if (procoreAccessToken) {
          headersConfig["Procore-Token"] = procoreAccessToken;
        }
      }

      return req.clone({ setHeaders: headersConfig });
    }
  }

  private refreshProcoreToken(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (!this.procoreRefreshingInProgress) {
      this.procoreRefreshingInProgress = true;
      this.procoreAccessTokenSubject.next(null);

      return this.integrationService.refreshProcoreToken().pipe(
        switchMap((res) => {
          this.procoreRefreshingInProgress = false;
          this.procoreAccessTokenSubject.next(res.access_token);
          return next.handle(this.addAuthorizationHeader(request));
        })
      );
    } else {
      return this.procoreAccessTokenSubject.pipe(
        filter((token) => token !== null),
        take(1),
        switchMap(() => {
          return next.handle(this.addAuthorizationHeader(request));
        })
      );
    }
  }

  private showLoginToProcoreWarning() {
    this.snackbarService.warningSnackBar(
      this.ts.instant("integration.procore.messages.loginToProcore")
    );
  }
}
