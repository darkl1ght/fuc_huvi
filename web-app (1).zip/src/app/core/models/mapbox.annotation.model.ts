import { Lookup } from "./lookup.model";

export interface MapboxAnnotation {
  area: string;
  perimeter: string;
  polygonVertices: any;
  drawnPolygonId: string;
  polygon_label: string;
  polygon_color: string;
}

export interface MapBoxAnnotationData {
  tourId: string;
  projectId: any;
  annotation: MapboxAnnotation;
  listType: Lookup[];
}

export interface MapVolumeData {
  volumeUniqueId: string;
  label: string;
  isSurfaceElevationRequest: boolean;
  surfaceElevation: string;
  volume: any;
  polygonGeojson: any;
  pointGeojson: any;
  tourId: string;
  projectId: string;
  machineId: string;
  tourType: string;
  status: string;
  createdBy: string;
  createdAt: string;
}

export interface UpdateWbsProgressBulk {
  wbsId: string;
  progress: number;
  comment: string;
}

export interface UpdateWbsProgressIntBulk {
  projectId: string;
  interiorId: string;
  tourId: string;
  towerId: string;
  floorId: string;
  unitId?: string;
  wbsList: UpdateWbsProgressBulk[];
}

export interface ElevationProfileData {
  elevationProfileUniqueId: string;
  label: string;
  lineString: any;
  tourId: string;
  projectId: string;
  machineId: string;
  tourType: string;
  status: string;
  createdBy: string;
  createdAt: string;
  elevProfileChartInfo: any;
  resolution: string;
  lineChartData?: any;
  lineChartLabels?: any;
  backgroundColors?: any;
}
