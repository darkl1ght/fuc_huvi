export interface MapboxLayer {
  dataType?: string;
  type: string;
  order?: number;
  key?: string;
  value?: string;
  code?: string;
  url?: string;
  minZoom?: number;
  maxZoom?: number;
  tilesetId?: string;
  sourceLayer?: string;
  data?: any;
  tilesize?: number;
  appendIndex: number;
  disabled: boolean;
  csvData?: [];
  geojsonData?: any;
  kmlSourceLayers?: KmlSourceLayer[];
  uploadedTo?: string;
  uploadedAt?: any;
  shapeFileData?: UserShapeSourceLayer;
}

export interface KmlSourceLayer {
  geometry: string;
  "source-layer": string;
  layerId: string;
}

export interface UserShapeSourceLayer {
  type: string;
  columns?: any;
}
