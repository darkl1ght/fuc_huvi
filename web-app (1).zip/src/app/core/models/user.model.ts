export interface User {
  id: string;
  email: string;
  token: string;
  firstName: string;
  lastName: string;
  isAdmin: boolean;
  bio: string;
  phone: string;
  password: string;
  image: string;
  signature?: any;
  language?: string;
}
