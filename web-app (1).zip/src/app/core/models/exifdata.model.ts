export interface ExifData {
  fileId: string;
  blobRef: string;
  fileName: string;
  lat: string;
  lng: string;
  alt: string;
  dateTaken: string;
  fileSize: number;
}
