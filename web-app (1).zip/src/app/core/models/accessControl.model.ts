export interface RoleMapping {
  objectKey: string;
  module?: string;
  type?: string;
  isAllowed: boolean;
  isRedactable?: boolean;
  isRedacted: boolean;
  permissionValue?: any;
}

export interface AccessMapping {
  role: string;
  desc?: string;
  accessMapping: RoleMapping[];
}

export interface AccessMappingLocalStorage {
  role: string;
  desc?: string;
  projectId: string;
  accessMapping: RoleMapping[];
}

export interface ProjectRole {
  role: string;
  desc: string;
}

export interface AccessPoint {
  isAllowed: boolean;
  isRedacted: boolean;
}

export interface AccessRoles {
  role: string;
  desc: string;
  length: number;
}

export interface AccessMappings {
  accessMappings: RoleMapping[];
}
