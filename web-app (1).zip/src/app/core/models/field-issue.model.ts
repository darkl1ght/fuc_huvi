import { TourImage } from "./interiortour.model";

/**
 * FI is Field Issue
 */
export interface FIComponentData {
  eventType: string;
  data: FI;
}

export interface OriginalPanellumPositionParameters {
  origPitchBounds: any;
  origYawBounds: any;
  origHfovBounds: any;
}

export interface PanellumHotspot {
  id: string;
  pitch: number;
  yaw: number;
  type: string;
  cssClass?: string;
  createTooltipFunc?: any;
  createTooltipArgs?: string;
  tooltip?: string;
}

/**
 * FI is Field Issue
 */
export interface FI {
  issueId: string;
  issueNumber: number;
  tour: TourImage;
  tourId: string;
  projectId: string;
  towerId: string;
  floorId: string;
  interiorId: string;
  towerName: string;
  tourName: string;
  status: string;
  dueDate: Date;
  description?: string;
  wbsLinks?: [];
  assignee: string;
  priority: string;
  workTrade: any;
  watchList: any;
  tags: string[];
  discussion: FIDisucussion[];
  hotspot: PanellumHotspot;
  snapshot: any;
  viewer?: any;
  attachments: FIAttachment[];
  createdBy?: string;
  updatedBy?: string;
  createdAt?: any;
  updatedAt?: any;
  statusColor?: any;
  floorplanImage: FIAttachment;
  snapshotImage: FIAttachment;
  currentImageId: string;
  fieldIssueRefId?: string;
  newDiscussion?: FIDisucussion;
  updatedDiscussion?: FIDisucussion[];
  maState: any;
}

/**
 * FI is Field Issue
 */
export interface FIAttachment {
  type?: string;
  name?: string;
  file?: File;
  size?: number;
  uploadFileType?: string;
  fileObjectId?: string;
  downloadUrl?: string;
  viewUrl?: string;
  isNew?: boolean;
}

/**
 * FI is Field Issue
 */
export interface FIDisucussion {
  discussionId: string;
  from: string;
  createdAt: string;
  updatedAt: string;
  content: string;
  mention: string[];
  isEdited?: boolean;
  isEditedByUser: boolean;
  isDeleted: boolean;
}

/**
 * FIDP is Field Issue Detail Panel
 */
export interface FIDPCloseAction {
  type: string;
  refresh: boolean;
  removeHotspot: boolean;
  setOriginalBound: boolean;
}

export interface FieldIssueFilter {
  createdDateFilterOperator?: string;
  createdDateFilter?: Date;
  createdDateFilterRangeStartDate?: Date;
  createdDateFilterRangeEndDate?: Date;
  isFilterApplied?: boolean;
}

export interface Person {
  firstName: string;
  lastName: string;
  email: string;
}
