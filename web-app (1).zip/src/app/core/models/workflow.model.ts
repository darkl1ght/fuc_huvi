export interface WorkFlow {
  projectId: string;
  type: string;
  name: string;
  orderNo: number;
  isActive: Boolean;
  createdAt: string;
  updatedAt: string;
}
