export interface ProjectUser {
  memberId: string;
  firstName: string;
  lastName: string;
  email: string;
  contactNo?: string;
  isActive: boolean;
  isBlocked: boolean;
  role: { code: string; desc: string };
  createdDate?: string;
  signature?: any;
  dashboard?: { overall: any; me: any };
}

export interface ProjectTeamDialogData {
  projectId: string;
  user: ProjectUser;
}

export interface ProjectUsers {
  users: ProjectUser[];
}
