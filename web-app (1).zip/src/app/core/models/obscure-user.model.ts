export interface ObscureUser {
  userId: string;
  email: string;
  token: string;
  firstName: string;
  lastName: string;
  userToken: string;
  clientId: string;
  obscureUrl: string;
}

export interface OBDialogData {
  clientId: string;
  userId: string;
  user: ObscureUser;
}
