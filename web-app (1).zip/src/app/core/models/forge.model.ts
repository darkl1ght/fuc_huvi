export interface ForgeTokenObject {
  accessToken: string;
  expiresIn: any;
}
export interface ForgeObject {
  urn: string;
  name?: string;
}
