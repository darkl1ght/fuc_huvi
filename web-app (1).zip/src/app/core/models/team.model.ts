export class SignatureDoc {
  imageId: string;
  imageName: string;
  blobContentId: string;
}
