export class BIMSyncModel {
  pitch: Number;
  yaw: Number;
  fov: Number;
  heading: Number;
  floorPlanOrientation: Number;
  bimAngularDeviationFromTrueNorth: Number;

  constructor(
    viewer: any,
    floorPlanOrientation: Number = 0,
    bimAngularDeviationFromTrueNorth: Number = 0
  ) {
    this.pitch = viewer.getPitch();
    this.yaw = viewer.getYaw();
    this.fov = viewer.getHfov();
    this.heading = viewer.getNorthOffset();
    this.floorPlanOrientation = floorPlanOrientation;
    this.bimAngularDeviationFromTrueNorth = bimAngularDeviationFromTrueNorth;
  }
}
