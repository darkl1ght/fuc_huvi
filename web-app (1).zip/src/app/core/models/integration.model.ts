export interface ProcoreTokenExchangePayload {
  code: string;
  code_verifier: string;
  redirect_uri: string;
}

export interface ProcoreToken {
  access_token: string;
  created_at: number;
  expires_in: number;
  refresh_token: string;
  token_type: string;
}

export interface ProcoreCompany {
  id: number;
  name: string;
  is_active?: boolean;
  logo_url?: string;
  isLinked?: boolean;
}

export interface ProcoreProject {
  id: number;
  name: string;
  isLinked?: boolean;
}

export interface LinkedProject {
  companyId: number;
  companyName: string;
  projectId: number;
  projectName: string;
}

export interface ProcoreObservationType {
  id: number;
  name: string;
}

export interface ProcoreProjectUser {
  id: number;
  name: string;
  first_name: string;
  last_name: string;
  email_address: string;
}

export interface ProcoreProjectLocation {
  id: number;
  name: string;
  node_name: string;
  parent_id: string;
}

export interface ProcoreTrade {
  id: number;
  name: string;
}

export interface ProcoreSpecSection {
  id: number;
  description: string;
  label: string;
  number: string;
}

export interface ProcoreContributingCondition {
  id: number;
  name: string;
}

export interface ProcoreContributingBehavior {
  id: number;
  name: string;
}

export interface ProcoreHazard {
  id: number;
  name: string;
}

export interface ProcoreProject {
  id: number;
  name: string;
}

export interface FileAttachment {
  id: string;
  file: any;
}

export interface UpdateObservationDistributionMembersPayload {
  project_id: number;
  observation: {
    distribution_member_ids: number[];
  };
}
