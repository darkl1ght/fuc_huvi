import { ProjectUser } from "src/app/core";

export interface Cabinet {
  createdBy: string;
  appId?: string;
  supportedFileStorage?: any;
  id: string;
  metadata: IMetadata[];
}

export interface IMetadata {
  options?: string[];
  isRequired?: boolean;
  _id?: string;
  metadataId: string;
  label?: string;
  metadataType?: string;
  sortOrder?: number;
  value: any;
}

export interface CabinetFile {
  name: string;
  fileObjectId: string;
  fileSize: string;
  description: string;
  metadata: IMetadata[];
}

export interface BulkFileUploadPayload {
  cabinetRefId: string;
  createdBy: string;
  files: CabinetFile[];
  parentFolderRefId?: string;
}

export interface BulkFileUpdatePayload {
  cabinetRefId: string;
  files: FileObjectId[];
  parentFolderRefId: string;
}

export interface FileObjectId {
  fileObjectId: string;
}

export interface PresignedURLResponse {
  files: {
    fileObjectId: string;
    fileId: string;
    signedUrl: string;
    image?: File;
    fileMarkerInfo?: {
      latitude: number;
      longitude: number;
      name: string;
    };
  }[];
}

export interface FolderPayload {
  isCreate: boolean;
  folderId?: string;
  name: string;
  description: string;
  cabinetRefId: string;
  parentFolderRefId?: string;
  projectId: string;
  additionalInfo?: string;
  status: boolean;
}

export interface CreateFolderPayload {
  name: string;
  description: string;
  cabinetRefId: string;
  parentFolderRefId?: string;
  projectId: string;
  additionalInfo?: string;
  status: boolean;
}

export interface UpdateFolderPayload {
  name: string;
  description?: string;
  cabinetRefId: string;
  parentFolderRefId: string;
  projectId: string;
  status: boolean;
}

export interface CreateProjectFolderPayload {
  companyId: string;
  projectId: string;
  projectName: string;
}

export interface CreateConstraCompanyPayload {
  companyName: string;
  storageType: string;
  companyId: string;
  permissions?: Array<string>;
  retentionPolicy?: string;
}

export interface FileUpdateStatusResponse {
  downloadUrl: string;
  fileObjectId: string;
  viewUrl: string;
}

export interface BulkFilePayload {
  cabinetRefId: string;
  parentFolderRefId: string;
  files: FilePayload[];
}

export interface FilePayload {
  name: string;
  description?: string;
  metadata: IMetadata[];
  fileObjectId: string;
  fileSize: string;
}

export interface FileEditVersion {
  versionId: string;
  versionNumber: string;
}

export interface FileEditPayload {
  fileObjectId: string;
  name: string;
  description?: string;
  metadata?: IMetadata[];
  version?: FileEditVersion;
}

export interface UploadFileLibrary {
  id: number;
  name: string;
  file: File;
  isEditable: boolean;
  fileObjectId?: string;
}

export interface FileVersionNumber {
  $numberDecimal: string;
}

export interface FileVersion {
  id: string;
  status: boolean;
  versionBy: string;
  versionFileObjectId: string;
  versionName: string;
  fileSize: string;
  fileSizeReadable?: string;
  versionNumber: FileVersionNumber;
  createdAt: Date;
  updatedAt: Date;
  createdDatetime?: Date;
  updatedDatetime?: Date;
  updatedAtMoment?: string;
}

export interface FileTag {
  id: string;
  name: string;
}

export interface IFile {
  id: string;
  name: string;
  fileObjectId: string;
  fileSize: string;
  metadata: IMetadata[];
  description: string;
  cabinetRefId: string;
  parentFolderRefId?: string;
  fileStorageType: string;
  viewUrl: string;
  downloadUrl: string;
  thumbnailUrl?: string;
  isNotPublished?: boolean;
  mediaTypeCode?: string;
  updatedBy: string;
  updatedOn: Date;
  updatedAt: Date;
  createdAt?: Date;
  tagList?: string[];
  versions?: FileVersion[];
  migratedOn?: Date;
  migratedUpdatedOn?: Date;
  annotations?: FileAnnotation[];
  features?: any;
  comments?: FileComment[];
  tags?: FileTag;
}

export interface UploadMediaFiles {
  id: number;
  name: string;
  file: File;
  fileObjectId?: string;
  progress?: number;
}

export interface BulkFileUpdateResponse {
  fileObjectId: string;
  fileId: string;
  signedUrl: string;
}

export interface Folder {
  id: string;
  name: string;
  description: string;
  cabinetRefId: string;
  parentFolderRefId?: string;
  additionalInfo?: string;
  fileCount: number;
  folderCount?: number;
  updatedBy: string;
  updatedOn: Date;
  updatedAt: Date;
  createdAt?: Date;
  createdBy: string;
  migratedOn?: Date;
  migratedUpdatedOn?: Date;
}

export interface FolderContents {
  folders: Folder[];
  files: IFile[];
  totalFolderCount?: number;
  totalFileCount?: number;
}

export interface FileGrid {
  type: string;
  icon?: string;
  id: string;
  fileObjectId?: string;
  description?: string;
  fileSize?: string;
  isSelected: boolean;
  fileCount?: number;
  folderCount?: number;
  name: string;
  parentFolderRefId: string;
  metadata?: IMetadata[];
  category?: string;
  otherCategory?: string;
  downloadUrl: string;
  viewUrl: string;
  thumbnailUrl: string;
  isThumbnailLoaded?: boolean;
  isNotPublished?: boolean;
  mediaTypeCode?: string;
  lastModifiedBy: string;
  updatedAt: Date;
  createdAt?: Date;
  lastModifiedDate: string;
  tagList?: string[];
  versions?: FileVersion[];
  currentVersion?: string;
  migratedOn?: Date;
  migratedUpdatedOn?: Date;
  index?: number;
  annotations?: FileAnnotation[];
  features?: any;
  comments?: FileComment[];
  tags?: FileTag;
}

export interface FolderPath {
  id: string;
  name: string;
  parentFolderRefId: string;
}

export interface MediaGrid {
  type: string;
  id: string;
  isSelected: boolean;
  fileCount: number;
  name: string;
  createdBy: string;
  createdDate: string;
  downloadUrl: string;
  commentsStatus: boolean;
  parentFolderRefId: string;
}

export interface FileId {
  fileId: string;
}

export interface FolderId {
  folderId: string;
}

export interface DeleteFileBulk {
  isSoftDelete: boolean;
  parentFolderRefId: string;
  files: FileId[];
}

export interface FolderTree {
  id: string;
  name: string;
  parentFolderRefId: string;
  subFolders?: FolderTree[];
}

export interface DeleteFolder {
  isSoftDelete: boolean;
  projectId: string;
  cabinetRefId: string;
}

export interface DeleteFolderBulk {
  isSoftDelete: boolean;
  projectId: string;
  cabinetRefId: string;
  folders: FolderId[];
}

export interface UploadFilePayload {
  cabinetRefId: string;
  parentFolderRefId: string;
  name: string;
  description: string;
  metadata: IMetadata[];
  fileObjectId: string;
  fileSize: string;
  fileContent: File;
  tagList?: string[];
}
export interface UploadFileListData {
  name: string;
  fileObjectId: string;
  progress: number;
}

export interface ThumbnailView {
  enabled: boolean;
  folder: boolean;
  file: boolean;
}

export interface FileVersionUploadUrlPayload {
  fileId: string;
  versionFileObjectId: string;
}

export interface CreateFileVersionUploadUrlResponse {
  fileId: string;
  versionFileObjectId: string;
  versionUploadUrl: string;
}

export interface UpdateFileVersionPayload {
  fileId: string;
  name: string;
  fileSize: string;
  versionFileObjectId: string;
  versionNumber: string;
}

export interface UpdateFileVersionResponse {
  fileId: string;
  fileObjectId: string;
  viewUrl: string;
  downloadUrl: string;
}

export interface FileDownloadUrlResponse {
  fileId: string;
  fileObjectId: string;
  downloadUrl: string;
}
export interface PaginatePayload {
  sortBy: string;
  sortDirection: number;
  limit: number;
  page: number;
  folderCount: number;
}

export interface RecordCountStatus {
  count: number;
  total: number;
}

export interface FileTagPayload {
  fileId?: string;
  tagList: string[];
}

export interface ImageViewerData {
  image: FileGrid;
  allImages: FileGrid[];
  projectId: string;
}

export interface PdfViewerData {
  image: FileGrid;
  projectId: string;
}

export interface VideoViewerData {
  video: FileGrid;
  allVideos: FileGrid[];
  projectId: string;
}
export interface AnnotationShape {
  guid: string;
  label: string;
  type: string;
}

export interface FileAnnotation {
  annotationId: string;
  annotationTitle: string;
  description: string;
  tags: [];
  shape: AnnotationShape;
  hidden?: boolean;
}

export interface SaveAnnotationNFeaturesPayload {
  fileId: string;
  annotation: FileAnnotation;
  features: any;
}

export interface UpdateFeaturesPayload {
  features: any;
}

export interface FileComment {
  commentId: string;
  body: string;
  createdAt: string;
  createdByName: string;
  createdByEmail: string;
}

export interface AddFileCommentPayload {
  commentId: string;
  comment: string;
  projectName: string;
  projectUsers: ProjectUser[];
}

export interface UpdateMediaBulkPayload {
  cabinetRefId: string;
  currentParentFolderRefId: string;
  targetParentFolderRefId: string;
  projectId: string;
  description: string;
  tagList: string[];
  files: FileId[];
}

export interface UpdateContent {
  cabinetRefId: string;
  projectId: string;
  currentParentFolderRefId: string;
  files: FileId[];
  folderTree: FolderTree;
  description?: string;
  tagList?: string[];
}
