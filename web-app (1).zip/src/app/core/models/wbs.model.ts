export class WBSData {
  id: number;
  wbsId: string;
  description: string;
  startDate: string;
  finishDate: string;
  duration: number;
  weightage: number;
  category?: string;
  classification?: string;
}

export class ProjectWBS {
  projectId: string;
  towerId: string;
  floorId: string;
  startDate: string;
  finishDate: string;
  captureInterval: number;
  wbsList: WBSData[] = [];
}

export class WorkSchedule {
  captureInterval: Number;
  projectStartDate: Date;
  projectFinishDate: Date;
  projectId: string;
  wbsList: WBSActivity[] = [];
}

export class WBSActivity {
  activityName: string;
  taskType: string;
  location: string;
  taskStart: string;
  taskEnd: string;
  category?: string;
  classification?: string;
}
