import { LatLng } from "leaflet";
import { AecLevel, BIM } from "./master-data.model";

export class InteriorTour {
  _id: string;
  interiorId: string;
  projectId: string;
  interiorName: string;
  interiorDate: string;
  status: any;
  tours: any[];
  isActive: boolean;
  tagList: string[];
  mapType: string;
  staticMap: {
    charts: any;
    urls: any;
  };
  isPannellum: boolean;
  floorWalkthough: any[];
  isDashboardPublished: boolean;
  createdBy: string;
  updatedBy: string;
  totalTour: number;
  isPublished: boolean;
  towerName: string;
  towerId: string;
  bim: BIM;
}

export class TourImage {
  tourId: string;
  towerId: string;
  interiorId: string;
  projectId: string;
  locationId: string;
  tourName: string;
  floorPlanBlobId: string;
  isDashboardPublished: string;
  floorPlanUrl: string;
  floorPlanOrientation: number;
  features: any;
  remarks: any;
  charts: [];
  images: InteriorImage[];
  isActive: boolean;
  isPublished: boolean;
  createdBy: string;
  updatedBy: string;
  updatedAt: string;
  tourPublishDate: string;
  transformationScale: number;
  aecLevel: AecLevel;
  origin?: LatLng;
  bimAngularDeviationFromTrueNorth?: Number;
  videoCaptureDetails?: any;
  lastFieldIssueNumber?: number;
}

export class InteriorImage {
  imageId: string;
  blobImageId: string;
  imageBlobUrl: string;
  imageName: string;
  imageNumber: number;
  linkage: [];
  createdBy: string;
  createdAt: string;
  offsetFromNorth: number;
}

export interface InteriorDialogData {
  projectId: string;
  interior: InteriorTour;
  interiorId: string;
  tourId: string;
  towerId: string;
  eventType: string;
}

export interface ProjectChart {
  chartId: string;
  chartTitle: string;
  chartType: string;
  chartData: any;
  createdBy: string;
}
export interface DashboardChart {
  orderNo: any;
  chartData: any;
  chartId: string;
  chartName: string;
  towerName: string;
  floorName: string;
  chartType: string;
  chartTitle: string;
  data: any;
  chartOptions?: any;
}

export interface StaticUrl {
  tourName: string;
  tourUrl: string;
}

export interface RemarkComment {
  commentId: string;
  remarkId: string;
  body: string;
  createdByName: string;
  createdByEmail: string;
}

export interface ForgeViewerComponentConfig {
  forgeObjectURN: string;
  origin: LatLng;
  aecLevel: AecLevel;
  modelOffset: any;
  transformationScale: number;
  event?: {
    type?: string;
    data?: any;
  };
}

export interface InteriorTagPayload {
  tagList: string[];
}
