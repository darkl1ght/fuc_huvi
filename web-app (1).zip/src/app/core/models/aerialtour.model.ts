export interface AerialTour {
  _id: string;
  tourId: string;
  projectId: string;
  tourName: string;
  tourDate: string;
  threeDUrl: string;
  status: any;
  images: Array<any>;
  charts: [];
  mapUrls: [];
  annotations: [];
  isPublished: boolean;
  totalImage: number;
  isActive: boolean;
  mapType: string;
  staticMap: {
    charts: any;
    urls: any;
  };
  lat?: any;
  lng?: any;
  legend: any;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
  code?: string;
  tagList: string[];
  isPointCloudAvailable?: string;
  isDashboardPublished: boolean;
  isSelfServe: boolean;
  isWBSPublished: boolean;
  tourCategory?: string;
  annotationTypes?: any;
  objectCount?: number;
}

export interface AerialImage {
  imageId: String;
  blobImageId: String;
  imageName: String;
  meta: {};
  createdBy: String;
  createdAt: String;
}

export interface AerialTourDialogData {
  projectId: string;
  tour: AerialTour;
  allTours?: AerialTour[];
  tourId: string;
}

export interface AerialTourComment {
  commentId: string;
  tourId: string;
  body: string;
  createdByName: string;
  createdByEmail: string;
  createdAt: string;
}

export class TourLegend {
  legendId: string;
  legendName: string;
  blobContentId: string;
}

export interface IUploadProgress {
  filename: string;
  progress: number;
}

export interface AerialTagPayload {
  tagList: string[];
}
