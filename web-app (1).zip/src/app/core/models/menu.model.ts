export enum MenuItems {
  NONE = "none",
  LOGIN = "Login",
  LOGOUT = "Logout",
  SAVE = "Save",
}

export function MENU_LABELS(): string[] {
  return Object.keys(MenuItems)
    .map((k) => MenuItems[k])
    .filter((m) => m != MenuItems.NONE);
}
