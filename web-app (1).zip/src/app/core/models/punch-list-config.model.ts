export interface PunchListConfig {
  tourId: string;
  projectId: string;
  type: string;

  filters: {
    punchListId?: string[];
    location?: string[];
    workPackage?: string[];
    priority?: string;
    startDate?: string;
    endDate?: string;
    createdStartDate?: string;
    createdEndDate?: string;
    assignee?: string[];
    isNonConformity?: boolean;
  };
}

export interface ExportData {
  "Punch Id": string;
  "Work Package": string;
  "Work Location - Level1": string;
  Description: string;
  Priority: string;
  "Due Date": string;
  "Level1 Status": string;
  "Level1 Verified By": string;
  "Level2 Status": string;
  "Level2 Verified By": string;
  Status: string;
  Remark: string;
  "Non Conformity?": string;
  "Created Date": string;
  "Created By": string;
}
