export class Rfi {
  projectId: string;
  rfiId: string;
  rfiNo: string;
  inspectionDate: string;
  inspectionTime: string;
  wbsId: string;
  workTradeId: string;
  towerId: string;
  floorId: string;
  sectionOfSpecification: string;
  drawingNumber: string;
  descriptionOfInspectionRequested: string;
  workFlow: [];
  history: [];
  checkList: [];
  sitePhotos: any = [];
  watchList: string;
  discussion: string;
  additionalComments: string;
  status: {
    key: string;
    value: string;
  };
  currentAssignee: {};
  createdBy: string;
  updatedBy: string;
  createdAt: string;
}

export class RfiTaskDialogData {
  projectId: string;
  rfiId: string;
  rfiType: string;
  rfiData: Rfi;
  teamMember: [];
  drawing: any;
}
