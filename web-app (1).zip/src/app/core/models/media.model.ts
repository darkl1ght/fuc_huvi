export class ProjectAlbum {
  albumId: string;
  albumName: string;
  albumDate: string;
  media: ProjectMedia[];
  projectId: string;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
  canDelete?: boolean;
}

export class MediaMetaData {
  fileName: string;
  lat: string;
  lng: string;
  alt: string;
  fileSize: number;
  dateTaken: string;
  updatedBy: string;
  updatedByEmail: string;
  updatedAt: string;
}

export class ProjectMedia {
  index: number;
  mediaId: string;
  projectId: string;
  mediaName: string;
  mediaDescription: string;
  fileDate: string;
  blobContentId: string;
  videoSource: any;
  albumId: string;
  annotations: any;
  mediaType: {};
  tags: any;
  comments: [];
  meta: MediaMetaData;
  features: any;
  isPublished: boolean;
  isSelected: boolean;
  isActive: boolean;
  createdBy: string;
  updatedBy: string;
}

export class AlbumDialogData {
  projectId: string;
  album: ProjectAlbum;
}

export class MediaDialogData {
  projectId: string;
  albumId: string;
  media: ProjectMedia;
}

export class MediaViewerData {
  projectId: string;
  token: string;
  media: ProjectMedia;
  mediaList: ProjectMedia[];
}

export interface MediaAnnotation {
  annotationId: String;
  annotationTitle: string;
  description: String;
  tags: [];
  shape: {};
  hidden?: boolean;
  createdBy: String;
  updatedBy: String;
  createdAt: String;
  updatedAt: String;
}

export interface MediaComment {
  commentId: string;
  mediaId: string;
  body: string;
  createdByName: string;
  createdByEmail: string;
}

export interface MediaUpdate {
  projectId: string;
  albumId: string;
  media: ProjectMedia;
  mediaIds: string[];
}

export interface MediaTag {
  name: string;
}
