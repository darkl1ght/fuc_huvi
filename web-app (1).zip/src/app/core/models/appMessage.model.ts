export interface Message {
  messageTitle: string;
  messageContent: string;
  sortOrder: number;
  isActive: boolean;
}

export interface AppMessage {
  appMessages: Message[];
}
