import { ProjectUser } from "./projectuser.model";

export interface ProjectListConfig {
  type: string;
  filters: {
    limit?: number;
    offset?: number;
  };
}

export interface Project {
  projectId: string;
  projectAdmin: string;
  projectName: string;
  location: string;
  lat: number;
  lng: number;
  type: { code: string; desc: string };
  isActive: Boolean;
  clientId: string;
  isCompleted?: string | boolean;
  contractEndDate?: Date;
  isSelfServe: Boolean;
  isExteriorWBSPublished: Boolean;
  isInteriorWBSPublished: Boolean;
  users: ProjectUser[];
  createdAt: string;
  updatedAt: string;
  isUnitLevel: boolean;
  excludeCaptureDateForInterior: boolean;
}

export class MapData {
  projectId: String;
  projectName: String;
  location: String;
  type: String;
}

export interface Reports {
  projectIds: Project[];
  startDate: Date;
  endDate: Date;
}

export interface CaptureMetrics {
  projectId: String;
  projectName: String;
  tourDate: string;
  tourName: string;
  floorName: string;
  towerName: string;
  imageCount: Number;
  type: String;
}

export interface ContractDates {
  clientName: String;
  projectName: String;
  contractEndDate: Date;
  status: String;
}
