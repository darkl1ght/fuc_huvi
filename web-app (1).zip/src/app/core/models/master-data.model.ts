import { ForgeObject } from "./forge.model";

export class WorkPackage {
  tradeId: string;
  tradeName: string;
  level1: string[];
  level2: string[];
  workFlow: any;
  workPackageCost?: number;
  createdBy: string;
  updatedBy: string;
}

export class WorkPackageData {
  projectId: string;
  workPackageId: string;
  workPackageName: string;
  level1: any;
  level2: any;
  members: any;
  workPackageCost: number;
}

export class WorkLocation {
  locationId: string;
  parentLocationId: string;
  orderNo: number;
  drawing: {
    drawingId: string;
    drawingName: string;
    blobContentId: string;
  };
  bim?: BIM;
  level1: string;
  level2: string;
  level3: string;
  level4: string;
  createdBy: string;
  updatedBy: string;
  level2BIMFloorName?: string;
  aecLevel?: AecLevel;
}

export class NewLocation {
  parentLocationId: string;
  level1: string;
  level2: string;
  level3: string;
  level4: string;
  orderNo: number;
}

export class BIM {
  forgeObject: ForgeObject;
  offset: { x: number; y: number; z: number };
  levels: AecLevel[];
  modelBound: number;
  transformationScale: number;
  uploadedBy: string;
  uploadedAt: Date;
  floorplanConfig: FloorplanConfig;
  bimAngularDeviationFromTrueNorth: number;
}

export class FloorPlanDoc {
  drawingId: string;
  drawingName: string;
  blobContentId: string;
}

export class BIMUploadDialog {
  projectId: string;
  locationId: string;
  updateChildElement: boolean;
}

export class BIMOffsetCalibrateDialog {
  projectId: string;
  bim: BIM;
  locationId: string;
  drawing: any;
}

export class BIMAEC {
  levels: AecLevel[];
}

export class AecLevel {
  guid: string;
  name: string;
  height: number;
  elevation: number;
}

export class LatLng {
  lat: number;
  lng: number;
}

export class FloorplanConfig {
  distanceOnFloorPlan?: number;
  point1?: LatLng;
  point2?: LatLng;
  origin?: LatLng;
}
