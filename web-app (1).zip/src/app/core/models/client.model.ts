export interface Client {
  clientId: string;
  clientName: string;
  email: string;
  firstName: string;
  lastName: string;
  blobContentId: string;
  isActive: Boolean;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface ClientData {
  client: Client;
  token: string;
  blobReadToken: string;
  isClientUpdate: boolean;
}

export interface ContractReport {
  clientIds: Client[];
  startDate: Date;
  endDate: Date;
}
