export class Lookup {
  id: number;
  type: string;
  key: string;
  value: string;
}
