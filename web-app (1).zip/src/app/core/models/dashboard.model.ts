export interface DashboardCard {
  id: number;
  label: string;
  order?: number;
  enabled: boolean;
  type: any;
  cols: number;
  rows: number;
  description: string;
  backgroundColor: string;
  isLoading?: boolean;
  options?: any;
  heading: string;
  category: string;
  _temp?: any;
}

export interface ITask {
  id: string;
  description: string;
  type?: string;
}
