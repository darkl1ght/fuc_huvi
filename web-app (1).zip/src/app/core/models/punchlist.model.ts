export class PunchItem {
  taskId: string;
  punchId: string;
  punchListId: string;
  projectId: string;
  taskDescription: string;
  punchItemMarkerId: string;
  tourId: string;
  remark: string;
  workLocation: {
    locationId: string;
    level1: string;
    level2: string;
    level3: string;
    level4: string;
  };
  workLocationData: string;
  workPackage: { tradeId: string; tradeName: string };
  taskPriority: { code: string; desc: string };
  level1Users: string[];
  level2Users: string[];
  level1Status: {
    status: { code: string; desc: string };
    comment: string;
    verifiedBy: string;
  };
  level2Status: {
    status: { code: string; desc: string };
    comment: string;
    verifiedBy: string;
  };
  dueDate: any;
  mediaList: any[];
  features: any;
  latestSnapshotBlobId: any;
  floorPlan: {};
  tags: [];
  comments: [];
  isNonConformity: Boolean;
  taskStatus: { code: string; desc: string };
  nonConformance: {
    rootCause: string;
    dueDate: string;
    approver: string;
    comment: string;
    action: string;
    completed: Boolean;
  };
  isActive: Boolean;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
}

export class PunchListData {
  workPackageId: string;
  tourId: string;
  tourName: string;
  punchItemMarkerId: string;
  punchItemMarkerLat: string;
  punchItemMarkerLng: string;
  markerType: string;
  punchItemPolygonMarkerId: string;
  stage1Approver: [];
  stage2Approver: [];
  punchListId: string;
  dueDate: string;
  priority: string;
  locations: string[];
  punchItems: PunchItem[];
  onsiteTaskId: string;
}

export class TaskDialogData {
  projectId: string;
  projectName: string;
  punchItem: PunchItem;
  priorityList: any;
}

export interface PunchListComment {
  commentId: String;
  comment: String;
  createdAt: String;
  createdBy: String;
}
