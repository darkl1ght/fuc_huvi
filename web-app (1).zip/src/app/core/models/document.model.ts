export interface Document {
  documentId: string;
  blobDocId: string;
  name: string;
  size: string;
  tagList: string[];
  history: [
    {
      blobDocId: String;
      name: String;
      size: String;
      lastUpdated: String;
      updatedAt: String;
    }
  ];
  isActive: boolean;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface DocumentDialogData {
  projectId: string;
  document: Document;
}

export interface DocumentHistory {
  blobDocId: String;
  name: String;
  size: String;
  lastUpdated: String;
  updatedAt: String;
}
