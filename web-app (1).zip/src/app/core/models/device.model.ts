export interface Device {
  deviceId: string;
  deviceName: string;
  projectId: string;
  deviceType: {};
  recording: boolean;
  isActive: boolean;
  rtmpUrl: string;
  upTime: number;
  bytesInRate: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface DeviceDialogData {
  projectId: string;
  device: Device;
  deviceId: string;
}
