import { Injectable } from "@angular/core";
import { SnackbarComponent } from "./snackbar.component";
import { MatSnackBarConfig, MatSnackBar } from "@angular/material/snack-bar";

@Injectable({
  providedIn: "root",
})
export class SnackbarService {
  configSuccess: MatSnackBarConfig = {
    panelClass: ["success-snackbar"],
    duration: 3000,
    horizontalPosition: "center",
    verticalPosition: "top",
  };

  configError: MatSnackBarConfig = {
    panelClass: ["error-snackbar"],
    duration: 3000,
    horizontalPosition: "center",
    verticalPosition: "top",
  };

  configWarning: MatSnackBarConfig = {
    panelClass: ["simple-snackbar"],
    duration: 3000,
    horizontalPosition: "center",
    verticalPosition: "top",
  };

  constructor(public snackBar: MatSnackBar) {}

  successSnackBar(message: string) {
    this.openSnackBarWithSuccess(message);
  }

  errorSnackBar(message: string) {
    this.openSnackBarWithError(message);
  }

  warningSnackBar(message: string) {
    this.openSnackBarWithWarning(message);
  }

  openSnackBarWithSuccess(message) {
    this.snackBar.openFromComponent(SnackbarComponent, {
      duration: 4000,
      data: message,
      ...this.configSuccess,
    });
  }

  openSnackBarWithError(message) {
    this.snackBar.openFromComponent(SnackbarComponent, {
      duration: 4000,
      data: message,
      ...this.configError,
    });
  }

  openSnackBarWithWarning(message) {
    this.snackBar.openFromComponent(SnackbarComponent, {
      duration: 8000,
      data: message,
      ...this.configWarning,
    });
  }
  openSnackBarWithErrorCustomDuration(
    message: string,
    duration: number = 8000
  ) {
    this.snackBar.openFromComponent(SnackbarComponent, {
      duration: duration,
      data: message,
      ...this.configError,
    });
  }
}
