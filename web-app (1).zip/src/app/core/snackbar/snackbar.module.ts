import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SnackbarComponent } from "./snackbar.component";
import { SnackbarService } from "./snackbar.service";
import { FlexLayoutModule } from "@angular/flex-layout";
import { MaterialModule } from "src/app/shared/material/material.module";

@NgModule({
  declarations: [SnackbarComponent],
  providers: [SnackbarService],
  imports: [CommonModule, MaterialModule, FlexLayoutModule],
})
export class SnackbarModule {}
